from pathlib import Path
import unittest

class Regression110(unittest.TestCase):
    def test_test_suite_does_not_hardcode_local_archive(self):
        text=(Path(__file__).parent/'test109.py').read_text()
        self.assertNotIn("Path('/mnt/data/dgus105_inner.zip')", text)
        self.assertIn("SV04_DGUS_ORIGINAL", text)
    def test_builder_preserved(self):
        self.assertTrue((Path(__file__).parents[1]/'tools'/'build109.py').exists())

if __name__=='__main__': unittest.main()
