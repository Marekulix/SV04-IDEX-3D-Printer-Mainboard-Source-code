import unittest,importlib.util,tempfile,zipfile,json,os
from pathlib import Path
spec=importlib.util.spec_from_file_location('m',str(Path(__file__).resolve().parents[1]/'tools'/'build109.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
ROOT=Path(__file__).resolve().parents[1]
# Stand 110: no absolute runner-specific test archive paths.
# Local fallback: SV04_DGUS_SOURCE_ZIP can reference the packaged Stand-105 source.
ZIP_ENV=os.environ.get('SV04_DGUS_SOURCE_ZIP')
ZIP=Path(ZIP_ENV) if ZIP_ENV else None
BASE='SV04_DGUS_EDITOR_SOURCE/'
class Test109(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  src=os.environ.get('SV04_DGUS_ORIGINAL')
  if src:
   cls.touch=(Path(src)/'DWIN_SET'/'13TouchFile.bin').read_bytes()
   cls.show=(Path(src)/'DWIN_SET'/'14ShowFile.bin').read_bytes()
  elif ZIP is not None:
   with zipfile.ZipFile(ZIP) as z:
    cls.touch=z.read(BASE+'DWIN_SET/13TouchFile.bin');cls.show=z.read(BASE+'DWIN_SET/14ShowFile.bin')
  else:
   raise RuntimeError('Set SV04_DGUS_ORIGINAL (GitHub) or SV04_DGUS_SOURCE_ZIP (offline)')
  cls.tpl=json.loads((ROOT/'OEM_MESH_OBJEKTE_106.json').read_text())
 def test_sizes(self):
  a=m.build_show(self.show,self.tpl);b,_=m.build_touch(self.touch)
  self.assertEqual(len(a)-len(self.show),512);self.assertEqual(len(b)-len(self.touch),32)
 def test_preserve_existing_objects(self):
  a=m.build_show(self.show,self.tpl);self.assertEqual(a[0x4000:0x5a80],self.show[0x4000:0x5a80])
  self.assertEqual(a[16:16+59*4],self.show[16:16+59*4])
 def test_show_page59_count(self):
  a=m.build_show(self.show,self.tpl);self.assertEqual(int.from_bytes(a[16+59*4:18+59*4],'little'),16)
  self.assertEqual(len(a[0x5a80:0x5c80]),512)
 def test_touch_preserved(self):
  a,_=m.build_touch(self.touch);self.assertEqual(a[:len(self.touch)-2],self.touch[:-2]);self.assertTrue(a.endswith(b'\xff\xff'))
 def test_touch_navigation(self):
  _,rr=m.build_touch(self.touch)
  self.assertEqual(rr[0][:2],b'\x00\x16');self.assertEqual(rr[0][10:12],b'\x00\x3b')
  self.assertEqual(rr[1][:2],b'\x00\x3b');self.assertEqual(rr[1][10:12],b'\x00\x01')
  self.assertTrue(all(x[12:16]==b'\xff\x00\xff\x00' for x in rr))
 def test_oem_guards(self):
  with self.assertRaises(ValueError):m.build_touch(self.touch+b'\x00')
  with self.assertRaises(ValueError):m.build_show(self.show+b'\x00',self.tpl)
 def test_no_out_of_bounds(self):
  with self.assertRaises(ValueError):m.basic_nav(59,(300,400,350,470),1)
 def test_missing_unknown_mesh(self):
  wrong=json.loads(json.dumps(self.tpl));wrong['objects'][0]['record_hex']='00'*32
  with self.assertRaises(ValueError):m.build_show(self.show,wrong)
 def test_project_hmi_entry(self):
  with tempfile.TemporaryDirectory() as d:
   src=Path(d);(src/"DWIN_SET").mkdir()
   (src/"DWIN_SET"/"13TouchFile.bin").write_bytes(self.touch)
   (src/"DWIN_SET"/"14ShowFile.bin").write_bytes(self.show)
   if os.environ.get('SV04_DGUS_ORIGINAL'):
    page22=(Path(os.environ['SV04_DGUS_ORIGINAL'])/'DWIN_SET'/'22.jpg').read_bytes()
   else:
    with zipfile.ZipFile(ZIP) as z: page22=z.read(BASE+'DWIN_SET/22.jpg')
   (src/'DWIN_SET'/'22.jpg').write_bytes(page22)
   (src/"DWprj.hmi").write_text("[INIT]\nSCREENDSIZE=272X480\n[IMG]\n0=0.jpg\n")
   out=src/"OUT"
   m.run(src,ROOT/"OEM_MESH_OBJEKTE_106.json",out)
   self.assertIn("59=59.jpg",(out/"EXPERIMENTELL_NICHT_INSTALLIEREN"/"DWprj.hmi").read_text())
 def test_direct_page_buttons_are_not_vps(self):
  _,rows=m.build_touch(self.touch)
  self.assertNotIn(b'\x13\x00',rows[0]);self.assertNotIn(b'\x13\x02',rows[1])
if __name__=='__main__':unittest.main()
