import unittest
from pathlib import Path
class Test111(unittest.TestCase):
    def test_payload_contains_builder(self):
        r=Path(__file__).resolve().parents[1]
        self.assertTrue((r/'tools'/'build109.py').is_file())
        self.assertTrue((r/'59.jpg').is_file())
        self.assertTrue((r/'OEM_MESH_OBJEKTE_106.json').is_file())
    def test_no_absolute_local_archive(self):
        self.assertNotIn('/mnt/data/dgus105_inner.zip',(Path(__file__).parent/'test109.py').read_text())
if __name__=='__main__':unittest.main()
