SV04 NEXT 109 | DWIN PUNKT 2 | EXPERIMENTELL, NICHT INSTALLIEREN

Großer Entwicklungsblock nach 108:
- Originale bphillips09/SV04-Touchscreen Quelle unverändert und SHA256-fixiert.
- 16 korrekt zugeordnete OEM Mesh-Anzeigeobjekte in neuer Seite 59.
- 2 neue DGUS-Basic-Touchobjekte für direktes Navigieren: Seite 22 -> 59, 59 -> 1.
- Neues sichtbares MESH-ANZEIGE-Tastenfeld auf OEM-Seite 22.
- 59.jpg ist als bestätigte 272x480-Projektressource im Paket enthalten.
- DWprj.hmi erhält die Bildzuordnung 59=59.jpg.
- Die ursprünglichen Marlin-Touchadressen 0x1300 / 0x1302 werden für diese direkte
  Displaynavigation nicht verwendet. Keine Änderungen am Marlin-Code.
- Die originale Touch-Konfiguration wird bytegenau beibehalten und nur erweitert.

DGUS-Format: Pic_ID 2 B, TP_Area 8 B, Pic_Next 2 B, Pic_On 2 B,
TP_Code 2 B. Für direkte Navigation wird TP_Code FF00 gesetzt.
Das Format beruht auf der veröffentlichten DWIN-DGUS-II-Dokumentation.
Eine Bestätigung der Interpretation auf diesem eingebauten Bildschirm fehlt.

Quellprojekt: bphillips09/SV04-Touchscreen @
5a3fae8c1ccdc04fb3372c077a61394e8a66ece4.
Original Show SHA256: 777d78bc05ca73cf15d7ab263edd129f196c133118c9ee8eef267c12d3497385
Original Touch SHA256: a7b0b51c2157acb37f3a42319b80c13c9736d740d41553646c80b132043342bd

Bauen: python tools/build109.py --source original-dgus --templates OEM_MESH_OBJEKTE_106.json --out output
Tests: SV04_DGUS_ORIGINAL=original-dgus python -m unittest discover -s tests -v

WICHTIG: Ein experimentell gepatchtes 13TouchFile.bin und 14ShowFile.bin ist
NICHT gleichbedeutend mit offizieller DGUS-Compiler-Ausgabe oder Hardwareprüfung.
Keine dieser Dateien auf den Drucker kopieren oder flashen.


## Stand 110 – Fehlerkorrektur GitHub 109

GitHub 109: Build SUCCESS, Audit SUCCESS, Tests 9/10 because test_project_hmi_entry
used a local absolute path `/mnt/data/dgus105_inner.zip`. Stand 110 reads the
original `DWIN_SET/22.jpg` from `SV04_DGUS_ORIGINAL` (normal GitHub workflow)
or uses the explicitly provided `SV04_DGUS_SOURCE_ZIP` only for local testing.
No changes to experimental DGUS binary generator. No install/flash permission.

## Stand 111: neue GitHub-Runde
Diese Nutzdateien werden als `111_A.zip` mit dem **genau passenden** Workflow `111_B.yml` bereitgestellt. Der Workflow liest ausdrücklich `111_A.zip` aus dem Repository-Hauptverzeichnis. Dies ist ein experimenteller DGUS-Quellstand, **NICHT INSTALLIEREN**.
