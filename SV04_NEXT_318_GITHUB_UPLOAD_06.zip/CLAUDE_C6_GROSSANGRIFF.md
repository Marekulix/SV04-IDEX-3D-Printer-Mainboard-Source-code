# CLAUDE – SV04 NEXT C6: GROSSANGRIFF AB 318

## Verbindlicher Eingang
- Dieses `SV04_NEXT_318_OEM_QUELLINTEGRATION_NO_FLASH.zip`.
- Reproduzierbare vollständige 309-OEM-Arbeitskopie (festgelegter Commit `1867fcba75354a5c65e0631d6972dd19f1bd6cbe`), nicht die 3-Dateien-Testfixture.
- C5-Rückgabe und Versionshistorie 309 bis 318 als Referenz.
- **Nicht** die alte C5-Adapterdatei über den 318/317-EEPROM-Adapter kopieren.

## Auftrag: ein einziger großer Entwicklungsdurchgang
1. **318 vollständig im Marlin-OEM-Baum zusammensetzen.** Auf neuer Kopie den 318-Installer verwenden, Quelle- und Referenzpins prüfen; fehlende Integrationsdateien und Includes sauber ergänzen. Keinen erfolgreichen Gesamtbuild vorwegnehmen.
2. **Zwei STM32-Profile** `integrated_backend` und `integrated_failclosed` wie beim Archivstand 309 mit PlatformIO `STM32F103RET6_creality` vollständig bauen. Originalbuild und modifizierten Build streng trennen. Buildprotokolle samt Exit-Codes, Speichergrößen und Quellhashes liefern. Falls Toolchain fehlt: Build als BLOCKED ausweisen und einen lauffähigen GitHub Actions Workflow samt separat nummernfreiem ZIP/YAML liefern.
3. **IDEX + BLTouch + G28:** C3/C5-Sicherheitsänderungen gegen echten Marlin-Code nachweisen. Werkzeugwechsel aller Modi, G28 X/Y/Z, Kaltstart, BLTouch-Fehler, Stoppzustand und Wiederanlauf testen. Die 410-mm-Grenze NICHT als kollisionssicher ausgeben. Automatik sperren, wenn reale Positionen nicht belegbar sind; kein Rückzug nach unsicherem Fehler.
4. **G29/Auto60/M420/EEPROM:** 60 °C M190-äquivalent mit Stabilisierung; G28-Freigabe; 4×4/16-Punkt-Messung; validiertes Mesh; M420 S1 und tatsächlichen Zustand; M500 nur nach Erfolg; vorheriges gültiges EEPROM-Mesh inklusive Journal schützen; unabhängige Rücklesung und Z-Offset-Check. Manual G29 und manuelle Bettausrichtung regressionsprüfen. Fehler und Stromausfall per kontrollierter Host-Simulation abdecken.
5. **DWIN:** Alle HMI-Objekte (inkl. der früher vereinbarten 16 Zuordnungen), Adresskonflikte, Anzeige-/Statuscodes, M1060 S2/S3, Fortschritt 1–16, Temperatur, 4×4-Messkarte und Abbruch prüfen. Falls DWIN-Ressourcen fehlen, konkret benennen, keine Attrappen als fertige Hardwareanbindung.
6. **Regression:** 315 EEPROM-Testfälle, 317-Z-Sperre und C5-G29-Sperre erneut gegen zusammengeführte Quellen prüfen; idempotente Patches, Fremdquellen-Abbruch, Byte-Vergleich und Reproduzierbarkeit. Tests mit FAIL/BLOCKED und echten Logs ausweisen.
7. **Hardware-Abnahmeplan:** T0/T1 reale Abstände, BLTouch-Auslöseverhalten, Start-/Homing-Kollisionsbedingungen und EEPROM-Speicherung getrennt als offen dokumentieren. Nichts flashen; keine Hardwarefreigabe.

## Lieferumfang
- `SV04_NEXT_CLAUDE_C6_GESAMTINTEGRATION.zip`: vollständige geänderte Quellen, Patches, Tests, echte Logs, Abweichungen zu 318, reproduzierbarer Build.
- Zweiter Download: `claude_c6_stm32_no_flash.yml` für GitHub, falls vor Ort kein Build möglich.
- Klarer Audit: neu bestätigt / ChatGPT-Annahme korrigiert / Claude-Fehler / offen / die **sechs** unveränderten Fortschrittsfelder samt tatsächlich belegten Änderungen, keine Fantasie-Prozente.
- **Keine Zwischenabnahmen** innerhalb des Großangriffs und kein Überschreiben der Version 309 oder 318.
