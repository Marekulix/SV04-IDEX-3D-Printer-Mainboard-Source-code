#!/usr/bin/env python3
"""Extract and COMPILE real sv04c_ee_commit from 314 and 315; old must fail negative cases."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parent

def fragment(p):
 s=p.read_text(); a=s.index('static bool sv04c_ee_commit(void *, uint32_t, bool verified) {')
 b=s.index('// UNABHAENGIGE Rueckablesung:',a)
 return s[a:b]

mock=r'''
#include <cstdint>
#include <cstdio>
#include <cstring>
namespace sv04c { namespace ee {
  enum PrimaryState { PR_UNREADABLE=0, PR_BLANK=1, PR_VALID=2, PR_CRC_BAD=3 };
  struct PrimaryInfo { PrimaryState st; };
  struct Store {};
  struct Block { uint16_t start,len; };
  struct ShadowPlan { bool ok; uint16_t data; };
  struct DiffSummary { uint16_t other; };
  enum Commit { CM_OK=0, CM_ROLLED_BACK, CM_ROLLBACK_FAILED, CM_CLEAR_FAILED };
  static Commit next_result=CM_OK;
  static PrimaryState next_primary=PR_VALID;
  static int commit_calls=0, primary_calls=0;
  inline Commit commit_transaction(const Store&,const ShadowPlan&,const Block&,bool) {++commit_calls;return next_result;}
  inline PrimaryInfo primary_info(const Store&,const Block&){++primary_calls;return {next_primary};}
  inline bool diff_regions(const Store&,uint16_t,uint16_t,uint16_t,uint16_t,bool,DiffSummary&) {return false;}
} }
using namespace sv04c;
static bool sv04c_ee_boot_blocked=false;
static uint8_t sv04c_ee_journal=0,sv04c_ee_last_commit=0;
static uint16_t sv04c_ee_unprotected_saves=0,sv04c_ee_other=0,sv04c_ee_mesh_at=0;
static bool sv04c_ee_mesh_found=false,access_ok=true;
static sv04c::ee::ShadowPlan sv04c_ee_plan={true,400};
static int messages=0;
struct Sv04cEeAccess{bool ok;Sv04cEeAccess():ok(access_ok) {}};
static sv04c::ee::Store sv04c_ee_store(){return sv04c::ee::Store();}
static sv04c::ee::Block sv04c_ee_block(){return {20,400};}
static void sv04c_ee_msg(const char*){++messages;}
#define SERIAL_ECHO_START() do{}while(0)
#define SERIAL_ECHOPGM(x) do{}while(0)
#define SERIAL_ECHOLNPGM(x) do{}while(0)
#define SERIAL_ECHO(x) do{}while(0)
'''

checks=r'''
static int checks=0,errors=0;
#define CHECK(c) do{++checks; if(!(c)){++errors; printf("FAIL %d: %s\n", __LINE__,#c);}}while(0)
static void reset(uint8_t journal,sv04c::ee::PrimaryState primary=sv04c::ee::PR_VALID,sv04c::ee::Commit result=sv04c::ee::CM_OK){
 sv04c_ee_boot_blocked=false;sv04c_ee_journal=journal;sv04c_ee_last_commit=0;
 sv04c_ee_unprotected_saves=0;sv04c_ee_other=0;sv04c_ee_mesh_at=0;sv04c_ee_mesh_found=false;
 access_ok=true;messages=0;sv04c::ee::next_result=result;sv04c::ee::next_primary=primary;
 sv04c::ee::primary_calls=0;sv04c::ee::commit_calls=0;
}
int main(){
  // Valid journal, successful commit, then duplicate must not be approved.
  reset(1);CHECK(sv04c_ee_commit(nullptr,12,true));CHECK(sv04c_ee_journal==0);
  CHECK(sv04c_ee_last_commit==1);CHECK(!sv04c_ee_boot_blocked);
  CHECK(!sv04c_ee_commit(nullptr,12,true));CHECK(sv04c_ee_boot_blocked);
  CHECK(sv04c::ee::commit_calls==1);CHECK(sv04c_ee_last_commit==8);

  reset(0);CHECK(!sv04c_ee_commit(nullptr,13,true));CHECK(sv04c_ee_boot_blocked);
  CHECK(sv04c_ee_journal==0);CHECK(sv04c_ee_last_commit==8);
  CHECK(sv04c::ee::commit_calls==0);CHECK(messages>=1);

  // A deliberately unprotected save is accepted ONLY if primary is valid.
  reset(2);CHECK(sv04c_ee_commit(nullptr,14,true));CHECK(sv04c_ee_journal==0);
  CHECK(sv04c_ee_unprotected_saves==1);CHECK(!sv04c_ee_boot_blocked);
  CHECK(sv04c_ee_last_commit==1);CHECK(sv04c::ee::primary_calls==1);

  reset(2,sv04c::ee::PR_CRC_BAD);CHECK(!sv04c_ee_commit(nullptr,15,true));
  CHECK(sv04c_ee_boot_blocked);CHECK(sv04c_ee_unprotected_saves==0);
  CHECK(sv04c_ee_journal==2);CHECK(sv04c_ee_last_commit==7);

  reset(3,sv04c::ee::PR_VALID);CHECK(sv04c_ee_commit(nullptr,16,true));
  CHECK(sv04c_ee_journal==0);CHECK(!sv04c_ee_boot_blocked);
  reset(3,sv04c::ee::PR_BLANK);CHECK(!sv04c_ee_commit(nullptr,17,true));
  CHECK(sv04c_ee_boot_blocked);CHECK(sv04c_ee_last_commit==7);

  // A virgin/blank region can be left untouched on cancel prior to save.
  reset(3,sv04c::ee::PR_BLANK);CHECK(sv04c_ee_commit(nullptr,18,false));
  CHECK(sv04c_ee_journal==0);CHECK(!sv04c_ee_boot_blocked);
  reset(3,sv04c::ee::PR_VALID);CHECK(!sv04c_ee_commit(nullptr,19,false));
  CHECK(sv04c_ee_boot_blocked);
  reset(2);CHECK(!sv04c_ee_commit(nullptr,20,false));CHECK(sv04c_ee_boot_blocked);

  // Missing access is a hard failure even on an otherwise valid no-journal write.
  reset(2);access_ok=false;CHECK(!sv04c_ee_commit(nullptr,21,true));
  CHECK(sv04c_ee_boot_blocked);CHECK(sv04c_ee_last_commit==6);
  reset(1);access_ok=false;CHECK(!sv04c_ee_commit(nullptr,22,true));CHECK(sv04c_ee_boot_blocked);
  CHECK(sv04c_ee_journal==1);

  // A result claiming rollback is never a successful verified save.
  reset(1,sv04c::ee::PR_VALID,sv04c::ee::CM_ROLLED_BACK);
  CHECK(!sv04c_ee_commit(nullptr,23,true));CHECK(sv04c_ee_boot_blocked);
  CHECK(sv04c_ee_journal==1);
  reset(1,sv04c::ee::PR_VALID,sv04c::ee::CM_ROLLED_BACK);
  CHECK(sv04c_ee_commit(nullptr,24,false));CHECK(!sv04c_ee_boot_blocked);
  CHECK(sv04c_ee_journal==0);
  reset(1,sv04c::ee::PR_CRC_BAD,sv04c::ee::CM_ROLLED_BACK);
  CHECK(!sv04c_ee_commit(nullptr,25,false));CHECK(sv04c_ee_boot_blocked);
  CHECK(sv04c_ee_journal==1);

  reset(1,sv04c::ee::PR_VALID,sv04c::ee::CM_CLEAR_FAILED);
  CHECK(!sv04c_ee_commit(nullptr,26,true));CHECK(sv04c_ee_boot_blocked);
  CHECK(sv04c_ee_journal==1);
  reset(1,sv04c::ee::PR_VALID,sv04c::ee::CM_ROLLBACK_FAILED);
  CHECK(!sv04c_ee_commit(nullptr,27,false));CHECK(sv04c_ee_boot_blocked);
  CHECK(sv04c_ee_journal==1);
  reset(1,sv04c::ee::PR_VALID,sv04c::ee::CM_OK);
  CHECK(sv04c_ee_commit(nullptr,28,false));CHECK(sv04c_ee_journal==0);
  CHECK(sv04c_ee_last_commit==2);
  reset(1);sv04c_ee_boot_blocked=true;
  CHECK(!sv04c_ee_commit(nullptr,29,true));CHECK(sv04c_ee_last_commit==8);
  CHECK(sv04c::ee::commit_calls==0);
  printf("COMMIT_CHECKS=%d FAIL=%d\n",checks,errors);
  return errors?1:0;
}
'''

def run(src):
 with tempfile.TemporaryDirectory() as d:
  cpp=Path(d)/'t.cpp';exe=Path(d)/'t'
  cpp.write_text(mock+fragment(src)+checks)
  p=subprocess.run(['g++','-std=c++11','-O2','-Wall','-Wextra','-Werror','-Wno-unused-function',str(cpp),'-o',str(exe)],capture_output=True,text=True)
  if p.returncode:raise RuntimeError(str(src)+' compilation: '+p.stderr)
  q=subprocess.run([str(exe)],capture_output=True,text=True)
  print(src.name,q.stdout.strip())
  return q.returncode,q.stdout

old=run(root/'auto60_adapter_314.inc')
new=run(root/'auto60_adapter_315.inc')
assert old[0]!=0,'Negative control failed to reproduce error'
assert new[0]==0,'315 did not pass'
print('PASS: negative control fails and fixed adapter passes')
