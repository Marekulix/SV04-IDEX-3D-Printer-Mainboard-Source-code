#!/usr/bin/env python3
"""Offline, standalone C++11 test of the actual adapter functions from 313/314.
The C++ fragments are extracted from source, not manually reimplemented.
"""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parent

def pick(s,a,b):
    start=s.index(a)
    stop=s.index(b,start)
    return s[start:stop]

stub=r'''
#include <stdint.h>
#include <cstdio>
#include <cstring>
#include <cassert>
namespace sv04c { namespace ee {
 enum PrimaryState { PR_BLANK, PR_VALID, PR_CRC_BAD };
 struct PrimaryInfo { PrimaryState st; };
 struct Store {};
 struct Block {};
 struct ShadowPlan { bool ok; uint16_t data; };
 enum ShadowCreate { SC_OK, SC_NO_SPACE, SC_PRIMARY_INVALID, SC_IO, SC_VERIFY, SC_UNRESOLVED_JOURNAL };
 static int create_calls=0; static ShadowCreate outcome=SC_OK;
 static PrimaryState state=PR_VALID; static bool has_room=true;
 PrimaryInfo primary_info(const Store&,const Block&){PrimaryInfo t={state};return t;}
 ShadowPlan shadow_plan(const Store&,const Block&){ShadowPlan p={has_room,1};return p;}
 ShadowCreate shadow_create(const Store&,const ShadowPlan&,const Block&,uint16_t){++create_calls;return outcome;}
}}
using namespace sv04c;
static bool sv04c_ee_boot_blocked=false;
static uint8_t sv04c_ee_journal=0;
static uint16_t sv04c_ee_other=0,sv04c_ee_seq=0;
static sv04c::ee::ShadowPlan sv04c_ee_plan;
static int announcements=0, messages=0;
static bool access_ok=true;
struct Sv04cEeAccess { bool ok; Sv04cEeAccess() : ok(access_ok) {} };
static sv04c::ee::Store sv04c_ee_store(){return sv04c::ee::Store();}
static sv04c::ee::Block sv04c_ee_block(){return sv04c::ee::Block();}
static bool sv04c_ee_policy_allows(bool blank,bool valid,bool room,bool required){return blank ||(valid && (room || !required));}
static void sv04c_ee_announce(uint8_t){++announcements;}
static void sv04c_ee_msg(const char*){++messages;}
static void sv04c_ee_boot(){}
#define SV04_CLAUDE_EEPROM_REQUIRE_JOURNAL 1
#define SERIAL_ECHO_START() do{}while(0)
#define SERIAL_ECHOLNPGM(x) do{}while(0)
'''
body=r'''
static int cases=0, failed=0;
#define CHECK(c) do{++cases;if(!(c)){++failed;printf("FAIL %d: %s\n",__LINE__,#c);}}while(0)
void reset() {
  sv04c_ee_boot_blocked=false;sv04c_ee_journal=0;sv04c_ee_other=0;sv04c_ee_seq=0;
  sv04c_ee_plan.ok=false;announcements=0;messages=0;access_ok=true;
  sv04c::ee::create_calls=0;sv04c::ee::outcome=sv04c::ee::SC_OK;
  sv04c::ee::state=sv04c::ee::PR_VALID;sv04c::ee::has_room=true;
}
int main(){
  reset();
  CHECK(sv04c_ee_start_ok());CHECK(sv04c_ee_prepare(nullptr,1));
  CHECK(!sv04c_ee_boot_blocked);CHECK(sv04c_ee_journal==1);CHECK(sv04c::ee::create_calls==1);

  reset();sv04c::ee::state=sv04c::ee::PR_BLANK;
  CHECK(sv04c_ee_prepare(nullptr,2));CHECK(sv04c_ee_journal==3);
  CHECK(sv04c::ee::create_calls==0);CHECK(!sv04c_ee_boot_blocked);

  reset();sv04c::ee::state=sv04c::ee::PR_CRC_BAD;
  CHECK(!sv04c_ee_start_ok());CHECK(!sv04c_ee_prepare(nullptr,3));CHECK(sv04c::ee::create_calls==0);

  reset();sv04c::ee::has_room=false;
  CHECK(!sv04c_ee_start_ok());CHECK(!sv04c_ee_prepare(nullptr,4));CHECK(sv04c::ee::create_calls==0);

  reset();access_ok=false;
  CHECK(!sv04c_ee_prepare(nullptr,5));CHECK(sv04c::ee::create_calls==0);

  for(int i=(int)sv04c::ee::SC_NO_SPACE;i<=(int)sv04c::ee::SC_UNRESOLVED_JOURNAL;i++){
    reset();sv04c::ee::outcome=(sv04c::ee::ShadowCreate)i;
    CHECK(!sv04c_ee_prepare(nullptr,6)); CHECK(sv04c::ee::create_calls==1);
    CHECK(sv04c_ee_boot_blocked);CHECK(messages==1);
    CHECK(!sv04c_ee_start_ok());
    sv04c::ee::outcome=sv04c::ee::SC_OK;
    CHECK(!sv04c_ee_prepare(nullptr,7));CHECK(sv04c::ee::create_calls==1);
    CHECK(sv04c_ee_journal==0);
  }
  printf("CHECKS=%d FAILED=%d\n",cases,failed);
  return failed?1:0;
}
'''

def run(file):
    code=file.read_text()
    fragments=pick(code,'static bool sv04c_ee_start_ok() {','// Vor dem ERSTEN Schreiben')+'\n'+pick(code,'static bool sv04c_ee_prepare(void *, uint32_t) {','// Abschluss: verified')
    with tempfile.TemporaryDirectory() as d:
        src=Path(d)/'test.cpp';exe=Path(d)/'test'
        src.write_text(stub+fragments+body)
        p=subprocess.run(['g++','-std=c++11','-Wall','-Wextra','-Werror','-Wno-unused-function','-O2',str(src),'-o',str(exe)],capture_output=True,text=True)
        if p.returncode:raise RuntimeError(file.name+' compile fail:\n'+p.stderr)
        p=subprocess.run([str(exe)],capture_output=True,text=True)
        print(file.name+'\n'+p.stdout)
        return p.returncode,p.stdout

after=run(root/'auto60_adapter_315.inc')
assert after[0]==0, '315 source regressed journal preparation safety'
print('315 PREPARE REGRESSION PASS: 57 checks')
