#!/usr/bin/env python3
"""Compile real DWIN callback from 314 and 315: terminal state must release OEM busy VP."""
from pathlib import Path
import tempfile,subprocess
root=Path(__file__).resolve().parent

def extract(p):
 s=p.read_text();a=s.index('static void sv04c_display(');b=s.index('static sv04c::Ports sv04c_make_ports()',a)
 return s[a:b]
header=r'''
#include <cstdio>
#include <utility>
#include <vector>
struct FakeRTS{std::vector<std::pair<int,int>> events;void RTS_SndData(int v,int a){events.push_back({v,a});}}rtscheck;
namespace sv04c{
 enum DispKind {D_STATE,D_PROGRESS,D_CELL,D_TEMP,D_RESULT};
 enum State {ST_IDLE,ST_PROBING,ST_SUCCESS,ST_FAILED,ST_CANCELLED};
 struct DisplayEvent {DispKind kind;State state;int reason;};
 const char* reason_name(int) {return "EEPROM_RECOVERY_REQUIRED";}
}
static bool sv04c_page_changed=false,sv04c_ee_boot_blocked=false;
static int sv04c_ee_journal=0;
const int ExchangePageBase=1000,ExchangepageAddr=80,AUTO_BED_LEVEL_ICON_VP=81;
const int SV04_CLAUDE_PAGE_SUCCESS=22,SV04_CLAUDE_PAGE_FAIL=28,SV04_CLAUDE_PAGE_PROBING=38;
#define SERIAL_ECHO_START() do{}while(0)
#define SERIAL_ECHOPGM(x) do{}while(0)
#define SERIAL_ECHO(x) do{}while(0)
#define SERIAL_EOL() do{}while(0)
'''
checks=r'''
static int count=0,failed=0;
#define CHECK(c) do {++count;if(!(c)){++failed;printf("FAIL %d: %s\n",__LINE__,#c);}}while(0)
void reset(){rtscheck.events.clear();sv04c_page_changed=false;sv04c_ee_boot_blocked=false;sv04c_ee_journal=0;}
int n(int v,int a){int k=0;for(auto p:rtscheck.events)if(p.first==v&&p.second==a)++k;return k;}
int main(){
 reset();sv04c_display(nullptr,{sv04c::D_STATE,sv04c::ST_PROBING,0});
 CHECK(n(1,AUTO_BED_LEVEL_ICON_VP)==1);CHECK(n(1038,ExchangepageAddr)==1);
 CHECK(sv04c_page_changed);
 rtscheck.events.clear();sv04c_display(nullptr,{sv04c::D_RESULT,sv04c::ST_SUCCESS,0});
 CHECK(n(0,AUTO_BED_LEVEL_ICON_VP)==1);CHECK(n(1022,ExchangepageAddr)==1);
 CHECK(n(1028,ExchangepageAddr)==0);CHECK(!sv04c_page_changed);
 reset();sv04c_display(nullptr,{sv04c::D_RESULT,sv04c::ST_FAILED,42});
 CHECK(n(0,AUTO_BED_LEVEL_ICON_VP)==1);CHECK(n(1028,ExchangepageAddr)==1);
 CHECK(n(1022,ExchangepageAddr)==0);
 reset();sv04c_display(nullptr,{sv04c::D_RESULT,sv04c::ST_CANCELLED,42});
 CHECK(n(0,AUTO_BED_LEVEL_ICON_VP)==1);CHECK(n(1028,ExchangepageAddr)==1);
 reset();sv04c_ee_boot_blocked=true;sv04c_display(nullptr,{sv04c::D_RESULT,sv04c::ST_SUCCESS,0});
 CHECK(n(0,AUTO_BED_LEVEL_ICON_VP)==1);CHECK(n(1028,ExchangepageAddr)==1);
 CHECK(n(1022,ExchangepageAddr)==0);
 reset();sv04c_ee_journal=1;sv04c_display(nullptr,{sv04c::D_RESULT,sv04c::ST_SUCCESS,0});
 CHECK(n(0,AUTO_BED_LEVEL_ICON_VP)==1);CHECK(n(1028,ExchangepageAddr)==1);
 reset();sv04c_display(nullptr,{sv04c::D_TEMP,sv04c::ST_PROBING,0});
 CHECK(rtscheck.events.empty());
 printf("DWIN_CHECKS=%d FAIL=%d\n",count,failed);return failed?1:0;
}
'''
def run(p):
 with tempfile.TemporaryDirectory() as td:
  c=Path(td)/'t.cpp';ex=Path(td)/'t';c.write_text(header+extract(p)+checks)
  x=subprocess.run(['g++','-std=c++11','-Wall','-Wextra','-Werror',str(c),'-o',str(ex)],text=True,capture_output=True)
  if x.returncode:raise RuntimeError(p.name+' COMPILE FAILED '+x.stderr)
  y=subprocess.run([str(ex)],text=True,capture_output=True)
  print(p.name,y.stdout.strip());return y.returncode
assert run(root/'auto60_adapter_314.inc')!=0
assert run(root/'auto60_adapter_315.inc')==0
print('PASS: old success lacks indicator reset, new callback passes')
