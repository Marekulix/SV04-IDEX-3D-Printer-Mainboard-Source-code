# SV04 NEXT 318 – OEM-Quellintegration (NO FLASH)

**Basis:** archivierte 309; ChatGPT-Adapter 317 mit EEPROM-/DWIN-Härtung aus 315; Claude C3/C4/C5 Bewegungsänderungen.

**Neu gegenüber 317:** C5-Bewegungsänderungen an `motion.cpp`, `tool_change.cpp`, `G29.cpp` auf dem korrekten 309-Quellstand rekonstruiert, Hashes unabhängig geprüft; passgenauer Fail-Closed-Installer für eine komplette 309-Arbeitskopie.

**Nicht mitgeliefert:** ein vollständiger OEM-Quellbaum. Die enthaltene `evidence_309_partial_fixture` ist NUR zum Nachvollziehen der drei Quelltransformationen vorhanden. Sie ist weder firmware- noch buildfähig.

**Anwendung:** Auf einem vollständigen, nachweislich aus OEM und 309 aufgebauten Marlin-Projekt: `python integrate_318.py /pfad/vollstaendiger_309 /pfad/neuer_318`. Dieser Befehl erstellt ausschließlich eine **neue Kopie**, verweigert bereits existierende Zielpfade und stoppt bei unbekannten Hashes. Er kopiert keine Firmware auf einen Drucker.

**Integration:** Der 317-Adapter und sein C5-Core werden gemeinsam verwendet. EEPROM-Kern und alle anderen Quellabhängigkeiten verbleiben auf dem bestehenden 309-Quellstand; C5-Abhängigkeiten sind als Referenz unter `assets/source_dependencies` beigelegt, werden aber NICHT blind übergeschrieben. Die C5-Z-Homing-Policy wird gezielt kopiert.

**Noch offen:** Integrationsbuild beider STM32-Profile, echte OEM-Laufzeittests, manuelle Homing-Sicherheit, T1-Kollisionsprüfung, LCD/DWIN HMI, sichere EEPROM-Transaktionsstrategie und Hardwareabnahme. **Keine Flash-Freigabe.**

**WICHTIG:** Abweichende 309-Zusammensetzungen führen zu BLOCKED, nicht zu einem geratenen Patch. C5-Kaltstart-Obergrenze 410 mm ist keine mechanische Freigabe.
