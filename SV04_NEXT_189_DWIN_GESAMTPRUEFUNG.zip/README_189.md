# SV04 NEXT 189 – eigenständige DWIN-Gesamtprüfung

Dieses neue Paket ist **189**, keine umbenannte 187. Es enthält die nötigen Prüfscripte sowie ältere, nur intern als Testfixtures genutzte DWIN-Pakete und den 189-spezifischen Prüfauftrag.

Workflow: `.github/workflows/189.yml`
Archiv im Repository-Hauptordner: `SV04_NEXT_189_DWIN_GESAMTPRUEFUNG.zip`

Drei Jobs: Host-Regression, Original-HMI-Audit, echter STM32-Cross-Build. Ein vierter Job erstellt den Bericht.

Historische Pakete werden nicht geändert; neue Uploads verwenden ausschließlich die Nummer 189.

Kein Firmware-Binary wird zum Flashen freigegeben. OEM-Versionsstände sind über Commits fixiert.
