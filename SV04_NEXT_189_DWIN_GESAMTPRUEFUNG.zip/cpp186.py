#!/usr/bin/env python3
import argparse, pathlib, subprocess, json
p=argparse.ArgumentParser();p.add_argument('--unpacked',required=True);p.add_argument('--out',required=True);a=p.parse_args()
root=pathlib.Path(a.unpacked);out=pathlib.Path(a.out);out.mkdir(parents=True,exist_ok=True)
inc=root/'version165';assert (inc/'SV04NextEvidence165.hpp').exists()
rows=[]
for n in range(171,186):
 d=root/f'version{n}'
 for source in sorted(d.glob('test*.cpp')):
  exe=out/f'{n}_{source.stem}'
  c=subprocess.run(['g++','-std=c++11','-Wall','-Wextra','-Werror','-I',str(d),'-I',str(inc),str(source),'-o',str(exe)],capture_output=True,text=True,timeout=60)
  if c.returncode: r=None;rc=c.returncode;log=c.stdout+c.stderr
  else:
   run=subprocess.run([str(exe)],capture_output=True,text=True,timeout=60)
   rc=run.returncode;log=run.stdout+run.stderr
  (out/f'{n}_{source.stem}.log').write_text(log)
  rows.append({'version':n,'test':source.name,'success':rc==0,'returncode':rc})
(out/'cpp_results.json').write_text(json.dumps(rows,indent=2)+'\n')
for row in rows:print(row)
assert rows and all(x['success'] for x in rows),'C++ suite FAILURE'
