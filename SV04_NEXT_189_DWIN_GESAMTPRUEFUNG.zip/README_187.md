# SV04 NEXT 187 - corrective audit only

The 186 STM32 cross-build succeeded, but host and HMI jobs failed.

Fix 1: host186.py invoked absolute/repeated relative test path with cwd=target; use primary.name.
Fix 2: historical 185 signatures for VPs 0x1100/02/04/06 used y=472 (0x01D8), whereas pinned 14ShowFile.bin uses y=440 (0x01B8). The old 185 archive remains unchanged. This release supplies a corrected evidence record and audits that record. No scale/signedness claim.

Never install or flash the builds from these CI jobs. The firmware may contain only an unreachable, disabled display adapter.
