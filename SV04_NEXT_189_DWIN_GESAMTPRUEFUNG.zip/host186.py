#!/usr/bin/env python3
import argparse, hashlib, json, pathlib, subprocess, zipfile, sys
p=argparse.ArgumentParser();p.add_argument('--base',required=True);p.add_argument('--out',required=True);a=p.parse_args()
base=pathlib.Path(a.base);out=pathlib.Path(a.out);out.mkdir(parents=True,exist_ok=True)
results=[]
for n in range(171,186):
 paths=list((base/'pkgs').glob(f'SV04_NEXT_{n}_*.zip'))
 if len(paths)!=1: raise RuntimeError(f'missing unique version {n}')
 target=out/f'version{n}';target.mkdir(exist_ok=True)
 with zipfile.ZipFile(paths[0]) as z:
  assert z.testzip() is None
  z.extractall(target)
 tests=sorted(target.glob('test*.py'))
 # Run the last listed Python suite per release (earlier tests are run by their original release).
 primary=target/f'test{n}.py'
 if primary.exists():
  proc=subprocess.run([sys.executable,primary.name],cwd=target,capture_output=True,text=True,timeout=100)
  (out/f'test{n}.log').write_text(proc.stdout+proc.stderr)
  results.append({'release':n,'test':primary.name,'returncode':proc.returncode,'log':f'test{n}.log'})
 else:results.append({'release':n,'test':None,'returncode':None,'comment':'No matching Python suite; source-specific C++/other tests executed separately'})
 json.dumps(results)
(out/'host_result.json').write_text(json.dumps(results,indent=2)+'\n')
for x in results:print(x['release'],x['test'],x['returncode'])
failed=[x for x in results if x['returncode'] not in (0,None)]
if failed:raise SystemExit(f'HOST SUITE FAIL: {[x["release"] for x in failed]}')
