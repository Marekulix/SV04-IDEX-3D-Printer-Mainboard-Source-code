#!/usr/bin/env python3
"""Full-source DWIN 186 evidence audit. Does not deploy or flash anything."""
import argparse, hashlib, json, pathlib, struct, sys, zipfile

def sha(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open('rb') as f:
  for c in iter(lambda:f.read(1<<20),b''):h.update(c)
 return h.hexdigest()

def audit(hmi, src_h, src_cpp, expected_records):
 raw=pathlib.Path(hmi).read_bytes(); header=pathlib.Path(src_h).read_text(); cpp=pathlib.Path(src_cpp).read_text()
 records=json.loads(pathlib.Path(expected_records).read_text())['records']
 assert len(records)==16
 assert all(rec.get('source_correction') == '186_HMI_Y_472_TO_440' for rec in records if rec['vp'] in ('0x1106','0x1104','0x1102','0x1100'))
 seen=set(); rows=[]
 for rec in records:
  off=rec['binary_offset']; prefix=bytes.fromhex(rec['record_prefix_hex']);assert len(prefix)==20
  assert raw[off-6:off+14]==prefix,(rec['vp'],off)
  vp=int(rec['vp'],16);assert vp not in seen;seen.add(vp)
  assert int.from_bytes(raw[off:off+2],'big')==vp
  rows.append({'vp':rec['vp'],'offset':off,'x':rec['x'],'y':rec['y'],'same_format_bytes':raw[off+6:off+14].hex()})
 assert seen==set(range(0x1100,0x1120,2))
 assert 'ChangePageKey' in header and '0X2202' in header and '0x110E' in header
 assert 'case ChangePageKey:' in cpp and 'case BedLevelFunKey:' in cpp
 assert 'snddat.command == 0x82' in cpp and 'LCD_SERIAL.write(databuf[i]);' in cpp
 assert 'unsigned char databuf[SizeofDatabuf]' in header
 result={'status':'PASS_STRUCTURAL_ONLY','show_file_sha256':sha(hmi),'original_marlin_h_sha256':sha(src_h),'original_marlin_cpp_sha256':sha(src_cpp),'records':rows,'record_count':16,'unverified':['display signedness','decimal scaling','page visibility','physical touch','physical IDEX clearance'],'deploy_approved':False}
 return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--hmi',required=True);p.add_argument('--header',required=True);p.add_argument('--cpp',required=True);p.add_argument('--records',required=True);p.add_argument('--out',required=True);a=p.parse_args()
 data=audit(a.hmi,a.header,a.cpp,a.records);pathlib.Path(a.out).write_text(json.dumps(data,indent=2)+'\n');print('HMI OEM BINARY 16/16 PASS, semantics UNVERIFIED, NO FLASH')
