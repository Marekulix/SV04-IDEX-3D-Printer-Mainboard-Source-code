# SV04 NEXT 186 – EIN GESAMTER GITHUB-RUN: DWIN OEM + 171–185
**ONLY FOR CI / NOT INSTALLABLE / DO NOT FLASH**

This audit is intentionally fail-closed. It never uploads firmware binaries, touches a printer, flashes HMI files, enables Auto60 or changes original source packages.

GitHub workflow `186.yml` automatically runs with exactly `SV04_NEXT_186_DWIN_GESAMTPRUEFUNG.zip`. It executes three jobs and one unconditional summary job:
1. Host regressions of versioned archives 171–185, with inherited C++ dependency 165.
2. Pinned original DWIN `14ShowFile.bin` 16-object replay against 185-byte-level signatures; pinned OEM Marlin receive/send contract.
3. Genuine STM32 PlatformIO cross-build of pinned OEM source, with version 181's *dormant/disabled* mesh interface patch in `LCD_RTS.cpp`.
4. Summary of all job outcomes and output artifacts, including non-passing jobs.

A successful host unit test does not prove DWIN physical display behavior. The data-format semantics for numeric scaling and signedness, HMI page visibility, the 0x110E directional collision, Auto60 runtime path, EEPROM rollback, IDEX collision safety and machine hardware have **not** been fully verified. The firmware is **NOT approved** for flashing.

Repo workflow assets (the 171–185 legacy archives) are bundled inside the new ZIP; no overwriting earlier GitHub files and no extra user uploads besides the two new 186 files.

Pinned Marlin OEM commit `1867fcba75354a5c65e0631d6972dd19f1bd6cbe`.
Pinned DGUS original commit `5a3fae8c1ccdc04fb3372c077a61394e8a66ece4`.
