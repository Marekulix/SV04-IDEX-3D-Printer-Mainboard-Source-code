import pathlib,tempfile,unittest,sys,subprocess
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from apply62 import patch,G29,RTS,DEST,BASE
H=ROOT/'src/SV04NextGuard62.h'
class Integration62(unittest.TestCase):
 def mk(self,d):
  p=pathlib.Path(d);(p/G29).parent.mkdir(parents=True);(p/RTS).parent.mkdir(parents=True)
  (p/'platformio.ini').write_text('[platformio]\n')
  (p/G29).write_text('#include "../../../inc/MarlinConfig.h"\nG29_TYPE GcodeSuite::G29() {\n    return false;\n}\n')
  (p/RTS).write_text('#include "LCD_RTS.h"\nvoid RTSUpdate() {}\n')
  return p
 def test_overlay(self):
  with tempfile.TemporaryDirectory() as d:
   r=self.mk(d); report=patch(r,H,False)
   self.assertIn('G29 U Q read-only diagnostic',report['active_features'])
   self.assertIn('READONLY AUTO60=0',(r/G29).read_text())
   self.assertIn('SV04NextGuard62',(r/RTS).read_text())
   self.assertTrue((r/DEST).exists())
 def test_double_apply_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   r=self.mk(d);patch(r,H,False)
   with self.assertRaises(ValueError):patch(r,H,False)
 def test_wrong_source_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   r=self.mk(d);(r/G29).write_text('wrong')
   with self.assertRaises(ValueError):patch(r,H,False)
 def test_missing_lcd_rejected_without_partial_patch(self):
  with tempfile.TemporaryDirectory() as d:
   r=self.mk(d);(r/RTS).write_text('wrong');before=(r/G29).read_text()
   with self.assertRaises(ValueError):patch(r,H,False)
   self.assertEqual(before,(r/G29).read_text())
 def test_commit_lock_rejects_unpinned(self):
  with tempfile.TemporaryDirectory() as d:
   r=self.mk(d);subprocess.run(['git','init',str(r)],capture_output=True,check=True)
   subprocess.run(['git','-C',str(r),'-c','user.name=Test','-c','user.email=t@example.com','commit','--allow-empty','-m','seed'],capture_output=True,check=True)
   with self.assertRaises(ValueError):patch(r,H,True)
 def test_g29_not_triggered_by_single_flag(self):
  src=(ROOT/'tools/apply62.py').read_text()
  self.assertIn("parser.seen_test('U') && parser.seen_test('Q')",src)
 def test_guard_forbids_all_releases(self):
  code=H.read_text()
  for k in ['SV04_NEXT_AUTO60_RELEASE','SV04_NEXT_DWIN_TOUCH_RELEASE','SV04_NEXT_T1_MOTION_RELEASE','SV04_NEXT_EEPROM_RELEASE','SV04_NEXT_FLASH_RELEASE']: self.assertIn(k,code)
 def test_cpp_compile(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d);(p/'test.cpp').write_text('#include "'+str(H)+'"\nint main(){ bool x[16]={};float z[16]={}; return sv04next62::mesh_valid(x,z)?1:0;}\n')
   subprocess.run(['g++','-std=c++11','-Wall','-Wextra','-Werror','-fsyntax-only',str(p/'test.cpp')],check=True)
 def test_cpp_release_macros_blocked(self):
  for name in ['SV04_NEXT_AUTO60_RELEASE','SV04_NEXT_DWIN_TOUCH_RELEASE','SV04_NEXT_T1_MOTION_RELEASE','SV04_NEXT_EEPROM_RELEASE','SV04_NEXT_FLASH_RELEASE']:
   with self.subTest(name=name):
    res=subprocess.run(['g++','-x','c++','-std=c++11','-D'+name,'-fsyntax-only','-'],input='#include "'+str(H)+'"\n',text=True,capture_output=True)
    self.assertNotEqual(res.returncode,0)
 def test_diag_does_not_write_dwin_or_eeprom(self):
  s=(ROOT/'tools/apply62.py').read_text()
  for term in ['RTS_SndData','M500','M190','process_subcommands_now_P']: self.assertNotIn(term,s)
 def test_mesh_all_points(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d)/'mesh.cpp';p.write_text('#include "'+str(H)+'"\nint main(){ bool a[16];float b[16];for(int i=0;i<16;i++){a[i]=true;b[i]=0.1f;}if(!sv04next62::mesh_valid(a,b))return 1; a[15]=false;return sv04next62::mesh_valid(a,b)?2:0;}')
   subprocess.run(['g++','-std=c++11',str(p),'-o',str(p.with_suffix(''))],check=True)
   subprocess.run([str(p.with_suffix(''))],check=True)
if __name__=='__main__':unittest.main()
