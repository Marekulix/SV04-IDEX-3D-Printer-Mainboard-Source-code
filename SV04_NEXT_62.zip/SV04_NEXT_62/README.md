# SV04 NEXT 62
Upload `SV04_NEXT_62.zip` into repository root, `62.yml` under `.github/workflows/`; run Action 62. Download evidence artifacts `sv04next62-host-evidence` and `sv04next62-stm32-evidence`.

This is a **read-only native diagnostic overlay test**, not a firmware release. It will not enable Auto60, EEPROM writes, T1 movement or DWIN touch controls. Never flash the generated images.
