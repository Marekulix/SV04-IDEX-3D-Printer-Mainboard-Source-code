# SV04 NEXT 62: scope and safety

- Last evidenced overall catalog progress: **39.50%**. This host integration is NOT a flashable firmware release.
- GitHub 61 compiled repository-existing Marlin, `STM32F103RET6_creality`, but did not establish SV04 NEXT features.
- Workflow 62 builds pinned Sovol OEM commit `1867fcba75354a5c65e0631d6972dd19f1bd6cbe` twice, first baseline then after injecting a genuine native Marlin G29 diagnostic and passive LCD header. It fails unless ELF contains the new marker and binaries differ.
- No new DWIN touchscreen gesture is enabled. No heater, stepper, T1 parking, auto mesh 60C, or EEPROM command is wired to hardware. Firmware release macros are actively forbidden.
- T1 needs validated mechanical limits and real collision test. Auto60 needs confirmed 4x4 BLTouch probing / 60C stabilisation / failure rollback / verified EEPROM state. The Z-offset must never be overwritten.
- The known historical host-code for these functions is not being misrepresented as finished native firmware.
- NEXT NUMBER: 63, preserving ZIP/YAML paired numbering. Do not flash or send G29 U Q on original printer firmware.
