Punkt 1 IDEX + BLTouch
SV04_PUNKT1_270_QUELLPAKET.zip in das Hauptverzeichnis des GitHub-Repositories laden.
SV04_PUNKT1_GITHUB_RUN_270_NO_FLASH.yml unter .github/workflows/ laden.
Danach Actions -> SV04 P1 IDEX BLTouch - BUILD ONLY -> Run workflow.
Die ZIP nicht entpacken vor dem GitHub-Upload.
Run erstellt nur Diagnose-Logs; keine Flash-Firmware.
