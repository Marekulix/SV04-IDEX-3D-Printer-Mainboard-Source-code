# SV04 NEXT – Claude C12: echte homeaxis-Tests und Lüfter im Stopp

Stand 14.11.2026 · FLASH_ALLOWED=NO · HARDWARE_TESTED=NO · 309/318/C9/C10/C11 unverändert (C12 ist ein weiterer Overlay-Patch, eine Datei)
Nachweisstufen: **C12 ist programmiert und host-getestet. STM32-gebaut: noch nicht** (erst der GitHub-Lauf mit `claude_c12_stm32_no_flash.yml`). Hardwarebestätigt: nein.

## 1. Kurzfassung
| AP | Ergebnis | Stufe |
|---|---|---|
| AP2 echte `homeaxis()` | **Jetzt ausgeführt**, mit den echten, präprozessierten Funktionen `homeaxis()`, `do_homing_move()`, `set_axis_is_at_home()`, `Endstops::validate_homing_move()`, der Z-Home-Policy (C3/C5) und den Achs-Inlines. 14 Tests, 11 520 Szenarien gegen ein unabhängiges Spezifikationsmodell, 0 Abweichungen, 14 von 14 Mutanten an der echten Funktion getötet | host-getestet an echtem Code, Stubs nur für Mitspieler |
| AP3 Lüfter im Stopp | **Echte Softwareänderung, eine Datei** (`sv04_claude_stopgate.h`): im Stopp ist `M106` nur noch in der sicheren Richtung (EIN) erlaubt; `M107`, `S0`, `T`, `I`, `A` bleiben verweigert. 14 Tests, Differenztest gegen das C10-Gate, 11 Mutanten getötet, 2 äquivalent bewiesen, 1 durch die volle Domäne getötet | programmiert + host-getestet |
| Regression | C10 28/28, C11 23/23 unverändert | host-getestet |

## 2. Korrekturen an meinen C11-Aussagen (bitte beachten)
* **C11-Abschlussbericht, Abschnitt 3:** „es gibt in dieser Konfiguration keinen `kill()`-Pfad in `homeaxis()`“ war **unvollständig**. `VALIDATE_HOMING_ENDSTOPS` ist aktiv (`endstops.cpp:386–396`): `do_homing_move()` ruft in Heimrichtung `endstops.validate_homing_move()`; löst kein Endstop aus, wird `kill("Homing Failed")` aufgerufen (und die Display-Seite 55 gesetzt). Ein fehlendes Endstop-/Sondensignal endet also in `kill()`, nicht in einer unbemerkten Fahrt bis zum Ende.
* **C11-Paket, Dokument `08_AP2_HOMEAXIS_TESTGRENZE.md`, Szenario 5:** „Nur `DETECT_BROKEN_ENDSTOP` führt zu `kill()`“ ist damit falsch. Das C11-ZIP bleibt unverändert (Hash steht im gelaufenen Workflow); maßgeblich ist dieser Bericht.
* Z-Verfahrstrecke: `Z_MAX_POS 400`; die „410 mm“ aus früheren Berichten sind 400 mm + 10 mm Sondenfreiheit (`Z_CLEARANCE_DEPLOY_PROBE`). Bei unbekanntem Z wird auf genau 410 mm begrenzt (Test H1203).

## 3. AP2 im Detail
Die Funktionen stammen **unverändert** aus dem Präprozessor-Auszug des C11-Laufs (`SV04_C11_PRAEPROZESSOR`, Hashes in `03_TESTS/eingang/EINGANG_SHA256.txt`); `extract_real.py` zieht sie reproduzierbar aus den `.i`-Dateien. Es ist **keine** handgeschriebene Nachbildung.
**Stubs (Testgrenze):** Planner/Stepper, `probe.deploy/stow`, `bltouch.deploy/stow`, `kill()`, Display, `trigger_state()`. Ihr Verhalten ist pro Szenario vorgegeben. **Nicht belegt:** das reale Verhalten von BLTouch, Endstop-Hardware, Stepper und von `kill()` (im Test: kehrt nicht zurück; so verhält sich Marlins `kill()`, am echten `kill()` hier nicht geprüft).

| Nr | Szenario | Ergebnis am echten Code (host) |
|---|---|---|
| 1 | Kaltstart, Z unbekannt | erste Fahrt auf 410 mm begrenzt (auch bei „homed aber nicht vertraut“ und umgekehrt) |
| 2 | BLTouch-Alarm (Deploy meldet Fehler) | keine Bewegung, keine Referenz gesetzt |
| 3 | BLTouch fährt nicht aus (1. und 2. Deploy) | 1. Deploy: keine Bewegung; 2. Deploy (nach der schnellen Fahrt): Abbruch nach 2 Bewegungen, keine Referenz |
| 4 | BLTouch fährt nicht ein (`probe.stow()` am Ende) | **Beobachtung:** Z ist dann bereits als referenziert **und vertraut** markiert (`set_axis_is_at_home()` steht vor dem letzten `probe.stow()`); `sv04_p1_z_completed` wird **nicht** gesetzt. Im echten BLTouch folgt `stop()`; C10 blockiert dann, C9 setzt bei `M999` zurück. Kein belegter Fehler |
| 5 | Endstop-Signal fehlt | `kill("Homing Failed")` nach der ersten (oder der Re-Bump-)Fahrt, keine Referenz; gilt auch für X |
| 6 | Z-Homing bei unbekannter Referenz | wie 1; bei bekannter Referenz begrenzt auf Z + Sondenoffset + 10 mm (z. B. Z=100 → 110 mm) |
| 7 | Abbruch beim Referenzieren | Abbruch bei jeder der 3 Fahrten (X und Z): nie eine Referenz oder ein Abschluss-Flag gesetzt |
| 8 | G28 nach M999 | Zustand „unreferenziert“ = Kaltstart (Szenario 1/6); M999 selbst: C9/C11-Tests |
| 9 | T0/T1 | T0 fährt nach links (−546 mm), T1 nach rechts; `sv04_p1_t0/t1_x_completed` jeweils nur für den aktiven Extruder |
| 10 | Übergabe an Auto60 | Abschluss-Flags nur nach vollständiger, vertrauter Referenzierung; bei jedem Fehlerpfad (Deploy, Endstop, Abbruch, Stow) bleibt `p1z` 0 |

Reihenfolge Z (Test H1212): `PROBE_DEPLOY → BL_DEPLOY → Fahrt → HIT → BL_STOW → Freifahrt → BL_DEPLOY → Fahrt → HIT → BL_STOW → PROBE_STOW`.

## 4. AP3 im Detail
Grundlage (echter Code aus dem Export): `M106`/`M107` ändern nur `thermalManager.set_fan_speed(fan, speed)` (Index `P` oder aktiver Extruder, `fan >= FAN_COUNT` wird ignoriert, Obergrenze 255); keine Heizung, keine Bewegung. `FAN_COUNT 2`, `FAN_PIN PB14`, `FAN1_PIN PB12`, `E0..E7_AUTO_FAN_PIN -1`.
Neu im Stopp erlaubt: `M106` mit optional `P0|P1` und optional `S1..S255` (nur Ziffern, ohne führende 0, jeder Buchstabe höchstens einmal). Ohne `S` setzt Marlin 255 (EIN). **Weiter verweigert:** `M107`, `M106 S0`, `T`, `I` (Preset kann 0 sein), `A`, alle anderen Parameter. Schalter `SV04_CLAUDE_STOPP_FAN_ON` (Standard 1, 0 = C10-Verhalten).
Begründung: Einschalten ist nie ein Sicherheitsrisiko (nur Kühlung), Ausschalten nur, falls ein Ausgang die Heatbreak-Kühlung eines heißen Hotends versorgt. **Nicht belegt:** was physisch an PB14/PB12 hängt. Deshalb bleibt „aus“ gesperrt. Beim Mutantentest hat die volle Domäne (65 882 Werttexte) eine Lücke im Standardkorpus gefunden (Mutante „Minus erlaubt“, z. B. `S5-`); sie wird jetzt getötet.
Entscheidung **D4** für Marek: Lüfter-EIN per G-Code im Stopp erlaubt (so gebaut). Ohne Ja: `-DSV04_CLAUDE_STOPP_FAN_ON=0`.

## 5. Grenzen und offene Punkte
Siehe `06_OFFENE_PROBLEME_C12.md`. Kurz: Display-Pfad (ChatGPT), reale BLTouch-/Endstop-/`kill()`-Verhalten nur am Gerät, T0/T1-Kollisionsabstände und 410/400-mm-Freigabe weiter gesperrt.

## 6. Fortschrittsfelder
Unverändert: IDEX+BLTouch 88 %, G28 81 %, G29+Abbruch 75 %, M420 S1 97 %, M500 EEPROM 70 %, EEPROM-Rücklesung 60 %, Gesamt 78,5 %. Begründung: Die `homeaxis()`-Tests erhöhen die Nachweisstufe (host-getestet an echtem Code), nicht den Gerätenachweis; der Lüfter-Patch liegt außerhalb der sechs Felder. Ob G28 (81 %) durch den echten Test steigt, entscheiden Marek und ChatGPT bei der Integration.
