# Offene Probleme nach C12
| Nr | Problem | Einstufung | Weg |
|---|---|---|---|
| P1 | Display (318 `LCD_RTS.cpp`) prüft den Stopp nirgends: Bewegung, SD-Fortsetzen, Heizen, Lüfter direkt | belegt (Quelltext) | ChatGPT nach `DWIN_SCHNITTSTELLE_C11.md` (im C11-Paket) |
| P2 | Realverhalten BLTouch, Endstop-Hardware, Stepper, `kill()` | nur am Gerät | Hardware gesperrt |
| P3 | Was hängt an `FAN_PIN PB14` / `FAN1_PIN PB12` (Heatbreak oder Bauteil)? | nur am Aufbau klärbar | Marek: Verdrahtung/Beschriftung; danach kann „M107/S0 im Stopp“ neu entschieden werden |
| P4 | Beobachtung H1207: Z ist bei fehlgeschlagenem letztem `probe.stow()` schon „vertraut“ | Beobachtung, kein belegter Fehler | optional C13: Reihenfolge prüfen, nur mit Entscheidung |
| P5 | Der Test nutzt die `.i`-Auszüge vom 14.11.2026; ändert sich der Baum, muss `extract_real.py` neu laufen | bekannt | Workflow liefert die Auszüge bei Bedarf wieder |
| P6 | T0/T1-Kollisionsabstände, 400/410 mm Z, EEPROM am Gerät, DWIN-Abnahme | weiter gesperrt | – |
