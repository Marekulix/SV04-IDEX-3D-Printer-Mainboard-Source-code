# GitHub-Lauf C12 (NO FLASH)
1. Ins Repository: `SV04_NEXT_CLAUDE_C12_HOMEAXIS_FAN_STOP.zip`, `claude_c12_stm32_no_flash.yml` (unter `.github/workflows/`) und die bisherigen Eingaben (318-Übergabe, C9-ZIP, C10-ZIP, **C11-ZIP `SV04_NEXT_CLAUDE_C11_SD_HOMEAXIS_FAN_SAFETY.zip`**). Manuell starten.
2. Jobs: `baseline_c11` (318 → C9 → C10 → C11, baut `oem_c11`), `c12_changes` (zusätzlich C12 → `oem_c12`, C11-/C12-Tests, Regression C10, beide Profile), `evaluate_builds` (grün nur bei 4/4 PASS).
3. Artefakte (bitte alle drei zurückgeben): `SV04_C12_BASELINE_C11_STM32_LOGS_NO_FLASH`, `SV04_C12_CHANGED_STM32_LOGS_NO_FLASH`, `SV04_C12_EVALUATION`.
4. „STM32-gebaut“ erst bei Exit 0 + `[SUCCESS]` + RAM/Flash je Profil. ZIP-Hashes sind im Workflow fest eingetragen; nicht neu packen.
