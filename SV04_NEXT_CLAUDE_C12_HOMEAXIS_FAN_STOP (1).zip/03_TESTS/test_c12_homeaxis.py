"""SV04 NEXT C12 AP2 - Tests mit den ECHTEN, praeprozessierten Funktionen homeaxis(), do_homing_move(), set_axis_is_at_home(),
Endstops::validate_homing_move() und der Z-Home-Policy (aus dem Praeprozessor-Auszug des GitHub-Laufs C11, eingang/real_extract.inc).
Stubs NUR fuer Mitspieler (Planner, probe.*, bltouch.*, kill, Display, trigger_state), per Szenario skriptiert. Nicht ausgefuehrt/nicht belegt: das reale
Verhalten von BLTouch, Stepper, Endstop-Hardware und von kill() (hier: kehrt nicht zurueck = Ausnahme). KEIN STM32-Build, KEINE Hardware.
 H12xx Szenarien (10 aus dem Auftrag) + Gitter gegen unabhaengiges Spezifikationsmodell, X12xx Mutanten der echten Funktionen."""
import itertools, shutil, subprocess, sys, tempfile, unittest
from pathlib import Path
HERE = Path(__file__).resolve().parent; CPP = HERE / 'cpp'; IN = HERE / 'eingang'
GXX = ['g++', '-std=gnu++11', '-O1', '-w']

def sh(cmd, **kw): return subprocess.run(cmd, capture_output=True, text=True, **kw)

def build(extract_text=None):
    d = Path(tempfile.mkdtemp()); shutil.copy(CPP / 'homeaxis_driver.cpp', d)
    (d / 'real_extract.inc').write_text(extract_text if extract_text is not None else (IN / 'real_extract.inc').read_text())
    r = sh(GXX + ['-I', str(d), str(d / 'homeaxis_driver.cpp'), '-o', str(d / 'h')]); assert r.returncode == 0, r.stderr[-1500:]
    return d / 'h'

def run(exe, rows):
    inp = '\n'.join(' '.join(str(x) for x in r) for r in rows) + '\n'
    out = sh([str(exe)], input=inp).stdout.splitlines(); assert len(out) == len(rows), (len(out), len(rows)); return [parse(l) for l in out]

def parse(line):
    kv = dict(x.split('=', 1) for x in line.split(' ', 8)[:8]); ev = line.split('ev=', 1)[1]
    return dict(end=kv['end'], homed=int(kv['homed']), trusted=int(kv['trusted']), p1z=int(kv['p1z']), p1t0=int(kv['p1t0']), p1t1=int(kv['p1t1']), moves=int(kv['moves']), ev=[e for e in ev.split(',') if e])

# Zeile: axis ext homed trusted z pdf psf bdf trig abort
def row(axis, ext=0, homed=0, trusted=0, z=0, pdf=0, psf=0, bdf=0, trig='111', ab=0): return (axis, ext, homed, trusted, z, pdf, psf, bdf, trig, ab)

def names(ev): return [e.split(':')[0] for e in ev]
def dist(e, axis): _, n, x, y, z, fr = e.split(':'); return float((x, y, z)[axis]), float(fr)

# ---------------- unabhaengiges Spezifikationsmodell (aus den Sicherheitsanforderungen, nicht aus dem Code abgeleitet) ----------------
def spec(axis, ext, homed, trusted, z, pdf, psf, bdf, trig, ab):
    ev, moves, ti = [], 0, [0]
    st = dict(homed=homed, trusted=trusted, p1z=0, p1t0=0, p1t1=0)
    class End(Exception): pass
    def move(is_home_dir):
        nonlocal moves
        moves += 1; ev.append('MOVE')
        if ab and moves == ab: raise End('ABORT')
        if is_home_dir:
            hit = (trig[ti[0]] == '1') if ti[0] < len(trig) else True; ti[0] += 1
            if hit: ev.append('HIT')
            else: ev.append('DISPLAY_PAGE55'); ev.append('KILL'); raise End('KILL')
    end = 'OK'; bl = 0
    try:
        if axis == 2:
            ev.append('PROBE_DEPLOY')
            if pdf: raise End('OK')
            bl += 1; ev.append('BL_DEPLOY')
            if bdf == 1: raise End('OK')
        move(True)
        if axis == 2: ev.append('BL_STOW')
        move(False)                                   # Freifahrt (kein Heimrichtungs-Check)
        if axis == 2:
            bl += 1; ev.append('BL_DEPLOY')
            if bdf == 2: raise End('OK')
        move(True)
        if axis == 2: ev.append('BL_STOW')
        st['homed'] |= 1 << axis; st['trusted'] |= 1 << axis
        if axis == 2:
            ev.append('PROBE_STOW')
            if psf: raise End('OK')
        if axis == 0 and ext == 1: st['p1t1'] = (st['trusted'] >> 0) & 1
        if axis == 0 and ext == 0: st['p1t0'] = (st['trusted'] >> 0) & 1
        if axis == 2: st['p1z'] = (st['trusted'] >> 2) & 1
    except End as e: end = str(e)
    return dict(end=end, moves=moves, ev=ev, **st)

def spec_first_move(axis, ext, homed, trusted, z):
    """erwartete Strecke der ersten (schnellen) Fahrt, Betrag, nach den dokumentierten Regeln"""
    full = {0: 1.5 * 364, 1: 1.5 * 302, 2: 1.5 * 400}[axis]
    if axis != 2: return full
    known = bool(homed & 4) and bool(trusted & 4)
    cap = (max(z + 0 + 10, 10) if known else 400 + 10)
    return min(full, cap)

GRID = [row(a, e, h, t, z, p, s, b, tr, ab) for a in (0, 2) for e in (0, 1) for (h, t) in ((0, 0), (7, 7), (4, 0), (0, 4)) for z in (0, 50, 400) for p in (0, 1) for s in (0, 1) for b in (0, 1, 2) for tr in ('111', '011', '101', '110', '001') for ab in (0, 1, 2, 3)]

class Real(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.exe = build(); cls.res = run(cls.exe, GRID)

    def test_H1201_full_grid_matches_the_independent_specification(self):
        bad = []
        for r, got in zip(GRID, self.res):
            exp = spec(*r); g = dict(got); g['ev'] = names(got['ev']); g['ev'] = [e if e != 'MOVE' else 'MOVE' for e in g['ev']]
            e2 = {k: exp[k] for k in ('end', 'homed', 'trusted', 'p1z', 'p1t0', 'p1t1', 'moves', 'ev')}
            g2 = {k: g[k] for k in e2}
            if g2 != e2: bad.append((r, g2, e2))
        self.assertEqual(bad[:2], [], f'{len(bad)} von {len(GRID)}')

    def test_H1202_move_lengths_follow_the_documented_rules(self):
        bad = []
        for r, got in zip(GRID, self.res):
            m1 = next((e for e in got['ev'] if e.startswith('MOVE:1:')), None)
            if m1 is None: continue
            d, _ = dist(m1, r[0]); exp = spec_first_move(r[0], r[1], r[2], r[3], r[4])
            if abs(abs(d) - exp) > 1e-3: bad.append((r, d, exp))
        self.assertEqual(bad[:3], [], len(bad))

    def test_H1203_scenario_1_and_6_cold_start_unknown_z_is_capped_to_max_length_plus_clearance_410(self):
        g = run(self.exe, [row(2)])[0]; d, fr = dist(g['ev'][2], 2); self.assertEqual(abs(d), 410.0); self.assertEqual(g['end'], 'OK')
        g = run(self.exe, [row(2, homed=4, trusted=0)])[0]; self.assertEqual(abs(dist(g['ev'][2], 2)[0]), 410.0, 'homed aber nicht vertraut = unbekannt')
        g = run(self.exe, [row(2, homed=0, trusted=4)])[0]; self.assertEqual(abs(dist(g['ev'][2], 2)[0]), 410.0, 'vertraut aber nicht homed = unbekannt')

    def test_H1204_scenario_8_g28_after_m999_state_unhomed_is_a_cold_start_known_z_is_limited_to_z_plus_clearance(self):
        g = run(self.exe, [row(2, homed=0, trusted=0, z=100)])[0]; self.assertEqual(abs(dist(g['ev'][2], 2)[0]), 410.0)
        g = run(self.exe, [row(2, homed=4, trusted=4, z=100)])[0]; self.assertEqual(abs(dist(g['ev'][2], 2)[0]), 110.0)

    def test_H1205_scenario_2_3_bltouch_alarm_or_no_deploy_means_no_motion_and_no_reference(self):
        for kw in (dict(pdf=1), dict(bdf=1)):
            g = run(self.exe, [row(2, homed=3, trusted=3, **kw)])[0]; self.assertEqual((g['moves'], g['homed'], g['trusted'], g['p1z']), (0, 3, 3, 0), kw)
        g = run(self.exe, [row(2, homed=0, trusted=0, bdf=1)])[0]; self.assertEqual((g['homed'], g['trusted']), (0, 0))

    def test_H1206_scenario_3b_second_deploy_failure_after_the_fast_move_leaves_the_reference_untouched(self):
        g = run(self.exe, [row(2, bdf=2)])[0]; self.assertEqual((g['moves'], g['homed'], g['trusted'], g['p1z']), (2, 0, 0, 0))

    def test_H1207_scenario_4_stow_failure_characterisation_axis_is_marked_but_p1_completion_flag_is_not(self):
        # BEOBACHTUNG am echten Code (kein Sollwert): set_axis_is_at_home() steht VOR dem letzten probe.stow(); bei Fehlschlag (stop() im echten BLTouch)
        # bleibt Z als referenziert+vertraut markiert, sv04_p1_z_completed wird nicht gesetzt. Im Stopp blockiert C10, M999 setzt per C9 zurueck.
        g = run(self.exe, [row(2, psf=1)])[0]; self.assertEqual((g['homed'], g['trusted'], g['p1z']), (4, 4, 0)); self.assertEqual(g['ev'][-1], 'PROBE_STOW')

    def test_H1208_scenario_5_missing_endstop_signal_kills_and_leaves_the_reference_untouched(self):
        for trig, at in (('011', 1), ('101', 3), ('110', 3)):
            pass
        g = run(self.exe, [row(2, trig='011')])[0]; self.assertEqual((g['end'], g['moves'], g['homed']), ('KILL', 1, 0)); self.assertIn('KILL:Homing Failed', g['ev'])
        g = run(self.exe, [row(2, trig='101')])[0]; self.assertEqual((g['end'], g['moves'], g['homed']), ('KILL', 3, 0))
        g = run(self.exe, [row(0, trig='011')])[0]; self.assertEqual((g['end'], g['moves'], g['homed']), ('KILL', 1, 0), 'auch X')

    def test_H1209_scenario_7_abort_at_any_homing_move_never_sets_a_reference(self):
        for axis in (0, 2):
            for ab in (1, 2, 3):
                g = run(self.exe, [row(axis, ab=ab)])[0]; self.assertEqual((g['end'], g['homed'], g['trusted'], g['p1z'], g['p1t0'], g['p1t1']), ('ABORT', 0, 0, 0, 0, 0), (axis, ab))

    def test_H1210_scenario_9_t0_t1_direction_and_completion_flags(self):
        g0 = run(self.exe, [row(0, ext=0)])[0]; g1 = run(self.exe, [row(0, ext=1)])[0]
        self.assertEqual((g0['p1t0'], g0['p1t1']), (1, 0)); self.assertEqual((g1['p1t0'], g1['p1t1']), (0, 1))
        self.assertLess(dist(g0['ev'][0], 0)[0], 0); self.assertGreater(dist(g1['ev'][0], 0)[0], 0)   # T0 faehrt nach links, T1 nach rechts
        self.assertEqual(abs(dist(g0['ev'][0], 0)[0]), 546.0)

    def test_H1211_scenario_10_reference_handover_flags_only_after_a_complete_trusted_homing(self):
        ok = run(self.exe, [row(2)])[0]; self.assertEqual((ok['p1z'], ok['trusted']), (1, 4))
        for kw in (dict(pdf=1), dict(bdf=1), dict(bdf=2), dict(trig='011'), dict(trig='101'), dict(ab=2), dict(psf=1)):
            g = run(self.exe, [row(2, **kw)])[0]; self.assertEqual(g['p1z'], 0, kw)

    def test_H1212_order_probe_deploy_then_bltouch_deploy_then_first_move_and_stow_after_each_approach(self):
        n = names(run(self.exe, [row(2)])[0]['ev'])
        self.assertEqual(n, ['PROBE_DEPLOY', 'BL_DEPLOY', 'MOVE', 'HIT', 'BL_STOW', 'MOVE', 'BL_DEPLOY', 'MOVE', 'HIT', 'BL_STOW', 'PROBE_STOW'])
        self.assertEqual(names(run(self.exe, [row(0)])[0]['ev']), ['MOVE', 'HIT', 'MOVE', 'MOVE', 'HIT'])

MUT = [  # (Name, alt, neu, Anzahl der Vorkommen im Extrakt, ersetzt wird nur das erste)
 ('X1 probe.deploy-Fehler ignoriert', 'if (axis == Z_AXIS && probe.deploy())\n      return;', 'if (axis == Z_AXIS && probe.deploy()) {}'),
 ('X2 bltouch.deploy-Alarm ignoriert', 'if (bltouch.deploy()) return;', 'bltouch.deploy();'),
 ('X3 Kaltstart-Kappe entfernt', 'if (axis == Z_AXIS) move_length = sv04c_zhome_limit(move_length, axis_was_homed(Z_AXIS) && axis_is_trusted(Z_AXIS), current_position.z, probe.offset.z, max_length(Z_AXIS));', ''),
 ('X4 Referenz nie gesetzt', 'set_axis_is_at_home(axis);\n      sync_plan_position();', 'sync_plan_position();'),
 ('X5 kill bei fehlendem Endstop entfernt', 'kill(Language_en::MSG_KILL_HOMING_FAILED);', ';'),
 ('X6 Endstop-Pruefung entfernt', 'if (trigger_state()) hit_on_purpose();', 'if (true) hit_on_purpose();'),
 ('X7 zweites Deploy ignoriert', 'if (axis == Z_AXIS && bltouch.deploy()) return;', 'if (axis == Z_AXIS) bltouch.deploy();'),
 ('X8 probe.stow-Fehler ignoriert', 'if (axis == Z_AXIS && probe.stow()) return;', 'if (axis == Z_AXIS) probe.stow();'),
 ('X9 T0/T1 vertauscht', 'if (axis == X_AXIS && active_extruder == 1) sv04_p1_t1_x_completed', 'if (axis == X_AXIS && active_extruder == 0) sv04_p1_t1_x_completed'),
 ('X10 Kaltstart-Rand 100 statt 10', 'sv04c::zh_cold_limit(move_length, max_len, (float)(10))', 'sv04c::zh_cold_limit(move_length, max_len, (float)(100))'),
 ('X11 bekannte Z-Grenze ohne Rand', 'float bound = in.z + in.probe_offset_z + in.margin;', 'float bound = in.z + in.probe_offset_z;'),
 ('X12 erstes Stow entfernt', 'if (axis == Z_AXIS) bltouch.stow();', ';'),
 ('X13 Z-bekannt ignoriert Vertrauen', 'axis_was_homed(Z_AXIS) && axis_is_trusted(Z_AXIS)', 'axis_was_homed(Z_AXIS)'),
 ('X14 Heimrichtung von X fuer T1 falsch', 'axis == X_AXIS\n                  ? ((active_extruder) ? 1 : -1) : home_dir(axis);', 'axis == X_AXIS\n                  ? ((active_extruder) ? -1 : -1) : home_dir(axis);'),
]
class Mutants(unittest.TestCase):
    def test_X1201_every_mutant_of_the_real_functions_is_killed(self):
        base = (IN / 'real_extract.inc').read_text(); rep = []
        for name, old, new in MUT:
            self.assertGreaterEqual(base.count(old), 1, name); txt = base.replace(old, new, 1)
            res = run(build(txt), GRID); bad = 0
            for r, got in zip(GRID, res):
                exp = spec(*r); e2 = {k: exp[k] for k in ('end', 'homed', 'trusted', 'p1z', 'p1t0', 'p1t1', 'moves')}; g2 = {k: got[k] for k in e2}
                m1 = next((e for e in got['ev'] if e.startswith('MOVE:1:')), None)
                if m1 is not None and abs(abs(dist(m1, r[0])[0]) - spec_first_move(*r[:5])) > 1e-3: bad += 1; continue
                if g2 != e2 or names(got['ev']) != exp['ev']: bad += 1
            rep.append(f'{name}: {"getoetet" if bad else "UEBERLEBT"} ({bad} Faelle)')
        Path(tempfile.gettempdir(), 'c12_homeaxis_mutants.txt').write_text('\n'.join(rep) + '\n'); print('\n'.join(rep))
        self.assertEqual([r for r in rep if 'UEBERLEBT' in r], [], '\n'.join(rep))

class Extract(unittest.TestCase):
    def test_E1201_extract_contains_the_real_functions_and_no_hand_written_homeaxis(self):
        t = (IN / 'real_extract.inc').read_text()
        for w in ('void homeaxis(const AxisEnum axis)', 'void do_homing_move(', 'void set_axis_is_at_home(', 'Endstops::validate_homing_move()', 'zh_cold_limit', 'x_home_pos', 'get_homing_bump_feedrate'): self.assertIn(w, t, w)
        self.assertEqual(t.count('void homeaxis('), 1)
if __name__ == '__main__': unittest.main(verbosity=1)
