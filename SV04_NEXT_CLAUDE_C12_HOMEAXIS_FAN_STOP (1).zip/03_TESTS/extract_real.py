#!/usr/bin/env python3
"""Zieht die ECHTEN, praeprozessierten Funktionen aus den .i-Dateien des GitHub-Laufs (SV04_C11_PRAEPROZESSOR) in eine .inc-Datei.
Nutzung: extract_real.py <module_motion.cpp.i> <module_endstops.cpp.i> <ausgabe.inc>   (Linienmarker '# ...' werden ignoriert)"""
import re, sys, hashlib
def body(lines, start):
    depth, out, seen = 0, [], False
    for i in range(start, len(lines)):
        l = lines[i]
        if l.startswith('# '): continue
        out.append(l)
        for ch in l:
            if ch == '{': depth += 1; seen = True
            elif ch == '}': depth -= 1
        if seen and depth == 0: return '\n'.join(out)
    raise SystemExit('Klammern nicht geschlossen ab Zeile %d' % start)
def find(lines, pat, nth=-1):
    hits = [i for i, l in enumerate(lines) if re.search(pat, l)]
    if not hits: raise SystemExit('nicht gefunden: ' + pat)
    return hits[nth]
def oneliners(lines, pats):
    return '\n'.join(next(l for l in lines if re.search(p, l)) for p in pats)
mot = open(sys.argv[1], errors='replace').read().split('\n'); end = open(sys.argv[2], errors='replace').read().split('\n')
parts = []
parts.append(oneliners(mot, [r'^constexpr xyz_feedrate_t homing_feedrate_mm_m', r'^constexpr feedRate_t z_probe_fast_mm_s|^  constexpr feedRate_t z_probe_fast_mm_s']))
parts.append(body(mot, find(mot, r'^__attribute__\(\(always_inline\)\) inline feedRate_t homing_feedrate\(const AxisEnum a\) \{')))
parts.append(oneliners(mot, [r'^inline float base_home_pos\(', r'^inline float max_length\(', r'^inline int8_t home_dir\(']))
parts.append(body(mot, find(mot, r'^inline float home_bump_mm\(const AxisEnum axis\) \{')))
parts.append(oneliners(mot, [r'inline void set_axis_unhomed\(', r'inline void set_axis_homed\(', r'inline void set_axis_trusted\(', r'inline bool axis_was_homed\(', r'inline bool axis_is_trusted\(']))
parts.append(body(mot, find(mot, r'^\s*float x_home_pos\(const uint8_t extruder\) \{')))
parts.append(body(mot, find(mot, r'^\s*feedRate_t get_homing_bump_feedrate\(const AxisEnum axis\) \{')))
parts.append(body(mot, find(mot, r'^\s*void do_homing_move\(const AxisEnum axis, const float distance')))
parts.append(body(mot, find(mot, r'^void set_axis_is_at_home\(const AxisEnum axis\) \{')))
parts.append(body(mot, find(mot, r'^\s*void homeaxis\(const AxisEnum axis\) \{')))
parts.append(body(end, find(end, r'^\s*void Endstops::validate_homing_move\(\) \{')))
i0 = find(mot, r'^# 1 ".*sv04_claude_zhome_policy\.h" 1', 0); i1 = next(i for i in range(i0, len(mot)) if re.match(r'^# \d+ "Marlin/src/module/motion\.cpp" 2', mot[i]))
policy = '\n'.join(l for l in mot[i0:i1] if not l.startswith('#'))
txt = '// Automatisch extrahiert aus dem Praeprozessor-Auszug des GitHub-Laufs. NICHT von Hand aendern.\n' + policy + '\n' + '\n'.join(parts) + '\n'
open(sys.argv[3], 'w').write(txt); print('geschrieben', sys.argv[3], len(txt), 'Bytes, sha256', hashlib.sha256(txt.encode()).hexdigest())
