// C12 AP2: ECHTE, praeprozessierte Funktionen homeaxis(), do_homing_move(), set_axis_is_at_home(), Endstops::validate_homing_move(),
// get_homing_bump_feedrate(), x_home_pos(), die Achs-Inlines und die Z-Home-Policy (sv04c) aus dem Praeprozessor-Auszug des GitHub-Laufs.
// STUBS NUR fuer die Mitspieler: Planner/Stepper, probe.*, bltouch.*, kill(), Display, trigger_state(). Ihr Verhalten ist pro Szenario VORGEGEBEN (Skript),
// es wird nicht aus dem echten Code abgeleitet. Das ist die Testgrenze (siehe 08_AP2_HOMEAXIS_TESTGRENZE.md / C12-Bericht).
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <cmath>
#include <cstring>
#include <string>
#include <sstream>
#include <vector>
enum AxisEnum : int { X_AXIS = 0, Y_AXIS = 1, Z_AXIS = 2 };
typedef float feedRate_t; typedef uint8_t linear_axis_bits_t; typedef const char *Language_Str;
template <typename T> struct XYZval { T x, y, z; T &operator[](int i) { return i == 0 ? x : i == 1 ? y : z; } const T &operator[](int i) const { return i == 0 ? x : i == 1 ? y : z; } };
typedef XYZval<float> xyz_pos_t; typedef XYZval<float> xyz_feedrate_t;
struct abce_pos_t { float x, y, z, e; float &operator[](int i) { return i == 0 ? x : i == 1 ? y : i == 2 ? z : e; } };
struct xyze_pos_t { float x, y, z, e; float &operator[](int i) { return i == 0 ? x : i == 1 ? y : i == 2 ? z : e; } };
inline float pgm_read_any(const float *p) { return *p; }
inline int8_t pgm_read_any(const int8_t *p) { return *p; }
#define _MAX(a, b) ((a) > (b) ? (a) : (b))
#define MARLIN_DEBUG_LEVELING 4
enum { DXC_AUTO_PARK_MODE = 1, DXC_DUPLICATION_MODE = 2 };
uint8_t marlin_debug_flags = 0, active_extruder = 0, dual_x_carriage_mode = DXC_AUTO_PARK_MODE;
linear_axis_bits_t axis_homed = 0, axis_trusted = 0;
xyze_pos_t current_position = { -62, 0, 0, 0 }, destination = { 0, 0, 0, 0 }; xyz_pos_t position_shift = { 0, 0, 0 }, hotend_offset[2] = { { 0, 0, 0 }, { 0, 0, 0 } };
bool sv04_p1_t1_x_completed = false, sv04_p1_t0_x_completed = false, sv04_p1_z_completed = false;
// ---- Szenario-Skript ----
struct Script { bool probe_deploy_fail = false, probe_stow_fail = false; int bl_deploy_fail_at = 0; std::string trig = "11111111"; int abort_at = 0; int kill_called = 0; } S;
std::vector<std::string> ev; int n_bl_deploy = 0, n_moves = 0, n_trig = 0;
struct AbortEx {}; struct KillEx { const char *m; };
static void kill(const char *m) { ev.push_back(std::string("KILL:") + m); throw KillEx{m}; }
struct Probe { xyz_pos_t offset = { 0, 25, 0 }; bool deploy() { ev.push_back("PROBE_DEPLOY"); return S.probe_deploy_fail; } bool stow() { ev.push_back("PROBE_STOW"); return S.probe_stow_fail; } } probe;
struct BLTouch { bool deploy() { ++n_bl_deploy; ev.push_back("BL_DEPLOY"); return S.bl_deploy_fail_at && n_bl_deploy == S.bl_deploy_fail_at; } void stow() { ev.push_back("BL_STOW"); } } bltouch;
struct Planner { abce_pos_t get_axis_positions_mm() { return { current_position.x, current_position.y, current_position.z, 0 }; } void set_machine_position_mm(abce_pos_t &) {}
  void buffer_segment(abce_pos_t &t, float fr, uint8_t) { ++n_moves; char b[96]; std::snprintf(b, sizeof b, "MOVE:%d:%g:%g:%g:%g", n_moves, (double)t.x, (double)t.y, (double)t.z, (double)fr); ev.push_back(b); if (S.abort_at && n_moves == S.abort_at) throw AbortEx(); } void synchronize() {} } planner;
struct RTS { void RTS_SndData(unsigned long, unsigned) { ev.push_back("DISPLAY_PAGE55"); } } rtscheck;
struct Endstops { static bool trigger_state() { const bool t = n_trig < (int)S.trig.size() ? S.trig[n_trig] == '1' : true; ++n_trig; return t; } static void hit_on_purpose() { ev.push_back("HIT"); } static void validate_homing_move(); } endstops;
namespace Language_en { const char *MSG_KILL_HOMING_FAILED = "Homing Failed"; }
static void sync_plan_position() {} static void update_workspace_offset(const AxisEnum) {}
static void serial_echo_start() {} static void serialprintPGM(const char *) {}
#include "real_extract.inc"
static int dist_log_index = 0;
int main() {
  char line[512];
  while (std::fgets(line, sizeof line, stdin)) {
    // axis ext homed trusted z probe_deploy_fail probe_stow_fail bl_deploy_fail_at trig abort_at
    int axis, ext, homed, trusted, pdf, psf, bdf, ab; float z; char trig[64];
    if (std::sscanf(line, "%d %d %d %d %f %d %d %d %63s %d", &axis, &ext, &homed, &trusted, &z, &pdf, &psf, &bdf, trig, &ab) != 10) continue;
    S = Script(); S.probe_deploy_fail = pdf; S.probe_stow_fail = psf; S.bl_deploy_fail_at = bdf; S.trig = trig; S.abort_at = ab;
    ev.clear(); n_bl_deploy = n_moves = n_trig = 0; active_extruder = ext; axis_homed = homed; axis_trusted = trusted; current_position = { -62, 0, z, 0 }; destination = { 0, 0, 0, 0 };
    sv04_p1_t1_x_completed = sv04_p1_t0_x_completed = sv04_p1_z_completed = false; probe = Probe(); std::string end = "OK";
    try { homeaxis((AxisEnum)axis); } catch (KillEx &) { end = "KILL"; } catch (AbortEx &) { end = "ABORT"; }
    std::string evs; for (auto &e : ev) { if (!evs.empty()) evs += ","; evs += e; }
    std::printf("end=%s homed=%d trusted=%d p1z=%d p1t0=%d p1t1=%d moves=%d ev=%s\n", end.c_str(), (int)axis_homed, (int)axis_trusted, (int)sv04_p1_z_completed, (int)sv04_p1_t0_x_completed, (int)sv04_p1_t1_x_completed, n_moves, evs.c_str());
  }
}
