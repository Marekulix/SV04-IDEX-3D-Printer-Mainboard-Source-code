"""SV04 NEXT C12 AP3 - Luefter im Stopp (nur EIN) - Host-Tests (KEIN STM32-Build, KEINE Hardware).
 F12xx  Gate-Funktion gegen unabhaengiges Modell + Differenz zum C10-Gate (nur M106 darf sich unterscheiden), echter Kopf der C10-gcode.cpp, Schalter
 P12xx  Patch-Skript   X12xx  Mutanten
Grundlage der Entscheidung: echter M106_M107.cpp/temperature.cpp aus dem Quellen-Export des GitHub-Laufs (M106/M107 setzen nur set_fan_speed(); keine Heizung/Bewegung).
NICHT belegt: welche Last an FAN_PIN PB14 / FAN1_PIN PB12 haengt."""
import hashlib, random, re, shutil, subprocess, sys, tempfile, unittest
from pathlib import Path
HERE = Path(__file__).resolve().parent; CPP = HERE / 'cpp'; IN = HERE / 'eingang'; APPLY = HERE.parent / '02_PATCHES/apply_c12.py'
GXX = ['g++', '-std=c++11', '-O1', '-Wall', '-Wextra', '-Wno-unused-function']
REL = 'Marlin/src/gcode/sv04_claude_stopgate.h'
def sh(cmd, **kw): return subprocess.run(cmd, capture_output=True, text=True, **kw)
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def patched_header(mut=None):
    d = Path(tempfile.mkdtemp()); (d / 'Marlin/src/gcode').mkdir(parents=True); shutil.copy(IN / 'c10/sv04_claude_stopgate.h', d / REL)
    r = sh([sys.executable, '-I', str(APPLY), str(d)]); assert r.returncode == 0, r.stdout + r.stderr
    f = d / REL
    if mut: t = f.read_text(); assert t.count(mut[0]) == 1, mut[0]; f.write_text(t.replace(mut[0], mut[1]))
    return f

def build_gate(header, defines=()):
    d = Path(tempfile.mkdtemp()); exe = d / 'g'
    r = sh(GXX + [f'-D{x}' for x in defines] + [f'-DSV04_GATE_HEADER="{header}"', str(CPP / 'gate_driver.cpp'), '-o', str(exe)]); assert r.returncode == 0, r.stderr[-800:]
    return exe

def parse_like_marlin(t):
    s = t.lstrip(' ')
    if not s: return ('\0', 0, 0)
    m = re.match(r'([A-Za-z])\s*([0-9]*)(?:\.([0-9]+))?', s)
    if not m: return (s[0], 0, 0)
    return (m.group(1).upper(), int(m.group(2) or 0), int(m.group(3) or 0))

def gate_run(exe, texts):
    inp = ''.join('%s\t%d\t%d\t%s\n' % (*parse_like_marlin(t), t) for t in texts)
    out = sh([str(exe)], input=inp).stdout.split(); assert len(out) == len(texts); return [x == '1' for x in out]

def m106_model(t):
    """Unabhaengiges Modell (Regex statt Zeichenschleife): erlaubt iff 'M106' + nur Tokens P0|P1 und S1..S255, jeder Buchstabe hoechstens einmal."""
    m = re.fullmatch(r' *M106((?: +[A-Z][0-9]*)*) *', t)
    if not m: return False
    toks = m.group(1).split()
    letters = [x[0] for x in toks]
    if len(set(letters)) != len(letters): return False
    for x in toks:
        if x[0] == 'P' and not re.fullmatch(r'P[01]', x): return False
        if x[0] == 'S' and not (re.fullmatch(r'S[1-9][0-9]{0,2}', x) and 1 <= int(x[1:]) <= 255): return False
        if x[0] not in 'PS': return False
    return True

ALLOW = ['M106', 'M106 S255', 'M106 S1', 'M106 S128', 'M106 P0', 'M106 P1', 'M106 P1 S200', 'M106 S200 P0', 'M106 P0 S255', '  M106', 'M106  ', 'M106 S99', 'M106 S10']
DENY = ['M107', 'M107 P1', 'M106 S0', 'M106 P1 S0', 'M106 S256', 'M106 S1000', 'M106 S0255', 'M106 S01', 'M106 S-1', 'M106 S+5', 'M106 S1.5', 'M106 S', 'M106 P', 'M106 P2', 'M106 P01', 'M106 P-1', 'M106 P0 P1', 'M106 S1 S2',
        'M106 T1', 'M106 T1 S5', 'M106 I0', 'M106 I1 S10', 'M106 A', 'M106 A1', 'M106 S100 A1', 'M106 B1', 'M106 S100 F1', 'M106S100', 'M106.1', 'M1060', 'M0106', 'M106 S100;M107', 'M106 s100', 'M106 p1', 'M106\tS100', 'M106 S1e2', 'M106 SS1', 'M106 S 100', 'M106 P1 S100 T0']

class Gate(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.h12 = patched_header(); cls.e12 = build_gate(cls.h12); cls.e10 = build_gate(IN / 'c10/sv04_claude_stopgate.h')

    def test_F1201_allow_and_deny_lists(self):
        for t, r in zip(ALLOW, gate_run(self.e12, ALLOW)): self.assertTrue(r, t)
        for t, r in zip(DENY, gate_run(self.e12, DENY)): self.assertFalse(r, t)

    def test_F1202_c10_gate_refuses_every_m106_and_m107(self):
        for t, r in zip(ALLOW + DENY, gate_run(self.e10, ALLOW + DENY)): self.assertFalse(r, t)

    def test_F1203_differential_against_independent_model_and_against_c10(self):
        rnd = random.Random(1212); alphabet = 'MP S0123456789.-+TIAGB;\t'
        corpus = ['M%d' % n for n in range(0, 1300)] + ['G%d' % n for n in range(0, 40)] + ['T0', 'T1']
        for n in (104, 140, 105, 114, 115, 119, 503, 999, 112, 108, 410, 106, 107, 84, 28):
            for pa in ('', ' S0', ' S1', ' S255', ' S256', ' P1', ' P1 S5', ' T1', ' S0 T1', ' X', ' I1', ' A', ' R'): corpus.append('M%d%s' % (n, pa))
        corpus += ['M106' + ''.join(rnd.choice(alphabet) for _ in range(rnd.randint(0, 9))) for _ in range(6000)]
        corpus += [''.join(rnd.choice('M1 06PS25.') for _ in range(rnd.randint(1, 10))) for _ in range(6000)]
        r12 = gate_run(self.e12, corpus); r10 = gate_run(self.e10, corpus); bad = []
        for t, a, b in zip(corpus, r12, r10):
            exp = m106_model(t) if re.match(r' *M106(?![0-9.])', t) and parse_like_marlin(t)[:2] == ('M', 106) and parse_like_marlin(t)[2] == 0 else b
            if a != exp: bad.append((t, a, exp))
        self.assertEqual(bad[:5], [], f'{len(bad)} von {len(corpus)}')
        diff = [t for t, a, b in zip(corpus, r12, r10) if a != b]
        self.assertTrue(diff and all(re.match(r' *M106', t) for t in diff), 'Unterschied zu C10 ausschliesslich bei M106')

    def test_F1204_no_m107_variant_is_ever_allowed(self):
        rnd = random.Random(7); cands = ['M107'] + ['M107 ' + ''.join(rnd.choice('PS0123456789 ') for _ in range(rnd.randint(1, 6))) for _ in range(3000)]
        self.assertFalse(any(gate_run(self.e12, cands)))

    def test_F1205_switch_off_restores_c10_behaviour(self):
        e = build_gate(self.h12, ['SV04_CLAUDE_STOPP_FAN_ON=0']); self.assertFalse(any(gate_run(e, ALLOW)))
        self.assertEqual(gate_run(e, ['M999', 'M104 S0', 'M106 S1', 'G28']), [True, True, False, False])

    def test_F1206_parser_and_text_must_still_agree_for_m106(self):
        # Marlin-Parser meldet 107 bzw. Unterbefehl, Text sagt M106 -> verweigert (Cross-Check aus C10 bleibt wirksam)
        inp = 'M\t107\t0\tM106 S5\nM\t106\t1\tM106 S5\nT\t106\t0\tM106 S5\nM\t106\t0\tM106 S5\n'
        out = sh([str(self.e12)], input=inp).stdout.split(); self.assertEqual(out, ['0', '0', '0', '1'])

class Head(unittest.TestCase):
    """Echter Kopf von process_parsed_command (C10-gcode.cpp) mit dem C12-Gate."""
    @classmethod
    def setUpClass(cls):
        t = (IN / 'c10/gcode.cpp').read_text(); a = t.index('void GcodeSuite::process_parsed_command(const bool no_ok/*=false*/) {'); b = t.index('  switch (parser.command_letter) {', a)
        d = Path(tempfile.mkdtemp()); (d / 'head_extract.inc').write_text(t[a:b] + '  dispatched++;\n  if (!no_ok) queue.ok_to_send();\n  SERIAL_OUT(msgDone);\n}\n')
        h = patched_header(); cls.exe = d / 'h'
        r = sh(GXX + ['-I', str(d), f'-DSV04_GATE_HEADER="{h}"', str(CPP / 'head_driver.cpp'), '-o', str(cls.exe)]); assert r.returncode == 0, r.stderr[-800:]
    def run1(self, stopped, text):
        l, c, s = parse_like_marlin(text); o = sh([str(self.exe), str(stopped), '0', l, str(c), str(s), '0', text]).stdout.split(); return dict(x.split('=') for x in o)
    def test_F1210_stopped_allowed_m106_reaches_the_dispatcher_refused_ones_do_not_but_still_get_their_ok(self):
        for t in ALLOW: r = self.run1(1, t); self.assertEqual((r['dispatched'], r['ok']), ('1', '1'), t)
        for t in ('M106 S0', 'M107', 'M106 T1', 'M106 S256', 'M106 P2'): r = self.run1(1, t); self.assertEqual((r['dispatched'], r['ok'], r['done']), ('0', '1', '1'), t)
    def test_F1211_not_stopped_everything_reaches_the_dispatcher(self):
        for t in ALLOW + ['M107', 'M106 S0', 'G28']: self.assertEqual(self.run1(0, t)['dispatched'], '1', t)

class Patch(unittest.TestCase):
    def tree(self):
        d = Path(tempfile.mkdtemp()); (d / 'Marlin/src/gcode').mkdir(parents=True); shutil.copy(IN / 'c10/sv04_claude_stopgate.h', d / REL); return d
    def apply(self, d): return sh([sys.executable, '-I', str(APPLY), str(d)])
    def test_P1201_idempotent_byte_stable(self):
        d = self.tree(); self.assertEqual(self.apply(d).returncode, 0); h = sha(d / REL); r = self.apply(d); self.assertEqual(r.returncode, 0); self.assertIn('ALREADY', r.stdout); self.assertEqual(h, sha(d / REL))
    def test_P1202_foreign_aborts_nothing_written(self):
        d = self.tree(); (d / REL).write_text((d / REL).read_text() + '\n'); h = sha(d / REL); self.assertEqual(self.apply(d).returncode, 3); self.assertEqual(h, sha(d / REL))
    def test_P1203_patched_but_modified_aborts(self):
        d = self.tree(); self.apply(d); (d / REL).write_text((d / REL).read_text() + '// x\n'); r = self.apply(d); self.assertEqual(r.returncode, 3); self.assertIn('C12-Signatur', r.stdout)
    def test_P1204_pin_is_the_c10_header_and_nothing_else_changes(self):
        self.assertEqual(sha(IN / 'c10/sv04_claude_stopgate.h')[:8], 'c8f8716f'); d = self.tree(); self.apply(d)
        a = (IN / 'c10/sv04_claude_stopgate.h').read_text().splitlines(); b = (d / REL).read_text().splitlines(); it = iter(b)
        self.assertTrue(all(any(x == y for y in it) for x in a), 'keine C10-Zeile geloescht oder umgestellt')
    def test_P1205_only_the_header_is_touched(self):
        d = self.tree(); (d / 'Marlin/src/gcode/other.txt').write_text('x'); self.apply(d); self.assertEqual((d / 'Marlin/src/gcode/other.txt').read_text(), 'x')

MUT = [
 ('X1 S0 erlaubt', "if (*v == '0' || n > 3) return false;", "if (n > 3) return false;"),
 ('X2 S>255 erlaubt', 'if (val < 1 || val > 255) return false;', 'if (val < 1) return false;'),
 ('X3 S 0 nicht geprueft (val>=0)', 'if (val < 1 || val > 255) return false;', 'if (val > 255) return false;'),
 ('X4 P2 erlaubt', "(*v != '0' && *v != '1')", "(*v != '0' && *v != '1' && *v != '2')"),
 ('X5 P01 erlaubt', 'if (n != 1 ||', 'if (n < 1 ||'),
 ('X6 doppeltes P erlaubt', 'if (seen & 1u) return false;', ''),
 ('X7 doppeltes S erlaubt', 'if (seen & 2u) return false;', ''),
 ('X8 andere Buchstaben (T) erlaubt', '    else return false;\n  }\n}', '    else if (c != \'T\') return false;\n  }\n}'),
 ('X9 Vorzeichen erlaubt', "if (*q < '0' || *q > '9') return false;\n    if (c == 'P')", "if ((*q < '0' || *q > '9') && *q != '-') return false;\n    if (c == 'P')"),
 ('X10 leerer Wert erlaubt', 'if (n < 1) return false;', ''),
 ('X11 M107 mit freigegeben', '    case 106:                                          // SV04 NEXT C12\n', '    case 107: return true;\n    case 106:                                          // SV04 NEXT C12\n'),
 ('X12 Schalter wirkungslos', '#if SV04_CLAUDE_STOPP_FAN_ON\n        return sv04c12_m106_on_ok(p);', '#if 1\n        return sv04c12_m106_on_ok(p);'),
 ('X13 Parameter nach M106 nicht geprueft', 'return sv04c12_m106_on_ok(p);', 'return true;'),
 ('X14 fuehrende Null bei S erlaubt', "if (*v == '0' || n > 3) return false;", "if (n > 3) return false;\n      if (val_dummy_zero(v)) return false;"),
]
EQUIV = {'X3', 'X10'}   # aequivalent: die Pruefung ist durch eine spaetere Pruefung doppelt abgesichert (Begruendung im Kommentar); Beweis = identisches Verhalten auf der VOLLSTAENDIGEN Domaene
def full_domain():
    import itertools
    alpha = '0123456789-+.'; vals = [''.join(p) for n in range(0, 5) for p in itertools.product(alpha, repeat=n)]
    return ['M106 P' + v for v in vals] + ['M106 S' + v for v in vals] + ['M106 S' + v + ' P1' for v in vals[:2000]] + ['M106 P1 S' + v for v in vals[:2000]]
class Mutants(unittest.TestCase):
    def test_X1201_every_mutant_is_killed_or_proven_equivalent(self):
        corpus = ALLOW + DENY + ['M106 S%d' % i for i in range(0, 300)] + ['M106 P%d' % i for i in range(0, 12)] + ['M107', 'M107 S0', 'M106 T0 S1', 'M106 S1 T0', 'M106 P1 P1', 'M106 S5 S5', 'M106 P0 S0']
        dom = full_domain(); ref = gate_run(build_gate(patched_header()), dom); rep = []; corpus = corpus + dom
        for name, old, new in MUT:
            tag = name.split()[0]
            if 'val_dummy_zero' in new: new = new.replace('\n      if (val_dummy_zero(v)) return false;', '')
            h = patched_header((old, new)); e = build_gate(h, ['SV04_CLAUDE_STOPP_FAN_ON=0'] if tag == 'X12' else [])
            res = gate_run(e, corpus); exp = [False] * len(corpus) if tag == 'X12' else [m106_model(t) for t in corpus]
            bad = sum(1 for a, b in zip(res, exp) if a != b)
            if tag in EQUIV:
                dd = sum(1 for a, b in zip(gate_run(e, dom), ref) if a != b)
                rep.append(f'{name}: AEQUIVALENT bewiesen (Domaene {len(dom)} Faelle, {dd} Abweichungen)'); self.assertEqual(dd, 0, name)
            else:
                rep.append(f'{name}: {"getoetet" if bad else "UEBERLEBT"} ({bad} Faelle)'); self.assertTrue(bad > 0, name)
        Path(tempfile.gettempdir(), 'c12_fan_mutants.txt').write_text('\n'.join(rep) + '\n'); print('\n'.join(rep))
if __name__ == '__main__': unittest.main(verbosity=1)
