#!/usr/bin/env python3
"""SV04 NEXT C12 (Luefter im Stopp, nur die sichere Richtung EIN) - ein Patch, SHA-gepinnt, idempotent, fail-closed.
Aufruf: apply_c12.py <baum>   (Baum = 318 + C9 + C10 + C11; wirkt auf Marlin/src/gcode/sv04_claude_stopgate.h)
Erlaubt im Stopp zusaetzlich: M106 mit optional P0|P1 und optional S1..S255 (nur Ziffern). Alles andere an M106 und ALLE M107 bleiben verweigert.
Fremder Hash / gemischter oder veraenderter Stand -> Abbruch Exit 3, nichts wird geschrieben."""
import hashlib, pathlib, sys
REL = 'Marlin/src/gcode/sv04_claude_stopgate.h'
PIN = 'c8f8716f8d42f6d48dc474320173e186600895563c3d715b37ea0490cbb89265'      # C10-Endstand (unveraendert in C11)
FINAL = '7ead4e640f70f1c9796d5cb3085f7f758a40ab63ce127fc1c4623d09cef9f29c'
SIG = 'SV04 NEXT C12'
def sha(b): return hashlib.sha256(b).hexdigest()
def fail(m): print('C12 FAIL:', m); sys.exit(3)
E = [
 (' *   M104 S0 [T<n>]   M140 S0               (nur Heizer AUS, S muss numerisch 0 sein, keine weiteren Parameter)\n */\n',
  ' *   M104 S0 [T<n>]   M140 S0               (nur Heizer AUS, S muss numerisch 0 sein, keine weiteren Parameter)\n'
  ' *   M106 [P0|P1] [S1..S255]                (SV04 NEXT C12: nur Luefter EIN; M107, S0, T, I, A bleiben verweigert)\n */\n'),
 ('#ifndef SV04_CLAUDE_STOPP_GATE\n  #define SV04_CLAUDE_STOPP_GATE 1\n#endif\n',
  '#ifndef SV04_CLAUDE_STOPP_GATE\n  #define SV04_CLAUDE_STOPP_GATE 1\n#endif\n\n// SV04 NEXT C12: Luefter-EIN im Stopp erlaubt (0 = wie C10, M106 verweigert)\n#ifndef SV04_CLAUDE_STOPP_FAN_ON\n  #define SV04_CLAUDE_STOPP_FAN_ON 1\n#endif\n'),
 ('/**\n * cmd      : Zeiger auf den Befehlstext ab Befehlsbuchstabe (parser.command_ptr)\n',
  '''// SV04 NEXT C12: M106 im Stopp nur in der sicheren Richtung (Luefter EIN). Ohne S setzt Marlin 255 (EIN, M106_M107.cpp).
// P (optional): genau "0" oder "1". S (optional): 1..255, nur Ziffern, keine fuehrende 0. Verweigert: T, I, A (koennen 0 setzen/kopieren),
// doppelte Buchstaben, Vorzeichen, Punkt, leere Werte, S0, S>255, alle anderen Buchstaben.
static inline bool sv04c12_m106_on_ok(const char *p) {
  unsigned seen = 0;                          // Bit0 = P, Bit1 = S
  for (;;) {
    while (*p == ' ') p++;
    if (*p == '\\0') return true;
    const char c = *p++;
    const char *v = p;
    while (*p && *p != ' ') p++;
    const int n = (int)(p - v);
    if (n < 1) return false;
    for (const char *q = v; q < p; q++) if (*q < '0' || *q > '9') return false;
    if (c == 'P') {
      if (seen & 1u) return false;
      seen |= 1u;
      if (n != 1 || (*v != '0' && *v != '1')) return false;
    }
    else if (c == 'S') {
      if (seen & 2u) return false;
      seen |= 2u;
      if (*v == '0' || n > 3) return false;
      int val = 0;
      for (const char *q = v; q < p; q++) val = val * 10 + (*q - '0');
      if (val < 1 || val > 255) return false;
    }
    else return false;
  }
}

/**
 * cmd      : Zeiger auf den Befehlstext ab Befehlsbuchstabe (parser.command_ptr)
'''),
 ('    case 140:\n      return sv04c10_params_ok(p, "S", \'S\', 0);\n    default:\n',
  '    case 140:\n      return sv04c10_params_ok(p, "S", \'S\', 0);\n    case 106:                                          // SV04 NEXT C12\n      #if SV04_CLAUDE_STOPP_FAN_ON\n        return sv04c12_m106_on_ok(p);\n      #else\n        return false;\n      #endif\n    default:\n'),
]
def main():
    if len(sys.argv) != 2: fail('usage: apply_c12.py <baum>')
    f = pathlib.Path(sys.argv[1]) / REL
    if not f.is_file(): fail(REL + ' fehlt')
    b = f.read_bytes(); t = b.decode('utf-8')
    if sha(b) == FINAL: print('C12 %s: ALREADY sha256 %s' % (REL, sha(b))); return
    if SIG in t: fail('%s: enthaelt C12-Signatur, Hash %s ist nicht der erwartete Endstand (veraendert oder gemischt)' % (REL, sha(b)))
    if sha(b) != PIN: fail('%s: fremder Hash %s (erwartet %s)' % (REL, sha(b), PIN))
    for old, _ in E:
        if t.count(old) != 1: fail('Anker %dx statt 1x: %r' % (t.count(old), old[:50]))
    for old, new in E: t = t.replace(old, new)
    f.write_text(t, encoding='utf-8'); print('C12 %s: PATCHED sha256 %s' % (REL, sha(t.encode())))
if __name__ == '__main__': main()
