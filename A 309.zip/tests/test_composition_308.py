#!/usr/bin/env python3
"""Test the real SHA-pinned STAND_282 in the 287 fixture, not just modern sources."""
from pathlib import Path
import hashlib,sys,tempfile,shutil,subprocess,importlib.util
P=Path(__file__).resolve().parents[1]
F=P/'fixtures/baseline_287'
C=Path('Marlin/src/feature/sv04_claude_auto60/sv04_claude_auto60_core.h')
A=Path('Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc')
E=Path('Marlin/src/feature/sv04_claude_auto60/sv04_claude_eeprom_core.h')
spec=importlib.util.spec_from_file_location('mig',P/'ensure_282_to_287_308.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(p,good=True):
 r=subprocess.run([sys.executable,str(P/'integrate_308.py'),str(p)],capture_output=True,text=True)
 if good:
  assert r.returncode==0,r.stdout+'\n'+r.stderr
  assert 'SV04_NEXT_308_COMPOSITION=PASS' in r.stdout
 else:assert r.returncode!=0,'unexpected acceptance of untrusted sources'
 return r
with tempfile.TemporaryDirectory(prefix='sv04_308_tests_') as td:
 temp=Path(td)
 # Simulate the 291/307 real coordinator core state (SHA 5553...) and old adapter.
 p=temp/'old282';shutil.copytree(F,p)
 for src,dest in [('sv04_claude_auto60_core.h',C),('sv04_claude_auto60_marlin.inc',A)]:
  shutil.copy2(P/'fixtures/old282'/src,p/dest)
 assert sha(p/C)==m.PIN282_CORE and sha(p/A)==m.PIN282_ADAPTER
 (p/E).unlink() # 306's real missing EEPROM header: combined with old 282 code
 r=run(p)
 assert 'SV04_308 MIGRATE' in r.stdout
 assert 'SV04_308 CREATE' in r.stdout
 assert sha(p/m.BACKUP/(str(C).replace('/','__')+'.original'))==m.PIN282_CORE
 assert sha(p/m.BACKUP/(str(A).replace('/','__')+'.original'))==m.PIN282_ADAPTER
 print('PASS 308_01 old 282 core + old 282 adapter + missing EEPROM: migrate, integrate, preserve backups')
 assert 'SV04 NEXT 294: successful readback' in (p/C).read_text()
 assert 'SV04 NEXT 303: resend mesh' in (p/A).read_text()
 assert 'SV04 NEXT C2: stop()' in (p/A).read_text()
 print('PASS 308_02 markers for 294, 303 and C2 remain after old-to-new integration')
 before={str(f.relative_to(p)):sha(f) for f in p.rglob('*') if f.is_file()}
 r=run(p)
 after={str(f.relative_to(p)):sha(f) for f in p.rglob('*') if f.is_file()}
 assert before==after,'second run unexpectedly changed files'
 print('PASS 308_03 idempotent rerun of migrated fully patched sources')
 p=temp/'modern';shutil.copytree(F,p);r=run(p)
 assert 'SV04_NEXT_308_COMPOSITION=PASS' in r.stdout
 print('PASS 308_04 modern 287 pins still integrate without changes to unrelated sources')
 p=temp/'alien_core';shutil.copytree(F,p)
 (p/C).write_text('#pragma once\n// maliciously modified header\n')
 before=sha(p/C);r=run(p,False)
 assert 'UNKNOWN_EXISTING_SOURCE_NOT_REPLACED' in r.stderr and before==sha(p/C)
 print('PASS 308_05 foreign coordinator source rejected and preserved')
 p=temp/'alien_adapter';shutil.copytree(F,p)
 (p/A).write_text('// not a supported Marlin adapter source\n')
 before=sha(p/A);r=run(p,False)
 assert 'UNKNOWN_EXISTING_SOURCE_NOT_REPLACED' in r.stderr and before==sha(p/A)
 print('PASS 308_06 foreign adapter source rejected and preserved')
 p=temp/'alien_eeprom';shutil.copytree(F,p)
 (p/E).write_text('#pragma once\n// foreign EEPROM\n')
 before=sha(p/E);r=run(p,False)
 assert before==sha(p/E) and 'UNKNOWN_EXISTING_SOURCE_NOT_REPLACED' in r.stderr
 print('PASS 308_07 foreign EEPROM header rejected and preserved')
 p=temp/'old_with_conflict';shutil.copytree(F,p)
 shutil.copy2(P/'fixtures/old282/sv04_claude_auto60_core.h',p/C)
 (p/A).write_text('// foreign adapter\n')
 before=sha(p/C);r=run(p,False)
 assert sha(p/C)==before and not (p/m.BACKUP).exists()
 print('PASS 308_08 transaction preflight avoids partial migration when one source is unknown')
 for fn,pin in [('sv04_claude_auto60_core.h',m.PIN282_CORE),('sv04_claude_auto60_marlin.inc',m.PIN282_ADAPTER)]:
  assert sha(P/'fixtures/old282'/fn)==pin
 assert sha(F/C)==m.F['sv04_claude_auto60_core.h'] and sha(F/A)==m.MODERN_ADAPTER
 print('PASS 308_09 source fingerprints match independently archived Claude 282 + 287')
 # Pin 289 adapter from the ACTUAL 307 log; this is an observed but not locally available byte sequence.
 assert m.PIN289_ADAPTER=='4e2da07a5dbd0952a6a623d582ab7420f1e2f8bafbc090a4f4444b44f9d780db'
 print('PASS 308_10 actual 289 adapter fingerprint carried over from 291/307 GitHub logs (bytes unavailable offline)')
print('SUMMARY tests=10 pass=10 fail=0')
