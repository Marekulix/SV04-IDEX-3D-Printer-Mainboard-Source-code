# SV04 NEXT 309 – PlatformIO Erstinstallation (kein Firmwarepatch)

## GitHub Run 308: Nachweis
- Vollstaendige Integration erfolgreich: `SV04_NEXT_308_COMPOSITION=PASS`.
- 50/50 EEPROM-C++-Tests und 150/150 Koordinatortests erfolgreich.
- BEIDE Profile VOR dem Compiler abgebrochen (`CLEAN_EXIT=1`).
- Fehler in `generic_create_variant.py`: `FRAMEWORK_DIR = platform.get_package_dir('framework-arduinoststm32')` ergibt None.
- Ursache: `pio run -t clean` wurde auf einem frischen Runner vor der ersten Paketinstallation aufgerufen.

## Reparatur
- Kein `pio run -t clean` vor dem ersten Build.
- Stattdessen getrennte PIO-Ausgabeverzeichnisse durch gezieltes Entfernen von `.pio/build/STM32F103RET6_creality` zwischen den Profilen.
- Jeder Lauf startet mit `pio run -d oem -e STM32F103RET6_creality`, wodurch PlatformIO zuerst das Arduino-Framework installiert.
- Erfolgsmarker im Buildprotokoll wird zusätzlich zum Exitcode geprüft.
- Warnungen, Pakete und Speicherbedarf werden je Profil archiviert.

## Basis und Grenzen
Firmware-/Patches: bytegenau wie SV04 NEXT 308. Es wurden KEINE Quellfunktionen veraendert.
OEM Commit: 1867fcba75354a5c65e0631d6972dd19f1bd6cbe.
PlatformIO: 6.1.18.
Die erfolgreichen Buildlogs von 291 beweisen, dass ein `pio run` ohne vorausgehendes Clean die Frameworkinstallation korrekt ausfuehrt.
309 muss diese erste Buildstufe im realen GitHub-Lauf erst bestaetigen.
Kein Flashen. Keine Hardwarefreigabe. 291 bleibt letzter erfolgreich kompilierter Stand.
