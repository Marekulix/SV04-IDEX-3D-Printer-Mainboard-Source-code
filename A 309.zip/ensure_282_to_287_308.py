#!/usr/bin/env python3
"""SV04 NEXT 308: fix actual 307 source mismatch 282->285/287 before patches.
Old sources are SHA-256 pinned against Claudes C2 STAND_282 and the real
291/307 GitHub logs. All source states are checked before *any* writes.
Never upgrade alien or unknown sources. Keep byte-exact previous file backups.
"""
from pathlib import Path
import sys,hashlib,os
HERE=Path(__file__).resolve().parent
FEATURE=Path('Marlin/src/feature/sv04_claude_auto60')
ADAPTER=Path('Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc')
F={
    'sv04_claude_auto60_core.h': '8792087b437ec8d0d1e70d32ce87106db08f387f5bd04fb2dbb49300ad9b65fd',
    'sv04_claude_eeprom_core.h': 'ea7705dd688ae0e7073d46afe3fd8532e8f30ba1eaaa1abe95005f06965b9b57',
    'sv04_claude_g29_session.h': 'd616c3e94826ffaac50e5e43fa842a53f17a091ff24537433edc8ce1c8afa250',
}
PIN282_CORE='5553a39a9968690cc9fd14bfd6458996c26971224edf3fcec555bf4f2460709b'
PIN282_ADAPTER='0ff5576afc1590c9c29ef6305f3fd235c7b62fb7eb64a67ad65a2dd7de3e78cf'
PIN289_ADAPTER='4e2da07a5dbd0952a6a623d582ab7420f1e2f8bafbc090a4f4444b44f9d780db'
MODERN_ADAPTER='ee3cb57e384b90ae029be70de5a505a3fd918e8439bc64a1a2a1954a10f74d4a'
PATCHED_CORE='faf2d034a067ccecea5e0d413028e9598935fe577486748a6a5493bc16c6a097'
PATCHED_ADAPTER='03543e739c3fe75d668f57202441597a3a5050b62ffaa25c2f8ca45573db4f1f'
PATCHED_EEPROM='379848c3a0e3cd2f2a67e4f560b0a02592b6d95bd414818d8d4fc8ad0f04a2a3'
BACKUP=Path('.sv04_next_308_pre_migration')
def sha_bytes(data):return hashlib.sha256(data).hexdigest()
def sha(path):return sha_bytes(path.read_bytes())
def migrate(root):
    root=Path(root).resolve()
    desired=[]
    for name,pinned in F.items():
        path=FEATURE/name
        original=HERE/'fixtures/baseline_287'/path
        if not original.is_file() or sha(original)!=pinned:raise RuntimeError('UNVERIFIED_MODERN_SOURCE '+str(path))
        desired.append((path,original.read_bytes(),pinned))
    base_adapter=HERE/'fixtures/baseline_287'/ADAPTER
    if not base_adapter.is_file() or sha(base_adapter)!=MODERN_ADAPTER:raise RuntimeError('UNVERIFIED_MODERN_ADAPTER')
    desired.append((ADAPTER,base_adapter.read_bytes(),MODERN_ADAPTER))
    # Check all destinations before modifying any of them.
    actions=[]
    for path,modern,modern_sha in desired:
        dest=root/path
        if dest.exists() and not dest.is_file():raise RuntimeError('NONFILE_SOURCE '+str(path))
        if not dest.is_file():
            if path==ADAPTER:raise RuntimeError('MISSING_EXISTING_ADAPTER '+str(path))
            actions.append(('CREATE',path,None,modern,modern_sha))
            continue
        old=dest.read_bytes();got=sha_bytes(old)
        permitted={modern_sha}
        if path==FEATURE/'sv04_claude_auto60_core.h':permitted.update((PIN282_CORE,PATCHED_CORE))
        if path==FEATURE/'sv04_claude_eeprom_core.h':permitted.add(PATCHED_EEPROM)
        if path==ADAPTER:permitted.update((PIN282_ADAPTER,PIN289_ADAPTER,PATCHED_ADAPTER))
        if got not in permitted:raise RuntimeError('UNKNOWN_EXISTING_SOURCE_NOT_REPLACED '+str(path)+' sha256='+got)
        action='MIGRATE' if got!=modern_sha and got not in (PATCHED_CORE,PATCHED_ADAPTER,PATCHED_EEPROM) else 'KEEP'
        actions.append((action,path,old,modern,modern_sha))
    # Backup originals before replacement. No unpinned source is ever replaced.
    backups=root/BACKUP
    for action,path,old,new,target_sha in actions:
        if action!='MIGRATE':continue
        back=backups/(str(path).replace('/','__')+'.original')
        if back.exists():
            if back.read_bytes()!=old:raise RuntimeError('EXISTING_BACKUP_CONFLICT '+str(back))
        else:
            back.parent.mkdir(parents=True,exist_ok=True)
            with back.open('xb') as f:f.write(old)
            if back.read_bytes()!=old:raise RuntimeError('BACKUP_WRITE_MISMATCH '+str(back))
    for action,path,old,new,target_sha in actions:
        dest=root/path
        if action in ('CREATE','MIGRATE'):
            dest.parent.mkdir(parents=True,exist_ok=True)
            if action=='CREATE':
                with dest.open('xb') as f:f.write(new)
            else:
                temp=dest.with_name(dest.name+'.sv04next308.tmp')
                if temp.exists():raise RuntimeError('TEMP_PATH_ALREADY_EXISTS '+str(temp))
                with temp.open('xb') as f:f.write(new)
                os.replace(temp,dest)
            if sha(dest)!=target_sha:raise RuntimeError('MIGRATED_SHA_MISMATCH '+str(path))
        print('SV04_308',action,str(path),'sha256',sha(dest),flush=True)
    print('SV04_NEXT_308_MIGRATION=PASS',flush=True)
if __name__=='__main__':
    if len(sys.argv)!=2:sys.exit('usage: python ensure_282_to_287_308.py OEM_ROOT')
    migrate(sys.argv[1])
