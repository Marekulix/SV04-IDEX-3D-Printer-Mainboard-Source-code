# SV04 NEXT 308 – historische Quellstands-Luecke aus Run 307 repariert

**KEINE HARDWAREFREIGABE. Kein Flashen. Letzter erfolgreich kompilierter Stand: 291.**

## Nachgewiesener Fehler
Github Run 307 stoppte mit `UNKNOWN_EXISTING_HEADER_NOT_OVERWRITTEN sv04_claude_auto60_core.h sha256=5553a39a99...`. Dieser SHA gehoert exakt zum Auto60-Kern aus **Claude Stand 282**, enthalten im 277/284/291-Integrationsstamm. Der neuere Kern aus 285/287 (SHA `8792087b...`) wurde trotz des modernisierten lokalen 287-Test-Fixtures nicht in den echten OEM-Baum eingesetzt. Das erklaert, weshalb die Tests 306/307 bestanden und der echte Build vor dem Compiler scheiterte.

Der Adapter nach dem bisherigen 289-G29-CANCEL-V1-Installer hat laut den echten GitHub-Buildlogs 291 und 307 SHA `4e2da07a...`; die unmodifizierte 282-Vorlage hat SHA `0ff5576a...`. 308 erkennt **beide** gepinnten Altzustaende, ersetzt sie bewusst durch die auf Claude 285/287 basierenden Quellen, wendet danach **299** G29-Abbruch und die **292–306** EEPROM-/C2-Patches erneut an und prueft die erwarteten Marker. Die alte G29-Befehls-Schutzlogik in G29.cpp/Hooks wird nicht entfernt. Unbekannte Adapter- oder Corevarianten werden nicht veraendert.

## Sicherheitsdesign
`ensure_282_to_287_308.py` verifiziert VOR einer Migration **alle** vorhandenen Quell-SHAs. Quell-SHA nicht erkannt => kein Eingriff. Nur eine aus Claude C2/291/307 belegte alte Variante darf migriert werden. Vor Austausch werden die alten Quelldateien im OEM-Baum unter `.sv04_next_308_pre_migration` bytegenau gesichert. Der GitHub-Workflow kopiert diese Backups spaeter in `evidence/source_backups_308` und entfernt das Arbeitsbackup aus dem Buildbaum. Die Originalquellen 282 liegen ausserdem als Archiv-Fixture vor. Ein erneuter Integrationslauf veraendert den vollst. gepatchten Stand nicht.

## Lokal unabhaengig geprueft
- 10/10 neue Testfaelle, darunter der echte alte `5553...`-Core, fehlender EEPROM-Header, der 282-Adapter, idempotente Patchkette, Fremdquell-Abwehr und All-or-nothing-Vorabpruefung.
- 50/50 EEPROM-Kerntests (306/307) und 150/150 Koordinatortests bleiben im GitHub-Workflow enthalten.
- Die *Bytes* des nach 289-G29-CANCEL geaenderten Adapters mit SHA `4e2da...` sind lokal nicht vorhanden; dieser SHA wurde aus echten GitHub-Logs uebernommen. Die SHA-gepinnten 282- und 285/287-Quellen sind vorhanden und lokal getestet. Es ist deshalb noch **kein echter End-to-End-OEM- oder STM32-Build** nachgewiesen.

## Dateien auf GitHub
`A 308.zip` in die Repo-Wurzel, `B 308.yml` nach `.github/workflows/`; Dateinamen unveraendert. Workflow `308` starten. Bei jedem Fehler Ergebnis-Archiv `SV04_NEXT_308_BOTH_PROFILES_STM32_LOGS_NO_FLASH` zurueckgeben.
