#!/usr/bin/env python3
"""308: migrate exact historical 282/289 source states to 287, then integrate 306."""
import sys
from ensure_282_to_287_308 import migrate
from integrate_306 import main as integrate_306
if __name__=='__main__':
    if len(sys.argv)!=2:sys.exit('usage: integrate_308.py OEM_ROOT')
    migrate(sys.argv[1])
    integrate_306(sys.argv[1])
    print('SV04_NEXT_308_COMPOSITION=PASS')
