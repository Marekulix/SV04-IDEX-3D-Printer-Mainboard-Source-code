#include "SV04NextMarlinObserver232.hpp"
#include <assert.h>
#include <math.h>
#include <stdio.h>
static sv04next194::MeshState sample(float base){
 sv04next194::MeshState m={};
 for(unsigned x=0;x<4;x++)for(unsigned y=0;y<4;y++)m.z[x][y]=base+(x*4+y)*0.01f;
 for(unsigned i=0;i<2;i++){m.spacing[i]=30;m.start[i]=15;m.factor[i]=1.0f/30;}
 return m;
}
int main(){
 sv04next194::Session session; sv04next232::Observer obs;
 assert(!obs.frame() && !obs.may_transmit_to_dwin() && !obs.may_enable_leveling() && !obs.may_write_eeprom());
 auto previous=sample(-0.3f); auto id=session.begin(previous);obs.begin(id);
 assert(obs.snapshot() && !obs.snapshot()->mesh_confirmed);
 session.probing(id);obs.probing(id,session);
 assert(obs.snapshot()->state==sv04next221::Snapshot::Probing);
 sv04next194::Outcome o=sv04next194::OUT_NONE;
 auto current=sample(-0.7f);
 assert(session.complete(id,true,false,false,current,o)==sv04next194::DEC_KEEP);
 obs.finish(id,session);
 assert(obs.last_result()==sv04next231::Accepted && obs.snapshot()->mesh_confirmed);
 for(unsigned x=0;x<4;x++)for(unsigned y=0;y<4;y++)
   assert(obs.snapshot()->mesh[sv04next195::show_index(x,y)]==current.z[x][y]);
 // End of a later failed session may not show previously confirmed mesh.
 auto id2=session.begin(current);obs.begin(id2);assert(!obs.snapshot()->mesh_confirmed);
 session.probing(id2);obs.probing(id2,session);
 assert(session.abort(id2,o)==sv04next194::DEC_ROLLBACK);
 obs.finish(id2,session);
 assert(obs.snapshot()->state==sv04next221::Snapshot::Aborted && !obs.snapshot()->mesh_present);
 // No success without an authentic accepted event.
 auto id3=session.begin(previous);obs.begin(id3);
 obs.finish(id3,session);assert(obs.last_result()==sv04next231::RejectedState);
 assert(!obs.snapshot()->mesh_confirmed);
 // Invalid final mesh triggers errors, not stale data.
 session.probing(id3);obs.probing(id3,session);
 auto invalid=sample(0);invalid.z[3][3]=NAN;
 assert(session.complete(id3,true,false,false,invalid,o)==sv04next194::DEC_ROLLBACK);
 obs.finish(id3,session);
 assert(obs.snapshot()->state==sv04next221::Snapshot::Error && !obs.snapshot()->mesh_confirmed);
 assert(!obs.may_transmit_to_dwin() && !obs.may_enable_leveling() && !obs.may_write_eeprom());
 puts("SV04 NEXT 232 HOST PASS: success, session abort, stale invalidation, invalid mesh, no actuation");
}
