#!/usr/bin/env python3
"""SV04 NEXT 232: safely inject a read-only observer into *Claude-patched* LCD_RTS.cpp.
Source file is never edited. Output directory must not exist. Idempotent edits are refused.
"""
import sys, pathlib, hashlib

FLAG='#ifndef SV04NEXT_HMI_OBSERVER_232\n  #define SV04NEXT_HMI_OBSERVER_232 0\n#endif\n'
INCLUDE='#include "SV04NextMarlinObserver232.hpp"\n'
HOOK='#if SV04NEXT_HMI_OBSERVER_232\nstatic sv04next232::Observer sv04next232_observer;\n#endif\n'
def replace_once(text,old,new):
    if text.count(old)!=1: raise ValueError('unexpected Claude 194 anchor: '+old[:80])
    return text.replace(old,new,1)
def transform(src):
    if 'SV04NextMarlinObserver232.hpp' in src: raise ValueError('already patched')
    if 'static sv04next194::Session sv04next194_session;' not in src: raise ValueError('no session')
    src=replace_once(src,'#include "SV04NextDwinDisplay195.hpp"\n','#include "SV04NextDwinDisplay195.hpp"\n'+FLAG+'#if SV04NEXT_HMI_OBSERVER_232\n'+INCLUDE+'#endif\n')
    src=replace_once(src,'static sv04next194::Session sv04next194_session;','static sv04next194::Session sv04next194_session;\n'+HOOK)
    src=replace_once(src,'uint32_t SV04Next_G29Begin194() { sv04next194::MeshState s; sv04next194_capture(s); return sv04next194_session.begin(s); }',
'uint32_t SV04Next_G29Begin194() {\n  sv04next194::MeshState s; sv04next194_capture(s);\n  const uint32_t id=sv04next194_session.begin(s);\n  #if SV04NEXT_HMI_OBSERVER_232\n    sv04next232_observer.begin(id);\n  #endif\n  return id;\n}')
    src=replace_once(src,'void SV04Next_G29Probing194(const uint32_t id) { sv04next194_session.probing(id); }',
'void SV04Next_G29Probing194(const uint32_t id) {\n  sv04next194_session.probing(id);\n  #if SV04NEXT_HMI_OBSERVER_232\n    sv04next232_observer.probing(id, sv04next194_session);\n  #endif\n}')
    src=replace_once(src,'  sv04next194_apply(sv04next194_session.complete(id, successful, dryrun, faux, now, o));',
'  sv04next194_apply(sv04next194_session.complete(id, successful, dryrun, faux, now, o));\n  #if SV04NEXT_HMI_OBSERVER_232\n    sv04next232_observer.finish(id, sv04next194_session);\n  #endif')
    src=replace_once(src,'  sv04next194_apply(sv04next194_session.abort(id, o));',
'  sv04next194_apply(sv04next194_session.abort(id, o));\n  #if SV04NEXT_HMI_OBSERVER_232\n    sv04next232_observer.finish(id, sv04next194_session);\n  #endif')
    if src.count('sv04next232_observer.finish(id, sv04next194_session)') !=2: raise ValueError('missing exits')
    return src
if __name__=='__main__':
    if len(sys.argv)!=3: sys.exit('Usage: patch232.py INPUT_LCD_RTS.cpp OUTPUT_LCD_RTS.cpp')
    src=pathlib.Path(sys.argv[1]); dest=pathlib.Path(sys.argv[2])
    if dest.exists(): sys.exit('Refusing to overwrite output')
    try:
        output=transform(src.read_text())
    except ValueError as e: sys.exit(str(e))
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(output)
    print('INPUT SHA256', hashlib.sha256(src.read_bytes()).hexdigest())
    print('OUTPUT SHA256', hashlib.sha256(dest.read_bytes()).hexdigest())
