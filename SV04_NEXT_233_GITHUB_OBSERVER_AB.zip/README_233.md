# SV04 NEXT 233 – STM32 Observer A/B Audit

Prueft zwei Varianten derselben Claude-194/196-gepatchten OEM-Firmware:
- Observer=0 (aus), Claude-Schutzflags alle 0
- Observer=1 (an), Claude-Schutzflags alle 0

Ausgangspunkt: OEM-Commit 1867fcba75354a5c65e0631d6972dd19f1bd6cbe.
Der Workflow fuegt die 232-Hooks nicht im Repository ein, sondern nur in einem temporaren Clone. Die ZIP enthaelt die unveraenderten Claude-Patchwerkzeuge und die 232-Schnittstellen.

Konfiguration wird als #define am Anfang der beiden betroffenen TU explizit auf 0/1 gesetzt, um nicht von Umgebungsvariablen abzuhaengen. Die Firmware wird nur kompiliert, nicht als Artifact ausgegeben.

Hostregression des 232 Observer wird lokal in CI kompiliert. Keine Flashfreigabe.
