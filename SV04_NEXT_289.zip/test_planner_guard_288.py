#!/usr/bin/env python3
"""Executable C++ guard behavioral tests + patch-application regression tests."""
import tempfile,subprocess,sys, pathlib
from apply_planner_guard_288 import transform,ANCHOR,GUARD,PREFIX

# The original OEM signature and first statements are preserved in this fixture.
FIXTURE='''#include "../MarlinCore.h"\n#if HAS_LEVELING\n#include "../feature/bedlevel/bedlevel.h"\n#endif\n'''+PREFIX+'''\n  OPTARG(SCARA_FEEDRATE_SCALING, const_float_t inv_duration/*=0.0*/)\n) {\n'''+ANCHOR+'''\n  return buffer_segment(machine, fr_mm_s, extruder, millimeters);\n}\n'''

patched,changed=transform(FIXTURE)
assert changed and GUARD in patched
assert transform(patched)==(patched,False)
for altered in [FIXTURE.replace(ANCHOR,'  xyze_pos_t machine = cart;'),FIXTURE.replace(PREFIX,'bool Planner::buffer_segment(')]:
    try: transform(altered);raise AssertionError('Expected conflict fail')
    except ValueError:pass
assert patched.index('SV04 NEXT 288') < patched.index('xyze_pos_t machine = cart')
print('PATCH CHECKS: 5/5')

# Compile the exact C++ guard text inserted by transform, with a host harness.
# Tests verify both unchanged planner queue state and halt/diagnostics on invalid meshes.
cpp='''#include <cassert>\n#include <cstdio>\n#include <string>\nusing namespace std;\nstatic int killed=0, queued=0, errors=0;\nstatic bool leveling_active=false, mesh_valid=true;\nstatic bool leveling_is_valid(){return mesh_valid;}\nstatic void kill(const char *, void *, bool){++killed;}\n#define PSTR(x) x\n#define SERIAL_ERROR_MSG(x) (++errors)\n#define ENABLED(x) x\n#define AUTO_BED_LEVELING_BILINEAR LEVELING_CONFIG\nstatic bool enqueue() {\n'''+GUARD+'''  ++queued; return true;\n}\nint main(){\n for(int i=0;i<30;i++){\n  const int k=killed,q=queued,e=errors;\n  leveling_active=(i%3!=0); mesh_valid=(i%3!=2);\n  bool ok=enqueue();bool blocked=LEVELING_CONFIG && leveling_active&&!mesh_valid;\n  assert(ok==!blocked); assert(killed==k+(blocked?1:0));\n  assert(queued==q+(blocked?0:1)); assert(errors==e+(blocked?1:0));\n }\n printf("C++ GUARD EXECUTIONS: 30/30\\n");\n}\n'''
with tempfile.TemporaryDirectory() as d:
    src=pathlib.Path(d)/'test.cpp';binary=pathlib.Path(d)/'run';src.write_text(cpp)
    for level in (1,0):
        subprocess.run(['g++','-std=c++11','-Wall','-Wextra',f'-DLEVELING_CONFIG={level}',str(src),'-o',str(binary)],check=True)
        subprocess.run([str(binary)],check=True)
print('ALL LOCAL TESTS PASSED (2 configurations; 60 C++ scenarios)')
