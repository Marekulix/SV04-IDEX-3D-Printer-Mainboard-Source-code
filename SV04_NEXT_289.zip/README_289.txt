SV04 NEXT 289: build overlay for 287 + planner guard 288. Two STM32 profiles. No flash. 287.zip required in GitHub repository root.
