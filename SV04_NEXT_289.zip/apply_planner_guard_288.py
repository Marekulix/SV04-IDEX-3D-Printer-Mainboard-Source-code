#!/usr/bin/env python3
"""Apply SV04 NEXT 288 planner guard. Only touches Marlin/src/module/planner.cpp."""
from pathlib import Path
import argparse,hashlib,sys

ANCHOR = '''  xyze_pos_t machine = cart;
  TERN_(HAS_POSITION_MODIFIERS, apply_modifiers(machine));'''
GUARD = '''  // SV04 NEXT 288: refuse further queued motion if an active bilinear mesh
  // has become invalid. This runs in the normal planner enqueue path,
  // not the stepper ISR. Do NOT clear leveling_active directly: its
  // coordinate transforms must remain consistent until the emergency stop.
  #if ENABLED(AUTO_BED_LEVELING_BILINEAR)
    if (leveling_active && !leveling_is_valid()) {
      SERIAL_ERROR_MSG("SV04: invalid active mesh at planner enqueue");
      kill(PSTR("Invalid active mesh"), nullptr, true);
      return false;
    }
  #endif

'''
PREFIX='''bool Planner::buffer_line(const xyze_pos_t &cart, const_feedRate_t fr_mm_s, const uint8_t extruder/*=active_extruder*/, const float millimeters/*=0.0*/'''


def transform(source):
    if source.count(PREFIX) != 1 or source.count(ANCHOR) != 1:
        raise ValueError('Unexpected planner.cpp structure; refusing patch')
    if GUARD.strip() in source:
        return source, False
    # Avoid conflicting third-party guards inserted in the same narrow region.
    pos=source.index(ANCHOR)
    start=source.index(PREFIX)
    region=source[start:pos]
    if 'SV04 NEXT 288' in region or 'Invalid active mesh' in region:
        raise ValueError('Conflicting pre-existing guard detected')
    if '"../MarlinCore.h"' not in source or '"../feature/bedlevel/bedlevel.h"' not in source:
        raise ValueError('Required OEM error/leveling interfaces not found')
    return source[:pos]+GUARD+source[pos:], True

def main():
    p=argparse.ArgumentParser();p.add_argument('marlin_root',type=Path);a=p.parse_args()
    src=a.marlin_root/'Marlin/src/module/planner.cpp'
    original=src.read_text(encoding='utf-8')
    patched,changed=transform(original)
    if changed:src.write_text(patched,encoding='utf-8')
    print(('PATCHED' if changed else 'ALREADY_APPLIED'),str(src))
    print('SHA256',hashlib.sha256(patched.encode()).hexdigest())
if __name__=='__main__':main()
