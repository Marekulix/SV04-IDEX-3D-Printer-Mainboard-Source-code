import json, pathlib, sys, tempfile, unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from build105 import build

class DWIN105(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.src=pathlib.Path(self.temp.name)/'orig';self.src.mkdir()
        (self.src/'DWIN_SET').mkdir()
        (self.src/'DWprj.hmi').write_text('[INIT]\nSCREENDSIZE=272X480\nProVersion=642\n[IMG]\n0=0.jpg\n',encoding='utf8')
        (self.src/'DWIN_SET'/'13TouchFile.bin').write_bytes(b'\x0c'*1600+b'\xff\xff')
        (self.src/'DWIN_SET'/'14ShowFile.bin').write_bytes(b'\x14'*2400)
        self.out=pathlib.Path(self.temp.name)/'out'
    def test_source_assembly_preserves_original_binaries(self):
        report=build(self.src,self.out)
        self.assertFalse(report['new_binaries_compiled'])
        self.assertEqual((self.out/'SV04_DGUS_EDITOR_SOURCE'/'DWIN_SET'/'13TouchFile.bin').read_bytes(),(self.src/'DWIN_SET'/'13TouchFile.bin').read_bytes())
        self.assertIn('59=59.jpg',(self.out/'SV04_DGUS_EDITOR_SOURCE'/'DWprj.hmi').read_text())
        self.assertEqual(report['uncompiled_objects'],18)
    def test_existing_page_collision_refused(self):
        (self.src/'DWprj.hmi').write_text('[INIT]\nSCREENDSIZE=272X480\nProVersion=642\n[IMG]\n59=other.jpg\n')
        with self.assertRaisesRegex(RuntimeError,'occupied'):build(self.src,self.out)
    def test_wrong_geometry_refused(self):
        (self.src/'DWprj.hmi').write_text('[INIT]\nSCREENDSIZE=480X272\nProVersion=642\n[IMG]\n')
        with self.assertRaisesRegex(RuntimeError,'dimensions'):build(self.src,self.out)
    def test_missing_binary_refused(self):
        (self.src/'DWIN_SET'/'14ShowFile.bin').unlink()
        with self.assertRaisesRegex(RuntimeError,'Missing'):build(self.src,self.out)
    def test_wrong_terminator_refused(self):
        (self.src/'DWIN_SET'/'13TouchFile.bin').write_bytes(b'A'*2000)
        with self.assertRaisesRegex(RuntimeError,'terminator'):build(self.src,self.out)
if __name__=='__main__':unittest.main()
