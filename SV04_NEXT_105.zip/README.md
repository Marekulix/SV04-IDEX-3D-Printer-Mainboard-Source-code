# SV04 NEXT 105: Punkt 2 DWIN GitHub Untersuchung

Basiert auf dem tatsächlichen lokalen Quellstand SV04 NEXT 104. Lädt in GitHub Actions das öffentliche SV04-Touchscreen-Quellprojekt und ergänzt nur Seite 59 als Quellressource sowie die 18 editorseitig anzulegenden Objekte.

**Es gibt aktuell keinen nachgewiesenen kompatiblen DGUS-Compiler unter Linux.** Dieser Workflow kann und soll daher **keine installierbare Touchscreen-Firmware behaupten**. Die Originaldateien `13TouchFile.bin`, `14ShowFile.bin` werden unverändert bewahrt. Das Ergebnis ist ein zusammengeführtes HMI-Quellprojekt, ein ausführlicher Report und die klare Liste der noch nötigen Editor-Schritte.

Quelle: https://github.com/bphillips09/SV04-Touchscreen (öffentliche Fremdquelle, Hardware-/Versionskompatibilität noch nicht bestätigt).

Auf dem Android-Tablet `SV04_NEXT_105.zip` im Repository-Hauptordner, `105.yml` in `.github/workflows/` speichern, Workflow manuell starten. Danach `sv04next105-dwin-audit` und `sv04next105-dwin-source` hier hochladen.
