#!/usr/bin/env python3
"""Reproducible SV04 DGUS source-assembly and honest compiled-binary audit.

No undocumented edits to 13TouchFile.bin/14ShowFile.bin and no claim of DGUS compilation.
"""
import argparse, configparser, csv, hashlib, json, shutil, subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC_REPO = 'https://github.com/bphillips09/SV04-Touchscreen.git'

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def build(source: Path, out: Path):
    out.mkdir(parents=True,exist_ok=True)
    report={'project':'SV04 NEXT 105','source_repository':SRC_REPO,
            'status':'SOURCE_ASSEMBLY_ONLY_NOT_DGUS_COMPILED',
            'original_binaries_modified':False,'new_binaries_compiled':False,
            'display_installation_authorized':False}
    try:
        report['source_commit']=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True,stderr=subprocess.DEVNULL).strip()
    except Exception: report['source_commit']='unknown'
    hmi=source/'DWprj.hmi'
    if not hmi.is_file():raise RuntimeError('Original DGUS project DWprj.hmi missing')
    original=hmi.read_text('utf-8-sig')
    cfg=configparser.ConfigParser(interpolation=None);cfg.optionxform=str;cfg.read_string(original)
    if cfg.get('INIT','SCREENDSIZE')!='272X480':raise RuntimeError('Unexpected screen dimensions')
    if cfg.get('INIT','ProVersion')!='642':raise RuntimeError('Unrecognized DGUS project version')
    if cfg.has_option('IMG','59') and cfg.get('IMG','59')!='59.jpg':raise RuntimeError('Page 59 already occupied')
    dwin=source/'DWIN_SET'
    for name in ('13TouchFile.bin','14ShowFile.bin'):
        src=dwin/name
        if not src.is_file() or src.stat().st_size<1000: raise RuntimeError('Missing or LFS-pointer original DGUS binary: '+name)
        report[name]={'original_bytes':src.stat().st_size,'original_sha256':sha(src)}
    touch=(dwin/'13TouchFile.bin').read_bytes()
    if len(touch)<2 or touch[-2:]!=b'\xff\xff':raise RuntimeError('Unexpected touch binary terminator')
    # 13TouchFile is not fully decoded. A grep for 0x1300 cannot confirm availability.
    report['touch_address_1300_conflict_status']='UNKNOWN_UNTIL_DGUS_EDITOR_INSPECTION'
    report['mesh_touch_overlap_110e']='OEM address 0x110E is both 8th mesh VP and page key in Marlin; editor review required'
    obj=json.loads((ROOT/'overlay'/'OBJEKTE_104.json').read_text())
    numeric=[v for v in obj if v['object_type']=='Data Variable Display']
    touchobj=[v for v in obj if v['object_type']=='Return Key Code']
    if len(numeric)!=16 or len(touchobj)!=2: raise RuntimeError('Wrong object counts')
    if [v['vp'] for v in numeric]!=[f'0x{x:04X}' for x in range(0x1100,0x1120,2)]:raise RuntimeError('Wrong OEM mesh VPs')
    if [v['grid_col'] for v in numeric]!=[3,2,1,0,0,1,2,3,3,2,1,0,0,1,2,3]:raise RuntimeError('Wrong zigzag mapping')
    if [v['vp'] for v in touchobj]!=['0x1300','0x1302']:raise RuntimeError('Wrong proposed touch VPs')
    overlay=out/'SV04_DGUS_EDITOR_SOURCE'
    shutil.copytree(source,overlay,ignore=shutil.ignore_patterns('.git','.github','__pycache__'))
    image=ROOT/'overlay'/'59.jpg'
    if image.read_bytes()[:2]!=b'\xff\xd8':raise RuntimeError('Page 59 must be a JPEG')
    # Image asset in project root and in DWIN_SET. Copying the image does not
    # change page control binaries: the DGUS editor must regenerate those.
    shutil.copy2(image,overlay/'59.jpg')
    shutil.copy2(image,overlay/'DWIN_SET'/'59.jpg')
    if not cfg.has_option('IMG','59'):
        original=original.rstrip()+ '\n59=59.jpg\n'
    (overlay/'DWprj.hmi').write_text(original,encoding='utf-8')
    for n in ('OBJEKTE_104.json','OBJEKTE_104.csv'):
        shutil.copy2(ROOT/'overlay'/n,overlay/n)
    # Audit that the original compiled object files are byte-for-byte unchanged.
    for name in ('13TouchFile.bin','14ShowFile.bin'):
        p=overlay/'DWIN_SET'/name
        if sha(p)!=report[name]['original_sha256']: raise RuntimeError('Original DGUS binary unexpectedly modified')
    report['new_page_59_source_present']=True
    report['object_definitions']={'numeric_displays':len(numeric),'touch_regions':len(touchobj)}
    report['uncompiled_objects']=len(obj)
    report['next_required']='Import/edit DGUS project in compatible DGUS editor; generate 13TouchFile.bin and 14ShowFile.bin; inspect TP conflicts and test display'
    (out/'AUDIT_105.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (out/'EDITIERANLEITUNG_105.md').write_text('''# SV04 NEXT 105, DWIN-Punkt 2\n\nDas Quellprojekt enthält die neue Grafik 59.jpg und OBJEKTE_104.csv/json. Die 18 Objekte sind **nicht** in den bestehenden DGUS-Binärdateien hinterlegt. Im kompatiblen DGUS-Editor die 16 Anzeigen für Seite 59 und 2 Touchobjekte nach Objektliste hinzufügen. Vor Freigabe aktive VP-Belegung prüfen, insbesondere 0x110E und 0x1300. Anschließend erst DGUS-Binärdateien neu kompilieren und am identifizierten SV04-Touchscreen testen.\n\n**NICHT installieren:** Die vorhandenen 13TouchFile.bin/14ShowFile.bin sind absichtlich unveränderte Originale.\n''',encoding='utf-8')
    return report

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,required=True);ap.add_argument('--out',type=Path,required=True)
    a=ap.parse_args();print(json.dumps(build(a.source,a.out),ensure_ascii=False,indent=2))
