"""Fuzz der Auto60-Zustandsmaschine (Host, Simulation). Kompiliert tests/fuzz_auto60_engine.cpp, laeuft mit mehreren Seeds in beiden Modi, prueft Abdeckung und die EMPFINDLICHKEIT des Tests per injizierter Fehler in Kopien der Maschine."""
import re, subprocess, sys, tempfile, shutil
from pathlib import Path
root = Path(__file__).resolve().parents[1]; n = [0]
def ck(c, m=''): assert c, m; n[0] += 1
src = (root / 'include/SV04NextAuto60Engine.hpp').read_text(encoding='utf-8'); g28 = (root / 'include/SV04NextG28PassiveReceipt.hpp').read_text(encoding='utf-8'); g29 = (root / 'include/SV04NextG29UReceipt.hpp').read_text(encoding='utf-8')
cnt = lambda txt, name: len([x for x in re.sub(r'\s+', ' ', re.search(r'enum class ' + name + r' : uint8_t \{(.*?)\};', txt, re.S).group(1)).split(',') if x.strip()])
G28N, G29N = cnt(g28, 'Phase'), cnt(g29, 'Failure'); reasons = [x.strip() for x in re.sub(r'\s+', ' ', re.search(r'enum class Reason : uint8_t \{(.*?)\};', src, re.S).group(1)).split(',') if x.strip()]
cpp = (root / 'tests/fuzz_auto60_engine.cpp').read_text(encoding='utf-8'); ck(int(re.search(r'#define G28_PHASES (\d+)', cpp).group(1)) == G28N and int(re.search(r'#define G29_FAILURES (\d+)', cpp).group(1)) == G29N, 'Standardwerte der Fuzz-Makros weichen von den echten Enum-Groessen ab')
def build(tree: Path, out: Path):
    r = subprocess.run(['g++', '-std=c++11', '-O2', '-Wall', '-Wextra', '-Werror', '-pedantic', f'-DG28_PHASES={G28N}', f'-DG29_FAILURES={G29N}', str(tree / 'tests/fuzz_auto60_engine.cpp'), '-o', str(out)], capture_output=True, text=True); return r
def run(exe, seed, mode, steps=300000):
    r = subprocess.run([str(exe), str(seed), str(mode), str(steps)], capture_output=True, text=True); return r.returncode, r.stdout
d = Path(tempfile.mkdtemp()); r = build(root, d / 'fz'); ck(r.returncode == 0, r.stderr[:400])
cov_states = [0] * 15; cov_reasons = [0] * 64; tot = {'runs': 0, 'done': 0, 'doneram': 0}
for mode in (0, 1, 2):
    for seed in range(1, 9):
        rc, out = run(d / 'fz', seed, mode); ck(rc == 0, f'seed {seed} modus {mode}: {out[:400]}')
        m = re.search(r'(\d+) Laeufe, Done (\d+), DoneRamOnly (\d+)', out)
        if mode in (0, 2): tot['runs'] += int(m.group(1)); tot['done'] += int(m.group(2)); tot['doneram'] += int(m.group(3))
        for i, v in enumerate(re.search(r'ZUSTAENDE ([\d ]+)', out).group(1).split()): cov_states[i] += int(v)
        for i, v in enumerate(re.search(r'GRUENDE ([\d ]+)', out).group(1).split()): cov_reasons[i] += int(v)
ck(all(c > 0 for i, c in enumerate(cov_states) if i != 1), f'nicht jeder Zustand erreicht (StartRequested ist nach tick() nie sichtbar): {cov_states}'); ck(tot['done'] > 50 and tot['doneram'] > 200, f'zu wenige erfolgreiche Laeufe, Fuzz waere leer: {tot}')
miss = [reasons[i] for i in range(len(reasons)) if cov_reasons[i] == 0]; ck(set(miss) <= {'None'}, f'Abbruchgruende ohne Treffer (ausser None): {miss}')
ck(all(x in reasons for x in ('UserAbort', 'Stopped', 'ObservationInvalid', 'TempOvershoot')) and not any(x in miss for x in ('UserAbort', 'Stopped', 'ObservationInvalid', 'TempOvershoot')), f'Kerngruende ohne Treffer: {miss}')
# --- Empfindlichkeit: bekannte Fehler in Kopien der Maschine muessen entdeckt werden
BUGS = [
 ('abort_ schaltet den Heizer nicht aus', 'return heater_off_action(); }\n  Action heater_off_action()', 'return Action::None; }\n  Action heater_off_action()'),
 ('Messen ohne elektrische T1-Bestaetigung', "if (!o.t1_parked_electrically) return abort_(Reason::Precondition);", "if (false) return abort_(Reason::Precondition);"),
 ('Commit ohne Quittung', 'if (cfg_.auto_commit || o.user_ack) {', 'if (true) {'),
 ('Commit ohne Unterstuetzung', 'if (!o.eeprom_commit_supported) return finish(State::DoneRamOnly, Reason::CommitNotAvailable);', ''),
 ('Stopp wird ignoriert', 'if (o.stopped) return abort_(Reason::Stopped);', ''),
 ('Nutzerabbruch wird ignoriert', 'if (o.user_abort) return abort_(Reason::UserAbort);', ''),
 ('Home ohne Soll 60', 'if (!o.thermal_safe || o.bed_target_c != 60.0f) return abort_(Reason::TempLost);\n        if (o.g28_seq == home_seq_', 'if (o.g28_seq == home_seq_'),
 ('ActionFailed wird ignoriert', "if (fail_pending_) { fail_pending_ = false; if (active(state_)) return abort_(Reason::ActionFailed); }", "if (fail_pending_) { fail_pending_ = false; }"),
 ('Messen bei verstelltem Z-Offset', "if (ABSF(o.probe_offset_z - z0_) > 0.00001f) return abort_(Reason::OffsetChanged);\n        meas_seq_ = o.g29_seq;", "meas_seq_ = o.g29_seq;"),
 ('Heizung ohne Wirkung wird nicht erkannt', "else if (elapsed() > cfg_.target_apply_ms) return abort_(Reason::HeatTargetNotApplied);", "else if (false) return abort_(Reason::HeatTargetNotApplied);"),
 ('Fortschritt nicht begrenzt (Befund dieser Runde)', 'progress_ = o.g29_completed > 16 ? 16 : o.g29_completed;', 'progress_ = o.g29_completed;'),
]
caught = 0; present = 0
for name, old, new in BUGS:
    if src.count(old) < 1: continue           # z. B. Fortschrittsbegrenzung noch nicht vorhanden: dann ist die Fassung ohnehin die "fehlerhafte"
    present += 1; t = d / ('m%d' % present); (t / 'include').mkdir(parents=True); (t / 'tests').mkdir()
    for f in (root / 'include').glob('*.hpp'): shutil.copy(f, t / 'include' / f.name)
    shutil.copy(root / 'tests/fuzz_auto60_engine.cpp', t / 'tests/fuzz_auto60_engine.cpp'); h = t / 'include/SV04NextAuto60Engine.hpp'; h.write_text(h.read_text(encoding='utf-8').replace(old, new, 1), encoding='utf-8')
    r = build(t, t / 'fz'); ck(r.returncode == 0, f'{name}: Mutant kompiliert nicht: {r.stderr[:200]}'); hit = any(run(t / 'fz', s, m, 200000)[0] != 0 for m in (2, 0, 1) for s in (1, 2, 3, 4)); ck(hit, f'Fuzz erkennt den Fehler NICHT: {name}'); caught += hit
print(f'PASS Fuzz Auto60-Maschine: {n[0]} Pruefungen (24 Laeufe x 300000 Schritte in drei Modi, alle 15 Zustaende erreicht, {tot["done"]} Done / {tot["doneram"]} DoneRamOnly, {len(reasons) - len(miss)}/{len(reasons)} Abbruchgruende getroffen; ohne Treffer: {missing_label}; {caught}/{present} injizierte Fehler entdeckt); Simulation, KEIN Geraet')
