# T1-/X_MAX-Belegmatrix (maschinell aus den ECHTEN Quellen, `tools/endstop_evidence.py`)

Strikte Trennung: **Quellenbeleg** = im echten Quelltext gefunden (Datei:Zeile); **Annahme** = folgt NICHT aus den vorhandenen Quellen; **HIL** = nur am Geraet klaerbar. **Kein Punkt dieser Tabelle ist eine Kollisionssicherheitsgarantie.**

| Aussage | Quellenbeleg | Annahme (nicht belegt) | HIL |
|---|---|---|---|
| Platinentyp laut Konfiguration | Configuration.h:146 | Die Konfiguration waehlt BOARD_CREALITY_V4 (nicht V5.2.1); die zugehoerige Pinbelegung (pins_CREALITY_V4.h) liegt NICHT vor. | Platine und Aufdruck am Geraet pruefen |
| X_MAX-Schalter ist aktiviert | Configuration.h:790 | Dass der Pin existiert (PIN_EXISTS(X_MAX)) haengt von der Pinbelegung ab; in CI 18 wurde der Ausdruck mit PIN_EXISTS(X_MAX) in LCD_RTS.cpp kompiliert, also ist X_MAX_PIN dort gesetzt (siehe Probe: X_MAX_PIN vorhanden). | Pinnummer gegen Schaltplan |
| Polaritaet: gedrueckt = Pegel LOW (INVERTING=true) | Configuration.h:843 | Marlins Endstops::update bildet ausgeloest als READ(pin) != INVERTING; endstops.cpp liegt NICHT vor (nur endstops.h). Annahme aus Marlin-Standardverhalten. | Pegel am Pin messen: gedrueckt/losgelassen |
| Pull-up aktiv (offener Kontakt = HIGH = nicht ausgeloest) | Configuration.h:798 | Dass Endstops::init() daraus SET_INPUT_PULLUP macht, steht in endstops.cpp (nicht vorhanden); Marlin-Standard. Daraus folgt (Annahme): Kabelbruch liest HIGH = NICHT ausgeloest -> Pruefung verweigert. | Kabel abziehen und Pegel lesen (ohne Bewegung) |
| T0 referenziert nach links (X_MIN) | Configuration.h:1367 | T1 referenziert nach rechts; X2_HOME_DIR steht in Configuration_adv.h bzw. wird von Marlin fuer DXC gesetzt (hier nicht gefunden). | Referenzfahrt beobachten (ohne Automatik) |
| Soft-Endstops von T0: bei save_dual_x_carriage_mode 1 oder 4 bis dual_max_x (X2_MAX_POS=362) | motion.cpp:718; motion.cpp:723 | Die genaue Zuordnung der Modi 1/4 zu Sovols save_dual_x_carriage_mode ist OEM-spezifisch; der Quelltext zeigt nur den Vergleich. | Modus am Geraet auslesen (M-Befehl ohne Bewegung) |
| Anfangswert inactive_extruder_x = X2_MAX_POS (schon vor der Referenzfahrt) | motion.cpp:1120 | Die Buchfuehrung beweist daher nichts ueber die physische Lage. | - |
| hotend_offset[1].x = MAX(X2_HOME_POS, X2_MAX_POS) | motion.cpp:133 | - | - |
| G28: T1 (X2) wird vor T0 referenziert, T1 bleibt auf dem Schalter (kein Rueckzug) | G28.cpp:399; Configuration_adv.h:792 | Kein Post-Homing-Backoff laut Configuration_adv.h (auskommentiert); ob die OEM-G28 intern doch zurueckfaehrt: aus dem G28-Text nicht ersichtlich (kein Backoff-Aufruf gefunden). | Schalterpegel nach G28 lesen |
| endstops.h kennt X2_MIN/X2_MAX als getrennte Eintraege (HAS_X2_MIN/HAS_X2_MAX) | endstops.h:51 | Ob diese Platine einen EIGENEN X2-Endstop-Pin hat (dann waere X_MAX nicht der Schalter von T1!), entscheidet die Pinbelegung (nicht vorhanden). v17 nimmt an: X_MAX_PIN ist der Schalter von T1. | KRITISCH: Verdrahtung pruefen, welcher Schalter T1 ausloest |
| X_MAX ist EIN Schalter fuer BEIDE Schlitten (T0 kann ihn bei Modus 1/4 bei 362 beruehren) | motion.cpp:723 | Deshalb Stand 17: zusaetzlich gefuehrte T0-X <= X_MAX_POS (NaN verweigert). Auch das ist Buchfuehrung, aber unabhaengig vom Schalter. | Mechanisch: kann T0 den Schalter erreichen? |

## Fehlende Quellen (der naechste Lauf von Workflow 19 sammelt sie, sobald die Sammelliste sie enthaelt)

- Marlin/src/module/endstops.cpp (Endstops::update, init, DXC-Zuordnung)
- Marlin/src/pins/stm32f1/pins_CREALITY_V4.h (X_MAX_PIN, X2_*_PIN, EEPROM-Typ)
- Marlin/src/HAL/STM32F1/fastio.h (READ)
