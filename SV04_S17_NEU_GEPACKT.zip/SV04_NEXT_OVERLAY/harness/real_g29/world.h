// WELT fuer die AUSFUEHRUNG des ECHTEN, GEPATCHTEN G29.cpp (bilinearer Zweig). Nachbildung, KEIN Marlin: Typen, Funktionen und ein Fake-Geraet (Sonde, Temperatur, Zeit).
#pragma once
#include <deque>
#include <string>
#include <vector>
#include <functional>
#include <map>
#include <string.h>
#include <stdlib.h>
#define GRID_MAX_POINTS (GRID_MAX_POINTS_X * GRID_MAX_POINTS_Y)
#define G29_TYPE void
#define STRINGIFY(x) #x
#define WITHIN(N, L, H) ((N) >= (L) && (N) <= (H))
#define LIMIT(v, n, x) ((v) = (v) < (n) ? (n) : ((v) > (x) ? (x) : (v)))
#define _MAX(a, b) ((a) > (b) ? (a) : (b))
#define MMM_TO_MMS(x) ((x) / 60.0f)
#define XY_PROBE_FEEDRATE 4000
#define X_CENTER 151.0f
#define Y_CENTER 151.0f
#define Z_CLEARANCE_DEPLOY_PROBE 10
#define RAW_X_POSITION(v) (v)
#define RAW_Y_POSITION(v) (v)
#define RAW_Z_POSITION(v) (v)
#define G28_STR "G28"
#define DEBUGGING(x) (false)
#define DEBUG_SECTION(...) do {} while (0)
#define DEBUG_ECHOLNPGM(...) do {} while (0)
#define DEBUG_ECHOPGM(...) do {} while (0)
#define DEBUG_ECHOLNPGM_P(...) do {} while (0)
#define DEBUG_POS(...) do {} while (0)
#define SERIAL_ECHOPGM(...) do {} while (0)
#define SERIAL_EOL() do {} while (0)
struct xy_float_t { float x, y; xy_float_t() : x(0), y(0) {} xy_float_t(float a, float b) : x(a), y(b) {} void set(float a, float b) { x = a; y = b; } };
typedef xy_float_t xy_pos_t;
inline bool operator!=(const xy_float_t &a, const xy_float_t &b) { return a.x != b.x || a.y != b.y; }
inline bool operator==(const xy_float_t &a, const xy_float_t &b) { return !(a != b); }
inline xy_float_t operator*(const xy_float_t &a, const xy_float_t &b) { return xy_float_t(a.x * b.x, a.y * b.y); }
inline xy_float_t operator+(const xy_float_t &a, const xy_float_t &b) { return xy_float_t(a.x + b.x, a.y + b.y); }
struct xy_int8_t { int8_t x, y; xy_float_t asFloat() const { return xy_float_t((float)x, (float)y); } };
struct xy_uint8_t { uint8_t x, y; };
struct xyz_pos_t { float x, y, z; };
struct xyze_pos_t { float x, y, z, e; void set(float a, float b) { x = a; y = b; } };
extern xyze_pos_t current_position;
enum ProbePtRaise : uint8_t { PROBE_PT_NONE, PROBE_PT_STOW, PROBE_PT_RAISE, PROBE_PT_BIG_RAISE };
enum DualXMode : char { DXC_FULL_CONTROL_MODE = 0, DXC_AUTO_PARK_MODE = 1, DXC_DUPLICATION_MODE = 2, DXC_MIRRORED_MODE = 3 };
typedef float bed_mesh_t[GRID_MAX_POINTS_X][GRID_MAX_POINTS_Y];
// ---------------------------------------------------------------- Fake-Geraet
struct World {
  std::string parser_letters; bool stopped = false, printing = false, paused = false, blocks = false, homing_needed = false; bool trusted[3] = {true, true, true};
  int target = 60; float bed = 60.0f; uint32_t now_ms = 100000; int sync_calls = 0, probe_calls = 0, eeprom_saves = 0, levelling_toggles = 0, refresh_calls = 0, reset_calls = 0, rts_sends = 0, rts_pages = 0, rts_icon_zero = 0, progress_msgs = 0, restore_msgs = 0, errors = 0, idle_calls = 0;
  float rts_vals[16]; int rts_seen = 0; std::vector<std::string> log; std::vector<float> probe_script; std::vector<xy_pos_t> call_pos;
  std::function<void(int)> before_probe, on_progress; float g29_z_param = 0; std::map<int, float> ovr; bool xmax_triggered = true;   // Stand 16: elektrischer Pegel des X_MAX-Schalters von T1 (gedrueckt = geparkt)
};
extern World w;
#define X_MAX_PIN 1
#define X_MAX_ENDSTOP_INVERTING true
#define READ(p) ((w.xmax_triggered) != (X_MAX_ENDSTOP_INVERTING))   // roher Pin-Pegel; Overlay vergleicht mit X_MAX_ENDSTOP_INVERTING
extern uint8_t active_extruder; extern DualXMode dual_x_carriage_mode; extern float inactive_extruder_x;
extern bed_mesh_t z_values; extern xy_pos_t bilinear_start, bilinear_grid_spacing; extern float xy_probe_feedrate_mm_s;
unsigned long millis(void); inline long random(long a, long) { return a; }
inline bool axis_is_trusted(const AxisEnum a) { return w.trusted[a]; }
#define X2_MAX_POS 362
#define X_MAX_POS 302   // Configuration.h: X_MAX_POS = X_BED_SIZE = 302
inline bool IsStopped() { return w.stopped; } inline bool printJobOngoing() { return w.printing; } inline bool printingIsPaused() { return w.paused; }
struct Temperature { static celsius_float_t degBed() { return w.bed; } static celsius_t degTargetBed() { return (celsius_t)w.target; } static void setTargetBed(const celsius_t c) { w.target = c; } }; extern Temperature thermalManager;
struct Planner { static bool leveling_active; static bool has_blocks_queued() { return w.blocks; } static void synchronize() {} static float fade_scaling_factor_for_z(float) { return 1.0f; } }; extern Planner planner;
struct Probe { static xyz_pos_t offset; static float probe_at_point(const xy_pos_t &pos, const ProbePtRaise raise_after = PROBE_PT_NONE, const uint8_t verbose_level = 0, const bool probe_relative = true, const bool sanity_check = true);
  static float min_x() { return 25; } static float max_x() { return 277; } static float min_y() { return 25; } static float max_y() { return 277; } static bool good_bounds(const xy_pos_t &, const xy_pos_t &) { return true; } static bool deploy() { return false; } static bool stow() { return false; } static void move_z_after_probing() {} }; extern Probe probe;
struct GCodeParser { static bool seen_test(const char c) { return w.parser_letters.find(c) != std::string::npos; } static bool seen(const char c) { return seen_test(c); } static bool boolval(const char c, const bool d = false) { return seen_test(c) ? true : d; }
  static int intval(const char, const int d = 0) { return d; } static uint8_t byteval(const char, const uint8_t d = 0) { return d; } static bool seenval(const char) { return false; } static float linearval(const char c, const float d = 0) { return c == 'Z' ? w.g29_z_param : d; } static float value_linear_units() { return 0; } static int value_int() { return 0; } }; extern GCodeParser parser;
struct RTSSHOW { void RTS_SndData(float v, unsigned long vp, unsigned char = 0x82) { ++w.rts_sends; if (vp == 0x108D && v == 0) ++w.rts_icon_zero; long i = ((long)vp - 0x1100) / 2; if (vp >= 0x1100 && i >= 0 && i < 16) { w.rts_vals[i] = v; ++w.rts_seen; } }
  void RTS_SndData(int v, unsigned long vp, unsigned char b = 0x82) { RTS_SndData((float)v, vp, b); } void RTS_SndData(unsigned long v, unsigned long vp, unsigned char b = 0x82) { RTS_SndData((float)v, vp, b); } void RTS_SndData(unsigned char v, unsigned long vp, unsigned char b = 0x82) { RTS_SndData((float)v, vp, b); } }; extern RTSSHOW rtscheck;
#define AUTO_BED_LEVEL_ICON_VP 0x108D
#define AUTO_BED_LEVEL_1POINT_VP 0x1100
inline void RTS_AutoBedLevelPage() { ++w.rts_pages; }
inline void extrapolate_unprobed_bed_level() {} inline void print_bilinear_leveling_grid() {}
// vereinfachtes Modell der echten Bilinearinterpolation (abl.cpp): Zelle begrenzen, Verhaeltnis NICHT begrenzen (Extrapolation), NAN pflanzt sich fort
inline float bilinear_z_offset(const xyze_pos_t &p) { const float fx = (p.x - bilinear_start.x) / bilinear_grid_spacing.x, fy = (p.y - bilinear_start.y) / bilinear_grid_spacing.y; int cx = (int)floorf(fx), cy = (int)floorf(fy);
  if (cx < 0) cx = 0; if (cx > GRID_MAX_POINTS_X - 2) cx = GRID_MAX_POINTS_X - 2; if (cy < 0) cy = 0; if (cy > GRID_MAX_POINTS_Y - 2) cy = GRID_MAX_POINTS_Y - 2; const float rx = fx - cx, ry = fy - cy;
  const float z11 = z_values[cx][cy], z21 = z_values[cx + 1][cy], z12 = z_values[cx][cy + 1], z22 = z_values[cx + 1][cy + 1]; return z11 + (z21 - z11) * rx + (z12 - z11) * ry + (z11 - z21 - z12 + z22) * rx * ry; }
// --- Semantik wie im ECHTEN bedlevel.cpp (Zeilen 49 bis 121, 123 bis 139): leveling_is_valid() = !!bilinear_grid_spacing.x; set_bed_leveling_enabled(true) tut OHNE gueltiges Raster NICHTS;
// reset_bed_level() schaltet das Leveling aus, setzt Raster-Start und -Abstand auf 0 und das Mesh auf NAN.
inline bool leveling_is_valid() { return !!bilinear_grid_spacing.x; }
inline void set_bed_leveling_enabled(const bool e = true) { const bool can_change = !e || leveling_is_valid(); if (can_change && e != Planner::leveling_active) {
    if (Planner::leveling_active) { current_position.z += bilinear_z_offset(current_position); Planner::leveling_active = false; }   // an -> aus: apply_leveling (logisch -> physisch), danach erst deaktivieren
    else { Planner::leveling_active = true; current_position.z -= bilinear_z_offset(current_position); }                                    // aus -> an: erst aktivieren, dann unapply_leveling (physisch -> logisch) mit dem AKTUELLEN Mesh
    ++w.levelling_toggles; ++w.sync_calls; } }
inline void reset_bed_level() { ++w.reset_calls; set_bed_leveling_enabled(false); bilinear_start.set(0, 0); bilinear_grid_spacing.set(0, 0); for (int x = 0; x < GRID_MAX_POINTS_X; ++x) for (int y = 0; y < GRID_MAX_POINTS_Y; ++y) z_values[x][y] = NAN; }
inline void refresh_bed_level() { ++w.refresh_calls; }
inline void sync_plan_position() {} inline void report_current_position() {} inline bool homing_needed_error() { return w.homing_needed; } inline void do_z_clearance(float) {} inline void tool_change(uint8_t, bool = false) {}
inline void remember_feedrate_scaling_off() {} inline void restore_feedrate_and_scaling() {} inline void reset_stepper_timeout() {} inline void process_subcommands_now_P(const char *) {} 
inline void idle_no_sleep() { w.now_ms += 20; ++w.idle_calls; }
inline void sv_log(const char *m) { w.log.push_back(m); ++w.errors; }
#define SERIAL_ERROR_MSG(m) do { sv_log(m); if (strstr(m, "restored")) ++w.restore_msgs; } while (0)
template <class... A> void sv_echo(const char *m, A...) { w.log.push_back(m); if (strstr(m, "PROGRESS")) { ++w.progress_msgs; if (w.on_progress) w.on_progress(w.progress_msgs - 1); } }
#undef SERIAL_ECHOLNPGM
#define SERIAL_ECHOLNPGM(...) sv_echo(__VA_ARGS__)
constexpr bool g29_in_progress = false;   // wie im echten bedlevel.h ohne PROBE_MANUALLY
class GcodeSuite { public: static void G28(); static G29_TYPE G29(); };
