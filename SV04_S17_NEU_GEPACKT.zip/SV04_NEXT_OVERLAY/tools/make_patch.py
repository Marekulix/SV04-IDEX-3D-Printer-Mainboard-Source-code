#!/usr/bin/env python3
"""Erzeugt aus den ECHTEN OEM-Dateien und der Patchkette v17 EINEN git-anwendbaren Patch (patches/0001-sv04next-overlay.patch): 3 geaenderte OEM-Dateien + neue Header als neue Dateien.
Ziel (P4.15): offen versionierte, pruefbare Quellaenderung statt eingebettetem Code. Der Patch ist NUR fuer exakt diesen OEM-Stand (Git-Blob-SHA1 der 5 Dateien) anwendbar; sonst schlaegt `git apply --check` fehl.
Aufruf: python3 tools/make_patch.py --oem-root tests/oem_real --out patches/0001-sv04next-overlay.patch"""
import argparse, os, shutil, subprocess, sys, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path[:0] = [str(ROOT / 'integration')]
import apply_native_guard_v17 as v17


def make(oem_root: Path) -> str:
    v14 = v17.v15.v14; orig = {n: (oem_root / n).read_text(encoding='utf-8') for n in v14.OEM_BLOBS}; heads = [(ROOT / 'include' / h).read_text(encoding='utf-8') for h in v17.HEADERS]; out = v17.render(dict(orig), *heads)
    d = Path(tempfile.mkdtemp()); run = lambda *a: subprocess.run(['git', '-c', 'user.email=t@t', '-c', 'user.name=t', '-c', 'core.autocrlf=false', '-c', 'core.safecrlf=false', *a], cwd=d, capture_output=True, text=True, check=True)
    run('init', '-q')
    for n, t in orig.items(): p = d / n; p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(t.encode('utf-8'))
    run('add', '-A'); run('commit', '-q', '-m', 'OEM')
    for n, t in out.items(): p = d / n; p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(t.encode('utf-8'))
    run('add', '-A'); patch = run('diff', '--cached', '--binary', '--no-color', '--full-index').stdout; shutil.rmtree(d, ignore_errors=True); return patch


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--oem-root', type=Path, default=ROOT / 'tests/oem_real'); ap.add_argument('--out', type=Path, default=ROOT / 'patches/0001-sv04next-overlay.patch'); a = ap.parse_args()
    p = make(a.oem_root); a.out.parent.mkdir(parents=True, exist_ok=True); a.out.write_bytes(p.encode('utf-8')); print(f'{a.out}: {len(p.splitlines())} Zeilen'); return 0


if __name__ == '__main__': sys.exit(main())
