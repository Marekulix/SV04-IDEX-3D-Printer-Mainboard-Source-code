#!/usr/bin/env python3
"""Mutationstest des A/B-Slot-Entwurfs: welche Schutzmechanismen sind TRAGEND (Mutant wird erkannt) und welche aequivalent/redundant (Mutant ueberlebt)."""
import os, shutil, subprocess, tempfile
from concurrent.futures import ThreadPoolExecutor
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..')); H = 'design/SV04NextMeshSlots.hpp'
M = [
 ('Z01', 'CRC wird beim Laden nicht geprueft', "    if (crc32(tmp, kSlot) != h.crc) return false;\n", ""),
 ('Z02', 'es wird der AKTUELL GUELTIGE Slot ueberschrieben (kein A/B-Wechsel)', "const int target = cur < 0 ? 0 : 1 - cur;", "const int target = cur < 0 ? 0 : cur;"),
 ('Z03', 'Folgenummer ohne Ueberlauf verglichen', "return (int32_t)(a - b) > 0; }", "return a > b; }"),
 ('Z04', 'Versionspruefung entfernt', "h.version != kVersion || ", ""),
 ('Z05', 'Rastergroessenpruefung entfernt', "h.gx != kGridX || h.gy != kGridY || ", ""),
 ('Z06', 'Magic-Pruefung entfernt', "h.magic != kMagic || ", ""),
 ('Z07', 'Kopf ZUERST, Nutzdaten danach (Reihenfolge)', "    for (uint16_t i = kHeader; i < kSlot; ++i) if (!dev.write(a + i, buf[i])) return false;      // zuerst die Nutzdaten\n    for (uint16_t i = 0; i < kHeader; ++i) if (!dev.write(a + i, buf[i])) return false;           // ZULETZT der Kopf\n",
  "    for (uint16_t i = 0; i < kHeader; ++i) if (!dev.write(a + i, buf[i])) return false;\n    for (uint16_t i = kHeader; i < kSlot; ++i) if (!dev.write(a + i, buf[i])) return false;\n"),
 ('Z08', 'Gegenwert der Folgenummer (seq_inv) nicht geprueft', " || h.seq != (uint32_t)~h.seq_inv", ""),
 ('Z09', 'Laengenpruefung entfernt', " || h.len != kPayload", ""),
 ('Z10', 'beim Laden immer Slot 0 statt des neuesten', "int newest(uint32_t &seq) const { uint32_t sa = 0, sb = 0; const bool a = valid(0, sa), b = valid(1, sb); if (a && b) { if (newer(sa, sb)) { seq = sa; return 0; } seq = sb; return 1; }", "int newest(uint32_t &seq) const { uint32_t sa = 0, sb = 0; const bool a = valid(0, sa), b = valid(1, sb); if (a && b) { seq = sa; return 0; }"),
]
def one(item):
    mid, why, old, new = item; src = open(os.path.join(ROOT, H), encoding='utf-8').read()
    if src.count(old) != 1: return (mid, why, 'UNGUELTIG(%d)' % src.count(old), '')
    d = tempfile.mkdtemp(); os.makedirs(d + '/design'); os.makedirs(d + '/tests'); shutil.copy(os.path.join(ROOT, 'tests/test_mesh_slots.cpp'), d + '/tests/')
    open(d + '/' + H, 'w', encoding='utf-8').write(src.replace(old, new))
    c = subprocess.run(['g++', '-std=c++11', '-O1', '-w', 'tests/test_mesh_slots.cpp', '-o', 't'], cwd=d, capture_output=True, text=True)
    if c.returncode: shutil.rmtree(d, ignore_errors=True); return (mid, why, 'INVALID', 'Compilefehler')
    r = subprocess.run(['./t'], cwd=d, capture_output=True, text=True, timeout=120); fl = [l[6:60].strip() for l in r.stdout.splitlines() if l.startswith('FAIL')]; shutil.rmtree(d, ignore_errors=True)
    return (mid, why, 'killed' if r.returncode else 'SURVIVED', ('%d Pruefungen, z. B. %s' % (len(fl), fl[0])) if fl else '')
with ThreadPoolExecutor(max_workers=2) as ex: res = list(ex.map(one, M))
for mid, why, st, info in res: print(f'{mid} {st:9} {why}' + (f'  <- {info}' if info else ''))
k = sum(r[2] == 'killed' for r in res); s = [r[0] for r in res if r[2] == 'SURVIVED']; bad = [r[0] for r in res if r[2] in ('INVALID',) or r[2].startswith('UNGUELTIG')]
print(f'--- erkannt {k}, UEBERLEBT {len(s)}: {s}, ungueltig {len(bad)} {bad} von {len(res)}')
