#!/usr/bin/env python3
"""Baut aus dem ECHTEN LCD_RTS.h/.cpp eine belegte DWIN/RTS-Karte: VP-Adressen, Tasten (Adresse -> Key-Enum -> Handler), je Handler die behandelten Datenwerte, enqueued Befehle,
angesprochene VPs und ob M500/settings.save vorkommt. JEDE Angabe traegt Quelldatei und Zeilen. NICHTS wird erfunden: was der Quelltext nicht hergibt, bleibt 'unbekannt'.
Aufruf: python3 tools/dwin_map.py --h LCD_RTS.h --cpp LCD_RTS.cpp --out-json docs/DWIN_VP_MAP.json --out-md docs/DWIN_VP_MAP.md"""
import argparse, json, re, sys
from pathlib import Path


def parse(h: str, c: str, hname='LCD_RTS.h', cname='LCD_RTS.cpp'):
    hl, cl = h.split('\n'), c.split('\n'); vps, commented = {}, {}
    for i, l in enumerate(hl, 1):
        m = re.match(r'^\s*#define\s+(\w+)\s+\(?(0x[0-9A-Fa-f]+)\)?', l)
        if m and m.group(1).endswith('_VP'): vps[m.group(1)] = {'addr': int(m.group(2), 16), 'line': i}
        m = re.match(r'^\s*//\s*#define\s+(\w+)\s+\(?(0x[0-9A-Fa-f]+)\)?', l)
        if m and m.group(1).endswith('_VP'): commented[m.group(1)] = {'addr': int(m.group(2), 16), 'line': i}
    em = re.search(r'enum\s+PROC_COM\s*\{(.*?)\};', h, re.S); enum_start = h[:em.start()].count('\n') + 1 if em else 0
    names = []
    if em:
        for tok in re.sub(r'//.*', '', em.group(1)).replace('\n', ' ').split(','):
            tok = tok.strip()
            if tok: names.append(re.sub(r'\s*=.*', '', tok))
    am = re.search(r'Addrbuf\[\]\s*=\s*\{(.*?)\};', h, re.S); addrs = []
    if am:
        for tok in re.sub(r'//.*', '', am.group(1)).replace('\n', ' ').split(','):
            tok = tok.strip()
            if tok: addrs.append(int(tok, 0) if re.fullmatch(r'0[xX][0-9A-Fa-f]+|\d+', tok) else (vps.get(tok, {}).get('addr') if tok in vps else None))
    sentinel = addrs and addrs[-1] == 0
    if sentinel: addrs = addrs[:-1]
    keys = [{'key': n, 'index': i, 'addr': addrs[i] if i < len(addrs) else None} for i, n in enumerate(names)]
    # Handler
    hm = re.search(r'void RTSSHOW::RTS_HandleData\(\)', c); body_start = c[:hm.start()].count('\n') + 1 if hm else 0
    cases = [(m.start(), m.group(1)) for m in re.finditer(r'^\s{4}case (\w+):', c, re.M)]
    for idx, (pos, key) in enumerate(cases):
        end = cases[idx + 1][0] if idx + 1 < len(cases) else len(c); body = c[pos:end]; s_line = c[:pos].count('\n') + 1; e_line = c[:end].count('\n') + 1
        for k in keys:
            if k['key'] == key and 'handler' not in k:
                k['handler'] = {'file': cname, 'lines': [s_line, e_line], 'data_values': sorted({int(x) for x in re.findall(r'recdat\.data\[0\]\s*==\s*(\d+)', body)}),
                                'enqueues': sorted(set(re.findall(r'enqueue_now_P\(PSTR\("([^"]*)"\)\)', body))), 'sends_vps': sorted(set(re.findall(r'RTS_SndData\([^;]*?,\s*(\w+_VP)\b', body))),
                                'mentions_eeprom_save': bool(re.search(r'M500|settings\.save', body)), 'mentions_g29': 'G29' in body, 'mentions_bed_leveling': bool(re.search(r'G29|BedLevel|AUTO_BED_LEVEL|bed_level', body))}
    for k in keys: k.setdefault('handler', None)
    problems = []
    if len(names) != len(addrs): problems.append(f'Enum ({len(names)}) und Addrbuf ({len(addrs)}) sind verschieden lang: Zuordnung Index->Adresse NICHT belegt')
    if not sentinel: problems.append('Addrbuf endet nicht auf 0')
    if None in addrs: problems.append('Addrbuf enthaelt nicht aufloesbare Eintraege')
    dup = sorted({a for a in addrs if addrs.count(a) > 1 and a is not None}); 
    if dup: problems.append('doppelte Adressen in Addrbuf: ' + ', '.join(hex(a) for a in dup))
    pt0 = vps.get('AUTO_BED_LEVEL_1POINT_VP', {}).get('addr'); overlaps = []
    if pt0 is not None:
        for k in keys:
            if k['addr'] is not None and pt0 <= k['addr'] <= pt0 + 2 * 15: overlaps.append({'key': k['key'], 'addr': k['addr'], 'collides_with_point_value': (k['addr'] - pt0) // 2 + 1, 'exact_slot': (k['addr'] - pt0) % 2 == 0})
    return {'overlaps_with_point_values': overlaps, 'sources': {'header': hname, 'cpp': cname}, 'vps': {k: v for k, v in sorted(vps.items(), key=lambda x: x[1]['addr'])}, 'vps_commented_out': commented, 'enum_line': enum_start, 'keys': keys, 'problems': problems, 'handler_function_line': body_start}


REQUIREMENTS = [
 ('Fortschritt 1 bis 16', 'BELEGT (OEM)', 'AUTO_BED_LEVEL_ICON_VP und je Punkt AUTO_BED_LEVEL_1POINT_VP + (n-1)*2; der OEM-G29 beschreibt sie selbst, G29 U nutzt dieselbe Schleife. Ob das Display-Projekt alle 16 Adressen darstellt: NICHT aus dem Quelltext belegbar.'),
 ('Temperatur Soll/Ist Bett', 'BELEGT (OEM)', 'BED_SET_TEMP_VP und BED_CURRENT_TEMP_VP existieren; auf welcher Seite sie sichtbar sind: unbekannt (Display-Projekt).'),
 ('Messwert je Punkt (Zahl)', 'BELEGT (OEM)', 'AUTO_BED_LEVEL_1POINT_VP + (n-1)*2, Wert z*1000.'),
 ('Schaltflaeche "Bettvermessung 60 C"', 'BLOCKIERT', 'Braucht einen NEUEN Touch-Bereich im DWIN-Projekt samt neuer Adresse, Eintrag in Addrbuf, neuem Enum-Wert und Handler. Ohne Display-Projekt (T5UID1-Konfiguration/Bilder) nicht verantwortbar; keine Adresse wird erfunden.'),
 ('Abbruch-Schaltflaeche', 'BLOCKIERT', 'Wie oben; Abbruch ueber das Display existiert fuer diese Funktion nicht.'),
 ('Farbige Messkarte', 'BLOCKIERT', 'Kein VP/Icon-Mapping fuer Farbzustaende der 16 Punkte im Quelltext; braucht Display-Ressourcen.'),
 ('Fehlercode-/Statuszeile', 'BLOCKIERT', 'Es gibt nur feste Text-VPs (PRINTER_*_TEXT_VP); keine freie Statuszeile belegt.'),
 ('Erfolgs-/Fehlerseite', 'BLOCKIERT', 'Seitenwechsel laufen ueber ExchangePageBase + Seitennummer; neue Seiten gibt es nur im Display-Projekt. Der OEM wechselt am Ende von G29 selbst via RTS_AutoBedLevelPage().'),
]


def render_md(m, dstat=None) -> str:
    L = ['# DWIN/RTS-Karte aus dem ECHTEN `LCD_RTS.h` / `LCD_RTS.cpp` (maschinell erzeugt, `tools/dwin_map.py`)', '',
         'Jede Zeile traegt Quelle und Zeile. **Nichts ist erfunden**; was der Quelltext nicht hergibt, steht als unbekannt/blockiert. Das Display-Projekt (T5UID1/DGUS-Konfiguration, Bilder) liegt NICHT vor.', '']
    if m['problems']: L += ['**Auffaelligkeiten:** ' + '; '.join(m['problems']), '']
    if m.get('overlaps_with_point_values'): L += ['**Befund (OEM, nicht von uns):** Tastenadressen im Wertebereich der 16 Messpunkte (AUTO_BED_LEVEL_1POINT_VP + 2*(n-1)): ' + '; '.join(f"`{o['key']}` = 0x{o['addr']:04X} = Punkt {o['collides_with_point_value']}" for o in m['overlaps_with_point_values']) + '. Neue Adressen muessen diesen Bereich meiden; ob das im Display-Projekt ein echtes Problem ist, ist aus dem Quelltext nicht belegbar.', '']
    L += [f"VP-Definitionen: {len(m['vps'])} aktiv, {len(m['vps_commented_out'])} auskommentiert. Tasten (Enum PROC_COM): {len(m['keys'])}.", '', '## Anforderungen an die Ein-Knopf-Funktion', '', '| Element | Status | Beleg / Grund |', '|---|---|---|']
    L += [f'| {a} | **{b}** | {c} |' for a, b, c in REQUIREMENTS]
    L += ['', '## Bettbezogene VPs', '', '| Name | Adresse | Zeile |', '|---|---|---|']
    for k, v in m['vps'].items():
        if re.search(r'BED|AUTO_BED|ZOFFSET', k): L.append(f"| `{k}` | `0x{v['addr']:04X}` | {m['sources']['header']}:{v['line']} |")
    L += ['', '## Tasten mit Bezug zum Bettnivellieren oder zu G29/G28', '', '| Key | Index | Adresse | Daten | Befehle | Zeilen |', '|---|---|---|---|---|---|']
    for k in m['keys']:
        h = k['handler']
        if h and (h['mentions_bed_leveling'] or any(c.startswith(('G28', 'G29')) for c in h['enqueues'])): L.append(f"| `{k['key']}` | {k['index']} | " + (f"`0x{k['addr']:04X}`" if k['addr'] is not None else '?') + f" | {h['data_values']} | {', '.join(h['enqueues'])[:70]} | {m['sources']['cpp']}:{h['lines'][0]}-{h['lines'][1]} |")
    L += ['', '## Alle Tasten (Adresse -> Key -> Handler)', '', '| Index | Key | Adresse | Handler (Zeilen) | Daten | M500/settings.save |', '|---|---|---|---|---|---|']
    for k in m['keys']:
        h = k['handler']; L.append(f"| {k['index']} | `{k['key']}` | " + (f"`0x{k['addr']:04X}`" if k['addr'] is not None else '?') + f" | " + (f"{h['lines'][0]}-{h['lines'][1]}" if h else 'kein case') + f" | {h['data_values'] if h else ''} | {'JA' if h and h['mentions_eeprom_save'] else ''} |")
    return '\n'.join(L) + '\n'


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--h', type=Path, required=True); ap.add_argument('--cpp', type=Path, required=True); ap.add_argument('--out-json', type=Path); ap.add_argument('--out-md', type=Path); a = ap.parse_args()
    m = parse(a.h.read_text(encoding='utf-8'), a.cpp.read_text(encoding='utf-8'))
    if a.out_json: a.out_json.write_text(json.dumps(m, indent=1, ensure_ascii=False), encoding='utf-8')
    md = render_md(m)
    if a.out_md: a.out_md.write_text(md, encoding='utf-8')
    print(f"VPs {len(m['vps'])}, Tasten {len(m['keys'])}, Auffaelligkeiten {len(m['problems'])}: {m['problems']}"); return 0


if __name__ == '__main__': sys.exit(main())
