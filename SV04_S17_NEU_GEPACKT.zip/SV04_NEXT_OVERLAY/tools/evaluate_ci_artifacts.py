#!/usr/bin/env python3
"""Wertet entpackte GitHub-Actions-Artefakte (Workflow 18/19-Format) NUR nach harten Kriterien aus und verhindert falsches Gruen:
  * welcher Overlay-Stand wurde WIRKLICH gebaut (overlay-zip.sha256 gegen ein Register)? Ein Stand-15-Erfolg ist KEIN Stand-17-Erfolg (--expect-stand);
  * SKIPPED/fehlende/leere Nachweise sind nie gruen; * Overlay-Varianten brauchen apply-Exit 0, block 13 und layer 17 (ab Stand 16);
  * Erreichbarkeit (reach.json) wird SEPARAT gemeldet (nie stillschweigend gruen); * Baseline-Reproduzierbarkeit nur mit Beleg; * Commit-SHA muss in allen Artefakten uebereinstimmen.
Aufruf: python3 tools/evaluate_ci_artifacts.py --dir DIR --prefix 19 --registry docs/RELEASE_REGISTER.json --expect-stand 17 [--out-json X --out-md Y]   (Exit 0 nur bei vollem Gruen fuer den erwarteten Stand)"""
import argparse, json, re, sys
from pathlib import Path
VARIANTS = ('baseline', 'probe', 'overlay', 'overlay-auto60')


def rd(p, default=None):
    p = Path(p); return p.read_text(encoding='utf-8', errors='replace').strip() if p.is_file() else default


def stand_of(sha, reg):
    for s, v in reg.get('overlays', {}).items():
        if v['sha256'] == sha: return s
    return None


def eval_variant(d, v, reg, expect):
    r = {'variant': v, 'dir': str(d), 'checks': {}, 'notes': []}; c = r['checks']
    if not d.is_dir(): r['verdict'] = 'FEHLT'; return r
    c['variant.txt stimmt'] = rd(d / 'variant.txt') == v
    be = rd(d / 'build.exit'); c['build.exit == 0'] = be == '0'
    if be and be != '0': r['notes'].append(f'build.exit = {be!r}' + (' (SKIPPED zaehlt nie als gruen)' if be == 'SKIPPED' else ''))
    log = rd(d / 'build.log', ''); c['build.log enthaelt SUCCESS'] = 'SUCCESS' in log
    c['firmware.sha256 vorhanden'] = bool(re.fullmatch(r'[0-9a-f]{64}\s+\S+', rd(d / 'firmware.sha256', ''))); fs = rd(d / 'firmware.size', ''); m = re.search(r'\s(\d{5,})\s', ' ' + fs.replace('\t', ' ') + ' '); c['firmware.size > 0'] = bool(m)
    c['OEM-Blobs 5/5'] = rd(d / 'oem-blobs.ok') == '1'   # echtes Format von Workflow 18/19: Datei enthaelt 1
    zs = rd(d / 'overlay-zip.sha256'); r['overlay_zip_sha256'] = zs; r['stand_built'] = stand_of(zs, reg) if zs else None
    if v in ('overlay', 'overlay-auto60'):
        c['overlay-apply.exit == 0'] = rd(d / 'overlay-apply.exit') == '0'; c['overlay-dry-run.exit == 0'] = rd(d / 'overlay-dry-run.exit') == '0'
        try: aj = json.loads(rd(d / 'overlay-apply.json', '{}')) or {}
        except Exception: aj = {}
        c['apply.json block == 13'] = aj.get('block') == 13; r['layer'] = aj.get('layer')
        if expect is not None and int(expect) >= 16: c['apply.json layer == 17 (Stand >= 16)'] = aj.get('layer') == 17
        c['auto60 im Standard-Overlay nicht kompiliert'] = (aj.get('auto60_engine_compiled_by_default') is False) if aj else False
        c['Stand gebaut == erwarteter Stand'] = (r['stand_built'] == f'stand{expect}') if expect is not None else r['stand_built'] is not None
        if r['stand_built'] is None: r['notes'].append('overlay-zip.sha256 steht NICHT im Register: gebauter Stand unbekannt')
        elif expect is not None and r['stand_built'] != f'stand{expect}': r['notes'].append(f'GEBAUT WURDE {r["stand_built"]}, ERWARTET stand{expect}: NICHT als Stand {expect} werten')
    rj = rd(d / 'reach.json')
    if rj:
        try: rep = json.loads(rj); bad = [x['name'] for x in rep.get('results', []) if not x.get('passed')]; r['reach'] = {'status': 'OK' if rep.get('all_expectations_met') else 'VERLETZT', 'violated': bad}
        except Exception: r['reach'] = {'status': 'UNLESBAR', 'violated': []}
    elif (d / 'reach.skipped').is_file(): r['reach'] = {'status': 'NICHT GELAUFEN (keine ELF/Binutils)', 'violated': []}
    else: r['reach'] = {'status': 'NICHT GELAUFEN', 'violated': []}
    if v == 'baseline':
        rp = rd(d / 'repro.txt')
        if rp: r['repro'] = {'result': rp.splitlines()[-1], 'diff_bytes': rd(d / 'repro-diff-bytes.txt')}
        else: r['repro'] = {'result': 'NICHT GEPRUEFT'}
    cm = rd(d / 'commit.txt'); r['commit'] = cm.splitlines()[0] if cm else None
    r['build_ok'] = all(c.values()); r['verdict'] = 'BAU GRUEN' if r['build_ok'] else ('SKIPPED' if be == 'SKIPPED' else 'NICHT GRUEN')
    return r


def evaluate(base, prefix, reg, expect):
    out = {'prefix': prefix, 'expect_stand': expect, 'variants': [eval_variant(Path(base) / f'{prefix}-build-{v}', v, reg, expect if v.startswith('overlay') else None) for v in VARIANTS]}
    ht = Path(base) / f'{prefix}-host-tests'; out['host_tests'] = {'exit': rd(ht / 'host-tests.exit'), 'ok': rd(ht / 'host-tests.exit') == '0'} if ht.is_dir() else {'exit': None, 'ok': False, 'note': 'Artefakt fehlt'}
    dj_path = Path(base) / f'{prefix}-diagnose' / 'diagnose' / 'diagnose.json'   # der Diagnose-Job ist IMMER gruen (kein exit 1): sein Urteil steht nur in diagnose.json
    if dj_path.is_file():
        try:
            dg = json.loads(dj_path.read_text(encoding='utf-8')); oem = dg.get('oem', {}); bad = [k for k, v in oem.items() if not v.get('match') or v.get('crlf') or not v.get('utf8') or v.get('markers_present')]
            out['diagnose'] = {'oem_all_match': bool(oem) and not bad, 'oem_problems': bad, 'overlay_integrity': (dg.get('overlay_integrity') or {}).get('ok', (dg.get('overlay_integrity') or {}).get('all_ok')), 'strict_dry_run_ok': (dg.get('strict_dry_run') or {}).get('ok'), 'git_head': (dg.get('env') or {}).get('git_head')}
            af = dg.get('anchor_failures'); n_af = af.get('count', 1) if isinstance(af, dict) else len(af or [])   # echtes Format: {'count': N, 'items': [...]}
            out['diagnose']['anchor_failure_count'] = n_af
            out['diagnose']['ok'] = bool(out['diagnose']['oem_all_match'] and out['diagnose']['strict_dry_run_ok'] and out['diagnose']['overlay_integrity'] is not False and n_af == 0)
        except Exception as e: out['diagnose'] = {'ok': False, 'error': str(e)}
    else: out['diagnose'] = {'ok': False, 'error': 'diagnose.json fehlt'}
    commits = {x['commit'] for x in out['variants'] if x.get('commit')}; dj = rd(Path(base) / f'{prefix}-diagnose' / 'commit.txt'); dc = dj.splitlines()[0] if dj else None
    if dc: commits.add(dc)
    out['commit_consistent'] = len(commits) <= 1 and bool(commits); out['commits'] = sorted(commits)
    builds = all(x.get('build_ok') for x in out['variants']); out['all_builds_green'] = builds
    out['overall'] = 'GRUEN FUER DEN ERWARTETEN STAND' if builds and out['host_tests']['ok'] and out['commit_consistent'] and out['diagnose'].get('ok') else 'NICHT GRUEN (oder nicht belegt)'
    out['reach_summary'] = {x['variant']: x['reach']['status'] for x in out['variants'] if 'reach' in x}
    return out


def render_md(o):
    L = [f"# CI-Auswertung (Praefix {o['prefix']}, erwarteter Stand: {o['expect_stand']})", '', f"**Gesamt: {o['overall']}**", '', '| Variante | Urteil | gebauter Stand | Erreichbarkeit | Hinweise |', '|---|---|---|---|---|']
    for x in o['variants']: L.append(f"| {x['variant']} | {x['verdict']} | {x.get('stand_built')} | {x.get('reach', {}).get('status')} | {'; '.join(x['notes'])[:140]} |")
    L += ['', f"Diagnose (der Job selbst ist immer gruen, entscheidend ist diagnose.json): {o['diagnose']}", f"Host-Tests: {o['host_tests']}", f"Commit konsistent: {o['commit_consistent']} {o['commits']}"]
    for x in o['variants']:
        if x['variant'] == 'baseline': L.append(f"Baseline-Reproduzierbarkeit: {x.get('repro')}")
        bad = [k for k, v in x['checks'].items() if not v]
        if bad: L.append(f"- {x['variant']} nicht erfuellt: {', '.join(bad)}")
    return '\n'.join(L) + '\n'


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--dir', type=Path, required=True); ap.add_argument('--prefix', required=True); ap.add_argument('--registry', type=Path, required=True); ap.add_argument('--expect-stand'); ap.add_argument('--out-json', type=Path); ap.add_argument('--out-md', type=Path); a = ap.parse_args()
    reg = json.loads(a.registry.read_text(encoding='utf-8')); o = evaluate(a.dir, a.prefix, reg, a.expect_stand)
    if a.out_json: a.out_json.write_text(json.dumps(o, indent=1, ensure_ascii=False), encoding='utf-8')
    md = render_md(o)
    if a.out_md: a.out_md.write_text(md, encoding='utf-8')
    print(md); return 0 if o['overall'].startswith('GRUEN') else 1


if __name__ == '__main__': sys.exit(main())
