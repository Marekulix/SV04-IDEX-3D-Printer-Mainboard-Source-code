#!/usr/bin/env python3
"""Mutationskampagne gegen die Stand-16-Schicht (elektrische T1-Parkbestaetigung): Patcher v17, Sensor-Header, Engine, Bruecke.
Pro Mutant wird EINE Datei geaendert; geprueft in dieser Reihenfolge bis ein Test fehlschlaegt: v17-Test, Engine-Test, Real-G29-Harness, Fixture-Harness (130 + E2E).
Ergebnis je Mutant: killed / SURVIVED / UNGUELTIG."""
import os, shutil, subprocess, sys, tempfile
from concurrent.futures import ThreadPoolExecutor
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
V17, SENSE, ENG, GLUE = 'integration/apply_native_guard_v17.py', 'include/SV04NextT1ParkSense.hpp', 'include/SV04NextAuto60Engine.hpp', 'include/SV04NextAuto60Glue.hpp'
M = [
 ('P01', V17, 'Startpruefung wirkungslos (Zaehler bleibt gleich, Ausfuehrung muss es merken)', "      if (!sv04next::t1_parked_electrically()) {", "      if (!sv04next::t1_parked_electrically() && false) {"),
 ('P02', V17, 'Punktpruefung wirkungslos (Zaehler bleibt gleich)', "if (sv04_transactional_run && !sv04next::t1_parked_electrically()) {", "if (sv04_transactional_run && !sv04next::t1_parked_electrically() && false) {"),
 ('P03', V17, 'Abschlusspruefung wirkungslos (Zaehler bleibt gleich)', "if (sv04_good && !sv04next::t1_parked_electrically()) sv04_good = false;", "if (sv04_good && !sv04next::t1_parked_electrically() && false) sv04_good = false;"),
 ('P09', V17, 'Zaehlpruefung des Patchers entfernt (AEQUIVALENT: allein wirkungslos, schuetzt nur vor einer kuenftig fehlenden Pruefung)', "if g.count('t1_parked_electrically()') != 3: raise PatchRefused('expected exactly 3 uses of t1_parked_electrically() in G29.cpp')", "pass"),
 ('P04', V17, 'Punktpruefung gilt auch fuer den normalen G29 (ohne U)', "if (sv04_transactional_run && !sv04next::t1_parked_electrically()) {", "if (!sv04next::t1_parked_electrically()) {"),
 ('P05', V17, 'Startpruefung ohne Beleg (kein refuse)', "        sv04next::g29u_receipt.refuse(sv04next::G29UReceipt::Failure::UnsafeIDEX);\\n'\n           '        SERIAL_ERROR_MSG(\"SV04 NEXT G29U REFUSED: T1 park", "        \\n'\n           '        SERIAL_ERROR_MSG(\"SV04 NEXT G29U REFUSED: T1 park"),
 ('P06', V17, 'Startpruefung ohne Rueckkehr (G29 laeuft trotzdem weiter)', "        SERIAL_ERROR_MSG(\"SV04 NEXT G29U REFUSED: T1 park not confirmed by X_MAX endstop\");\\n'\n           '        G29_RETURN(true);\\n'", "        SERIAL_ERROR_MSG(\"SV04 NEXT G29U REFUSED: T1 park not confirmed by X_MAX endstop\");\\n'\n           '\\n'"),
 ('P07', V17, 'Punktpruefung ohne Abbruch der Schleife', "              abl.measured_z = NAN;\\n'\n           '              break;\\n'", "              abl.measured_z = NAN;\\n'\n           '\\n'"),
 ('P08', V17, 'Punktpruefung hinter dem OEM-Antastkommentar (falsche Platzierung)', "g = g.replace(A_POINT, N_POINT + '\\n' + A_POINT)", "g = g.replace(A_POINT, A_POINT + N_POINT)"),
 ('S01', SENSE, 'Sensor: Polaritaet vertauscht', "READ(X_MAX_PIN) != X_MAX_ENDSTOP_INVERTING &&", "READ(X_MAX_PIN) == X_MAX_ENDSTOP_INVERTING &&"),
 ('S02', SENSE, 'Sensor: fail OPEN, wenn der Pin fehlt', "inline bool t1_parked_electrically() { return false; }   // fail closed", "inline bool t1_parked_electrically() { return true; }   // fail closed"),
 ('S03', SENSE, 'Sensor: Bedingung ohne DUAL_X_CARRIAGE', "#if ENABLED(DUAL_X_CARRIAGE) && PIN_EXISTS(X_MAX)", "#if PIN_EXISTS(X_MAX)"),
 ('S05', SENSE, 'Sensor: ohne Positionsunterscheidung (T0 rechts koennte den Schalter selbst druecken)', " && current_position.x <= X_MAX_POS; }", "; }"),
 ('S06', SENSE, 'Sensor: NaN-Position wird durchgelassen (Fail-open)', "current_position.x <= X_MAX_POS; }", "!(current_position.x > X_MAX_POS); }"),
 ('S04', SENSE, 'Sensor: liest anderen Pin', "{ return READ(X_MAX_PIN)", "{ return READ(Y_MAX_PIN)"),
 ('E01', ENG, 'Engine verlangt die elektrische Bestaetigung nicht mehr', "if (!o.t1_parked_electrically) return abort_(Reason::Precondition);", "if (false) return abort_(Reason::Precondition);"),
 ('G01', GLUE, 'Bruecke meldet den Schalter immer als ausgeloest', "o.t1_parked_electrically = t1_parked_electrically();", "o.t1_parked_electrically = true;"),
 ('G02', GLUE, 'Bruecke vergisst, das Feld zu setzen', "  o.t1_parked_electrically = t1_parked_electrically();   // Stand 16: elektrischer X_MAX-Pegel, nicht die Firmware-Buchfuehrung\n", ""),
]
ENGINE_CMD = 'g++ -std=c++11 -O2 -Wall -Wextra -Werror -pedantic tests/test_auto60_engine.cpp -o /tmp/mv17_$$ && /tmp/mv17_$$ > /dev/null'
TESTS = [('v17-Test', [sys.executable, 'tests/test_overlay_v17.py']), ('Engine-Test', ['bash', '-c', ENGINE_CMD]), ('Real-G29-Harness', [sys.executable, 'harness/run_real_g29.py']), ('Fixture-Harness', [sys.executable, 'harness/run_harness.py'])]
def one(item):
    mid, f, why, old, new = item; src = open(os.path.join(ROOT, f), encoding='utf-8').read()
    if src.count(old) != 1: return (mid, why, 'UNGUELTIG(%d)' % src.count(old), '')
    d = tempfile.mkdtemp()
    for sub in ('integration', 'include', 'tests', 'harness', 'tools'): shutil.copytree(os.path.join(ROOT, sub), os.path.join(d, sub), ignore=shutil.ignore_patterns('__pycache__', '*.pyc', 'real_g29'), dirs_exist_ok=False) if sub != 'harness' else shutil.copytree(os.path.join(ROOT, sub), os.path.join(d, sub), ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    open(os.path.join(d, f), 'w', encoding='utf-8').write(src.replace(old, new)); env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    for name, cmd in TESTS:
        try: r = subprocess.run(cmd, cwd=d, capture_output=True, text=True, env=env, timeout=300)
        except subprocess.TimeoutExpired: shutil.rmtree(d, ignore_errors=True); return (mid, why, 'killed', name + ': Zeitueberschreitung')
        if r.returncode: shutil.rmtree(d, ignore_errors=True); tail = (r.stdout.strip().splitlines() + r.stderr.strip().splitlines() or [''])[-1][:60]; return (mid, why, 'killed', name + ': ' + tail)
    shutil.rmtree(d, ignore_errors=True); return (mid, why, 'SURVIVED', '')
with ThreadPoolExecutor(max_workers=2) as ex: res = list(ex.map(one, M))
for mid, why, st, info in res: print(f'{mid} {st:9} {why}' + (f'  <- {info}' if info else ''))
k = sum(r[2] == 'killed' for r in res); s = [r[0] for r in res if r[2] == 'SURVIVED']; bad = [r[0] for r in res if r[2].startswith('UNGUELTIG')]
print(f'--- erkannt {k}, UEBERLEBT {len(s)}: {s}, ungueltig {len(bad)} {bad} von {len(res)}')
