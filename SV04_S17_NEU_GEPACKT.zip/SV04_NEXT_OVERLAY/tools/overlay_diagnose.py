#!/usr/bin/env python3
"""Diagnose des Overlays gegen den ECHTEN Marlin-Quelltext in EINEM Lauf. Schreibt nichts in den Quelltext (nur in --out). NICHT FLASHEN.
Liefert: Integritaet des Overlay-Ordners (Hashliste), OEM-Dateien (SHA1, Zeilenenden, Marker), IDEX-Topologie von G28.cpp, ALLE fehlgeschlagenen Anker der Patch-Kette
(nicht nur den ersten), das Ergebnis des strengen Trockenlaufs und einen Abgleich der Marlin-Namen, die Bruecke und G29-Code verwenden, gegen den echten Quelltext.
Aufruf: python3 tools/overlay_diagnose.py --root <Repo-Wurzel> --overlay <Overlay-Ordner> --out <Ausgabeordner>"""
import argparse, fnmatch, hashlib, json, os, re, shutil, subprocess, sys, traceback
from pathlib import Path

SYMBOLS = ['setTargetBed', 'degBed', 'degTargetBed', 'enqueue_one_P', 'enqueue_now_P', 'has_commands_queued', 'has_blocks_queued', 'leveling_active', 'refresh_bed_level',
           'set_bed_leveling_enabled', 'z_values', 'bilinear_start', 'bilinear_grid_spacing', 'axis_is_trusted', 'dual_x_carriage_mode', 'DXC_AUTO_PARK_MODE', 'inactive_extruder_x',
           'X2_MAX_POS', 'RTS_SndData', 'RTS_AutoBedLevelPage', 'printJobOngoing', 'printingIsPaused', 'IsStopped', 'active_extruder', 'millis', 'AUTO_BED_LEVEL_1POINT_VP']
CONFIG_FLAGS = ['DUAL_X_CARRIAGE', 'AUTO_BED_LEVELING_BILINEAR', 'PROBE_MANUALLY', 'RTS_AVAILABLE', 'EXTENSIBLE_UI', 'G29_RETRY_AND_RECOVER', 'FULL_REPORT_TO_HOST_FEATURE', 'ENABLE_LEVELING_FADE_HEIGHT', 'EEPROM_SETTINGS']
HEADERS_OF_INTEREST = ['temperature.h', 'queue.h', 'planner.h', 'probe.h', 'motion.h', 'bedlevel.h', 'abl.h', 'LCD_RTS.h', 'MarlinCore.h', 'settings.h', 'gcode.h', 'Configuration_adv.h',
                       # ab Stand 15: fuer die Ausfuehrung der echten G28.cpp (Mehrachsen-Makros, Typen, IDEX) und die D1-Analyse (EEPROM-Verhalten)
                       'macros.h', 'types.h', 'enum.h', 'endstops.h', 'idex.h', 'bltouch.h', 'serial.h', 'stepper.h', 'Conditionals_post.h', 'Conditionals_adv.h', 'MarlinConfig.h', 'settings.cpp', 'bedlevel.cpp', 'abl.cpp', 'motion.cpp',
                       # ab Stand 16: EEPROM-Backend (D1), Board-Pinbelegung (X_MAX_PIN, EEPROM-Typ), Befehlsverteilung, Version
                       'gcode.cpp', 'Version.h', 'pins.h', 'pins_CREALITY*.h', 'pins_SOVOL*.h', 'eeprom*.cpp', 'eeprom*.h', 'persistent_store*.h', 'persistent_store*.cpp', 'HAL.h', 'fastio.h',
                       # ab Stand 17: Endstop-Logik (Endstops::update, DXC-Zuordnung), Parser, Planner-Nebenwirkungen, Thermoschutz, Stepper-ISR
                       'endstops.cpp', 'parser.h', 'parser.cpp', 'planner.cpp', 'temperature.cpp', 'stepper.cpp']
G28_TOKENS = re.compile(r'homeaxis\(|active_extruder|DUAL_X|dual_x_carriage_mode|DXC_|idex_|#\s*(if|elif|else|endif)|\breturn\b|set_and_report_grblstate|axis_is_trusted')


def sha256(b): return hashlib.sha256(b).hexdigest()
def blob_sha1(b): return hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()


def overlay_integrity(overlay: Path):
    res = {'manifest': None, 'modified': [], 'missing': [], 'extra_py_or_hpp': [], 'ok': None}
    cands = sorted(overlay.glob('proof/SHA256SUMS_*_ALL.txt'))
    if not cands: res['note'] = 'keine Hashliste im Overlay-Ordner (proof/SHA256SUMS_*_ALL.txt); Integritaet nicht pruefbar'; return res
    man = cands[-1]; res['manifest'] = man.name; listed = set()
    for line in man.read_text(encoding='utf-8').splitlines():
        if not line.strip(): continue
        h, _, name = line.partition('  '); name = name.strip(); listed.add(name); p = overlay / name
        if not p.is_file(): res['missing'].append(name)
        elif sha256(p.read_bytes()) != h: res['modified'].append(name)
    for p in overlay.rglob('*'):
        rel = str(p.relative_to(overlay))
        if p.is_file() and p.suffix in ('.py', '.hpp', '.cpp') and '__pycache__' not in rel and rel not in listed and not rel.startswith('proof/'): res['extra_py_or_hpp'].append(rel)
    res['ok'] = not (res['modified'] or res['missing']); return res


def scan_symbols(src: Path):
    out = {s: {'files': 0, 'total': 0, 'header_hits': [], 'other_hits': []} for s in SYMBOLS}; pats = {s: re.compile(r'\b' + re.escape(s) + r'\b') for s in SYMBOLS}; flags = {f: [] for f in CONFIG_FLAGS}
    for dp, dn, fn in os.walk(src):
        for f in fn:
            if not f.endswith(('.h', '.hpp', '.cpp', '.c', '.ino')): continue
            p = Path(dp) / f
            try: lines = p.read_text(encoding='utf-8', errors='replace').splitlines()
            except OSError: continue
            rel = str(p.relative_to(src.parent)); seen = set()
            for i, l in enumerate(lines, 1):
                for s, rx in pats.items():
                    if rx.search(l):
                        o = out[s]; o['total'] += 1
                        if s not in seen: o['files'] += 1; seen.add(s)
                        bucket = o['header_hits'] if f.endswith(('.h', '.hpp')) else o['other_hits']
                        if len(bucket) < 6: bucket.append(f'{rel}:{i}: {l.strip()[:150]}')
    return out


def config_flags(marlin: Path):
    res = {}
    for name in ('Configuration.h', 'Configuration_adv.h'):
        p = marlin / name
        if not p.is_file(): continue
        for i, l in enumerate(p.read_text(encoding='utf-8', errors='replace').splitlines(), 1):
            m = re.match(r'^\s*(//)?\s*#\s*define\s+(\w+)', l)
            if m and m.group(2) in CONFIG_FLAGS: res.setdefault(m.group(2), []).append(f'{name}:{i}: {"AUSKOMMENTIERT " if m.group(1) else "AKTIV "}{l.strip()[:110]}')
    return res


def diagnose(root: Path, overlay: Path, out: Path, oem_blobs: dict | None = None) -> dict:
    sys.path.insert(0, str(overlay / 'integration')); out.mkdir(parents=True, exist_ok=True)
    # finale Kette (Stand 16): der Name v16 bleibt fuer die bestehenden Aufrufe
    import importlib; v16 = importlib.import_module('apply_native_guard_v17'); v15 = v16.v15; v14 = v15.v14
    if oem_blobs is None and os.environ.get('SV04_DIAG_OEM_BLOBS_JSON'): oem_blobs = json.loads(os.environ['SV04_DIAG_OEM_BLOBS_JSON'])   # NUR fuer Tests mit synthetischer Wurzel
    blobs = oem_blobs or dict(v14.OEM_BLOBS); rep = {'env': {'python': sys.version.split()[0], 'root': str(root), 'overlay': str(overlay)}}
    try: rep['env']['git_head'] = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=root, capture_output=True, text=True).stdout.strip()
    except OSError: pass
    rep['overlay_integrity'] = overlay_integrity(overlay)
    # OEM-Dateien
    originals = {}; rep['oem'] = {}; (out / 'oem-sources').mkdir(exist_ok=True)
    for name, want in blobs.items():
        p = root / name; r = {'exists': p.is_file(), 'expected_blob': want}
        if p.is_file():
            raw = p.read_bytes(); txt = raw.decode('utf-8', errors='replace'); originals[name] = txt
            r.update({'blob_sha1': blob_sha1(raw), 'match': blob_sha1(raw) == want, 'bytes': len(raw), 'lines': txt.count('\n'), 'crlf': raw.count(b'\r\n'), 'utf8': True,
                      'markers_present': [m for m in v14.OVERLAY_MARKERS if m in txt]})
            try: raw.decode('utf-8')
            except UnicodeDecodeError: r['utf8'] = False
            dest = out / 'oem-sources' / name; dest.parent.mkdir(parents=True, exist_ok=True); dest.write_bytes(raw)
        rep['oem'][name] = r
    # G28-Struktur
    g28 = originals.get(v14.G28)
    if g28 is not None:
        rep['g28'] = {'idex_topology': v14.idex_topology(g28), 'lines_of_interest': [f'{i}: {l.rstrip()[:140]}' for i, l in enumerate(g28.splitlines(), 1) if G28_TOKENS.search(l)][:400]}
    # alle Anker der Kette auf einmal
    mods = [m for n, m in list(sys.modules.items()) if n.startswith('apply_native_guard_v') and hasattr(m, 'replace_one')]; saved = {m: m.replace_one for m in mods}; failures = []
    def tolerant(value, before, after, name='?'):
        n = value.count(before)
        if n == 1: return value.replace(before, after, 1)
        failures.append({'target': name, 'found': n, 'anchor': before[:160]}); return value
    for m in mods: m.replace_one = tolerant
    tol_exc = None
    try:
        heads = [(overlay / 'include' / n).read_text(encoding='utf-8') for n in v16.HEADERS]; v16.render(dict(originals), *heads)
    except Exception as e: tol_exc = f'{type(e).__name__}: {e}'
    finally:
        for m, f in saved.items(): m.replace_one = f
    rep['anchor_failures'] = {'count': len(failures), 'items': failures, 'first_audit_exception_after_tolerant_run': tol_exc,
                              'note': 'Folgefehler moeglich: ein nicht eingefuegter Text laesst spaetere Anker scheitern; der ERSTE Eintrag ist massgeblich.'}
    # strenger Trockenlauf (schreibt nichts)
    try:
        heads_p = [overlay / 'include' / n for n in v16.HEADERS]; saved_blobs = dict(v14.OEM_BLOBS); v14.OEM_BLOBS.clear(); v14.OEM_BLOBS.update(blobs)
        try: r = v16.apply(root, heads_p, None, dry_run=True, diff_out=out / 'overlay-review.diff'); rep['strict_dry_run'] = {'ok': True, 'changed_files': sorted((r.get('changed_sha256') or {}).keys()), 'report': r}
        finally: v14.OEM_BLOBS.clear(); v14.OEM_BLOBS.update(saved_blobs)
    except Exception as e: rep['strict_dry_run'] = {'ok': False, 'exception': f'{type(e).__name__}: {e}', 'traceback_tail': traceback.format_exc().splitlines()[-6:]}
    # Namen gegen den echten Quelltext, Konfigurationsmakros
    src = root / 'Marlin' / 'src'
    if src.is_dir(): rep['symbols'] = scan_symbols(src); rep['config_flags'] = config_flags(root / 'Marlin')
    else: rep['symbols'] = {'note': 'Marlin/src nicht gefunden'}
    (out / 'oem-headers').mkdir(exist_ok=True); copied = []
    for base in HEADERS_OF_INTEREST:
        for dp, dn, fn in os.walk(root / 'Marlin'):
            for hit in ([base] if base in fn else sorted(x for x in fn if fnmatch.fnmatch(x, base)) if any(ch in base for ch in '*?') else []):
                p = Path(dp) / hit
                if p.stat().st_size < 400000 and len(copied) < 220: dest = out / 'oem-headers' / str(p.relative_to(root)); dest.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(p, dest); copied.append(str(p.relative_to(root)))
    pio = root / 'platformio.ini'
    if pio.is_file(): shutil.copy2(pio, out / 'platformio.ini')
    rep['copied_headers'] = copied
    (out / 'diagnose.json').write_text(json.dumps(rep, indent=1, ensure_ascii=False), encoding='utf-8')
    (out / 'DIAGNOSE.md').write_text(render_md(rep), encoding='utf-8'); return rep


def render_md(r: dict) -> str:
    L = ['# Overlay-Diagnose gegen den echten Quelltext', '', f"Python {r['env']['python']}, HEAD {r['env'].get('git_head', '?')}", '']
    oi = r['overlay_integrity']; L += ['## 1. Integritaet des Overlay-Ordners', f"Hashliste: {oi.get('manifest')} | ok: {oi.get('ok')} | veraendert: {oi['modified'] or 'keine'} | fehlend: {oi['missing'] or 'keine'} | zusaetzliche .py/.hpp/.cpp: {oi['extra_py_or_hpp'] or 'keine'}", oi.get('note', ''), '']
    L += ['## 2. OEM-Dateien', '| Datei | vorhanden | SHA1 passt | Zeilen | CRLF | UTF-8 | Overlay-Marker im Text |', '|---|---|---|---|---|---|---|']
    for n, o in r['oem'].items(): L.append(f"| {n} | {o['exists']} | {o.get('match')} | {o.get('lines')} | {o.get('crlf')} | {o.get('utf8')} | {o.get('markers_present') or 'keine'} |")
    if 'g28' in r: L += ['', '## 3. G28.cpp: IDEX-Topologie', '```', json.dumps(r['g28']['idex_topology'], indent=1), '```', '', '### Zeilen mit homeaxis/active_extruder/IDEX/Praeprozessor', '```', *r['g28']['lines_of_interest'][:250], '```']
    af = r['anchor_failures']; L += ['', f"## 4. Fehlgeschlagene Anker der gesamten Patch-Kette (toleranter Lauf): {af['count']}", af['note']]
    for it in af['items']: L.append(f"- {it['target']}: {it['found']}x gefunden, Anker: `{it['anchor']!r}`")
    L += ['', f"Erste Audit-Ausnahme nach tolerantem Lauf: {af['first_audit_exception_after_tolerant_run']}", '', '## 5. Strenger Trockenlauf']
    sd = r['strict_dry_run']; L.append('OK, geaenderte Dateien: ' + ', '.join(sd['changed_files']) if sd['ok'] else f"FEHLER: {sd['exception']}")
    if 'config_flags' in r: L += ['', '## 6. Konfigurationsmakros'] + [f'- {k}: {v}' for k, v in r['config_flags'].items()]
    if isinstance(r.get('symbols'), dict) and 'note' not in r['symbols']:
        L += ['', '## 7. Marlin-Namen aus Bruecke und G29-Code im echten Quelltext', '| Name | Dateien | Treffer | Header-Treffer (bis 3) |', '|---|---|---|---|']
        for s, o in r['symbols'].items(): L.append(f"| {s} | {o['files']} | {o['total']} | {' ; '.join(h[:110] for h in o['header_hits'][:3]) or '-'} |")
    return '\n'.join(L) + '\n'


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description='Overlay-Diagnose (nur lesend)'); ap.add_argument('--root', type=Path, default=Path('.')); ap.add_argument('--overlay', type=Path); ap.add_argument('--out', type=Path, default=Path('out-diagnose'))
    a = ap.parse_args(); ov = a.overlay or (a.root / 'SV04_NEXT_OVERLAY'); rep = diagnose(a.root.resolve(), ov.resolve(), a.out)
    sd = rep['strict_dry_run']; print('Anker-Fehler:', rep['anchor_failures']['count'], '| strenger Trockenlauf:', 'OK' if sd['ok'] else sd['exception']); print('Overlay-Integritaet ok:', rep['overlay_integrity'].get('ok'))
