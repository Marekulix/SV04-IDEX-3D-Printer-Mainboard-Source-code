#!/usr/bin/env python3
"""Belegmatrix zum X_MAX-/T1-Interlock aus den ECHTEN Quellen (Configuration.h, Configuration_adv.h, motion.cpp, endstops.h, G28.cpp).
Jede Zeile trennt strikt: QUELLENBELEG (Datei:Zeile, maschinell gefunden) / ANNAHME (was die vorhandenen Quellen NICHT hergeben) / HIL (was nur am Geraet geklaert werden kann).
Aufruf: python3 tools/endstop_evidence.py --cfg Configuration.h --adv Configuration_adv.h --motion motion.cpp --endstops endstops.h --g28 G28.cpp --out-json X.json --out-md X.md"""
import argparse, json, re, sys
from pathlib import Path


def find(text, rx):
    for i, l in enumerate(text.split('\n'), 1):
        if re.search(rx, l): return i
    return None


def build(cfg, adv, motion, endstops, g28):
    S = {'Configuration.h': cfg, 'Configuration_adv.h': adv, 'motion.cpp': motion, 'endstops.h': endstops, 'G28.cpp': g28}
    q = lambda f, rx: (lambda ln: {'file': f, 'line': ln, 'found': ln is not None})(find(S[f], rx))
    rows = [
     ('Platinentyp laut Konfiguration', [q('Configuration.h', r'^\s*#define MOTHERBOARD BOARD_CREALITY_V4\b')], 'Die Konfiguration waehlt BOARD_CREALITY_V4 (nicht V5.2.1); die zugehoerige Pinbelegung (pins_CREALITY_V4.h) liegt NICHT vor.', 'Platine und Aufdruck am Geraet pruefen'),
     ('X_MAX-Schalter ist aktiviert', [q('Configuration.h', r'^\s*#define USE_XMAX_PLUG\b')], 'Dass der Pin existiert (PIN_EXISTS(X_MAX)) haengt von der Pinbelegung ab; in CI 18 wurde der Ausdruck mit PIN_EXISTS(X_MAX) in LCD_RTS.cpp kompiliert, also ist X_MAX_PIN dort gesetzt (siehe Probe: X_MAX_PIN vorhanden).', 'Pinnummer gegen Schaltplan'),
     ('Polaritaet: gedrueckt = Pegel LOW (INVERTING=true)', [q('Configuration.h', r'^\s*#define X_MAX_ENDSTOP_INVERTING true')], 'Marlins Endstops::update bildet ausgeloest als READ(pin) != INVERTING; endstops.cpp liegt NICHT vor (nur endstops.h). Annahme aus Marlin-Standardverhalten.', 'Pegel am Pin messen: gedrueckt/losgelassen'),
     ('Pull-up aktiv (offener Kontakt = HIGH = nicht ausgeloest)', [q('Configuration.h', r'^\s*#define ENDSTOPPULLUPS\b')], 'Dass Endstops::init() daraus SET_INPUT_PULLUP macht, steht in endstops.cpp (nicht vorhanden); Marlin-Standard. Daraus folgt (Annahme): Kabelbruch liest HIGH = NICHT ausgeloest -> Pruefung verweigert.', 'Kabel abziehen und Pegel lesen (ohne Bewegung)'),
     ('T0 referenziert nach links (X_MIN)', [q('Configuration.h', r'^\s*#define X_HOME_DIR -1')], 'T1 referenziert nach rechts; X2_HOME_DIR steht in Configuration_adv.h bzw. wird von Marlin fuer DXC gesetzt (hier nicht gefunden).', 'Referenzfahrt beobachten (ohne Automatik)'),
     ('Soft-Endstops von T0: bei save_dual_x_carriage_mode 1 oder 4 bis dual_max_x (X2_MAX_POS=362)', [q('motion.cpp', r'const float dual_max_x = _MAX\(hotend_offset\[1\]\.x, X2_MAX_POS\)'), q('motion.cpp', r'soft_endstop\.max\.x = dual_max_x')], 'Die genaue Zuordnung der Modi 1/4 zu Sovols save_dual_x_carriage_mode ist OEM-spezifisch; der Quelltext zeigt nur den Vergleich.', 'Modus am Geraet auslesen (M-Befehl ohne Bewegung)'),
     ('Anfangswert inactive_extruder_x = X2_MAX_POS (schon vor der Referenzfahrt)', [q('motion.cpp', r'inactive_extruder_x\s*=\s*X2_MAX_POS')], 'Die Buchfuehrung beweist daher nichts ueber die physische Lage.', '-'),
     ('hotend_offset[1].x = MAX(X2_HOME_POS, X2_MAX_POS)', [q('motion.cpp', r'hotend_offset\[1\]\.x = _MAX\(X2_HOME_POS, X2_MAX_POS\)')], '-', '-'),
     ('G28: T1 (X2) wird vor T0 referenziert, T1 bleibt auf dem Schalter (kein Rueckzug)', [q('G28.cpp', r'active_extruder = 1;'), q('Configuration_adv.h', r'^\s*//\s*#define HOMING_BACKOFF_POST_MM')], 'Kein Post-Homing-Backoff laut Configuration_adv.h (auskommentiert); ob die OEM-G28 intern doch zurueckfaehrt: aus dem G28-Text nicht ersichtlich (kein Backoff-Aufruf gefunden).', 'Schalterpegel nach G28 lesen'),
     ('endstops.h kennt X2_MIN/X2_MAX als getrennte Eintraege (HAS_X2_MIN/HAS_X2_MAX)', [q('endstops.h', r'_ES_ITEM\(HAS_X2_MAX, X2_MAX\)')], 'Ob diese Platine einen EIGENEN X2-Endstop-Pin hat (dann waere X_MAX nicht der Schalter von T1!), entscheidet die Pinbelegung (nicht vorhanden). v17 nimmt an: X_MAX_PIN ist der Schalter von T1.', 'KRITISCH: Verdrahtung pruefen, welcher Schalter T1 ausloest'),
     ('X_MAX ist EIN Schalter fuer BEIDE Schlitten (T0 kann ihn bei Modus 1/4 bei 362 beruehren)', [q('motion.cpp', r'soft_endstop\.max\.x = dual_max_x')], 'Deshalb Stand 17: zusaetzlich gefuehrte T0-X <= X_MAX_POS (NaN verweigert). Auch das ist Buchfuehrung, aber unabhaengig vom Schalter.', 'Mechanisch: kann T0 den Schalter erreichen?'),
    ]
    out = []
    for name, ev, ann, hil in rows: out.append({'aussage': name, 'quellenbeleg': ev, 'beleg_vollstaendig': all(e['found'] for e in ev), 'annahme': ann, 'hil': hil})
    missing = ['Marlin/src/module/endstops.cpp (Endstops::update, init, DXC-Zuordnung)', 'Marlin/src/pins/stm32f1/pins_CREALITY_V4.h (X_MAX_PIN, X2_*_PIN, EEPROM-Typ)', 'Marlin/src/HAL/STM32F1/fastio.h (READ)']
    return {'rows': out, 'quellen_fehlen': missing, 'alle_belege_gefunden': all(r['beleg_vollstaendig'] for r in out)}


def render_md(r):
    L = ['# T1-/X_MAX-Belegmatrix (maschinell aus den ECHTEN Quellen, `tools/endstop_evidence.py`)', '', 'Strikte Trennung: **Quellenbeleg** = im echten Quelltext gefunden (Datei:Zeile); **Annahme** = folgt NICHT aus den vorhandenen Quellen; **HIL** = nur am Geraet klaerbar. **Kein Punkt dieser Tabelle ist eine Kollisionssicherheitsgarantie.**', '',
         '| Aussage | Quellenbeleg | Annahme (nicht belegt) | HIL |', '|---|---|---|---|']
    for x in r['rows']: L.append(f"| {x['aussage']} | " + '; '.join(f"{e['file']}:{e['line']}" if e['found'] else f"{e['file']}: NICHT GEFUNDEN" for e in x['quellenbeleg']) + f" | {x['annahme']} | {x['hil']} |")
    L += ['', '## Fehlende Quellen (der naechste Lauf von Workflow 19 sammelt sie, sobald die Sammelliste sie enthaelt)', ''] + [f'- {m}' for m in r['quellen_fehlen']]
    return '\n'.join(L) + '\n'


def main():
    ap = argparse.ArgumentParser()
    for k in ('cfg', 'adv', 'motion', 'endstops', 'g28'): ap.add_argument('--' + k, type=Path, required=True)
    ap.add_argument('--out-json', type=Path); ap.add_argument('--out-md', type=Path); a = ap.parse_args()
    r = build(*(getattr(a, k).read_text(encoding='utf-8') for k in ('cfg', 'adv', 'motion', 'endstops', 'g28')))
    if a.out_json: a.out_json.write_text(json.dumps(r, indent=1, ensure_ascii=False), encoding='utf-8')
    if a.out_md: a.out_md.write_text(render_md(r), encoding='utf-8')
    print('Belege vollstaendig:', r['alle_belege_gefunden']); return 0 if r['alle_belege_gefunden'] else 1


if __name__ == '__main__': sys.exit(main())
