#!/usr/bin/env python3
"""VP-Konfliktmatrix aus dem ECHTEN LCD_RTS.h/.cpp (baut auf tools/dwin_map.py auf). Jede Aussage mit Quellstelle.
  * Alias: mehrere Namen auf derselben Adresse;  * Familie: Adressbereich base + stride*i (z. B. 16 Messpunkte), abgeleitet aus den (auch auskommentierten) NNPOINT_VP-Definitionen;
  * Taste-in-Familie: eine Tastenadresse (Addrbuf) liegt in einem Wertebereich;  * Overlay-Nutzung: der vom Overlay EINGEFUEGTE Code darf nur bereits vorhandene VPs verwenden.
  --check 0x....  prueft eine VORGESCHLAGENE Adresse gegen die Karte. Das Werkzeug SCHLAEGT NIE eine Adresse vor und kann nicht belegen, dass eine Adresse im Display-Projekt frei ist.
Aufruf: python3 tools/dwin_conflicts.py --h LCD_RTS.h --cpp LCD_RTS.cpp [--patched LCD_RTS_patched.cpp --patched-g29 G29_patched.cpp] [--check 0x1234] --out-json X.json --out-md X.md"""
import argparse, collections, json, re, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent)); import dwin_map as D


def inserted_text(orig, patched):
    import difflib
    a, b = orig.split('\n'), patched.split('\n'); out = []
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
        if tag in ('insert', 'replace'): out += [(j + 1, b[j]) for j in range(j1, j2)]
    return out


def analyze(h, c, patched=None):
    m = D.parse(h, c); allv = dict(m['vps']); allc = m['vps_commented_out']
    by_addr = collections.defaultdict(list)
    for n, v in list(allv.items()) + [(n, v) for n, v in allc.items()]: by_addr[v['addr']].append({'name': n, 'line': v['line'], 'active': n in allv})
    alias = {hex(a): xs for a, xs in by_addr.items() if len({x['name'] for x in xs}) > 1}
    fam = collections.defaultdict(list)
    for n, v in list(allv.items()) + list(allc.items()):
        mm = re.fullmatch(r'(\w+?)_(\d+)POINT_VP', n)
        if mm: fam[mm.group(1)].append((int(mm.group(2)), v['addr'], v['line']))
    families = []
    for base, xs in fam.items():
        xs.sort(); strides = {xs[i + 1][1] - xs[i][1] for i in range(len(xs) - 1)}
        families.append({'prefix': base, 'count': len(xs), 'first': xs[0][1], 'last': xs[-1][1], 'stride': sorted(strides), 'regular': len(strides) == 1 and [x[0] for x in xs] == list(range(1, len(xs) + 1)), 'lines': [xs[0][2], xs[-1][2]],
                         'arithmetic_uses': [i + 1 for i, l in enumerate(c.split('\n')) if re.search(re.escape(base) + r'_1POINT_VP\s*\+', l)][:6]})
    key_in_family = []
    for k in m['keys']:
        if k['addr'] is None: continue
        for f in families:
            if f['first'] <= k['addr'] <= f['last']: key_in_family.append({'key': k['key'], 'addr': k['addr'], 'family': f['prefix'], 'point': (k['addr'] - f['first']) // f['stride'][0] + 1 if f['stride'] else None, 'exact_slot': (k['addr'] - f['first']) % f['stride'][0] == 0 if f['stride'] else None})
    key_vs_vp = [{'key': k['key'], 'addr': k['addr'], 'vp_names': [x['name'] for x in by_addr.get(k['addr'], [])]} for k in m['keys'] if k['addr'] in by_addr]
    overlay = None
    if patched:
        used, bad = set(), []
        known = set(allv) | set(allc)
        for name, (orig_text, patched_text) in patched.items():
            for ln, text in inserted_text(orig_text, patched_text):
                code = re.sub(r'//.*$', '', text)
                for tok in re.findall(r'\b[A-Z0-9_]+_VP\b', code): used.add(tok); bad += [(name, ln, tok)] if tok not in known else []
                for hx in re.findall(r'\b0[xX]1[0-9A-Fa-f]{3}\b', code): bad.append((name, ln, hx))   # keine eigenen Adressliterale
        overlay = {'vps_used_by_inserted_code': sorted(used), 'unknown_or_literal': bad, 'only_existing_vps': not bad}
    return {'map_problems': m['problems'], 'alias': alias, 'families': families, 'keys_inside_value_families': key_in_family, 'keys_equal_to_a_vp_define': key_vs_vp, 'overlay_use': overlay, '_map': m, '_by_addr': {hex(a): xs for a, xs in by_addr.items()}}


def check(r, addr):
    a = int(addr, 0); issues = []; ba = r['_by_addr'].get(hex(a))
    if ba: issues.append(f"Adresse ist schon als VP definiert: {', '.join(x['name'] for x in ba)} (Zeile {ba[0]['line']})")
    for k in r['_map']['keys']:
        if k['addr'] == a: issues.append(f"Adresse ist Tastenadresse {k['key']} (Addrbuf-Index {k['index']})")
    for f in r['families']:
        if f['first'] <= a <= f['last'] + 1: issues.append(f"Adresse liegt im Bereich der Familie {f['prefix']} ({hex(f['first'])} bis {hex(f['last'])}, Schritt {f['stride']}); Zweiwort-Werte belegen auch die Folgeadresse")
    return {'address': hex(a), 'conflicts_in_known_map': issues, 'verdict': 'KONFLIKT in der bekannten Karte' if issues else 'kein Konflikt in der bekannten Karte (NICHT belegt, dass sie im Display-Projekt frei ist)'}


def render_md(r):
    L = ['# DWIN VP-Konfliktmatrix (maschinell aus dem ECHTEN LCD_RTS, `tools/dwin_conflicts.py`)', '', 'Nur Quellenfakten. Das Display-Projekt (T5UID1/DGUS) liegt NICHT vor; eine Adresse, die hier "frei" erscheint, ist damit nicht als frei im Display belegt.', '']
    L += ['## Alias (mehrere Namen, eine Adresse)', ''] + (['| Adresse | Namen (Zeile) |', '|---|---|'] + [f"| `{a}` | " + ', '.join(f"{x['name']} ({x['line']}{'' if x['active'] else ', auskommentiert'})" for x in xs) + ' |' for a, xs in r['alias'].items()] if r['alias'] else ['keine'])
    L += ['', '## Adressfamilien (Wertebereiche)', '', '| Familie | Anzahl | von | bis | Schritt | regulaer | Zeilen | Nutzung per Arithmetik (cpp-Zeilen) |', '|---|---|---|---|---|---|---|---|']
    L += [f"| `{f['prefix']}_nPOINT_VP` | {f['count']} | `0x{f['first']:04X}` | `0x{f['last']:04X}` | {f['stride']} | {f['regular']} | {f['lines']} | {f['arithmetic_uses']} |" for f in r['families']]
    L += ['', '## Tastenadressen im Wertebereich einer Familie', ''] + (['| Taste | Adresse | Familie | entspricht Punkt | genau auf Wertplatz |', '|---|---|---|---|---|'] + [f"| `{k['key']}` | `0x{k['addr']:04X}` | {k['family']} | {k['point']} | {k['exact_slot']} |" for k in r['keys_inside_value_families']] if r['keys_inside_value_families'] else ['keine'])
    L += ['', '## Tastenadressen, die zugleich als VP-Name definiert sind', ''] + (['| Taste | Adresse | VP-Namen |', '|---|---|---|'] + [f"| `{k['key']}` | `0x{k['addr']:04X}` | {', '.join(k['vp_names'])} |" for k in r['keys_equal_to_a_vp_define']] if r['keys_equal_to_a_vp_define'] else ['keine'])
    o = r['overlay_use']
    if o: L += ['', '## Overlay-Nutzung (nur der EINGEFUEGTE Code)', '', f"Verwendete VPs: {', '.join(o['vps_used_by_inserted_code']) or 'keine'}. Unbekannte VP-Namen oder eigene Adressliterale: **{len(o['unknown_or_literal'])}**. Ergebnis: **{'nur vorhandene OEM-VPs' if o['only_existing_vps'] else 'VERLETZT'}**."]
    return '\n'.join(L) + '\n'


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--h', type=Path, required=True); ap.add_argument('--cpp', type=Path, required=True); ap.add_argument('--check'); ap.add_argument('--out-json', type=Path); ap.add_argument('--out-md', type=Path); a = ap.parse_args()
    r = analyze(a.h.read_text(encoding='utf-8'), a.cpp.read_text(encoding='utf-8'))
    if a.check: print(json.dumps(check(r, a.check), ensure_ascii=False, indent=1))
    pub = {k: v for k, v in r.items() if not k.startswith('_')}
    if a.out_json: a.out_json.write_text(json.dumps(pub, indent=1, ensure_ascii=False), encoding='utf-8')
    if a.out_md: a.out_md.write_text(render_md(r), encoding='utf-8')
    return 0


if __name__ == '__main__': sys.exit(main())
