#!/usr/bin/env python3
"""D1-Analyse am ECHTEN settings.cpp: belegt Zeile fuer Zeile, wie MarlinSettings::save()/validate()/load() mit Unterbrechung und Fehlern umgehen.
Jede Tatsache wird per Textmuster im Quelltext gesucht (mit Zeilennummer); die Schlussfolgerung wird NUR aus den gefundenen Tatsachen abgeleitet.
Aufruf: python3 tools/eeprom_audit.py --settings settings.cpp [--configuration Configuration.h] --out-json docs/D1_EEPROM_FAKTEN.json"""
import argparse, json, re, sys
from pathlib import Path


def find(lines, rx, start=1, end=None):
    end = end or len(lines)
    for i in range(start - 1, end):
        if re.search(rx, lines[i]): return i + 1
    return None


def audit(settings: str, configuration: str = ''):
    L = settings.split('\n'); f = {}
    save0 = find(L, r'bool MarlinSettings::save\(\)'); val0 = find(L, r'bool MarlinSettings::validate\(\)'); load0 = find(L, r'bool MarlinSettings::load\(\)')
    save1 = val_end = None
    if save0:
        nxt = find(L, r'^\s*/\*\*\s*$', save0 + 1)   # naechster Kommentarblock nach save() ist M501-Doku
        save1 = find(L, r'M501 - Retrieve Configuration', save0) or (nxt or len(L))
    def fact(name, rx, lo, hi, what):
        ln = find(L, rx, lo, hi) if lo else None; f[name] = {'found': ln is not None, 'line': ln, 'what': what}
    fact('version_placeholder_ERR', r'char ver\[4\]\s*=\s*"ERR"', save0, save1, 'save() legt den Platzhalter-Header "ERR" an')
    fact('header_written_first_unless_flash', r'TERN\(FLASH_EEPROM_EMULATION,\s*EEPROM_SKIP,\s*EEPROM_WRITE\)\(ver\)', save0, save1, 'ohne Flash-Emulation wird "ERR" ZUERST an EEPROM_OFFSET geschrieben')
    fact('crc_slot_skipped', r'EEPROM_SKIP\(working_crc\)', save0, save1, 'der CRC-Platz bleibt zunaechst unbeschrieben (alter Wert)')
    fact('mesh_written_in_save', r'EEPROM_WRITE\(z_values\)', save0, save1, 'das bilineare Mesh wird nur als Teil des gesamten Einstellungsblocks gespeichert')
    ok_ln = find(L, r'if \(!eeprom_error\)\s*\{', (f['crc_slot_skipped']['line'] or save0 or 1), save1); f['final_header_only_without_error'] = {'found': ok_ln is not None, 'line': ok_ln, 'what': 'echte Version und CRC werden nur geschrieben, wenn waehrend des Speicherns KEIN Fehler auftrat'}
    wv = find(L, r'EEPROM_WRITE\(version\)', ok_ln or 1, save1); wc = find(L, r'EEPROM_WRITE\(final_crc\)', ok_ln or 1, save1); f['final_header_written_last'] = {'found': bool(wv and wc and ok_ln and wv > ok_ln), 'line': wv, 'what': 'Version und CRC werden als LETZTES geschrieben (nach allen Daten)'}
    fin = find(L, r'EEPROM_FINISH\(\)', wc or 1, save1); f['finish_after_header'] = {'found': fin is not None, 'line': fin, 'what': 'EEPROM_FINISH() folgt dem Header'}
    ver_ln = find(L, r'strncmp\(version, stored_ver, 3\) != 0'); f['load_version_mismatch_is_error'] = {'found': ver_ln is not None, 'line': ver_ln, 'what': 'abweichende Version beim Laden ist ein Fehler'}
    crc_ln = find(L, r'working_crc != stored_crc'); f['load_crc_mismatch_is_error'] = {'found': crc_ln is not None, 'line': crc_ln, 'what': 'abweichende CRC beim Laden ist ein Fehler'}
    pp = find(L, r'if \(!validating && !eeprom_error\) postprocess\(\)'); f['validate_does_not_apply_data'] = {'found': pp is not None, 'line': pp, 'what': 'validate() prueft nur (Version, Groesse, CRC); es uebernimmt keine Daten in den RAM'}
    v = val0 and find(L, r'validating = true;', val0, val0 + 12); f['validate_is_readonly_check'] = {'found': bool(v), 'line': v, 'what': 'validate() = _load() mit validating=true (nur lesend)'}
    rs = find(L, r'^\s*reset\(\);', load0, (load0 or 1) + 14) if load0 else None; f['failed_load_resets_everything'] = {'found': rs is not None, 'line': rs, 'what': 'ungueltiger EEPROM -> reset(): ALLE Einstellungen fallen auf die Konfigurationswerte zurueck'}
    auto = None
    if configuration:
        C = configuration.split('\n'); a = find(C, r'^\s*//\s*#define\s+EEPROM_AUTO_INIT'); auto = {'found': a is not None, 'line': a, 'what': 'EEPROM_AUTO_INIT ist AUSkommentiert: nach dem Zuruecksetzen wird NICHT automatisch neu gespeichert'}
    if auto is not None: f['auto_init_disabled'] = auto
    must = ['version_placeholder_ERR', 'header_written_first_unless_flash', 'final_header_only_without_error', 'final_header_written_last', 'load_version_mismatch_is_error', 'failed_load_resets_everything', 'validate_is_readonly_check', 'validate_does_not_apply_data']
    complete = all(f[k]['found'] for k in must)
    concl = {'all_required_facts_found': complete,
             'failed_or_interrupted_save_invalidates_stored_image': complete,   # Header zuerst "ERR", echter Header nur nach fehlerfreiem Schreiben
             'old_mesh_survives_failed_save': not complete,
             'consequence_if_invalid': 'beim naechsten Start wird NICHT nur das Mesh, sondern der GESAMTE Einstellungsblock verworfen (reset() auf Konfigurationswerte, ohne EEPROM_AUTO_INIT keine Neuspeicherung)',
             'readback_possible': bool(f['validate_is_readonly_check']['found']),
             'readback_strength': 'validate() bestaetigt nur Version, Groesse und CRC des gespeicherten Abbilds; es vergleicht NICHT das Mesh mit dem RAM',
             'catalog_clause_never_overwrite_old_mesh_on_error': 'NICHT erfuellbar mit settings.save()' if complete else 'unbelegt',
             'backend': 'UNVERIFIZIERT: Configuration.h legt den EEPROM-Typ nicht fest; er kommt aus der Board-Pinbelegung (nicht im Nachweis). Ob I2C-EEPROM (Seitenschreiben, sequenziell) oder Flash-Emulation (Seite loeschen+schreiben): unbekannt; beide sind nicht atomar gegenueber Stromausfall.'}
    return {'facts': f, 'conclusion': concl}


def render_md(r):
    c = r['conclusion']; L = ['# D1: EEPROM-Persistenz, belegt am ECHTEN `settings.cpp` (maschinell, `tools/eeprom_audit.py`)', '', '**Ergebnis: die Katalogklausel "Fehler ueberschreiben das alte Mesh nie" ist mit `settings.save()` NICHT erfuellbar. D1 bleibt offen; es wird nichts verdrahtet.**', '',
         '| Tatsache | gefunden | Zeile | Bedeutung |', '|---|---|---|---|']
    for k, v in r['facts'].items(): L.append(f"| `{k}` | {'ja' if v['found'] else 'NEIN'} | {v['line'] or ''} | {v['what']} |")
    L += ['', '## Schlussfolgerung (nur aus den gefundenen Tatsachen abgeleitet)', '']
    for k, v in c.items(): L.append(f'- **{k}**: {v}')
    L += ['', '## Was daraus folgt', '', '1. Ein fehlgeschlagener ODER unterbrochener `M500` hinterlaesst den Platzhalter-Header `"ERR"`: beim naechsten Start gilt der EEPROM als ungueltig, **alle** gespeicherten Einstellungen (auch ein kalibrierter Z-Offset, Schrittzahlen, PID) fallen auf die Konfigurationswerte zurueck. Das ist ein Risiko des OEM-Speicherns insgesamt, nicht nur des Meshs.',
          '2. Solange kein Stromausfall mitten im Speichern passiert, bleibt der RAM gueltig; ein fehlgeschlagenes `save()` kann wiederholt werden. Das ist ein Mitigationsgedanke, keine Garantie.',
          '3. `validate()` kann nach dem Speichern als Pruefung der Abbild-Konsistenz dienen, ersetzt aber keine atomare Wiederherstellung.',
          '4. Deshalb: die Auto60-Maschine endet in `DoneRamOnly` (nur RAM). Das Persistieren bleibt eine bewusste Handlung des Nutzers (OEM-Taste bzw. `M500`) nach Sichtpruefung des Meshs. Ein automatischer Commit waere nur mit einem echten Doppelpuffer-/Zweiseiten-Konzept verantwortbar, das hier nicht existiert.', '']
    return '\n'.join(L)


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--settings', type=Path, required=True); ap.add_argument('--configuration', type=Path); ap.add_argument('--out-json', type=Path); ap.add_argument('--out-md', type=Path); a = ap.parse_args()
    r = audit(a.settings.read_text(encoding='utf-8'), a.configuration.read_text(encoding='utf-8') if a.configuration else '')
    if a.out_json: a.out_json.write_text(json.dumps(r, indent=1, ensure_ascii=False), encoding='utf-8')
    if a.out_md: a.out_md.write_text(render_md(r), encoding='utf-8')
    print(json.dumps(r['conclusion'], ensure_ascii=False, indent=1)[:900]); return 0 if r['conclusion']['all_required_facts_found'] else 1


if __name__ == '__main__': sys.exit(main())
