#!/usr/bin/env python3
"""Erreichbarkeits- und Inertheitsanalyse eines gebauten Binaries (ELF) aus `objdump -d -C --no-show-raw-insn` und `nm -C -S`.
Zweck (Auftrag P0): scheinbar gruene, aber TOTE oder INAKTIVE Funktionalitaet nicht als Integration ausgeben. Ein Compile- und Link-Erfolg beweist nur, dass Code uebersetzt wurde;
dieses Werkzeug beantwortet: Ist ein Symbol im fertigen Binary vorhanden (nach gc-sections)? Ist es vom OEM-Einstieg (z. B. RTSUpdate, GcodeSuite::G29) ueber direkte Aufrufe erreichbar? Gibt es
gar keinen Aufrufer (kein Starttrigger)?
GRENZEN (werden im Bericht ausgewiesen): nur DIREKTE Sprung-/Aufrufkanten (bl, b.w, call, jmp); indirekte Aufrufe (Funktionszeiger, virtuelle Methoden, blx Rx) und per Literal-Pool geladene Adressen
werden NICHT verfolgt; kleine Funktionen koennen weginlint sein (Symbol dann nicht separat vorhanden, Code aber durchaus vorhanden). 'absent' (Symbol fehlt komplett) ist der belastbarste Befund.
Aufruf: python3 tools/reach_analyze.py --objdump dis.txt [--nm nm.txt] --profile overlay|overlay-auto60|baseline|FILE.json --out-json reach.json --out-md reach.md   (Exit 1 bei verletzter Erwartung)
"""
import argparse, collections, json, re, sys
from pathlib import Path
HDR = re.compile(r'^[0-9a-fA-F]+ <(.+)>:\s*$')
INS = re.compile(r'^\s*[0-9a-fA-F]+:\s*(?:[0-9a-fA-F]{2,8}(?: [0-9a-fA-F]{2,8})*\s+)?([a-zA-Z][\w.]*)\s*(.*)$')
TGT = re.compile(r'<([^<>]+?)(?:\+0x[0-9a-fA-F]+)?>')
BRANCH = re.compile(r'^(bl|blx|b|b\.w|b\.n|bx|call|jmp|tail|j[a-z]+|b[a-z]{2}(?:\.[nw])?|cb[n]?z(?:\.[nw])?)$')


def parse_objdump(text: str):
    funcs, edges, cur = set(), collections.defaultdict(set), None
    for line in text.splitlines():
        m = HDR.match(line)
        if m: cur = m.group(1); funcs.add(cur); continue
        if cur is None: continue
        m = INS.match(line)
        if not m: continue
        mn, ops = m.group(1), m.group(2)
        if not BRANCH.match(mn): continue
        t = TGT.search(ops)
        if not t: continue
        tgt = t.group(1)
        if tgt != cur and not (tgt.startswith(cur) and '+0x' in ops and TGT.search(ops).group(0).startswith('<' + cur)): edges[cur].add(tgt)
    return funcs, edges


def parse_nm(text: str):
    syms = {}
    for line in text.splitlines():
        p = line.split(None, 3)
        if len(p) == 4 and re.fullmatch(r'[0-9a-fA-F]+', p[0]) and re.fullmatch(r'[0-9a-fA-F]+', p[1]) and len(p[2]) == 1: syms[p[3]] = {'addr': p[0], 'size': int(p[1], 16), 'type': p[2]}
        elif len(p) == 3 and re.fullmatch(r'[0-9a-fA-F]+', p[0]) and len(p[1]) == 1: syms[p[2]] = {'addr': p[0], 'size': 0, 'type': p[1]}
    return syms


def bfs(edges, roots):
    prev, queue, seen = {}, collections.deque(roots), set(roots)
    while queue:
        a = queue.popleft()
        for b in sorted(edges.get(a, ())):
            if b not in seen: seen.add(b); prev[b] = a; queue.append(b)
    return seen, prev


def path_to(prev, roots, target):
    p = [target]
    while p[-1] in prev: p.append(prev[p[-1]])
    return list(reversed(p)) if p[-1] in roots else []


def analyze(funcs, edges, syms, profile):
    allnames = set(funcs) | set(syms)
    rootsets = {k: {f for f in funcs if re.search(rx, f)} for k, rx in profile.get('roots', {}).items()}
    reach = {k: bfs(edges, r) for k, r in rootsets.items()}
    callers = collections.defaultdict(set)
    for a, bs in edges.items():
        for b in bs: callers[b].add(a)
    results, ok = [], True
    for chk in profile['checks']:
        rx = re.compile(chk['regex']); hits = sorted(n for n in allnames if rx.search(n)); kind = chk['expect']; entry = dict(chk, hits=hits[:6], hit_count=len(hits), passed=True, note='')
        if kind == 'present': entry['passed'] = bool(hits)
        elif kind == 'absent': entry['passed'] = not hits
        elif kind.startswith('reachable_from:'):
            root = kind.split(':', 1)[1]; seen, prev = reach.get(root, (set(), {})); found = [h for h in hits if h in seen]; entry['passed'] = bool(found)
            if found: entry['path'] = path_to(prev, rootsets[root], found[0])
            entry['note'] = '' if rootsets.get(root) else f'Wurzel {root!r} nicht gefunden'
        elif kind == 'no_callers':
            real = {h: sorted(callers.get(h, ())) for h in hits}; entry['passed'] = all(not v for v in real.values()); entry['callers'] = {k: v[:5] for k, v in real.items() if v}
        results.append(entry); ok &= entry['passed']
    return results, ok, {k: sorted(v)[:3] for k, v in rootsets.items()}


PROFILES = {
 'baseline': {'roots': {'RTSUpdate': r'^RTSUpdate\(', 'G29': r'^GcodeSuite::G29\('}, 'checks': [
    {'name': 'kein Overlay-Objekt im Binary', 'regex': r'sv04next::', 'expect': 'absent'}, {'name': 'RTSUpdate vorhanden (OEM)', 'regex': r'^RTSUpdate\(', 'expect': 'present'}]},
 'overlay': {'roots': {'RTSUpdate': r'^RTSUpdate\(', 'G29': r'^GcodeSuite::G29\('}, 'checks': [
    {'name': 'G29 vorhanden', 'regex': r'^GcodeSuite::G29\(', 'expect': 'present'}, {'name': 'RTSUpdate vorhanden', 'regex': r'^RTSUpdate\(', 'expect': 'present'},
    {'name': 'G29-U-Beleg (Objekt) gelinkt', 'regex': r'sv04next::g29u_receipt$', 'expect': 'present'}, {'name': 'Thermotor (Objekt) gelinkt', 'regex': r'sv04next::native_thermal_gate$', 'expect': 'present'},
    {'name': 'T1-Endstop-Beobachter (Objekt) gelinkt', 'regex': r'sv04next::t1_endstop_observer$', 'expect': 'present'},
    {'name': 'Auto60-Maschine NICHT im Standard-Overlay', 'regex': r'sv04next::auto60_engine$', 'expect': 'absent'}, {'name': 'Auto60 tick NICHT im Standard-Overlay', 'regex': r'Auto60Engine::tick', 'expect': 'absent'},
    {'name': 'kein Startpfad der Maschine (request_start)', 'regex': r'Auto60Engine::request_start|auto60_request_start', 'expect': 'absent'}]},
 'overlay-auto60': {'roots': {'RTSUpdate': r'^RTSUpdate\(', 'G29': r'^GcodeSuite::G29\('}, 'checks': [
    {'name': 'G29 vorhanden', 'regex': r'^GcodeSuite::G29\(', 'expect': 'present'}, {'name': 'RTSUpdate vorhanden', 'regex': r'^RTSUpdate\(', 'expect': 'present'},
    {'name': 'Auto60-Maschine (Objekt) gelinkt', 'regex': r'sv04next::auto60_engine$', 'expect': 'present'}, {'name': 'Auto60 tick gelinkt', 'regex': r'Auto60Engine::tick', 'expect': 'present'},
    {'name': 'Auto60 tick von RTSUpdate aus erreichbar (Bedienung einer laufenden Maschine)', 'regex': r'Auto60Engine::tick|auto60_glue_tick', 'expect': 'reachable_from:RTSUpdate'},
    {'name': 'KEIN Startpfad: request_start/auto60_request_start nicht im Binary', 'regex': r'Auto60Engine::request_start|auto60_request_start', 'expect': 'absent'},
    {'name': 'falls doch vorhanden: ohne Aufrufer', 'regex': r'Auto60Engine::request_start|auto60_request_start', 'expect': 'no_callers'}]},
}


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--objdump', required=True); ap.add_argument('--nm'); ap.add_argument('--profile', required=True); ap.add_argument('--out-json'); ap.add_argument('--out-md'); a = ap.parse_args()
    prof = PROFILES.get(a.profile) or json.loads(Path(a.profile).read_text(encoding='utf-8'))
    funcs, edges = parse_objdump(Path(a.objdump).read_text(encoding='utf-8', errors='replace')); syms = parse_nm(Path(a.nm).read_text(encoding='utf-8', errors='replace')) if a.nm else {}
    res, ok, roots = analyze(funcs, edges, syms, prof)
    rep = {'profile': a.profile, 'functions': len(funcs), 'edges': sum(len(v) for v in edges.values()), 'nm_symbols': len(syms), 'roots': roots, 'all_expectations_met': ok, 'results': res,
           'limits': 'nur direkte Sprung-/Aufrufkanten; indirekte Aufrufe, Funktionszeiger, Literal-Pool-Adressen werden nicht verfolgt; Inlining kann Symbole verbergen'}
    if a.out_json: Path(a.out_json).write_text(json.dumps(rep, indent=1, ensure_ascii=False), encoding='utf-8')
    md = [f'# Erreichbarkeitsanalyse ({a.profile})', f'Funktionen {rep["functions"]}, direkte Kanten {rep["edges"]}, nm-Symbole {rep["nm_symbols"]}. **{"ALLE Erwartungen erfuellt" if ok else "ERWARTUNG VERLETZT"}**', '', '| Pruefung | Erwartung | Ergebnis | Treffer |', '|---|---|---|---|']
    for r in res: md.append(f"| {r['name']} | {r['expect']} | {'OK' if r['passed'] else 'VERLETZT'} | {r['hit_count']}: {', '.join(h[:60] for h in r['hits'][:2])} |")
    md += ['', 'Grenzen: ' + rep['limits']]
    if a.out_md: Path(a.out_md).write_text('\n'.join(md) + '\n', encoding='utf-8')
    print('\n'.join(md)); return 0 if ok else 1


if __name__ == '__main__': sys.exit(main())
