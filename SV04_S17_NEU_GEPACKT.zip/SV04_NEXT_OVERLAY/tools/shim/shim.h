// SHIM fuer Syntaxpruefung der GEPATCHTEN ECHTEN Dateien. KEIN Marlin. Bildet nur Praeprozessor-Makros und Basistypen nach.
#pragma once
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <stddef.h>
// --- Marlins Optionsmakros (leer oder 1 definiert = aktiv)
#define _ISENA_1 ,
#define _ISENA_ ,
#define _ISENA_true ,
#define _SEL2_(a, b, ...) b
#define _CAT_(a, b) a##b
#define _EN2_(V) _CAT_(_ISENA_, V)
#define _SEL2X_(...) _SEL2_(__VA_ARGS__)
#define _IS_(V) _SEL2X_(_EN2_(V) 1, 0, 0)
#define _ENX_(V) _IS_(V)
#define ENABLED(V) (_ENX_(V))
#define DISABLED(V) (!(_ENX_(V)))
#define EITHER(A, B) (ENABLED(A) || ENABLED(B))
#define BOTH(A, B) (ENABLED(A) && ENABLED(B))
#define _TERN_1(...) __VA_ARGS__
#define _TERN_0(...)
#define _TERNC_(c, ...) _CAT_(_TERN_, c)(__VA_ARGS__)
#define TERN_(O, V...) _TERNC_(_ENX_(O), V)
#define _TELSE_1(a, b) a
#define _TELSE_0(a, b) b
#define _TELSEC_(c, a, b) _CAT_(_TELSE_, c)(a, b)
#define TERN(O, A, B) _TELSEC_(_ENX_(O), A, B)
#define TERN0(O, A) TERN(O, A, 0)
#define TERN1(O, A) TERN(O, A, 1)
#define OPTARG(O, V...) TERN_(O, , V)
#define PIN_EXISTS(p) (defined(p##_PIN) && p##_PIN >= 0)
#define PSTR(s) s
#define STR_(x) #x
// --- Basistypen
typedef int16_t celsius_t; typedef float celsius_float_t;
/* wie in Marlin: xy_pos_t ist xy_float_t */ struct xy_float_t { float x, y; }; typedef xy_float_t xy_pos_t; struct xyz_pos_t { float x, y, z; }; struct xyz_float_t { float x, y, z; };
struct xy_int8_t { int8_t x, y; xy_float_t asFloat() const { return {(float)x, (float)y}; } };
enum AxisEnum : uint8_t { X_AXIS, Y_AXIS, Z_AXIS, E_AXIS };
#define _MIN(a, b) ((a) < (b) ? (a) : (b))
#define ABS(x) ((x) < 0 ? -(x) : (x))
#define SQRT(x) sqrtf(x)

#define _ANY1(a) ENABLED(a)
#define _ANY2(a, b) (ENABLED(a) || ENABLED(b))
#define _ANY3(a, b, c) (ENABLED(a) || ENABLED(b) || ENABLED(c))
#define _ANY4(a, b, c, d) (ENABLED(a) || ENABLED(b) || ENABLED(c) || ENABLED(d))
#define _ANY5(a, b, c, d, e) (_ANY4(a, b, c, d) || ENABLED(e))
#define _ANY6(a, b, c, d, e, f) (_ANY5(a, b, c, d, e) || ENABLED(f))
#define _ANY7(a, b, c, d, e, f, g) (_ANY6(a, b, c, d, e, f) || ENABLED(g))
#define _ANY8(a, b, c, d, e, f, g, h) (_ANY7(a, b, c, d, e, f, g) || ENABLED(h))
#define _PICKANY(_1, _2, _3, _4, _5, _6, _7, _8, N, ...) N
#define ANY(...) _PICKANY(__VA_ARGS__, _ANY8, _ANY7, _ANY6, _ANY5, _ANY4, _ANY3, _ANY2, _ANY1)(__VA_ARGS__)

// --- Deklarationen der vom EINGEFUEGTEN Code benutzten Marlin-Namen, Signaturen aus den ECHTEN Headern (motion.h, planner.h, probe.h, temperature.h, MarlinCore.h, queue.h, abl.h, bedlevel.h, LCD_RTS.h, gcode.h)
unsigned long millis(void);
extern uint8_t active_extruder;
inline bool axis_is_trusted(const AxisEnum axis) { return axis < 3; }
enum DualXMode : char { DXC_FULL_CONTROL_MODE = 0, DXC_AUTO_PARK_MODE = 1, DXC_DUPLICATION_MODE = 2, DXC_MIRRORED_MODE = 3 };
extern DualXMode dual_x_carriage_mode; extern float inactive_extruder_x;
#define X2_MAX_POS 362
inline bool IsStopped() { return false; } bool printJobOngoing(); bool printingIsPaused();
struct Temperature { static celsius_float_t degBed(); static celsius_t degTargetBed(); static void setTargetBed(const celsius_t celsius); }; extern Temperature thermalManager;
struct Planner { static bool leveling_active; static bool has_blocks_queued(); }; extern Planner planner;
enum ProbePtRaise : uint8_t { PROBE_PT_NONE, PROBE_PT_STOW, PROBE_PT_RAISE, PROBE_PT_BIG_RAISE };
struct Probe { static xyz_pos_t offset; static float probe_at_point(const xy_pos_t &pos, const ProbePtRaise raise_after = PROBE_PT_NONE, const uint8_t verbose_level = 0, const bool probe_relative = true, const bool sanity_check = true); static bool can_reach(float, float); }; extern Probe probe;
struct GCodeQueue { static bool enqueue_one_P(const char *const pgcode); static bool has_commands_queued(); }; extern GCodeQueue queue;
typedef float bed_mesh_t[GRID_MAX_POINTS_X][GRID_MAX_POINTS_Y];
extern xy_pos_t bilinear_grid_spacing, bilinear_start; extern bed_mesh_t z_values; void refresh_bed_level(); void set_bed_leveling_enabled(const bool enable = true);
#define VarAddr_W 0x82
struct String { const char *c; };
struct RTSSHOW { void RTS_SndData(void); void RTS_SndData(const String &, unsigned long, unsigned char = VarAddr_W); void RTS_SndData(const char[], unsigned long, unsigned char = VarAddr_W); void RTS_SndData(char, unsigned long, unsigned char = VarAddr_W);
  void RTS_SndData(unsigned char *, unsigned long, unsigned char = VarAddr_W); void RTS_SndData(int, unsigned long, unsigned char = VarAddr_W); void RTS_SndData(float, unsigned long, unsigned char = VarAddr_W);
  void RTS_SndData(unsigned int, unsigned long, unsigned char = VarAddr_W); void RTS_SndData(long, unsigned long, unsigned char = VarAddr_W); void RTS_SndData(unsigned long, unsigned long, unsigned char = VarAddr_W); }; extern RTSSHOW rtscheck;
#define AUTO_BED_LEVEL_ICON_VP 0x108D
#define AUTO_BED_LEVEL_1POINT_VP 0x1100
void RTS_AutoBedLevelPage(); void RTS_MoveAxisHoming(); extern void RTSUpdate();
struct GCodeParser { static bool seen_test(const char c); static bool boolval(const char c, const bool dflt = false); }; extern GCodeParser parser;
struct xyze_pos_t { float x, y, z, e; }; extern xyze_pos_t current_position;   // Stand 17: gefuehrte Position (motion.h)
bool shim_read_pin(int);
#define READ(p) (shim_read_pin(p))
#define SERIAL_ERROR_MSG(...) do {} while (0)
#define SERIAL_ECHOLNPGM(...) do {} while (0)
#define SERIAL_ECHO_MSG(...) do {} while (0)
