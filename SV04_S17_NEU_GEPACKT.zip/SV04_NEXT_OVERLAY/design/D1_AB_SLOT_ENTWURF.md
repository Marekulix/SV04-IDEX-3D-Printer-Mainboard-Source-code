# D1: A/B-Slot-Persistenz, ENTWURF (Stand 17)  |  NICHT verdrahtet, NICHT im Firmware-Build, NICHT freigegeben

Datei: `design/SV04NextMeshSlots.hpp`, Test: `tests/test_mesh_slots.cpp` (13 Pruefungen), Mutationen: `tools/mutate_slots.py` (7 von 10 erkannt, 3 redundant).

## Was belegt ist (Modell, byteweise beschreibbarer Speicher)
- Zwei Slots, Kopf (Magic, Version, Rastergroesse, Laenge, Folgenummer samt Gegenwert, CRC32) und Nutzdaten (16 Messwerte, Raster-Start, Raster-Abstand). Schreiben in den **anderen** Slot, **Kopf zuletzt**.
- **Absturz an jedem der 212 Schreibpunkte** (Byte nicht geschrieben und halb geschriebenes Muellbyte): immer genau das alte ODER das neue Mesh, das neue nur nach vollstaendigem Schreiben. Jeder Einzelbitfehler in beiden Slots: nie ein verfaelschtes Mesh. Andere Version/Rastergroesse mit korrektem CRC wird abgelehnt. Folgenummer mit Ueberlauf.
- Tragend (Mutant wird erkannt): CRC, A/B-Wechsel, Ueberlauf-Vergleich, Version, Rastergroesse, Ladereihenfolge, **Schreibreihenfolge** (mit Kopf zuerst kann das neue Mesh sichtbar werden, obwohl `save()` Misserfolg meldet). Redundant (CRC deckt sie ab): Magic, Gegenwert der Folgenummer, Laenge.

## Was NICHT belegt ist (darum bleibt D1 OFFEN)
1. **EEPROM-Backend und freier Bereich unbekannt.** `Configuration.h` waehlt `BOARD_CREALITY_V4`; die Pinbelegung (EEPROM-Typ, Groesse) liegt nicht vor. Nur bei byteweise beschreibbarem Medium (z. B. I2C) gilt das Modell; Flash-Emulation braucht ein anderes Verfahren. Wo ein eigener Bereich liegen duerfte (hinter `settings.datasize()`), ist unbekannt.
2. **Ladepfad beim Start fehlt**: nach `settings.load()` muesste ein eigener Code das Mesh laden, `bilinear_grid_*` setzen, `refresh_bed_level()` und `set_bed_leveling_enabled()` aufrufen. Das waere ein neuer Eingriff in OEM-Startcode.
3. **Zusammenspiel mit `M500`/`M501`/`M502`:** Marlins eigener Block bleibt davon unberuehrt, kann aber weiterhin bei unterbrochenem `M500` ALLE Einstellungen verlieren (siehe `docs/D1_EEPROM_ANALYSE.md`). Der Entwurf schuetzt nur das Mesh, nicht die uebrigen Einstellungen.
4. **Schreibdauer und Stromausfall am Geraet:** nicht gemessen. Das Modell kennt keine Seitenpuffer, keinen Erase, keine Mehrfachfehler.
5. Die Katalogklausel D1 verlangt einen **nativen** EEPROM-Commit mit Readback; der Entwurf ersetzt sie nicht.

## Voraussetzungen, bevor irgendetwas verdrahtet wird
Backend und Bereich aus der Pinbelegung belegen; HIL-Test mit echtem Stromausfall (ohne Heizen/Bewegen); Ladepfad als eigener, geprueft eingefuegter Patch; ausdrueckliche Freigabe. Bis dahin: **kein `M500` aus der Firmware**, Persistenz bleibt die bewusste Handlung des Nutzers.
