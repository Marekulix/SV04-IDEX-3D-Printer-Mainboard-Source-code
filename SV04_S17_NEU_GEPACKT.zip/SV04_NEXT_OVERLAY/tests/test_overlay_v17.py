"""Test der Patchschicht v17 (elektrische T1-Parkbestaetigung) gegen die ECHTEN OEM-Dateien. Stufe: SIMULATION/Text + Host-Kompilat des Sensor-Headers. KEIN Marlin-Build."""
import contextlib, difflib, io, json, os, subprocess, sys, tempfile
from pathlib import Path
root = Path(__file__).resolve().parents[1]; sys.path[:0] = [str(root / 'integration')]
import apply_native_guard_v16 as v16, apply_native_guard_v17 as v17
v14 = v16.v15.v14; real = root / 'tests/oem_real'; G29 = v17.G29; n = [0]
def ck(c, m=''): assert c, m; n[0] += 1
def refused(fn, *words):
    try: fn()
    except v17.PatchRefused as e:
        s = str(e); ck(all(w in s for w in words), s); return
    ck(False, 'PatchRefused erwartet: ' + ' / '.join(words))
orig = {k: (real / k).read_text(encoding='utf-8') for k in v14.OEM_BLOBS}
H16 = [(root / 'include' / h).read_text(encoding='utf-8') for h in v16.HEADERS]; H17 = [(root / 'include' / h).read_text(encoding='utf-8') for h in v17.HEADERS]
o16 = v16.render(dict(orig), *H16); o17 = v17.render(dict(orig), *H17)
# 1 Schichtung: nur G29.cpp und der neue Header unterscheiden sich von der CI-verifizierten v16-Ausgabe; ausschliesslich Einfuegungen
ck(sorted(set(o17) - set(o16)) == [v17.H_SENSE] and [k for k in o16 if o16[k] != o17[k]] == [G29], 'Unterschiede ausser G29/Sensor-Header')
d = list(difflib.unified_diff(o16[G29].split('\n'), o17[G29].split('\n'), lineterm='', n=0)); ck(not [l for l in d if l.startswith('-') and not l.startswith('---')], 'Zeilen entfernt/umgeschrieben')
ck(len([l for l in d if l.startswith('+') and not l.startswith('+++')]) == 17, 'erwartet genau 17 eingefuegte Zeilen')
ck(o17[G29].count('t1_parked_electrically()') == 3 and o17[G29].count('SV04NextT1ParkSense.hpp') == 1, 'Anzahl der Nutzungen/Includes')
# 2 OEM-Zeilen bleiben (als Teilfolge) erhalten, nichts anderes OEM-seitig geaendert
it = iter(o17[G29].split('\n')); ck(all(any(m == l for m in it) for l in o16[G29].split('\n')), 'v16-Zeilen nicht als Teilfolge erhalten')
for k in o16:
    if k != G29: ck(o16[k] == o17[k], k)
# 3 Platzierung: Pruefung steht unmittelbar nach der IDEX-Vorpruefung, vor der Temperaturpruefung; Punktpruefung vor dem OEM-Antastkommentar; Abschluss vor finish_ram_only
L = o17[G29]; ck(L.index('IDEX/homing preflight') < L.index('T1 park not confirmed by X_MAX endstop') < L.index('const float bed_c = thermalManager.degBed();'), 'Startpruefung falsch platziert')
ck(L.index('G29U ABORT: T1 park not confirmed') < L.index('// Ordinary G29 still calls the OEM probe path exactly once.'), 'Punktpruefung falsch platziert')
ck(L.index('sv04_good = false;   // auch beim Abschluss') < L.index('finish_ram_only()', L.index('sv04_good = false;   // auch beim Abschluss')), 'Abschlusspruefung falsch platziert')
ck('sv04_transactional_run && !sv04next::t1_parked_electrically()' in L, 'Punktpruefung nicht auf G29 U beschraenkt (normaler G29 darf nicht betroffen sein)')
# 4 Sicherheitsvertrag der Zusaetze: kein Schreiben, kein EEPROM, kein Auto60-Start
add = '\n'.join(l for l in d if l.startswith('+') and not l.startswith('+++')); ck(not any(b in add for b in ('settings.', 'M500', 'enqueue', 'setTarget', 'auto60_request_start', 'WRITE(')), 'verbotenes Token in der Einfuegung')
ck('auto60_request_start' not in ''.join(o17[k] for k in v14.OEM_BLOBS), 'auto60_request_start in OEM-Datei')
# 5 Atomaritaet: fehlender/doppelter Anker -> PatchRefused, nichts wird veraendert
real_v16 = v16.render
for anchor, what in ((v17.A_INCLUDE, 'include'), (v17.A_START, 'start check'), (v17.A_POINT, 'per-point check'), (v17.A_FINAL, 'final check')):
    for variant in ('', anchor + anchor):
        def fake(o, *h, _a=anchor, _v=variant):
            out = real_v16(o, *h); out[G29] = out[G29].replace(_a, _v); return out
        v17.v16.render = fake
        try: refused(lambda: v17.render(dict(orig), *H17), 'anchor for ' + what, 'nothing was modified')
        finally: v17.v16.render = real_v16
# 6 Header-Vertrag: jede Abweichung wird verweigert
s = H17[-1]
for bad, words in ((s.replace('// SV04 NEXT 16:', '// SV04 NEXT 99:'), 'provenance'), (s.replace('return READ(X_MAX_PIN) !=', 'WRITE(X_MAX_PIN, 1); return READ(X_MAX_PIN) !='), 'forbidden'), (s.replace('READ(X_MAX_PIN)', 'READ(Y_MAX_PIN)'), 'only READ(X_MAX_PIN)'),
                   (s.replace('inline bool t1_parked_electrically() { return false; }', 'inline bool t1_parked_electrically() { return true; }'), 'fail closed'),
                   (s.replace(' && current_position.x <= X_MAX_POS', ''), 'position discriminator'), (s.replace('current_position.x <= X_MAX_POS', '!(current_position.x > X_MAX_POS)'), 'position discriminator'), (s.replace('#if ENABLED(DUAL_X_CARRIAGE) && PIN_EXISTS(X_MAX)', '#if 1'), 'availability'), (s + '\nint x = thermalManager.degBed();', 'forbidden')):
    refused(lambda b=bad: v17.render(dict(orig), *H17[:-1], b), words)
refused(lambda: v17.render(dict(orig), *H16), '17 headers')
# 7 Semantik des Sensor-Headers auf dem Host uebersetzt und ausgefuehrt (4 Konfigurationen)
def run_cfg(defs, pin_val, cx='100.0f'):
    src = f'''#include <cstdio>
{defs}
static bool raw = {pin_val};
struct {{ float x; }} current_position = {{ {cx} }};
#ifndef X_MAX_POS
#define X_MAX_POS 302
#endif
#define READ(p) (raw)
#include "{root}/include/SV04NextT1ParkSense.hpp"
int main() {{ (void)raw; (void)current_position; std::printf("%d %d\\n", sv04next::t1_park_sense_available ? 1 : 0, sv04next::t1_parked_electrically() ? 1 : 0); }}'''
    d = Path(tempfile.mkdtemp()); (d / 't.cpp').write_text(src); r = subprocess.run(['g++', '-std=gnu++11', '-Wall', '-Wextra', '-Wno-expansion-to-defined', '-Werror', str(d / 't.cpp'), '-o', str(d / 't')], capture_output=True, text=True)
    ck(r.returncode == 0, r.stderr); return subprocess.run([str(d / 't')], capture_output=True, text=True).stdout.strip()
M = (root / 'tools/shim/shim.h').read_text(encoding='utf-8').split('// --- Basistypen')[0].replace('#pragma once', '')
base = M + '\n#define DUAL_X_CARRIAGE 1\n#define X_MAX_PIN 1\n#define X_MAX_ENDSTOP_INVERTING true\n'
ck(run_cfg(base, 'false') == '1 1', 'raw LOW + INVERTING=true muss "ausgeloest" sein')
ck(run_cfg(base, 'true') == '1 0', 'raw HIGH + INVERTING=true muss "nicht ausgeloest" sein (Kabelbruch/Pull-up)')
ck(run_cfg(base.replace('#define DUAL_X_CARRIAGE 1\n', ''), 'false') == '0 0', 'ohne DUAL_X_CARRIAGE: fail closed')
ck(run_cfg(base.replace('#define X_MAX_PIN 1\n', ''), 'false') == '0 0', 'ohne X_MAX_PIN: fail closed')
ck(run_cfg(base.replace('#define X_MAX_PIN 1', '#define X_MAX_PIN -1'), 'false') == '0 0', 'X_MAX_PIN -1: fail closed')
ck(run_cfg(base, 'false', '330.0f') == '1 0', 'Schalter gedrueckt, aber T0 steht rechts von X_MAX_POS (T0 koennte ihn selbst druecken): muss VERWEIGERN')
ck(run_cfg(base, 'false', '302.0f') == '1 1' and run_cfg(base, 'false', '-62.0f') == '1 1', 'T0 bei X_MAX_POS bzw. am Homepunkt: erlaubt')
ck(run_cfg(base, 'false', '(0.0f/0.0f)') == '1 0', 'NaN-Position muss verweigern (kein Fail-open)')
# 8 CLI aus anderem Arbeitsverzeichnis: Trockenlauf und Anwendung auf die ECHTEN Dateien, Bericht mit block 13 und layer 17
work = Path(tempfile.mkdtemp()); r0 = work / 'repo'
for k in v14.OEM_BLOBS: p = r0 / k; p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes((real / k).read_bytes())
cwd = Path(tempfile.mkdtemp()); env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
cp = subprocess.run([sys.executable, str(root / 'integration/apply_native_guard_v17.py'), '--root', str(r0), '--dry-run'], cwd=cwd, capture_output=True, text=True, env=env); ck(cp.returncode == 0, cp.stderr[-400:])
ck(all((r0 / k).read_bytes() == (real / k).read_bytes() for k in v14.OEM_BLOBS), 'Trockenlauf hat Dateien veraendert')
cp = subprocess.run([sys.executable, str(root / 'integration/apply_native_guard_v17.py'), '--root', str(r0)], cwd=cwd, capture_output=True, text=True, env=env); ck(cp.returncode == 0, cp.stderr[-400:]); rep = json.loads(cp.stdout)
ck(rep['block'] == 13 and rep['layer'] == 17 and rep['t1_electrical_park_check'] is True and rep['auto60_start_trigger_present'] is False and rep['eeprom_write'] is False, str(rep)[:200])
ck((r0 / G29).read_text(encoding='utf-8') == o17[G29] and (r0 / v17.H_SENSE).read_text(encoding='utf-8') == o17[v17.H_SENSE], 'CLI-Ausgabe weicht von render() ab')
cp = subprocess.run([sys.executable, str(root / 'integration/apply_native_guard_v17.py'), '--root', str(r0)], cwd=cwd, capture_output=True, text=True, env=env); ck(cp.returncode != 0, 'zweite Anwendung muss verweigert werden')
print(f'PASS Patchschicht v17 (elektrische T1-Parkbestaetigung) gegen ECHTE OEM-Dateien: {n[0]} Pruefungen (nur Einfuegungen, Platzierung, Vertrag, Atomaritaet, Sensor-Semantik auf dem Host, CLI); Simulation/Text, KEIN Marlin-Build')
