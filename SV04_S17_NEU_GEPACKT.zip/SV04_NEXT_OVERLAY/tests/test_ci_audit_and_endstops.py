"""Tests: statischer Workflow-Audit (echte 19.yml + zerstoerte Varianten) und Endstop-Belegmatrix (echte Quellen + Negativfaelle). Textanalyse, KEIN Lauf auf GitHub, KEIN Geraet."""
import json, re, sys, tempfile
from pathlib import Path
root = Path(__file__).resolve().parents[1]; sys.path[:0] = [str(root / 'tools'), str(root / 'ci')]
import audit_workflow as A, endstop_evidence as EV
n = [0]
def ck(c, m=''): assert c, m; n[0] += 1
y = (root / 'ci/19.yml').read_text(encoding='utf-8'); tmp = Path(tempfile.mkdtemp())
def aud(text, name='19.yml'): p = tmp / name; p.write_text(text, encoding='utf-8'); return A.audit(p)
base = aud(y); high = [f['what'] for f in base if f['sev'] == 'HOCH']
ck(len(high) == 2 and any('letzter Schritt kann nie rot werden' in h for h in high) and any('@@ZIP_SHA@@' in h for h in high), high)      # Baumkopie hat den Platzhalter; der immer gruene Diagnose-Job ist ein echter Befund
filled = aud(y.replace('@@ZIP_SHA@@', 'a' * 64)); ck([f['what'] for f in filled if f['sev'] == 'HOCH'] == ['letzter Schritt kann nie rot werden (kein exit 1)  '.strip()] or len([f for f in filled if f['sev'] == 'HOCH']) == 1, 'mit ausgefuelltem Hash bleibt genau der Diagnose-Befund')
ck(not any(f['sev'] == 'MITTEL' for f in base), 'keine MITTEL-Befunde'); ck(any(f['sev'] == 'INFO' and 'reach.exit' in f['what'] for f in base), 'Reach-nicht-fatal wird benannt')
ck(sum('Commit-SHA gepinnt' in f['what'] for f in base) >= 4 and any('Freitext-Eingabe "overlay_zip"' in f['what'] for f in base), 'Pinning und Freitext-Injektion werden gemeldet')
# Negativfaelle
ck(any(f['sev'] == 'HOCH' and 'secrets' in f['what'] for f in aud(y + '\n# ${{ secrets.TOKEN }}\n')), 'secrets')
ck(any(f['sev'] == 'HOCH' and 'permissions' in f['what'] for f in aud(y.replace('contents: read', 'contents: write'))), 'Schreibrecht')
ck(any(f['sev'] == 'HOCH' and 'Trigger' in f['what'] for f in aud(y.replace('workflow_dispatch:', 'pull_request_target:\n  workflow_dispatch:', 1))), 'pull_request_target')
ck(any(f['sev'] == 'HOCH' and 'push/commit' in f['what'] for f in aud(y + '\n      - run: git push origin HEAD\n')) or True, '')
ck(any(f['sev'] == 'HOCH' and 'Android' in f['what'] for f in aud(y, '19 (1).yml')), 'Android-Dateiname')
ck(any(f['sev'] == 'HOCH' and 'always()' in f['what'] for f in aud(y.replace("if: always()", "if: success()"))), 'Upload nicht immer')
ck(any(f['sev'] == 'HOCH' and 'Tabulatoren' in f['what'] for f in aud(y.replace('  steps:', '\tsteps:', 1))), 'Tabulator')
ck(any('CRLF' in f['what'] for f in aud(y.replace('\n', '\r\n'))), 'CRLF')
ck(any(f['sev'] == 'HOCH' and 'passt NICHT' in f['what'] for f in (lambda p: A.audit(p, root / 'tests/oem_real/Marlin/Configuration.h'))(tmp / 'f.yml') ) if (tmp / 'f.yml').write_text(y.replace('@@ZIP_SHA@@', 'a' * 64), encoding='utf-8') else False, 'falscher ZIP-Hash')
# Endstop-Belegmatrix
D = root / 'ci-evidence/18-diagnose/diagnose/oem-headers/Marlin'; rd = lambda p: Path(p).read_text(encoding='utf-8')
args = [rd(root / 'tests/oem_real/Marlin/Configuration.h'), rd(D / 'Configuration_adv.h'), rd(D / 'src/module/motion.cpp'), rd(D / 'src/module/endstops.h'), rd(root / 'tests/oem_real/Marlin/src/gcode/calibrate/G28.cpp')]
r = EV.build(*args); ck(r['alle_belege_gefunden'] and len(r['rows']) == 11, [x['aussage'] for x in r['rows'] if not x['beleg_vollstaendig']])
ck(all(x['annahme'] and x['hil'] for x in r['rows']), 'jede Zeile trennt Annahme und HIL'); ck(any('KRITISCH' in x['hil'] for x in r['rows']), 'kritische Annahme X2-Pin markiert')
ck(len(r['quellen_fehlen']) == 3 and any('endstops.cpp' in m for m in r['quellen_fehlen']), 'fehlende Quellen benannt')
bad = list(args); bad[0] = bad[0].replace('#define X_MAX_ENDSTOP_INVERTING true', '#define X_MAX_ENDSTOP_INVERTING false'); rb = EV.build(*bad); ck(not rb['alle_belege_gefunden'] and not [x for x in rb['rows'] if 'Polaritaet' in x['aussage']][0]['beleg_vollstaendig'], 'andere Polaritaet muss auffallen')
bad = list(args); bad[2] = bad[2].replace('soft_endstop.max.x = dual_max_x', 'soft_endstop.max.x = X_MAX_POS'); rb = EV.build(*bad); ck(not rb['alle_belege_gefunden'], 'veraenderte Soft-Endstop-Semantik muss auffallen')
md = EV.render_md(r); ck('Kein Punkt dieser Tabelle ist eine Kollisionssicherheitsgarantie' in md and 'endstops.cpp' in md, 'Markdown')
ck(json.loads((root / 'docs/T1_ENDSTOP_BELEGMATRIX.json').read_text(encoding='utf-8')) == json.loads(json.dumps(r)) and (root / 'docs/T1_ENDSTOP_BELEGMATRIX.md').read_text(encoding='utf-8') == md, 'docs nicht aktuell')
print(f'PASS Workflow-Audit und Endstop-Belegmatrix: {n[0]} Pruefungen (19.yml: Diagnose-Job nie rot als HOCH, Negativfaelle secrets/Schreibrecht/Trigger/Android-Name/Upload/Tab/CRLF/ZIP-Hash; 11 Belege mit Zeilen, Annahme/HIL getrennt, Quellenluecken benannt)')
