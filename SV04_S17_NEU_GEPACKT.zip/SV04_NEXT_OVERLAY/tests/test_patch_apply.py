"""Test des git-Patches: Anwendung auf die ECHTEN OEM-Dateien == Ausgabe des Patchers; Rueckwaertsanwendung stellt das Original byte-genau wieder her; abweichender OEM-Stand und Doppelanwendung werden verweigert."""
import hashlib, shutil, subprocess, sys, tempfile
from pathlib import Path
root = Path(__file__).resolve().parents[1]; sys.path[:0] = [str(root / 'integration'), str(root / 'tools')]
import apply_native_guard_v17 as v17, make_patch as MP
n = [0]
def ck(c, m=''): assert c, m; n[0] += 1
real = root / 'tests/oem_real'; v14 = v17.v15.v14; orig = {k: (real / k).read_bytes() for k in v14.OEM_BLOBS}
out = v17.render({k: v.decode('utf-8') for k, v in orig.items()}, *[(root / 'include' / h).read_text(encoding='utf-8') for h in v17.HEADERS])
shipped = (root / 'patches/0001-sv04next-overlay.patch').read_text(encoding='utf-8'); ck(shipped == MP.make(real), 'ausgelieferter Patch entspricht nicht der Neuerzeugung (bitte tools/make_patch.py ausfuehren)')
files = [l.split(' b/')[1] for l in shipped.splitlines() if l.startswith('diff --git')]; changed = sorted(f for f in files if f in orig); new = sorted(f for f in files if f not in orig)
ck(len(changed) == 3 and sorted(changed) == sorted(k for k in orig if k.endswith(('G28.cpp', 'G29.cpp', 'LCD_RTS.cpp'))), changed); ck(len(new) == 17 and all(f.startswith('Marlin/src/feature/sv04_next/') and f.endswith('.hpp') for f in new), new)
ck('Configuration.h' not in ' '.join(files) and 'probe.cpp' not in ' '.join(files), 'Configuration.h/probe.cpp duerfen nicht im Patch stehen'); ck(b'\r' not in shipped.encode('utf-8'), 'CRLF im Patch')
def repo(files_):
    d = Path(tempfile.mkdtemp()); g = lambda *a: subprocess.run(['git', '-c', 'core.autocrlf=false', *a], cwd=d, capture_output=True, text=True)
    g('init', '-q')
    for k, v in files_.items(): p = d / k; p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(v)
    return d, g
pf = Path(tempfile.mkdtemp()) / 'p.patch'; pf.write_text(shipped, encoding='utf-8')
d, g = repo(orig); r = g('apply', '--check', str(pf)); ck(r.returncode == 0, r.stderr[:300]); r = g('apply', str(pf)); ck(r.returncode == 0, r.stderr[:300])
ck(all((d / k).read_bytes() == out[k].encode('utf-8') for k in out), 'git apply != Ausgabe des Patchers (byte-genau)')
r = g('apply', '--check', str(pf)); ck(r.returncode != 0, 'zweite Anwendung muss verweigert werden')
r = g('apply', '-R', str(pf)); ck(r.returncode == 0, r.stderr[:300]); ck(all((d / k).read_bytes() == orig[k] for k in orig) and not (d / 'Marlin/src/feature/sv04_next').exists() or not any((d / 'Marlin/src/feature/sv04_next').glob('*')), 'Rueckwaerts: OEM nicht byte-genau wiederhergestellt oder Header uebrig')
# abweichender OEM-Stand: eine Zeile IM Kontext eines G29-Hunks geaendert -> Patch darf NICHT anwendbar sein
lines = shipped.split('\n'); gi = next(k for k, l in enumerate(lines) if l.startswith('diff --git') and l.endswith('G29.cpp')); ctx = next(l[1:] for l in lines[gi:gi + 60] if l.startswith(' ') and len(l.strip()) > 20 and '@@' not in l)
bad = dict(orig); k = next(x for x in bad if x.endswith('G29.cpp')); assert bad[k].count(ctx.encode('utf-8')) >= 1; bad[k] = bad[k].replace(ctx.encode('utf-8'), (ctx + ' /*abweichend*/').encode('utf-8'), 1); d2, g2 = repo(bad); r = g2('apply', '--check', str(pf)); ck(r.returncode != 0, 'Aenderung im Hunk-Kontext muss verweigert werden')
# DOKUMENTIERTE GRENZE: eine Aenderung WEIT weg von den Hunks bemerkt git apply NICHT; deshalb ist die Git-Blob-SHA1-Pruefung der 5 OEM-Dateien vor dem Anwenden Pflicht (Workflow 19 macht sie)
bad2 = dict(orig); k2 = next(x for x in bad2 if x.endswith('LCD_RTS.cpp')); bad2[k2] = bad2[k2] + b'\n// zusaetzliche Zeile am Dateiende\n'; d3, g3 = repo(bad2); r = g3('apply', '--check', str(pf)); ck(r.returncode == 0, 'Grenze: unrelated Aenderung wird NICHT bemerkt (SHA1-Pruefung ist Pflicht)')
import hashlib; blob = lambda b: hashlib.sha1(b'blob %d\0' % len(b) + b).hexdigest(); ck(blob(bad2[k2]) != blob(orig[k2]), 'die SHA1-Pruefung WUERDE die Abweichung bemerken')
for dd in (d, d2, d3): shutil.rmtree(dd, ignore_errors=True)
print(f'PASS Quellpatch (git apply) gegen die ECHTEN OEM-Dateien: {n[0]} Pruefungen (3 OEM-Dateien + 17 neue Header, byte-identisch zum Patcher, Rueckwaertsanwendung stellt OEM wieder her, abweichender Stand und Doppelanwendung verweigert); Simulation/Text, KEIN Marlin-Build')
