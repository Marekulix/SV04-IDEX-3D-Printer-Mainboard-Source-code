"""Test des Erreichbarkeitswerkzeugs: synthetische ARM-Ausgabe (Parser) + ECHTES Host-Binary des Real-G29-Harness (objdump/nm) + Negativfaelle. KEIN Test des ARM-ELF (das laeuft erst in CI)."""
import json, subprocess, sys, tempfile
from pathlib import Path
root = Path(__file__).resolve().parents[1]; sys.path[:0] = [str(root / 'tools'), str(root / 'harness')]
import reach_analyze as R
n = [0]
def ck(c, m=''): assert c, m; n[0] += 1
# 1 Parser: ARM/Thumb
ARM = '''08001000 <GcodeSuite::G29()>:
 8001000:	push	{r4, lr}
 8001002:	bl	8001020 <Probe::probe_at_point(xy_float_t const&, ProbePtRaise, unsigned char, bool, bool)>
 8001006:	beq.n	8001010 <GcodeSuite::G29()+0x10>
 8001008:	b.w	8001040 <sv04next::g29u_tail()>
 800100c:	blx	r3
 800100e:	bx	lr
 8001010:	add	r1, r2
08001020 <Probe::probe_at_point(xy_float_t const&, ProbePtRaise, unsigned char, bool, bool)>:
 8001020:	bl	8001050 <idle_no_sleep()>
 8001024:	bx	lr
08000900 <RTSUpdate()>:
 8000900:	bl	8000a00 <sv04next::auto60_glue_tick()>
 8000904:	bl	8001000 <GcodeSuite::G29()>
08000a00 <sv04next::auto60_glue_tick()>:
 8000a00:	bl	8000b00 <sv04next::Auto60Engine::tick(sv04next::Auto60Engine::Obs const&)>
08000b00 <sv04next::Auto60Engine::tick(sv04next::Auto60Engine::Obs const&)>:
 8000b00:	bx	lr
'''
NM = '20000a00 00000040 B sv04next::g29u_receipt\n20000a40 00000030 B sv04next::native_thermal_gate\n20000a80 00000020 B sv04next::t1_endstop_observer\n20000ac0 000000a0 B sv04next::auto60_engine\n'
funcs, edges = R.parse_objdump(ARM)
ck(len(funcs) == 5 and 'RTSUpdate()' in funcs, 'Funktionen'); ck('GcodeSuite::G29()' not in edges['GcodeSuite::G29()'], 'intra-funktionaler Sprung darf keine Kante sein')
ck(edges['GcodeSuite::G29()'] == {'Probe::probe_at_point(xy_float_t const&, ProbePtRaise, unsigned char, bool, bool)', 'sv04next::g29u_tail()'}, 'Kanten von G29 (bl, b.w; kein blx Rx, kein bx, kein add)')
syms = R.parse_nm(NM); ck(syms['sv04next::auto60_engine']['size'] == 0xa0 and syms['sv04next::auto60_engine']['type'] == 'B', 'nm-Parser')
res, ok, roots = R.analyze(funcs, edges, syms, R.PROFILES['overlay-auto60']); by = {r['name']: r for r in res}
ck(ok, [r['name'] for r in res if not r['passed']]); p = by['Auto60 tick von RTSUpdate aus erreichbar (Bedienung einer laufenden Maschine)']['path']; ck(p[0] == 'RTSUpdate()' and len(p) == 3, p)
ck(by['KEIN Startpfad: request_start/auto60_request_start nicht im Binary']['hit_count'] == 0, 'request_start darf fehlen')
# 2 Standard-Overlay-Profil: Auto60-Maschine darf NICHT vorhanden sein -> mit auto60-Symbolen muss es VERLETZT melden
res2, ok2, _ = R.analyze(funcs, edges, syms, R.PROFILES['overlay']); ck(not ok2 and not {r['name']: r for r in res2}['Auto60-Maschine NICHT im Standard-Overlay']['passed'], 'Standard-Overlay mit Auto60-Symbol muss auffallen')
# 3 Negativfaelle: vorhandener Startpfad MIT Aufrufer wird gemeldet
bad = ARM + '08000c00 <sv04next::Auto60Engine::request_start()>:\n 8000c00:\tbx\tlr\n08000d00 <SomeCaller()>:\n 8000d00:\tbl\t8000c00 <sv04next::Auto60Engine::request_start()>\n'
f2, e2 = R.parse_objdump(bad); r3, ok3, _ = R.analyze(f2, e2, syms, R.PROFILES['overlay-auto60']); b3 = {(r['name'], r['expect']): r for r in r3}
ck(not ok3 and not b3[('KEIN Startpfad: request_start/auto60_request_start nicht im Binary', 'absent')]['passed'] and b3[('falls doch vorhanden: ohne Aufrufer', 'no_callers')]['callers'], 'vorhandener Startpfad muss auffallen')
# 4 ECHTES Host-Binary (x86) des Real-G29-Harness: Symbole, direkte Kanten, Erreichbarkeit
import run_real_g29 as RG
work = Path(tempfile.mkdtemp()); RG.build_tree(work); r = RG.build(work, None, 'real_g29'); ck(r.returncode == 0, r.stderr[:300]); exe = work / 'real_g29'
dis = subprocess.run(['objdump', '-d', '-C', '--no-show-raw-insn', str(exe)], capture_output=True, text=True).stdout; nm = subprocess.run(['nm', '-C', '-S', str(exe)], capture_output=True, text=True).stdout
prof = {'roots': {'G29': r'^GcodeSuite::G29\('}, 'checks': [
  {'name': 'G29 vorhanden', 'regex': r'^GcodeSuite::G29\(', 'expect': 'present'}, {'name': 'G29-U-Beleg gelinkt', 'regex': r'sv04next::g29u_receipt$', 'expect': 'present'},
  {'name': 'Antastung von G29 aus erreichbar', 'regex': r'^Probe::probe_at_point\(', 'expect': 'reachable_from:G29'}, {'name': 'kein Startpfad der Auto60-Maschine', 'regex': r'Auto60Engine::request_start|auto60_request_start', 'expect': 'absent'},
  {'name': 'T1-Sensor nicht als eigene Funktion noetig (inline) oder vorhanden', 'regex': r'.*', 'expect': 'present'}]}
pj = work / 'prof.json'; pj.write_text(json.dumps(prof)); dp, np_, oj = work / 'dis.txt', work / 'nm.txt', work / 'reach.json'; dp.write_text(dis); np_.write_text(nm)
c = subprocess.run([sys.executable, str(root / 'tools/reach_analyze.py'), '--objdump', str(dp), '--nm', str(np_), '--profile', str(pj), '--out-json', str(oj), '--out-md', str(work / 'reach.md')], capture_output=True, text=True); ck(c.returncode == 0, c.stdout[-500:])
rep = json.loads(oj.read_text()); ck(rep['functions'] > 50 and rep['edges'] > 50 and rep['all_expectations_met'], str(rep)[:200])
path = [x for x in rep['results'] if x['expect'].startswith('reachable_from')][0]['path']; ck(path[0].startswith('GcodeSuite::G29(') and path[-1].startswith('Probe::probe_at_point('), path)
# 5 Negativfall am echten Binary: nicht vorhandenes Symbol als 'present' erwartet -> Exit 1
prof['checks'].append({'name': 'Phantom', 'regex': r'DoesNotExist_xyz', 'expect': 'present'}); pj.write_text(json.dumps(prof))
c = subprocess.run([sys.executable, str(root / 'tools/reach_analyze.py'), '--objdump', str(dp), '--nm', str(np_), '--profile', str(pj)], capture_output=True, text=True); ck(c.returncode == 1 and 'VERLETZT' in c.stdout, 'Phantom-Erwartung muss rot werden')
print(f'PASS Erreichbarkeitswerkzeug: {n[0]} Pruefungen (ARM-Parser synthetisch, ECHTES Host-Binary mit objdump/nm, Negativfaelle); das ARM-ELF wird erst in CI analysiert')
