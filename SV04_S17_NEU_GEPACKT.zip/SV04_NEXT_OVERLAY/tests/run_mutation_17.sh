#!/usr/bin/env bash
# Mutationskampagnen Stand 17 (zusammen etwa 3 bis 4 Minuten): Patcher-Sicherheitslogik, erzeugter G29-Code, Zustandsmaschine, Bruecke.
set -uo pipefail
cd "$(dirname "$0")/.."
python3 tools/mutate_overlay.py | tail -1
python3 harness/mutate_g29.py | tail -1
python3 tools/mutate_engine.py | tail -1
python3 harness/mutate_glue.py | tail -1
python3 harness/mutate_real_g29.py | tail -1
python3 tools/mutate_v17.py | tail -1
python3 tools/mutate_slots.py | tail -1
python3 harness/mutate_real_g29.py X | tail -1
