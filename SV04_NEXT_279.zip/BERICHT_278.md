# SV04 NEXT 278 – P1(276) + M420 V5 Integrationsbuild

Basis: OEM Sovol Commit 1867fcba75354a5c65e0631d6972dd19f1bd6cbe.
P1 bleibt unverändert auf Stand 276 (Claude-277-Code NICHT enthalten).
M420: Guard V2 auf bedlevel.cpp, zentraler Guard V4 und M420-Aktivierungsschutz, V5 frühzeitige Ablehnung von ungültiger M420-Z-Ausblendhöhe.

Host-Tests V4: 16 C++-Guard-Szenarien und 5 Patchprüfungen PASS.
Host-Tests V5: 18 C++-Fade-Szenarien und Patch-/Konfliktkontrollen PASS.
Vollständiger STM32-Build NICHT lokal durchgeführt (kein OEM-Baum und keine PlatformIO-Abhängigkeiten). GitHub-Workflow 278.yml ist zur Kompilierung vorgesehen.
Keine installierbare Firmware im ZIP, kein Flashen. Hardwarestatus offen.

WICHTIG: Der Build prüft die 276-basierte Integration, NICHT Claudes späteren 277-Zweig. Für endgültige gemeinsame Firmware müssen Claudes Änderungen anschließend konfliktgeprüft integriert werden.
