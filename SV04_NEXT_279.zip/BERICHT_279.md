# SV04 NEXT 279: Wiederholung STM32-Build nach fehlerhaftem Audit

Run 278 endete vor der M420-Installation und vor dem STM32-Build. Das statische Audit erwartete den Text 'homing NOT complete' aus P1 275, der in P1 276 geändert wurde. In 279 prüft es den P1-276-Fehlerzweig und die Fehlermeldung. G28-Quellcode und M420-Patches bleiben unverändert.

Daraus ergibt sich **kein** nachgewiesener erfolgreicher STM32-Build: die Bestätigung kann nur das Ergebnis von Run 279 liefern. Kein Flash.
