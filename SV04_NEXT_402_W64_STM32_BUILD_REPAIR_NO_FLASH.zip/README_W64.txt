SV04-NEXT VERSION 402 / WORKFLOW 64 (NO FLASH)
=============================================
Ziel: Die bislang fehlenden PlatformIO ini/*-Dateien ergänzen.
Die W58-396-Quellarchivdatei enthält platformio.ini, buildroot
und Marlin, aber kein ini/*. Die Umgebung STM32F103RET6_creality
liegt in der ursprünglichen Repository-Datei ini/stm32f1.ini.
Workflow 64 kopiert daher das vollständige ini-Verzeichnis
aus dem GitHub Checkout nach oem_c13/ini, kontrolliert es, und
führt beide Profil-Builds, Präprozessor-Export und originale
401-EEPROM-Kette erneut aus.
Kein neues Firmware-Patch. Keine Flash-Freigabe.
Externe ZIP bleibt bereits im GitHub-Repo; Quelle 396.
Sicherheit: FLASH_ALLOWED=NO, HARDWARE_TESTED=NO.
SHA256 YAML: 25f388aaad025728dc100e48fe6de03ece49c8f5c602250a7d34b554459bf6c0
