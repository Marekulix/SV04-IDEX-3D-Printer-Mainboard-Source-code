// SV04 NEXT 16: UNABHAENGIGE ELEKTRISCHE Bestaetigung, dass der zweite Schlitten (T1) am X_MAX-Endstop geparkt ist.
// Gelesen wird der PEGEL des Schalters (READ(X_MAX_PIN) != X_MAX_ENDSTOP_INVERTING, wie Marlins Endstops::update), NICHT die Firmware-Buchfuehrung
// (inactive_extruder_x, axis_is_trusted). Die Buchfuehrung ist schon vor der ersten Referenzfahrt 362; sie beweist nichts. Hier wird nur gelesen:
// kein WRITE/OUT_WRITE/SET_OUTPUT, keine Bewegung, keine Heizung, kein EEPROM. Der Aufrufer MUSS MarlinConfig.h vorher eingebunden haben.
// FAIL CLOSED: fehlt der Pin oder ist DUAL_X_CARRIAGE nicht aktiv, liefert t1_parked_electrically() immer false (Guard verweigert).
// ANNAHMEN, die erst am Geraet belegt werden (HIL): (1) X_MAX_PIN ist der Schalter des T1-Schlittens bei 362; (2) bei der echten Konfiguration
// (X_MAX_ENDSTOP_INVERTING=true, Pull-up) liest ein Kabelbruch als NICHT ausgeloest, die Pruefung faellt dann geschlossen; (3) nach G28 bleibt der
// Schalter gedrueckt (HOMING_BACKOFF_POST_MM ist in der echten Configuration_adv.h auskommentiert). Ein gedrueckter Schalter allein ist KEIN Beweis fuer
// Kollisionsfreiheit; er ist eine zusaetzliche, von der Software-Buchfuehrung unabhaengige Verweigerungsbedingung.
// GRENZE (Stand 17): X_MAX ist EIN Schalter fuer BEIDE Schlitten; bei save_dual_x_carriage_mode 1/4 erlaubt der OEM T0 bis X2_MAX_POS (motion.cpp 718-733). Gedrueckt beweist daher nicht, dass T1 ihn drueckt.
// Deshalb muss zusaetzlich die gefuehrte X-Position des aktiven Werkzeugs (T0) <= X_MAX_POS sein (NaN verweigert); T0 kann dann den Schalter bei 362 nicht beruehren.
#pragma once
namespace sv04next {
#if ENABLED(DUAL_X_CARRIAGE) && PIN_EXISTS(X_MAX)
  constexpr bool t1_park_sense_available = true;
  inline bool t1_parked_electrically() { return READ(X_MAX_PIN) != X_MAX_ENDSTOP_INVERTING && current_position.x <= X_MAX_POS; }
#else
  constexpr bool t1_park_sense_available = false;
  inline bool t1_parked_electrically() { return false; }   // fail closed
#endif
}  // namespace sv04next
