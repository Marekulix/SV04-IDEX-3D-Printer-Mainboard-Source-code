# T1-/X_MAX-Belegmatrix (maschinell aus den ECHTEN Quellen, `tools/endstop_evidence.py`)

Strikte Trennung: **Quellenbeleg** = im echten Quelltext gefunden (Datei:Zeile); **Annahme** = folgt NICHT aus den vorhandenen Quellen; **HIL** = nur am Geraet klaerbar. **Kein Punkt dieser Tabelle ist eine Kollisionssicherheitsgarantie.**

| Aussage | Quellenbeleg | Annahme (nicht belegt) | HIL |
|---|---|---|---|
| Platinentyp laut Konfiguration | Configuration.h:146 | Die Konfiguration waehlt BOARD_CREALITY_V4 (nicht V5.2.1); die zugehoerige Pinbelegung (pins_CREALITY_V4.h) liegt NICHT vor. | Platine und Aufdruck am Geraet pruefen |
| X_MAX-Schalter ist aktiviert | Configuration.h:790 | Dass der Pin existiert (PIN_EXISTS(X_MAX)) haengt von der Pinbelegung ab; in CI 18 wurde der Ausdruck mit PIN_EXISTS(X_MAX) in LCD_RTS.cpp kompiliert, also ist X_MAX_PIN dort gesetzt (siehe Probe: X_MAX_PIN vorhanden). | Pinnummer gegen Schaltplan |
| Polaritaet: gedrueckt = Pegel LOW (INVERTING=true) | Configuration.h:843 | Marlins Endstops::update bildet ausgeloest als READ(pin) != INVERTING; endstops.cpp liegt NICHT vor (nur endstops.h). Annahme aus Marlin-Standardverhalten. | Pegel am Pin messen: gedrueckt/losgelassen |
| Pull-up aktiv (offener Kontakt = HIGH = nicht ausgeloest) | Configuration.h:798 | Jetzt per Quelle belegt (siehe Zeile "Pull-up fuer X_MAX wird gesetzt"): Kabelbruch liest HIGH = NICHT ausgeloest = Pruefung verweigert. Offen bleibt nur, dass die HAL-Umsetzung von SET_INPUT_PULLUP am Geraet wirkt. | Kabel abziehen und Pegel lesen (ohne Bewegung) |
| T0 referenziert nach links (X_MIN) | Configuration.h:1367 | T1 referenziert nach rechts; X2_HOME_DIR steht in Configuration_adv.h bzw. wird von Marlin fuer DXC gesetzt (hier nicht gefunden). | Referenzfahrt beobachten (ohne Automatik) |
| Soft-Endstops von T0: bei save_dual_x_carriage_mode 1 oder 4 bis dual_max_x (X2_MAX_POS=362) | motion.cpp:718; motion.cpp:723 | Die genaue Zuordnung der Modi 1/4 zu Sovols save_dual_x_carriage_mode ist OEM-spezifisch; der Quelltext zeigt nur den Vergleich. | Modus am Geraet auslesen (M-Befehl ohne Bewegung) |
| Anfangswert inactive_extruder_x = X2_MAX_POS (schon vor der Referenzfahrt) | motion.cpp:1120 | Die Buchfuehrung beweist daher nichts ueber die physische Lage. | - |
| hotend_offset[1].x = MAX(X2_HOME_POS, X2_MAX_POS) | motion.cpp:133 | - | - |
| G28: T1 (X2) wird vor T0 referenziert, T1 bleibt auf dem Schalter (kein Rueckzug) | G28.cpp:399; Configuration_adv.h:792 | Kein Post-Homing-Backoff laut Configuration_adv.h (auskommentiert); ob die OEM-G28 intern doch zurueckfaehrt: aus dem G28-Text nicht ersichtlich (kein Backoff-Aufruf gefunden). | Schalterpegel nach G28 lesen |
| endstops.h kennt X2_MIN/X2_MAX als getrennte Eintraege (HAS_X2_MIN/HAS_X2_MAX) | endstops.h:51 | Aufgeloest durch pins_CREALITY_V4.h: es gibt KEIN X2_MIN_PIN/X2_MAX_PIN, also kein HAS_X2_MAX; X_MAX_PIN (PE15) ist der einzige rechte Schalter. | Verdrahtung: sitzt der Schalter am Parkplatz von T1? |
| X_MAX ist EIN Schalter fuer BEIDE Schlitten (T0 kann ihn bei Modus 1/4 bei 362 beruehren) | motion.cpp:723 | Deshalb Stand 17: zusaetzlich gefuehrte T0-X <= X_MAX_POS (NaN verweigert). Auch das ist Buchfuehrung, aber unabhaengig vom Schalter. | Mechanisch: kann T0 den Schalter erreichen? |
| X_MAX_PIN ist PE15; es gibt KEINEN eigenen X2-Endstop-Pin | pins_CREALITY_V4.h:84 | Negativbeleg: 0 aktive Zeilen mit X2_MIN_PIN/X2_MAX_PIN in der Pinbelegung. | Schaltplan |
| Pull-up fuer X_MAX wird gesetzt (ENDSTOPPULLUPS + USE_XMAX_PLUG -> ENDSTOPPULLUP_XMAX -> SET_INPUT_PULLUP) | Configuration.h:798; Configuration.h:790; Conditionals_post.h:1364; endstops.cpp:187 | Annahme: SET_INPUT_PULLUP der HAL wirkt am Pin PE15. | Pegel bei abgezogenem Kabel lesen (ohne Bewegung) |
| Der X_MAX-Schalter stoppt im IDEX-Betrieb nur T1 (X2_HOME_DIR 1 -> X2_HOME_TO_MAX; T0 hat X_HOME_DIR -1) | endstops.cpp:635; Configuration_adv.h:758; Configuration.h:1367 | Der PEGEL wird unabhaengig davon gelesen; T0 wird am Schalter NICHT gestoppt (bei Modus 1/4 darf T0 bis 362). Deshalb die T0-Positionsunterscheidung. | T0 kann den Schalter mechanisch erreichen? |
| EEPROM-Backend: I2C-EEPROM 24C16, 2 KB (Pinbelegung waehlt IIC_BL24CXX_EEPROM, weil keine Option in der Konfiguration gewaehlt ist) | pins_CREALITY_V4.h:48; pins_CREALITY_V4.h:52; Configuration.h:1830 | Negativbeleg: 0 aktive Backend-Optionen in Configuration.h; NO_EEPROM_SELECTED stammt aus Conditionals_adv.h:949 (nicht als Datei gesammelt). | Bauteil 24C16 am Geraet |
| Das Backend schreibt BYTEWEISE mit 2 ms Pause (ein vollstaendiges M500 dauert Sekunden) | eeprom_bl24cxx.cpp:56; eeprom_if_iic.cpp:45 | Die Dauer ist nicht gemessen; sizeof(SettingsData) (freier Rest hinter dem Marlin-Block) ist aus dem Quelltext nicht ablesbar und im Build zu ermitteln. | Dauer und Stromausfall am Geraet |
| Leveling-Fade: DEFAULT_LEVELING_FADE_HEIGHT 1,0 mm; oberhalb davon ist die Mesh-Korrektur 0 (und wird gar nicht berechnet) | Configuration.h:1583; planner.h:590; planner.cpp:1590 | Die Fade-Hoehe kann zur Laufzeit (M420 Z) oder aus dem EEPROM abweichen; hier nur der Standard. | - |

## Fehlende Quellen (der naechste Lauf von Workflow 19 sammelt sie, sobald die Sammelliste sie enthaelt)

- Marlin/src/inc/Conditionals_adv.h Zeile 949 (NO_EEPROM_SELECTED) ist vorhanden, wird aber hier nicht ausgewertet
- sizeof(SettingsData) / MarlinSettings::datasize() (nur im Build ermittelbar)
