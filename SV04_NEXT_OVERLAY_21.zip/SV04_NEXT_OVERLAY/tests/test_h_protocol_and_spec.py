"""Tests: H-Protokoll-Pruefer (leere Vorlagen bestehen nie, Manipulationen werden erkannt), DWIN-Spezifikation (aktuell, vollstaendig, keine erfundenen Adressen), SOURCE_DATE_EPOCH-Mechanismus auf dem Host-GCC. Host, KEIN Geraet."""
import copy, json, os, re, subprocess, sys, tempfile, time
from pathlib import Path
root = Path(__file__).resolve().parents[1]; sys.path[:0] = [str(root / 'tools')]
import h_protocol_check as HP, make_dwin_spec as MS
n = [0]
def ck(c, m=''): assert c, m; n[0] += 1
reg = {'overlays': {'stand18': {'sha256': 'a' * 64}}}
for st in HP.RULES:
    t = json.loads((root / f'hardware/templates/{st}.json').read_text(encoding='utf-8')); ck(not HP.evaluate(t)['ok'], f'{st}: leere Vorlage darf nie bestehen')
def good(st):
    t = json.loads((root / f'hardware/templates/{st}.json').read_text(encoding='utf-8')); t.update({'datum': '2026-11-02', 'bediener': 'Test', 'geraet': {'bezeichnung': 'SV04', 'seriennummer': 'X1'}, 'overlay_zip_sha256': 'a' * 64, 'commit_sha': 'b' * 40, 'bewegung_ausgeloest': False, 'heizung_ausgeloest': False, 'bestaetigung': {'unterschrift_name': 'Test', 'wahrheitsgemaess': True}})
    vals = {'auswerter_urteil': 'GRUEN', 'overlay_hash_gleich_register': True, 'm119_x_max_gedrueckt': 'TRIGGERED', 'm119_x_max_losgelassen': 'open', 'm119_kabel_abgezogen': 'open', 'neue_taste_vorhanden': False, 'oem_messwerte_unveraendert': True, 'bettmenue_unveraendert': True, 'abstand_t0_t1_mm': 25.0, 'x_max_t1_park': 'TRIGGERED', 'x_max_t0_bis_302': 'open'}
    for m in t['messungen']: m['gemessen'] = vals[m['id']]
    return t
for st in HP.RULES: ck(HP.evaluate(good(st), reg, 'stand18')['ok'], f'{st}: vollstaendiges Protokoll muss bestehen: {HP.evaluate(good(st), reg, "stand18")["fehler"]}')   # synthetisch, nur zum Testen des Pruefers
def bad(st, f):
    d = good(st); f(d); return HP.evaluate(d, reg, 'stand18')
ck(not bad('H1', lambda d: d.update(bewegung_ausgeloest=True))['ok'], 'Bewegung ausgeloest'); ck(not bad('H1', lambda d: d.update(heizung_ausgeloest=True))['ok'], 'Heizung ausgeloest'); ck(not bad('H3', lambda d: d['messungen'][0].update(gemessen=12.0))['ok'], 'Abstand zu klein')
ck(not bad('H1', lambda d: d['messungen'][2].update(gemessen='TRIGGERED'))['ok'], 'Kabel abgezogen zeigt TRIGGERED (fail-open!)'); ck(not bad('H1', lambda d: d['messungen'].pop())['ok'], 'Messung fehlt'); ck(not bad('H1', lambda d: d.update(datum='02.11.2026'))['ok'], 'Datum nicht ISO')
ck(not bad('H1', lambda d: d['bestaetigung'].update(wahrheitsgemaess=None))['ok'], 'Bestaetigung fehlt'); ck(not bad('H1', lambda d: d.update(overlay_zip_sha256='c' * 64))['ok'], 'Hash passt nicht zum Register'); ck(not bad('H0', lambda d: d['messungen'][0].update(gemessen='ROT'))['ok'], 'Auswerter nicht GRUEN'); ck(not HP.evaluate({'stufe': 'H9'})['ok'], 'unbekannte Stufe')
ck(not any((root / 'hardware/protocols').glob('*.json')), 'protocols/ muss leer sein: nichts ist durchgefuehrt')
# --- DWIN-Spezifikation: aktuell, jede Maschinen-Ursache mit Text, keine erfundene Adresse
doc = (root / 'docs/DWIN_DISPLAY_SPEZIFIKATION.md').read_text(encoding='utf-8'); ck(doc == MS.build(), 'Spezifikation nicht aktuell (tools/make_dwin_spec.py ausfuehren)')
import dwin_map as DM
vpmap = DM.parse((root / 'tests/oem_real_headers/Marlin/src/lcd/e3v2/creality/LCD_RTS.h').read_text(encoding='utf-8'), (root / 'tests/oem_real/Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp').read_text(encoding='utf-8'))['vps']
rs = MS.reasons(); ck(all(f'`{r}`' in doc for r in rs) and len(rs) == 23, 'jeder Abbruchgrund mit Text'); known = {f'{v["addr"]:04X}' for v in vpmap.values()} | {f'{0x1100 + 2 * i:04X}' for i in range(16)}
used = {m.upper() for m in re.findall(r'0x([0-9A-Fa-f]{4})', doc)}; ck(used <= known | {'110E'} | {'1100'}, f'Spezifikation nennt Adressen, die nicht in der verifizierten Karte stehen: {used - known}')
ck('ADRESSE: vom Display-Designer festzulegen' in doc and 'keine neu erfundene VP-Adresse' in doc, 'Platzhalter statt erfundener Adressen')
# --- SOURCE_DATE_EPOCH: Zeitstempel im Binary fest (GCC >= 7), ohne Quelltext- oder Flagaenderung
d = Path(tempfile.mkdtemp()); (d / 't.cpp').write_text('#include <cstdio>\nint main() { std::printf("%s|%s\\n", __DATE__, __TIME__); return 0; }\n')
def build_run(env_extra):
    env = dict(os.environ, TZ='UTC'); env.pop('SOURCE_DATE_EPOCH', None); env.update(env_extra); r = subprocess.run(['g++', '-o', str(d / 't'), str(d / 't.cpp')], env=env, capture_output=True, text=True); ck(r.returncode == 0, r.stderr[:200]); return subprocess.run([str(d / 't')], capture_output=True, text=True).stdout.strip()
a = build_run({'SOURCE_DATE_EPOCH': '1700000000'}); time.sleep(2.1); b = build_run({'SOURCE_DATE_EPOCH': '1700000000'}); ck(a == b == 'Nov 14 2023|22:13:20', f'SOURCE_DATE_EPOCH ergibt keine festen Strings: {a!r} {b!r}')
c1 = build_run({}); time.sleep(2.1); c2 = build_run({}); ck(c1 != c2, 'ohne SOURCE_DATE_EPOCH muessten sich die Zeitstempel unterscheiden (belegt die Ursache der 2 Byte)')
print(f'PASS H-Protokoll, DWIN-Spezifikation, SOURCE_DATE_EPOCH: {n[0]} Pruefungen (leere Vorlagen bestehen nie, Manipulationen erkannt, protocols/ leer; Spezifikation aktuell und ohne erfundene Adresse; SOURCE_DATE_EPOCH macht __DATE__/__TIME__ auf dem HOST-GCC fest, fuer den ARM-GCC 9.2.1 aus der GCC-Dokumentation (>= 7) angenommen, in CI zu pruefen)')
