// Host-Test des Ring-Entwurfs (Modell eines byteweise beschreibbaren Speichers). Absturz an JEDEM Schreibpunkt (Byte nicht geschrieben / Muellbyte), mehrere Abstuerze nacheinander, Einzelbitfehler, Verschleissverteilung.
#include "../design/SV04NextMeshRing.hpp"
#include <cstdio>
#include <cstdlib>
#include <vector>
using namespace sv04next::slots;
struct Dev { std::vector<uint8_t> mem; long writes_left = -1; bool garbage = false; std::vector<long> per_slot; uint32_t base = 0; long total = 0;
  Dev() : mem(2048, 0xFF) {}
  uint8_t read(uint32_t a) const { return mem[a]; }
  bool write(uint32_t a, uint8_t v) { if (writes_left == 0) { if (garbage) mem[a] = (uint8_t)(v ^ 0xA5); return false; } if (writes_left > 0) --writes_left; mem[a] = v; ++total; if (!per_slot.empty()) ++per_slot[(a - base) / kSlot]; return true; } };
static int fails = 0, checks = 0; static void ck(bool c, const char *m) { ++checks; if (!c) { if (fails < 10) std::printf("FAIL %s\n", m); ++fails; } }
static Mesh mk(int k) { Mesh m; for (int i = 0; i < kGridX * kGridY; ++i) m.z[i] = 0.01f * (float)(k * 17 + i); m.start_x = 25; m.start_y = 25; m.sp_x = 84; m.sp_y = 84; return m; }
static bool same(const Mesh &a, const Mesh &b) { return memcmp(&a, &b, kPayload) == 0; }
// ein Slot mit KORREKTER CRC, aber fremder Version oder Rastergroesse darf nie geladen werden (faelscht den neuesten Slot und rechnet die CRC neu)
template <class D, int NS> static void forge(D &d, RingStore<D, NS> &st, int what) {
  uint32_t seq; const int s = st.newest(seq); uint8_t buf[kSlot]; for (uint16_t i = 0; i < kSlot; ++i) buf[i] = d.mem[st.slot_addr(s) + i]; Header h; memcpy(&h, buf, sizeof h);
  if (what == 0) h.version = (uint8_t)(kVersion + 1); else h.gx = (uint8_t)(kGridX + 1); h.crc = 0; memcpy(buf, &h, sizeof h); h.crc = crc32(buf, kSlot); memcpy(buf, &h, sizeof h); for (uint16_t i = 0; i < kSlot; ++i) d.mem[st.slot_addr(s) + i] = buf[i];
}
template <int NS> static void run() {
  const long WRITES = kSlot;                          // Schreibpunkte je Speichern
  // 1) Absturz an JEDEM Schreibpunkt von Speichern j (nach j-1 vollstaendigen), beide Varianten; danach muss load() das letzte vollstaendig committete Mesh liefern; weitere Speicherungen muessen wieder normal funktionieren
  for (int j = 1; j <= NS * 2 + 1; ++j) for (int variant = 0; variant < 2; ++variant) for (long w = 0; w < WRITES; ++w) {
    Dev d; RingStore<Dev, NS> st(d, 0); for (int k = 1; k < j; ++k) ck(st.save(mk(k)), "vorheriges Speichern");
    d.writes_left = w; d.garbage = variant == 1; const bool ok = st.save(mk(j)); d.writes_left = -1; ck(!ok, "Absturz muss gemeldet werden");
    Mesh m; const bool have = st.load(m); if (j == 1) ck(!have, "nach Absturz im ersten Speichern darf kein Mesh geladen werden"); else ck(have && same(m, mk(j - 1)), "nach Absturz muss das LETZTE committete Mesh erhalten sein");
    ck(st.save(mk(j + 1)), "Erholung: Speichern nach Absturz"); ck(st.load(m) && same(m, mk(j + 1)), "Erholung: neues Mesh geladen");
  }
  // 2) mehrere Abstuerze nacheinander (Zufall): load() liefert immer das letzte vollstaendig committete Mesh
  uint32_t S = 12345u + NS; auto rnd = [&]() { S ^= S << 13; S ^= S >> 17; S ^= S << 5; return S; };
  for (int trial = 0; trial < 4000; ++trial) { Dev d; RingStore<Dev, NS> st(d, 0); int committed = 0; for (int k = 1; k <= 12; ++k) { const bool crash = rnd() % 3 == 0; if (crash) { d.writes_left = (long)(rnd() % WRITES); d.garbage = rnd() & 1; } const bool ok = st.save(mk(k)); d.writes_left = -1; if (ok) committed = k; Mesh m; const bool have = st.load(m); if (committed == 0) ck(!have, "kein committetes Mesh, aber geladen"); else ck(have && same(m, mk(committed)), "Mehrfach-Absturz: falsches Mesh"); } }
  // 3) jedes einzelne Bit jedes Slots kippen: nie ein Mesh liefern, das nicht committet wurde; der Rest des Rings bleibt nutzbar
  { Dev d; RingStore<Dev, NS> st(d, 0); for (int k = 1; k <= NS + 2; ++k) st.save(mk(k)); const std::vector<uint8_t> ref = d.mem; for (uint32_t a = 0; a < (uint32_t)(NS * kSlot); ++a) for (int b = 0; b < 8; ++b) { d.mem = ref; d.mem[a] ^= (uint8_t)(1u << b); Mesh m; if (st.load(m)) { bool known = false; for (int k = 1; k <= NS + 2; ++k) known = known || same(m, mk(k)); ck(known, "Einzelbitfehler: ein NICHT committetes Mesh wurde geladen"); } } }
  // 4) Verschleiss: nach vielen Speicherungen unterscheiden sich die Schreibzahlen der Slots um hoechstens ein Speichern
  { Dev d; d.per_slot.assign(NS, 0); RingStore<Dev, NS> st(d, 0); for (int k = 1; k <= 1000; ++k) st.save(mk(k)); long mn = d.per_slot[0], mx = d.per_slot[0]; for (int s = 0; s < NS; ++s) { if (d.per_slot[s] < mn) mn = d.per_slot[s]; if (d.per_slot[s] > mx) mx = d.per_slot[s]; } ck(mx - mn <= kSlot, "Verschleiss ungleich verteilt"); ck(mx <= (1000 / NS + 1) * kSlot, "ein Slot wird zu oft beschrieben"); }
  // 6) fremde Version / Rastergroesse mit gueltiger CRC wird abgelehnt: das vorherige Mesh bleibt massgeblich
  for (int what = 0; what < 2; ++what) { Dev d; RingStore<Dev, NS> st(d, 0); for (int k = 1; k <= 3; ++k) st.save(mk(k)); forge(d, st, what); Mesh m; ck(st.load(m) && same(m, mk(2)), what == 0 ? "fremde Version wurde akzeptiert" : "fremde Rastergroesse wurde akzeptiert"); }
  // 5) Folgenummer mit Ueberlauf: nahe 2^32 starten
  { Dev d; RingStore<Dev, NS> st(d, 0); Mesh m0 = mk(1); st.save(m0); /* Folgenummer manuell nahe Ueberlauf */ Header h; memcpy(&h, &d.mem[0], sizeof h); h.seq = 0xFFFFFFFEu; h.seq_inv = ~h.seq; uint8_t buf[kSlot]; memcpy(buf, &d.mem[0], kSlot); memcpy(buf, &h, sizeof h); h.crc = 0; memcpy(buf, &h, sizeof h); h.crc = crc32(buf, kSlot); memcpy(buf, &h, sizeof h); memcpy(&d.mem[0], buf, kSlot);
    for (int k = 2; k <= 6; ++k) { ck(st.save(mk(k)), "Ueberlauf: Speichern"); Mesh m; ck(st.load(m) && same(m, mk(k)), "Ueberlauf: neuestes Mesh nicht erkannt"); } }
}
int main() { run<2>(); run<3>(); run<4>(); run<7>(); std::printf("=== %d Pruefungen, %d FAIL (Ring N=2,3,4,7; Absturz an jedem Schreibpunkt, Mehrfachabstuerze, Einzelbitfehler, Verschleiss, Ueberlauf)\n", checks, fails); return fails ? 1 : 0; }
