// Absturzinjektion an JEDEM Schreibvorgang des A/B-Slot-Entwurfs (Modell, kein Firmware-Code, keine EEPROM-Hardware): altes Mesh bleibt bei jedem Abbruch erhalten.
#include "../design/SV04NextMeshSlots.hpp"
#include <cstdio>
#include <cstdlib>
#include <vector>
using namespace sv04next::slots;
struct Dev { uint8_t mem[2 * kSlot + 64]; long budget = -1; int garbage = 0; unsigned rng = 12345; uint32_t writes = 0;
  Dev() { memset(mem, 0xFF, sizeof mem); }
  uint8_t read(uint32_t a) const { return mem[a]; }
  bool write(uint32_t a, uint8_t v) { if (budget == 0) { if (garbage == 1) mem[a] = (uint8_t)(rng = (rng * 1103515245u + 12345u) >> 8);  /* halb geschriebenes Byte = Muell */ return false; } if (budget > 0) --budget; mem[a] = v; ++writes; return true; } };
static int fails = 0, total = 0;
static void check(const char *n, bool ok, const char *why = "") { ++total; if (!ok) ++fails; std::printf("%s  %s%s%s\n", ok ? "PASS" : "FAIL", n, ok ? "" : "  <- ", ok ? "" : why); }
static Mesh mk(float base) { Mesh m; for (int i = 0; i < 16; ++i) m.z[i] = base + 0.001f * i; m.start_x = 25; m.start_y = 25; m.sp_x = 84; m.sp_y = 84; return m; }
static bool same(const Mesh &a, const Mesh &b) { return memcmp(&a, &b, sizeof(Mesh)) == 0; }
int main() {
  const Mesh A = mk(1.0f), B = mk(2.0f), C = mk(3.0f);
  { Dev d; Store<Dev> s(d, 8); Mesh m; check("S01 leerer Speicher: kein gespeichertes Mesh", !s.load(m)); check("S02 speichern und laden", s.save(A) && s.load(m) && same(m, A)); check("S03 zweites Mesh ersetzt das erste", s.save(B) && s.load(m) && same(m, B)); check("S04 drittes Mesh (Slot A wird wiederverwendet)", s.save(C) && s.load(m) && same(m, C)); }
  // Absturz an JEDER Stelle des Schreibens von B, dann von C: das Ergebnis ist IMMER genau das alte oder das neue Mesh, nie etwas dazwischen
  for (int variant = 0; variant < 2; ++variant) {
    long ncut = 0, old_kept = 0, new_done = 0; bool never_mixed = true, never_invented = true;
    for (int round = 0; round < 2; ++round) {
      const Mesh &prev = round == 0 ? A : B, &next = round == 0 ? B : C;
      for (long cut = 0; cut <= (long)kSlot + 1; ++cut) {
        Dev d; Store<Dev> s(d, 8); s.save(A); if (round == 1) s.save(B);
        d.budget = cut; d.garbage = variant; const bool done = s.save(next); d.budget = -1; Mesh m; const bool ok = Store<Dev>(d, 8).load(m); ++ncut;
        if (!ok) { never_invented = false; continue; }
        if (same(m, next)) { ++new_done; never_mixed = never_mixed && done; } else if (same(m, prev)) { ++old_kept; never_mixed = never_mixed && !done; } else never_mixed = false;
      }
    }
    char nm[320]; std::snprintf(nm, sizeof nm, "A%d Absturz an JEDEM der %ld Schreibpunkte (%s): immer genau altes ODER neues Mesh; neues nur nach vollstaendigem Schreiben (%ld alt erhalten, %ld neu)", variant, ncut, variant ? "Muellbyte beim Abbruch" : "Byte nicht geschrieben", old_kept, new_done);
    check(nm, never_mixed && never_invented && old_kept > 0 && new_done > 0, "Mischzustand oder verlorenes Mesh");
  }
  // Einzelbitfehler in einem der beiden Slots (Alterung, Stoerung): niemals ein verfaelschtes Mesh
  { Dev d; Store<Dev> s(d, 8); s.save(A); s.save(B); bool ok = true; for (int slot = 0; slot < 2; ++slot) for (uint32_t i = 0; i < kSlot; ++i) for (int bit = 0; bit < 8; ++bit) { Dev e = d; e.mem[8 + slot * kSlot + i] ^= (uint8_t)(1u << bit); Mesh m; const bool l = Store<Dev>(e, 8).load(m); ok = ok && l && (same(m, B) || same(m, A)); } check("B01 jeder Einzelbitfehler in beiden Slots: es wird nie ein verfaelschtes Mesh geliefert (immer B oder der aeltere A)", ok, "verfaelschtes Mesh"); }
  { Dev d; Store<Dev> s(d, 8); s.save(A); s.save(B); for (uint32_t i = 0; i < 2u * kSlot; ++i) d.mem[8 + i] ^= 0x55; Mesh m; check("B02 beide Slots zerstoert: kein Mesh (Rueckfall: Marlins Block, hier nicht modelliert)", !Store<Dev>(d, 8).load(m)); }
  // Kompatibilitaet und Folgenummer
  { Dev d; Store<Dev> s(d, 8); s.save(A); Header h; memcpy(&h, d.mem + 8, sizeof h); h.version = 2; uint8_t tmp[kSlot]; memcpy(tmp, d.mem + 8, kSlot); memcpy(tmp, &h, sizeof h); memset(tmp + offsetof(Header, crc), 0, 4); h.crc = crc32(tmp, kSlot); memcpy(d.mem + 8, &h, sizeof h); Mesh m; check("K01 andere Version (mit korrektem CRC): wird abgelehnt (Kompatibilitaet)", !Store<Dev>(d, 8).load(m)); }
  { Dev d; Store<Dev> s(d, 8); s.save(A); Header h; memcpy(&h, d.mem + 8, sizeof h); h.gx = 5; uint8_t tmp[kSlot]; memcpy(tmp, d.mem + 8, kSlot); memcpy(tmp, &h, sizeof h); memset(tmp + offsetof(Header, crc), 0, 4); h.crc = crc32(tmp, kSlot); memcpy(d.mem + 8, &h, sizeof h); Mesh m; check("K02 andere Rastergroesse (mit korrektem CRC): wird abgelehnt", !Store<Dev>(d, 8).load(m)); }
  { check("F01 Folgenummer-Vergleich mit Ueberlauf (0xFFFFFFFF -> 0 ist neuer)", Store<Dev>::newer(0u, 0xFFFFFFFFu) && !Store<Dev>::newer(0xFFFFFFFFu, 0u) && Store<Dev>::newer(5u, 4u)); }
  { Dev d; Store<Dev> s(d, 8); s.save(A); const uint32_t w1 = d.writes; s.save(B); check("W01 je Speichern genau eine Slot-Laenge an Schreibvorgaengen (Slot-Wechsel statt Ueberschreiben)", d.writes - w1 == kSlot, "Schreibmenge"); }
  { Dev d; Store<Dev> s(d, 8); s.save(A); s.save(B); uint8_t before[2 * kSlot]; memcpy(before, d.mem + 8, 2 * kSlot); d.budget = 3; s.save(C); d.budget = -1; check("U01 Abbruch beim Speichern von C beruehrt den gueltigen Slot (B) nicht", memcmp(before + kSlot, d.mem + 8 + kSlot, kSlot) == 0 || memcmp(before, d.mem + 8, kSlot) == 0, "gueltiger Slot veraendert"); }
  std::printf("=== %d Pruefungen, %d FAIL\n", total, fails); return fails ? 1 : 0;
}
