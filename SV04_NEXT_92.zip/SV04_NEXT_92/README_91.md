# SV04 NEXT 91 – Punkt 1: realer GitHub-STM32-Build

**Anwendung:** `SV04_NEXT_91.zip` in Repository-Root hochladen; `91.yml` nach `.github/workflows/91.yml`; GitHub Actions → Workflow 91 → Run workflow.

Der Workflow prüft die komplette lokale Patchkette, klont genau den Sovol-OEM-Commit `1867fcba75354a5c65e0631d6972dd19f1bd6cbe`, führt die Marlin-Änderungen aus Stand 62 bis 91 mittels `tools/integrate82.py` aus, kontrolliert den erzeugten Quellstand und startet den realen PlatformIO-STM32-Build. Stand-91-Codeänderungen sind die bis 91 nachgeführten Integrationsprüfungen (u.a. ELF-Markierung), KEINE zusätzlichen Marlin-Funktionsänderungen.

**Artefakte:** `sv04next91-host-evidence.zip` und `sv04next91-stm32-evidence.zip`. Beide werden auch bei Buildfehlern hochgeladen. Für die Auswertung bitte beide hochladen. Die Firmware-BIN wird absichtlich NICHT als flashbares Release veröffentlicht; diese Runde ist ein Buildtest.

**Besonders wichtig:** Ein grüner GitHub-Lauf bestätigt Compiler/Linker und das nachgewiesene Diagnosemerkmal, **nicht** die Hardwarefunktion oder Flashfreigabe. Punkt 1 bleibt bis zum echten Resultat offen (derzeit ca. 70%).
