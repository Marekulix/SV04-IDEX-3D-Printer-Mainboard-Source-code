# SV04 NEXT 75 | Offline-DWIN-Übertragungsabsicherung

## Neu
- C++11 `SV04NextDwinDelivery75.hpp`: Komplette 16-Werte-Vorprüfung; ein Sender liefert `bool` als **Softwareannahme** zurück.
- Nach einem abgelehnten Schreibaufruf wird der Cache verworfen und beim nächsten Aufruf der vollständige Satz erneut angeboten.
- Neues Fail-Closed-Patchtool und vollständige Patchkette OEM → 62 → 65 → 66 → 67 → 68 → 70 → 73 → 74 → 75.
- Unbekannte Quellen, Doppelpatches und freigegebene HMI-Mapping-Konstanten werden abgelehnt.

## Wichtige Grenzen
- Die Originalfunktion `RTS_SndData` meldet keinen Display-Empfang. Der Wrapper bestätigt nur, dass der Funktionsaufruf zurückgekehrt ist, **keine UART-Zustellung oder Display-Aktualisierung**.
- HMI-Mapping ist absichtlich `false`; die echte Ausgabe der neuen Brücke bleibt damit gesperrt.
- Kein realer STM32-Build für 75, keine HMI-Firmware, kein Display- oder Druckertest, keine Flashfreigabe.
- Ohne exakte OEM-HMI-Datei bleibt die neue farbige Touchseite **nicht installiert**. Die Stand-69-Grafik ist nur eine Ressource.

## Test
`python -m unittest discover -s tests -p 'test*.py' -v`

## Prozent
Vorher 52 %. Vorläufig 52 %: Verbesserung der Fehlerbehandlung ohne neue freigegebene Hardwarefunktion. Messbare neue Tests separat ausweisen.
