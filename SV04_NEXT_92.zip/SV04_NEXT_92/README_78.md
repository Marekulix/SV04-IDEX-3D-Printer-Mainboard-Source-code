# SV04 NEXT 78 – Marlin DWIN writer removed from the experimental call site

## Independently identified problem

The stage77 call site **still passes a real `rtscheck.RTS_SndData` callback** to the locked function. It is presently not executed, but keeping it at a call site that is advertised as fully read-only is an unnecessary safety risk. Stages 68–75 also intentionally reuse the OEM 4×4 VP range `0x1100..0x111E`; `0x110E` has an unresolved address overlap. We cannot responsibly unlock this pending the installed HMI project and actual hardware validation.

## Real change

Stage78 replaces the call with `sv04next78::observe_only(sv04_dwin70, millis())` whose API **cannot accept a writer**. The C++ header has hard compile-time release denials. Stage78 only touches the added SV04 NEXT display hook and leaves Sovol's original screen control untouched. The stage78 audit rejects a reintroduced writer in this hook. `tools/apply_chain78.py` keeps all prior stages in sequence.

This does **not** install the custom colored HMI project, provide physical display transmission, drive motors/heaters, or save EEPROM. It is a safety fix. Actual OEM Marlin STM32 compilation of this stage still requires the next GitHub run. Do not flash. No hardware release.
