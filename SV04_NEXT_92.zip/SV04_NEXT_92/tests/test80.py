import importlib.util
import tempfile
import pathlib
import json
import unittest
from unittest.mock import patch

ROOT=pathlib.Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location('integrate80', ROOT/'tools/integrate80.py')
M=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)

class Integration80(unittest.TestCase):
    def test_integrator_python_valid(self):
        compile((ROOT/'tools/integrate80.py').read_text(), 'integrate80.py', 'exec')

    def test_rejects_missing_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=pathlib.Path(tmp)
            with self.assertRaisesRegex(ValueError,'platformio.ini'):
                M.integrate(p/'oem',p/'proof')

    def test_rejects_output_inside_checkout(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=pathlib.Path(tmp)/'oem';root.mkdir();(root/'platformio.ini').write_text('')
            with self.assertRaisesRegex(ValueError,'outside'):
                M.integrate(root,root/'proof')

    def test_rejects_wrong_revision(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=pathlib.Path(tmp)/'oem';root.mkdir();(root/'platformio.ini').write_text('')
            with patch.object(M,'command',return_value='different\n'):
                with self.assertRaisesRegex(ValueError,'wrong OEM'):
                    M.integrate(root,pathlib.Path(tmp)/'proof')

    def test_rejects_dirty_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=pathlib.Path(tmp)/'oem';root.mkdir();(root/'platformio.ini').write_text('')
            with patch.object(M,'command',side_effect=[M.BASE+'\n',' M somefile\n']):
                with self.assertRaisesRegex(ValueError,'not pristine'):
                    M.integrate(root,pathlib.Path(tmp)/'proof')

    def test_collects_real_source_diff_and_new_headers(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=pathlib.Path(tmp)/'oem';root.mkdir();(root/'platformio.ini').write_text('')
            out=pathlib.Path(tmp)/'proof'
            g='Marlin/src/gcode/bedlevel/abl/G29.cpp';d='Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp';h='Marlin/src/feature/SV04NextUnified79.hpp'
            for name in [g,d,h]:
                f=root/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_text('// '+name+' SV04 NEXT 79')
            diff='diff --git a/G29.cpp b/G29.cpp\n+// SV04 NEXT 79\n'
            def fake(args,cwd=None,output=None):
                if args[1:3]==['rev-parse','HEAD']:return M.BASE+'\n'
                if args[1:3]==['status','--porcelain']:return ''
                if args[1:3]==['ls-files','--modified']:return '\n'.join([g,d,h])
                if args[1]=='diff':return diff
                raise AssertionError(args)
            with patch.object(M,'command',side_effect=fake),patch.object(M,'run79',return_value={'ok':True}):
                result=M.integrate(root,out)
            self.assertEqual(result['source_file_count'],3)
            self.assertIsNone(result['stm32_build_success'])
            self.assertEqual((out/'added_source_files'/h).read_text(),(root/h).read_text())
            self.assertTrue((out/'Marlin_source_changes_62_to_79.patch').is_file())
            self.assertEqual(json.loads((out/'integration80.json').read_text())['scope'],'POINT_1_MARLIN_SOURCE_INTEGRATION_ONLY')

if __name__=='__main__':unittest.main()
