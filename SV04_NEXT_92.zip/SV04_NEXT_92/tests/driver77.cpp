#include "../src/SV04NextHmiFirewall77.hpp"
#include <cassert>
#include <iostream>
int main() {
 sv04next70::Presenter p;
 int count=0;
 auto getter=[](int,int)->float{return 0.1f;};
 auto writer=[&count](uint16_t,int16_t)->bool{++count;return true;};
 assert(!sv04next77::locked_update(p,getter,writer,1000,true));
 assert(count==0);
 assert(!sv04next77::locked_update(p,getter,writer,2000,false));
 assert(count==0);
 std::cout<<"SV04NEXT77_NO_WRITES_OK\n";
}
