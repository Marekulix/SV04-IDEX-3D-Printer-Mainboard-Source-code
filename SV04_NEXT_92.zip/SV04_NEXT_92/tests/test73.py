import unittest,sys,tempfile,subprocess
from pathlib import Path
P=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(P/'tools'))
from apply73 import apply,RTS,MARKER,INCLUDE,HEAD,WIRE
class Stage73(unittest.TestCase):
 def cpp(self,*flags):
  with tempfile.TemporaryDirectory() as td:
   exe=Path(td)/'driver73'
   c=subprocess.run(['g++','-std=c++11','-Wall','-Wextra','-Werror','-pedantic',*flags,str(P/'tests/driver73.cpp'),'-o',str(exe)],capture_output=True,text=True)
   if c.returncode:return c,None
   return c,subprocess.run([str(exe)],capture_output=True,text=True)
 def setup_source(self,r):
  (r/'platformio.ini').write_text('[platformio]\n')
  d=r/'Marlin/src/feature';d.mkdir(parents=True)
  (d/'SV04NextDwinPresenter70.hpp').write_text('stage70')
  s='#include "../../../feature/SV04NextDwinPresenter70.hpp"\n'+MARKER+'\n'
  f=r/RTS;f.parent.mkdir(parents=True);f.write_text(s);return f
 def test_cpp_bridge(self):
  c,run=self.cpp();self.assertEqual(c.returncode,0,c.stderr);self.assertEqual(run.returncode,0,run.stderr)
  self.assertIn('SV04NEXT73',run.stdout)
 def test_lock_flags(self):
  for flag in ('SV04_NEXT_AUTO60_RELEASE','SV04_NEXT_DWIN_TOUCH_RELEASE','SV04_NEXT_T1_MOTION_RELEASE','SV04_NEXT_EEPROM_RELEASE','SV04_NEXT_FLASH_RELEASE'):
   with self.subTest(flag=flag):
    c,_=self.cpp('-D'+flag);self.assertNotEqual(c.returncode,0)
 def test_patch(self):
  with tempfile.TemporaryDirectory() as td:
   r=Path(td);f=self.setup_source(r);prev=f.read_bytes();d=apply(r,P/'src/SV04NextDwinBridge73.hpp',P/'src/SV04NextDwinWire72.hpp')
   self.assertEqual(d['dwin_writes_default'],0);self.assertNotEqual(f.read_bytes(),prev)
   self.assertIn('sv04next73::update',f.read_text());self.assertTrue((r/HEAD).exists());self.assertTrue((r/WIRE).exists())
   with self.assertRaises(ValueError):apply(r,P/'src/SV04NextDwinBridge73.hpp',P/'src/SV04NextDwinWire72.hpp')
 def test_refuse_unknown_unchanged(self):
  with tempfile.TemporaryDirectory() as td:
   r=Path(td);f=self.setup_source(r);f.write_text(f.read_text().replace('sv04_dwin70.update','sv04_dwin70.bad'))
   original=f.read_bytes()
   with self.assertRaises(ValueError):apply(r,P/'src/SV04NextDwinBridge73.hpp',P/'src/SV04NextDwinWire72.hpp')
   self.assertEqual(f.read_bytes(),original);self.assertFalse((r/HEAD).exists())
 def test_no_actuators_and_default_blocked(self):
  s=(P/'src/SV04NextDwinBridge73.hpp').read_text();self.assertIn('MAPPING_CONFIRMED=false',s)
  for command in ('queue.enqueue','settings.save','thermalManager','planner.buffer','G29','M500'):
   self.assertNotIn(command,s)
 def test_chain(self):
  s=(P/'tools/apply_chain73.py').read_text();self.assertIn('from apply_chain70 import run',s)
  for f in (P/'tools').glob('*.py'):compile(f.read_bytes(),str(f),'exec')
