#include "SV04NextSafety65.hpp"
#include <assert.h>
#include <limits>
using namespace sv04next65;
Gates good(){return {true,true,true,true,true,true,true,false};}
Input ev(uint32_t n,Event t,float z=0,uint8_t idx=0,bool verified=false,uint32_t fp=0){return {n,t,60.0f,z,idx,verified,fp};}
void until_soak(Monitor &m,Gates &g){assert(m.consume(ev(1,ARM),g));assert(m.consume(ev(2,START),g));assert(m.consume(ev(3,BED_AT_60),g));assert(m.consume(ev(4,TEMP_SAMPLE),g));assert(m.consume(ev(5,TEMP_SAMPLE),g));assert(m.consume(ev(6,SOAK_VERIFIED,0,0,true),g));}
void until_mesh(Monitor &m,Gates &g){until_soak(m,g);assert(m.consume(ev(7,HOME_VERIFIED,0,0,true),g));for(uint8_t i=0;i<16;i++)assert(m.consume(ev(8+i,MESH_POINT,0.1f,i),g));assert(m.state==VALIDATE);}
int main(){
  assert(!kCanHeat && !kCanMove && !kCanTouchStart && !kCanWriteEeprom && !kFlashApproved);
  Gates g=good();
  {Monitor m; assert(!m.save_preconditions_model(g));assert(!m.consume(ev(1,START),g));assert(m.fault==ORDER);}
  {Monitor m;g.hmi_verified=false;assert(!m.consume(ev(1,ARM),g));assert(m.fault==UNAUTHORIZED);g=good();}
  {Monitor m;assert(m.consume(ev(1,ARM),g));g.t1_clearance_verified=false;assert(!m.consume(ev(2,START),g));assert(m.fault==REVOKED);g=good();}
  {Monitor m;assert(m.consume(ev(1,ARM),g));assert(!m.consume(ev(1,START),g));assert(m.fault==STALE_EVENT);}
  {Monitor m;until_soak(m,g);assert(m.state==HOMING);}
  {Monitor m;until_mesh(m,g);assert(m.consume(ev(24,MESH_VERIFIED,0,0,true),g));assert(m.save_preconditions_model(g));
   uint32_t fp=m.fingerprint;assert(!m.consume(ev(25,SAVE_REQUESTED,0,0,true,fp+1),g));assert(m.state==FAILED);}
  {Monitor m;until_mesh(m,g);assert(m.consume(ev(24,MESH_VERIFIED,0,0,true),g));uint32_t fp=m.fingerprint;
   assert(m.consume(ev(25,SAVE_REQUESTED,0,0,true,fp),g));assert(!m.save_preconditions_model(g));assert(m.consume(ev(26,READBACK_VERIFIED,0,0,true,fp),g));assert(m.state==COMPLETE);}
  {Monitor m;assert(m.consume(ev(1,ARM),g));assert(!m.consume(ev(2,ABORT),g));assert(m.state==FAILED);}
  {Monitor m;until_mesh(m,g);assert(!m.consume(ev(24,MESH_VERIFIED,0,0,false),g));assert(m.fault==ORDER);}
  {Monitor m;Input i=ev(1,ARM); i.temperature=std::numeric_limits<float>::quiet_NaN();assert(m.consume(i,g));}
  return 0;
}
