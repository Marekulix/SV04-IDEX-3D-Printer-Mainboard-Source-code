import unittest,subprocess,tempfile,sys
from pathlib import Path
P=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(P/'tools'))
from apply74 import apply,RTS,HEAD,BRIDGE,OLD,NEW
class Stage74(unittest.TestCase):
 def source(self,r):
  (r/'platformio.ini').write_text('[platformio]\n')
  f=r/RTS;f.parent.mkdir(parents=True)
  f.write_text('#include "../../../feature/SV04NextDwinBridge73.hpp"\n'
    'sv04next73::update(sv04_dwin70, get, send, millis(),true,sv04next73::MAPPING_CONFIRMED);\n')
  p=r/BRIDGE;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('// MAPPING_CONFIRMED=false\n')
  return f
 def test_native_preflight(self):
  with tempfile.TemporaryDirectory() as td:
   exe=Path(td)/'d74'
   c=subprocess.run(['g++','-std=c++11','-Wall','-Wextra','-Werror','-pedantic',str(P/'tests/driver74.cpp'),'-o',str(exe)],capture_output=True,text=True)
   self.assertEqual(c.returncode,0,c.stderr)
   o=subprocess.run([str(exe)],capture_output=True,text=True)
   self.assertEqual(o.returncode,0,o.stderr);self.assertIn('PREFLIGHT_16_OK',o.stdout)
 def test_fail_closed_release_macros(self):
  for x in ('SV04_NEXT_AUTO60_RELEASE','SV04_NEXT_DWIN_TOUCH_RELEASE','SV04_NEXT_T1_MOTION_RELEASE','SV04_NEXT_EEPROM_RELEASE','SV04_NEXT_FLASH_RELEASE'):
   with self.subTest(flag=x):
    r=subprocess.run(['g++','-std=c++11','-D'+x,'-fsyntax-only',str(P/'tests/driver74.cpp')],capture_output=True,text=True)
    self.assertNotEqual(r.returncode,0)
 def test_patch_exact_once_and_locked(self):
  with tempfile.TemporaryDirectory() as td:
   r=Path(td);f=self.source(r);old=f.read_bytes()
   m=apply(r,P/'src/SV04NextDwinAtomic74.hpp')
   self.assertEqual(m['runtime_dwin_sends'],0)
   self.assertNotEqual(f.read_bytes(),old);self.assertIn(NEW,f.read_text())
   self.assertTrue((r/HEAD).is_file())
   with self.assertRaises(ValueError):apply(r,P/'src/SV04NextDwinAtomic74.hpp')
 def test_unknown_source_untouched(self):
  with tempfile.TemporaryDirectory() as td:
   r=Path(td);f=self.source(r);f.write_text(f.read_text().replace(OLD,'unknown::update('));s=f.read_bytes()
   with self.assertRaises(ValueError):apply(r,P/'src/SV04NextDwinAtomic74.hpp')
   self.assertEqual(s,f.read_bytes());self.assertFalse((r/HEAD).exists())
 def test_mapping_cannot_be_unlocked(self):
  with tempfile.TemporaryDirectory() as td:
   r=Path(td);f=self.source(r);(r/BRIDGE).write_text('MAPPING_CONFIRMED=true')
   with self.assertRaises(ValueError):apply(r,P/'src/SV04NextDwinAtomic74.hpp')
   self.assertFalse((r/HEAD).exists())
 def test_syntax_chain_and_no_actuation(self):
  for f in (P/'tools').glob('*.py'):compile(f.read_bytes(),str(f),'exec')
  s=(P/'src/SV04NextDwinAtomic74.hpp').read_text()
  for forbidden in ('queue.enqueue','settings.save','thermalManager','planner.buffer','M500','G29'):
   self.assertNotIn(forbidden,s)
  chain=(P/'tools/apply_chain74.py').read_text();self.assertIn('from apply_chain73 import run',chain)
