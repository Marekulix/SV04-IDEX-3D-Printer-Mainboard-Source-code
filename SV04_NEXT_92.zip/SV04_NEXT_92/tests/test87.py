import pathlib,subprocess,tempfile,sys,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
import verify81
from test81 import SourceIntegration81

class Integration87(unittest.TestCase):
 def run_fixture(self,extra,should_fail=False):
  with tempfile.TemporaryDirectory() as d:
   root,g,r=SourceIntegration81().fixture(d)
   head=root/'Marlin/src/feature/SV04NextUnified79.hpp'
   head.write_text(head.read_text()+extra)
   original=verify81.BASE
   verify81.BASE=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()
   try:
    if should_fail:
     with self.assertRaisesRegex(verify81.VerificationFailure,'missing source include'):verify81.verify(root)
    else:
     result=verify81.verify(root)
     self.assertTrue(result['verification_passed'])
   finally:verify81.BASE=original
 def test_nested_missing_header_rejected(self):self.run_fixture('#include "SV04NextMissing87.hpp"\n',True)
 def test_nested_valid_header_accepted(self):self.run_fixture('#include "SV04NextGuard62.h"\n')
 def test_local_include_cycle_does_not_loop(self):
  with tempfile.TemporaryDirectory() as d:
   root,g,r=SourceIntegration81().fixture(d)
   h=root/'Marlin/src/feature/SV04NextUnified79.hpp'
   h.write_text('#include "SV04NextHmiGate78.hpp"\n')
   (root/'Marlin/src/feature/SV04NextHmiGate78.hpp').write_text('#include "SV04NextUnified79.hpp"\n')
   original=verify81.BASE;verify81.BASE=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()
   try:self.assertTrue(verify81.verify(root)['verification_passed'])
   finally:verify81.BASE=original
