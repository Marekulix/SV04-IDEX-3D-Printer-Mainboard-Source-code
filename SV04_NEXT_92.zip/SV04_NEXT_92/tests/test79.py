import unittest,subprocess,tempfile,pathlib,sys,shutil
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from apply79 import apply,G29,RTS
from audit79 import audit
class Stage79(unittest.TestCase):
 def test_cpp(self):
  with tempfile.TemporaryDirectory() as t:
   p=pathlib.Path(t)/'driver';subprocess.run(['g++','-std=c++11','-Wall','-Wextra','-Werror','-pedantic','-I',str(ROOT/'src'),str(ROOT/'tests/driver79.cpp'),'-o',str(p)],check=True,capture_output=True)
   self.assertIn('HOST_PASS',subprocess.run([str(p)],check=True,capture_output=True,text=True).stdout)
 def fake(self):
  t=tempfile.TemporaryDirectory();r=pathlib.Path(t.name)
  (r/'platformio.ini').write_text('[platformio]')
  (r/G29).parent.mkdir(parents=True);(r/RTS).parent.mkdir(parents=True)
  (r/G29).write_text('#include "../../../feature/SV04NextSafety65.hpp"\n  // SV04 NEXT 62 read-only diagnostic. Exact U+Q combination only.\n')
  (r/RTS).write_text('#include "../../../feature/SV04NextHmiGate78.hpp"\nsv04next78::observe_only(sv04_dwin70, millis());')
  (r/'Marlin/src/feature').mkdir(parents=True,exist_ok=True)
  (r/'Marlin/src/feature/SV04NextHmiGate78.hpp').write_text('// stage78')
  return t,r
 def test_patch_and_audit(self):
  t,r=self.fake()
  try:
   result=apply(r,ROOT/'src/SV04NextUnified79.hpp');self.assertFalse(result['flash_approved'])
   self.assertTrue(audit(r)['pass'])
   with self.assertRaises(ValueError):apply(r,ROOT/'src/SV04NextUnified79.hpp')
  finally:t.cleanup()
 def test_unknown_refused(self):
  t,r=self.fake()
  try:
   (r/G29).write_text('unknown')
   with self.assertRaises(ValueError):apply(r,ROOT/'src/SV04NextUnified79.hpp')
  finally:t.cleanup()
 def test_missing_required_include_refused_without_changes(self):
  t,r=self.fake()
  try:
   original=(r/G29).read_text()
   (r/G29).write_text(original.replace('#include "../../../feature/SV04NextSafety65.hpp"\n',''))
   before=(r/G29).read_bytes(),(r/RTS).read_bytes()
   with self.assertRaises(ValueError):apply(r,ROOT/'src/SV04NextUnified79.hpp')
   self.assertEqual(before,((r/G29).read_bytes(),(r/RTS).read_bytes()))
   self.assertFalse((r/'Marlin/src/feature/SV04NextUnified79.hpp').exists())
  finally:t.cleanup()
 def test_duplicate_required_include_refused(self):
  t,r=self.fake()
  try:
   old=(r/G29).read_text()
   (r/G29).write_text(old.replace('#include "../../../feature/SV04NextSafety65.hpp"\n','#include "../../../feature/SV04NextSafety65.hpp"\n'*2))
   with self.assertRaises(ValueError):apply(r,ROOT/'src/SV04NextUnified79.hpp')
  finally:t.cleanup()
 def test_locked_and_no_actuators(self):
  s=(ROOT/'src/SV04NextUnified79.hpp').read_text()
  for x in ('CAN_HEAT=false','CAN_MOVE=false','CAN_EEPROM_WRITE=false','CAN_DWIN_TOUCH=false','CAN_FLASH=false','r.can_start=false'):
   self.assertIn(x,s)
  for x in ('queue.enqueue','settings.save(', 'queue.inject', 'thermalManager.setTargetBed', 'do_blocking_move_to'):
   self.assertNotIn(x,s)
 def test_python_syntax(self):
  for file in (ROOT/'tools').glob('*.py'):
   compile(file.read_text(),str(file),'exec')
if __name__=='__main__':unittest.main()
