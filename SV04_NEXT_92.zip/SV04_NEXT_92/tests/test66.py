import pathlib,tempfile,unittest,subprocess,sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from apply66 import apply,G29,DEST,ANCHOR,BEFORE,MARK
class Verify66(unittest.TestCase):
 def fixture(self,td):
  p=pathlib.Path(td);src=p/G29;src.parent.mkdir(parents=True);(p/'platformio.ini').write_text('[platformio]')
  (p/'Marlin/src/feature').mkdir(parents=True)
  (p/'Marlin/src/feature/SV04NextSafety65.hpp').write_text('// approved test fixture')
  src.write_text(ANCHOR+MARK+'  if (parser.seen_test(\'U\')) { SERIAL_ECHOLNPGM("'+BEFORE+'"); }\n')
  return p
 def test_patch_installs(self):
  with tempfile.TemporaryDirectory() as d:
   p=self.fixture(d);result=apply(p,ROOT/'src/SV04NextAudit66.hpp');self.assertTrue((p/DEST).exists());self.assertIn('static_assert',(p/G29).read_text());self.assertFalse(result['flash_approved'])
 def test_repeat_denied(self):
  with tempfile.TemporaryDirectory() as d:
   p=self.fixture(d);apply(p,ROOT/'src/SV04NextAudit66.hpp')
   with self.assertRaises(ValueError):apply(p,ROOT/'src/SV04NextAudit66.hpp')
 def test_unknown_denied_without_write(self):
  with tempfile.TemporaryDirectory() as d:
   p=self.fixture(d);(p/G29).write_text('BAD');
   with self.assertRaises(ValueError):apply(p,ROOT/'src/SV04NextAudit66.hpp')
   self.assertFalse((p/DEST).exists())
 def test_cpp(self):
  with tempfile.TemporaryDirectory() as d:
   o=pathlib.Path(d)/'checker'
   subprocess.run(['g++','-std=c++11','-O2','-Wall','-Wextra','-Werror','-I',str(ROOT/'src'),str(ROOT/'tests/driver66.cpp'),'-o',str(o)],check=True)
   subprocess.run([str(o)],check=True)
 def test_release_guards(self):
  for k in ['SV04_NEXT_AUTO60_RELEASE','SV04_NEXT_DWIN_TOUCH_RELEASE','SV04_NEXT_T1_MOTION_RELEASE','SV04_NEXT_EEPROM_RELEASE','SV04_NEXT_FLASH_RELEASE']:
   p=subprocess.run(['g++','-std=c++11','-x','c++','-fsyntax-only','-D'+k,'-I',str(ROOT/'src'),'-'],input='#include "SV04NextAudit66.hpp"',text=True,capture_output=True)
   self.assertNotEqual(p.returncode,0,k)
 def test_chain_contains_versions(self):
  s=(ROOT/'tools/apply_chain66.py').read_text()
  self.assertIn('from apply62',s);self.assertIn('from apply65',s);self.assertIn('from apply66',s)
 def test_no_command_invocations_in_patch(self):
  s=(ROOT/'tools/apply66.py').read_text();self.assertNotIn('process_subcommands_now_P',s);self.assertNotIn('RTS_SndData',s)
if __name__=='__main__':unittest.main()
