import unittest,subprocess,tempfile,sys
from pathlib import Path
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'tools'))
from apply77 import apply,RTS,HEADER,BRIDGE
from audit77 import audit
from test76 import Integration76
class Firewall77(unittest.TestCase):
 def fixture(self,root):
  f=Integration76().fixture(root)
  from apply76 import apply as apply76
  apply76(root,P/'src/SV04NextIntegration76.hpp')
  return f
 def test_cpp_no_uart(self):
  with tempfile.TemporaryDirectory() as d:
   exe=Path(d)/'driver'
   r=subprocess.run(['g++','-std=c++11','-Wall','-Wextra','-Werror','-pedantic',str(P/'tests/driver77.cpp'),'-o',str(exe)],capture_output=True,text=True)
   self.assertEqual(r.returncode,0,r.stderr)
   x=subprocess.run([str(exe)],capture_output=True,text=True)
   self.assertEqual(x.returncode,0,x.stderr);self.assertIn('NO_WRITES_OK',x.stdout)
 def test_all_release_macros_denied(self):
  for f in ['AUTO60','DWIN_TOUCH','T1_MOTION','EEPROM','FLASH']:
   r=subprocess.run(['g++','-std=c++11','-DSV04_NEXT_'+f+'_RELEASE','-fsyntax-only',str(P/'tests/driver77.cpp')],capture_output=True,text=True)
   self.assertNotEqual(r.returncode,0,f)
 def test_patch_and_audit(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);f=self.fixture(root)
   x=apply(root,P/'src/SV04NextHmiFirewall77.hpp')
   self.assertFalse(x['flash_approved']);self.assertTrue(audit(root)['pass'])
   self.assertIn('sv04next77::locked_update',f.read_text())
   with self.assertRaises(ValueError):apply(root,P/'src/SV04NextHmiFirewall77.hpp')
 def test_unknown_or_unlocked_source_denied(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);f=self.fixture(root)
   old=f.read_bytes();f.write_text(f.read_text().replace('sv04next75::update','sv04next99::update'))
   with self.assertRaises(ValueError):apply(root,P/'src/SV04NextHmiFirewall77.hpp')
   self.assertFalse((root/HEADER).exists())
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);f=self.fixture(root);(root/BRIDGE).write_text('MAPPING_CONFIRMED=true')
   with self.assertRaises(ValueError):apply(root,P/'src/SV04NextHmiFirewall77.hpp')
 def test_audit_detects_bypass(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);f=self.fixture(root);apply(root,P/'src/SV04NextHmiFirewall77.hpp')
   f.write_text(f.read_text().replace('sv04next77::locked_update','sv04next75::update'))
   self.assertFalse(audit(root)['pass'])
 def test_chain_python_syntax(self):
  for x in (P/'tools').glob('*.py'):compile(x.read_bytes(),str(x),'exec')
