import unittest,subprocess,tempfile,sys
from pathlib import Path
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'tools'))
from apply78 import apply,RTS,HEADER,OLD,NEW
from audit78 import audit
from test77 import Firewall77
class Hmi78(unittest.TestCase):
 def fixture(self,root):
  f=Firewall77().fixture(root)
  from apply77 import apply as apply77
  apply77(root,P/'src/SV04NextHmiFirewall77.hpp')
  s=f.read_text()
  # Real 70-series result page container absent in minimal test77 fixture.
  s=s.replace('// SV04 NEXT 68: render valid 4x4 OEM mesh',
    '// SV04 NEXT 70: only during OEM bed-level result transition;\n'
    '// SV04 NEXT 68: render valid 4x4 OEM mesh')
  # The fixture uses a short single-line stage77 call, so replace with exact
  # multiline production anchor only in synthetic fixture.
  short='sv04next77::locked_update(sv04_dwin70, get, [](uint16_t vp,int16_t z)->bool { rtscheck.RTS_SndData((int)z,vp); return true; }, millis(),true);'
  self.assertIn(short,s)
  s=s.replace(short,OLD)
  f.write_text(s)
  return f
 def test_cpp_no_writer(self):
  with tempfile.TemporaryDirectory() as d:
   exe=Path(d)/'driver'
   q=subprocess.run(['g++','-std=c++11','-Wall','-Wextra','-Werror','-pedantic',str(P/'tests/driver78.cpp'),'-o',str(exe)],capture_output=True,text=True)
   self.assertEqual(q.returncode,0,q.stderr)
   r=subprocess.run([str(exe)],capture_output=True,text=True)
   self.assertEqual(r.returncode,0,r.stderr);self.assertIn('SV04NEXT78_NO_WRITER_OK',r.stdout)
 def test_patch_and_audit(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);f=self.fixture(root)
   out=apply(root,P/'src/SV04NextHmiGate78.hpp')
   self.assertFalse(out['flash_approved'])
   self.assertNotIn('RTS_SndData',f.read_text().split('// SV04 NEXT 70:')[1].split('#endif')[0]) if '#endif' in f.read_text() else None
   self.assertIn(NEW,f.read_text())
   self.assertFalse(audit(root)['hmi_mapping_verified'])
   with self.assertRaises(ValueError):apply(root,P/'src/SV04NextHmiGate78.hpp')
 def test_unknown_refused_without_changes(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);f=self.fixture(root);s=f.read_text().replace(OLD,'sv04next99::foo();');f.write_text(s)
   with self.assertRaises(ValueError):apply(root,P/'src/SV04NextHmiGate78.hpp')
   self.assertEqual(f.read_text(),s);self.assertFalse((root/HEADER).exists())
 def test_gate_unlocked_refused(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);self.fixture(root)
   p=root/'Marlin/src/feature/SV04NextDwinBridge73.hpp';p.write_text('MAPPING_CONFIRMED=true')
   with self.assertRaises(ValueError):apply(root,P/'src/SV04NextHmiGate78.hpp')
 def test_compile_time_release_denied(self):
  for key in ('AUTO60','DWIN_TOUCH','T1_MOTION','EEPROM','FLASH'):
   q=subprocess.run(['g++','-std=c++11','-DSV04_NEXT_'+key+'_RELEASE','-fsyntax-only',str(P/'tests/driver78.cpp')],capture_output=True,text=True)
   self.assertNotEqual(q.returncode,0,key)
 def test_audit_detects_injected_writer(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);f=self.fixture(root)
   apply(root,P/'src/SV04NextHmiGate78.hpp')
   s=f.read_text().replace(NEW,NEW+' rtscheck.RTS_SndData(5,0x110E);')
   f.write_text(s)
   self.assertFalse(audit(root)['pass'])
 def test_all_scripts_syntax(self):
  for x in (P/'tools').glob('*.py'):compile(x.read_bytes(),str(x),'exec')
