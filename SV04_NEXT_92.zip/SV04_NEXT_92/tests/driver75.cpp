#include <cassert>
#include <cstdint>
#include <cmath>
#include <iostream>
#include "../src/SV04NextDwinDelivery75.hpp"
int main() {
  sv04next70::Presenter s;unsigned sent=0;
  const auto grid=[](uint8_t x,uint8_t y)->float {return float(x+y)*.1f;};
  const auto invalid=[](uint8_t x,uint8_t y)->float {return x==3&&y==3?NAN:float(x+y)*.1f;};
  const auto ok=[&sent](uint16_t,int16_t)->bool {++sent;return true;};
  assert(!sv04next75::update(s,grid,ok,600,true,false) && sent==0);
  assert(!sv04next75::update(s,grid,ok,600,false,true) && sent==0);
  assert(!sv04next75::update(s,invalid,ok,600,true,true) && sent==0);
  unsigned rejected=0;
  const auto fail7=[&rejected](uint16_t,int16_t)->bool {++rejected;return rejected!=7;};
  assert(!sv04next75::update(s,grid,fail7,600,true,true));
  assert(rejected==7 && !s.have_previous);
  assert(sv04next75::update(s,grid,ok,601,true,true));
  assert(sent==16 && s.have_previous);
  assert(!sv04next75::update(s,grid,ok,1200,true,true) && sent==16);
  const auto changed=[](uint8_t x,uint8_t y)->float {return float(x+y)*.1f+.02f;};
  unsigned failed=0;
  const auto fail16=[&failed](uint16_t,int16_t)->bool {++failed;return failed!=16;};
  assert(!sv04next75::update(s,changed,fail16,1201,true,true));
  assert(failed==16 && !s.have_previous);
  assert(sv04next75::update(s,changed,ok,1202,true,true));
  assert(sent==32);
  std::cout<<"SV04NEXT75_DELIVERY_RECOVERY_OK\n";
}
