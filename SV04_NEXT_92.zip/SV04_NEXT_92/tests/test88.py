import gzip,io,tarfile,tempfile,unittest,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))

class Test88(unittest.TestCase):
 def test_export_has_deterministic_time_and_metadata(self):
  src=(ROOT/'tools/integrate82.py').read_text()
  for marker in ["gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0)", 'info.mtime=0', 'info.uid=info.gid=0', "info.uname=info.gname=''", 'archive.addfile(info,io.BytesIO(payload))']:
   self.assertIn(marker,src)
 def test_roundtrip_same_bytes_across_rebuilds(self):
  import hashlib
  def build():
   raw=io.BytesIO()
   with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed:
    with tarfile.open(mode='w',fileobj=compressed,format=tarfile.PAX_FORMAT) as archive:
     data=b'int main(){return 0;}\n'
     info=tarfile.TarInfo('Marlin/src/feature/demo.hpp')
     info.size=len(data);info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';info.mode=0o644
     archive.addfile(info,io.BytesIO(data))
   return raw.getvalue()
  a,b=build(),build()
  self.assertEqual(hashlib.sha256(a).digest(),hashlib.sha256(b).digest())
  with tarfile.open(fileobj=io.BytesIO(a),mode='r:gz') as f:
   self.assertEqual(f.extractfile('Marlin/src/feature/demo.hpp').read(),b'int main(){return 0;}\n')
