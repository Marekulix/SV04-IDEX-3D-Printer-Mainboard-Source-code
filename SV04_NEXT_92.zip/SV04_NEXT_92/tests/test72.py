import unittest, tempfile, subprocess, sys, pathlib, json
R=pathlib.Path(__file__).resolve().parents[1]
class Stage72(unittest.TestCase):
 def test_cpp_wire_protocol(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d)/'driver72'
   subprocess.run(['g++','-std=c++11','-Wall','-Wextra','-Werror','-pedantic',str(R/'tests/driver72.cpp'),'-o',str(p)],check=True,capture_output=True)
   proc=subprocess.run([str(p)],check=True,capture_output=True,text=True)
   self.assertIn('SV04NEXT72_DGUS16_FRAME_CONTRACT_OK',proc.stdout)
 def test_hmi_inventory_fails_closed(self):
  sys.path.insert(0,str(R/'tools'))
  from audit_hmi72 import audit
  a=audit(R/'resources')
  self.assertFalse(a['stock_sovol_hmi_compatibility_verified'])
  self.assertFalse(a['flash_approved'])
  self.assertFalse(a['hmi_binary_generated'])
  self.assertFalse(a['has_hmi_source'])
 def test_hmi_inventory_detects_but_doesnt_approve(self):
  sys.path.insert(0,str(R/'tools'))
  from audit_hmi72 import audit
  with tempfile.TemporaryDirectory() as d:
   (pathlib.Path(d)/'DWprj.hmi').write_bytes(b'dummy')
   a=audit(d)
   self.assertTrue(a['has_hmi_source'])
   self.assertFalse(a['stock_sovol_hmi_compatibility_verified'])
 def test_five_release_gates(self):
  h=(R/'src/SV04NextDwinWire72.hpp').read_text()
  for t in ['SV04_NEXT_AUTO60_RELEASE','SV04_NEXT_DWIN_TOUCH_RELEASE','SV04_NEXT_T1_MOTION_RELEASE','SV04_NEXT_EEPROM_RELEASE','SV04_NEXT_FLASH_RELEASE']:
   self.assertIn(t,h)
 def test_no_actuating_code(self):
  h=(R/'src/SV04NextDwinWire72.hpp').read_text()
  for t in ['queue.enqueue','settings.save','thermalManager','planner.buffer','stepper.move']:
   self.assertNotIn(t,h)
 def test_all_python_sources_compile(self):
  for p in list((R/'tools').glob('*.py'))+list((R/'tests').glob('*.py')):
   compile(p.read_bytes(),str(p),'exec')
 def test_previous_patchchain_present(self):
  self.assertTrue((R/'tools/apply_chain70.py').is_file())
  self.assertTrue((R/'resources/SV04_NEXT_69_DWIN_SCREEN.bmp').is_file())
