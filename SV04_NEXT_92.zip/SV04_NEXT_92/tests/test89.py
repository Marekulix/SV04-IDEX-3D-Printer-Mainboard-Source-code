import hashlib,io,sys,tarfile,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from integrate82 import verify_overlay

class Test89(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
  self.root=Path(self.tmp.name);self.rel='Marlin/src/feature/SV04NextDemo.hpp'
  p=self.root/self.rel;p.parent.mkdir(parents=True);p.write_bytes(b'known source bytes\n')
  self.data=p.read_bytes()
  self.entry={'path':self.rel,'bytes':len(self.data),'sha256':hashlib.sha256(self.data).hexdigest()}
  self.archive=self.root/'overlay.tar.gz'
 def build(self, members):
  with tarfile.open(self.archive,'w:gz') as tar:
   for name,body in members:
    info=tarfile.TarInfo(name);info.size=len(body);tar.addfile(info,io.BytesIO(body))
 def test_exact_roundtrip(self):
  self.build([(self.rel,self.data)])
  self.assertEqual(verify_overlay(self.archive,[self.entry],self.root),1)
 def test_modified_bytes_rejected(self):
  self.build([(self.rel,b'known source bytex\n')])
  with self.assertRaises(RuntimeError):verify_overlay(self.archive,[self.entry],self.root)
 def test_missing_member_rejected(self):
  self.build([])
  with self.assertRaises(RuntimeError):verify_overlay(self.archive,[self.entry],self.root)
 def test_duplicate_member_rejected(self):
  self.build([(self.rel,self.data),(self.rel,self.data)])
  with self.assertRaises(RuntimeError):verify_overlay(self.archive,[self.entry],self.root)
 def test_unexpected_member_rejected(self):
  self.build([(self.rel,self.data),('extra.txt',b'no')])
  with self.assertRaises(RuntimeError):verify_overlay(self.archive,[self.entry],self.root)
 def test_manifest_duplicate_rejected(self):
  self.build([(self.rel,self.data)])
  with self.assertRaises(RuntimeError):verify_overlay(self.archive,[self.entry,self.entry],self.root)
