#include "../src/SV04NextHmiGate78.hpp"
#include <cassert>
#include <iostream>
int main(){
  sv04next70::Presenter p;
  p.have_previous=true;
  assert(!sv04next78::observe_only(p,1000));
  assert(!p.have_previous);
  assert(!sv04next78::HMI_VERIFIED);
  assert(!sv04next78::MESH_TRANSMISSION_ALLOWED);
  std::cout << "SV04NEXT78_NO_WRITER_OK\n";
}
