import pathlib,sys,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
class Chain(unittest.TestCase):
 def test_base62_vendored_exact(self):
  for original,copy in [(pathlib.Path('/mnt/data/SV04_NEXT_62/src/SV04NextGuard62.h'),ROOT/'base62/SV04NextGuard62.h'),(pathlib.Path('/mnt/data/SV04_NEXT_62/tools/apply62.py'),ROOT/'base62/apply62.py')]:
   if original.exists():self.assertEqual(original.read_bytes(),copy.read_bytes())
 def test_chain_requires_pinned_clean_tree(self):
  s=(ROOT/'tools/apply_chain65.py').read_text();self.assertIn("git('status','--porcelain')",s);self.assertIn("git('rev-parse','HEAD')",s)
 def test_firmware_guard_included(self):
  s=(ROOT/'tools/apply65.py').read_text()
  self.assertIn('#include',s)
  self.assertIn('SV04NextSafety65.hpp',s)
  self.assertIn('static_assert',s)
if __name__=='__main__':unittest.main()
