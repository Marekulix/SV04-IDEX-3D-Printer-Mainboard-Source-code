#include "SV04NextAudit66.hpp"
#include <assert.h>
#include <limits>
using namespace sv04next66;
static Sample s(unsigned seq,unsigned tm,float temp=60.f){return {seq,tm,temp,true,true,true,true};}
int main(){
 static_assert(!kAuto60Enabled && !kPhysicalT1Validated && !kTouchStartEnabled && !kEepromWriteEnabled && !kFlashApproved,"read-only");
 {Auditor a;assert(a.ingest(s(1,100))==AUDIT_NOT_READY);assert(a.ingest(s(2,200))==AUDIT_NOT_READY);assert(a.ingest(s(3,300))==AUDIT_OK);assert(a.model_ready());}
 {Auditor a;assert(a.ingest(s(1,100))==AUDIT_NOT_READY);assert(a.ingest(s(1,200))==AUDIT_BAD_DATA);assert(!a.model_ready());assert(a.ingest(s(3,300))==AUDIT_UNSAFE);}
 {Auditor a;assert(a.ingest(s(1,100))==AUDIT_NOT_READY);assert(a.ingest(s(2,100))==AUDIT_BAD_DATA);}
 {Auditor a;Sample v=s(1,100);v.t1_park_confirmed=false;assert(a.ingest(v)==AUDIT_UNSAFE);}
 {Auditor a;Sample v=s(1,100);v.probe_ok=false;assert(a.ingest(v)==AUDIT_UNSAFE);}
 {Auditor a;assert(a.ingest(s(1,100,62.f))==AUDIT_BAD_DATA);}
 {Auditor a;assert(a.ingest(s(1,100,std::numeric_limits<float>::quiet_NaN()))==AUDIT_BAD_DATA);}
 assert(physical_clearance_model(100.f,110.f,5.f));
 assert(!physical_clearance_model(100.f,105.f,5.f));
 assert(!physical_clearance_model(std::numeric_limits<float>::infinity(),110.f,2.f));
 bool seen[16]; float z[16];for(unsigned i=0;i<16;i++){seen[i]=true;z[i]=0.01f*i;}
 assert(mesh_complete_model(seen,z));seen[15]=false;assert(!mesh_complete_model(seen,z));seen[15]=true;z[3]=std::numeric_limits<float>::quiet_NaN();assert(!mesh_complete_model(seen,z));
 return 0;
}
