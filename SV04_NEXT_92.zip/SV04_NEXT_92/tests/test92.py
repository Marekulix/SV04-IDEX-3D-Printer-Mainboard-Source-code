import sys,unittest,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from audit_chain76 import audit
from integrate82 import verify_compiled_diagnostic
class Test92(unittest.TestCase):
 def test_elf_current_marker(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp)/'a.elf'
   p.write_bytes(b"\x7fELF SV04NEXT67 DIAG READONLY")
   self.assertTrue(verify_compiled_diagnostic(p))
   p.write_bytes(b"\x7fELF SV04NEXT62 DIAG READONLY")
   self.assertFalse(verify_compiled_diagnostic(p))
 def test_audit_correct_translation_unit(self):
  src=(ROOT/'tools/audit_chain76.py').read_text()
  self.assertIn('dwin_headers=',src)
  self.assertIn('G29 include count !=1',src)
  self.assertIn('SV04NEXT67 DIAG READONLY',src)
