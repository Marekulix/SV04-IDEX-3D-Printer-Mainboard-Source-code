import unittest, pathlib,sys,subprocess,tempfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from apply67 import apply,G29,DEST,HEADER,OLD,ANCHOR
class Test67(unittest.TestCase):
 def fixture(self,where):
  p=pathlib.Path(where);f=p/G29;f.parent.mkdir(parents=True)
  (p/'platformio.ini').write_text('[platformio]\n')
  (p/'Marlin/src/feature').mkdir(parents=True)
  (p/'Marlin/src/feature/SV04NextAudit66.hpp').write_text('// stage66')
  f.write_text(HEADER+ANCHOR+'if (parser.seen_test(\'U\')) { SERIAL_ECHOLNPGM("'+OLD+'"); }\n')
  return p
 def test_patch(self):
  with tempfile.TemporaryDirectory() as t:
   p=self.fixture(t);r=apply(p,ROOT/'src/SV04NextDwinContract67.hpp')
   self.assertTrue((p/DEST).exists());self.assertIn('SV04NEXT67 DIAG',(p/G29).read_text())
   self.assertIn('static_assert',(p/G29).read_text());self.assertFalse(r['flash_allowed'])
 def test_repeat_denied(self):
  with tempfile.TemporaryDirectory() as t:
   p=self.fixture(t);apply(p,ROOT/'src/SV04NextDwinContract67.hpp')
   with self.assertRaises(ValueError):apply(p,ROOT/'src/SV04NextDwinContract67.hpp')
 def test_unknown_denied(self):
  with tempfile.TemporaryDirectory() as t:
   p=self.fixture(t);(p/G29).write_text('bad')
   with self.assertRaises(ValueError):apply(p,ROOT/'src/SV04NextDwinContract67.hpp')
   self.assertFalse((p/DEST).exists())
 def test_native(self):
  with tempfile.TemporaryDirectory() as t:
   o=pathlib.Path(t)/'driver';subprocess.run(['g++','-std=c++11','-O2','-Wall','-Wextra','-Werror','-I',str(ROOT/'src'),str(ROOT/'tests/driver67.cpp'),'-o',str(o)],check=True)
   subprocess.run([str(o)],check=True)
 def test_release_guards(self):
  for k in ['SV04_NEXT_AUTO60_RELEASE','SV04_NEXT_DWIN_TOUCH_RELEASE','SV04_NEXT_T1_MOTION_RELEASE','SV04_NEXT_EEPROM_RELEASE','SV04_NEXT_FLASH_RELEASE']:
   r=subprocess.run(['g++','-std=c++11','-x','c++','-fsyntax-only','-D'+k,'-I',str(ROOT/'src'),'-'],input='#include "SV04NextDwinContract67.hpp"',capture_output=True,text=True)
   self.assertNotEqual(r.returncode,0,k)
 def test_no_runtime_actuation(self):
  s=(ROOT/'tools/apply67.py').read_text()
  for forbidden in ['RTS_SndData(', 'process_subcommands_now_P(', 'settings.save(', 'thermalManager.setTargetBed(']:
   self.assertNotIn(forbidden,s)
 def test_chain(self):
  s=(ROOT/'tools/apply_chain67.py').read_text()
  self.assertIn('from apply_chain66',s);self.assertIn('from apply67',s)
if __name__=='__main__':unittest.main()
