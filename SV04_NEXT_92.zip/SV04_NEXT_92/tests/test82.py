import ast,importlib.util,io,subprocess,sys,tarfile,tempfile,unittest,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from integrate82 import run

class Test82(unittest.TestCase):
 def test_python_compiles(self):
  ast.parse((ROOT/'tools/integrate82.py').read_text())
 def test_fails_missing_oem(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d)/'no_source';root.mkdir()
   with self.assertRaises((ValueError,subprocess.CalledProcessError)):
    run(root,Path(d)/'output')
 def test_no_fake_firmware_claim(self):
  s=(ROOT/'tools/integrate82.py').read_text()
  self.assertIn('stm32_build_tested',s)
  self.assertIn('proc.returncode==0 and binary.is_file() and elf.is_file()',s)
  self.assertIn('binary.stat().st_size>0 and elf.stat().st_size>0',s)
 def test_manifest_includes_untracked(self):
  s=(ROOT/'tools/integrate82.py').read_text()
  self.assertIn('--others',s)
  self.assertIn('archive.addfile(info,io.BytesIO(payload))',s)
 def test_audit_before_build(self):
  s=(ROOT/'tools/integrate82.py').read_text()
  self.assertLess(s.index('audit=verify(root)'),s.index("subprocess.run(['pio'"))
 def test_build_env(self):
  self.assertIn('STM32F103RET6_creality',(ROOT/'tools/integrate82.py').read_text())
 def test_overlay_real_roundtrip(self):
  with tempfile.TemporaryDirectory() as d:
   path=Path(d)/'Marlin/src/feature';path.mkdir(parents=True)
   (path/'demo.hpp').write_text('TEST HEADER\n')
   archive=Path(d)/'overlay.tar.gz'
   with tarfile.open(archive,'w:gz') as a:a.add(path/'demo.hpp',arcname='Marlin/src/feature/demo.hpp')
   with tarfile.open(archive,'r:gz') as a:
    data=a.extractfile('Marlin/src/feature/demo.hpp').read()
   self.assertEqual(data,b'TEST HEADER\n')
