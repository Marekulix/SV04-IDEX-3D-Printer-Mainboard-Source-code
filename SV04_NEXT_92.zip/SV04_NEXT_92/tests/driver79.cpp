#include "../src/SV04NextUnified79.hpp"
#include <assert.h>
#include <stdio.h>
int main() {
 using namespace sv04next79;
 float z[16]={}; uint32_t h=0;
 assert(!mesh_check(z,0,h) && !h);
 assert(mesh_check(z,0xffffu,h) && h);
 assert(!temp_stable(60,60,60,29000));
 assert(temp_stable(60,60.2f,59.9f,30000));
 assert(!temp_stable(60,62,60,30000));
 Realtime a={60,60,100,160,10,true,true,true,true,true,true,true,true};
 assert(t1_geometry(a));
 auto r=examine(a,z,0xffffu);
 assert(r.completed_points==16 && r.mesh_ok && r.eeprom_safe && r.t1_geometry_ok);
 assert(r.first_failure==HMI_UNVERIFIED && !r.can_start && !r.hmi_safe);
 a.t1_park_sensor_proven=false;
 r=examine(a,z,0xffffu);assert(r.first_failure==T1_UNVERIFIED && !r.can_start);
 a.t1_park_sensor_proven=true;a.bed_actual=62;
 r=examine(a,z,0xffffu);assert(r.first_failure==TEMP_INVALID);
 a.bed_actual=60;a.saved_mesh_backup_proven=false;
 r=examine(a,z,0xffffu);assert(r.first_failure==EEPROM_UNVERIFIED);
 assert(readback_matches(h,h,true) && !readback_matches(h,h+1,true) && !readback_matches(h,h,false));
 z[7]=NAN;assert(!mesh_check(z,0xffffu,h) && h==0);
 puts("SV04_NEXT_79_HOST_PASS");
}
