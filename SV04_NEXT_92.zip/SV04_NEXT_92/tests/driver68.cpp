#include "SV04NextDwinRenderer68.hpp"
#include <cassert>
#include <vector>
#include <utility>
#include <limits>
int main(){
 float mesh[4][4];for(int y=0;y<4;y++)for(int x=0;x<4;x++)mesh[x][y]=float(x+4*y)/1000.0f;
 int16_t values[16];
 assert(sv04next68::validate([&](uint8_t x,uint8_t y){return mesh[x][y];},values));
 std::vector<std::pair<int,int> > writes;
 sv04next68::send(values,[&](uint16_t vp,int16_t z){writes.push_back(std::make_pair(int(vp),int(z)));});
 assert(writes.size()==16);
 for(int i=0;i<16;i++){assert(writes[i].first==0x1100+2*i);assert(writes[i].second==int(sv04next68::linear_index_to_x(i)+4*sv04next68::linear_index_to_y(i)));}
 assert(writes[4].second==7 && writes[7].second==4 && writes[8].second==8);
 assert(writes[7].first==0x110e); // OEM overlap is documented, not disguised
 mesh[2][2]=std::numeric_limits<float>::quiet_NaN();assert(!sv04next68::validate([&](uint8_t x,uint8_t y){return mesh[x][y];},values));
 assert(!sv04next68::FLASH_APPROVED && !sv04next68::TOUCH_ENABLED);
}
