#include <cassert>
#include <cmath>
#include <cstdint>
#include <iostream>
#include "../src/SV04NextDwinBridge73.hpp"
struct Emitter {unsigned calls;uint16_t vp[32];int16_t val[32];Emitter():calls(0),vp(),val(){}
 void operator()(uint16_t a,int16_t b){assert(calls<32);vp[calls]=a;val[calls]=b;++calls;}};
int main(){
 sv04next70::Presenter p;
 Emitter out;
 auto grid=[](uint8_t x,uint8_t y)->float{return float(x+y)/10.0f;};
 auto callback=[&out](uint16_t a,int16_t v){out(a,v);};
 assert(!sv04next73::update(p,grid,callback,1000,true,false));assert(out.calls==0);
 assert(!sv04next73::update(p,grid,callback,1000,false,true));assert(out.calls==0);
 assert(sv04next73::update(p,grid,callback,1000,true,true));assert(out.calls==16);
 for(unsigned i=0;i<16;i++)assert(out.vp[i]==0x1100+2*i);
 assert(!sv04next73::update(p,grid,callback,2000,true,true));assert(out.calls==16);
 auto invalid=[](uint8_t x,uint8_t y)->float{return x==3&&y==3?NAN:float(x+y)/10.0f;};
 assert(!sv04next73::update(p,invalid,callback,2500,true,true));assert(out.calls==16);
 auto grid2=[](uint8_t x,uint8_t y)->float{return float(x+y)/10.0f+0.01f;};
 assert(!sv04next73::update(p,grid2,callback,2600,true,false));assert(out.calls==16);
 assert(sv04next73::update(p,grid2,callback,2601,true,true));assert(out.calls==32);
 std::cout<<"SV04NEXT73_OEM_BRIDGE_16_VALIDATED_OK\n";
}
