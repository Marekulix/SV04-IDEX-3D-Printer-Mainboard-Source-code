#include "../src/SV04NextDwinPresenter70.hpp"
#include <assert.h>
#include <math.h>
#include <vector>
#include <utility>
int main(){
 static_assert(!sv04next70::CAN_HEAT && !sv04next70::CAN_MOVE && !sv04next70::CAN_SAVE && !sv04next70::CAN_TOUCH && !sv04next70::CAN_FLASH,"release forbidden");
 sv04next70::Presenter p;
 float grid[4][4];for(int y=0;y<4;y++)for(int x=0;x<4;x++)grid[x][y]=float(x+y)/100.0f;
 auto get=[&](uint8_t x,uint8_t y){return grid[x][y];};
 std::vector<std::pair<uint16_t,int16_t>> log;
 auto send=[&](uint16_t a,int16_t z){log.push_back({a,z});};
 assert(!p.update(get,send,1000,false)&&log.empty());
 assert(p.update(get,send,1000,true)&&log.size()==16);
 for(int i=0;i<16;i++) assert(log[i].first==uint16_t(0x1100+2*i));
 assert(log[0].second==0);assert(log[4].second==40); // second row reversed, x3,y1
 assert(!p.update(get,send,1100,true)&&log.size()==16);
 grid[0][0]=0.123f;
 assert(!p.update(get,send,1400,true)&&log.size()==16);
 assert(p.update(get,send,1500,true)&&log.size()==32);
 grid[3][3]=NAN;
 assert(!p.update(get,send,2100,true)&&log.size()==32); // reject entire invalid snapshot
 grid[3][3]=0.06f;
 assert(p.update(get,send,2200,true)&&log.size()==48);
 p.invalidate();assert(p.update(get,send,2400,true)&&log.size()==64);
 return 0;
}
