#include "SV04NextDwinContract67.hpp"
#include <cassert>
#include <limits>
using namespace sv04next67;
int main() {
 static_assert(!kFlashApproved && !kTouchEnabled && !kEepromEnabled && !kAuto60Enabled && !kT1MovementEnabled,"release guard");
 MeshSnapshot m; assert(!m.complete() && m.count()==0);auto v=view(m);
 assert(v.stage==67 && v.status==DIAGNOSTIC && !v.heating && !v.motion && !v.save && !v.touch);
 for(unsigned i=0;i<16;i++) {assert(m.add(i,0.125f,i+1));assert(m.count()==i+1);}
 assert(m.complete()); assert(m.z_microns[0]==125);assert(m.z_microns[15]==125);
 assert(!m.add(0,0.0f,17));assert(m.fault && !m.complete() && view(m).status==FAULT);
 MeshSnapshot n;assert(!n.add(0,std::numeric_limits<float>::quiet_NaN(),1));
 MeshSnapshot o;assert(!o.add(16,0.0f,1));
 MeshSnapshot p;assert(p.add(0,0.0f,1));assert(!p.add(1,0.0f,1));
 MeshSnapshot q;assert(!q.add(0,2.01f,1));
 MeshSnapshot r;assert(r.add(0,-2.0f,1));assert(r.add(1,2.0f,2));
 return 0;
}
