#include "../src/SV04NextIntegration76.hpp"
#include <cassert>
#include <cstdio>
int main() {
  static_assert(sv04next76::vp(0)==0x1100,"VP0");
  static_assert(sv04next76::vp(15)==0x111e,"VP15");
  static_assert(!sv04next76::CAN_FLASH,"flash denied");
  assert(sv04next76::vp(7)==0x110E);
  std::puts("SV04NEXT76_GATES_OK");
}
