import ast, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class Integration83(unittest.TestCase):
    def test_source_parses(self):
        ast.parse((ROOT/'tools/integrate82.py').read_text())
    def test_stale_outputs_removed_before_build(self):
        s=(ROOT/'tools/integrate82.py').read_text()
        self.assertLess(s.index('stale.unlink()'), s.index("subprocess.run(['pio'"))
    def test_failures_persist_in_report(self):
        s=(ROOT/'tools/integrate82.py').read_text()
        self.assertIn("result['build_failure']",s)
        self.assertIn("result['stm32_build_log_sha256']=sha(log)",s)
        self.assertIn('raise RuntimeError',s)
    def test_both_nonempty_artifacts_required(self):
        s=(ROOT/'tools/integrate82.py').read_text()
        self.assertIn('binary.stat().st_size>0 and elf.stat().st_size>0',s)
