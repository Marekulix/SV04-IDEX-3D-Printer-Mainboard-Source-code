import unittest,tempfile,pathlib,subprocess,sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from apply68 import apply,RTS,G29,HEADER,ENTRY
class Dwin68(unittest.TestCase):
 def test_native(self):
  with tempfile.TemporaryDirectory() as t:
   o=pathlib.Path(t)/'test';subprocess.run(['g++','-std=c++11','-O2','-Wall','-Wextra','-Werror','-I',str(ROOT/'src'),str(ROOT/'tests/driver68.cpp'),'-o',str(o)],check=True);subprocess.run([str(o)],check=True)
 def fixture(self,folder):
  p=pathlib.Path(folder);(p/'platformio.ini').write_text('')
  f=p/RTS;f.parent.mkdir(parents=True);f.write_text('#include "LCD_RTS.h"\n'+ENTRY+'\n  }\n}\n')
  g=p/G29;g.parent.mkdir(parents=True);g.write_text('SV04NEXT67 DIAG')
  h=p/'Marlin/src/feature/SV04NextDwinContract67.hpp';h.parent.mkdir(parents=True);h.write_text('// 67')
  return p
 def test_patch_and_repeat_denied(self):
  with tempfile.TemporaryDirectory() as t:
   p=self.fixture(t);result=apply(p,ROOT/'src/SV04NextDwinRenderer68.hpp');self.assertFalse(result['flash_approved']);s=(p/RTS).read_text();self.assertIn('leveling_is_valid()',s);self.assertIn('RTS_SndData((int)z,vp)',s)
   with self.assertRaises(ValueError):apply(p,ROOT/'src/SV04NextDwinRenderer68.hpp')
 def test_refuse_unknown_source(self):
  with tempfile.TemporaryDirectory() as t:
   p=self.fixture(t);(p/RTS).write_text('bad')
   with self.assertRaises(ValueError):apply(p,ROOT/'src/SV04NextDwinRenderer68.hpp')
 def test_compile_gates(self):
  for flag in ('AUTO60','DWIN_TOUCH','T1_MOTION','EEPROM','FLASH'):
   p=subprocess.run(['g++','-std=c++11','-fsyntax-only','-x','c++','-I',str(ROOT/'src'),'-D'+'SV04_NEXT_'+flag+'_RELEASE','-'],input='#include "SV04NextDwinRenderer68.hpp"\n',capture_output=True,text=True);self.assertNotEqual(p.returncode,0,flag)
 def test_no_actuation(self):
  text=(ROOT/'tools/apply68.py').read_text()
  for value in ['settings.save(', 'queue.enqueue_now_P(', 'thermalManager.setTargetBed(', 'stepper.move(']:self.assertNotIn(value,text)
if __name__=='__main__':unittest.main()
