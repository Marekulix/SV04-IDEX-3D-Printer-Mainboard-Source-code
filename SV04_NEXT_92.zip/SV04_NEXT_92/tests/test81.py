import unittest, tempfile, subprocess, pathlib, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
import verify81

class SourceIntegration81(unittest.TestCase):
    def fixture(self, location):
        r=pathlib.Path(location)
        subprocess.run(['git','init','-q',str(r)],check=True)
        subprocess.run(['git','-C',str(r),'config','user.email','tests@example.invalid'],check=True)
        subprocess.run(['git','-C',str(r),'config','user.name','Test'],check=True)
        (r/'platformio.ini').write_text('[env]\n')
        g=r/verify81.G29;d=r/verify81.RTS
        for f in (g,d):f.parent.mkdir(parents=True,exist_ok=True)
        g.write_text('SV04NEXT62 DIAG READONLY\nSV04 NEXT 79\n')
        d.write_text('SV04NextGuard62.h\nSV04NextHmiGate78.hpp\nSV04NextUnified79.hpp\n')
        for name in ['SV04NextGuard62.h','SV04NextHmiGate78.hpp','SV04NextUnified79.hpp']:
            p=r/'Marlin/src/feature'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('// test header\n')
        subprocess.run(['git','-C',str(r),'add','.'],check=True)
        subprocess.run(['git','-C',str(r),'commit','-qm','baseline'],check=True)
        g.write_text(g.read_text()+'// modified\n')
        return r,g,d
    def test_missing_source(self):
        with tempfile.TemporaryDirectory() as t:
            with self.assertRaisesRegex(verify81.VerificationFailure,'platformio'):
                verify81.verify(t)
    def test_wrong_revision(self):
        with tempfile.TemporaryDirectory() as t:
            r,g,d=self.fixture(t)
            with self.assertRaisesRegex(verify81.VerificationFailure,'revision'):
                verify81.verify(r)
    def test_include_resolution_detects_missing_header(self):
        with tempfile.TemporaryDirectory() as t:
            r,g,d=self.fixture(t)
            # For this synthetic fixture only, patch base check to exercise include walk.
            old=verify81.BASE;verify81.BASE=subprocess.check_output(['git','-C',str(r),'rev-parse','HEAD'],text=True).strip()
            try:
                d.write_text(d.read_text()+'#include "../../../feature/does-not-exist81.hpp"\n')
                with self.assertRaisesRegex(verify81.VerificationFailure,'missing source include'):
                    verify81.verify(r)
            finally:verify81.BASE=old
    def test_valid_local_include(self):
        with tempfile.TemporaryDirectory() as t:
            r,g,d=self.fixture(t)
            old=verify81.BASE;verify81.BASE=subprocess.check_output(['git','-C',str(r),'rev-parse','HEAD'],text=True).strip()
            try:
                d.write_text(d.read_text()+'#include "../../../feature/SV04NextGuard62.h"\n')
                result=verify81.verify(r)
                self.assertTrue(result['verification_passed'])
                self.assertTrue(result['resolved_relative_includes'])
            finally:verify81.BASE=old
    def test_diff_whitespace_failure(self):
        with tempfile.TemporaryDirectory() as t:
            r,g,d=self.fixture(t)
            old=verify81.BASE;verify81.BASE=subprocess.check_output(['git','-C',str(r),'rev-parse','HEAD'],text=True).strip()
            try:
                g.write_text(g.read_text()+'trailing space   \n')
                with self.assertRaisesRegex(verify81.VerificationFailure,'diff --check'):
                    verify81.verify(r)
            finally:verify81.BASE=old
    def test_scripts_compile(self):
        for name in ['verify81.py','integrate81.py']:
            compile((ROOT/'tools'/name).read_text(),name,'exec')

if __name__=='__main__': unittest.main()
