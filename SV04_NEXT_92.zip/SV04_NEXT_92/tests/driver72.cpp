#include "../src/SV04NextDwinWire72.hpp"
#include <cassert>
#include <cmath>
#include <cstdio>
int main() {
  for(int i=0;i<16;i++) {
    sv04next72::Frame f{};
    const uint16_t vp=sv04next68::address(i);
    const int16_t value=int16_t(i*120-900);
    assert(sv04next72::encode(vp,value,f));
    assert(f.bytes[0]==0x5A && f.bytes[1]==0xA5 && f.bytes[2]==5 && f.bytes[3]==0x82);
    uint16_t vp2=0;int16_t value2=0;
    assert(sv04next72::decode(f.bytes,vp2,value2));
    assert(vp2==vp && value2==value);
  }
  sv04next72::Frame f{};
  assert(!sv04next72::encode(0x1101,4,f));
  assert(!sv04next72::encode(0x10FE,4,f));
  assert(!sv04next72::encode(0x1120,4,f));
  assert(sv04next72::known_oem_collision(0x110E));
  assert(!sv04next72::known_oem_collision(0x110C));
  int count=0;
  auto sink=[&count](const sv04next72::Frame&){++count;};
  auto mesh=[](uint8_t x,uint8_t y)->float{return float(int(x)+4*int(y)-8)*0.1f;};
  assert(!sv04next72::encode_mesh(mesh,sink,false) && count==0);
  assert(sv04next72::encode_mesh(mesh,sink,true) && count==16);
  count=0;
  auto broken=[](uint8_t x,uint8_t y)->float{return x==3&&y==3?NAN:0.1f;};
  assert(!sv04next72::encode_mesh(broken,sink,true) && count==0);
  assert(!sv04next72::CAN_FLASH && !sv04next72::CAN_SAVE && !sv04next72::CAN_TOUCH);
  puts("SV04NEXT72_DGUS16_FRAME_CONTRACT_OK");
}
