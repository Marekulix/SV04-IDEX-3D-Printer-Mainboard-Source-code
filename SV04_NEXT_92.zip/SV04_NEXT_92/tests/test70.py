import sys, tempfile, unittest, subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from apply70 import apply, BEFORE, EXIST, RTS, OUT

class Dwin70(unittest.TestCase):
    def compile_driver(self, *extra):
        with tempfile.TemporaryDirectory() as t:
            out=Path(t)/'test'
            cmd=['g++','-std=c++11','-Werror','-Wall','-Wextra',*extra,str(ROOT/'tests/driver70.cpp'),'-o',str(out)]
            p=subprocess.run(cmd,capture_output=True,text=True)
            return p, (subprocess.run([str(out)],capture_output=True) if p.returncode==0 else None)

    def source(self, root):
        (root/'platformio.ini').write_text('[platformio]\n')
        (root/'Marlin/src/feature').mkdir(parents=True)
        (root/'Marlin/src/feature/SV04NextDwinRenderer68.hpp').write_text('// 68\n')
        f=root/RTS
        f.parent.mkdir(parents=True)
        f.write_text(EXIST+'void RTS_AutoBedLevelPage()\n{\n  if(waitway == 3)\n  {\n'+BEFORE+'}\n')
        return f

    def test_cpp_host(self):
        p,run=self.compile_driver()
        self.assertEqual(p.returncode,0,p.stderr)
        self.assertEqual(run.returncode,0,run.stderr)

    def test_release_flags_rejected(self):
        for flag in ('SV04_NEXT_AUTO60_RELEASE','SV04_NEXT_DWIN_TOUCH_RELEASE','SV04_NEXT_T1_MOTION_RELEASE','SV04_NEXT_EEPROM_RELEASE','SV04_NEXT_FLASH_RELEASE'):
            with self.subTest(flag=flag):
                p,_=self.compile_driver('-D'+flag)
                self.assertNotEqual(p.returncode,0)
                self.assertIn('SV04 NEXT 70',p.stderr)

    def test_patch_and_repeat_denied(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);f=self.source(root)
            before=f.read_bytes()
            report=apply(root,ROOT/'src/SV04NextDwinPresenter70.hpp')
            self.assertFalse(report['flash_approved'])
            self.assertNotEqual(before,f.read_bytes())
            self.assertIn('sv04_dwin70.update',f.read_text())
            self.assertIn('SV04 NEXT 70', (root/OUT).read_text())
            with self.assertRaises(ValueError):apply(root,ROOT/'src/SV04NextDwinPresenter70.hpp')

    def test_unknown_source_not_modified(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);f=self.source(root)
            f.write_text(f.read_text().replace('SV04 NEXT 68','SV04 NEXT 69'))
            before=f.read_bytes()
            with self.assertRaises(ValueError):apply(root,ROOT/'src/SV04NextDwinPresenter70.hpp')
            self.assertEqual(before,f.read_bytes())
            self.assertFalse((root/OUT).exists())

    def test_no_gcode_or_eeprom_call_in_stage70(self):
        code=(ROOT/'tools/apply70.py').read_text()
        replacement=code.split('AFTER="""')[1].split('"""',1)[0]
        for forbidden in ('settings.save(', 'queue.enqueue', 'G28', 'G29', 'M500', 'M190', 'setTarget', 'move_to'):
            self.assertNotIn(forbidden,replacement)

    def test_version_chain(self):
        code=(ROOT/'tools/apply_chain70.py').read_text()
        self.assertIn('from apply_chain68 import run',code)
        self.assertIn('from apply70 import apply',code)

if __name__=='__main__':unittest.main()
