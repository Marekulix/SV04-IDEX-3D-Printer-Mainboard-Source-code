#include <cassert>
#include <cmath>
#include <cstdint>
#include <iostream>
#include "../src/SV04NextDwinAtomic74.hpp"
struct Output {unsigned n; uint16_t vp[32]; int16_t val[32];Output():n(0),vp(),val(){}
  void send(uint16_t a,int16_t b){assert(n<32);vp[n]=a;val[n]=b;n++;}};
int main(){
  Output out; sv04next70::Presenter state;
  auto send=[&out](uint16_t a,int16_t b){out.send(a,b);};
  auto grid=[](uint8_t x,uint8_t y)->float{return float(x+y)/10.0f;};
  assert(!sv04next74::update(state,grid,send,500,true,false));assert(out.n==0);
  assert(!sv04next74::update(state,grid,send,500,false,true));assert(out.n==0);
  auto bad=[](uint8_t x,uint8_t y)->float{return (x==3&&y==3)?NAN:float(x+y)/10.0f;};
  assert(!sv04next74::update(state,bad,send,500,true,true));assert(out.n==0);
  assert(!state.have_previous);
  assert(sv04next74::update(state,grid,send,500,true,true));assert(out.n==16);
  for(unsigned i=0;i<16;i++)assert(out.vp[i]==0x1100+2*i);
  assert(!sv04next74::update(state,grid,send,1000,true,true));assert(out.n==16);
  auto grid2=[](uint8_t x,uint8_t y)->float{return float(x+y)/10.0f+0.01f;};
  assert(!sv04next74::update(state,grid2,send,1100,false,true));assert(out.n==16);
  assert(sv04next74::update(state,grid2,send,1101,true,true));assert(out.n==32);
  // Independent batch validates exact address order and rejects overflow BEFORE dispatch.
  sv04next74::Batch b;
  b.collect(0x1102,100);assert(!b.valid);assert(!b.complete());
  sv04next74::Batch b2;
  for(unsigned i=0;i<16;i++)b2.collect(uint16_t(0x1100+2*i),int16_t(i));
  assert(b2.complete());b2.collect(0x1120,99);assert(!b2.complete());
  std::cout<<"SV04NEXT74_ATOMIC_PREFLIGHT_16_OK\n";
}
