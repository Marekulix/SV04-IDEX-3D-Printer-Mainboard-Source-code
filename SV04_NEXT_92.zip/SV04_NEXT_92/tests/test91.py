import sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from integrate82 import verify_compiled_diagnostic

class BuildProof91(unittest.TestCase):
    def test_existing_elf_marker(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'firmware.elf'
            p.write_bytes(b'\x7fELF...' + b'SV04NEXT67 DIAG READONLY' + b'\x00')
            self.assertTrue(verify_compiled_diagnostic(p))

    def test_original_firmware_elf_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'firmware.elf'
            p.write_bytes(b'\x7fELF OEM WITHOUT NEXT DIAGNOSTIC')
            self.assertFalse(verify_compiled_diagnostic(p))

    def test_missing_and_empty_elf_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'firmware.elf'
            self.assertFalse(verify_compiled_diagnostic(p))
            p.write_bytes(b'')
            self.assertFalse(verify_compiled_diagnostic(p))
