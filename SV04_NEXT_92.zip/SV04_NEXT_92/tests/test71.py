import sys, unittest, tempfile, shutil, subprocess, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from audit_dwin71 import audit, bmp_info

class Stage71(unittest.TestCase):
 def test_all_python_compiles(self):
  files=list(ROOT.rglob('*.py'))
  self.assertGreater(len(files),12)
  for p in files:
   with self.subTest(path=p.name):
    compile(p.read_bytes(),str(p),'exec')
 def test_pinned_layout(self):
  report=audit(ROOT)
  self.assertEqual(len(report['oem_16_vps']),16)
  self.assertIn('0x110e',report['collisions'])
  self.assertFalse(report['flash_approved'])
  self.assertFalse(report['hmi_project_verified'])
  self.assertFalse(report['dwin_bin_generated'])
 def test_bad_bmp_truncation(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'bad.bmp';src=ROOT/'resources/SV04_NEXT_69_DWIN_SCREEN.bmp'
   p.write_bytes(src.read_bytes()[:-5])
   with self.assertRaises(ValueError):bmp_info(p)
 def test_bad_bmp_header(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'bad.bmp';p.write_bytes(b'not-bmp')
   with self.assertRaises(ValueError):bmp_info(p)
 def test_layout_release_refused(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d);(p/'resources').mkdir()
   import json
   layout=json.loads((ROOT/'resources/SV04_NEXT_69_Layout.json').read_text())
   layout['touch_enabled']=True
   (p/'resources/SV04_NEXT_69_Layout.json').write_text(json.dumps(layout))
   with self.assertRaises(ValueError):audit(p)
 def test_chain70_import(self):
  # Previous build's chain had an unterminated string literal.
  import importlib
  importlib.import_module('apply_chain70')
 def test_no_write_or_motion_from_audit(self):
  s=(ROOT/'tools/audit_dwin71.py').read_text()
  for x in ('settings.save(', 'queue.enqueue_now', 'M190 ', 'G28 ', 'G29 ', 'M500 ', 'RTS_SndData('):
   self.assertNotIn(x,s)

if __name__=='__main__':unittest.main()
