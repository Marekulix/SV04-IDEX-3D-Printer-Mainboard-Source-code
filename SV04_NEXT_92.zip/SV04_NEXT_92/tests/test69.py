import unittest,subprocess,sys,json,tempfile
from pathlib import Path
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
class Test69(unittest.TestCase):
 def test_chain68_is_valid_python(self):
  import ast
  ast.parse((ROOT/'tools/apply_chain68.py').read_text())
 def test_compiled_assets(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'image.png';subprocess.run([sys.executable,str(ROOT/'tools/render_dwin69.py'),'--output',str(p)],check=True,capture_output=True)
   with Image.open(p) as img:self.assertEqual(img.size,(272,480))
   with Image.open(p.with_suffix('.bmp')) as img:
    self.assertEqual(img.size,(272,480))
    self.assertEqual(img.mode,'RGB')
 def test_contract(self):
  j=json.loads((ROOT/'resources/SV04_NEXT_69_Layout.json').read_text());self.assertFalse(j['touch_enabled']);self.assertFalse(j['flash_approved']);self.assertEqual(len(j['original_oem_mesh_vps']),16);self.assertEqual(j['resolution'],[272,480]);self.assertEqual(j['oem_vp_collision_known'],'0x110E')
 def test_preview_never_dispatches_commands(self):
  s=(ROOT/'resources/SV04_NEXT_69_DWIN_OFFLINE.html').read_text().lower()
  self.assertNotIn('navigator.serial',s);self.assertNotIn('websocket',s);self.assertNotIn('fetch(',s);self.assertNotIn('sendgcode(',s)
 def test_headers_all_locked(self):
  s=(ROOT/'src/SV04NextDwinRenderer68.hpp').read_text();self.assertIn('FLASH_APPROVED=false',s)
if __name__=='__main__':unittest.main()
