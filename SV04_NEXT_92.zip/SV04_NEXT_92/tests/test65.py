import pathlib,subprocess,tempfile,unittest,sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from apply65 import patch,G29,DEST
class Check65(unittest.TestCase):
 def fixture(self,td):
  r=pathlib.Path(td);(r/G29).parent.mkdir(parents=True)
  (r/'platformio.ini').write_text('[platformio]\n')
  (r/'Marlin/src/feature').mkdir(parents=True,exist_ok=True)
  (r/'Marlin/src/feature/SV04NextGuard62.h').write_text('// 62\n')
  (r/G29).write_text('#include "../../../feature/SV04NextGuard62.h"\nG29_TYPE GcodeSuite::G29() {\n  // SV04 NEXT 62 read-only diagnostic. Exact U+Q combination only.\n  if (parser.seen_test(\'U\') && parser.seen_test(\'Q\')) {\n    SERIAL_ECHOLNPGM("SV04NEXT62 DIAG READONLY AUTO60=0 T1=0 EEPROM=0 DWIN_TOUCH=0 FLASH=0");\n    G29_RETURN(false);\n  }\n}\n')
  return r
 def test_patch(self):
  with tempfile.TemporaryDirectory() as d:
   r=self.fixture(d);p=patch(r,ROOT/'src/SV04NextSafety65.hpp');self.assertFalse(p['flash_approved']);self.assertTrue((r/DEST).exists());self.assertIn('static_assert',(r/G29).read_text())
 def test_repeat_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   r=self.fixture(d);patch(r,ROOT/'src/SV04NextSafety65.hpp')
   with self.assertRaises(ValueError):patch(r,ROOT/'src/SV04NextSafety65.hpp')
 def test_unknown_rejected_no_write(self):
  with tempfile.TemporaryDirectory() as d:
   r=self.fixture(d);(r/G29).write_text('unknown')
   with self.assertRaises(ValueError):patch(r,ROOT/'src/SV04NextSafety65.hpp')
   self.assertFalse((r/DEST).exists())
 def test_no_actuators(self):
  s=(ROOT/'tools/apply65.py').read_text()
  for v in ['M500','M190','G28','G29 U P','RTS_SndData','process_subcommands_now_P']:self.assertNotIn(v,s)
 def test_cpp_host(self):
  with tempfile.TemporaryDirectory() as d:
   out=pathlib.Path(d)/'test'
   subprocess.run(['g++','-std=c++11','-O2','-Wall','-Wextra','-Werror','-I',str(ROOT/'src'),str(ROOT/'tests/driver65.cpp'),'-o',str(out)],check=True)
   subprocess.run([str(out)],check=True)
 def test_release_macros_denied(self):
  for k in ['SV04_NEXT_AUTO60_RELEASE','SV04_NEXT_DWIN_TOUCH_RELEASE','SV04_NEXT_T1_MOTION_RELEASE','SV04_NEXT_EEPROM_RELEASE','SV04_NEXT_FLASH_RELEASE']:
   p=subprocess.run(['g++','-x','c++','-std=c++11','-D'+k,'-I',str(ROOT/'src'),'-fsyntax-only','-'],input='#include "SV04NextSafety65.hpp"',text=True,capture_output=True)
   self.assertNotEqual(p.returncode,0,k)
if __name__=='__main__':unittest.main()
