import unittest,subprocess,tempfile,sys
from pathlib import Path
P=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(P/'tools'))
from apply75 import apply,RTS,HEAD,OLD,OLD_SEND,NEW,NEW_SEND
class Stage75(unittest.TestCase):
 def source(self,r):
  (r/'platformio.ini').write_text('[platformio]\n')
  f=r/RTS;f.parent.mkdir(parents=True)
  f.write_text('#include "../../../feature/SV04NextDwinAtomic74.hpp"\n'
   'sv04next74::update(sv04_dwin70, get, '
   '[](uint16_t vp,int16_t z){ rtscheck.RTS_SndData((int)z,vp); },'
   'millis(),true,sv04next73::MAPPING_CONFIRMED);\n')
  d=r/'Marlin/src/feature';d.mkdir(parents=True,exist_ok=True)
  (d/'SV04NextDwinAtomic74.hpp').write_text('// stage74')
  (d/'SV04NextDwinBridge73.hpp').write_text('static constexpr bool MAPPING_CONFIRMED=false;')
  return f
 def test_cpp_recovery(self):
  with tempfile.TemporaryDirectory() as td:
   exe=Path(td)/'test75'
   c=subprocess.run(['g++','-std=c++11','-Wall','-Wextra','-Werror','-pedantic',str(P/'tests/driver75.cpp'),'-o',str(exe)],capture_output=True,text=True)
   self.assertEqual(c.returncode,0,c.stderr)
   o=subprocess.run([str(exe)],capture_output=True,text=True)
   self.assertEqual(o.returncode,0,o.stderr);self.assertIn('RECOVERY_OK',o.stdout)
 def test_release_denials(self):
  for flag in ['SV04_NEXT_AUTO60_RELEASE','SV04_NEXT_DWIN_TOUCH_RELEASE','SV04_NEXT_T1_MOTION_RELEASE','SV04_NEXT_EEPROM_RELEASE','SV04_NEXT_FLASH_RELEASE']:
   with self.subTest(flag=flag):
    r=subprocess.run(['g++','-std=c++11','-D'+flag,'-fsyntax-only',str(P/'tests/driver75.cpp')],capture_output=True,text=True)
    self.assertNotEqual(r.returncode,0)
 def test_patch_and_repeated_refusal(self):
  with tempfile.TemporaryDirectory() as td:
   r=Path(td);f=self.source(r)
   a=apply(r,P/'src/SV04NextDwinDelivery75.hpp')
   self.assertFalse(a['physical_dwin_ack']);self.assertFalse(a['firmware_writes_enabled'])
   self.assertIn(NEW,f.read_text());self.assertIn(NEW_SEND,f.read_text());self.assertTrue((r/HEAD).exists())
   with self.assertRaises(ValueError):apply(r,P/'src/SV04NextDwinDelivery75.hpp')
 def test_unknown_source_untouched(self):
  with tempfile.TemporaryDirectory() as td:
   r=Path(td);f=self.source(r);f.write_text(f.read_text().replace(OLD,'broken::update('));o=f.read_bytes()
   with self.assertRaises(ValueError):apply(r,P/'src/SV04NextDwinDelivery75.hpp')
   self.assertEqual(f.read_bytes(),o);self.assertFalse((r/HEAD).exists())
 def test_lock_required(self):
  with tempfile.TemporaryDirectory() as td:
   r=Path(td);self.source(r)
   (r/'Marlin/src/feature/SV04NextDwinBridge73.hpp').write_text('MAPPING_CONFIRMED=true')
   with self.assertRaises(ValueError):apply(r,P/'src/SV04NextDwinDelivery75.hpp')
 def test_scripts_compile_no_actuators(self):
  for f in (P/'tools').glob('*.py'):compile(f.read_bytes(),str(f),'exec')
  s=(P/'src/SV04NextDwinDelivery75.hpp').read_text()
  for bad in ['queue.enqueue','settings.save','thermalManager','planner.buffer','M500']:
   self.assertNotIn(bad,s)
  self.assertIn('from apply_chain74 import run', (P/'tools/apply_chain75.py').read_text())
