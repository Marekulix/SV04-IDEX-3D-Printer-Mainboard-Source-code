#!/usr/bin/env python3
"""Pinned OEM -> 62 -> 65 -> 66 -> 67 -> 68 -> 70 -> 73 -> 74 -> 75."""
import argparse,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from apply_chain74 import run as run74
from apply75 import apply as apply75
def run(root,report):
 earlier=run74(root,str(Path(report).with_suffix('.74.json')))
 last=apply75(root,ROOT/'src/SV04NextDwinDelivery75.hpp')
 result={'history':earlier,'stage75':last,'flash_approved':False}
 Path(report).write_text(json.dumps(result,indent=2)+'\n')
 return result
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);ap.add_argument('--report',required=True);a=ap.parse_args()
 run(a.root,a.report)
