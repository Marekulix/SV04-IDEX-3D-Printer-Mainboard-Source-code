#!/usr/bin/env python3
"""Integrate stage 62..79 into a pinned clean OEM checkout and produce an independently
replayable source overlay + patch. Requires actual OEM tree. --build compiles STM32.
No firmware binary is marked installable without successful compilation.
"""
import argparse,gzip,hashlib,io,json,subprocess,sys,tarfile,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from integrate80 import integrate, sha
from verify81 import verify

def compile_integrated_headers(root, out):
    """Compile all SV04-NEXT headers TOGETHER under C++11, not separately.

    GCC host check is independent from a successful STM32/Marlin build.
    """
    src=Path(root)/'Marlin/src/feature'
    names=sorted(p for p in src.glob('SV04Next*.h*') if p.is_file())
    if len(names)<13:
        raise RuntimeError(f'incomplete SV04 NEXT header integration: {len(names)} headers')
    code='#include <stdint.h>\n'+''.join(f'#include "{p.name}"\n' for p in names)+'int main(){return 0;}\n'
    with tempfile.TemporaryDirectory(prefix='sv04_headers_') as directory:
        unit=Path(directory)/'all_sv04_next.cpp';unit.write_text(code)
        proc=subprocess.run(['g++','-std=c++11','-fsyntax-only','-I',str(src),str(unit)],
                            text=True,capture_output=True)
    (Path(out)/'combined-headers-cxx11.log').write_text(proc.stdout+proc.stderr)
    if proc.returncode:
        raise RuntimeError('combined C++11 headers failed: combined-headers-cxx11.log')
    return len(names)

def verify_overlay(archive_path, manifest, root):
    """Read exported source BACK and compare every byte to the integrated checkout.

    Enforce a one-to-one file mapping. A manifest alone cannot prove the
    tarball contains the firmware that was audited.
    """
    expected={entry['path']:entry for entry in manifest}
    if len(expected)!=len(manifest) or not expected:
        raise RuntimeError('overlay manifest has duplicate paths or is empty')
    seen=set()
    with tarfile.open(archive_path,'r:gz') as archive:
        for item in archive:
            rel=item.name
            if not item.isfile() or item.issym() or item.islnk():
                raise RuntimeError('overlay contains a non-regular entry: '+rel)
            if rel not in expected or rel in seen:
                raise RuntimeError('overlay contains unexpected or duplicate path: '+rel)
            source=(Path(root)/rel).resolve()
            if not source.is_relative_to(Path(root).resolve()):
                raise RuntimeError('overlay path escapes source tree: '+rel)
            data=archive.extractfile(item).read()
            entry=expected[rel]
            if len(data)!=entry['bytes'] or hashlib.sha256(data).hexdigest()!=entry['sha256']:
                raise RuntimeError('overlay has corrupt data: '+rel)
            if data!=source.read_bytes():
                raise RuntimeError('overlay does not match integrated source: '+rel)
            seen.add(rel)
    if seen!=set(expected):
        raise RuntimeError('overlay missing source files: '+str(sorted(set(expected)-seen)))
    return len(seen)

def verify_compiled_diagnostic(elf_path):
    """Require the real integrated G29 diagnostic in the linked STM32 ELF.

    The diagnostic string was already verified in the successful stage-62
    build. Finding it in a linked ELF is stronger than a source-only marker.
    """
    elf_path=Path(elf_path)
    if not elf_path.is_file() or elf_path.stat().st_size==0:
        return False
    return b'SV04NEXT67 DIAG READONLY' in elf_path.read_bytes()

def run(root,out,build=False):
    root=Path(root).resolve();out=Path(out).resolve()
    if root==out or root in out.parents:raise ValueError('output must not be under OEM source')
    # Integrate without compiling. Audit the resulting actual source files FIRST.
    previous=integrate(root,out,do_build=False)
    audit=verify(root)
    compiled_headers=compile_integrated_headers(root,out)
    if audit.get('verification_passed') is not True:
        raise RuntimeError('Marlin source audit not passed')
    originals=subprocess.run(['git','ls-files','--modified','--others','--exclude-standard'],cwd=root,
                             check=True,text=True,capture_output=True).stdout.splitlines()
    unique=sorted(set(x for x in originals if x))
    if not unique:raise RuntimeError('no integrated source files')
    # Create a reproducible source export of ALL modified and newly added Marlin files,
    # not only git diff (which omits untracked headers).
    overlay=out/'marlin-integrated-overlay.tar.gz'
    manifest=[]
    # Deterministic archive: checked-out timestamps, owners and gzip timestamp
    # must not affect the SHA256 of the exact same integrated source files.
    with overlay.open('wb') as raw:
        with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed:
            with tarfile.open(mode='w',fileobj=compressed,format=tarfile.PAX_FORMAT) as archive:
                for rel in unique:
                    file=root/rel
                    if not file.is_file() or file.is_symlink() or not file.resolve().is_relative_to(root):
                        raise RuntimeError('invalid source file: '+rel)
                    payload=file.read_bytes()
                    info=tarfile.TarInfo(rel)
                    info.size=len(payload)
                    info.mtime=0
                    info.uid=info.gid=0
                    info.uname=info.gname=''
                    info.mode=0o644
                    archive.addfile(info,io.BytesIO(payload))
                    manifest.append({'path':rel,'sha256':sha(file),'bytes':len(payload)})
    (out/'integrated_source_manifest82.json').write_text(json.dumps(manifest,indent=2)+'\n')
    verified_export_count=verify_overlay(overlay,manifest,root)
    # Source-only complete tracked diff. Newly introduced files are in the overlay above.
    patch=subprocess.run(['git','diff','--binary','--'],cwd=root,check=True,text=True,capture_output=True).stdout
    if not patch:raise RuntimeError('missing source diff')
    (out/'marlin-full-tracked-82.patch').write_text(patch)
    result={'stage':82,'oem_commit':previous['oem_commit'],'scope':'POINT_1_MARLIN_ONLY',
            'source_audit_passed':True,'source_count':len(manifest),
            'export_roundtrip_verified':True,'export_roundtrip_file_count':verified_export_count,
            'cxx11_combined_header_compile_passed':True,'cxx11_header_count':compiled_headers,
            'overlay_sha256':sha(overlay),'source_manifest_sha256':sha(out/'integrated_source_manifest82.json'),
            'tracked_patch_sha256':sha(out/'marlin-full-tracked-82.patch'),
            'stm32_build_tested':False,'stm32_build_success':None}
    if build:
        log=out/'stm32-build-82.log'
        bin_dir=root/'.pio/build/STM32F103RET6_creality'
        binary=bin_dir/'firmware.bin'
        elf=bin_dir/'firmware.elf'
        # Never accept a leftover firmware.bin from an older successful build.
        for stale in (binary,elf):
            if stale.exists():
                stale.unlink()
        result['stm32_build_tested']=True
        try:
            with log.open('w',encoding='utf-8') as dest:
                proc=subprocess.run(['pio','run','-e','STM32F103RET6_creality'],cwd=root,
                                    stdout=dest,stderr=subprocess.STDOUT,text=True)
            result['build_exit_code']=proc.returncode
            result['stm32_build_success']=(proc.returncode==0 and binary.is_file() and elf.is_file()
                                          and binary.stat().st_size>0 and elf.stat().st_size>0
                                          and verify_compiled_diagnostic(elf))
            if result['stm32_build_success']:
                result['firmware_sha256']=sha(binary)
                result['firmware_bytes']=binary.stat().st_size
                result['elf_sha256']=sha(elf)
            else:
                result['build_failure']='PlatformIO failed, missing/empty firmware artifacts, or linked ELF lacks SV04 NEXT diagnostic marker'
        except (FileNotFoundError,OSError) as error:
            result['stm32_build_success']=False
            result['build_failure']='Unable to start PlatformIO: '+str(error)
            log.write_text(result['build_failure']+'\n',encoding='utf-8')
        result['stm32_build_log_sha256']=sha(log)
    (out/'integration82.json').write_text(json.dumps(result,indent=2)+'\n')
    if build and not result['stm32_build_success']:
        raise RuntimeError('STM32 build failed: '+str(out/'stm32-build-82.log'))
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--out',required=True)
    p.add_argument('--build',action='store_true');a=p.parse_args()
    print(json.dumps(run(a.root,a.out,a.build),indent=2))
