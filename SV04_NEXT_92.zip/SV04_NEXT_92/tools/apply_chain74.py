#!/usr/bin/env python3
"""Pinned OEM -> 62 -> 65 -> 66 -> 67 -> 68 -> 70 -> 73 -> 74."""
import argparse,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from apply_chain73 import run as run73
from apply74 import apply as apply74
def run(root,report):
 earlier=run73(root,str(Path(report).with_suffix('.73.json')))
 last=apply74(root,ROOT/'src/SV04NextDwinAtomic74.hpp')
 result={'history':earlier,'stage74':last,'flash_approved':False}
 Path(report).write_text(json.dumps(result,indent=2)+'\n')
 return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--report',required=True);a=p.parse_args()
 run(a.root,a.report)
