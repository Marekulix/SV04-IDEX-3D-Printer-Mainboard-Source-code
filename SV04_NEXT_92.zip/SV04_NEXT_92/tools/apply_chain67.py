#!/usr/bin/env python3
"""Pinned OEM source -> 62 -> 65 -> 66 -> 67, never flash."""
import sys,json,argparse
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from apply_chain66 import run as run66
from apply67 import apply as apply67

def run(source,report):
 # A disposable checkout is required. 66 verifies pinned revision and clean status.
 prior=run66(source,Path(report).with_suffix('.chain66.json'))
 latest=apply67(source,ROOT/'src/SV04NextDwinContract67.hpp')
 result={'62_65_66':prior,'67':latest,'flash_approved':False,'releases_enabled':False}
 Path(report).write_text(json.dumps(result,indent=2)+'\n')
 return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--report',required=True);a=p.parse_args()
 run(a.root,a.report);print('SV04NEXT67_CHAIN_OK_NO_FLASH')
