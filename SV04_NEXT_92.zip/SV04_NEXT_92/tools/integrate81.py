#!/usr/bin/env python3
"""Stage 81 end-to-end source integration; actual STM32 build only with --build."""
from pathlib import Path
import argparse,json,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from integrate80 import integrate, sha
from verify81 import verify

def run(root,out,build=False):
    root=Path(root).resolve();out=Path(out).resolve()
    old=integrate(root,out,do_build=build)
    audit=verify(root)
    if build and old.get('stm32_build_success') is not True:
        raise RuntimeError('no confirmed STM32 firmware build')
    report={'stage':81,'integration80':old,'source_audit81':audit,
            'build_confirmed':old.get('stm32_build_success') is True}
    (out/'integration81.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',required=True)
    p.add_argument('--out',required=True);p.add_argument('--build',action='store_true')
    a=p.parse_args();r=run(a.root,a.out,a.build)
    print(json.dumps({'source_audit':r['source_audit81']['verification_passed'],
                      'stm32_build':r['build_confirmed']},indent=2))
