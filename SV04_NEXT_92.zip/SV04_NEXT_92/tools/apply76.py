#!/usr/bin/env python3
"""Stage 75 -> 76: add native Marlin compile-time integration invariants."""
import argparse,hashlib,json
from pathlib import Path
RTS=Path('Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp')
HDR=Path('Marlin/src/feature/SV04NextIntegration76.hpp')
EXIST='#include "../../../feature/SV04NextDwinDelivery75.hpp"\n'
INC='#include "../../../feature/SV04NextIntegration76.hpp"\n'
CALL='sv04next75::update(sv04_dwin70,'

def apply(root,header):
 root=Path(root); p=root/RTS;h=root/HDR;gate=root/'Marlin/src/feature/SV04NextDwinBridge73.hpp'
 if not (root/'platformio.ini').is_file() or not p.is_file() or not gate.is_file() or not (root/'Marlin/src/feature/SV04NextDwinDelivery75.hpp').is_file():
  raise ValueError('stage75 tree required')
 old=p.read_bytes();s=old.decode('utf-8')
 if h.exists() or INC in s or s.count(EXIST)!=1 or s.count(CALL)!=1 or 'MAPPING_CONFIRMED=false' not in gate.read_text():
  raise ValueError('unknown, duplicate or unlocked HMI source; refused')
 if s.count('sv04next73::MAPPING_CONFIRMED')!=1 or s.count('RTS_SndData((int)z,vp); return true;')!=1:
  raise ValueError('unknown stage75 writer; refused')
 b=Path(header).read_bytes()
 if b'SV04 NEXT 76' not in b or b'#error' not in b or b'static_assert(!sv04next73::MAPPING_CONFIRMED' not in b:
  raise ValueError('untrusted guard header')
 new=s.replace(EXIST,EXIST+INC,1)
 try:
  h.parent.mkdir(parents=True,exist_ok=True);h.write_bytes(b);p.write_text(new,encoding='utf-8')
 except BaseException:
  p.write_bytes(old);h.unlink(missing_ok=True);raise
 return {'stage':76,'before_sha256':hashlib.sha256(old).hexdigest(),'after_sha256':hashlib.sha256(new.encode()).hexdigest(),'new_commands':0,'hmi_mapping_confirmed':False,'flash_approved':False}
if __name__=='__main__':
 q=argparse.ArgumentParser();q.add_argument('--root',required=True);q.add_argument('--report',required=True);a=q.parse_args()
 out=apply(a.root,Path(__file__).resolve().parents[1]/'src/SV04NextIntegration76.hpp')
 Path(a.report).write_text(json.dumps(out,indent=2)+'\n');print('SV04NEXT76_INTEGRATION_LOCKED')
