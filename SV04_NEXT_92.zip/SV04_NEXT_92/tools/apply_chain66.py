#!/usr/bin/env python3
"""Pinned Sovol OEM HEAD -> 62 -> 65 -> 66, no hardware flash.
Use only an intentionally disposable clean source checkout.
"""
import sys,argparse,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'base62'));sys.path.insert(0,str(ROOT/'tools'))
from apply62 import BASE,patch as p62
from apply65 import patch as p65
from apply66 import apply as p66

def run(source,report):
 source=Path(source)
 def git(*x):return subprocess.check_output(['git','-C',str(source),*x],text=True).strip()
 if git('rev-parse','HEAD')!=BASE or git('status','--porcelain'):
  raise ValueError('REFUSED: requires clean pinned OEM source')
 r62=p62(source,ROOT/'base62/SV04NextGuard62.h',True)
 r65=p65(source,ROOT/'src/SV04NextSafety65.hpp')
 r66=p66(source,ROOT/'src/SV04NextAudit66.hpp')
 result={'pinned_oem':BASE,'62':r62,'65':r65,'66':r66,'flash_allowed':False,'note':'Diagnostic only. Actuators/touch/EEPROM not enabled.'}
 Path(report).write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
 return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--report',required=True);a=p.parse_args()
 run(a.root,a.report);print('SV04NEXT66_CHAIN_OK_NO_FLASH')
