#!/usr/bin/env python3
"""Pinned clean OEM -> 62 -> 65 -> 66 -> 67 -> 68 -> 70 -> 73."""
import argparse,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from apply_chain70 import run as run70
from apply73 import apply as apply73
def run(root,report):
 earlier=run70(root,str(Path(report).with_suffix('.70.json')))
 last=apply73(root,ROOT/'src/SV04NextDwinBridge73.hpp',ROOT/'src/SV04NextDwinWire72.hpp')
 result={'history':earlier,'stage73':last,'flash_approved':False}
 Path(report).write_text(json.dumps(result,indent=2)+'\n')
 return result
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);ap.add_argument('--report',required=True);a=ap.parse_args()
 run(a.root,a.report)
