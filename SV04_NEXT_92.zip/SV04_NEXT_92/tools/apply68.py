#!/usr/bin/env python3
# Read-only firmware DWIN renderer insertion after stage 67.
# Only identified OEM VP constants; no touch handler.
import argparse,hashlib,json
from pathlib import Path
RTS=Path('Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp')
G29=Path('Marlin/src/gcode/bedlevel/abl/G29.cpp')
HEADER=Path('Marlin/src/feature/SV04NextDwinRenderer68.hpp')
ENTRY='void RTS_AutoBedLevelPage()\n{\n  if(waitway == 3)\n  {'
INCLUDE='#include "../../../feature/SV04NextDwinRenderer68.hpp"\n'
HOOK='''
  // SV04 NEXT 68: render valid 4x4 OEM mesh on the existing DWIN result screen.
  // No touch, motion, heater, EEPROM or success-icon command is dispatched.
  #if ENABLED(AUTO_BED_LEVELING_BILINEAR) && GRID_MAX_POINTS_X == 4 && GRID_MAX_POINTS_Y == 4
    if (leveling_is_valid()) {
      int16_t sv04_mesh68[16];
      if (sv04next68::validate([](uint8_t x,uint8_t y)->float { return z_values[x][y]; },sv04_mesh68)) {
        sv04next68::send(sv04_mesh68, [](uint16_t vp,int16_t z){ rtscheck.RTS_SndData((int)z,vp); });
      }
    }
  #endif
'''
def apply(root,header):
 root=Path(root); f=root/RTS; h=root/HEADER; g=root/G29
 if not (root/'platformio.ini').is_file() or not f.is_file() or not g.is_file() or not (root/'Marlin/src/feature/SV04NextDwinContract67.hpp').is_file():
  raise ValueError('requires installed stage 67 source')
 s=f.read_text(encoding='utf-8'); original=s
 if h.exists() or INCLUDE in s or s.count(ENTRY)!=1 or s.count('#include "LCD_RTS.h"\n')!=1: raise ValueError('unknown OEM source or stage 68 already applied')
 if 'SV04NEXT67 DIAG' not in g.read_text(encoding='utf-8'): raise ValueError('G29 stage 67 missing')
 data=Path(header).read_bytes()
 if b'SV04 NEXT 68' not in data or b'FLASH_APPROVED=false' not in data:raise ValueError('invalid renderer header')
 new=s.replace('#include "LCD_RTS.h"\n','#include "LCD_RTS.h"\n'+INCLUDE,1).replace(ENTRY,ENTRY+HOOK,1)
 if len(new)<=len(s):raise ValueError('unexpected patch result')
 h.parent.mkdir(parents=True,exist_ok=True)
 try:
  h.write_bytes(data);f.write_text(new,encoding='utf-8')
 except BaseException:
  f.write_text(original,encoding='utf-8');h.unlink(missing_ok=True);raise
 return {'stage':68,'source_before':hashlib.sha256(s.encode()).hexdigest(),'source_after':hashlib.sha256(new.encode()).hexdigest(),'oem_dwin_mesh_vps':'0x1100..0x111e','touch_added':False,'flash_approved':False,'hmi_display_verified_on_device':False}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--report',required=True);a=p.parse_args();res=apply(a.root,Path(__file__).resolve().parents[1]/'src/SV04NextDwinRenderer68.hpp');Path(a.report).write_text(json.dumps(res,indent=2)+'\n');print('SV04NEXT68_DWIN_OEM_RENDERER_INSTALLED_NO_FLASH')
