from pathlib import Path
from apply79 import G29,RTS,DEST

def audit(root):
 root=Path(root);fail=[]
 for p in (G29,RTS,DEST):
  if not (root/p).is_file():fail.append('missing '+str(p))
 if fail:return {'pass':False,'failures':fail}
 g=(root/G29).read_text();d=(root/RTS).read_text();h=(root/DEST).read_text()
 for file,label in ((g,'G29'),(d,'LCD_RTS')):
  if file.count('#include "../../../feature/SV04NextUnified79.hpp"')!=1:fail.append(label+' include count')
 if g.count('SV04 NEXT 79: compile-time unified feature contract')!=1:fail.append('G29 contract count')
 if d.count('SV04 NEXT 79: compile-time contract')!=1:fail.append('DWIN contract count')
 if d.count('sv04next78::observe_only(sv04_dwin70, millis());')!=1:fail.append('stage78 gate lost')
 if 'sv04next77::locked_update(sv04_dwin70,' in d:fail.append('latent callback restored')
 for x in ('CAN_HEAT=false','CAN_MOVE=false','CAN_EEPROM_WRITE=false','CAN_DWIN_TOUCH=false','CAN_FLASH=false','r.can_start=false','r.hmi_safe=s.hmi_signature_proven && false'):
  if x not in h:fail.append('missing gate '+x)
 return {'pass':not fail,'failures':fail,'hardware_verified':False,'flash_approved':False}
