#!/usr/bin/env python3
"""Apply SV04 NEXT 65 read-only diagnostics onto *already applied* pinned 62 overlay.

Replaces the 62 diagnostic line only. Rejects unknown or previously modified trees.
"""
import argparse, hashlib, json
from pathlib import Path
G29 = Path('Marlin/src/gcode/bedlevel/abl/G29.cpp')
DEST = Path('Marlin/src/feature/SV04NextSafety65.hpp')
HEADER_ANCHOR = '#include "../../../feature/SV04NextGuard62.h"\n'
OLD = 'SV04NEXT62 DIAG READONLY AUTO60=0 T1=0 EEPROM=0 DWIN_TOUCH=0 FLASH=0'
NEW = 'SV04NEXT65 DIAG READONLY AUTO60=0 T1=0 EEPROM=0 DWIN_TOUCH=0 FLASH=0 FSM=LOCKED'
INCLUDE = '#include "../../../feature/SV04NextSafety65.hpp"\n'

def patch(root, header):
    root=Path(root); src=root/G29
    if not (root/'platformio.ini').is_file() or not src.is_file() or not (root/'Marlin/src/feature/SV04NextGuard62.h').is_file():
        raise ValueError('requires exact existing Marlin+62 overlay')
    old=src.read_text(encoding='utf-8')
    if old.count(OLD)!=1 or old.count(HEADER_ANCHOR)!=1 or INCLUDE in old or (root/DEST).exists():
        raise ValueError('unknown/already updated G29: fail closed')
    data=Path(header).read_bytes()
    if b'SV04 NEXT 65' not in data or b'kCanWriteEeprom=false' not in data:raise ValueError('wrong safety header')
    new=old.replace(HEADER_ANCHOR, HEADER_ANCHOR+INCLUDE,1).replace(OLD,NEW,1)
    # Explicit passive compile-time connection. No controller operation or GCode enqueue.
    needle='  // SV04 NEXT 62 read-only diagnostic. Exact U+Q combination only.\n'
    if old.count(needle)!=1:raise ValueError('missing exact diagnostic anchor')
    new=new.replace(needle,'  static_assert(!sv04next65::kCanHeat && !sv04next65::kCanMove && !sv04next65::kCanWriteEeprom && !sv04next65::kCanTouchStart && !sv04next65::kFlashApproved, "read-only build only");\n'+needle,1)
    (root/DEST).parent.mkdir(parents=True,exist_ok=True)
    (root/DEST).write_bytes(data);src.write_text(new,encoding='utf-8')
    return {'changed':[str(G29),str(DEST)],'g29_sha256':hashlib.sha256(new.encode()).hexdigest(),'flash_approved':False,'hardware_actuation':False}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--report',required=True);p.add_argument('--header',default=str(Path(__file__).resolve().parents[1]/'src/SV04NextSafety65.hpp'));a=p.parse_args()
    r=patch(a.root,a.header);Path(a.report).write_text(json.dumps(r,indent=2)+'\n');print('SV04NEXT65_OFFLINE_READONLY_PATCH_OK')
