#!/usr/bin/env python3
"""Point 1 only: apply all existing changes to a pristine pinned OEM Marlin checkout.

Writes a complete source diff, new-file inventory and SHA manifest. Optional PIO build.
Does not flash hardware. No additional feature or safety model introduced.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE/'tools'))
from apply_chain79 import run as run79
BASE='1867fcba75354a5c65e0631d6972dd19f1bd6cbe'
ENV='STM32F103RET6_creality'

def command(args, cwd=None, output=None):
    if output is None:
        return subprocess.run(args,cwd=cwd,check=True,text=True,capture_output=True).stdout
    with open(output,'w',encoding='utf-8') as log:
        proc=subprocess.run(args,cwd=cwd,text=True,stdout=log,stderr=subprocess.STDOUT)
    if proc.returncode:
        raise RuntimeError(f'command failed ({proc.returncode}); see {output}: {args}')
    return ''

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def integrate(root, out, do_build=False):
    root=Path(root).resolve();out=Path(out).resolve()
    if root==out or root in out.parents:
        raise ValueError('output must be outside the OEM source checkout')
    if not (root/'platformio.ini').is_file():
        raise ValueError('missing Marlin platformio.ini')
    commit=command(['git','rev-parse','HEAD'],cwd=root).strip()
    if commit!=BASE:
        raise ValueError('wrong OEM source revision: '+commit)
    if command(['git','status','--porcelain','--untracked-files=all'],cwd=root).strip():
        raise ValueError('OEM tree not pristine; use a disposable clean checkout')
    out.mkdir(parents=True,exist_ok=True)
    proof=run79(root,str(out/'chain79.json'))
    # Stage79 has no actual native firmware build, just patch integration.
    files=[Path(p) for p in command(['git','ls-files','--modified','--others','--exclude-standard'],cwd=root).splitlines()]
    entries=[]
    for relative in files:
        absolute=(root/relative)
        if not absolute.is_file():raise RuntimeError('modified source disappeared: '+str(relative))
        entries.append({'path':relative.as_posix(),'sha256':sha(absolute),'bytes':absolute.stat().st_size})
    expected={'Marlin/src/gcode/bedlevel/abl/G29.cpp', 'Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp'}
    if not expected.issubset({e['path'] for e in entries}):
        raise RuntimeError('core Marlin source changes not present')
    if not any(e['path'].endswith('SV04NextUnified79.hpp') for e in entries):
        raise RuntimeError('stage79 unified source missing')
    diff=command(['git','diff','--binary','--','Marlin/src/gcode/bedlevel/abl/G29.cpp','Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp'],cwd=root)
    if not diff or 'SV04 NEXT 79' not in diff:
        raise RuntimeError('Marlin integration diff missing')
    (out/'Marlin_source_changes_62_to_79.patch').write_text(diff,encoding='utf-8')
    for e in entries:
        if e['path'] not in expected:
            destination=out/'added_source_files'/e['path']
            destination.parent.mkdir(parents=True,exist_ok=True)
            destination.write_bytes((root/e['path']).read_bytes())
    report={'stage':80,'scope':'POINT_1_MARLIN_SOURCE_INTEGRATION_ONLY','oem_commit':BASE,
            'changed_source_files':entries,'source_file_count':len(entries),'diff_sha256':sha(out/'Marlin_source_changes_62_to_79.patch'),
            'marlin_source_integrated':True,'stm32_build_tested':False,'stm32_build_success':None,
            'production_firmware_verified':False,'chain_report':'chain79.json'}
    if do_build:
        log=out/'stm32-build.log'
        try:
            command(['pio','run','-e',ENV],cwd=root,output=log)
            binary=root/'.pio'/'build'/ENV/'firmware.bin'
            elf=root/'.pio'/'build'/ENV/'firmware.elf'
            if not binary.is_file() or not elf.is_file():
                raise RuntimeError('build returned success without firmware.bin and firmware.elf')
            report.update(stm32_build_tested=True,stm32_build_success=True,firmware_sha256=sha(binary),
                          firmware_bytes=binary.stat().st_size,elf_sha256=sha(elf))
            # Build artifacts are kept on the build runner separately from this integration report.
        except Exception as e:
            report.update(stm32_build_tested=True,stm32_build_success=False,build_failure=str(e))
            (out/'integration80.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
            raise
    (out/'integration80.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--root',required=True,help='clean pinned OEM Marlin Git checkout')
    p.add_argument('--out',required=True,help='outside checkout; source diff and manifest')
    p.add_argument('--build',action='store_true',help='also run real PlatformIO STM32 compile')
    args=p.parse_args()
    result=integrate(args.root,args.out,args.build)
    print(json.dumps({'stage':80,'files':result['source_file_count'],'stm32_success':result['stm32_build_success']},indent=2))
