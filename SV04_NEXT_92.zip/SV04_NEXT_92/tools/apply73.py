#!/usr/bin/env python3
"""Patch existing stage-70 OEM DWIN renderer to use stage-72 wire contract.

Never install a new VP, touch key, G-code or raw UART writer.
Default HMI mapping confirmation is false; runtime writes are suppressed.
"""
from pathlib import Path
import argparse, hashlib, json
RTS=Path('Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp')
HEAD=Path('Marlin/src/feature/SV04NextDwinBridge73.hpp')
WIRE=Path('Marlin/src/feature/SV04NextDwinWire72.hpp')
INCLUDE='#include "../../../feature/SV04NextDwinBridge73.hpp"\n'
MARKER="""      sv04_dwin70.update([](uint8_t x,uint8_t y)->float {return z_values[x][y];},
        [](uint16_t vp,int16_t z){ rtscheck.RTS_SndData((int)z,vp); },millis(),true);"""
NEW="""      // SV04 NEXT 73: original OEM display frame contract; fail closed
      // until the installed HMI asset and 0x110E collision are checked.
      sv04next73::update(sv04_dwin70,
        [](uint8_t x,uint8_t y)->float {return z_values[x][y];},
        [](uint16_t vp,int16_t z){ rtscheck.RTS_SndData((int)z,vp); },
        millis(),true,sv04next73::MAPPING_CONFIRMED);"""
def apply(root, header, wire):
 root=Path(root); f=root/RTS
 if not (root/'platformio.ini').is_file() or not f.is_file() or not (root/'Marlin/src/feature/SV04NextDwinPresenter70.hpp').is_file():raise ValueError('requires installed 70')
 original=f.read_bytes();s=original.decode('utf-8')
 if s.count(MARKER)!=1 or s.count('#include "../../../feature/SV04NextDwinPresenter70.hpp"\n')!=1 or INCLUDE in s or (root/HEAD).exists() or (root/WIRE).exists(): raise ValueError('unknown, duplicate, or not stage70: refuse')
 new=s.replace('#include "../../../feature/SV04NextDwinPresenter70.hpp"\n','#include "../../../feature/SV04NextDwinPresenter70.hpp"\n'+INCLUDE,1).replace(MARKER,NEW,1)
 h=Path(header).read_bytes();w=Path(wire).read_bytes()
 if b'SV04 NEXT 73' not in h or b'MAPPING_CONFIRMED=false' not in h or b'SV04 NEXT 72' not in w:raise ValueError('unrecognized headers')
 try:
  (root/HEAD).write_bytes(h);(root/WIRE).write_bytes(w);f.write_text(new,encoding='utf-8')
 except BaseException:
  f.write_bytes(original);(root/HEAD).unlink(missing_ok=True);(root/WIRE).unlink(missing_ok=True);raise
 return {'stage':73,'original_sha256':hashlib.sha256(original).hexdigest(),'patched_sha256':hashlib.sha256(new.encode()).hexdigest(),'hmi_mapping_verified':False,'dwin_writes_default':0,'new_vps':0,'flash_approved':False}
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);ap.add_argument('--report',required=True);a=ap.parse_args()
 p=Path(__file__).resolve().parents[1];data=apply(a.root,p/'src/SV04NextDwinBridge73.hpp',p/'src/SV04NextDwinWire72.hpp')
 Path(a.report).write_text(json.dumps(data,indent=2)+'\n');print('SV04NEXT73_OEM_DWIN_BRIDGE_INSTALLED_LOCKED')
