#!/usr/bin/env python3
"""Strict stage-73 -> 74 patch, read-only OEM DWIN bridge, fail closed."""
from pathlib import Path
import argparse,hashlib,json
RTS=Path('Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp')
HEAD=Path('Marlin/src/feature/SV04NextDwinAtomic74.hpp')
BRIDGE=Path('Marlin/src/feature/SV04NextDwinBridge73.hpp')
OLD_INC='#include "../../../feature/SV04NextDwinBridge73.hpp"\n'
INC='#include "../../../feature/SV04NextDwinAtomic74.hpp"\n'
OLD='sv04next73::update(sv04_dwin70,'
NEW='sv04next74::update(sv04_dwin70,'
def apply(root,header):
 root=Path(root);f=root/RTS;target=root/HEAD
 if not (root/'platformio.ini').is_file() or not f.is_file() or not (root/BRIDGE).is_file():
  raise ValueError('requires stage73 tree')
 orig=f.read_bytes();s=orig.decode('utf-8')
 if target.exists() or s.count(OLD)!=1 or s.count(OLD_INC)!=1 or INC in s or NEW in s:
  raise ValueError('unknown or duplicate stage73; refuse')
 if 'sv04next73::MAPPING_CONFIRMED' not in s or 'MAPPING_CONFIRMED=false' not in (root/BRIDGE).read_text():
  raise ValueError('runtime HMI gate not confirmed as locked')
 data=Path(header).read_bytes()
 if b'SV04 NEXT 74' not in data or b'CAN_FLASH=false' not in data or b'#error' not in data:
  raise ValueError('invalid diagnostic header')
 edited=s.replace(OLD_INC,OLD_INC+INC,1).replace(OLD,NEW,1)
 try:
  target.parent.mkdir(parents=True,exist_ok=True)
  target.write_bytes(data)
  f.write_text(edited,encoding='utf-8')
 except BaseException:
  f.write_bytes(orig);target.unlink(missing_ok=True);raise
 return {'stage':74,'before':hashlib.sha256(orig).hexdigest(),'after':hashlib.sha256(edited.encode()).hexdigest(),
         'runtime_hmi_mapping_verified':False,'runtime_dwin_sends':0,'touch_added':False,'flash_approved':False}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--report',required=True);a=p.parse_args()
 out=apply(a.root,Path(__file__).resolve().parents[1]/'src/SV04NextDwinAtomic74.hpp')
 Path(a.report).write_text(json.dumps(out,indent=2)+'\n');print('SV04NEXT74_PATCH_OK_READONLY_LOCKED')
