#!/usr/bin/env python3
"""Audit exactly one stage78 call, no latent writer callback in injected block."""
from pathlib import Path
from apply78 import RTS,HEADER

def audit(root):
 root=Path(root); failures=[]
 f=root/RTS;h=root/HEADER
 if not f.is_file() or not h.is_file():return {'pass':False,'failures':['source/header missing']}
 s=f.read_text();b=h.read_text()
 if s.count('sv04next78::observe_only(sv04_dwin70, millis());')!=1:failures.append('stage78 call missing or duplicated')
 if s.count('#include "../../../feature/SV04NextHmiGate78.hpp"')!=1:failures.append('stage78 header missing or duplicated')
 if 'sv04next77::locked_update(sv04_dwin70,' in s:failures.append('old callback-based call remains')
 # The new stage-78 hook is embedded in the ORIGINAL bedlevel result page.
 start=s.find('// SV04 NEXT 70: only during OEM bed-level result transition;')
 if start<0:failures.append('OEM result page hook absent')
 else:
  end=s.find('#endif',start)
  if end<0:failures.append('unterminated result-page hook')
  elif any(x in s[start:end] for x in ('RTS_SndData(', 'sv04next75::update(', 'sv04next73::update(', 'queue.enqueue', 'settings.save(', 'thermalManager.')):
   failures.append('SV04 result-page hook still has hardware output')
 if 'HMI_VERIFIED = false' not in b or 'MESH_TRANSMISSION_ALLOWED = false' not in b:failures.append('HMI gate not hard-disabled')
 if 'RTS_SndData(' in b or 'Writer' in b:failures.append('stage78 gate exposes a writer')
 return {'pass':not failures,'failures':failures,'flash_approved':False,'hmi_mapping_verified':False,'stm32_compiled':False}
