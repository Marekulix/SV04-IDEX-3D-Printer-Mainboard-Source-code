#!/usr/bin/env python3
"""Stage 69 -> 70: bind read-only, throttled OEM 16-point mesh presenter.
Passes through original stage-68 DWIN result-page code. Does not allocate VPs.
"""
from pathlib import Path
import argparse,hashlib,json
RTS=Path('Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp')
OUT=Path('Marlin/src/feature/SV04NextDwinPresenter70.hpp')
INC='#include "../../../feature/SV04NextDwinPresenter70.hpp"\n'
EXIST='#include "../../../feature/SV04NextDwinRenderer68.hpp"\n'
BEFORE="""  // SV04 NEXT 68: render valid 4x4 OEM mesh on the existing DWIN result screen.
  // No touch, motion, heater, EEPROM or success-icon command is dispatched.
  #if ENABLED(AUTO_BED_LEVELING_BILINEAR) && GRID_MAX_POINTS_X == 4 && GRID_MAX_POINTS_Y == 4
    if (leveling_is_valid()) {
      int16_t sv04_mesh68[16];
      if (sv04next68::validate([](uint8_t x,uint8_t y)->float { return z_values[x][y]; },sv04_mesh68)) {
        sv04next68::send(sv04_mesh68, [](uint16_t vp,int16_t z){ rtscheck.RTS_SndData((int)z,vp); });
      }
    }
  #endif
"""
AFTER="""  // SV04 NEXT 70: only during OEM bed-level result transition; bounded, read-only.
  #if ENABLED(AUTO_BED_LEVELING_BILINEAR) && GRID_MAX_POINTS_X == 4 && GRID_MAX_POINTS_Y == 4
    if (leveling_is_valid()) {
      static sv04next70::Presenter sv04_dwin70;
      sv04_dwin70.update([](uint8_t x,uint8_t y)->float {return z_values[x][y];},
        [](uint16_t vp,int16_t z){ rtscheck.RTS_SndData((int)z,vp); },millis(),true);
    }
  #endif
"""
def apply(root,header):
 root=Path(root); f=root/RTS; dest=root/OUT
 if not (root/'platformio.ini').is_file() or not f.is_file() or not (root/'Marlin/src/feature/SV04NextDwinRenderer68.hpp').is_file(): raise ValueError('stage 68 source required')
 old=f.read_bytes(); s=old.decode('utf-8')
 if dest.exists() or s.count(BEFORE)!=1 or s.count(EXIST)!=1 or INC in s:raise ValueError('unknown or duplicate source: refuse')
 b=Path(header).read_bytes()
 if b'SV04 NEXT 70' not in b or b'CAN_FLASH=false' not in b:raise ValueError('unrecognized header')
 new=s.replace(EXIST,EXIST+INC,1).replace(BEFORE,AFTER,1)
 dest.parent.mkdir(parents=True,exist_ok=True)
 try:
  dest.write_bytes(b);f.write_text(new,encoding='utf-8')
 except BaseException:
  f.write_bytes(old);dest.unlink(missing_ok=True);raise
 return {'stage':70,'source_before':hashlib.sha256(old).hexdigest(),'source_after':hashlib.sha256(new.encode()).hexdigest(),'status':'readonly OEM rendering only','new_vps':0,'flash_approved':False}
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--root',required=True);a.add_argument('--report',required=True);v=a.parse_args()
 x=apply(v.root,Path(__file__).resolve().parents[1]/'src/SV04NextDwinPresenter70.hpp')
 Path(v.report).write_text(json.dumps(x,indent=2)+'\n');print('SV04NEXT70 OEM_READONLY_PATCH_OK')
