#!/usr/bin/env python3
"""Pinned OEM -> stage 62..75 -> 76; refuses unverified source."""
import argparse,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from apply_chain75 import run as run75
from apply76 import apply as apply76
from audit_chain76 import audit

def run(root,report):
 prior=run75(root,str(Path(report).with_suffix('.75.json')))
 now=apply76(root,ROOT/'src/SV04NextIntegration76.hpp')
 checks=audit(root)
 if not checks['pass']: raise RuntimeError('stage76 audit failed: '+str(checks['failures']))
 out={'previous':prior,'stage76':now,'audit76':checks,'flash_approved':False}
 Path(report).write_text(json.dumps(out,indent=2)+'\n')
 return out
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--report',required=True);a=p.parse_args()
 run(a.root,a.report)
