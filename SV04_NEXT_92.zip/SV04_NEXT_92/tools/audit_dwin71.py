#!/usr/bin/env python3
"""SV04 NEXT 71: inspect the proposed DWIN artwork and OEM VP map offline.

No DWIN binary, touch resource, or firmware image is produced or flashed.
"""
import argparse
import hashlib
import json
import struct
from pathlib import Path

OEM_VPS = [0x1100 + 2*i for i in range(16)]
KNOWN_COLLISIONS = {0x110E: 'OEM ChangePageKey / touch address space overlap; verification required'}

def bmp_info(path):
    raw = Path(path).read_bytes()
    if len(raw) < 54 or raw[:2] != b'BM':
        raise ValueError('not a BMP')
    size, off = struct.unpack_from('<II', raw, 2)[0], struct.unpack_from('<I', raw, 10)[0]
    dib_size, width, height, planes, bpp, compression = struct.unpack_from('<IiiHHI', raw, 14)
    if dib_size < 40 or size != len(raw) or width != 272 or abs(height) != 480:
        raise ValueError('DWIN artwork must be a complete 272x480 BMP')
    if planes != 1 or bpp != 24 or compression != 0:
        raise ValueError('DWIN artwork must be uncompressed 24-bit BMP')
    expected = ((width * 3 + 3)//4)*4*abs(height)
    if off + expected != len(raw):
        raise ValueError('BMP pixel payload size mismatch')
    return dict(width=width, height=abs(height), depth=bpp, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def audit(package):
    package = Path(package)
    layout = json.loads((package/'resources/SV04_NEXT_69_Layout.json').read_text(encoding='utf-8'))
    if layout['resolution'] != [272, 480] or layout['original_oem_mesh_vps'] != OEM_VPS:
        raise ValueError('resolution or OEM VP address mismatch')
    if layout['touch_enabled'] or layout['autostart_enabled'] or layout['eeprom_enabled'] or layout['flash_approved']:
        raise ValueError('unsafe DWIN release flag')
    bmp = bmp_info(package/'resources/SV04_NEXT_69_DWIN_SCREEN.bmp')
    return dict(stage=71, artifact='SV04_NEXT_69_DWIN_SCREEN.bmp', bmp=bmp,
                oem_16_vps=[hex(v) for v in OEM_VPS], collisions={hex(k):v for k,v in KNOWN_COLLISIONS.items()},
                visual_artwork_ready=True, hmi_project_verified=False, dwin_bin_generated=False,
                hardware_touch_test=False, flash_approved=False,
                required_next_evidence=['Installed display DWprj.hmi or compatible original resources',
                                        'Verified picture index and matching DWIN compilation',
                                        'Real on-device OEM VP/touch collision validation'])

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--package', type=Path, default=Path(__file__).resolve().parents[1])
    p.add_argument('--out', type=Path)
    a=p.parse_args()
    result=audit(a.package)
    text=json.dumps(result,indent=2,ensure_ascii=False)+'\n'
    if a.out:a.out.write_text(text,encoding='utf-8')
    print(text)

if __name__=='__main__': main()
