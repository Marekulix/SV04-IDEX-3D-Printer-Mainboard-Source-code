#!/usr/bin/env python3
"""Fail-closed, atomic-ish 65->66 diagnostic patch. No actuator path touched.
Known source shape only, with backup+rollback on errors.
"""
from pathlib import Path
import argparse,hashlib,json,os,tempfile
G29=Path('Marlin/src/gcode/bedlevel/abl/G29.cpp')
DEST=Path('Marlin/src/feature/SV04NextAudit66.hpp')
ANCHOR='#include "../../../feature/SV04NextSafety65.hpp"\n'
BEFORE='SV04NEXT65 DIAG READONLY AUTO60=0 T1=0 EEPROM=0 DWIN_TOUCH=0 FLASH=0 FSM=LOCKED'
AFTER='SV04NEXT66 DIAG READONLY AUTO60=0 T1=0 EEPROM=0 DWIN_TOUCH=0 FLASH=0 SENSOR=NOT_READ HARDWARE_RELEASE=0'
INCLUDE='#include "../../../feature/SV04NextAudit66.hpp"\n'
ASSERT='  static_assert(!sv04next66::kAuto60Enabled && !sv04next66::kPhysicalT1Validated && !sv04next66::kTouchStartEnabled && !sv04next66::kEepromWriteEnabled && !sv04next66::kFlashApproved, "SV04 NEXT 66 NO RELEASE");\n'
MARK='  // SV04 NEXT 62 read-only diagnostic. Exact U+Q combination only.\n'
def apply(root,header):
 root=Path(root); src=root/G29; dest=root/DEST
 if not (root/'platformio.ini').is_file() or not src.is_file() or not (root/'Marlin/src/feature/SV04NextSafety65.hpp').is_file():
  raise ValueError('refused: requires Marlin with installed 65 diagnostic')
 if dest.exists():raise ValueError('refused: already applied')
 data=Path(header).read_bytes()
 if b'SV04 NEXT 66' not in data or b'kFlashApproved=false' not in data or b'kEepromWriteEnabled=false' not in data:
  raise ValueError('refused: unexpected header')
 original=src.read_bytes(); old=original.decode('utf-8')
 if any(old.count(s)!=1 for s in (ANCHOR,BEFORE,MARK)) or INCLUDE in old:
  raise ValueError('refused: unknown G29 source / anchors')
 new=old.replace(ANCHOR,ANCHOR+INCLUDE,1).replace(BEFORE,AFTER,1).replace(MARK,ASSERT+MARK,1).encode('utf-8')
 # All inputs validated prior to modifications. Keep old file available for rollback.
 dest.parent.mkdir(parents=True,exist_ok=True)
 try:
  dest.write_bytes(data)
  src.write_bytes(new)
 except Exception:
  src.write_bytes(original)
  dest.unlink(missing_ok=True)
  raise
 return {'g29_sha256_before':hashlib.sha256(original).hexdigest(),'g29_sha256_after':hashlib.sha256(new).hexdigest(),'updated':[str(G29),str(DEST)],'readonly':True,'flash_approved':False}
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);ap.add_argument('--report',required=True);ap.add_argument('--header',default=str(Path(__file__).resolve().parents[1]/'src/SV04NextAudit66.hpp'));a=ap.parse_args()
 r=apply(a.root,a.header);Path(a.report).write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');print('SV04NEXT66_DIAGNOSTIC_ONLY_OK')
