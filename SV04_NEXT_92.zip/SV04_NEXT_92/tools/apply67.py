#!/usr/bin/env python3
"""Apply stage 67 strictly to previously installed stage 66, diagnostic-only."""
import argparse,hashlib,json
from pathlib import Path
G29=Path('Marlin/src/gcode/bedlevel/abl/G29.cpp')
DEST=Path('Marlin/src/feature/SV04NextDwinContract67.hpp')
HEADER='#include "../../../feature/SV04NextAudit66.hpp"\n'
OLD='SV04NEXT66 DIAG READONLY AUTO60=0 T1=0 EEPROM=0 DWIN_TOUCH=0 FLASH=0 SENSOR=NOT_READ HARDWARE_RELEASE=0'
NEW='SV04NEXT67 DIAG READONLY AUTO60=0 T1=0 EEPROM=0 DWIN_TOUCH=0 FLASH=0 VP=UNVERIFIED SENSOR=NOT_READ HARDWARE_RELEASE=0'
INSERT='#include "../../../feature/SV04NextDwinContract67.hpp"\n'
ASSERT='  static_assert(!sv04next67::kTouchEnabled && !sv04next67::kAuto60Enabled && !sv04next67::kT1MovementEnabled && !sv04next67::kEepromEnabled && !sv04next67::kFlashApproved, "SV04 NEXT 67 NO RELEASE");\n'
ANCHOR='  // SV04 NEXT 62 read-only diagnostic. Exact U+Q combination only.\n'
def apply(root,header):
 root=Path(root); f=root/G29; out=root/DEST
 if not (root/'platformio.ini').is_file() or not f.is_file() or not (root/'Marlin/src/feature/SV04NextAudit66.hpp').is_file():
  raise ValueError('requires installed stage 66 Marlin tree')
 original=f.read_bytes();s=original.decode('utf-8')
 if out.exists() or any(s.count(x)!=1 for x in (HEADER,OLD,ANCHOR)) or INSERT in s:
  raise ValueError('unknown or repeated stage 67, fail closed')
 data=Path(header).read_bytes()
 if b'SV04 NEXT 67' not in data or b'kFlashApproved=false' not in data:
  raise ValueError('unrecognized stage 67 header')
 modified=s.replace(HEADER,HEADER+INSERT,1).replace(OLD,NEW,1).replace(ANCHOR,ASSERT+ANCHOR,1).encode('utf-8')
 out.parent.mkdir(parents=True,exist_ok=True)
 try:
  out.write_bytes(data);f.write_bytes(modified)
 except BaseException:
  f.write_bytes(original);out.unlink(missing_ok=True);raise
 return {'stage':67,'g29_before':hashlib.sha256(original).hexdigest(),'g29_after':hashlib.sha256(modified).hexdigest(),'readonly':True,'flash_allowed':False,'dwin_vps_verified':False}
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--root',required=True);a.add_argument('--report',required=True);a.add_argument('--header',default=str(Path(__file__).resolve().parents[1]/'src/SV04NextDwinContract67.hpp'));v=a.parse_args()
 r=apply(v.root,v.header);Path(v.report).write_text(json.dumps(r,indent=2)+'\n');print('SV04NEXT67_PATCH_OK_READONLY')
