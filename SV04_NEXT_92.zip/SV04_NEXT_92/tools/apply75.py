#!/usr/bin/env python3
"""Stage 74 -> 75, preserve physical HMI lock, idempotence rejected."""
from pathlib import Path
import argparse,hashlib,json
RTS=Path('Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp')
HEAD=Path('Marlin/src/feature/SV04NextDwinDelivery75.hpp')
OLD_INC='#include "../../../feature/SV04NextDwinAtomic74.hpp"\n'
INC='#include "../../../feature/SV04NextDwinDelivery75.hpp"\n'
OLD='sv04next74::update(sv04_dwin70,'
NEW='sv04next75::update(sv04_dwin70,'
# RTS_SndData returns void. Return true only to report call completion;
# there is no DGUS device ACK, and mapping remains statically false.
OLD_SEND='[](uint16_t vp,int16_t z){ rtscheck.RTS_SndData((int)z,vp); },'
NEW_SEND='[](uint16_t vp,int16_t z)->bool { rtscheck.RTS_SndData((int)z,vp); return true; },'
def apply(root,header):
 root=Path(root);f=root/RTS;target=root/HEAD
 if not (root/'platformio.ini').is_file() or not f.is_file() or not (root/'Marlin/src/feature/SV04NextDwinAtomic74.hpp').is_file():
  raise ValueError('requires stage74 tree')
 orig=f.read_bytes();s=orig.decode('utf-8')
 if target.exists() or s.count(OLD)!=1 or s.count(OLD_SEND)!=1 or s.count(OLD_INC)!=1 or INC in s or NEW in s:
  raise ValueError('unknown or duplicate stage74 source')
 gate=root/'Marlin/src/feature/SV04NextDwinBridge73.hpp'
 if 'MAPPING_CONFIRMED=false' not in gate.read_text() or 'sv04next73::MAPPING_CONFIRMED' not in s:
  raise ValueError('HMI lock missing, reject')
 data=Path(header).read_bytes()
 if b'SV04 NEXT 75' not in data or b'#error' not in data or b'CAN_FLASH=false' not in data:
  raise ValueError('invalid stage75 header')
 edited=s.replace(OLD_INC,OLD_INC+INC,1).replace(OLD,NEW,1).replace(OLD_SEND,NEW_SEND,1)
 try:
  target.parent.mkdir(parents=True,exist_ok=True)
  target.write_bytes(data);f.write_text(edited,encoding='utf-8')
 except BaseException:
  f.write_bytes(orig);target.unlink(missing_ok=True);raise
 return {'stage':75,'before':hashlib.sha256(orig).hexdigest(),'after':hashlib.sha256(edited.encode()).hexdigest(),'installed_hmi_mapping_confirmed':False,'physical_dwin_ack':False,'firmware_writes_enabled':False,'flash_approved':False}
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);ap.add_argument('--report',required=True);a=ap.parse_args()
 r=apply(a.root,Path(__file__).resolve().parents[1]/'src/SV04NextDwinDelivery75.hpp')
 Path(a.report).write_text(json.dumps(r,indent=2)+'\n');print('SV04NEXT75_PATCH_LOCKED')
