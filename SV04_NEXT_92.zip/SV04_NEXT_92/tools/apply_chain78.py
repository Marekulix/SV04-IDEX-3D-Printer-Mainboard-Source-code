#!/usr/bin/env python3
"""Strict source chain pinned OEM -> 62 -> ... -> 77 -> 78."""
import argparse,json
from pathlib import Path
from apply_chain77 import run as run77
from apply78 import apply
from audit78 import audit
ROOT=Path(__file__).resolve().parents[1]
def run(root,report):
 earlier=run77(root,str(Path(report).with_suffix('.77.json')))
 patch=apply(root,ROOT/'src/SV04NextHmiGate78.hpp')
 checks=audit(root)
 if not checks['pass']:raise RuntimeError('stage78 audit failed: '+str(checks['failures']))
 data={'history':earlier,'stage78':patch,'audit78':checks,'flash_approved':False}
 Path(report).write_text(json.dumps(data,indent=2)+'\n')
 return data
if __name__=='__main__':
 q=argparse.ArgumentParser();q.add_argument('--root',required=True);q.add_argument('--report',required=True);a=q.parse_args()
 run(a.root,a.report)
