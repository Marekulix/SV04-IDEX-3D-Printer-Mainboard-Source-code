#!/usr/bin/env python3
"""Produce a reproducible 272x480 DWIN background image. No HMI compilation."""
import argparse
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
WIDTH, HEIGHT = 272,480
BG=(12,21,36); CARD=(24,39,58); GREEN=(65,206,153); MUTE=(162,183,199)
def render(path):
    canvas=Image.new('RGB',(WIDTH,HEIGHT),BG);d=ImageDraw.Draw(canvas)
    d.rounded_rectangle((10,11,261,85),radius=12,fill=(21,40,62))
    d.text((22,22),'SV04 NEXT',fill=GREEN)
    d.text((22,44),'BETTVERMESSUNG',fill=(242,248,250))
    d.text((22,63),'60 C | DIAGNOSE',fill=MUTE)
    d.rounded_rectangle((10,97,261,157),radius=9,fill=CARD)
    d.text((22,108),'Status: NICHT FREIGEGEBEN',fill=(255,188,114))
    d.text((22,131),'Messwerte nur nach G29',fill=MUTE)
    d.text((20,163),'4 x 4 MESSPUNKTE',fill=(236,245,250))
    for r in range(4):
        for c in range(4):
            x=20+c*59;y=192+r*49
            d.rounded_rectangle((x,y,x+52,y+42),radius=7,fill=CARD,outline=(70,99,126),width=1)
            d.text((x+7,y+6),f'{r*4+c+1:02d}',fill=MUTE)
            d.text((x+8,y+24),'--.--',fill=(232,238,241))
    d.rounded_rectangle((10,401,261,464),radius=9,fill=(25,40,54))
    d.text((20,410),'NUR ANZEIGE',fill=GREEN)
    d.text((20,429),'KEIN START / KEIN EEPROM',fill=(230,236,243))
    d.text((20,447),'Firmware & HMI pruefen',fill=MUTE)
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    canvas.save(path.with_suffix('.png'))
    canvas.save(path.with_suffix('.bmp'))
    return path.with_suffix('.png'),path.with_suffix('.bmp')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',default='resources/SV04_NEXT_69_DWIN_SCREEN.png');a=p.parse_args();print(render(a.output))
