#!/usr/bin/env python3
"""Strict 77 -> 78 patch: REMOVE latent UART sender from SV04 firmware call site.
This does not modify OEM DWIN routines, which remain vendor-owned.
"""
import argparse,hashlib,json
from pathlib import Path
RTS=Path('Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp')
HEADER=Path('Marlin/src/feature/SV04NextHmiGate78.hpp')
FIREWALL=Path('Marlin/src/feature/SV04NextHmiFirewall77.hpp')
INC_77='#include "../../../feature/SV04NextHmiFirewall77.hpp"\n'
INC_78='#include "../../../feature/SV04NextHmiGate78.hpp"\n'
OLD="""sv04next77::locked_update(sv04_dwin70,
        [](uint8_t x,uint8_t y)->float {return z_values[x][y];},
        [](uint16_t vp,int16_t z)->bool { rtscheck.RTS_SndData((int)z,vp); return true; },
        millis(),true);"""
NEW='sv04next78::observe_only(sv04_dwin70, millis());'
def apply(root,header):
 root=Path(root);f=root/RTS; dest=root/HEADER
 gate=root/'Marlin/src/feature/SV04NextDwinBridge73.hpp'
 if not (root/'platformio.ini').is_file() or not f.is_file() or not (root/FIREWALL).is_file() or not gate.is_file():
  raise ValueError('verified stage77 required')
 raw=f.read_bytes();s=raw.decode('utf-8')
 if dest.exists() or s.count(INC_77)!=1 or INC_78 in s or s.count(OLD)!=1 or s.count('sv04next77::locked_update(')!=1:
  raise ValueError('unknown/duplicate stage77 integration: refused')
 if 'MAPPING_CONFIRMED=false' not in gate.read_text() or 'CAN_TRANSMIT_MESH = false' not in (root/FIREWALL).read_text():
  raise ValueError('HMI gate unverified or unlocked')
 content=Path(header).read_bytes()
 for marker in (b'SV04 NEXT 78',b'#error',b'HMI_VERIFIED = false',b'MESH_TRANSMISSION_ALLOWED = false',b'observe_only'):
  if marker not in content:raise ValueError('untrusted gate header')
 new=s.replace(INC_77,INC_77+INC_78,1).replace(OLD,NEW,1)
 try:
  dest.write_bytes(content);f.write_text(new,encoding='utf-8')
 except BaseException:
  f.write_bytes(raw);dest.unlink(missing_ok=True);raise
 return {'stage':78,'before_sha256':hashlib.sha256(raw).hexdigest(),'after_sha256':hashlib.sha256(new.encode()).hexdigest(),'physical_dwin_write_callback_in_new_firmware_path':False,'hmi_verified':False,'flash_approved':False}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--report',required=True);a=p.parse_args()
 r=apply(a.root,Path(__file__).resolve().parents[1]/'src/SV04NextHmiGate78.hpp');Path(a.report).write_text(json.dumps(r,indent=2)+'\n')
