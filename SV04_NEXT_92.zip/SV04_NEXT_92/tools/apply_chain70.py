#!/usr/bin/env python3
"""Pinned clean source -> 62 -> 65 -> 66 -> 67 -> 68 -> 70."""
import argparse,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from apply_chain68 import run as run68
from apply70 import apply as apply70
def run(root,report):
 result68=run68(root,str(Path(report).with_suffix('.68.json')))
 result70=apply70(root,ROOT/'src/SV04NextDwinPresenter70.hpp')
 result={'history':result68,'stage70':result70,'flash_approved':False}
 Path(report).write_text(json.dumps(result,indent=2)+'\n')
 return result
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);ap.add_argument('--report',required=True);a=ap.parse_args()
 run(a.root,a.report)
