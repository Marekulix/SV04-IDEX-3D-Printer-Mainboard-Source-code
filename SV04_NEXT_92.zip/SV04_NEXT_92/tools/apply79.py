#!/usr/bin/env python3
"""Stage 78 -> 79 read-only diagnostic integration into Marlin G29 and OEM DWIN.
No new touch, actuator, EEPROM or screen resource writes.
"""
from pathlib import Path
import hashlib,json,argparse
G29=Path('Marlin/src/gcode/bedlevel/abl/G29.cpp')
RTS=Path('Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp')
DEST=Path('Marlin/src/feature/SV04NextUnified79.hpp')
INCLUDE='#include "../../../feature/SV04NextUnified79.hpp"\n'
DIAG_ANCHOR='  // SV04 NEXT 62 read-only diagnostic. Exact U+Q combination only.\n'
RTS_ANCHOR='#include "../../../feature/SV04NextHmiGate78.hpp"\n'
RTS_EXTRA="""  // SV04 NEXT 79: compile-time contract for unified DWIN / Auto60 / T1 / EEPROM.
  // No new RTS_SndData, no touch key handler, and no movement/EEPROM commands.
  static_assert(!sv04next79::CAN_DWIN_TOUCH && !sv04next79::CAN_HEAT && !sv04next79::CAN_MOVE && !sv04next79::CAN_EEPROM_WRITE, "read-only");
"""
DIAG_EXTRA="""  // SV04 NEXT 79: compile-time unified feature contract, no actuator invocation.
  static_assert(!sv04next79::CAN_HEAT && !sv04next79::CAN_MOVE && !sv04next79::CAN_DWIN_TOUCH && !sv04next79::CAN_EEPROM_WRITE && !sv04next79::CAN_FLASH, "diagnostic-only");
"""
def apply(root,header):
 root=Path(root); g=root/G29;d=root/RTS;h=root/DEST
 if not (root/'platformio.ini').is_file() or not g.is_file() or not d.is_file() or h.exists():raise ValueError('requires stage 78 source')
 gs=g.read_text();ds=d.read_text()
 if not (root/'Marlin/src/feature/SV04NextHmiGate78.hpp').is_file():raise ValueError('stage78 missing')
 if any((gs.count(DIAG_ANCHOR)!=1,ds.count(RTS_ANCHOR)!=1,gs.count('#include "../../../feature/SV04NextSafety65.hpp"\n')!=1,ds.count('sv04next78::observe_only(sv04_dwin70, millis());')!=1, INCLUDE in gs or INCLUDE in ds)):
  raise ValueError('unknown/duplicate stage78 source')
 content=Path(header).read_bytes()
 if any(m not in content for m in (b'SV04 NEXT 79',b'#error',b'CAN_HEAT=false',b'CAN_EEPROM_WRITE=false',b'can_start=false',b'hmi_signature_proven && false')):
  raise ValueError('stage79 header unsafe')
 ng=gs.replace(DIAG_ANCHOR,DIAG_EXTRA+DIAG_ANCHOR,1).replace('#include "../../../feature/SV04NextSafety65.hpp"\n','#include "../../../feature/SV04NextSafety65.hpp"\n'+INCLUDE,1)
 nd=ds.replace(RTS_ANCHOR,RTS_ANCHOR+INCLUDE,1).replace('sv04next78::observe_only(sv04_dwin70, millis());',RTS_EXTRA+'  sv04next78::observe_only(sv04_dwin70, millis());',1)
 if ng==gs or nd==ds:raise ValueError('patch anchors missing')
 h.parent.mkdir(parents=True,exist_ok=True)
 try:h.write_bytes(content);g.write_text(ng);d.write_text(nd)
 except BaseException:
  g.write_text(gs);d.write_text(ds);h.unlink(missing_ok=True);raise
 return {'stage':79,'G29_sha256':hashlib.sha256(ng.encode()).hexdigest(),'LCD_RTS_sha256':hashlib.sha256(nd.encode()).hexdigest(),'heater_motion_eeprom_touch_enabled':False,'flash_approved':False}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--report',required=True);a=p.parse_args();r=apply(a.root,Path(__file__).resolve().parents[1]/'src/SV04NextUnified79.hpp');Path(a.report).write_text(json.dumps(r,indent=2)+'\n')
