#!/usr/bin/env python3
"""Strict 76 -> 77 patch, routes real firmware through unconditionally locked API."""
import argparse,hashlib,json
from pathlib import Path
RTS=Path('Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp')
HEADER=Path('Marlin/src/feature/SV04NextHmiFirewall77.hpp')
BRIDGE=Path('Marlin/src/feature/SV04NextDwinBridge73.hpp')
OLD_INCLUDE='#include "../../../feature/SV04NextIntegration76.hpp"\n'
NEW_INCLUDE='#include "../../../feature/SV04NextHmiFirewall77.hpp"\n'
OLD_CALL='sv04next75::update(sv04_dwin70,'
NEW_CALL='sv04next77::locked_update(sv04_dwin70,'
OLD_END='millis(),true,sv04next73::MAPPING_CONFIRMED);'
NEW_END='millis(),true);'
def apply(root,source):
 root=Path(root); f=root/RTS; h=root/HEADER; gate=root/BRIDGE
 if not (root/'platformio.ini').is_file() or not f.is_file() or not gate.is_file() or not (root/'Marlin/src/feature/SV04NextIntegration76.hpp').is_file():
  raise ValueError('requires stage76 Marlin source')
 raw=f.read_bytes();s=raw.decode('utf-8')
 if h.exists() or s.count(OLD_INCLUDE)!=1 or s.count(OLD_CALL)!=1 or s.count(OLD_END)!=1 or s.count('sv04next73::MAPPING_CONFIRMED')!=1 or NEW_CALL in s:
  raise ValueError('unrecognized or duplicate stage76 source')
 if 'MAPPING_CONFIRMED=false' not in gate.read_text() or 'MAPPING_CONFIRMED=true' in gate.read_text():
  raise ValueError('existing HMI lock removed')
 content=Path(source).read_bytes()
 for marker in (b'SV04 NEXT 77',b'#error',b'HMI_AUTHENTICATED = false',b'CAN_TRANSMIT_MESH = false',b'locked_update'):
  if marker not in content:raise ValueError('unsafe stage77 header')
 changed=s.replace(OLD_INCLUDE,OLD_INCLUDE+NEW_INCLUDE,1).replace(OLD_CALL,NEW_CALL,1).replace(OLD_END,NEW_END,1)
 try:
  h.write_bytes(content);f.write_text(changed)
 except BaseException:
  f.write_bytes(raw);h.unlink(missing_ok=True);raise
 return {'stage':77,'old_sha256':hashlib.sha256(raw).hexdigest(),'new_sha256':hashlib.sha256(changed.encode()).hexdigest(),'firmware_dwin_transmission_allowed':False,'touch_enabled':False,'flash_approved':False}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--report',required=True);a=p.parse_args()
 from pathlib import Path
 out=apply(a.root,Path(__file__).resolve().parents[1]/'src/SV04NextHmiFirewall77.hpp')
 Path(a.report).write_text(json.dumps(out,indent=2)+'\n')
