#!/usr/bin/env python3
"""Pinned OEM -> stages 62..76 -> 77; hardware outputs remain locked."""
import argparse,json
from pathlib import Path
from apply_chain76 import run as run76
from apply77 import apply
from audit77 import audit
ROOT=Path(__file__).resolve().parents[1]
def run(root,report):
 previous=run76(root,str(Path(report).with_suffix('.76.json')))
 patch=apply(root,ROOT/'src/SV04NextHmiFirewall77.hpp')
 result=audit(root)
 if not result['pass']:raise RuntimeError(str(result['failures']))
 out={'previous':previous,'stage77':patch,'audit77':result,'flash_approved':False}
 Path(report).write_text(json.dumps(out,indent=2)+'\n')
 return out
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--report',required=True);a=p.parse_args();run(a.root,a.report)
