#!/usr/bin/env python3
"""Exact OEM HEAD -> 62 diagnostic -> 65 passive safety reference.
Runs against a clean *temporary* clone or intentionally disposable working tree only.
Never flashes or generates auto60 movement code.
"""
import argparse,subprocess,sys,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'base62'))
from apply62 import BASE,patch as patch62
from apply65 import patch as patch65

def main():
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--report',required=True);a=p.parse_args()
 src=Path(a.root).resolve()
 git=lambda *args: subprocess.check_output(['git','-C',str(src),*args],text=True).strip()
 if git('rev-parse','HEAD') != BASE:raise SystemExit('REFUSED: HEAD is not pinned original Sovol source')
 if git('status','--porcelain'):raise SystemExit('REFUSED: source tree is not clean')
 if not (src/'Marlin/src/gcode/bedlevel/abl/G29.cpp').is_file():raise SystemExit('REFUSED: missing original G29')
 base=patch62(src,ROOT/'base62/SV04NextGuard62.h',True)
 extended=patch65(src,ROOT/'src/SV04NextSafety65.hpp')
 out={'oem_commit':BASE,'base62':base,'step65':extended,'flash_release':False,'notes':'Read-only diagnostic; no heater, motion, touchscreen trigger, or EEPROM changes'}
 Path(a.report).write_text(json.dumps(out,indent=2)+'\n')
 print('SV04NEXT65_CHAIN_OK READONLY=YES FLASH_APPROVED=NO')
if __name__=='__main__':main()
