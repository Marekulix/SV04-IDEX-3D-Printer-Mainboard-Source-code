#!/usr/bin/env python3
"""Pinned clean OEM -> all patches -> stage 79, no flashing."""
from pathlib import Path
import argparse,json
from apply_chain78 import run as run78
from apply79 import apply
from audit79 import audit
ROOT=Path(__file__).resolve().parents[1]
def run(root,report):
 r78=run78(root,str(Path(report).with_suffix('.78.json')))
 r79=apply(root,ROOT/'src/SV04NextUnified79.hpp')
 proof=audit(root)
 if not proof['pass']:raise RuntimeError('stage 79 failed: '+str(proof['failures']))
 result={'history':r78,'stage79':r79,'audit79':proof,'flash_approved':False}
 Path(report).write_text(json.dumps(result,indent=2)+'\n');return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--report',required=True);a=p.parse_args();run(a.root,a.report)
