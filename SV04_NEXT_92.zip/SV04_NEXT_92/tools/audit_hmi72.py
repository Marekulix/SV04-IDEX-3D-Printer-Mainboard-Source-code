#!/usr/bin/env python3
"""Strict evidence inventory, not a DGUS compiler or compatibility proof."""
from pathlib import Path
import argparse, hashlib, json
ALLOWED_SUFFIX={'.hmi','.dhmi','.icl','.bin','.cfg','.bmp'}

def audit(path):
    path=Path(path)
    if not path.exists() or not path.is_dir(): raise ValueError('existing project directory required')
    entries=[]
    for f in sorted(path.rglob('*')):
        if not f.is_file() or f.suffix.lower() not in ALLOWED_SUFFIX: continue
        data=f.read_bytes()
        entries.append(dict(name=str(f.relative_to(path)),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
    hmi=[e for e in entries if Path(e['name']).name.lower()=='dwprj.hmi']
    return {'stage':72,'files':entries,'has_hmi_source':bool(hmi),
            'stock_sovol_hmi_compatibility_verified':False,
            'picture_index_verified':False,'touch_collision_0x110e_resolved':False,
            'hmi_binary_generated':False,'flash_approved':False,
            'reason':'File presence alone does not prove the installed DWIN configuration or VP mapping'}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('directory',type=Path);p.add_argument('--out',type=Path)
    a=p.parse_args();result=audit(a.directory)
    payload=json.dumps(result,ensure_ascii=False,indent=2)+'\n'
    if a.out:a.out.write_text(payload,encoding='utf-8')
    print(payload)
