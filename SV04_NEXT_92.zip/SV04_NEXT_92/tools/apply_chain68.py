#!/usr/bin/env python3
import argparse,sys,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from apply_chain67 import run as run67
from apply68 import apply as apply68
def run(root,report):
 root=Path(root);r67=run67(root,str(Path(report).with_suffix('.67.json')))
 r68=apply68(root,ROOT/'src/SV04NextDwinRenderer68.hpp')
 result={'chain67':r67,'68':r68,'flash_allowed':False}
 Path(report).write_text(json.dumps(result,indent=2)+'\n');return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--report',required=True);a=p.parse_args()
 run(a.root,a.report)
