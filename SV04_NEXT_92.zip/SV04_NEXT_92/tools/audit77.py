#!/usr/bin/env python3
"""Audit full stage77 patched tree; detect accidental call through test-only sender."""
from pathlib import Path
from audit_chain76 import audit as audit76
from apply77 import RTS,HEADER,BRIDGE

def audit(root):
 root=Path(root); failures=[]
 # Stage76 invariants still apply except its expectation of a stage75 direct call.
 original=root/RTS
 if not original.is_file():return {'pass':False,'failures':['DWIN source missing']}
 s=original.read_text()
 if s.count('sv04next77::locked_update(sv04_dwin70,')!=1:failures.append('locked call missing or duplicated')
 if 'sv04next75::update(sv04_dwin70,' in s:failures.append('test adapter still called by firmware')
 if s.count('#include "../../../feature/SV04NextHmiFirewall77.hpp"')!=1:failures.append('firewall header missing or duplicated')
 if 'millis(),true,sv04next73::MAPPING_CONFIRMED);' in s:failures.append('runtime test gate still exposed')
 h=root/HEADER
 if not h.is_file():failures.append('firewall missing')
 else:
  body=h.read_text()
  if 'CAN_TRANSMIT_MESH = false' not in body or 'HMI_AUTHENTICATED = false' not in body:failures.append('firewall unlocked')
  if 'writer(' in body or 'RTS_SndData(' in body:failures.append('unexpected output in firewall')
 g=root/BRIDGE
 if not g.is_file() or 'MAPPING_CONFIRMED=false' not in g.read_text():failures.append('old HMI gate missing')
 return {'pass':not failures,'failures':failures,'hmi_authenticated':False,'mesh_writes_allowed':False,'flash_approved':False}
