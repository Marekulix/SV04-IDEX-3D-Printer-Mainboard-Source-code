#!/usr/bin/env python3
"""Apply a fail-closed, diagnostic-only Marlin source overlay to a PINNED OEM tree.

Never touches motor/heater/EEPROM code paths, and never modifies an unknown source tree.
"""
from pathlib import Path
import argparse, hashlib, json, subprocess
BASE='1867fcba75354a5c65e0631d6972dd19f1bd6cbe'
G29='Marlin/src/gcode/bedlevel/abl/G29.cpp'
RTS='Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp'
DEST='Marlin/src/feature/SV04NextGuard62.h'
G29_START='G29_TYPE GcodeSuite::G29() {\n'
G29_ADD='''  // SV04 NEXT 62 read-only diagnostic. Exact U+Q combination only.
  if (parser.seen_test('U') && parser.seen_test('Q')) {
    SERIAL_ECHOLNPGM("SV04NEXT62 DIAG READONLY AUTO60=0 T1=0 EEPROM=0 DWIN_TOUCH=0 FLASH=0");
    G29_RETURN(false);
  }
'''
INC='#include "../../../feature/SV04NextGuard62.h"\n'

def patch(root, header, enforce_commit=True):
    root=Path(root)
    if enforce_commit:
        commit=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()
        if commit!=BASE: raise ValueError('refuse overlay: OEM commit differs from pinned '+BASE)
    if not (root/'platformio.ini').is_file(): raise ValueError('not a Marlin source tree')
    gpath=root/G29; rpath=root/RTS
    oldg=gpath.read_text(encoding='utf-8'); oldr=rpath.read_text(encoding='utf-8')
    if oldg.count(G29_START)!=1: raise ValueError('unexpected G29 signature')
    if oldr.count('#include "LCD_RTS.h"\n')!=1: raise ValueError('unexpected DWIN source anchor')
    if 'SV04NextGuard62' in oldg or 'SV04NextGuard62' in oldr: raise ValueError('already modified, fail closed')
    if (root/DEST).exists(): raise ValueError('header already present, fail closed')
    # Guard is included in both target compilation units. No DWIN writes enabled.
    newg=oldg.replace('#include "../../../inc/MarlinConfig.h"\n','#include "../../../inc/MarlinConfig.h"\n'+INC,1).replace(G29_START,G29_START+G29_ADD,1)
    if newg==oldg or INC not in newg: raise ValueError('G29 include anchor missing')
    newr=oldr.replace('#include "LCD_RTS.h"\n','#include "LCD_RTS.h"\n'+INC,1)
    data=Path(header).read_bytes()
    if b'SV04 NEXT 62' not in data: raise ValueError('wrong guard source')
    # Validate all anchors before any write, then write changes.
    (root/DEST).parent.mkdir(parents=True,exist_ok=True)
    (root/DEST).write_bytes(data)
    gpath.write_text(newg,encoding='utf-8');rpath.write_text(newr,encoding='utf-8')
    return dict(oem_commit=BASE,files={x:hashlib.sha256((root/x).read_bytes()).hexdigest() for x in [G29,RTS,DEST]},
                active_features=['G29 U Q read-only diagnostic'],
                blocked_features=['Auto60 actuation','T1 physical motion','DWIN touch triggers','EEPROM writes','flash release'])

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--header',default=str(Path(__file__).resolve().parents[1]/'src/SV04NextGuard62.h'));p.add_argument('--report',required=True)
    a=p.parse_args();report=patch(a.root,a.header)
    Path(a.report).write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print('SV04NEXT62_OVERLAY_OK READONLY=YES FLASH_APPROVED=NO')
if __name__=='__main__':main()
