#pragma once
// SV04 NEXT 62: passive firmware diagnostic, NOT A FLASH RELEASE.
// All actuation and EEPROM writes remain delegated to unmodified OEM code.
#if defined(SV04_NEXT_AUTO60_RELEASE) || defined(SV04_NEXT_DWIN_TOUCH_RELEASE) || defined(SV04_NEXT_T1_MOTION_RELEASE) || defined(SV04_NEXT_EEPROM_RELEASE) || defined(SV04_NEXT_FLASH_RELEASE)
 #error "SV04 NEXT 62: actuation/touch/EEPROM/flash release forbidden pending hardware verification"
#endif
namespace sv04next62 {
  enum Status { OFFLINE, READ_ONLY, FAULT };
  struct Diagnostics {
    static constexpr bool can_heat = false;
    static constexpr bool can_move = false;
    static constexpr bool can_park_t1 = false;
    static constexpr bool can_save_mesh = false;
    static constexpr bool can_touch_start = false;
    static constexpr unsigned mesh_points = 16;
  };
  // Only numerical integrity. Physical clearance requires device measurements.
  inline bool mesh_valid(const bool (&seen)[16], const float (&z)[16]) {
    for (unsigned i=0;i<16;i++)
      if (!seen[i] || !(z[i]>=-2.0f && z[i]<=2.0f)) return false;
    return true;
  }
  inline bool hypothetical_carriage_clearance(float left_max, float right_min, float margin) {
    return margin>=0.0f && left_max+margin<right_min;
  }
}
