# SV04 NEXT 79
Gemeinsamer Offline-Angriff: DWIN, Auto60, T1-Sicherheit und EEPROM-Gates auf dem gepinnten Sovol-Marlin-Quellstand. **Nur Diagnose/Modell, nichts flashen.**

`python -m unittest discover -s tests -q`

Später: `python tools/apply_chain79.py --root /pfad/zum/sauberen/oem --report /tmp/stage79.json`

Keine Touch-, Bewegungs-, Heiz- oder EEPROM-Schreibfreigabe. Keine DWIN-HMI-Firmware erzeugt. Siehe `docs/UEBERGABE_79.md`.
