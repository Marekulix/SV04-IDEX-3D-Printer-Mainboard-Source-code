# SV04 NEXT 80: Punkt 1, tatsächliche Marlin-Integration

**Nur Punkt 1 der fünf beschlossenen Arbeitspunkte.** An DWIN-HMI, Auto60-Bewegungssteuerung, T1-Bewegung und EEPROM wurde in dieser Runde nichts weiterentwickelt.

Die bereits vorhandenen Änderungen aus Stand 62–79 sind als vollständiges Quellpaket enthalten. `tools/integrate80.py` wendet die Kette **auf einen sauberen, exakten Sovol-OEM-Git-Checkout** an und liefert einen normalen Diff der modifizierten Marlin-Quelldateien, die neu angelegten Header sowie eine SHA-256-Dateiliste. `--build` führt außerdem einen **echten PlatformIO STM32-Build** aus und protokolliert dessen Erfolg bzw. Fehler.

## Reproduzierbar ausführen

```sh
python3 SV04_NEXT_80/tools/integrate80.py --root _sv04_oem80 --out sv04next80-proof --build
```

Dazu muss `_sv04_oem80` ein sauberer Checkout von `1867fcba75354a5c65e0631d6972dd19f1bd6cbe` sein. Plattform: `STM32F103RET6_creality`. Nicht auf einem schon gepatchten oder unbekannten Quellbaum anwenden.

## Abnahmestatus

- Vollständige Anwendung auf Original-Marlin **noch nicht live durchgeführt**, weil derzeit kein OEM-Checkout in dieser Offline-Umgebung verfügbar ist.
- Echter STM32-Build für Stand 80 **noch offen**.
- Paket enthält daher **keine freigegebene Firmware.bin**.
- **Punkt 1 nicht 100 % abgeschlossen.** Wir bleiben bei Punkt 1, bis ein realer Firmwarebuild erfolgreich ist.

`80.yml` liegt separat vor und kann später im Android-GitHub-Workflow eingesetzt werden. **Es ist nicht nötig, jetzt GitHub zu benutzen.**
