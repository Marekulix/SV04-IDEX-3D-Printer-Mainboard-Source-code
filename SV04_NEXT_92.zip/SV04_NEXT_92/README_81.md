# SV04 NEXT 81 — Nur Punkt 1: Marlin-Integration

Verbindliche Reihenfolge: Punkt 1 vollständig abschließen, dann erst Punkt 2.

**Neue konkrete Änderung:** Ein vollständiger Integrationslauf erfasst nun nicht bloß einen Quell-Diff, sondern prüft die aus dem real gepatchten Marlin-Quellbaum referenzierten lokalen Header, kontrolliert `git diff --check`, die gemeinsamen Integrationsmarker und die vorhandenen Quelldateien. Die Resultate werden als JSON protokolliert. Ein erfolgreiches Unit-Test-Ergebnis kann nicht als erfolgreicher STM32-Build ausgegeben werden.

Lauf mit einem sauberen OEM-Checkout von Commit `1867fcba75354a5c65e0631d6972dd19f1bd6cbe`:

```bash
python3 SV04_NEXT_81/tools/integrate81.py --root _sv04_oem81 --out sv04next81-proof --build
```

**Ist-Zustand:** Die tatsächlichen OEM-Gesamtquellen und PlatformIO fehlen im lokalen Container. Deshalb wurde **kein STM32-Build von Stand 81** ausgeführt; der nächste Abnahmepunkt bleibt offen. Dies ist kein flasherlaubter Firmwarestand.

Keine neuen Sicherheitsmodelle. Punkt 2 (DWIN-Oberfläche) wurde nicht bearbeitet.
