# SV04 NEXT 76 – Marlin-Integrationsaudit, ohne GitHub

Ausgang: Stand 75, Entwicklungseinschätzung 52 %. Ziel: vollständige Integrationsprüfung statt erneuter isolierter Simulation.

## Implementiert

- `src/SV04NextIntegration76.hpp`: C++11-Kompiliersperre der fünf experimentellen Freigaben; kontrolliert den OEM-VP-Bereich einschließlich bekanntem Konflikt `0x110E`.
- `tools/apply76.py`: fügt den Guard in das reale Marlin-Displaymodul ein, nur bei genau passendem Stand 75; zweimalige Anwendung und aufgehobene HMI-Sperre werden abgelehnt.
- `tools/audit_chain76.py`: überprüft **alle** erwarteten Header, einzelne Patch-Einbindungen, G29-Diagnosemarker, DWIN-Präsentationsaufruf und unveränderte HMI-Sperre im **gepatchten** Quellbaum; erstellt SHA-256-Beweisliste.
- `tools/apply_chain76.py`: Gesamtkette, mit anschließendem Audit. **Nur in einer temporären Kopie des gepinnten Sovol-Originals anwenden.**
- C++11-Hosttest und Negativtests; alle bestehenden Tests bleiben enthalten.

## Grenzen

Der OEM-DWIN-Sender bestätigt den Empfang nicht. Es ist weiterhin **keine passende, nachweislich installierte DWIN-HMI-Projektdatei** vorhanden. Das 0x110E-Adressenproblem ist dokumentiert, nicht behoben. Die schöne farbige Seite liegt nur als Designressource vor. Es gibt **keine Marlin-Heiz-, Bewegungs-, BLTouch- oder EEPROM-Freigabe**. Stand 76 wurde nicht als STM32-Firmware gebaut. Kein Flashen.

Für die spätere Prüfung: gepinnten OEM-Commit `1867fcba75354a5c65e0631d6972dd19f1bd6cbe` sauber auschecken, `python tools/apply_chain76.py --root <oem-kopie> --report <report.json>` ausführen, gesondert PlatformIO bauen, weder BIN noch neue HMI ungeprüft auf das Gerät spielen.
