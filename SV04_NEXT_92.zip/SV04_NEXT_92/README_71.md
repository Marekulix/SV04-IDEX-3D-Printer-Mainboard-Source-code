# SV04 NEXT 71 – DWIN-Ressourcenaudit und Patchketten-Reparatur

**Status:** Offline-Entwicklungsstand. NICHT FLASHEN.

## Tatsächlich erledigt
- Kritischen Syntaxfehler in `tools/apply_chain70.py` behoben. Die gesamte Python-Patchkette ist wieder importierbar.
- Syntaxprüfung **aller** im Paket vorhandenen Python-Skripte als verpflichtenden Regressionstest ergänzt.
- Originale Bildressource (`272×480`, unkomprimiertes BMP mit 24 bit) überprüft.
- OEM-DWIN-Meshadressen (16 x `0x1100` bis `0x111E` in 2er-Schritten) überprüft.
- Bekannte VP-/Tasten-Überlappung `0x110E` explizit im Auditbericht vermerkt.
- Keine neuen Touchadressen eingeführt, keine Stellbefehle oder EEPROM-Schreibvorgänge ergänzt.

## Unverändert offen
- Die farbige Grafik (aus Stand 69) ist **noch nicht** Bestandteil einer nachgewiesen kompatiblen, kompilierten `13TouchFile.bin` / `14ShowFile.bin`.
- Keine authentische HMI-Projektdatei **vom eingebauten Display** vorhanden; keine automatische HMI-Kompatibilitätsannahme.
- Kein STM32-Build dieser Änderung und keine Hardwaretest-/Flashfreigabe.
- Der bereits vorhandene OEM-Mesh-Renderer aus Stand 70 arbeitet auf alten VPs und darf nicht mit einer fertig eingebauten farbigen Bildschirmseite verwechselt werden.

## Offlinetests

`python -m unittest discover -s tests -p 'test*.py' -v`

Auditbericht neu erzeugen:

`python tools/audit_dwin71.py --out proof/DWIN71_AUDIT.json`

## Fortsetzung
- Hardware-displayseitige HMI-Version/Originalressourcen verifizieren.
- Farbige Bildschirmgrafik in die kompatible DWIN-Projektquelle aufnehmen und den Bildindex sowie alle VP-/Touchkollisionen prüfen.
- In späterem gemeinsamen GitHub-Lauf Patchkette und Firmware erfolgreich auf STM32 bauen.

## Fortschritt
Der zuletzt ausgewiesene **51 %**-Entwicklungswert war eine Schätzung. Die Reparatur und Ressourcenauditierung rechtfertigen ohne HMI-/Hardware-/STM32-Nachweis keine belastbare weitere Steigerung.
