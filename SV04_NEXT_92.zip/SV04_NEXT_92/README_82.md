# SV04 NEXT 82: Punkt 1 Marlin-Integration

- Nur **Punkt 1**, keine weiteren Sicherheitsmodelle und keine Arbeiten an DWIN, Auto60 oder T1.
- Das ausführbare Werkzeug `tools/integrate82.py` appliziert die vollständige bestehende Patchkette auf einen **sauberen** OEM-Checkout, prüft die **echten** Marlin-Dateien **vor** dem Build und exportiert einen vollständigen Quellstand als `marlin-integrated-overlay.tar.gz` sowie `marlin-full-tracked-82.patch`.
- Anders als ein reiner Git-Diff enthält das Overlay **auch alle neu hinzugefügten Header**. Die Liste und SHA256-Werte stehen in `integrated_source_manifest82.json`.
- `--build` startet einen echten PlatformIO-Build für `STM32F103RET6_creality`. Das Ergebnis wird mit Erfolg/Fehler, Firmware-SHA256 und Log protokolliert.
- Die reale Ausführung gegen die originalen OEM-Quellen **ist lokal nicht möglich**, weil der Container GitHub nicht erreichen kann und `pio` nicht installiert ist. **Kein STM32-Build von 82 ist bestätigt.**
- Vorherige lokale Testanzahl Stand 81: 123. Für Stand 82 werden zusätzliche Werkzeugtests ergänzt, aber nur ein echter STM32-Build zählt als Compiler-Nachweis.

Echter Lauf (wenn später ein sauberer OEM-Checkout vorliegt):

`python3 SV04_NEXT_82/tools/integrate82.py --root _sv04_oem82 --out sv04next82-proof --build`

**Status Punkt 1:** offen. Nicht flashen.
