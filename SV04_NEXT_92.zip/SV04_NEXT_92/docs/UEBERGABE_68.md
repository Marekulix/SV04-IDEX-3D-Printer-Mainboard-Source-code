# SV04 NEXT 68 | DWIN-Darstellung: aktive OEM-Ausgabe

Technisch umgesetzt: Firmware-Patch in `RTS_AutoBedLevelPage()`, bestehende Sovol-Displayvaradressen 0x1100–0x111E, 16 Punkte, alternierende X-Richtung, Rundung in 0,001 mm, vollständige Datensatzprüfung vor Ausgabe. Nur während der bestehenden OEM-AutoBedLevel-Seitenabschlussroutine (`waitway == 3`) bei `leveling_is_valid()` und 4×4-Bilinear-Mesh.

**Wichtige Grenzen:** Das ist die native Anzeige auf dem *bestehenden* OEM-Bettleveling-Bildschirm, nicht eine neu designte Bildschirmgrafik. Installierte Displayprojektdatei fehlt. Keine neue Auto60-Taste, Farbkarten-Ressource, DWIN-Flash oder Hardwareabnahme. OEM-Adresse 0x110E hat eine bekannte Überlappung mit der OEM-Touchadressliste. Diese wird weder entfernt noch zur neuen Taste umgewidmet.

Dieser Stand 68 muss später per GitHub-ST32-Compile und auf der echten Displayversion geprüft werden. Kein Firmwareflash ohne separate Freigabe.

Prozentstand: vorher 49 %, neue Schätzung 50 % für implementierten Renderer und Regressionstests. Keine Behauptung 100 % DWIN-Produktabnahme.
