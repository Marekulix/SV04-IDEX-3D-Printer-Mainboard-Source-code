# SV04 NEXT – Übergabe Stand 65 · 04.11.2026

## Geprüfte Altentscheidungen
- Sovol SV04 IDEX: zwei Extruder, BLTouch, Marlin V1.1.0; Mainboard Creality V5.2.1. Keine Annahme über physischen T1-Freiraum.
- Auto60: nur Idle, T0 aktiv, Bett 60 °C und stabil, sicheres G28, 16 BLTouch-Messpunkte, Validierung, Leveling aktivieren, nur dann M500 und M420 V/M503-Rückprüfung. Z-Offset (-1,10 mm) niemals automatisch ändern. Fehler dürfen vorheriges EEPROM-Mesh nicht überschreiben.
- Keine Touch-Startfunktion ohne reale VP-/Seitennummern-Ground-Truth und identifiziertes DWIN-Projekt.
- Fortlaufende Nummerierung 64 → 65. Weiterentwicklung offline über Android, bei Bedarf später ZIP + workflow YAML für GitHub.

## Was Stand 65 tatsächlich liefert
- C++11-Nachbildung wesentlicher Fail-Closed-Invarianten aus den Python-Modellen 63/64, einschließlich 16 Messpunkten, laufend erneuter Freigabekontrolle, Stopp bei alten/doppelten Meldungen, EEPROM-Vorabprüfstatus und extern belegtem Readback.
- Passiv angebunden an die bereits gebaute 62er-Marlin-Diagnose (Patchscript, nicht eigener STM32-Build); Include und `static_assert` im G29-Quelltext. Diagnoseausgabe bleibt statisch `LOCKED` und erfindet keine Sensormessung.
- Stufenübergreifender gepinnter Offline-Patch `62 → 65` mit enthaltenen 62er-Abhängigkeiten.

## Testbelege
- Stand 65: 9/9 Python-Testfälle bestanden, inkl. kompilierter und ausgeführter C++-Fälle.
- Stand 64 Regression: 21/21 Tests bestanden.
- **Nicht getestet:** vollständige kompilierte Marlin-65-Firmware, DWIN-Display, tatsächliche BLTouch-Messung, Extruder-Kollision, realer EEPROM-Write/Restore.

## Offen für Hardware- und Buildfreigabe
1. OEM-Checkout auf die Pin-Version bringen und Patchkette 62→65 mit STM32-PlatformIO bauen, Binary diff und RAM/Flash analysieren.
2. Physische T0/T1-Sicherheitsabstände, Z-Homing, BLTouch-Fenster und Notabbruch am echten SV04 verifizieren.
3. Exakte Original-DWIN-Ressourcen und Touch-VPs abgleichen; erst danach Auto60-Taste integrieren.
4. Persistente EEPROM-Strategie vor realem M500 inklusive Wiederherstellung im Fehlerfall validieren.

## Fortschritt
- Vorläufiger Entwicklungsstand nach Stand 64: **ca. 47 %**.
- Stand 65 C++-Portierung und konkrete Diagnose-Patchkette: **ca. 48 %** als *subjektive Planungsschätzung* (+1 Prozentpunkt), keine gemessene Abnahmequote.
- Gesamtfunktions-/Hardwarefreigabe: **nicht neu nachgewiesen**. Die früheren 39,5 % waren ein anders bewerteter Katalog; diese beiden Prozentstände sind keine identischen Messreihen.
