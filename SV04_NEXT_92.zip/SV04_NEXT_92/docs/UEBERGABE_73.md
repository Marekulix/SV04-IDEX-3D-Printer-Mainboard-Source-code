# SV04 NEXT 73 – DWIN Wire Bridge

- Stand 72 1:1 übernommen, neue Stage 73 ergänzt.
- Verbindet die DGUS-Frameprüfungen aus 72 über einen C++-Adapter mit dem bestehenden OEM-RTS_SndData. Es werden **keine rohen UART-Telegramme** doppelt gesendet.
- `apply_chain73.py` wendet die gesamte Patchkette auf **sauberen, gepinnten** OEM-Quellcode an (über die vererbte Prüfkette).
- Standardmäßiges `MAPPING_CONFIRMED=false`: Keine zusätzliche DWIN-Meshübertragung durch Stage 73, solange das tatsächlich verbaute HMI und der Konflikt `0x110E` nicht geklärt sind. Tests mit explizit simuliertem `true` beweisen den 16-Werte-Pfad.
- Keine neuen Tasten, Seitenwechsel, Bewegungen, Heizung, EEPROM-Änderungen oder Flashfreigabe.
- Komplette farbige HMI-Seite braucht weiterhin eine nachweisbar passende originale HMI-Quelldatei. Ein PNG/BMP ist kein installiertes DWIN-Projekt.
- C++-Code auf Host kompiliert und getestet, **kein STM32-Build Stand 73**, kein Test am physischen SV04.
- Gesamtfortschritt 51,5 % (vorläufig); keine automatische Erhöhung ohne Hardware-/Integrationsnachweis.
