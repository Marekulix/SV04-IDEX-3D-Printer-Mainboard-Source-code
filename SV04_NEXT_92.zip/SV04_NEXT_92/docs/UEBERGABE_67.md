# SV04 NEXT 67 – DWIN-Datenvertrag und Marlin-Diagnose, OFFLINE

Stand 67 übernimmt die vollständige Kette aus 66 und erweitert die tatsächlich bereits in Marlin verankerte lesende `G29 U Q`-Diagnose um eine Versionskennung. Der zusätzliche C++11-Header verwaltet ein **rein internes 16-Punkt-Mesh-Snapshot-Modell** für eine spätere DWIN-Anzeige. Es werden **keine echten BLTouch- oder Temperaturdaten ausgelesen**. Ein Statusmodell ist keine Hardwarefreigabe.

**Keine erfundenen DWIN-VP-Adressen:** Bis die aktive HMI-Ressource am eingebauten Display verifiziert ist, existieren keine Touch-Bindings und keine RTS-Schreiboperationen. Die angezeigte Diagnose `VP=UNVERIFIED SENSOR=NOT_READ` stellt genau diese Einschränkung dar.

**Sicherheit:** Kein Auto60, keine Motorfahrt, kein Heizen, kein EEPROM-Schreiben, keine Änderung des OEM-G29-Verfahrens für normale Befehle. Die diagnostische Kombination `G29 U Q` ist ausschließlich in einem künftig erfolgreich gebauten und separat freigegebenen SV04-NEXT-Firmwarestand verfügbar, nicht auf der momentan installierten Originalfirmware.

**Nächster GitHub-Lauf:** Auf sauberem Sovol-OEM-Checkout mit gepinntem Commit `1867fcba75354a5c65e0631d6972dd19f1bd6cbe` `python3 tools/apply_chain67.py --root ... --report ...` und dann `pio run -e STM32F103RET6_creality`. Das ist noch nicht hier durchgeführt; Ergebnis nur als Host-Tests ausweisen.

**Fortschritt:** 48,5 % vorher, ca. 49 % Entwicklungs-Einschätzung neu (+0,5 Prozentpunkte für Marlin-nahe Diagnoseschnittstelle). Kein Zuwachs in Hardware-Abnahme. Keine Flashfreigabe.
