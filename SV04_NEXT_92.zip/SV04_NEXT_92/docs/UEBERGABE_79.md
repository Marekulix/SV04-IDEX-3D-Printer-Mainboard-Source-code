# SV04 NEXT 79 – gemeinsamer Angriff DWIN / Auto60 / T1 / EEPROM

**Status: Offline-Integration der drei Bereiche fertig; KEINE betriebsfähige Auto60-Firmware.**

## 1 DWIN
- Vorhandene native OEM-Mesh-Anzeige der 16 Werte aus Stand 68 weiter eingebunden; neue Stand-79-Kontrakte in `LCD_RTS.cpp` eingehängt.
- Schreiber des experimentellen DWIN-Pfades weiterhin fest gesperrt. Eine PNG-/BMP-Seite wird NICHT zu einer installierbaren DWIN-HMI-Firmware.
- OEM-VP `0x110E` bleibt ungeklärter Konflikt; keine neuen Touchbuttons.

## 2 Auto60
- Gemeinsame C++11-Funktionsprüfung für Bett-Temperaturfenster 59–61 °C, modellierte Haltezeit >=30 s, Vollständigkeit/Integrität des 4×4-Mesh, Fehlerpriorisierung.
- Der konkrete G29-Diagnosepfad enthält jetzt einen Compile-time-Vertrag; das Modul gibt KEINEN Heiz- oder Bewegungsbefehl aus.
- Temperaturstabilität im Modell ist KEINE freigegebene physische Temperierzeit.

## 3 T1 und EEPROM
- T1: vollständig endliche numerische Geometrie mit Sicherheitsabstand und *separatem* Park-Sensor-Nachweis als Pflicht. Diese Nachweise fehlen real.
- EEPROM: vollständiges Mesh + Nachweis einer Sicherung + Rückleseverifikation als Pflicht. FNV-Fingerprint ist keine cryptographische EEPROM-Integritätsbestätigung. Kein `M500` wird aufgerufen.
- Vollständiger automatischer Backup-/Rollback-Nachweis am Gerät fehlt weiterhin.

## First flash gate – benötigte Nachweise
A. **Firmware Build**: `tools/apply_chain79.py` auf sauberem gepinntem Sovol-OEM-Quellbaum anwenden, `pio run -e STM32F103RET6_creality` und Buildlog prüfen. Host-Tests beweisen keinen STM32-Build.
B. **Geräteidentität**: Board Creality V5.2.1/STM32F103RET6, Bootloader, DWIN-Version, Konfig und EEPROM-Backup vor Installation.
C. **Erster sicherer Test**: zunächst nur Diagnose-Firmware mit gesperrten NEU-Aktuatoren/Taste, getrennte Hardware-Sicherheitsprüfung, danach **erst** Bedien-/Auto60-Freigabe.
D. **Funktionsfreigabe Auto60**: T1-Abstände auf realem Gerät, BLTouch-/Homing-Sicherheit, 60°C thermische Prüfung, kontrollierte EEPROM-Sicherung und Rollback, DWIN-HMI-Nachweis.

**Keine feste Stunden-/Tagesangabe seriös möglich**, solange Build- und Hardware-Nachweise fehlen. Für eine erste Diagnoseinstallation fehlen insbesondere A+B+C. Eine einsatzfähige Auto60-FW erfordert zusätzlich D.

Gesamtfortschritt bisher 52,5 % (vorläufige Schätzung). Kein automatisch erfundener Prozentanstieg ohne vollständigen STM32-Build.
