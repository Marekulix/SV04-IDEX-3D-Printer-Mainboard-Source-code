# SV04 NEXT 74 | DWIN atomare Vorabvalidierung

## Nachweisbare Änderung
- `src/SV04NextDwinAtomic74.hpp`: C++11-Batch-Vorprüfung des **vollständigen** 16-Punkte-Mesh vor dem ersten RTS_SndData-Aufruf.
- Sequentielle Prüfung der 16 Original-OEM-DWIN-Adressen 0x1100..0x111E, 0x110E bleibt bekannter Konflikt.
- Presenter-Cache wird erst nach vollständiger versuchter Übertragung aktualisiert. Bei ungültigen Messwerten und Framefehlern keine Ausgabe, kein Cache-Commit.
- `tools/apply74.py`: passgenaue, ablehnende Patchanwendung auf Stand 73.
- `tools/apply_chain74.py`: pinned OEM -> 62 -> 65 -> 66 -> 67 -> 68 -> 70 -> 73 -> 74.

## Grenzen / Sicherheitslage
- Originale DWIN-HMI-Projektdatei des Druckers nicht nachgewiesen. `sv04next73::MAPPING_CONFIRMED` bleibt **false**: Der neue Displaypfad sendet im echten Firmware-Quellcode derzeit **0** Werte.
- Übertragung ist logisch vorvalidiert, aber ein physikalischer UART-Abbruch nach Beginn der Übertragung kann keine atomare Übernahme am Display garantieren.
- Keine neue HMI-Bildschirmseite auf dem Display, keine Touchfreigabe, keine T1-/Heiz-/EEPROM-Freigabe, keine Flashfreigabe.
- Lokaler C++11-Test, **kein** STM32/PlatformIO Build dieses Standes und kein Hardwaretest.

## Nächster Block
- Exakte, kompatible DWIN-HMI-Ressourcen für die originale SV04-Firmware ermitteln.
- HMI-VP-Kollision 0x110E hardwarebezogen prüfen und die HMI-Freigabe erst dann aktivieren.
- Gesamte Patchkette auf dem STM32 im späteren GitHub-Build kompilieren.
