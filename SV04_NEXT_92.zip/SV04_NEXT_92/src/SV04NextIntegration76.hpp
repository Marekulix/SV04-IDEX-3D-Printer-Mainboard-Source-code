#pragma once
// SV04 NEXT 76: compile-time lock + no additional DWIN hardware command.
#if defined(SV04_NEXT_AUTO60_RELEASE) || defined(SV04_NEXT_DWIN_TOUCH_RELEASE) || defined(SV04_NEXT_T1_MOTION_RELEASE) || defined(SV04_NEXT_EEPROM_RELEASE) || defined(SV04_NEXT_FLASH_RELEASE)
#error "SV04 NEXT 76: hardware release not approved"
#endif
#include "SV04NextDwinDelivery75.hpp"
namespace sv04next76 {
static constexpr bool CAN_HEAT=false, CAN_MOVE=false, CAN_SAVE=false;
static constexpr bool CAN_TOUCH=false, CAN_FLASH=false;
// This is a compile-time proof of the OEM 4x4 VP range only,
// not a claim that the installed HMI image is compatible.
constexpr uint16_t vp(uint8_t index) { return static_cast<uint16_t>(0x1100u + 2u*index); }
static_assert(vp(0)==0x1100u && vp(7)==0x110Eu && vp(15)==0x111Eu,
              "SV04 NEXT OEM VP mismatch");
static_assert(!sv04next73::MAPPING_CONFIRMED, "installed HMI has not been authenticated");
static_assert(!CAN_HEAT && !CAN_MOVE && !CAN_SAVE && !CAN_TOUCH && !CAN_FLASH,
              "read-only firmware build");
}
