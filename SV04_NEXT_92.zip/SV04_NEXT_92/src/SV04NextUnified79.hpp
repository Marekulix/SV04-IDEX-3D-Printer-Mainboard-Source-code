#pragma once
// SV04 NEXT 79: unified read-only Marlin-side preflight model.
// NO heat/motion/touch dispatch/M500. No HMI mapping authorization. No flash approval.
#if defined(SV04_NEXT_AUTO60_RELEASE) || defined(SV04_NEXT_DWIN_TOUCH_RELEASE) || defined(SV04_NEXT_T1_MOTION_RELEASE) || defined(SV04_NEXT_EEPROM_RELEASE) || defined(SV04_NEXT_FLASH_RELEASE)
#error "SV04 NEXT 79: unauthorized actuator, touch or flash release"
#endif
#include <stdint.h>
#include <math.h>
#include "SV04NextSafety65.hpp"
#include "SV04NextDwinRenderer68.hpp"
#include "SV04NextHmiGate78.hpp"
namespace sv04next79 {
static constexpr bool CAN_HEAT=false, CAN_MOVE=false, CAN_DWIN_TOUCH=false, CAN_EEPROM_WRITE=false, CAN_FLASH=false;
static constexpr float BED_TARGET_C = 60.0f;
static constexpr uint8_t MESH_SIZE=16;
static_assert(!CAN_HEAT && !CAN_MOVE && !CAN_DWIN_TOUCH && !CAN_EEPROM_WRITE && !CAN_FLASH,"read-only only");
static_assert(!sv04next78::MESH_TRANSMISSION_ALLOWED,"unverified display remains disabled");
enum Fault : uint8_t { NONE=0, NOT_IDLE, TEMP_INVALID, T1_UNVERIFIED, PROBE_UNVERIFIED, MESH_INVALID, EEPROM_UNVERIFIED, HMI_UNVERIFIED };
struct Realtime {
  float bed_actual,bed_target;
  float t0_rightmost, t1_leftmost, physical_margin;
  bool idle, t0_selected, t1_park_sensor_proven, probe_proven;
  bool mesh_valid, saved_mesh_backup_proven, eeprom_readback_proven, hmi_signature_proven;
};
struct Report {
  Fault first_failure;
  bool temperature_ok, t1_geometry_ok, mesh_ok, eeprom_safe, hmi_safe, can_start;
  uint8_t completed_points;
};
inline bool finite_range(float v,float minv,float maxv) { return isfinite(v) && v>=minv && v<=maxv; }
inline bool t1_geometry(const Realtime &a) {
  // Geometric check is NOT proof of real-world safety; park must be independently sensed.
  return a.t1_park_sensor_proven && finite_range(a.t0_rightmost,-500,500)
       && finite_range(a.t1_leftmost,-500,500) && finite_range(a.physical_margin,1,100)
       && a.t0_rightmost+a.physical_margin < a.t1_leftmost;
}
inline bool temp_stable(float a,float b,float c,uint32_t elapsed_ms) {
  if(elapsed_ms<30000u) return false; // Model lower-bound, not validated real thermal soak
  return finite_range(a,59,61) && finite_range(b,59,61) && finite_range(c,59,61)
         && fabsf(a-b)<=1.0f && fabsf(b-c)<=1.0f && fabsf(a-c)<=1.0f;
}
inline bool mesh_check(const float (&z)[16],uint16_t seen_mask,uint32_t &fingerprint) {
  if(seen_mask != 0xffffu) {fingerprint=0;return false;}
  fingerprint=sv04next65::Monitor::hash(z);
  return fingerprint!=0;
}
inline bool readback_matches(uint32_t before,uint32_t after,bool readback_verified) {
  return readback_verified && before!=0u && after==before;
}
inline Report examine(const Realtime &s,const float (&z)[16],uint16_t seen_mask) {
  uint32_t h=0; const bool mesh=mesh_check(z,seen_mask,h);
  Report r={NONE,false,false,false,false,false,false,0};
  for(uint8_t i=0;i<16;++i)if(seen_mask & (uint16_t(1u)<<i))++r.completed_points;
  r.temperature_ok=finite_range(s.bed_actual,59,61) && finite_range(s.bed_target,59,61);
  r.t1_geometry_ok=t1_geometry(s);
  r.mesh_ok=mesh && s.mesh_valid;
  r.eeprom_safe=s.saved_mesh_backup_proven && s.eeprom_readback_proven && r.mesh_ok;
  r.hmi_safe=s.hmi_signature_proven && false; // Real HMI project is NOT authenticated.
  if(!s.idle || !s.t0_selected)r.first_failure=NOT_IDLE;
  else if(!r.temperature_ok)r.first_failure=TEMP_INVALID;
  else if(!r.t1_geometry_ok)r.first_failure=T1_UNVERIFIED;
  else if(!s.probe_proven)r.first_failure=PROBE_UNVERIFIED;
  else if(!r.mesh_ok)r.first_failure=MESH_INVALID;
  else if(!r.eeprom_safe)r.first_failure=EEPROM_UNVERIFIED;
  else r.first_failure=HMI_UNVERIFIED;
  r.can_start=false; // NEVER return physical authorization from model.
  return r;
}
} // namespace sv04next79
