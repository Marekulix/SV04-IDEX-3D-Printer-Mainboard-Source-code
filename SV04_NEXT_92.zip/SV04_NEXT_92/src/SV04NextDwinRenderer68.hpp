#pragma once
// SV04 NEXT 68. Read-only renderer for verified original OEM 16-point mesh VPs.
// Does not dispatch touch keys, does not move steppers, heat bed or write EEPROM.
#if defined(SV04_NEXT_AUTO60_RELEASE) || defined(SV04_NEXT_DWIN_TOUCH_RELEASE) || defined(SV04_NEXT_T1_MOTION_RELEASE) || defined(SV04_NEXT_EEPROM_RELEASE) || defined(SV04_NEXT_FLASH_RELEASE)
#error "SV04 NEXT 68 remains hardware locked"
#endif
#include <stdint.h>
#include <math.h>
namespace sv04next68 {
static constexpr uint16_t MESH_BASE_VP=0x1100;
static constexpr uint8_t MESH_CELLS=16;
static constexpr bool TOUCH_ENABLED=false, EEPROM_ENABLED=false, MOTION_ENABLED=false, FLASH_APPROVED=false;
// Reproduces the Sovol OEM display order, serpentine per row.
inline uint8_t linear_index_to_x(uint8_t i) {const uint8_t y=i/4;return y & 1 ? uint8_t(3-(i%4)) : uint8_t(i%4);}
inline uint8_t linear_index_to_y(uint8_t i) {return i/4;}
inline uint16_t address(uint8_t i) {return uint16_t(MESH_BASE_VP + 2u*i);}
inline bool encode_mm(float mm,int16_t &encoded) {
  if (!isfinite(mm) || mm < -2.0f || mm > 2.0f) return false;
  const float scaled=mm*1000.0f;
  if (!isfinite(scaled) || scaled < -2000.0f || scaled > 2000.0f) return false;
  encoded=static_cast<int16_t>(scaled);return true;
}
// Atomic full-snapshot validation: no partial invalid DWIN writes.
template<typename GetValue> bool validate(GetValue get, int16_t (&out)[16]) {
  for(uint8_t i=0;i<16;++i)
    if(!encode_mm(get(linear_index_to_x(i),linear_index_to_y(i)),out[i])) return false;
  return true;
}
template<typename Writer> void send(const int16_t (&points)[16],Writer write) {
  for(uint8_t i=0;i<16;++i) write(address(i),points[i]);
}
// Intentionally does not use AUTO_BED_LEVEL_ICON_VP: OEM 1 means busy, not "success".
// There is a known 0x110E overlap with the OEM touch address list. The same OEM
// mesh VPs are used, with no additional address allocation or event processing.
}
