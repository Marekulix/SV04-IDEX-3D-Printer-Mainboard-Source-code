#pragma once
// SV04 NEXT 67: offline DWIN display DATA CONTRACT ONLY. Does not touch RTS or VP.
// Read-only build; no touch handler, EEPROM writes or motion.
#if defined(SV04_NEXT_AUTO60_RELEASE) || defined(SV04_NEXT_DWIN_TOUCH_RELEASE) || defined(SV04_NEXT_T1_MOTION_RELEASE) || defined(SV04_NEXT_EEPROM_RELEASE) || defined(SV04_NEXT_FLASH_RELEASE)
#error "SV04 NEXT 67 requires disabled releases"
#endif
#include <stdint.h>
#include <math.h>
namespace sv04next67 {
static constexpr uint8_t kVersion=67, kMeshCells=16;
static constexpr bool kTouchEnabled=false,kAuto60Enabled=false,kT1MovementEnabled=false,kEepromEnabled=false,kFlashApproved=false;
enum ScreenStatus : uint8_t { LOCKED=0, DIAGNOSTIC=1, INVALID_DATA=2, FAULT=3 };
struct MeshSnapshot {
 uint16_t received_mask;
 int16_t z_microns[16];
 uint32_t sequence;
 bool fault;
 MeshSnapshot(): received_mask(0), z_microns(), sequence(0), fault(false) {}
 bool add(uint8_t index,float millimeters,uint32_t seq) {
   if(fault || seq<=sequence || index>=16 || (received_mask&(1u<<index)) || !isfinite(millimeters) || millimeters < -2.0f || millimeters > 2.0f) {
     fault=true;return false;
   }
   const float micron=millimeters*1000.0f;
   if(!isfinite(micron) || micron < -2000.0f || micron > 2000.0f) {fault=true;return false;}
   z_microns[index]=static_cast<int16_t>(micron);
   received_mask=static_cast<uint16_t>(received_mask | (1u<<index));sequence=seq;return true;
 }
 uint8_t count() const {uint16_t m=received_mask;uint8_t n=0;while(m){n+=m&1u;m>>=1;}return n;}
 bool complete() const {return !fault && received_mask==0xFFFFu && count()==16;}
};
struct DwinReadOnlyView {
 uint8_t stage,completed;
 ScreenStatus status;
 bool heating,motion,t1,save,touch;
};
inline DwinReadOnlyView view(const MeshSnapshot &m) {
 DwinReadOnlyView r={kVersion,m.count(),m.fault ? FAULT : DIAGNOSTIC,false,false,false,false,false};
 return r;
}
// VP bindings are intentionally NOT supplied: must be confirmed on installed panel.
// Never synthesize touch key values or guess panel VP addresses.
}
