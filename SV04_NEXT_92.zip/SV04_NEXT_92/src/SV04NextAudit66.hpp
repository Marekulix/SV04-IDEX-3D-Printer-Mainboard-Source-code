#pragma once
// SV04 NEXT 66: read-only validation helpers. NOT a motion controller, probe driver,
// EEPROM controller, display handler or flash release. Never actuates hardware.
#if defined(SV04_NEXT_AUTO60_RELEASE) || defined(SV04_NEXT_DWIN_TOUCH_RELEASE) || defined(SV04_NEXT_T1_MOTION_RELEASE) || defined(SV04_NEXT_EEPROM_RELEASE) || defined(SV04_NEXT_FLASH_RELEASE)
#error "SV04 NEXT 66: no hardware or flash release"
#endif
#include <stdint.h>
#include <math.h>
#include "SV04NextSafety65.hpp"
namespace sv04next66 {
// The actual firmware integration emits CONSTANT diagnostic flags only, not
// simulated sensor data or claims of real-world T1 clearance.
static constexpr bool kAuto60Enabled=false;
static constexpr bool kPhysicalT1Validated=false;
static constexpr bool kTouchStartEnabled=false;
static constexpr bool kEepromWriteEnabled=false;
static constexpr bool kFlashApproved=false;
enum AuditStatus : uint8_t { AUDIT_OK, AUDIT_UNSAFE, AUDIT_BAD_DATA, AUDIT_NOT_READY };
struct Sample { uint32_t sequence, elapsed_ms; float bed_celsius; bool probe_ok, t0_selected, t1_park_confirmed, idle; };
struct Auditor {
 uint32_t last_sequence, last_time;
 uint8_t stable_samples;
 bool seen, failed;
 Auditor():last_sequence(0),last_time(0),stable_samples(0),seen(false),failed(false){}
 AuditStatus ingest(const Sample &s) {
   if(failed)return AUDIT_UNSAFE;
   if(seen && (s.sequence<=last_sequence || s.elapsed_ms<=last_time)) {failed=true;return AUDIT_BAD_DATA;}
   seen=true; last_sequence=s.sequence;last_time=s.elapsed_ms;
   if(!s.probe_ok || !s.t0_selected || !s.t1_park_confirmed || !s.idle) {failed=true;return AUDIT_UNSAFE;}
   if(!isfinite(s.bed_celsius) || s.bed_celsius<59.0f || s.bed_celsius>61.0f) {failed=true;return AUDIT_BAD_DATA;}
   if(stable_samples<3) ++stable_samples;
   return stable_samples==3 ? AUDIT_OK : AUDIT_NOT_READY;
 }
 // For documentation/testing only: no gcode issuance, not an M500 permission.
 bool model_ready() const {return seen && !failed && stable_samples>=3;}
};
inline bool physical_clearance_model(float t0_right,float t1_left,float margin) {
 return isfinite(t0_right) && isfinite(t1_left) && isfinite(margin)
        && margin>0.0f && t0_right+margin<t1_left;
}
inline bool mesh_complete_model(const bool (&seen)[16], const float (&z)[16]) {
 for (uint8_t i=0;i<16;++i)
   if(!seen[i] || !isfinite(z[i]) || z[i]<-2.0f || z[i]>2.0f) return false;
 return true;
}
} // namespace sv04next66
