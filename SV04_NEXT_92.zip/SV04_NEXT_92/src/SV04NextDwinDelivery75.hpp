#pragma once
// SV04 NEXT 75: delivery-aware, complete preflight for 16 OEM DWIN values.
// A successful call to the OEM RTS_SndData is NOT a physical DWIN ACK.
// This component can only infer synchronous software acceptance from a bool writer.
#if defined(SV04_NEXT_AUTO60_RELEASE) || defined(SV04_NEXT_DWIN_TOUCH_RELEASE) || defined(SV04_NEXT_T1_MOTION_RELEASE) || defined(SV04_NEXT_EEPROM_RELEASE) || defined(SV04_NEXT_FLASH_RELEASE)
#error "SV04 NEXT 75: no hardware release"
#endif
#include "SV04NextDwinAtomic74.hpp"
namespace sv04next75 {
static constexpr bool CAN_MOVE=false,CAN_HEAT=false,CAN_SAVE=false,CAN_TOUCH=false,CAN_FLASH=false;
// Never commit snapshot state if any writer call rejects. The display may have
// received a prefix already; next attempt must resend the FULL 16-element set.
// The bool callback is a *software acceptance* signal, never a physical ACK.
template<typename Getter,typename TryWriter>
bool update(sv04next70::Presenter &state, Getter get, TryWriter try_write,
            uint32_t timestamp_ms, bool page_visible, bool mapping_verified) {
  if (!mapping_verified || !page_visible) { state.invalidate(); return false; }
  sv04next70::Presenter shadow=state;
  sv04next74::Batch batch;
  const bool changed=shadow.update(get,[&batch](uint16_t vp,int16_t value){
    batch.collect(vp,value);
  },timestamp_ms,true);
  if (!changed || !batch.complete()) {
    if (!batch.valid) state.invalidate();
    return false;
  }
  for (uint8_t i=0;i<16;++i) {
    uint16_t vp=0;int16_t value=0;
    if (!sv04next72::decode(batch.frame[i].bytes,vp,value) ||
        !try_write(vp,value)) {
      state.invalidate();
      return false;
    }
  }
  state=shadow;
  return true;
}
}
