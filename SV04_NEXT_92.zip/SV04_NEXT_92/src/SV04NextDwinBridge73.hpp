#pragma once
// SV04 NEXT 73 - OEM sender bridge with explicit mapping confirmation.
// No raw serial injection. All bytes are validated against the OEM 0x82
// frame contract, then dispatched through the existing RTS_SndData API.
// The 0x110E VP is an acknowledged shared OEM value. No touch writes added.
#if defined(SV04_NEXT_AUTO60_RELEASE) || defined(SV04_NEXT_DWIN_TOUCH_RELEASE) || defined(SV04_NEXT_T1_MOTION_RELEASE) || defined(SV04_NEXT_EEPROM_RELEASE) || defined(SV04_NEXT_FLASH_RELEASE)
#error "SV04 NEXT 73: hardware release flags forbidden"
#endif
#include <stdint.h>
#include "SV04NextDwinWire72.hpp"
#include "SV04NextDwinPresenter70.hpp"
namespace sv04next73 {
static constexpr bool CAN_HEAT=false, CAN_MOVE=false, CAN_SAVE=false, CAN_TOUCH=false, CAN_FLASH=false;
static constexpr bool MAPPING_CONFIRMED=false; // Never infer installed HMI from OEM source.
// Verify each encoded frame before using the native OEM sender. No second raw sender.
struct WriteState {bool valid;uint8_t sent;WriteState():valid(true),sent(0) {}};
template<typename Writer> struct VerifiedWriter {
  Writer &writer;
  WriteState &state;
  explicit VerifiedWriter(Writer &w,WriteState &s):writer(w),state(s) {}
  void operator()(uint16_t vp,int16_t value) {
    sv04next72::Frame frame;
    uint16_t decoded_vp=0;
    int16_t decoded_value=0;
    if (!sv04next72::encode(vp,value,frame) ||
        !sv04next72::decode(frame.bytes,decoded_vp,decoded_value) ||
        decoded_vp!=vp || decoded_value!=value) {state.valid=false;return;}
    writer(decoded_vp,decoded_value);
    ++state.sent;
  }
};
// Full snapshot is validated by Presenter before any I/O. This gate is normally
// false until the exact OEM HMI is identified and its 0x110E overlap reviewed.
template<typename Getter,typename Writer>
bool update(sv04next70::Presenter &presenter,Getter get,Writer writer,
            uint32_t now_ms,bool oem_result_page_visible,bool hmi_mapping_verified) {
  if (!hmi_mapping_verified || !oem_result_page_visible) {presenter.invalidate();return false;}
  WriteState state;
  VerifiedWriter<Writer> safe_writer(writer,state);
  const bool changed=presenter.update(get,safe_writer,now_ms,true);
  return changed && state.valid && state.sent==16;
}
}
