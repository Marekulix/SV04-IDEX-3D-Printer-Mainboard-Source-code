#pragma once
// SV04 NEXT 74 - validate COMPLETE OEM DWIN snapshot before dispatch.
// No writes occur unless all 16 frames pass validation. Writer is the preexisting
// OEM RTS_SndData; physical UART failure after dispatch cannot be rolled back.
#if defined(SV04_NEXT_AUTO60_RELEASE) || defined(SV04_NEXT_DWIN_TOUCH_RELEASE) || defined(SV04_NEXT_T1_MOTION_RELEASE) || defined(SV04_NEXT_EEPROM_RELEASE) || defined(SV04_NEXT_FLASH_RELEASE)
#error "SV04 NEXT 74 - no physical release permitted"
#endif
#include "SV04NextDwinBridge73.hpp"
namespace sv04next74 {
static constexpr bool CAN_HEAT=false, CAN_MOVE=false, CAN_SAVE=false, CAN_TOUCH=false, CAN_FLASH=false;
struct Batch {
  sv04next72::Frame frame[16];
  uint8_t count;
  bool valid;
  Batch():frame(),count(0),valid(true) {}
  void collect(uint16_t vp,int16_t value) {
    if(!valid || count>=16 || vp!=sv04next68::address(count)) {valid=false;return;}
    sv04next72::Frame item;
    uint16_t back_vp=0; int16_t back_value=0;
    if(!sv04next72::encode(vp,value,item) ||
       !sv04next72::decode(item.bytes,back_vp,back_value) ||
       back_vp!=vp || back_value!=value) {valid=false;return;}
    frame[count++]=item;
  }
  bool complete() const {return valid && count==16;}
};
// Provide mapping confirmation as an explicit runtime argument only for tests.
// In deployed Marlin call site stage 74 always passes MAPPING_CONFIRMED=false.
// This stage never asserts that the installed HMI has been confirmed.
template<typename Getter,typename Writer>
bool update(sv04next70::Presenter &state,Getter get,Writer writer,
            uint32_t timestamp_ms,bool result_page_visible,bool mapping_verified) {
  if(!mapping_verified || !result_page_visible) {state.invalidate();return false;}
  sv04next70::Presenter shadow=state;
  Batch batch;
  const bool wants_update=shadow.update(get,[&batch](uint16_t vp,int16_t value){
    batch.collect(vp,value);
  },timestamp_ms,true);
  if(!wants_update || !batch.complete()) return false;
  // Verified complete 16-frame batch. No malformed/partial logical snapshot.
  for(uint8_t i=0;i<16;++i) {
    uint16_t vp=0; int16_t value=0;
    if(!sv04next72::decode(batch.frame[i].bytes,vp,value)) return false;
    writer(vp,value);
  }
  state=shadow; // Only commit cached values after every attempted OEM write.
  return true;
}
}
