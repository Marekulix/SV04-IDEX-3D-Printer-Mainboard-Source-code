#pragma once
// SV04 NEXT 72: pure data conversion to OEM DGUS write-variable frames.
// This does NOT communicate with hardware, install HMI assets, or handle touch.
// DGUS framing: 5A A5 LEN 82 VP_H VP_L DATA_H DATA_L.
#if defined(SV04_NEXT_AUTO60_RELEASE) || defined(SV04_NEXT_DWIN_TOUCH_RELEASE) || defined(SV04_NEXT_T1_MOTION_RELEASE) || defined(SV04_NEXT_EEPROM_RELEASE) || defined(SV04_NEXT_FLASH_RELEASE)
#error "SV04 NEXT 72 diagnostics only: hardware release forbidden"
#endif
#include <stdint.h>
#include <stddef.h>
#include "SV04NextDwinRenderer68.hpp"
namespace sv04next72 {
static constexpr bool CAN_FLASH=false, CAN_TOUCH=false, CAN_HEAT=false, CAN_MOVE=false, CAN_SAVE=false;
static constexpr uint8_t FRAME_SIZE=8, FRAME_LENGTH=5, WRITE_VAR=0x82;
static constexpr uint16_t OEM_COLLISION_VP=0x110E;
struct Frame {uint8_t bytes[FRAME_SIZE];};
inline bool valid_oem_mesh_vp(uint16_t vp) {
  return vp>=0x1100u && vp<=0x111Eu && ((vp-0x1100u)%2u)==0u;
}
inline bool known_oem_collision(uint16_t vp) {return vp==OEM_COLLISION_VP;}
inline bool encode(uint16_t vp,int16_t value,Frame &out) {
  if(!valid_oem_mesh_vp(vp)) return false;
  const uint16_t raw=static_cast<uint16_t>(value);
  out.bytes[0]=0x5A;out.bytes[1]=0xA5;out.bytes[2]=FRAME_LENGTH;
  out.bytes[3]=WRITE_VAR;out.bytes[4]=uint8_t(vp>>8);out.bytes[5]=uint8_t(vp);
  out.bytes[6]=uint8_t(raw>>8);out.bytes[7]=uint8_t(raw);
  return true;
}
inline bool decode(const uint8_t (&bytes)[FRAME_SIZE],uint16_t &vp,int16_t &value) {
  if(bytes[0]!=0x5A || bytes[1]!=0xA5 || bytes[2]!=FRAME_LENGTH || bytes[3]!=WRITE_VAR) return false;
  const uint16_t decoded_vp=(uint16_t(bytes[4])<<8)|bytes[5];
  if(!valid_oem_mesh_vp(decoded_vp)) return false;
  const uint16_t raw=(uint16_t(bytes[6])<<8)|bytes[7];
  vp=decoded_vp;value=static_cast<int16_t>(raw);
  return true;
}
// Atomic precheck before emitting any frames: rejects malformed measurement sets.
// Caller must verify that the installed HMI uses the stock 16 VPs and that
// 0x110E is not used for an active touch action on the visible page.
template<typename Getter,typename Sink> bool encode_mesh(Getter get,Sink sink,bool hmi_verified) {
  if(!hmi_verified) return false; // fail closed; never assume user display compatibility
  int16_t values[16];
  if(!sv04next68::validate(get,values)) return false;
  Frame frames[16];
  for(uint8_t i=0;i<16;i++) if(!encode(sv04next68::address(i),values[i],frames[i])) return false;
  for(uint8_t i=0;i<16;i++) sink(frames[i]);
  return true;
}
}
