#pragma once
// SV04 NEXT 70 - bounded read-only OEM DWIN display bridge.
// Never changes a page, reads a key, triggers G-code, EEPROM, heaters, or movement.
#if defined(SV04_NEXT_AUTO60_RELEASE) || defined(SV04_NEXT_DWIN_TOUCH_RELEASE) || defined(SV04_NEXT_T1_MOTION_RELEASE) || defined(SV04_NEXT_EEPROM_RELEASE) || defined(SV04_NEXT_FLASH_RELEASE)
#error "SV04 NEXT 70 is diagnostics only: release flags forbidden"
#endif
#include <stdint.h>
#include "SV04NextDwinRenderer68.hpp"
namespace sv04next70 {
static constexpr bool CAN_MOVE=false, CAN_HEAT=false, CAN_SAVE=false, CAN_TOUCH=false, CAN_FLASH=false;
struct Presenter {
  int16_t previous[16];
  bool have_previous;
  uint32_t last_send;
  bool have_send_time;
  Presenter():previous(),have_previous(false),last_send(0),have_send_time(false) {}
  void invalidate() { have_previous=false; have_send_time=false; }
  // Caller supplies a complete, validated OEM 4x4 mesh. No partial writes.
  template<typename Getter,typename Writer>
  bool update(Getter get,Writer send,uint32_t now_ms,bool page_visible) {
    if(!page_visible) return false;
    int16_t next[16];
    if(!sv04next68::validate(get,next)) { invalidate(); return false; }
    bool changed=!have_previous;
    for(uint8_t i=0;i<16;++i) if(!have_previous || previous[i]!=next[i]) changed=true;
    if(!changed) return false;
    // Minimum 500ms between full-screen updates; unsigned subtraction handles wrap.
    if(have_send_time && static_cast<uint32_t>(now_ms-last_send)<500u) return false;
    for(uint8_t i=0;i<16;++i) send(sv04next68::address(i),next[i]);
    for(uint8_t i=0;i<16;++i) previous[i]=next[i];
    have_previous=true;have_send_time=true;last_send=now_ms;
    return true;
  }
};
}
