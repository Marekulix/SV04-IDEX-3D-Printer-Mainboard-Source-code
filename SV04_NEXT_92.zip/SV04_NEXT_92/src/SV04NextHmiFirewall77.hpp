#pragma once
// SV04 NEXT 77: firmware call-site firewall. No HMI mapping has been authenticated.
// Model-only functions in earlier stages accept a test bool. The firmware path may not.
#if defined(SV04_NEXT_AUTO60_RELEASE) || defined(SV04_NEXT_DWIN_TOUCH_RELEASE) || defined(SV04_NEXT_T1_MOTION_RELEASE) || defined(SV04_NEXT_EEPROM_RELEASE) || defined(SV04_NEXT_FLASH_RELEASE)
#error "SV04 NEXT 77: hardware authorization denied"
#endif
#include "SV04NextIntegration76.hpp"
namespace sv04next77 {
static constexpr bool HMI_AUTHENTICATED = false;
static constexpr bool CAN_TRANSMIT_MESH = false;
static constexpr uint16_t OEM_SHARED_VP = 0x110E;
static_assert(sv04next76::vp(7) == OEM_SHARED_VP, "OEM VP conflict changed");
static_assert(!sv04next73::MAPPING_CONFIRMED, "HMI mapping must remain unverified");
static_assert(!HMI_AUTHENTICATED && !CAN_TRANSMIT_MESH, "do not enable display writes");
// Marlin call site uses this, not the parameter-driven test adapter.
// No write callback is ever invoked, even if the caller supplies valid mesh data.
template<typename Getter, typename Writer>
inline bool locked_update(sv04next70::Presenter &state, Getter, Writer, uint32_t, bool) {
  state.invalidate();
  return false;
}
}
