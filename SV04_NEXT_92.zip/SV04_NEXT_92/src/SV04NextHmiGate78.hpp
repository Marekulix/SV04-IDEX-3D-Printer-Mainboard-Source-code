#pragma once
// SV04 NEXT 78: firmware gate has no DWIN writer argument at all.
// Explicitly no display writes, touch dispatch, heating, motion, or EEPROM.
#if defined(SV04_NEXT_AUTO60_RELEASE) || defined(SV04_NEXT_DWIN_TOUCH_RELEASE) || defined(SV04_NEXT_T1_MOTION_RELEASE) || defined(SV04_NEXT_EEPROM_RELEASE) || defined(SV04_NEXT_FLASH_RELEASE)
#error "SV04 NEXT 78: hardware authorization denied"
#endif
#include "SV04NextHmiFirewall77.hpp"
namespace sv04next78 {
static constexpr bool HMI_VERIFIED = false;
static constexpr bool MESH_TRANSMISSION_ALLOWED = false;
static_assert(!sv04next77::HMI_AUTHENTICATED && !sv04next77::CAN_TRANSMIT_MESH, "previous safety gate must remain locked");
static_assert(!HMI_VERIFIED && !MESH_TRANSMISSION_ALLOWED, "unauthorized HMI release");
// There is intentionally no callback or sender parameter in the firmware API.
inline bool observe_only(sv04next70::Presenter &state, uint32_t) {
  state.invalidate();
  return false;
}
}
