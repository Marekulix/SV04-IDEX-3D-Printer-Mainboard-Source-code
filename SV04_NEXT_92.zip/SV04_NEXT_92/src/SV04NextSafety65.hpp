#pragma once
// SV04 NEXT 65 - read-only reference state machine. No actuator or EEPROM access.
// This is NOT a physical safety system or flash-release authorization.
#if defined(SV04_NEXT_AUTO60_RELEASE) || defined(SV04_NEXT_DWIN_TOUCH_RELEASE) || defined(SV04_NEXT_T1_MOTION_RELEASE) || defined(SV04_NEXT_EEPROM_RELEASE) || defined(SV04_NEXT_FLASH_RELEASE)
#error "SV04 NEXT 65: hardware release forbidden pending independent verification"
#endif
#include <stdint.h>
#include <math.h>
namespace sv04next65 {
enum State : uint8_t { LOCKED, READY, HEATING, SOAKING, HOMING, MESH, VALIDATE, SAVE_PENDING, READBACK, COMPLETE, FAILED };
enum Event : uint8_t { ARM, START, BED_AT_60, TEMP_SAMPLE, SOAK_VERIFIED, HOME_VERIFIED, MESH_POINT, MESH_VERIFIED, SAVE_REQUESTED, READBACK_VERIFIED, ABORT };
enum Fault : uint8_t { NO_FAULT, UNAUTHORIZED, ORDER, TEMPERATURE, MESH_ERROR, READBACK_ERROR, REVOKED, STALE_EVENT };
struct Gates {
  bool firmware_verified, hmi_verified, t1_clearance_verified, eeprom_recovery_verified;
  bool idle, t0_active, probe_healthy, emergency_stop;
  bool valid() const { return firmware_verified && hmi_verified && t1_clearance_verified && eeprom_recovery_verified && idle && t0_active && probe_healthy && !emergency_stop; }
};
struct Input { uint32_t sequence; Event event; float temperature, z; uint8_t index; bool external_verified; uint32_t mesh_fingerprint; };
struct Monitor {
  State state; Fault fault; uint32_t last_sequence, fingerprint;
  uint8_t points, samples; float low_temp, high_temp;
  bool has_sequence; float mesh[16];
  Monitor():state(LOCKED),fault(NO_FAULT),last_sequence(0),fingerprint(0),points(0),samples(0),low_temp(1000),high_temp(-1000),has_sequence(false),mesh() {}
  bool fail(Fault f) { state=FAILED; fault=f; fingerprint=0; return false; }
  static uint32_t hash(const float (&values)[16]) {
    // Deterministic bounded proof-of-integrity marker; not a cryptographic EEPROM checksum.
    uint32_t h=2166136261u;
    for(uint8_t i=0;i<16;++i) {
      if(!isfinite(values[i]) || values[i]<-2.0f || values[i]>2.0f) return 0;
      const int32_t n=static_cast<int32_t>(values[i]*100000.0f);
      uint32_t u=static_cast<uint32_t>(n);
      for(uint8_t j=0;j<4;++j) { h ^= (u >> (j*8)) & 0xffu; h*=16777619u; }
    }
    return h ? h : 1;
  }
  bool consume(const Input &in,const Gates &g) {
    if(has_sequence && in.sequence<=last_sequence) return fail(STALE_EVENT);
    has_sequence=true;last_sequence=in.sequence;
    if(in.event==ABORT) return fail(REVOKED);
    if(state==FAILED || state==COMPLETE) return false;
    if(!g.valid()) return fail(state==LOCKED ? UNAUTHORIZED : REVOKED);
    switch(state) {
      case LOCKED: if(in.event==ARM) { state=READY;return true; } break;
      case READY: if(in.event==START) { state=HEATING;return true; } break;
      case HEATING:
        if(in.event==BED_AT_60) {
          if(!isfinite(in.temperature)||in.temperature<59||in.temperature>61) return fail(TEMPERATURE);
          low_temp=high_temp=in.temperature;samples=1;state=SOAKING;return true;
        } break;
      case SOAKING:
        if(in.event==TEMP_SAMPLE) {
          if(!isfinite(in.temperature)||in.temperature<59||in.temperature>61) return fail(TEMPERATURE);
          ++samples; if(in.temperature<low_temp) low_temp=in.temperature; if(in.temperature>high_temp) high_temp=in.temperature;
          return true;
        }
        if(in.event==SOAK_VERIFIED) {
          if(samples<3 || high_temp-low_temp>1.0f || !in.external_verified) return fail(TEMPERATURE);
          state=HOMING;return true;
        }break;
      case HOMING: if(in.event==HOME_VERIFIED && in.external_verified) {state=MESH;return true;}break;
      case MESH:
        if(in.event==MESH_POINT) {
          if(in.index!=points||points>=16||!isfinite(in.z)||in.z< -2||in.z>2) return fail(MESH_ERROR);
          mesh[points++]=in.z;if(points==16) state=VALIDATE;return true;
        }break;
      case VALIDATE:
        if(in.event==MESH_VERIFIED && in.external_verified && points==16) {
          fingerprint=hash(mesh);if(!fingerprint)return fail(MESH_ERROR);
          state=SAVE_PENDING;return true;
        }break;
      case SAVE_PENDING:
        if(in.event==SAVE_REQUESTED) {
          if(!in.external_verified||in.mesh_fingerprint!=fingerprint) return fail(MESH_ERROR);
          state=READBACK;return true;
        }break;
      case READBACK:
        if(in.event==READBACK_VERIFIED) {
          if(!in.external_verified||in.mesh_fingerprint!=fingerprint) return fail(READBACK_ERROR);
          state=COMPLETE;return true;
        }break;
      default:break;
    }
    return fail(ORDER);
  }
  // Only a diagnostic suggestion, never a command to write EEPROM.
  bool save_preconditions_model(const Gates &g) const {return state==SAVE_PENDING && fingerprint!=0 && g.valid();}
};
static constexpr bool kCanHeat=false,kCanMove=false,kCanTouchStart=false,kCanWriteEeprom=false,kFlashApproved=false;
}
