# SV04 NEXT 72: DGUS-Protokoll und HMI-Evidenzprüfung

**Status: Offline-Modul, keine Flashfreigabe.**

## Tatsächlich umgesetzt
- `src/SV04NextDwinWire72.hpp` ist eine C++11-Implementierung der DGUS-Writes (`5A A5 05 82 VP_H VP_L DATA_H DATA_L`) für die vorhandenen 16 OEM-Mesh-VPs.
- Vollständige Vorabvalidierung des 4×4-Meshes. Bei ungültigen Werten oder ohne ausdrücklich geprüfte HMI-Zuordnung werden **keine** Telegramme erzeugt.
- Test für alle 16 Telegramme, negative Werte, ungültige Adressen, NaN, fehlende HMI-Bestätigung und `0x110E` als bekannte mögliche Überschneidung.
- `tools/audit_hmi72.py` prüft HMI-Ressourcen als Datei-Inventar mit SHA-256 und verweigert die Kompatibilitäts- und Flashfreigabe auch bei vorhandener HMI-Datei.
- Bestehende Patchkette 62 → 65 → 66 → 67 → 68 → 70 unverändert mitgeliefert.

## Wichtige Grenzen
- Das DGUS-Telegrammmodul ist im Host kompiliert und getestet, **noch nicht** in die STM32-Firmware integriert.
- Die farbige SV04-NEXT-Bildschirmseite ist weiterhin eine exportierte Bitmap und Offline-Vorschau. Es gibt noch kein kompatibel kompiliertes DWIN-HMI-Image.
- Die öffentlich gefundene `Bully85/DGUS-SV04`-Projektquelle ist **Klipper-spezifisch** und nicht als kompatible OEM-Marlin-HMI validiert. Sie wird deshalb **nicht** in das Paket kopiert oder geflasht.
- OEM-Kollision bei VP `0x110E` ist bekannt und **nicht gelöst**. Neue Touch-Interaktionen sind gesperrt.
- Keine Motor-, Heizungs-, Z-Offset-, EEPROM- oder Druckerbefehle.

## Tests
`python -m unittest discover -s tests -p 'test*.py' -v`

## Entwicklungsfortschritt
Bisherige Schätzung: 51 %. Zusätzliche Arbeit ist nachgewiesen, neue Gesamtprozente erst nach überprüfbarer firmwareseitiger Integration bzw. HMI-Nachweis.
