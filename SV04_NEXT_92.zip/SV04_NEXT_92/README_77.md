# SV04 NEXT 77 – DWIN-Firmware-Firewall

Stand 76 hatte den Test-Adapter `sv04next75::update` direkt als Marlin-Aufrufstelle. Der Adapter akzeptiert zur Simulation einen `mapping_verified`-Parameter. In der gepatchten Firmware war dieser zwar `false`, konnte aber durch eine Änderung unbeabsichtigt aktiviert werden. Stand 77 ersetzt die **reale Marlin-Aufrufstelle** durch `sv04next77::locked_update`, dessen Verhalten unabhängig von Parametern grundsätzlich alle DWIN-Ausgaben sperrt. Das ursprüngliche C++-Übertragungsmodell bleibt für Hosttests erhalten.

Damit wird die echte DWIN-HMI-Version **nicht** als bestätigt ausgegeben. Es wird **kein** installierbares HMI-Projekt behauptet. Insbesondere ist die bekannte VP-Überlappung bei `0x110E` weiterhin ungeklärt und die farbige Grafik bleibt eine Ressource, nicht die installierte Displayseite.

`tools/apply77.py` verändert nur den vorhandenen Marlin-Code nach Stand 76 und verweigert unbekannte/doppelte Patches. `tools/apply_chain77.py` enthält die gesamte Reihenfolge. Kein STM32-Build, kein Hardwaretest, keine Flashfreigabe. Nächster Stand 78.
