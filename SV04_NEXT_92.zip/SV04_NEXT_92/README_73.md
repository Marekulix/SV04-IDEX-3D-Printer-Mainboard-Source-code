# SV04 NEXT 73

Offline-DWIN-Bridge: DGUS 72 validiert, DWIN OEM 70 schreibt ausschließlich nach explizit bestätigter HMI-Zuordnung. Keine Hardwarefreigabe.

Start Patchkette: `python tools/apply_chain73.py --root <sauberer_oem_clone> --report <report.json>`

Tests: `python -m unittest discover -s tests -p "test*.py"`

Siehe `docs/UEBERGABE_73.md`.
