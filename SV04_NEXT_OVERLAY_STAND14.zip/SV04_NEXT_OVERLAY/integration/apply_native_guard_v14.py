#!/usr/bin/env python3
"""Block 10: instrument the two OEM IDEX G28 carriage return paths.

Read-only. No auto-heat/motion/BLTouch action/EEPROM or DWIN VP. The two
X homeaxis returns are *not* proof of physical parking or switch validation.
Requires exact original Sovol OEM Git object bytes; rejects drift and repatch.
"""
from __future__ import annotations
import argparse,hashlib,json,re
from pathlib import Path
import apply_native_guard_v13 as previous
import apply_native_guard_v5 as base

OEM_BLOBS=previous.OEM_BLOBS
PatchRefused=previous.PatchRefused
G28=previous.G28
RTS=previous.RTS
HEADER_IDEX='Marlin/src/feature/sv04_next/SV04NextNativeIdexHomingTrace.hpp'
HEADER_EVIDENCE='Marlin/src/feature/sv04_next/SV04NextNativeIdexEvidence.hpp'
HEADER_AUDIT='Marlin/src/feature/sv04_next/SV04NextT1CorrelationAudit.hpp'
HEADERS=['SV04NextNativeThermalGate.hpp','SV04NextVisitProof.hpp',
         'SV04NextG29UReceipt.hpp','SV04NextNativeReadiness.hpp',
         'SV04NextT1EndstopObserver.hpp','SV04NextNativeEventTimeline.hpp',
         'SV04NextNativeStatusPacket.hpp','SV04NextMeshMapPacket.hpp',
         'SV04NextG28PassiveReceipt.hpp','SV04NextG28G29OrderWitness.hpp',
         'SV04NextNativeIdexHomingTrace.hpp','SV04NextT1CorrelationAudit.hpp',
         'SV04NextNativeIdexEvidence.hpp']


# Stand 14: statische Topologie der IDEX-Referenzfahrten wird aus dem ECHTEN Text ermittelt (frueher: feste Annahme "genau 2+2").
IDEX_X2=re.compile(r'(?m)^([ \t]*)active_extruder = 1;[ \t]*\n\s*homeaxis\(X_AXIS\);')
IDEX_X1=re.compile(r'(?m)^([ \t]*)active_extruder = 0;[ \t]*\n\s*homeaxis\(X_AXIS\);')
OVERLAY_MARKERS=('saw_x2_homeaxis_return(','saw_x1_homeaxis_return(','sv04_g28_scope','sv04_idex_scope','sv04next::','SV04 NEXT')
MAX_IDEX_PAIRS=4
LAST_TOPOLOGY:dict={}


def idex_topology(text:str)->dict:
    """Read-only analysis of the X2->X1 homing pairs in a G28.cpp text. Changes nothing."""
    x2=[m.start() for m in IDEX_X2.finditer(text)];x1=[m.start() for m in IDEX_X1.finditer(text)]
    order=''.join(k for _,k in sorted([(p,'2') for p in x2]+[(p,'1') for p in x1]))
    line=lambda pos:text.count('\n',0,pos)+1
    return {'x2':len(x2),'x1':len(x1),'x2_lines':[line(p) for p in x2],'x1_lines':[line(p) for p in x1],
            'interleaved':bool(x2) and order=='21'*len(x2),'order':order,
            'other_homeaxis_x':text.count('homeaxis(X_AXIS)')-len(x2)-len(x1)}


def render(original:dict[str,str],*headers:str)->dict[str,str]:
    if len(headers)!=13:raise PatchRefused('13 headers required')
    idex,audit,evidence=headers[-3:]
    required_idex=('both_x_homeaxis_returned', 'bool physical_t1_park_proven()const{return false;}',
                   'bool allows_motion()const{return false;}',
                   'bool allows_eeprom()const{return false;}')
    required_evidence=('frame_.t1_physically_parked=false;',
                       'frame_.allow_motion=false;',
                       'frame_.allow_heat=false;frame_.allow_eeprom=false;',
                       'bool permits_motion()const{return false;}',
                       'bool permits_eeprom()const{return false;}')
    required_audit=('bool physical_t1_park_proven()const{return false;}',
                    'bool permit_motion()const{return false;}')
    if (any(x not in idex for x in required_idex) or
        any(x not in evidence for x in required_evidence) or
        any(x not in audit for x in required_audit)):
        raise PatchRefused('passive security contract missing')
    dangerous=('queue.enqueue','settings.save(', 'setTargetBed(',
               'process_subcommands_now', 'do_blocking_move_to', 'M500')
    if any(x in idex+audit+evidence for x in dangerous):
        raise PatchRefused('observer headers may not contain actuator commands')
    for name,text in original.items():
        for mk in OVERLAY_MARKERS:
            if mk in text:raise PatchRefused(f'{name}: already contains SV04 NEXT marker {mk!r} (already patched or not the OEM file); nothing was modified')
    out=previous.render(original,*headers[:10])
    g28=out[G28]
    topo=idex_topology(g28);LAST_TOPOLOGY.clear();LAST_TOPOLOGY.update(topo)
    if topo['x2']<1 or topo['x1']<1:
        raise PatchRefused('OEM G28 IDEX homeaxis topology mismatch: no X2->X1 pair found (active_extruder = 1/0 directly followed by homeaxis(X_AXIS)); '+repr(topo))
    if topo['x2']!=topo['x1'] or not topo['interleaved'] or topo['x2']>MAX_IDEX_PAIRS:
        raise PatchRefused('OEM G28 IDEX homeaxis topology mismatch: pairs not cleanly interleaved X2,X1,X2,X1... or more than %d; '%MAX_IDEX_PAIRS+repr(topo))
    g28=previous.replace_one(g28,
      '#include "../../feature/sv04_next/SV04NextG28PassiveReceipt.hpp"',
      '#include "../../feature/sv04_next/SV04NextG28PassiveReceipt.hpp"\n'
      '  #include "../../feature/sv04_next/SV04NextNativeIdexHomingTrace.hpp"',G28)
    g28=previous.replace_one(g28,
      'namespace sv04next { G28PassiveReceipt g28_passive_receipt; }',
      'namespace sv04next { G28PassiveReceipt g28_passive_receipt; }\n'
      '  namespace sv04next { NativeIdexHomingTrace native_idex_homing_trace; }',G28)
    g28=previous.replace_one(g28,
      'sv04next::G28PassiveReceipt::Scope sv04_g28_scope(sv04next::g28_passive_receipt, (uint32_t)millis());',
      'sv04next::G28PassiveReceipt::Scope sv04_g28_scope(sv04next::g28_passive_receipt, (uint32_t)millis());\n'
      '    sv04next::NativeIdexHomingTrace::Scope sv04_idex_scope(\n'
      '      sv04next::native_idex_homing_trace,(uint32_t)millis(),\n'
      '      sv04next::g28_passive_receipt.view().sequence);',G28)
    g28=previous.replace_one(g28,
      'sv04_g28_scope.finish((uint32_t)millis(),',
      'sv04_idex_scope.finish((uint32_t)millis());\n'
      '    sv04_g28_scope.finish((uint32_t)millis(),',G28)
    # Every IDEX X2->X1 pair found in the real text is instrumented (1..4, cleanly interleaved); the count is audited against that analysis.
    # Probe only after the native `homeaxis()` call has returned. Counts do NOT
    # testify that a switch was hit, nor that T1 is physically parked.
    def add_x2(m:re.Match)->str:
        indent=m.group(1)
        return (m.group(0)+'\n'+indent+'#if ENABLED(AUTO_BED_LEVELING_BILINEAR) && DISABLED(PROBE_MANUALLY)\n'
                +indent+'  sv04next::native_idex_homing_trace.saw_x2_homeaxis_return((uint32_t)millis(),active_extruder);\n'
                +indent+'#endif')
    def add_x1(m:re.Match)->str:
        indent=m.group(1)
        return (m.group(0)+'\n'+indent+'#if ENABLED(AUTO_BED_LEVELING_BILINEAR) && DISABLED(PROBE_MANUALLY)\n'
                +indent+'  sv04next::native_idex_homing_trace.saw_x1_homeaxis_return((uint32_t)millis(),active_extruder);\n'
                +indent+'#endif')
    g28,n2=IDEX_X2.subn(add_x2,g28)   # dasselbe Muster wie die Analyse idex_topology()
    g28,n1=IDEX_X1.subn(add_x1,g28)
    if (n2,n1)!=(topo['x2'],topo['x1']):raise PatchRefused('OEM G28 IDEX homeaxis topology mismatch: analysis and substitution disagree; '+repr((n2,n1,topo)))
    out[G28]=g28
    rt=out[RTS]
    rt=previous.replace_one(rt,
      '#include "../../../feature/sv04_next/SV04NextG28G29OrderWitness.hpp"',
      '#include "../../../feature/sv04_next/SV04NextG28G29OrderWitness.hpp"\n'
      '  #include "../../../feature/sv04_next/SV04NextNativeIdexHomingTrace.hpp"\n'
      '  #include "../../../feature/sv04_next/SV04NextT1CorrelationAudit.hpp"\n'
      '  #include "../../../feature/sv04_next/SV04NextNativeIdexEvidence.hpp"',RTS)
    rt=previous.replace_one(rt,
      'namespace sv04next { G28G29OrderWitness g28_g29_order_witness; }',
      'namespace sv04next { G28G29OrderWitness g28_g29_order_witness; }\n'
      '  namespace sv04next { T1CorrelationAudit t1_correlation_audit; }\n'
      '  namespace sv04next { NativeIdexEvidence native_idex_evidence; }',RTS)
    anchor='''      sv04next::g28_passive_receipt.view(), sv04next::g29u_receipt);'''
    rt=previous.replace_one(rt,anchor,anchor+'''
    // Read-only G28 X2/X1 path, X_MAX electrical edge and G29 observation.
    sv04next::t1_correlation_audit.observe((uint32_t)millis(),
      sv04next::g28_passive_receipt.view(),sv04next::t1_endstop_observer);
    sv04next::native_idex_evidence.observe((uint32_t)millis(),
      sv04next::g28_passive_receipt.view(),
      sv04next::native_idex_homing_trace.view(),
      sv04next::t1_correlation_audit.view(),
      sv04next::g28_g29_order_witness.view());''',RTS)
    out[RTS]=rt
    out[HEADER_IDEX]=idex;out[HEADER_AUDIT]=audit;out[HEADER_EVIDENCE]=evidence
    if any(out[n]!=original[n] for n in ('Marlin/Configuration.h','Marlin/src/module/probe.cpp')):
        raise PatchRefused('OEM config/probe unexpectedly modified')
    if g28.count('saw_x2_homeaxis_return(')!=topo['x2'] or g28.count('saw_x1_homeaxis_return(')!=topo['x1']:
        raise PatchRefused('G28 homing path audit incomplete: x2 hooks %d/%d, x1 hooks %d/%d'%(g28.count('saw_x2_homeaxis_return('),topo['x2'],g28.count('saw_x1_homeaxis_return('),topo['x1']))
    hooked=lambda k:len(re.findall(r'homeaxis\(X_AXIS\);\n\s*#if ENABLED\(AUTO_BED_LEVELING_BILINEAR\) && DISABLED\(PROBE_MANUALLY\)\n\s*sv04next::native_idex_homing_trace\.saw_x'+k+r'_homeaxis_return\(',g28))
    if hooked('2')!=topo['x2'] or hooked('1')!=topo['x1']:raise PatchRefused('G28 homing path audit incomplete: a hook is not directly behind its homeaxis(X_AXIS) call')
    if rt.count('native_idex_evidence.observe(')!=1 or rt.count('t1_correlation_audit.observe(')!=1:
        raise PatchRefused('RTS observer hook incomplete')
    return out


def apply(root:Path,headers:list[Path],evidence:Path|None=None):
    originals={}
    for name,sha in OEM_BLOBS.items():
        raw=(root/name).read_bytes()
        if base.git_blob_sha(raw)!=sha:raise PatchRefused('OEM SHA mismatch: '+name)
        originals[name]=raw.decode('utf-8')
    out=render(originals,*[h.read_text(encoding='utf-8') for h in headers])
    report={'block':10,'stm32_build':False,'physical_t1_witness':False,
            'automatic_motion':False,'automatic_heat':False,
            'eeprom_write':False,'dwin_button':False,'flash_approved':False,
            'changed_sha256':{}}
    for name,content in out.items():
        if name not in originals or content!=originals[name]:
            report['changed_sha256'][name]=hashlib.sha256(content.encode()).hexdigest()
            dest=root/name;dest.parent.mkdir(parents=True,exist_ok=True)
            dest.write_text(content,encoding='utf-8')
    if evidence:
        evidence.parent.mkdir(parents=True,exist_ok=True)
        evidence.write_text(json.dumps(report,indent=2)+'\n')
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path('.'))
    p.add_argument('--evidence',type=Path)
    for name in HEADERS:p.add_argument('--'+name[:-4].lower(),type=Path,default=Path('include')/name)
    a=p.parse_args()
    print(json.dumps(apply(a.root,[getattr(a,n[:-4].lower()) for n in HEADERS],a.evidence),indent=2))
