#!/usr/bin/env python3
"""Herkunft jedes Ankers der Patch-Kette: 'OEM' (steht im Original-Text der Datei) oder 'OVERLAY' (steht nur in Text, den ein frueherer Schritt selbst eingefuegt hat).
Nur OEM-Anker koennen am echten Quelltext scheitern. Aufruf ohne Argumente: analysiert die Kette auf den Test-Fixtures (Struktur der Kette, nicht die echten Dateien)."""
import contextlib, inspect, io, re, sys
from collections import Counter
from pathlib import Path
root = Path(__file__).resolve().parents[1]; sys.path[:0] = [str(root / 'integration'), str(root / 'tests')]


def analyse(originals: dict, heads: list, render):
    import apply_native_guard_v2 as v2
    mods = [m for n, m in list(sys.modules.items()) if n.startswith('apply_native_guard_v') and hasattr(m, 'replace_one')]; saved = {m: m.replace_one for m in mods}; rows = []
    def spy(value, before, after, name='?'):
        caller = Path(inspect.stack()[1].filename).stem.replace('apply_native_guard_', ''); orig = originals.get(name, '')
        rows.append({'step': caller, 'file': name, 'kind': 'OEM' if before in orig else 'OVERLAY', 'anchor': before[:70]})
        return saved[mods[0]](value, before, after, name)
    for m in mods: m.replace_one = spy
    try: out = render(dict(originals), *heads)
    finally:
        for m, f in saved.items(): m.replace_one = f
    return rows, out


if __name__ == '__main__':
    with contextlib.redirect_stdout(io.StringIO()): import test_overlay_v14 as T
    import apply_native_guard_v16 as v16
    heads = [(root / 'include' / n).read_text(encoding='utf-8') for n in v16.HEADERS]; rows, _ = analyse(dict(T.src), heads, v16.render)
    ver = lambda s: int(re.sub(r'\D', '', s) or 0); steps = sorted({r['step'] for r in rows}, key=ver)
    print('Herkunft der Anker (Struktur der Kette, ermittelt auf den Test-Fixtures):'); print(f"{'Schritt':8} {'OEM-Anker':>10} {'Overlay-Anker':>14}")
    c = Counter((r['step'], r['kind']) for r in rows)
    for s in steps: print(f"{s:8} {c[(s, 'OEM')]:>10} {c[(s, 'OVERLAY')]:>14}")
    late = [r for r in rows if ver(r['step']) >= 14 and r['kind'] == 'OEM']
    print(f"\nGesamt: {len(rows)} Anker, davon OEM {sum(1 for r in rows if r['kind'] == 'OEM')}; OEM-Anker ab v14: {len(late)}")
    print('Ab v14 haengt NUR die Regex-Suche der IDEX-Paare (idex_topology) am OEM-Text; sie ist in diesem Stand aus dem echten Text abgeleitet.')
