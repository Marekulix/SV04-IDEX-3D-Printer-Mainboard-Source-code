#!/usr/bin/env python3
"""Mutationskampagne gegen die NEUE Sicherheitslogik in integration/apply_native_guard_v14.py (Topologie, Marker, Audit). Tests: test_overlay_v14_forms.py und test_overlay_v14.py."""
import os, shutil, subprocess, sys, tempfile
from concurrent.futures import ThreadPoolExecutor
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..')); F = 'integration/apply_native_guard_v14.py'; orig = open(os.path.join(ROOT, F), encoding='utf-8').read()
M = [
 ('V01', 'Marker-Vorpruefung entfernt', "if mk in text:raise PatchRefused(f'{name}: already contains SV04 NEXT marker", "if False:raise PatchRefused(f'{name}: already contains SV04 NEXT marker"),
 ('V02', 'Marker saw_x2 nicht mehr gemeldet', "OVERLAY_MARKERS=('saw_x2_homeaxis_return(',", "OVERLAY_MARKERS=("),
 ('V03', 'null Paare erlaubt', "if topo['x2']<1 or topo['x1']<1:", "if False:"),
 ('V04', 'ungleiche Paarzahl erlaubt', "if topo['x2']!=topo['x1'] or not topo['interleaved'] or topo['x2']>MAX_IDEX_PAIRS:", "if not topo['interleaved'] or topo['x2']>MAX_IDEX_PAIRS:"),
 ('V05', 'Verschachtelung (X2,X1,X2,X1) nicht verlangt', "or not topo['interleaved'] or topo['x2']>MAX_IDEX_PAIRS:", "or topo['x2']>MAX_IDEX_PAIRS:"),
 ('V06', 'Obergrenze der Paare entfernt', "or topo['x2']>MAX_IDEX_PAIRS:", ":"),
 ('V07', 'Verschachtelung schwach geprueft (nur Anzahl)', "'interleaved':bool(x2) and order=='21'*len(x2)", "'interleaved':bool(x2) and order.count('2')==order.count('1')"),
 ('V08', 'Abgleich Analyse/Ersetzung entfernt', "if (n2,n1)!=(topo['x2'],topo['x1']):raise", "if False:raise"),
 ('V09', 'Zaehlaudit der Haken entfernt', "if g28.count('saw_x2_homeaxis_return(')!=topo['x2'] or g28.count('saw_x1_homeaxis_return(')!=topo['x1']:", "if False:"),
 ('V10', 'Pruefung "Haken direkt hinter homeaxis" entfernt', "if hooked('2')!=topo['x2'] or hooked('1')!=topo['x1']:raise", "if False:raise"),
 ('V11', 'Analyse zaehlt X1 mit falschem Muster', "IDEX_X1=re.compile(r'(?m)^([ \\t]*)active_extruder = 0;", "IDEX_X1=re.compile(r'(?m)^([ \\t]*)active_extruder = 9;"),
 ('V12', 'Substitution X1 ohne Haken (Hook-Text leer)', "saw_x1_homeaxis_return((uint32_t)millis(),active_extruder);\\n'", "saw_x1_NOOP((uint32_t)millis(),active_extruder);\\n'"),
]
def one(item):
    mid, why, old, new = item
    if orig.count(old) != 1: return (mid, why, 'UNGUELTIG(%d)' % orig.count(old), '')
    d = tempfile.mkdtemp(); shutil.copytree(os.path.join(ROOT, 'integration'), d + '/integration'); shutil.copytree(os.path.join(ROOT, 'include'), d + '/include'); shutil.copytree(os.path.join(ROOT, 'tests'), d + '/tests')
    open(os.path.join(d, F), 'w', encoding='utf-8').write(orig.replace(old, new)); env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1'); res = []
    for t in ('test_overlay_v14_forms.py', 'test_overlay_v14.py'):
        r = subprocess.run([sys.executable, 'tests/' + t], cwd=d, capture_output=True, text=True, env=env, timeout=120); res.append((t, r.returncode, (r.stderr.strip().splitlines() or [''])[-1][:70]))
    shutil.rmtree(d, ignore_errors=True); bad = [x for x in res if x[1]]
    return (mid, why, 'killed' if bad else 'SURVIVED', bad[0][0] + ': ' + bad[0][2] if bad else '')
with ThreadPoolExecutor(max_workers=2) as ex: res = list(ex.map(one, M))
for mid, why, st, info in res: print(f'{mid} {st:9} {why}' + (f'  <- {info}' if info else ''))
k = sum(r[2] == 'killed' for r in res); s = [r[0] for r in res if r[2] == 'SURVIVED']; bad = [r[0] for r in res if r[2].startswith('UNGUELTIG')]
print(f'--- erkannt {k}, UEBERLEBT {len(s)}: {s}, ungueltig {len(bad)} {bad} von {len(res)}')
