"""Reproduziert den gemeldeten Fehler 'G28 homing path audit incomplete' mit der ALTEN v14 (Stand 13) und prueft die neue v14 gegen viele G28-Layouts.
SYNTHETISCHE Texte (keine echte OEM-Datei); die echte Datei prueft die Diagnose (tools/overlay_diagnose.py) im CI."""
import contextlib, importlib.util, io, sys
from pathlib import Path
root = Path(__file__).resolve().parents[1]; sys.path[:0] = [str(root / 'integration'), str(root / 'tests')]
with contextlib.redirect_stdout(io.StringIO()): import test_overlay_v14 as T
import apply_native_guard_v15 as v15
v14 = T.v14; heads = [(root / 'include' / n).read_text(encoding='utf-8') for n in v15.HEADERS]
spec = importlib.util.spec_from_file_location('v14_old', root / 'tests/fixtures/apply_native_guard_v14_stand13.py'); old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
G = v14.G28; HDR = T.src[G].split('void GcodeSuite::G28() {')[0]
P2 = lambda i='    ': f'{i}active_extruder = 1;\n{i}homeaxis(X_AXIS);'; P1 = lambda i='    ': f'{i}active_extruder = 0;\n{i}homeaxis(X_AXIS);'
def g28(*blocks, tail=''):
    return HDR + "void GcodeSuite::G28() {\n  if (parser.seen_test('O')) return;\n" + '\n'.join(blocks) + '\n' + tail + "  TERN_(FULL_REPORT_TO_HOST_FEATURE, set_and_report_grblstate(M_IDLE));\n}\n"
def render(mod, text, which=None):
    src = dict(T.src); src[G] = text; fn = (which or v15).render
    return fn(src, *heads) if mod == 'new' else old.render(dict(T.src, **{G: text}), *heads[:13])
n_ck = [0]
def ck(c, m=''): assert c, m; n_ck[0] += 1
def refused(fn, *words):
    try: fn()
    except v14.PatchRefused as e: ck(all(w in str(e) for w in words), f'{words} nicht in: {e}'); return str(e)
    raise AssertionError('haette verweigert werden muessen: ' + str(words))
# --- R1 Reproduktion Ursache (a): OEM-Text enthaelt bereits einen Marker -> ALTE v14 meldet genau den gemeldeten Fehler
marked = g28(P2(), P1(), P2('      '), P1('      '), tail='  // saw_x2_homeaxis_return( bereits vorhanden\n')
refused(lambda: render('old', marked), 'G28 homing path audit incomplete')
msg = refused(lambda: render('new', marked), 'already contains SV04 NEXT marker', G); ck('nothing was modified' in msg)
# --- R2 Reproduktion Ursache (b): in der Repo-v14 wurde die erwartete Topologie auf (1,1) geaendert, die Audit-Zeile aber nicht
src_old = (root / 'tests/fixtures/apply_native_guard_v14_stand13.py').read_text(encoding='utf-8'); edited_src = src_old.replace("if (n2,n1)!=(2,2):raise", "if (n2,n1)!=(1,1):raise"); ck(edited_src != src_old)
spec2 = importlib.util.spec_from_loader('v14_edited', loader=None); edited = importlib.util.module_from_spec(spec2); exec(compile(edited_src, 'v14_edited.py', 'exec'), edited.__dict__)
one = g28(P2(), P1())
try: edited.render(dict(T.src, **{G: one}), *heads[:13]); raise AssertionError('editierte v14 haette scheitern muessen')
except v14.PatchRefused as e: ck('G28 homing path audit incomplete' in str(e), str(e))
out = render('new', one); gp = out[G]; ck(gp.count('saw_x2_homeaxis_return(') == 1 and gp.count('saw_x1_homeaxis_return(') == 1, 'neue v14: 1 Paar'); ck(v14.LAST_TOPOLOGY['x2'] == 1 and v14.LAST_TOPOLOGY['interleaved'])
# --- Layoutvarianten der NEUEN v14
for n in (1, 2, 3, 4):
    blocks = []
    for k in range(n): blocks += [P2('  ' * (k % 3 + 1)), '  // zwischen den Fahrten', P1('  ' * (k % 3 + 1)), '']
    gp = render('new', g28(*blocks))[G]; ck(gp.count('saw_x2_homeaxis_return(') == n and gp.count('saw_x1_homeaxis_return(') == n, f'{n} Paare')
    ck(gp.count('sv04_g28_scope.finish(') == 1 and gp.count('sv04_idex_scope.finish(') == 1)
refused(lambda: render('new', g28(*[P2(), P1()] * 5)), 'topology mismatch', 'more than 4')
refused(lambda: render('new', g28(P2(), P1(), P2())), 'topology mismatch', 'interleaved')          # X2 ohne X1
refused(lambda: render('new', g28(P1(), P2())), 'topology mismatch', 'interleaved')                  # falsche Reihenfolge
refused(lambda: render('new', g28(P2(), P2(), P1(), P1())), 'topology mismatch', 'interleaved')      # nicht verschachtelt
refused(lambda: render('new', g28('  homeaxis(X_AXIS);')), 'topology mismatch', 'no X2->X1 pair')    # null Paare
# Toleranzen, die echter Code haben kann: Leerzeilen zwischen den Zeilen, Leerzeichen am Zeilenende, fremde homeaxis(X_AXIS)-Aufrufe (z. B. #else-Zweig)
tol = g28('    active_extruder = 1; \n\n    homeaxis(X_AXIS);', P1(), '  #else\n  homeaxis(X_AXIS);\n  #endif'); gp = render('new', tol)[G]; ck(gp.count('saw_x2_homeaxis_return(') == 1 and v14.LAST_TOPOLOGY['other_homeaxis_x'] == 1)
# andere OEM-Dateien mit Markern werden ebenfalls vorab gemeldet
for key in (v14.RTS, 'Marlin/src/gcode/bedlevel/abl/G29.cpp'):
    s2 = dict(T.src); s2[key] = s2[key] + '\n// sv04next::x\n'; refused(lambda: v15.render(s2, *heads), 'already contains SV04 NEXT marker', key)
# Konsistenz-Audits gezielt ausloesen (sie sind bei gleichen Mustern sonst unausloesbar): Abgleich Analyse/Ersetzung und Zaehlaudit
real_topo = v14.idex_topology
def skewed(text):
    t = real_topo(text); t['x2'] += 1; t['x1'] += 1; return t
v14.idex_topology = skewed
try: refused(lambda: render('new', g28(P2(), P1(), P2('      '), P1('      '))), 'analysis and substitution disagree')
finally: v14.idex_topology = real_topo
saved_markers = v14.OVERLAY_MARKERS; v14.OVERLAY_MARKERS = ()
try: refused(lambda: render('new', marked), 'G28 homing path audit incomplete', 'x2 hooks 3/2')   # Marker-Vorpruefung umgangen: das Zaehlaudit faengt den gemeldeten Fall
finally: v14.OVERLAY_MARKERS = saved_markers
# die Standard-Fixture bleibt (2,2)
gp = v15.render(dict(T.src), *heads)[G]; ck(gp.count('saw_x2_homeaxis_return(') == 2 and gp.count('saw_x1_homeaxis_return(') == 2)
print(f'PASS v14 Formen: {n_ck[0]} Pruefungen (beide Fehlerursachen reproduziert, neue v14 behandelt beide; Layouts mit 1 bis 4 Paaren, 5 Verweigerungsfaelle); synthetisch, KEIN echtes OEM')
