# SV04 NEXT: Stand 14 (Claude, 31.10.2026)  |  NICHT FLASHEN

Anlass: Der echte CI-Lauf zeigte (a) `baseline`-Build GRUEN (5/5 OEM-Hashes stimmen, 154.460 Byte, Flash 29,4 %, RAM 14,1 %), (b) Host-Tests GRUEN auf GitHub (GCC 11),
(c) beide Overlay-Varianten scheitern im Trockenlauf mit `PatchRefused: G28 homing path audit incomplete` (apply_native_guard_v14.py, Zeile 115).
Befund: Mit dem Code aus Stand 13 kann dieser Fehler bei JEDEM G28-Layout nicht entstehen (4.000 Zufallslayouts, nur "OK" oder "topology mismatch"). Er ist nur moeglich, wenn der gelesene G28.cpp bereits
Overlay-Marker enthaelt oder die v14 im Repository von der gelieferten abweicht. BEIDE Ursachen sind mit der alten v14 reproduziert (`tests/test_overlay_v14_forms.py`). Der echte G28.cpp lag mir NICHT vor.
Aenderungen: v14 leitet die IDEX-Paare aus dem echten Text ab (1 bis 4, sauber verschachtelt) statt "genau 2+2" anzunehmen, meldet vorhandene Marker vorab klar, audit relativ; `tools/overlay_diagnose.py`
(alles in einem Lauf: Overlay-Integritaet, echte OEM-Dateien/-Header als Artefakt, ALLE fehlgeschlagenen Anker, Namensabgleich gegen den echten Quelltext); `ci/SV04NextSymbolProbe.cpp`; `ci/7.yml`;
Bruecke ohne `celsius_t` (erst ab Marlin 2.0.9). Kein Marlin-Overlay-Build bisher, kein Hardwaretest.
Fortschritt laut Katalog: 16,85 von 100, unveraendert gegenueber Stand 13 (kein neues Kriterium belegt; der naechste Zuwachs haengt am gruenen Overlay-Build).
