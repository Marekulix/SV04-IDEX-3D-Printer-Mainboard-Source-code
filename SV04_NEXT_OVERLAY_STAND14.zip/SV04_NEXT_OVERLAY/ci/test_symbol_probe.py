"""Syntaxpruefung der Symbol-Probe gegen eine MOCK-Struktur. Belegt NUR, dass die Probe selbst fehlerfrei ist, NICHT, dass Marlin die Namen besitzt (das tut der CI-Build)."""
import subprocess, tempfile, textwrap
from pathlib import Path
HERE = Path(__file__).resolve().parent
d = Path(tempfile.mkdtemp()); S = d / 'Marlin/src'
def w(rel, txt): p = S / rel; p.parent.mkdir(parents=True, exist_ok=True); p.write_text(textwrap.dedent(txt))
w('inc/MarlinConfig.h', """#pragma once
#include <stdint.h>
#include <math.h>
#define ENABLED(x) (x)
#define DISABLED(x) (!(x))
#define DUAL_X_CARRIAGE 1
#define AUTO_BED_LEVELING_BILINEAR 1
#define PROBE_MANUALLY 0
#define RTS_AVAILABLE 1
#define PSTR(s) s
#define PIN_EXISTS(p) (defined(p##_PIN))
typedef int celsius_t;
#define X_AXIS 0
#define Y_AXIS 1
#define Z_AXIS 2
#define GRID_MAX_POINTS_X 4
#define GRID_MAX_POINTS_Y 4
#define DXC_AUTO_PARK_MODE 1
#define X2_MAX_POS 362.0f
#define AUTO_BED_LEVEL_1POINT_VP 1000
#define AUTO_BED_LEVEL_ICON_VP 900
#define X_MAX_PIN 5
#define X_MAX_ENDSTOP_INVERTING false
inline bool READ_(int){return false;}
#define READ(p) READ_(p)
struct xy_pos_t{float x,y;}; struct xy_float_t{float x,y;};
struct Parser{ bool seen_test(char); }; extern Parser parser;
#define SERIAL_ECHOLNPGM(s) (void)(s)
#define SERIAL_ERROR_MSG(s) (void)(s)
#define ABS(x) fabsf(x)
""")
w('MarlinCore.h', 'inline bool IsStopped(){return false;} inline bool printJobOngoing(){return false;} inline bool printingIsPaused(){return false;} uint32_t millis();\n')
w('module/temperature.h', 'struct T{ void setTargetBed(float){} float degBed(){return 0;} int degTargetBed(){return 0;} }; extern T thermalManager;\n')
w('module/planner.h', 'struct P{ bool has_blocks_queued(){return false;} bool leveling_active; }; extern P planner;\n')
w('module/motion.h', 'extern int active_extruder, dual_x_carriage_mode; extern float inactive_extruder_x; bool axis_is_trusted(int);\n')
w('module/probe.h', 'struct O{float z;}; struct Pr{O offset;}; extern Pr probe;\n')
w('gcode/queue.h', 'struct Q{ bool enqueue_one_P(const char*); bool has_commands_queued(); }; extern Q queue;\n')
w('gcode/gcode.h', '\n')
w('feature/bedlevel/bedlevel.h', 'struct XY{float x,y;}; extern float z_values[4][4]; extern XY bilinear_start, bilinear_grid_spacing; void refresh_bed_level(); void set_bed_leveling_enabled(bool);\n')
w('lcd/e3v2/creality/LCD_RTS.h', 'struct R{ void RTS_SndData(float,int); }; extern R rtscheck; void RTS_AutoBedLevelPage();\n')
dst = S / 'feature/sv04_next'; dst.mkdir(parents=True, exist_ok=True); (dst / 'probe.cpp').write_text((HERE / 'SV04NextSymbolProbe.cpp').read_text())
n = 0
for std in ('gnu++11', 'gnu++14', 'gnu++17'):
    r = subprocess.run(['g++', f'-std={std}', '-fsyntax-only', '-Wall', '-Wextra', '-Wno-pedantic', 'probe.cpp'], cwd=dst, capture_output=True, text=True)
    assert r.returncode == 0, r.stderr[-400:]; assert sum('SV04PROBE' in l for l in r.stderr.splitlines()) >= 12, 'Konfig-Meldungen fehlen'; n += 1
# fehlendes Symbol muss gemeldet werden (die Probe darf nicht still durchlaufen)
(S / 'module/temperature.h').write_text('struct T{ float degBed(){return 0;} int degTargetBed(){return 0;} }; extern T thermalManager;\n')
r = subprocess.run(['g++', '-std=gnu++14', '-fsyntax-only', 'probe.cpp'], cwd=dst, capture_output=True, text=True); assert r.returncode != 0 and 'setTargetBed' in r.stderr; n += 1
(S / 'module/planner.h').unlink(); r = subprocess.run(['g++', '-std=gnu++14', '-fsyntax-only', 'probe.cpp'], cwd=dst, capture_output=True, text=True); assert r.returncode != 0 and 'SV04PROBE: fehlt src/module/planner.h' in r.stderr; n += 1
print(f'PASS Symbol-Probe: {n} Pruefungen (3 Standards, fehlendes Symbol und fehlender Header werden gemeldet); MOCK-Marlin, nicht der echte Quelltext')
