import unittest,importlib.util,os,json,pathlib
path=pathlib.Path(__file__).resolve().parents[1]/'tools'/'audit112.py'
spec=importlib.util.spec_from_file_location('audit112',path);a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
class Tests112(unittest.TestCase):
 def test_01_order_count(self):self.assertEqual(len(a.order()),16)
 def test_02_order_unique(self):self.assertEqual(len(set(a.order())),16)
 def test_03_zigzag_first(self):self.assertEqual(a.order()[:4],[(3,0),(2,0),(1,0),(0,0)])
 def test_04_zigzag_second(self):self.assertEqual(a.order()[4:8],[(0,1),(1,1),(2,1),(3,1)])
 def test_05_zigzag_third(self):self.assertEqual(a.order()[8:12],[(3,2),(2,2),(1,2),(0,2)])
 def test_06_zigzag_fourth(self):self.assertEqual(a.order()[12:],[(0,3),(1,3),(2,3),(3,3)])
 def test_07_frames_16(self):self.assertEqual(len(list(a.frames([[0]*4 for _ in range(4)]))),16)
 def test_08_frames_distinct_vps(self):self.assertEqual(len({z['vp'] for z in a.frames([[0]*4 for _ in range(4)])}),16)
 def test_09_first_frame(self):self.assertEqual(next(a.frames([[0]*4 for _ in range(4)]))['frame_hex'],'5aa5058211000000')
 def test_10_last_vp(self):self.assertEqual(list(a.frames([[0]*4 for _ in range(4)]))[-1]['vp'],'0x111E')
 def test_11_positive_scale(self):self.assertEqual(next(a.frames([[0,0,0,.123]]*4))['frame_hex'],'5aa505821100007b')
 def test_12_negative_frame(self):self.assertEqual(next(a.frames([[0,0,0,-.123]]*4))['frame_hex'],'5aa505821100ff85')
 def test_13_no_extra_oem_source(self):self.assertNotEqual(a.order()[0],(0,0))
 def test_14_one_word_negative(self):self.assertEqual(len(bytes.fromhex(next(a.frames([[0,0,0,-1]]*4))['frame_hex'])),8)
 def test_15_all_indices_in_range(self):self.assertTrue(all(0<=x<4 and 0<=y<4 for x,y in a.order()))
 def test_16_rows_4_each(self):self.assertEqual([sum(y==r for x,y in a.order()) for r in range(4)],[4]*4)
 def test_17_vp_endpoints(self):
  q=list(a.frames([[0]*4 for _ in range(4)]));self.assertEqual((q[0]['vp'],q[-1]['vp']),('0x1100','0x111E'))
 def test_18_marlin_guard_rejects_empty(self):
  with self.assertRaises(AssertionError):a.check_marlin('','')
 def test_19_marlin_guard_accepts_source_fixture(self):
  h='#define AUTO_BED_LEVEL_1POINT_VP 0x1100\n 0x110E,\n'
  c=('AUTO_BED_LEVEL_1POINT_VP + showcount * 2; z_values[x][y] * 1000; zig ^= true;\n')*2+'databuf[3] = snddat.command; databuf[4] = snddat.addr >> 8; snddat.data[0] = n >> 16; snddat.len = 7;'
  self.assertEqual(a.check_marlin(h,c)['oem_mesh_sender_occurrences'],2)
 def test_20_guard_rejects_changed_vp(self):
  with self.assertRaises(AssertionError):a.check_marlin('#define AUTO_BED_LEVEL_1POINT_VP 0x2200','')
 def test_21_zero_packet(self):self.assertTrue(next(a.frames([[0]*4 for _ in range(4)]))['frame_hex'].endswith('0000'))
 def test_22_decimal_truncation(self):self.assertEqual(next(a.frames([[0,0,0,.0009]]*4))['frame_hex'],'5aa5058211000000')
if __name__=='__main__':unittest.main()
