#!/usr/bin/env python3
"""Check pinned OEM Marlin -> DGUS data contract; simulate, never flash."""
import argparse,json,re,struct,hashlib
from pathlib import Path
from PIL import Image,ImageDraw
BASE=0x1100

def order():
    return [(x,y) for y in range(4) for x in (range(3,-1,-1) if y%2==0 else range(4))]

def frames(values):
    for i,(x,y) in enumerate(order()):
        vp=BASE+2*i
        n=int(values[y][x]*1000) # C++ truncation towards zero
        raw=struct.pack('>I',n & 0xffffffff) if n>65535 else struct.pack('>H',n & 65535)  # OEM signed int comparison: negatives use one 16-bit word
        yield {'point':i+1,'vp':f'0x{vp:04X}','grid_x':x,'grid_y':y,'value_mm':values[y][x],
               'frame_hex':(bytes([0x5a,0xa5,3+len(raw),0x82,vp>>8,vp&255])+raw).hex()}

def check_marlin(header,cpp):
    assert re.search(r'^\s*#define\s+AUTO_BED_LEVEL_1POINT_VP\s+0x1100\b',header,re.M)
    assert re.search(r'0[xX]110[Ee]\s*,',header), 'OEM 0x110E input mapping not found'
    assert cpp.count('AUTO_BED_LEVEL_1POINT_VP + showcount * 2') >= 2
    assert cpp.count('z_values[x][y] * 1000') >= 2
    assert cpp.count('zig ^= true') >= 2
    assert 'databuf[3] = snddat.command' in cpp and 'databuf[4] = snddat.addr >> 8' in cpp
    assert 'snddat.data[0] = n >> 16' in cpp and 'snddat.len = 7' in cpp
    return {'oem_mesh_sender_occurrences':cpp.count('AUTO_BED_LEVEL_1POINT_VP + showcount * 2'),
            'header_sha256':hashlib.sha256(header.encode()).hexdigest(),
            'cpp_sha256':hashlib.sha256(cpp.encode()).hexdigest()}

def check_display(templates,candidate):
    arr=templates['objects'];assert len(arr)==16
    show=(candidate/'14ShowFile.bin').read_bytes();touch=(candidate/'13TouchFile.bin').read_bytes()
    assert show[:8]==b'\x14DGUS_2\x10' and len(show)==23712 and len(touch)==7298
    expected=b''.join(bytes.fromhex(r['record_hex']) for r in arr)
    assert show[0x5a80:0x5c80]==expected
    assert touch[-34:-2]==bytes.fromhex('001600ac019100fa01c8003bff00ff00003b00150192007c01c70001ff00ff00')
    for i,item in enumerate(arr):
        row=bytes.fromhex(item['record_hex'])
        assert row[6:8]==(BASE+2*i).to_bytes(2,'big')
        assert [int.from_bytes(row[8:10],'big'),int.from_bytes(row[10:12],'big')]==item['desired_xy']
        assert 0<=item['desired_xy'][0]<272 and 0<=item['desired_xy'][1]<480

def preview(art,out,values):
    im=Image.open(art).convert('RGB');assert im.size==(272,480)
    d=ImageDraw.Draw(im)
    for y in range(4):
        for x in range(4):
            z=values[y][x];a,b=20+59*x,193+49*y
            col=(245,137,139) if z<-.1 else ((255,179,105) if z>.2 else (108,210,171))
            d.rounded_rectangle((a,b,a+53,b+42),radius=4,outline=col,width=2)
            d.text((a+4,b+25),f'{z:+.3f}',fill=col)
    d.rectangle((7,129,266,158),fill=(35,12,20))
    d.text((12,138),'SIMULATION - NICHT LIVE',fill=(255,210,170))
    im.save(out)

def main():
    p=argparse.ArgumentParser()
    for n in ['h','cpp','templates','art','candidate','out']:p.add_argument('--'+n,required=True,type=Path)
    a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    con=check_marlin(a.h.read_text(),a.cpp.read_text())
    check_display(json.loads(a.templates.read_text()),a.candidate)
    vals=[[-.225,-.08,.025,.16],[-.125,-.01,.055,.21],[-.19,-.045,.09,.28],[-.15,-.035,.12,.31]]
    data=list(frames(vals));assert len(data)==16
    preview(a.art,a.out/'112_SIMULATION_ONLY.png',vals)
    con.update({'vp_range':'0x1100..0x111E','oem_zigzag':True,'oem_output_multiplier':1000,
                'records':16,'navigation_controls':2,'shared_address':'0x110E both numeric mesh VP and OEM incoming ChangePageKey',
                'page59_refresh_risk':'No automatic refresh when opening new page; display can contain stale mesh values',
                'signed_values':'OEM int overload transmits negative values as 16-bit two-complement; DGUS signed display not hardware-verified',
                'dynamic_colors':'NOT implemented: image is a visual simulation only',
                'install_release':False})
    (a.out/'112_OEM_DGUS_CONTRACT.json').write_text(json.dumps(con,indent=2)+'\n')
    (a.out/'112_SERIAL_16_SAMPLE_FRAMES.json').write_text(json.dumps(data,indent=2)+'\n')
    print('112 AUDIT PASS: 16 mesh VP bindings, 16 simulation packets, OEM source checks')
    print(json.dumps(con,indent=2))
if __name__=='__main__':main()
