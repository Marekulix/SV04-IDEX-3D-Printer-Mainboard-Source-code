# SV04 NEXT 112 – DWIN-Punkt 2 – großer Integrations-/Protokolltest

**NICHT INSTALLIEREN.** Dieses Paket erweitert den erfolgreichen GitHub-Stand 111.

Neu gegenüber 111:
1. Quellcodeprüfung des fest gepinnten Sovol-Marlin `1867fcba75354a5c65e0631d6972dd19f1bd6cbe`: ursprüngliche Mesh-Basisadresse, 2 Übertragungsstellen, Zigzag-Reihenfolge, mm x 1000, DGUS-Seriellencoder.
2. Unabhängige Prüfung aller 16 DGUS-Anzeigeobjekte gegen tatsächlich erzeugte 14ShowFile.bin.
3. Beide Navigations-Touchobjekte in tatsächlich erzeugter 13TouchFile.bin prüfen.
4. 16 synthetische serielle Datentelegramme, positive und negative Werte: ein 16-Bit-Wort bei normalen Meshwerten; zwei Worte nur bei positiven Werten über 65535, Zickzack-Zuordnung.
5. 272x480-Vorschaugrafik mit Testwerten und farbiger Einordnung, ausdrücklich nur Simulation.
6. OEM-Adressenprüfung: 0x110E ist bereits in Marlin eingehendes ChangePageKey und die achte numerische Meshadresse. Diese Doppelbelegung NICHT durch ungetestete VP-Umnummerierung umgehen.
7. Neue und bisherige Tests gemeinsam in GitHub, Belege mit Original-SHA-Hashes.

Nachweisgrenzen:
- Dynamische Farbänderung auf dem echten DGUS-Display ist NICHT implementiert.
- Stand 112 bietet keinen neuen Firmwarebefehl, der beim Aufruf von Seite 59 automatisch aktuelle Meshwerte holt. Werte könnten leer/veraltet sein.
- Negative Zahlen könnten hardwareabhängig angezeigt werden; Darstellung nicht real getestet.
- Keine DGUS-Compiler- oder Display-Hardwarebestätigung.
- Keine Freigabe zum Flashen.

Die zwei GitHub-Dateien heißen exakt **112_A.zip** (Repository-Wurzel) und **112_B.yml** (nach `.github/workflows/`). Der Workflow sucht exakt 112_A.zip, kein Umbenennen.

Artifakte nach GitHub Actions: `sv04next112-dwin-evidence` und `sv04next112-dwin-experimental-NOT-FOR-INSTALL`.
