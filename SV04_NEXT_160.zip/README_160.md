# SV04 NEXT 160 - komplette GitHub-Prüfung (nur Entwicklungsnachweise)

- Neue Nummer 160; keine vorhandenen Dateien ändern oder löschen.
- `160.yml` nach `.github/workflows/` und `SV04_NEXT_160.zip` ins Root-Verzeichnis hochladen.
- Workflow läuft bei Push automatisch oder per `workflow_dispatch`.
- Erwartete vorhandene Pakete: `SV04_NEXT_159.zip`, `SV04_NEXT_92.zip`, `112_A.zip`.
- Prüft: Hash/ZIP-Integrität, die Auto60-Hostsuite aus 159, Marlin 92 STM32 Cross-Build, DWIN-112-Archiv, Quell-Audit, sicherheitskritische Grenzen und Gesamtreport.
- Diese Prüfrunde integriert Auto60 157 NICHT automatisch in Marlin 92. GitHub liefert weder reale T1-Kollisionserkennung noch BLTouch-, Heizungs-, DWIN- oder EEPROM-Hardwaretests. Diese bleiben ausdrücklich NOT_VERIFIED.
- Firmware/Display NICHT FLASHEN oder auf Drucker installieren.
