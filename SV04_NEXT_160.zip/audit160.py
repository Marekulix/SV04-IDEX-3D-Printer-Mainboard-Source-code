#!/usr/bin/env python3
"""SV04 NEXT 160: read-only evidence and integration coverage report."""
import argparse,hashlib,json,pathlib,sys,zipfile

def sha(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()

def main():
 p=argparse.ArgumentParser()
 p.add_argument('--root',default='.')
 p.add_argument('--out',default='audit160')
 a=p.parse_args(); root=pathlib.Path(a.root); out=pathlib.Path(a.out);out.mkdir(parents=True,exist_ok=True)
 observations=[]
 def put(name,status,evidence): observations.append({'check':name,'status':status,'evidence':evidence})
 for fn in ['SV04_NEXT_159.zip','SV04_NEXT_92.zip','112_A.zip']:
  path=root/fn
  if not path.is_file():put('archive '+fn,'MISSING','not present in checkout');continue
  try:
   with zipfile.ZipFile(path) as z:
    corrupted=z.testzip();names=z.namelist()
    put('archive '+fn,'PASS' if corrupted is None else 'FAIL',f'{len(names)} entries; SHA256={sha(path)}; corrupt={corrupted}')
    if fn=='SV04_NEXT_159.zip':
     tests=[n for n in names if n.endswith('audit_all_157.py')]
     put('Auto60 host audit runner', 'PASS' if len(tests)==1 else 'FAIL',str(tests))
    if fn=='112_A.zip':
     put('DWIN firmware compatibility','NOT_VERIFIED','ZIP integrity cannot prove live HMI touch addressing, EEPROM or wiring')
  except Exception as e:put('archive '+fn,'FAIL',str(e))
 # These are not verifiable in GitHub without instrumented device and integration source.
 for title,reason in [
 ('Auto60 to production Marlin wiring','Marlin92 build and Auto60 157 host suite are distinct, not proven linked'),
 ('DWIN touch navigation','device VP and display page mapping require verified original assets and device testing'),
 ('Thermal sensor and heater sequence','hardware sensor/heat behavior cannot be verified with CI'),
 ('T0/T1 mechanical collision prevention','position loss and real IDEX hardware require physical tests'),
 ('BLTouch 16 point mesh','servo/probe travel and grid geometry require device tests'),
 ('EEPROM atomic commit/rollback','mock tests do not prove real EEPROM persistence and power-loss recovery'),
 ('SD card and recovery interactions','mock tests do not prove real media and power-cut safety'),
 ('Firmware flashing approval','no hardware acceptance and no validated deployable combined binary')]:
  put(title,'NOT_VERIFIED',reason)
 data={'version':160,'policy':'READ_ONLY_NO_FLASH','checks':observations,'counts':{s:sum(x['status']==s for x in observations) for s in ('PASS','FAIL','MISSING','NOT_VERIFIED')},'flash_approved':False}
 (out/'REPORT_160.json').write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
 lines=['# SV04 NEXT 160 - umfassender CI-Nachweis','', '**KEINE FLASHFREIGABE.** GitHub kann die Hardware nicht testen.','', '| Bereich | Status | Nachweis |','|---|---|---|']
 for x in observations:lines.append('| '+x['check']+' | '+x['status']+' | '+x['evidence'].replace('|','/')+' |')
 (out/'REPORT_160.md').write_text('\n'.join(lines)+'\n')
 print(json.dumps(data['counts'],ensure_ascii=False))
 if data['counts']['FAIL'] or data['counts']['MISSING']:sys.exit(1)
if __name__=='__main__':main()
