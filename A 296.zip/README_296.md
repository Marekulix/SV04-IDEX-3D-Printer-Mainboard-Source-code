# SV04 NEXT 296 – Fix für fehlgeschlagenen Run 295

Run 295 scheiterte vor dem STM32-Build an `apply_eeprom_policy_292.py`:
`Anchor is missing or ambiguous: #define SV04_CLAUDE_EEPROM_REQUIRE_JOURNAL 0`.

Die tatsächlich integrierte Auto60-Datei hat zwei Leerzeichen vor `#define`. Der ursprüngliche Patch verlangte den Text ohne Einrückung. Version 296 korrigiert ausschließlich diese Einrückung in der bekannten Quelltextverankerung. Fehlende, fremd veränderte oder mehrfach vorhandene Textstellen werden weiterhin abgelehnt. Alle Firmwarefunktionen und ihre Logik bleiben wie in Version 294.

Der neue Regressionstest wendet die Patches 292 und 293 auf die gesicherte Auto60-Basisdatei 285 an, prüft die aktivierte Journalpflicht und die Idempotenz beider Patches.

Lokale Tests: Regression 296 PASS; Patchkette 293 10/10; 294 4/4. Der STM32-Gesamtbuild von 296 ist noch nicht erfolgt. Keine Flashfreigabe.

GitHub: `296.yml` nach `.github/workflows/`, `SV04_NEXT_296.zip` ins Repository-Hauptverzeichnis. Die Workflowdatei setzt die bereits im Repository vorhandenen Archive 287, 289, 291 und 294 voraus.
