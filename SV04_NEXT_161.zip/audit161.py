#!/usr/bin/env python3
"""Static regression gates, prevents accidental misrepresentation of 161 as released."""
import pathlib,sys,json
root=pathlib.Path(__file__).resolve().parent;h=(root/'SV04NextAuto60Gate161.hpp').read_text();p=(root/'stage161.py').read_text()
for marker in ['static constexpr bool heat_enabled = false','static constexpr bool motion_enabled = false','static constexpr bool eeprom_write_enabled = false','static constexpr bool hmi_touch_enabled = false','static constexpr bool flash_approved = false','return false;']:
 assert marker in h, marker
for marker in ['SV04NextUnified79.hpp','SV04NextAuto60Gate161.hpp','read_only' if False else 'no G28/G29 start connection']:
 assert marker in p,marker
for forbidden in ['queue.inject','settings.save(','G29()','thermalManager.setTargetBed(','G28();']:
 assert forbidden not in h, forbidden
print('GATE161 PASS: no actuation/EEPROM/touch release; staged compile only')
