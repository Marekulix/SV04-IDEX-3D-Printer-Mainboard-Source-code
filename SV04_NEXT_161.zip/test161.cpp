#include "SV04NextAuto60Gate161.hpp"
#include <cassert>
int main() {
  sv04::Guards g;
  sv04::PersistenceInterlocks141 p;
  assert(!sv04next161::auto60_start_authorized(g));
  assert(!sv04next161::dispatch_dwin_touch(59,0));
  assert(!sv04next161::permit_eeprom_commit(p));
  assert(!sv04next161::heat_enabled && !sv04next161::motion_enabled);
  assert(!sv04next161::flash_approved);
  sv04::Controller c;
  assert(c.phase()==sv04::Phase::Idle);
}
