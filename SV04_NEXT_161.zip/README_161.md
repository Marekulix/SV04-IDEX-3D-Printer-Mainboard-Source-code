# SV04 NEXT 161 – Combined source compilation gate (NOT FOR INSTALL)

This stage links the **stand 157 Auto60 safety/EEPROM/SD model headers into the same Marlin82 LCD compilation unit** using `SV04NextAuto60Gate161.hpp` and a source-only integration script. It fixes one real C++11 incompatibility of the host-only source: `HomingPermit` requires an explicit constructor for the Marlin C++11 toolchain. Source changes relative to 157 are limited to that constructor plus the new 161 files.

The integration is **deliberately non-operational**: touch mapping, G28/G29 routing, motion, heat, and EEPROM writing stay disabled. It does not claim a complete or flashable firmware. CI builds the combined STM32 target to detect integration errors and runs all 29 earlier host tests plus security gates. Any missing board-level integration remains a release blocker.

Five tasks: (1) source integration/combined build attempted by GitHub; (2) touch-to-command chain blocked pending verified OEM asset mapping; (3) EEPROM write/readback blocked pending independent device backend/rollback; (4) host-only IDEX+BLTouch validation and negative guard tests; (5) full 29-test regression plus STM32 CI rebuild. **No hardware test is possible in GitHub.**

Never copy a resulting firmware image to the printer. NO FLASH APPROVAL.
