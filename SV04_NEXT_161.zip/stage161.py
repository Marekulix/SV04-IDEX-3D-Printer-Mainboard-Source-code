#!/usr/bin/env python3
"""Stage 157 host modules in a pinned, ALREADY-integrated Marlin82 tree; no flash authorization."""
import argparse,hashlib,json,pathlib,shutil
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--auto60',required=True);p.add_argument('--bundle',required=True);p.add_argument('--out',required=True);a=p.parse_args()
root=pathlib.Path(a.root);auto=pathlib.Path(a.auto60);bundle=pathlib.Path(a.bundle);out=pathlib.Path(a.out);out.mkdir(parents=True,exist_ok=True)
feature=root/'Marlin/src/feature';lcd=root/'Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp'
assert feature.is_dir() and lcd.is_file() and (feature/'SV04NextUnified79.hpp').exists(), 'Marlin82 source not present'
text=lcd.read_text(); anchor='#include "../../../feature/SV04NextUnified79.hpp"'
assert text.count(anchor)==1,'LCD integration anchor mismatch'
assert 'SV04NextAuto60Gate161.hpp' not in text,'161 already applied'
# Source headers are copied into firmware only for compilation. No runtime callbacks installed.
headers=sorted(auto.glob('*.h'));assert len(headers)>=20,len(headers)
dest=feature/'sv04_auto60_161';assert not dest.exists(),'existing source namespace would be overwritten'
dest.mkdir()
for x in headers: shutil.copy2(x,dest/x.name)
shutil.copy2(bundle/'SV04NextAuto60Gate161.hpp',feature/'SV04NextAuto60Gate161.hpp')
lcd.write_text(text.replace(anchor,anchor+'\n#include "../../../feature/SV04NextAuto60Gate161.hpp"',1))
files=[feature/'SV04NextAuto60Gate161.hpp',lcd]+sorted(dest.glob('*.h'))
report={'version':161,'scope':'READ_ONLY_COMPILE_LINKED_NO_ACTUATORS','files':[{'name':str(f.relative_to(root)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files], 'release_allowed':False,'real_touch_mapping_verified':False,'eeprom_write_path_enabled':False,'flash_approved':False,'limitations':['no G28/G29 start connection','no proven real DWIN VP mapping','no EEPROM independent decoder','no hardware tests']}
(out/'integration161.json').write_text(json.dumps(report,indent=2)+'\n')
print('STAGE161 PASS: additional source headers and LCD inclusion, no actuation')
