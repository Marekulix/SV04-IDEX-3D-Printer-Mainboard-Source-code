#pragma once
// SV04 NEXT 161: compile-linked Auto60 157 models; all physical actions DISABLED.
// DO NOT FLASH. No HMI address, actuator, mesh writer or EEPROM writer authorized.
#if defined(SV04_NEXT_AUTO60_RELEASE) || defined(SV04_NEXT_DWIN_TOUCH_RELEASE) || defined(SV04_NEXT_T1_MOTION_RELEASE) || defined(SV04_NEXT_EEPROM_RELEASE) || defined(SV04_NEXT_FLASH_RELEASE)
#error "SV04 NEXT 161: unauthorized release flag"
#endif
#include "sv04_auto60_161/auto60_eeprom141.h"
#include "sv04_auto60_161/sd_guarded_slice157.h"
namespace sv04next161 {
static constexpr bool hmi_touch_enabled = false;
static constexpr bool heat_enabled = false;
static constexpr bool motion_enabled = false;
static constexpr bool eeprom_write_enabled = false;
static constexpr bool flash_approved = false;
static constexpr bool verified_device_touch_mapping = false;
static_assert(!hmi_touch_enabled && !heat_enabled && !motion_enabled && !eeprom_write_enabled && !flash_approved, "fail closed");
// A deliberate compilation boundary, not an actuator path. Refuses ANY start request.
inline bool auto60_start_authorized(const sv04::Guards&) { return false; }
inline bool dispatch_dwin_touch(unsigned, unsigned) { return false; }
inline bool permit_eeprom_commit(const sv04::PersistenceInterlocks141&) { return false; }
}
