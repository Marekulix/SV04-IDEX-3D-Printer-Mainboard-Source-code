#pragma once
#include "auto60_controller.h"
#include "idex_homing_gate.h"
namespace sv04 {
// Host-side gate for the point at which the controller requests a G28.
// Return values are PERMISSIONS only; nothing here queues G-code or moves a motor.
struct HomingPermit {
  GateReason reason = GateReason::NotIdle;
  bool allowed = false;
  HomingPermit() = default;
  HomingPermit(GateReason r, bool ok) : reason(r), allowed(ok) {}
};
inline HomingPermit permit_home(const Controller &controller, const IDEXInputs &live) {
  if (controller.phase() != Phase::Home || controller.pending() != Action::HomeSafely)
    return { GateReason::HomeNotConfirmed, false };
  const auto r = preflight(live);
  return {r, r == GateReason::Ready};
}
// Call only after command executor confirms G28 has completed and axes are trusted.
inline bool accept_home_completion(Controller &controller, const HomingResult &result, uint32_t ms) {
  if (controller.phase() != Phase::Home || controller.pending() != Action::HomeSafely) return false;
  const bool good = verify_homing(result) == GateReason::Ready;
  controller.ack(Action::HomeSafely, good, ms);
  return good;
}
} // namespace sv04

// 138: G28 initial homing path where T1 X will first be homed by the OEM code.
// Does not rely on T1's last reported X position as proof of prior parking.
#include "idex_park_evidence.h"
namespace sv04 {
inline HomingPermit permit_initial_home(const Controller& c, const IDEXInputs& live) {
  if (c.phase()!=Phase::Home || c.pending()!=Action::HomeSafely)
    return {GateReason::HomeNotConfirmed,false};
  const auto r=initial_g28_preflight(live);
  return {r,r==GateReason::Ready};
}
inline bool accept_initial_home_completion(Controller& c, ParkEvidence& evidence,
                                           const HomingResult& h, const ParkObservation& o,
                                           uint32_t ms) {
  if (c.phase()!=Phase::Home || c.pending()!=Action::HomeSafely) return false;
  const bool good=post_g28_safe(h,evidence,o);
  c.ack(Action::HomeSafely,good,ms);
  return good;
}
} // namespace sv04
