#include "SV04NextProbe163.hpp"
// A deliberately dormant, retained ELF symbol for verifying inclusion into STM32 firmware.
// The symbol is never called by the LCD parser and grants no hardware functionality.
extern "C" __attribute__((used,noinline)) unsigned sv04_next_163_link_probe(const unsigned command, const unsigned vp, const unsigned value) {
  const sv04next163::State s = sv04next163::submit(sv04next163::initial(),
      static_cast<uint8_t>(command), static_cast<uint16_t>(vp), static_cast<uint16_t>(value));
  return (s.phase == sv04next163::Phase::Rejected ? 1u : 0u) + static_cast<unsigned>(s.denied);
}
