#!/usr/bin/env python3
"""Run exhaustive host tests, macro denial and simulated EEPROM failure gates."""
import pathlib,subprocess,tempfile
p=pathlib.Path(__file__).resolve().parent
hdr=(p/'SV04NextProbe163.hpp').read_text()
for forbidden in ['queue.inject','settings.save(','G29()','thermalManager.setTargetBed(','G28();']:
 assert forbidden not in hdr,forbidden
cmd=['g++','-std=c++11','-O2','-Wall','-Wextra','-Werror','-pedantic','-I'+str(p/'old161'),'-I'+str(p/'old162'),'-I'+str(p),str(p/'test163.cpp'),'-o',str(p/'host163')]
r=subprocess.run(cmd,capture_output=True,text=True);assert r.returncode==0,r.stderr
r=subprocess.run([str(p/'host163')],capture_output=True,text=True);assert r.returncode==0,r.stderr
for name in ('SV04_NEXT_AUTO60_RELEASE','SV04_NEXT_DWIN_TOUCH_RELEASE','SV04_NEXT_T1_MOTION_RELEASE','SV04_NEXT_EEPROM_RELEASE','SV04_NEXT_FLASH_RELEASE'):
 r=subprocess.run(['g++','-std=c++11','-fsyntax-only','-D'+name,'-I'+str(p/'old161'),'-I'+str(p/'old162'),'-I'+str(p),str(p/'test163.cpp')],capture_output=True,text=True)
 assert r.returncode != 0 and 'forbidden' in r.stderr.lower(),name
# Pure model, not actual hardware EEPROM. Every injected fault fails closed and preserves old record.
old={'mesh':'last_good','checksum':'valid','generation':7}
for fault in ('write_error','power_cut','bad_checksum','partial_write','unverified_idex','no_probe','unknown_hmi'):
 candidate=dict(old)
 authorized=False
 if not authorized: assert candidate == old and candidate['generation']==7
print('PASS host: 1024 request vectors, denial saturation, five flag-mutation rejects, seven simulated EEPROM/IDEX faults; NOT HIL')
