#pragma once
// SV04 NEXT 163: dormant link-evidence entry point. NEVER used for machine control.
// Compile/link presence is NOT evidence of a real UI->Auto60 execution path.
#if defined(SV04_NEXT_AUTO60_RELEASE) || defined(SV04_NEXT_DWIN_TOUCH_RELEASE) || defined(SV04_NEXT_T1_MOTION_RELEASE) || defined(SV04_NEXT_EEPROM_RELEASE) || defined(SV04_NEXT_FLASH_RELEASE)
#error "SV04 NEXT 163: activation forbidden"
#endif
#include <stdint.h>
#include "SV04NextDiagnostics162.hpp"
namespace sv04next163 {
enum class Phase : uint8_t { Locked=0, Rejected=1 };
struct State { Phase phase; uint16_t denied; };
inline State initial() { return {Phase::Locked,0}; }
inline State submit(State s, uint8_t request, uint16_t vp, uint16_t value) {
  // No actuation is permitted. This is intentionally NOT an Auto60 command bridge.
  const sv04next162::Decision d = sv04next162::request(static_cast<sv04next162::Request>(request),vp,value);
  if (d.allowed && request == 0) return s; // diagnostic Query only
  if (s.denied != UINT16_MAX) ++s.denied;
  s.phase=Phase::Rejected;
  return s;
}
inline bool can_start(const State&) { return false; }
inline bool can_heat(const State&) { return false; }
inline bool can_move(const State&) { return false; }
inline bool can_store(const State&) { return false; }
static_assert(!sv04next161::heat_enabled && !sv04next161::motion_enabled && !sv04next161::eeprom_write_enabled,
              "unsafe 161 activation");
}
