#include <cassert>
#include <stdint.h>
#include "SV04NextProbe163.hpp"
int main() {
  sv04next163::State s=sv04next163::initial();
  for(unsigned v=0;v<256;++v) {
    for(unsigned k=0;k<4;++k) {
      s=sv04next163::submit(s,static_cast<uint8_t>(v),static_cast<uint16_t>(k*16383u),0xFFFF);
      assert(!sv04next163::can_start(s));
      assert(!sv04next163::can_heat(s));
      assert(!sv04next163::can_move(s));
      assert(!sv04next163::can_store(s));
      if(v != 0) assert(s.phase==sv04next163::Phase::Rejected);
    }
  }
  assert(s.denied==1020);
  assert(s.phase==sv04next163::Phase::Rejected);
  for(unsigned i=0;i<65536;i++) s=sv04next163::submit(s,1,123,4);
  assert(s.denied==UINT16_MAX);
  return 0;
}
