# SV04 NEXT 163: DORMANT ELF LINK-EVIDENCE + FAIL-CLOSED HOST GATES
DO NOT FLASH. No automatic bed leveling, heating, real motion or EEPROM writes are enabled.

This package does NOT invent DWIN addresses. It stages after 161 and 162, adds a retained `sv04_next_163_link_probe` symbol in the real OEM LCD translation unit, tests the denied command state model, and directs CI to inspect the linked ELF via `nm`. A retained symbol demonstrates only compilation/link inclusion, **not real UI reachability**. `stage163.py` deliberately refuses duplicate files. Any real touch-to-actor mapping needs separately proven OEM resources and printer HIL clearance.

Prerequisites on GitHub: original immutable 92, 159, 161, 162 archives plus `112_A.zip` and this 163 package. GitHub workflow separately reports verified coverage and unverified physical blockers. No binary is uploaded for flashing.
