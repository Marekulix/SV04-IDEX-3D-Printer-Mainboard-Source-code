#!/usr/bin/env python3
"""Stage AFTER 161+162, no existing file overwritten; inert probe in LCD translation unit."""
import argparse,hashlib,json,pathlib,shutil
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--bundle',required=True);p.add_argument('--out',required=True);a=p.parse_args()
root=pathlib.Path(a.root); bundle=pathlib.Path(a.bundle);out=pathlib.Path(a.out);out.mkdir(parents=True,exist_ok=True)
feature=root/'Marlin/src/feature';lcd=root/'Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp';src=lcd.read_text()
anchor='#include "../../../feature/SV04NextDiagnostics162.hpp"'
assert src.count(anchor)==1, '162 dependency not present uniquely'
assert 'SV04NextProbe163.hpp' not in src and 'sv04_next_163_link_probe' not in src,'163 already staged'
assert not (feature/'SV04NextProbe163.hpp').exists(), 'refuse overwrite'
shutil.copy2(bundle/'SV04NextProbe163.hpp',feature/'SV04NextProbe163.hpp')
probe=(bundle/'probe163.cpp').read_text()
assert 'extern "C" __attribute__((used,noinline)) unsigned sv04_next_163_link_probe' in probe
src=src.replace(anchor,anchor+'\n#include "../../../feature/SV04NextProbe163.hpp"',1)
# The function is defined inside the existing LCD compile unit, not compiled as an orphan .cpp file.
lcd.write_text(src+'\n// SV04 NEXT 163 dormant ELF presence probe; not a UI callback.\n'+probe.replace('#include "SV04NextProbe163.hpp"','')+'\n')
assert lcd.read_text().count('sv04_next_163_link_probe')==1
assert lcd.read_text().count('SV04NextProbe163.hpp')==1
r={'version':163,'dormant_link_probe_only':True,'touch_event_bound':False,'motor_or_heat_authorized':False,'eeprom_writes_authorized':False,'release_allowed':False,'firmware_source_sha256':hashlib.sha256(lcd.read_bytes()).hexdigest()}
(out/'integration163.json').write_text(json.dumps(r,indent=2)+'\n');print('PASS: dormant probe staged exactly once')
