SV04 NEXT 273: fresh package for GitHub upload.
Upload 273.yml to .github/workflows/273.yml
Upload SV04_NEXT_273.zip to repository root.
Build only. No flash. Same patch logic as 272.
