# SV04 NEXT 272 - P1 IDEX BLTouch

## Root cause found after real 271 STM32 successful build
- Firmware OEM `Marlin/src/module/motion.cpp` uses `x_home_pos(1)` which returns `hotend_offset[1].x` when positive, and `X2_HOME_POS` otherwise.
- OEM `Configuration.h` defines `HOTEND_OFFSET_X { 0.0, 188.00 }`; `Configuration_adv.h` defines `X2_MAX_POS 362`, `X2_HOME_POS X2_MAX_POS`.
- In 271 our two T1 proof checks compared `inactive_extruder_x` to `X2_HOME_POS` (362), erroneously rejecting a correctly homed T1 at 188 mm.
- 272 updates both comparisons to `x_home_pos(1)`. It does NOT assert a physical T1 parked sensor exists.
- 271 built and linked successfully (BUILD_EXIT=0), but the build did not establish runtime safety.

## Scope
Only point 1. G28.cpp delta, no changes to EEPROM/G29/M420. Runs 271 patch then 272 correction on the same pinned OEM commit. Host tests + STM32 build. No firmware binary published.

## Remaining risks
- T1 parked state is inferred from Marlin state, not an independent physical endstop readout.
- BLTouch alarm/failure conditions must be demonstrated in runtime tests.
- IDEX mirrored/duplication/full-control/auto-park modes need targeted state tests.
- Hardware testing remains mandatory before flash release.

## Control-point status
P1 50% (development estimate) until 272 STM32 run result is independently verified. Others unchanged. No flash allowed.
