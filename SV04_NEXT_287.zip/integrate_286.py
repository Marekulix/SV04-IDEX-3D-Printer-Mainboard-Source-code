#!/usr/bin/env python3
"""SV04 NEXT 286: unchanged 285 integration then G29 cancel at actual probe sites."""
from pathlib import Path
import subprocess,sys,argparse,traceback
HERE=Path(__file__).resolve().parent

def main(root,logs):
    logs.mkdir(parents=True,exist_ok=True)
    for n,(script,args) in enumerate([
      ('integrate_285.py',[str(root),'--logs',str(logs/'baseline285')]),
      ('g29/apply_g29_cancel.py',[str(root)])
    ],1):
        r=subprocess.run([sys.executable,str(HERE/script),*args],capture_output=True,text=True)
        (logs/f'{n:02d}_{Path(script).stem}.txt').write_text(f'EXIT={r.returncode}\nSTDOUT\n{r.stdout}\nSTDERR\n{r.stderr}\n')
        if r.returncode: raise RuntimeError(f'{script} failed ({r.returncode}): {r.stderr}')
    g29=(root/'Marlin/src/gcode/bedlevel/abl/G29.cpp').read_text()
    assert g29.count('SV04Claude_G29CancelRequested()')==2
    assert 'if (!sv04_g29_cancelled)' in g29
    print('SV04_NEXT_286_G29_CANCEL_INTEGRATED=YES')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('--logs',required=True,type=Path)
    a=p.parse_args()
    try:main(a.root.resolve(),a.logs.resolve())
    except Exception:
        a.logs.mkdir(exist_ok=True,parents=True)
        (a.logs/'fatal_error.txt').write_text(traceback.format_exc())
        raise
