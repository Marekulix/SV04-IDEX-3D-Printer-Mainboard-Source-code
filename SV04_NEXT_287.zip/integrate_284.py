#!/usr/bin/env python3
"""SV04 NEXT 284: preserve successful build 282, add M420 V7 and V8 only.
Standalone wrapper: 277 + V2/V4/V5/V6 from 282, then V7/V8.
"""
from pathlib import Path
import sys, subprocess, traceback, argparse, hashlib
HERE = Path(__file__).resolve().parent

def integrate(root: Path, logs: Path):
    root=root.resolve(); logs=logs.resolve(); logs.mkdir(parents=True,exist_ok=True)
    steps=[('integrate_281.py',[str(root),'--logs',str(logs/'baseline_282')]),
           ('m420/apply_m420_v7.py',[str(root)]),
           ('m420/apply_m420_v8.py',[str(root)])]
    for index,(script,args) in enumerate(steps,1):
        proc=subprocess.run([sys.executable,str(HERE/script),*args],capture_output=True,text=True)
        (logs/f'{index:02d}_{Path(script).stem}.log').write_text(f'EXIT={proc.returncode}\nSTDOUT:\n{proc.stdout}\nSTDERR:\n{proc.stderr}\n')
        if proc.returncode: raise RuntimeError(f'{script}: EXIT={proc.returncode} (see logs)')
    m=(root/'Marlin/src/gcode/bedlevel/M420.cpp').read_text()
    for marker in ('SV04 NEXT V4:', 'SV04 NEXT V5:', 'SV04 NEXT V6:', 'SV04 NEXT V7:', 'SV04 NEXT V8:'):
        if marker not in m:raise RuntimeError('Missing applied marker '+marker)
    if 'rejected while a print is active.' in m: raise RuntimeError('V7 late print guard was not removed')
    (logs/'M420_SHA256.txt').write_text(hashlib.sha256(m.encode()).hexdigest()+'  Marlin/src/gcode/bedlevel/M420.cpp\n')
    (logs/'INTEGRATION_OK.txt').write_text('SV04 282 + M420 V7/V8 applied, M420 anchors checked; FLASH=NO\n')
    print('INTEGRATED_282_PLUS_M420_V7_V8=YES')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('--logs',type=Path,required=True);a=p.parse_args()
    try:integrate(a.root,a.logs)
    except Exception:
        a.logs.mkdir(parents=True,exist_ok=True)
        (a.logs/'fatal_error.txt').write_text(traceback.format_exc())
        raise
