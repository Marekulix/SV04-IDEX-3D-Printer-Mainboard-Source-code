# SV04 NEXT 287 – GitHub-G29-Testpfad korrigiert

Ausgangspunkt: Version 286, keine Änderungen an Marlin-Firmwarefunktionen.
Der frühere G29-Hosttest benutzte `UP=Path('/mnt/data/work285')`.
Das existiert beim GitHub Runner nicht. Jetzt benutzt er `UP=HERE.parent`,
die Wurzel des entpackten Entwicklungspakets. Die 7 aktiven Abbruchszenarien,
Fail-Closed-Test und Patch-Idempotenz wurden lokal ausgeführt und bestanden.

GitHub-Workflow: `.github/workflows/287.yml`; Quellpaket: `SV04_NEXT_287.zip`.
Version 285 bleibt erfolgreicher Baseline-Build; Version 286 wurde vor Compiler abgebrochen.
Kein Flash. Keine Aussage über STM32-Build bis GitHub-Run 287 bestätigt ist.
