# SV04 NEXT 285 — gemeinsam integrierbarer M420-V9-Zweig

Ausgang: der in GitHub erfolgreich gebaute 284-Zweig, OEM Sovol Commit `1867fcba75354a5c65e0631d6972dd19f1bd6cbe`.

**NEU:** `integrate_285.py` führt unverändert `integrate_284.py` aus und installiert danach `m420/apply_m420_v9.py`. Der optionale `M420_C_USE_MEAN`-Zweig benutzt jetzt `double` beim Aufsummieren der 16 Meshwerte. Dies vermeidet Float-Überlauf bei großen endlichen Summanden. Keine Änderungen an G28, G29, DWIN, M500 oder EEPROM.

Lokale Nachweise: `HOST_TESTS_285.txt` (ausgeführte C++-Testfälle + Integrations-/Konfliktfälle). Bei Verwendung des GitHub Workflows werden beide Buildvarianten mit dem vollständigen OEM-Quellbaum kompiliert. **Bis dahin ist 285 keine bestätigte Build-Baseline.**

Checkpoint: 284 bleibt unverändert. Claude bearbeitet parallel 283 EEPROM. 285 wird später mit Claude 283 integriert, nicht vorher als alleinige Freigabe verwendet.

Upload ins GitHub-Repo: `285.yml` → `.github/workflows/`; `SV04_NEXT_285.zip` → Repo-Root. Kein Flashen, Build-Logs ohne Firmware-Binärdateien.
