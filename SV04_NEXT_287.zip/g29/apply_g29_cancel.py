#!/usr/bin/env python3
"""Apply G29 active cancellation at sampling boundaries on integrated SV04 NEXT 285 tree.
No changes to EEPROM/M500. Fail closed if upstream markers differ.
"""
from pathlib import Path
import sys, hashlib

ROOT_FILES={
 'Marlin/src/gcode/bedlevel/abl/G29.cpp':None,
 'Marlin/src/lcd/e3v2/creality/sv04_claude_hooks.h':None,
 'Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc':None,
}
MARKER='SV04 NEXT G29-CANCEL V1'

def one(s, old, new, label):
    n=s.count(old)
    if n!=1: raise RuntimeError(f'{label}: expected one anchor, found {n}')
    return s.replace(old,new,1)

def apply(root):
    paths={k:root/k for k in ROOT_FILES}
    sources={k:p.read_text(encoding='utf-8') for k,p in paths.items()}
    if all(MARKER in s for s in sources.values()):
        print('ALREADY_INSTALLED: '+MARKER)
        return
    if any(MARKER in s for s in sources.values()):
        raise RuntimeError('PARTIAL INSTALLATION: manually reconcile; no files touched')
    hook='Marlin/src/lcd/e3v2/creality/sv04_claude_hooks.h'
    inc='Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc'
    g29='Marlin/src/gcode/bedlevel/abl/G29.cpp'
    sources[hook]=one(sources[hook],
      'extern void SV04Claude_G29Abort(const uint32_t id);',
      'extern void SV04Claude_G29Abort(const uint32_t id);\n'
      '// SV04 NEXT G29-CANCEL V1: stop the currently bound Auto60 G29 between probe points.\n'
      'extern bool SV04Claude_G29CancelRequested();', 'hook')
    # Predicate is available in all configuration profiles, using the existing Auto60 guard, without ticking coordinator from G29.
    anchor='void SV04Claude_G29Probing(const uint32_t id) { sv04c_g29s.probing(id); }'
    body='''// SV04 NEXT G29-CANCEL V1: abort only an Auto60-owned active G29.
// DWIN cancel is queued while idle() is called inside a probe move. Do not wait
// until the end of 16 moves. Promote that request to coordinator.cancel_pending
// and let the normal G29 failure / probe.stow() / mesh rollback path complete.
bool SV04Claude_G29CancelRequested() {
  #if SV04_CLAUDE_AUTO60_ENABLE && ENABLED(EEPROM_SETTINGS)
    if (sv04c_bound != 0 && sv04c_bound_g29 == sv04c_g29s.active_id()) {
      if (sv04c_cancel_req) {
        sv04c_cancel_req = false;
        sv04c_coord.cancel();
      }
      return sv04c_coord.state() != sv04c::ST_PROBING || sv04c_coord.cancel_requested();
    }
  #endif
  return false;
}
'''
    sources[inc]=one(sources[inc], anchor,body+anchor,'Auto60 hook')
    # Disabled bilinear branch requires a symbol as well; enabled bilinear but auto60 off returns false in main function.
    sources[inc]=one(sources[inc],
       'void SV04Claude_G29Abort(const uint32_t) {}',
       'void SV04Claude_G29Abort(const uint32_t) {}\n'
       'bool SV04Claude_G29CancelRequested() { return false; } // SV04 NEXT G29-CANCEL V1', 'disabled profile')
    pre='''          abl.probePos = abl.probe_position_lf + abl.gridSpacing * abl.meshCount.asFloat();'''
    pre_new='''          // SV04 NEXT G29-CANCEL V1: exit before scheduling another probe move.
          #if ENABLED(RTS_AVAILABLE) && ENABLED(AUTO_BED_LEVELING_BILINEAR)
            if (SV04Claude_G29CancelRequested()) {
              set_bed_leveling_enabled(abl.reenable);
              abl.measured_z = NAN;
              break;
            }
          #endif

'''+pre
    # Keep a local abort latch across the complete G29 function, including its OEM end script.
    guard='''    SV04Claude_G29Guard sv04claude_guard;'''
    sources[g29]=one(sources[g29], guard, guard+'''
    bool sv04_g29_cancelled = false; // SV04 NEXT G29-CANCEL V1: survives until OEM end-script''', 'G29 local latch')
    pre_new=pre_new.replace('''              set_bed_leveling_enabled(abl.reenable);''', '''              sv04_g29_cancelled = true;
              set_bed_leveling_enabled(abl.reenable);''')
    sources[g29]=one(sources[g29],pre,pre_new,'G29 pre-probe')
    probe='''          abl.measured_z = faux ? 0.001f * random(-100, 101) : probe.probe_at_point(abl.probePos, raise_after, abl.verbose_level);

          if (isnan(abl.measured_z)) {'''
    probe_new='''          abl.measured_z = faux ? 0.001f * random(-100, 101) : probe.probe_at_point(abl.probePos, raise_after, abl.verbose_level);

          // SV04 NEXT G29-CANCEL V1: a touch request may arrive DURING probe_at_point().
          // Do not commit that measurement or start the next point on cancellation.
          #if ENABLED(RTS_AVAILABLE) && ENABLED(AUTO_BED_LEVELING_BILINEAR)
            if (SV04Claude_G29CancelRequested()) { sv04_g29_cancelled = true; abl.measured_z = NAN; }
          #endif

          if (isnan(abl.measured_z)) {'''
    sources[g29]=one(sources[g29],probe,probe_new,'G29 post-probe')
    # OEM runs G28 XY unconditionally even after a failed G29. Suppress only when this Auto60 loop was cancelled.
    endscript='''    process_subcommands_now_P(PSTR(Z_PROBE_END_SCRIPT));'''
    endscript_safe='''    // SV04 NEXT G29-CANCEL V1: do NOT move both IDEX carriages after Auto60 cancel.
    #if ENABLED(RTS_AVAILABLE) && ENABLED(AUTO_BED_LEVELING_BILINEAR)
      if (!sv04_g29_cancelled)
    #endif
        process_subcommands_now_P(PSTR(Z_PROBE_END_SCRIPT));'''
    sources[g29]=one(sources[g29],endscript,endscript_safe,'G29 end-script')
    # no writes until every anchor matches
    for k,p in paths.items():
        p.write_text(sources[k],encoding='utf-8')
        print(hashlib.sha256(sources[k].encode()).hexdigest(),k)
    print('APPLIED: G29-CANCEL V1')

if __name__=='__main__':
    if len(sys.argv)!=2: raise SystemExit('usage: apply_g29_cancel.py ROOT')
    apply(Path(sys.argv[1]).resolve())
