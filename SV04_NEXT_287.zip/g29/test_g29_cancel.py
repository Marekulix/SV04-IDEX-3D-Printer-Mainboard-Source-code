#!/usr/bin/env python3
"""Execute exact G29 cancel predicate from patched Auto60 adapter with C++ stubs;
verify the patched OEM G29's pre/post sampling checks and early-exit paths.
"""
from pathlib import Path
import tempfile, subprocess, re, shutil, sys
HERE=Path(__file__).resolve().parent
UP=HERE.parent  # Project root inside the extracted development ZIP
sys.path.insert(0,str(HERE))
from apply_g29_cancel import apply

# Make a realistic staging tree: Claude's OEM G29, patch 277, plus matching 277 headers.
with tempfile.TemporaryDirectory() as td:
    root=Path(td); code=root/'Marlin/src/gcode/bedlevel/abl'; code.mkdir(parents=True)
    lcd=root/'Marlin/src/lcd/e3v2/creality';lcd.mkdir(parents=True)
    src=UP/'claude/01_BASELINE/OEM_FILES/Marlin/src/gcode/bedlevel/abl/G29.cpp'
    shutil.copy2(src,code/'G29.cpp')
    patch=UP/'diffs/2_OVERLAY_G29_OEM_nach_277.patch'
    p=subprocess.run(['patch','-p1','-i',str(patch)],cwd=root,capture_output=True,text=True)
    assert p.returncode==0,(p.stdout,p.stderr)
    shutil.copy2(UP/'claude/02_SOURCE/Marlin/src/lcd/e3v2/creality/sv04_claude_hooks.h',lcd/'sv04_claude_hooks.h')
    shutil.copy2(UP/'claude/02_SOURCE/Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc',lcd/'sv04_claude_auto60_marlin.inc')
    apply(root)
    # repeat installation must not duplicate
    apply(root)
    g=(code/'G29.cpp').read_text(); inc=(lcd/'sv04_claude_auto60_marlin.inc').read_text()
    assert g.count('SV04Claude_G29CancelRequested()')==2
    assert g.index('SV04Claude_G29CancelRequested()')<g.index('probe.probe_at_point')
    assert g.index('probe.probe_at_point')<g.rindex('SV04Claude_G29CancelRequested()')
    assert g.count('abl.measured_z = NAN;') >= 2
    assert 'bool sv04_g29_cancelled = false;' in g
    assert g.count('sv04_g29_cancelled = true;') == 2
    assert 'if (!sv04_g29_cancelled)' in g
    assert g.index('if (!sv04_g29_cancelled)') < g.index('process_subcommands_now_P(PSTR(Z_PROBE_END_SCRIPT));')
    assert g.index('probe.stow()') < g.index('if (!sv04_g29_cancelled)')
    # compile EXACT function copied from patched firmware, with stubs for coordinator.
    start=inc.index('bool SV04Claude_G29CancelRequested() {')
    brace=inc.index('{',start); depth=1;j=brace+1
    while depth:
        if inc[j]=='{': depth+=1
        if inc[j]=='}': depth-=1
        j+=1
    fn=inc[start:j]
    assert 'SV04_CLAUDE_AUTO60_ENABLE' in fn
    test=r'''
#include <stdint.h>
#include <assert.h>
#define SV04_CLAUDE_AUTO60_ENABLE 1
#define EEPROM_SETTINGS 1
#define ENABLED(x) (x)
namespace sv04c { enum State { ST_IDLE=0, ST_PROBING=1, ST_FAILED=2 }; }
struct Coord {
  sv04c::State st=sv04c::ST_PROBING;
  bool cancelled=false;
  int cancel_calls=0;
  sv04c::State state() const {return st;}
  bool cancel_requested() const {return cancelled;}
  void cancel(){ cancelled=true; cancel_calls++; }
} sv04c_coord;
struct G29S { uint32_t id=7; uint32_t active_id() const {return id;} } sv04c_g29s;
uint32_t sv04c_bound=0,sv04c_bound_g29=0;
bool sv04c_cancel_req=false;
''' + fn + r'''
int main(){
  // Standalone manual G29: no Auto60 bound, untouched.
  sv04c_cancel_req=true;
  assert(!SV04Claude_G29CancelRequested());
  assert(sv04c_cancel_req && sv04c_coord.cancel_calls==0);
  // Stale G29 ID: no spurious cancellation.
  sv04c_bound=1; sv04c_bound_g29=8;
  assert(!SV04Claude_G29CancelRequested());
  assert(sv04c_coord.cancel_calls==0);
  // Active Auto60 G29: request is immediately promoted and recognized.
  sv04c_bound_g29=7;
  assert(SV04Claude_G29CancelRequested());
  assert(!sv04c_cancel_req && sv04c_coord.cancel_calls==1);
  assert(SV04Claude_G29CancelRequested());
  assert(sv04c_coord.cancel_calls==1);
  // No cancellation, active probing: keep going.
  sv04c_coord.cancelled=false;sv04c_coord.st=sv04c::ST_PROBING;
  assert(!SV04Claude_G29CancelRequested());
  // Coordinator failure while probing: stop the measurements.
  sv04c_coord.st=sv04c::ST_FAILED;
  assert(SV04Claude_G29CancelRequested());
  // Disabled/finished session: cannot abort another run.
  sv04c_bound=0;
  assert(!SV04Claude_G29CancelRequested());
}
'''
    f=root/'test.cpp'; f.write_text(test)
    exe=root/'test'
    c=subprocess.run(['g++','-std=c++11','-Wall','-Wextra','-Werror',str(f),'-o',str(exe)],capture_output=True,text=True)
    assert c.returncode==0,c.stderr
    r=subprocess.run([str(exe)],capture_output=True,text=True)
    assert r.returncode==0,r.stderr
    print('PASS: compiled and executed patched production cancel predicate (7 scenarios).')
    # Fail-closed test: EEPROM_SETTINGS disabled
    t=test.replace('#define EEPROM_SETTINGS 1','#define EEPROM_SETTINGS 0')
    (root/'test_disabled.cpp').write_text(t.split('int main(){')[0]+'int main(){sv04c_bound=1;sv04c_bound_g29=7;sv04c_cancel_req=true;assert(!SV04Claude_G29CancelRequested());}\n')
    c=subprocess.run(['g++','-std=c++11','-Wall','-Wextra','-Werror',str(root/'test_disabled.cpp'),'-o',str(root/'td')],capture_output=True,text=True)
    assert c.returncode==0,c.stderr
    assert subprocess.run([str(root/'td')]).returncode==0
    print('PASS: fail-closed profile compiled and executed.')
    print('PASS: OEM G29.cpp patched at before/after probe execution sites, idempotent installer.')
print('ALL CHECKS PASSED')
