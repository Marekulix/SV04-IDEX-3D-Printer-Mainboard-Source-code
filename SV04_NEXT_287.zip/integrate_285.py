#!/usr/bin/env python3
"""SV04 NEXT 285: Apply successful 284 integration first, then M420 V9.
Does not modify Claude's EEPROM development branch or 284 baseline ZIP.
"""
from pathlib import Path
import subprocess, sys, argparse, hashlib, traceback
HERE=Path(__file__).resolve().parent

def main(root, logs):
    logs.mkdir(parents=True,exist_ok=True)
    steps=[('integrate_284.py',[str(root),'--logs',str(logs/'baseline284')]),('m420/apply_m420_v9.py',[str(root)])]
    for number,(script,args) in enumerate(steps,1):
        proc=subprocess.run([sys.executable,str(HERE/script),*args],text=True,capture_output=True)
        (logs/f'{number:02d}_{Path(script).stem}.log').write_text(f'EXIT={proc.returncode}\nSTDOUT:\n{proc.stdout}\nSTDERR:\n{proc.stderr}\n')
        if proc.returncode:raise RuntimeError(f'{script}: EXIT={proc.returncode}; inspect evidence')
    src=(root/'Marlin/src/gcode/bedlevel/M420.cpp').read_text()
    for marker in ['SV04 NEXT V4:', 'SV04 NEXT V5:', 'SV04 NEXT V6:', 'SV04 NEXT V7:', 'SV04 NEXT V8:', 'SV04 NEXT V9:']:
        if marker not in src:raise RuntimeError('M420 patch missing: '+marker)
    if 'float mesh_sum = 0;' in src:raise RuntimeError('OLD optional mean accumulator survived V9')
    (logs/'M420_SHA256.txt').write_text(hashlib.sha256(src.encode()).hexdigest()+'  Marlin/src/gcode/bedlevel/M420.cpp\n')
    print('INTEGRATED_284_PLUS_M420_V9=YES')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('--logs',required=True,type=Path)
    a=p.parse_args()
    try:main(a.root.resolve(),a.logs.resolve())
    except Exception:
        a.logs.mkdir(parents=True,exist_ok=True)
        (a.logs/'fatal_error.txt').write_text(traceback.format_exc())
        raise
