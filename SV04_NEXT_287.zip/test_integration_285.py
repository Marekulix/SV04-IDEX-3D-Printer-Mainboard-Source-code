#!/usr/bin/env python3
"""V9 on a representative post-V8 M420 block, plus negative conflict cases.
NOT a replacement for complete OEM/STM32 compile in GitHub workflow.
"""
from pathlib import Path
import tempfile, importlib.util
m=Path(__file__).resolve().parent/'m420'/'apply_m420_v9.py'
s=importlib.util.spec_from_file_location('v9',m);v9=importlib.util.module_from_spec(s);s.loader.exec_module(v9)
with tempfile.TemporaryDirectory() as d:
    p=Path(d)/'Marlin/src/gcode/bedlevel/M420.cpp';p.parent.mkdir(parents=True)
    src='// SV04 NEXT V6: valid prior patch\n// SV04 NEXT V8: valid prior patch\n'+v9.OLD+'\n'
    p.write_text(src)
    v9.apply(d);current=p.read_text()
    assert current.count('SV04 NEXT V9:')==1
    assert v9.NEW in current and v9.OLD not in current
    v9.apply(d);assert p.read_text()==current
    print('PASS V9 install and idempotence on V8-compatible mean block')
    p.write_text(src.replace('float mesh_sum = 0;', 'float mesh_sum = 1;'))
    try:v9.apply(d)
    except RuntimeError:print('PASS incompatible prior edit rejected')
    else:raise AssertionError('V9 accepted incompatible source')
    p.write_text(src.replace('SV04 NEXT V8:', 'V8 absent:'))
    try:v9.apply(d)
    except RuntimeError:print('PASS missing V8 rejected')
    else:raise AssertionError('V9 accepted missing V8')
