# SV04 NEXT 284 – Integration des M420-Schutzes in die erfolgreiche Firmware 282

Die erfolgreich kompilierten Dateien für Version 282 bleiben unverändert. Dieses Paket enthält die
**gesamte Patchkette 282** (Claude 277 + M420 V2/V4/V5/V6) und ergänzt **M420 V7 + V8**.
Claude arbeitet separat auf 282 an M500/EEPROM (Version 283); dieses Paket verändert weder
`settings.cpp` noch EEPROM-/G28-/G29-/Auto60-Dateien außerhalb der bestehenden 282-Patchkette.

## Installation und Build

- `284.yml` ins GitHub-Repository unter `.github/workflows/`.
- `SV04_NEXT_284.zip` ins Repository-Hauptverzeichnis.
- Workflow 284 starten: zwei vollständige STM32-Buildprofile, keine Flash-Freigabe.

Der Workflow verwendet den unveränderten Sovol-OEM-Commit
`1867fcba75354a5c65e0631d6972dd19f1bd6cbe`, führt `integrate_284.py`
aus, sichert STDERR aller Patches und baut nur bei erfolgreicher Integration.

## Nachweise

Lokal ausgeführte V7/V8 C++ Hosttests und Installations-/Konflikttests.
STM32-Kompilierung von Version 284 ist **erst nach GitHub-Run 284** nachgewiesen.
Der bereits erfolgreiche vollständige STM32-Build von 282 ist **kein** Nachweis für 284.

## Versionskollisionen

283 ist für Claudes EEPROM-Zweig reserviert. 284 ist ausschließlich der getrennte
M420-Buildzweig. Zusammenführung beider erfolgt erst nach unabhängigen Builds.
