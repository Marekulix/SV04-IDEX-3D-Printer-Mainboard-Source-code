#!/usr/bin/env python3
"""V7: refuse mesh-centering during print jobs; drain motion queue before mesh writes.
Apply AFTER V6. Touches M420.cpp only. Fails closed on unknown source changes.
"""
from pathlib import Path
import argparse

OLD_ENTRY = "      if (parser.seen('C')) {\n        const float cval = parser.value_float();"
NEW_ENTRY = """      if (parser.seen('C')) {
        // SV04 NEXT V7: a mesh edit is not safe during an active print.
        // In particular a serial-host print may still have planner blocks.
        if (printingIsActive() || printJobOngoing()) {
          SERIAL_ERROR_MSG("M420 C: rejected while a print is active.");
          return;
        }
        const float cval = parser.value_float();"""
OLD_COMMIT = """          if (!NEAR_ZERO(zmean)) {
            set_bed_leveling_enabled(false);
            // All the results passed preflight, so apply them atomically"""
NEW_COMMIT = """          if (!NEAR_ZERO(zmean)) {
            // SV04 NEXT V7: an idle print job may still leave queued moves.
            // Finish them BEFORE changing the mesh used by interpolation.
            planner.synchronize();
            set_bed_leveling_enabled(false);
            // All the results passed preflight, so apply them atomically"""

def apply(root):
    p=Path(root)/'Marlin/src/gcode/bedlevel/M420.cpp'
    s=p.read_text(encoding='utf-8')
    if 'SV04 NEXT V6' not in s or 'SV04 NEXT V4' not in s:
        raise RuntimeError('CONFLICT: V6 and V4 are required')
    if s.count(NEW_ENTRY)==1 and s.count(NEW_COMMIT)==1:
        print('ALREADY_APPLIED V7');return
    if 'SV04 NEXT V7' in s:
        raise RuntimeError('CONFLICT: incomplete or foreign V7 modification')
    if s.count(OLD_ENTRY)!=1 or s.count(OLD_COMMIT)!=1:
        raise RuntimeError(f'CONFLICT: expected OEM/V6 anchors; entry {s.count(OLD_ENTRY)}, commit {s.count(OLD_COMMIT)}')
    n=s.replace(OLD_ENTRY,NEW_ENTRY,1).replace(OLD_COMMIT,NEW_COMMIT,1)
    p.write_text(n,encoding='utf-8')
    print('APPLIED V7',p)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('firmware_root',type=Path);apply(ap.parse_args().firmware_root)
