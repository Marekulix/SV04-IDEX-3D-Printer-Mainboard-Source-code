#!/usr/bin/env python3
"""SV04 NEXT M420 V8: fail-closed M420 C preflight BEFORE S0 mutations.

Run after V7 against 282 + V7. Changes only M420.cpp. Maintains
both compiled-STM32 baseline 282 and Claude's separate EEPROM branch.
"""
from pathlib import Path
import argparse

ANCHOR='  xyz_pos_t oldpos = current_position;'
GUARD='''  // SV04 NEXT V8: Preflight C before even M420 S0 can change leveling.
  // The previous V7 guard was inside the centering block, after S0.
  #if ENABLED(AUTO_BED_LEVELING_BILINEAR)
    if (parser.seen('C')) {
      if (printingIsActive() || printJobOngoing()) {
        SERIAL_ERROR_MSG("M420 C: rejected during a print; state unchanged.");
        return;
      }
      if (!leveling_is_valid()) {
        SERIAL_ERROR_MSG("M420 C: mesh invalid; state unchanged.");
        return;
      }
      const float sv04_c_preflight = parser.value_float();
      if (!__builtin_isfinite(sv04_c_preflight)) {
        SERIAL_ERROR_MSG("M420 C: non-finite correction; state unchanged.");
        return;
      }
      double sv04_center_preflight = double(sv04_c_preflight);
      #if ENABLED(M420_C_USE_MEAN)
        double sv04_sum = 0.0;
        GRID_LOOP(x, y) sv04_sum += double(Z_VALUES(x, y));
        sv04_center_preflight += sv04_sum / double(GRID_MAX_POINTS);
      #else
        double sv04_lo = double(Z_VALUES(0, 0)), sv04_hi = sv04_lo;
        GRID_LOOP(x, y) {
          const double sv04_z = double(Z_VALUES(x, y));
          if (sv04_z < sv04_lo) sv04_lo = sv04_z;
          if (sv04_z > sv04_hi) sv04_hi = sv04_z;
        }
        sv04_center_preflight += (sv04_lo + sv04_hi) * 0.5;
      #endif
      bool sv04_c_valid = __builtin_isfinite(sv04_center_preflight);
      if (sv04_c_valid) GRID_LOOP(x, y) {
        const double sv04_result = double(Z_VALUES(x, y)) - sv04_center_preflight;
        if (!__builtin_isfinite(sv04_result) || sv04_result > double(FLT_MAX) || sv04_result < -double(FLT_MAX))
          sv04_c_valid = false;
      }
      if (!sv04_c_valid) {
        SERIAL_ERROR_MSG("M420 C: invalid result; leveling and mesh unchanged.");
        return;
      }
    }
  #endif
'''

# V7's later print gate becomes redundant. Only remove this exact known block.
LATE='''        // SV04 NEXT V7: a mesh edit is not safe during an active print.
        // In particular a serial-host print may still have planner blocks.
        if (printingIsActive() || printJobOngoing()) {
          SERIAL_ERROR_MSG("M420 C: rejected while a print is active.");
          return;
        }
'''

def apply(root):
    p=Path(root)/'Marlin/src/gcode/bedlevel/M420.cpp'
    s=p.read_text(encoding='utf-8')
    if s.count(GUARD)==1 and LATE not in s:
        print('ALREADY_APPLIED V8',p);return
    if 'SV04 NEXT V8' in s:
        raise RuntimeError('CONFLICT: unknown or partial V8 edit')
    required=['SV04 NEXT V4:', 'SV04 NEXT V5:', 'SV04 NEXT V6:', 'SV04 NEXT V7:']
    missing=[k for k in required if k not in s]
    if missing:raise RuntimeError('CONFLICT: missing earlier patches '+str(missing))
    if s.count(ANCHOR)!=1 or s.count(LATE)!=1:
        raise RuntimeError(f'CONFLICT: V7 anchors mismatch oldpos={s.count(ANCHOR)} late={s.count(LATE)}')
    # Validate all replacements before writing. Never silently replace foreign code.
    n=s.replace(ANCHOR,GUARD+'\n'+ANCHOR,1).replace(LATE,'',1)
    if n.count(GUARD)!=1 or LATE in n:raise RuntimeError('INTERNAL ERROR: incomplete V8 output')
    p.write_text(n,encoding='utf-8')
    print('APPLIED V8',p)

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('firmware_root',type=Path)
    apply(a.parse_args().firmware_root)
