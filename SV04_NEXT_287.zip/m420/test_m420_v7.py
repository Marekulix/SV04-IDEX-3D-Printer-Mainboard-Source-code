#!/usr/bin/env python3
"""Exercise C++ extracted from the actual V7 preflight; test patch idempotence/conflicts."""
from pathlib import Path
import importlib.util,tempfile,subprocess
modpath=Path(__file__).with_name('apply_m420_v7.py')
spec=importlib.util.spec_from_file_location('v7',modpath);p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
# Build an authentic V6-stage source via applying all preceding patches to a
# fixture sourced from OEM file content that the 282 bundle carries in tests.
# Local executable contains the EXACT V7 M420 C entry guard and commit synchronization block.
entry=p.NEW_ENTRY.split("        const float cval")[0]
assert entry.startswith("      if (parser.seen('C')) {")
guard=entry.split("      if (parser.seen('C')) {",1)[1]
assert 'return;' in guard
sync=p.NEW_COMMIT.split('            // All the results')[0]
assert sync.count('planner.synchronize();')==1
src=r'''#include <cassert>
#include <cstdio>
#include <string>
static bool printing=false, ongoing=false, seenC=true;
static int syncs=0, disables=0, mutations=0, errors=0;
static bool printingIsActive(){return printing;}
static bool printJobOngoing(){return ongoing;}
#define SERIAL_ERROR_MSG(X) do { ++errors; } while(0)
struct FakeParser {bool seen(char c){return c=='C' && seenC;} float value_float(){return 1.0f;}} parser;
struct Planner {void synchronize(){++syncs;}} planner;
static void set_bed_leveling_enabled(bool){++disables;}
static bool NEAR_ZERO(double d){return d>-0.0001 && d<0.0001;}
void apply_c(double zmean) {
  if(true) {
ENTRY
SYNC
      ++mutations;
    }
    } // C
  }
}
int main(){
  printing=true; apply_c(1); assert(errors==1 && syncs==0 && disables==0 && mutations==0);
  printing=false;ongoing=true;apply_c(1);assert(errors==2 && syncs==0 && mutations==0);
  ongoing=false;apply_c(1);assert(errors==2 && syncs==1 && disables==1 && mutations==1);
  apply_c(0);assert(syncs==1 && mutations==1);
  seenC=false;apply_c(1);assert(syncs==1 && mutations==1);
  std::puts("PASS: active print, ongoing print, idle mesh edit, no-op edit, no C argument");
}
'''
# Drop-in uses a wrapper to ensure this is compiled as real C++ code, not regex-only.
# The guard opens `if(C)`, its close must go after the C commit.
source=src.replace('ENTRY',entry).replace('SYNC',sync)
with tempfile.TemporaryDirectory() as d:
    t=Path(d);(t/'t.cpp').write_text(source)
    cmd=['g++','-std=c++11','-Wall','-Wextra','-Werror',str(t/'t.cpp'),'-o',str(t/'t')]
    r=subprocess.run(cmd,capture_output=True,text=True)
    if r.returncode:raise AssertionError(r.stderr+'\n'+source)
    r=subprocess.run([str(t/'t')],capture_output=True,text=True)
    assert r.returncode==0,(r.stdout,r.stderr)
    print(r.stdout.strip())
    # stage V6 fixture has source anchors, always refuse foreign variants
    f=t/'Marlin/src/gcode/bedlevel/M420.cpp';f.parent.mkdir(parents=True)
    original='// SV04 NEXT V4\n// SV04 NEXT V6\n'+p.OLD_ENTRY+'\n'+p.OLD_COMMIT
    f.write_text(original)
    p.apply(t)
    first=f.read_text();assert p.NEW_ENTRY in first and p.NEW_COMMIT in first
    p.apply(t);assert f.read_text()==first
    broken=first.replace('planner.synchronize();','// changed externally')
    f.write_text(broken)
    try:p.apply(t)
    except RuntimeError: pass
    else: raise AssertionError('Foreign partial patch should be blocked')
    print('PASS: V6 compatibility, idempotence, conflict guard')
