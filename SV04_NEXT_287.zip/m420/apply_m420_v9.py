#!/usr/bin/env python3
"""SV04 M420 V9: prevent overflow in optional M420_C_USE_MEAN path.
Apply AFTER V8. Does not touch G28, G29, DWIN or EEPROM.
"""
from pathlib import Path
import argparse
OLD = """            // Get the sum and average of all mesh values
            float mesh_sum = 0;
            GRID_LOOP(x, y) mesh_sum += Z_VALUES(x, y);
            const float zmean = mesh_sum / float(GRID_MAX_POINTS);"""
NEW = """            // SV04 NEXT V9: the sum of finite floats may overflow a float.
            // Calculate in double; the V6 validation checks the result before
            // updating any mesh value. Keep this consistent with V8 preflight.
            double mesh_sum = 0.0;
            GRID_LOOP(x, y) mesh_sum += double(Z_VALUES(x, y));
            const double zmean = mesh_sum / double(GRID_MAX_POINTS);"""

def apply(root):
    p = Path(root) / 'Marlin/src/gcode/bedlevel/M420.cpp'
    src = p.read_text(encoding='utf-8')
    if not all(x in src for x in ('SV04 NEXT V6:', 'SV04 NEXT V8:')):
        raise RuntimeError('CONFLICT: V6 and V8 are required')
    if src.count(NEW)==1 and src.count(OLD)==0:
        print('ALREADY APPLIED V9');return
    if 'SV04 NEXT V9:' in src or src.count(OLD)!=1 or src.count(NEW)!=0:
        raise RuntimeError(f'CONFLICT: expected exact V8 mean block, got {src.count(OLD)}')
    p.write_text(src.replace(OLD,NEW,1),encoding='utf-8')
    print('APPLIED V9',p)

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('root',type=Path)
    apply(a.parse_args().root)
