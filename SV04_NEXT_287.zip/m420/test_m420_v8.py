#!/usr/bin/env python3
"""Compile and run V8 production preflight translated only at Marlin macro boundaries."""
from pathlib import Path
import tempfile, subprocess, importlib.util, math
root=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('v8',root/'apply_m420_v8.py')
v8=importlib.util.module_from_spec(spec);spec.loader.exec_module(v8)
# Retain actual generated C++ body. Expand Marlin GRID_LOOP and Z_VALUES into
# their functional C++ equivalents and use direct host state instrumentation.
pre=v8.GUARD.replace('#if ENABLED(AUTO_BED_LEVELING_BILINEAR)','',1)
pre=pre.replace('  #endif\n','',1) if False else pre
# Select the bilinear/midrange production branch; mean mode is a second profile.
mid=pre.split('      #if ENABLED(M420_C_USE_MEAN)')[0]+pre.split('      #else',1)[1].split('      #endif',1)[0]+pre.split('      #endif',1)[1]
mean=pre.split('      #if ENABLED(M420_C_USE_MEAN)')[0]+pre.split('      #if ENABLED(M420_C_USE_MEAN)')[1].split('      #else',1)[0]+pre.split('      #endif',1)[1]
for mode,block in [('midrange',mid),('mean',mean)]:
    block=block.replace('  #if ENABLED(AUTO_BED_LEVELING_BILINEAR)','').replace('  #endif','')
    block=block.replace('GRID_LOOP(x, y)','for (int x=0;x<4;++x) for(int y=0;y<4;++y)')
    block=block.replace('Z_VALUES(x, y)','mesh[x][y]').replace('Z_VALUES(0, 0)','mesh[0][0]')
    # C test runs this preflight directly before the S0 deactivation simulation.
    cpp=r'''#include <cmath>
#include <cfloat>
#include <cstdio>
#include <cassert>
#include <limits>
static float mesh[4][4];
static bool is_printing=false,job_ongoing=false,mesh_valid=true,seenC=true;
static int errors=0,disables=0,updates=0;
static bool printingIsActive(){return is_printing;}
static bool printJobOngoing(){return job_ongoing;}
static bool leveling_is_valid(){return mesh_valid;}
#define GRID_MAX_POINTS 16
#define SERIAL_ERROR_MSG(x) (++errors)
struct Parser {bool seen(char k){return k=='C'&&seenC;}float value_float(){return correction;}
float correction=0;} parser;
static void handler(bool S0) {
BLOCK
  if(S0) ++disables;
  if(seenC)++updates;
}
static void fill(float z){for(int x=0;x<4;++x)for(int y=0;y<4;++y)mesh[x][y]=z;}
static void reset(){is_printing=job_ongoing=false;mesh_valid=seenC=true;errors=disables=updates=0;parser.correction=0;fill(0.1f);}
int main(){
 int count=0;
 // Safe valid centering leaves S0 available.
 reset();handler(true);assert(errors==0&&disables==1&&updates==1);++count;
 // Negative and positive corrections remain valid when representable.
 reset();parser.correction=-1.0f;handler(true);assert(errors==0&&disables==1);++count;
 reset();parser.correction=1.0f;handler(true);assert(errors==0&&disables==1);++count;
 // Printing and ongoing job MUST NOT even disable S0.
 reset();is_printing=true;handler(true);assert(errors==1&&disables==0&&updates==0);++count;
 reset();job_ongoing=true;handler(true);assert(errors==1&&disables==0&&updates==0);++count;
 reset();mesh_valid=false;handler(true);assert(errors==1&&disables==0&&updates==0);++count;
 // C NaN/Inf invalid, no planner state changed.
 reset();parser.correction=std::numeric_limits<float>::quiet_NaN();handler(true);assert(errors==1&&disables==0);++count;
 reset();parser.correction=std::numeric_limits<float>::infinity();handler(true);assert(errors==1&&disables==0);++count;
 reset();parser.correction=-std::numeric_limits<float>::infinity();handler(true);assert(errors==1&&disables==0);++count;
 // Overflow of prospective float grid values is rejected atomically.
 reset();fill(-FLT_MAX);mesh[0][0]=FLT_MAX;parser.correction=FLT_MAX;handler(true);assert(errors==1&&disables==0);++count;
 // C absent means S0 behavior unchanged.
 reset();seenC=false;handler(true);assert(errors==0&&disables==1&&updates==0);++count;
 // Existing near-limit, finite mesh is representable when offset zero.
 reset();fill(FLT_MAX);handler(true);assert(errors==0&&disables==1);++count;
 printf("PASS %d executed M420 V8 %s C++ scenarios\n",count,"MODE");
}
'''.replace('BLOCK',block).replace('MODE',mode)
    with tempfile.TemporaryDirectory() as d:
        d=Path(d);(d/'t.cpp').write_text(cpp)
        q=subprocess.run(['g++','-std=c++11','-O0','-Wall','-Wextra','-Werror',str(d/'t.cpp'),'-o',str(d/'test')],text=True,capture_output=True)
        if q.returncode:raise AssertionError(q.stderr+'\n'+cpp)
        q=subprocess.run([str(d/'test')],text=True,capture_output=True)
        if q.returncode:raise AssertionError(q.stderr+'\n'+q.stdout)
        print(q.stdout.strip())
with tempfile.TemporaryDirectory() as d:
    p=Path(d)/'Marlin/src/gcode/bedlevel/M420.cpp';p.parent.mkdir(parents=True)
    fixture='// SV04 NEXT V4:\n// SV04 NEXT V5:\n// SV04 NEXT V6:\n// SV04 NEXT V7:\n'+v8.ANCHOR+'\n'+v8.LATE
    p.write_text(fixture)
    v8.apply(d);snapshot=p.read_text();v8.apply(d);assert p.read_text()==snapshot
    p.write_text(fixture.replace('rejected while a print is active','CHANGED'))
    try:v8.apply(d)
    except RuntimeError:pass
    else:raise AssertionError('partial/foreign patch accepted')
    print('PASS 3 patch-installation and conflict cases')
