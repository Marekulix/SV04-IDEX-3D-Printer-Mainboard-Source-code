#!/usr/bin/env python3
"""Execute the exact V9 arithmetic snippet in compiled C++, including edge cases."""
import importlib.util, pathlib, subprocess, tempfile
s=importlib.util.spec_from_file_location('v9',pathlib.Path(__file__).with_name('apply_m420_v9.py'))
v9=importlib.util.module_from_spec(s);s.loader.exec_module(v9)
# The exact V9 C++ arithmetic statements, with Marlin macros mapped to a 4x4 grid.
statement=v9.NEW.split('            double mesh_sum = 0.0;',1)[1]
statement='double mesh_sum = 0.0;'+statement
statement=statement.replace('GRID_LOOP(x, y)','for (int x=0;x<4;x++) for (int y=0;y<4;y)').replace('Z_VALUES(x, y)','grid[x][y]').replace('for (int y=0;y<4;y)', 'for (int y=0;y<4;++y)')
cpp=r'''#include <cassert>
#include <cfloat>
#include <cmath>
#include <cstdio>
#define GRID_MAX_POINTS 16
float grid[4][4];
void fill(float v) { for(int x=0;x<4;x++) for(int y=0;y<4;y++) grid[x][y]=v; }
void check(double expected){
STATEMENT
 assert(std::isfinite(zmean));
 assert(std::fabs(zmean-expected)<=std::fabs(expected)*1.e-12+1.e-10);
}
int main(){
 int n=0;
 fill(0.0f); check(0.0); ++n;
 fill(1.25f); check(1.25); ++n;
 fill(-1.25f); check(-1.25); ++n;
 fill(FLT_MAX); check(double(FLT_MAX)); ++n;
 fill(-FLT_MAX); check(-double(FLT_MAX)); ++n;
 fill(FLT_MIN); check(double(FLT_MIN)); ++n;
 fill(-FLT_MIN); check(-double(FLT_MIN)); ++n;
 fill(FLT_MAX);for(int x=0;x<2;x++)for(int y=0;y<4;y++)grid[x][y]=-FLT_MAX;check(0.0);++n;
 fill(0.0f);grid[0][0]=FLT_MAX;check(double(FLT_MAX)/16.0);++n;
 fill(0.0f);grid[0][0]=-FLT_MAX;check(-double(FLT_MAX)/16.0);++n;
 printf("PASS %d compiled C++ V9 mean scenarios\n",n);
}
'''.replace('STATEMENT',statement)
with tempfile.TemporaryDirectory() as temp:
 p=pathlib.Path(temp);(p/'test.cpp').write_text(cpp)
 r=subprocess.run(['g++','-std=c++11','-Wall','-Wextra','-Werror',str(p/'test.cpp'),'-o',str(p/'test')],capture_output=True,text=True)
 assert r.returncode==0,r.stderr
 r=subprocess.run([str(p/'test')],capture_output=True,text=True)
 assert r.returncode==0,(r.stdout,r.stderr)
 print(r.stdout.strip())
 fixture=p/'Marlin/src/gcode/bedlevel/M420.cpp';fixture.parent.mkdir(parents=True)
 fixture.write_text('// SV04 NEXT V6:\n// SV04 NEXT V8:\n'+v9.OLD+'\n')
 v9.apply(p);a=fixture.read_text();v9.apply(p);assert fixture.read_text()==a
 fixture.write_text(a.replace('double mesh_sum = 0.0','double mesh_sum = 1.0'))
 try:v9.apply(p)
 except RuntimeError:pass
 else:raise AssertionError('Foreign edits accepted')
 print('PASS 3 install/idempotence/conflict cases')
