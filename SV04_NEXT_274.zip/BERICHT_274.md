# SV04 NEXT 274 – Punkt 1: IDEX + BLTouch

OEM-Basis: Sovol3d/SV04-IDEX-3D-Printer-Mainboard-Source-code @ 1867fcba75354a5c65e0631d6972dd19f1bd6cbe.

## Neue Änderung gegenüber 273
- `motion.h`/`motion.cpp`: flüchtige Abschlussmarker für T1-X und Z; nur am regulären Ende von `homeaxis()` gesetzt.
- `G28.cpp`: Marker bei Beginn der G28-Ausführung zurücksetzen; T1-Prüfung verlangt zusätzlich den Marker aus dem tatsächlichen X1-Homing-Aufruf; Z-Erfolg verlangt Marker nach BLTouch-Deploy/Stow-Verarbeitung.
- Bereits bestehende Positionsplausibilitätsprüfungen bleiben erhalten.

## Grenzen
Ein Abschlussmarker ist **kein externer Sensor** für T1-Parken und beweist keine echte Kollisionsfreiheit. Marlin kann in anderen internen Pfaden endstopbezogene Fehler melden, ohne dass diese Marker allein jede denkbare Fehlerursache erkennen. Die Variante lehnt weiterhin eigenständiges `G28 Z` ohne frische T1-X-Referenzfahrt ab; diese Verhaltensänderung muss vor Hardwaretests explizit geprüft werden. Die vier IDEX-Betriebsarten sind noch nicht komplett durch Hardwaretests abgesichert.

## Bisherige Evidenz
34 lokale unittest-Prüfungen erfolgreich (24 aus Version 273 plus 10 neue). Keine vollständige STM32-Kompilierung dieser Version in dieser Umgebung. Keine Flashfreigabe. Kein Hardwaretest.

## GitHub
274.yml unter `.github/workflows/`, `SV04_NEXT_274.zip` im Repo-Hauptverzeichnis. Run manuell starten. Ergebnis: `SV04_NEXT_274_STM32_LOGS_NO_FLASH`.
