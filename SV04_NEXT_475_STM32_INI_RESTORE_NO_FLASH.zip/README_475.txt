# SV04 NEXT 475 - STM32 INI-RESTORE - KEINE FLASHFREIGABE

Quelle der Entscheidung: GitHub Actions 474, Run 44342375820.
Abbruch: UnknownEnvNamesError: valid names are include_tree.
Ursache: Das vollstaendige 474-Archiv enthaelt `platformio.ini`, jedoch KEINEN Ordner `ini/`.
Pruefung: Im Repository auf `master` existiert `ini/stm32f1.ini` mit `[env:STM32F103RET6_creality]`.

Der neue 475-Workflow verwendet das UNVERAENDERTE bereits hochgeladene 474-Archiv und kopiert ausschliesslich `ini/` aus dem GitHub-Checkout in den isolierten Buildbaum.
Keine weiteren Quellpatches, kein Ueberschreiben von master-Quelldateien, keine neuen Sicherheitsfreigaben.

Dateiname bestehendes ZIP im Repository:
`SV04_NEXT_474_FULL_SOURCE_STM32_BUILD_CANDIDATE_NO_FLASH.zip`

Hochladen muss man NUR diese 475-YAML nach `.github/workflows/`.
Status: FLASH_ALLOWED=NO; G28_OK=NO; HARDWARE_TESTED=NO.
Die 15 nativen Tests sind keine Hardware-Sicherheitsabnahme.
