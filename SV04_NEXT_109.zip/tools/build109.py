#!/usr/bin/env python3
"""SV04 NEXT 109: experimental DGUS page59 integrated display+touch candidate.

Requires pristine original SV04 DGUS source extracted from pinned bphillips09 commit.
DO NOT INSTALL: compiled DGUS format derived using OEM samples and manufacturer specs;
untested on the actual T5L display, firmware version not established.
"""
import argparse, hashlib, json, io, shutil
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ORIGINAL_SHOW_SHA='777d78bc05ca73cf15d7ab263edd129f196c133118c9ee8eef267c12d3497385'
ORIGINAL_TOUCH_SHA='a7b0b51c2157acb37f3a42319b80c13c9736d740d41553646c80b132043342bd'
PAGE=59
START=0x5a80
MESH_BASE=0x1100
RECT_OPEN=(172,401,250,456)
RECT_BACK=(21,402,124,455)

def sha(x):return hashlib.sha256(x).hexdigest()
def u16(x):return int(x).to_bytes(2,'big')

def basic_nav(page,rect,destination):
    """DGUS II 16-byte basic touch: PicID, Area, PicNext, PicOn, TPCode.
    Page change without VP upload, no new Marlin-side 0x1300/0x1302 handler needed.
    0xFF00 as TP_Code has invalid key code, intentionally no key upload.
    """
    x1,y1,x2,y2=rect
    if not (0<=page<256 and 0<=destination<256):raise ValueError('Invalid page')
    if not (0<=x1<x2<=272 and 0<=y1<y2<=480):raise ValueError('Outside 272x480')
    v=u16(page)+u16(x1)+u16(y1)+u16(x2)+u16(y2)+u16(destination)+b'\xff\x00'+b'\xff\x00'
    assert len(v)==16
    return v

def build_show(oem,template):
    if sha(oem)!=ORIGINAL_SHOW_SHA:raise ValueError('Unrecognized original show binary')
    if not oem.startswith(b'\x14DGUS_2\x10'):raise ValueError('DGUS header mismatch')
    if oem[8:10]!=b'\x00\x3a' or len(oem)!=0x5aa0:raise ValueError('Unexpected show table length')
    objs=template['objects'];assert len(objs)==16
    payload=b''.join(bytes.fromhex(o['record_hex']) for o in objs)
    if len(payload)!=512:raise ValueError('Invalid display object payload')
    for i in range(16):
        x=payload[32*i:32*(i+1)]
        if x[:2]!=b'\x5a\x10' or x[4:6]!=b'\x00\x0d' or x[6:8]!=u16(MESH_BASE+i*2):
            raise ValueError(f'Bad display object {i}')
    # Original end region is only 32 bytes 0xff padding
    if oem[START:]!=b'\xff'*32:raise ValueError('Unexpected show trailer')
    # Expected vacant page59 table location, count 0
    row_off=16+PAGE*4
    if oem[row_off:row_off+4]!=b'\x00\x00\x5a\x80':raise ValueError('Page59 already occupied')
    out=bytearray(oem[:START]+payload+b'\xff'*32)
    out[8:10]=u16(59) # page count encoding: highest configured page
    out[row_off:row_off+2]=(16).to_bytes(2,'little')
    for p in range(60,256):
        off=16+p*4+2
        out[off:off+2]=u16(START+512)
    if out[0x4000:START]!=oem[0x4000:START]:raise AssertionError('Original objects changed')
    for p in range(59):
        off=16+p*4
        if out[off:off+4]!=oem[off:off+4]:raise AssertionError('Existing page changed')
    assert len(out)==len(oem)+512
    return bytes(out)

def build_touch(oem):
    if sha(oem)!=ORIGINAL_TOUCH_SHA:raise ValueError('Unrecognized original touch binary')
    if oem[-2:]!=b'\xff\xff':raise ValueError('Unexpected touch trailer')
    original_region=oem[:-2]
    # Basic touch instruction (16 bytes), documented by DGUS II guide.
    new_objects=[basic_nav(22,RECT_OPEN,59),basic_nav(59,RECT_BACK,1)]
    out=original_region+b''.join(new_objects)+b'\xff\xff'
    assert out[:len(original_region)]==original_region
    assert len(out)==len(oem)+32
    return out,new_objects

def draw_open_button(original_jpg):
    im=Image.open(io.BytesIO(original_jpg)).convert('RGB')
    if im.size!=(272,480):raise ValueError('OEM page22 not 272x480')
    d=ImageDraw.Draw(im)
    x1,y1,x2,y2=RECT_OPEN
    d.rounded_rectangle((x1,y1,x2,y2),radius=9,fill=(5,79,93),outline=(0,220,232),width=2)
    d.text((x1+15,y1+11),'MESH',fill='white')
    d.text((x1+8,y1+29),'ANZEIGE',fill=(204,255,253))
    out=io.BytesIO();im.save(out,format='JPEG',quality=96,subsampling=0)
    return out.getvalue()

def run(source,template_path,out):
    dwin=source/'DWIN_SET'
    t=(dwin/'13TouchFile.bin').read_bytes()
    s=(dwin/'14ShowFile.bin').read_bytes()
    template=json.loads(template_path.read_text('utf-8'))
    show=build_show(s,template)
    touch,touch_rows=build_touch(t)
    page22=draw_open_button((dwin/'22.jpg').read_bytes())
    artwork=Path(__file__).resolve().parents[1]/'59.jpg'
    page59=artwork.read_bytes()
    with Image.open(io.BytesIO(page59)) as im:
        if im.size!=(272,480):raise ValueError('Page59 artwork invalid size')
    out.mkdir(parents=True,exist_ok=True)
    generated=out/'EXPERIMENTELL_NICHT_INSTALLIEREN'
    generated.mkdir(exist_ok=True)
    for name,data in [('13TouchFile.bin',touch),('14ShowFile.bin',show),('22.jpg',page22),('59.jpg',page59)]:
        (generated/name).write_bytes(data)
    # HMI source project as well as both root and DWIN_SET images. No mutation of OEM source.
    hmi=(source/'DWprj.hmi').read_text('utf-8')
    if 'SCREENDSIZE=272X480' not in hmi or '[IMG]' not in hmi:
        raise ValueError('Unknown original HMI project layout')
    if '59=59.jpg' not in hmi:
        hmi=hmi.rstrip()+ '\n59=59.jpg\n'
    (generated/'DWprj.hmi').write_text(hmi,'utf-8')
    # Installer-ready DWIN_SET is NOT emitted deliberately.
    report={'build':'SV04 NEXT 109','status':'EXPERIMENTAL: not verified using official DGUS compiler or hardware',
            'upstream':'bphillips09/SV04-Touchscreen @ 5a3fae8c1ccdc04fb3372c077a61394e8a66ece4',
            'source_show_sha256':sha(s),'source_touch_sha256':sha(t),
            'new_show_sha256':sha(show),'new_touch_sha256':sha(touch),
            'old_show_bytes':len(s),'new_show_bytes':len(show),
            'old_touch_bytes':len(t),'new_touch_bytes':len(touch),
            'page59_display_objects':16,'new_navigation_objects':2,
            'navigation':{'from_oem_page22_to_page59':touch_rows[0].hex(),
                          'from_new_page59_to_page1':touch_rows[1].hex()},
            'stand95_vps_0x1300_0x1302':'superseded in experimental DGUS-only navigation. No new Marlin VP needed.',
            'limitations':['DGUS firmware tooling version not verified','Installed display model and HMI revision not verified',
                           'DGUS touch 16-byte direct page command not confirmed on hardware',
                           'Original page22 artwork modified at open-mesh rectangle; screen must be tested',
                           'No flash/install approval']}
    (out/'REPORT_109.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--templates',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    a=p.parse_args();r=run(a.source,a.templates,a.out)
    print(json.dumps(r,indent=2,ensure_ascii=False))
