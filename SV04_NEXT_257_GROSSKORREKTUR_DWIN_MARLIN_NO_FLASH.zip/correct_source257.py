from pathlib import Path
ROOT=Path(__file__).resolve().parent
src=ROOT/'input/firmware/Marlin/src/lcd/e3v2/creality'
ctl=src/'SV04NextUnified245.hpp'
s=ctl.read_text()
needle='  // G29 has actually started under Claude\'s session gate. No invented session id.'
assert s.count(needle)==1
s=s.replace(needle,'''  // A rejected hardware START must not strand the UI in Requested state.
  // Do not claim that the bed is heating or that a measurement has started.
  bool reject_unstarted_request(Writer &w) {
    if(state_!=Requested || active_) return false;
    requested_=false;confirmed_=false;points_=0;state_=Error;
    w.change_page(PAGE_ERROR);return true;
  }
'''+needle)
ctl.write_text(s)
lcd=src/'LCD_RTS.cpp';s=lcd.read_text()
old='''            if (accepted_245 && tr==sv04next244::StartRequested) {
              if (sv04next254_adapter.touch_start((uint32_t)millis()))
                (void)sv04next255_proofs.new_cycle();
            }'''
new='''            if (accepted_245 && tr==sv04next244::StartRequested) {
              // Reject visibly if the real machine backend does not authorize START.
              // The older implementation silently left the UI stuck in Requested.
              if (sv04next254_adapter.touch_start((uint32_t)millis())) {
                if (!sv04next255_proofs.new_cycle())
                  sv04next250_runtime.external_fault();
              } else
                (void)sv04next245_controller.reject_unstarted_request(sv04next245_writer);
            }'''
assert s.count(old)==1
s=s.replace(old,new)
old='''  // A verified transaction has completed. DWIN output requires a separate,
  // hardware-proven callback and must not be inferred from G29 completion.
  return true;'''
new='''  // The Auto60 RESULT is permitted only after an independent EEPROM proof.
  // The old branch returned true without releasing the pending results page.
  // The physical write remains compile-gated by a validated ICL installation.
  #if SV04NEXT_DGUS_244 && SV04NEXT_UNIFIED_245
    const uint32_t accepted_id = sv04next194_session.accepted_id();
    if (accepted_id != 0 && !sv04next194_session.session_open() &&
        sv04next245_controller.active() &&
        sv04next245_controller.session() == accepted_id) {
      SV04Next244Writer display;
      (void)sv04next245_controller.finish(accepted_id, true, true, saved_mesh, display);
    }
  #endif
  return true;'''
assert s.count(old)==1
s=s.replace(old,new)
lcd.write_text(s)
print('patched real Marlin LCD_RTS.cpp + Unified245.hpp')
