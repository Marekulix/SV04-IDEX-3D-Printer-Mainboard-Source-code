import hashlib,json,pathlib,sys
root=pathlib.Path(sys.argv[1]).resolve()
manifest=json.loads((root/'SHA256_MANIFEST_257.json').read_text())
bad=[]
for rel,digest in manifest.items():
 p=root/rel
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest:bad.append(rel)
print('V257 manifest:',len(manifest),'entries','PASS' if not bad else 'FAIL '+str(bad))
if bad:sys.exit(1)
