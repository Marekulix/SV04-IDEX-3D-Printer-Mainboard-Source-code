import hashlib,io,struct,json
from pathlib import Path
from PIL import Image
base=Path(__file__).resolve().parent
old=(base/'dwin_evidence/32_main_ORIGINAL_NOT_MODIFIED.icl').read_bytes()
new=(base/'DWIN_SET_257/32_main.icl').read_bytes()
assert new[:14]==old[:14] and old[14]==58 and new[14]==63
assert old[15]==new[15]==0
assert len(new)==2805760 and len(new)%2048==0
op=[struct.unpack_from('>I',old,16+4*i)[0] for i in range(59)]
np=[struct.unpack_from('>I',new,16+4*i)[0] for i in range(64)]
assert np==sorted(np) and len(set(np))==64 and np[0]==272
for i in range(64):
 p=np[i];end=np[i+1] if i<63 else len(new)
 assert p<end and p+10<end
 assert new[p:p+6]==bytes.fromhex('011001e00272')
 raw=new[p+10:end]
 e=raw.find(b'\xff\xd9')
 assert e>=0 and not any(raw[e+2:]), f'bad padding {i}'
 img=Image.open(io.BytesIO(raw[:e+2]))
 assert img.size==(272,480)
 if i<59:
  start=op[i];end_old=op[i+1] if i<58 else len(old)
  old_piece=old[start+10:old.find(b'\xff\xd9',start+10,end_old)+2]
  assert old[start:start+10]==new[p:p+10]
  assert old_piece==raw[:e+2], f'changed old image {i}'
 else:
  expected=(base/'dwin_evidence'/f'{i}.jpg').read_bytes()
  assert expected==raw[:e+2]
  img.load()
assert hashlib.sha256(new).hexdigest()==json.loads((base/'REPORT_257_ICL.json').read_text())['new_sha256']
print('ICL 257: pointer table 64/64, 59 OEM images byte-exact, 5 new JPGs validated, header and padding: PASS')
