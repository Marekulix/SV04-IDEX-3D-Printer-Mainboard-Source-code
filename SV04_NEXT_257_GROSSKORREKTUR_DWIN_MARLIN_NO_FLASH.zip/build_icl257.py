#!/usr/bin/env python3
"""Rebuild DGUS_36 ICL from SHA-verified OEM image slots, adding 59..63.
Experimental resource; does NOT grant permission to flash it.
"""
import hashlib, io, json, struct, sys
from pathlib import Path
from PIL import Image

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'dwin_evidence/32_main_ORIGINAL_NOT_MODIFIED.icl'
OUT=ROOT/'DWIN_SET_257/32_main.icl'
EXPECTED_SHA='f3f77190deeda947db9597749d24ebbb1cc42c38a786ba192f136b2b482b384f'
# Pinned checksum comes from the GitHub-provided evidence, not a hard-coded assumed hash.
sha_file=ROOT/'dwin_evidence/original_icl_sha256.txt'
raw=SOURCE.read_bytes()
print('SOURCE_SHA256',hashlib.sha256(raw).hexdigest())
if hashlib.sha256(raw).hexdigest()!=EXPECTED_SHA: raise ValueError('OEM ICL checksum mismatch')
if not raw.startswith(b'DGUS_36') or raw[14]!=58:
    raise ValueError('unexpected OEM ICL header / last image index')
assert int.from_bytes(raw[16:20],'big')==252, 'OEM offset table not expected'
if len(raw)!=2641920: raise ValueError('OEM ICL length changed')

old_offsets=[int.from_bytes(raw[16+i*4:20+i*4],'big') for i in range(59)]
if old_offsets!=sorted(old_offsets) or old_offsets[0]!=252: raise ValueError('bad OEM offsets')
slots=[]
for i,p in enumerate(old_offsets):
    end=old_offsets[i+1] if i<58 else len(raw)
    if p<252 or p+10>end: raise ValueError('bad source segment')
    pre=raw[p:p+10]
    if pre[:6]!=bytes.fromhex('011001e00272'):raise ValueError(f'wrong JPEG image metadata at {i}')
    jpg_start=p+10
    jpg_end=raw.find(b'\xff\xd9',jpg_start,end)
    if jpg_end==-1: raise ValueError(f'missing JPEG end at {i}')
    jpg=raw[jpg_start:jpg_end+2]
    if any(raw[jpg_end+2:end]): raise ValueError(f'non-zero OEM padding at {i}')
    im=Image.open(io.BytesIO(jpg))
    if im.size!=(272,480):raise ValueError(f'wrong OEM image size at {i}')
    slots.append((pre,jpg))

new_images=[]
for i in range(59,64):
    jpg=(ROOT/'dwin_evidence'/f'{i}.jpg').read_bytes()
    im=Image.open(io.BytesIO(jpg)); im.load()
    if im.size!=(272,480) or im.format!='JPEG': raise ValueError(f'bad new JPG {i}')
    if not jpg.startswith(b'\xff\xd8') or not jpg.endswith(b'\xff\xd9'):raise ValueError('invalid JPEG')
    # OEM metadata records signed image size as 4-byte aligned (JPEG_len-615).
    # Its exact vendor meaning is NOT established; the editor-generated ICL
    # remains the installation reference, not this reverse-engineered file.
    length=((len(jpg)-615)//4)*4
    if length<=0:raise ValueError('impossible JPEG length')
    pre=bytes.fromhex('011001e00272')+length.to_bytes(4,'big')
    new_images.append((pre,jpg))
slots+=new_images
assert len(slots)==64
# DGUS_36 keeps last-image-id in header[14], and a big-endian pointer table.
header=bytearray(raw[:16]);header[14]=63
result=bytearray(header+b'\x00'*256)
positions=[]
for i,(pre,jpg) in enumerate(slots):
    if i>0:result+=b'\x00'*((-len(result))%2048)
    positions.append(len(result))
    result.extend(pre);result.extend(jpg)
result+=b'\x00'*((-len(result))%2048)
for i,p in enumerate(positions):struct.pack_into('>I',result,16+i*4,p)
# Independent round trip of all entries, including preservation of OLD image bytes.
for i,p in enumerate(positions):
    assert int.from_bytes(result[16+4*i:20+4*i],'big')==p
    meta,jpg=slots[i]
    assert result[p:p+10]==meta and result[p+10:p+10+len(jpg)]==jpg
    im=Image.open(io.BytesIO(result[p+10:p+10+len(jpg)]))
    assert im.size==(272,480)
for i in range(59):
    p=old_offsets[i];e=old_offsets[i+1] if i<58 else len(raw)
    old_jpeg=raw[p+10:raw.find(b'\xff\xd9',p+10,e)+2]
    assert hashlib.sha256(old_jpeg).digest()==hashlib.sha256(slots[i][1]).digest()
OUT.parent.mkdir(exist_ok=True)
OUT.write_bytes(result)
report={'format':'DGUS_36','source_length':len(raw),'source_sha256':hashlib.sha256(raw).hexdigest(),'new_length':len(result),'new_sha256':hashlib.sha256(result).hexdigest(),'original_image_count':59,'new_images':list(range(59,64)), 'all_image_count':64,'original_jpegs_byte_preserved':True,'all_64_jpegs_metadata_read':True,'original_jpegs_decode_full':False,'all_dimension_272x480':True,'new_image_offsets':positions[59:],'warning':'Experimental reverse-engineered ICL: no DWIN editor/runtime or display test. NOT FOR FLASH. Metadata meaning not fully independently verified.'}
(ROOT/'REPORT_257_ICL.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
