#include "firmware/Marlin/src/lcd/e3v2/creality/SV04NextUnified245.hpp"
#include "firmware/Marlin/src/lcd/e3v2/creality/SV04NextMachineProof255.hpp"
#include <cassert>
#include <cstdio>
#include <cstdint>
using namespace sv04next244;
class Display final : public Writer {
 public: uint8_t page; unsigned writes;Display():page(0),writes(0){}
 void write_word(uint16_t,uint16_t) override {++writes;}
 void change_page(uint8_t p) override {page=p;}
};
class Locked final : public sv04next255::Commands {
 public:
 bool machine_idle_and_idex_parked() override {return false;}
 bool enqueue_g28() override {return false;}
 bool enqueue_g29() override {return false;}
 bool enable_leveling() override {return false;}
 bool store_settings() override {return false;}
 bool request_safe_abort() override {return false;}
};
int main(){
 Display d;
 sv04next245::Controller c;
 assert(c.show_start(d));assert(d.page==59);
 assert(c.touch(StartRequested,d));
 assert(c.requested() && c.state()==sv04next245::Requested);
 Locked locked; sv04next255::Backend backend(locked);
 assert(!backend.ready_idle_and_idex_safe());
 assert(c.reject_unstarted_request(d));
 assert(d.page==62 && c.state()==sv04next245::Error && !c.requested());
 assert(!c.reject_unstarted_request(d));
 assert(c.show_start(d));
 assert(c.touch(StartRequested,d));
 assert(c.begin(11,d));
 assert(!c.reject_unstarted_request(d));
 assert(c.point(11,1,d));
 float mesh[16]; for(int i=0;i<16;++i)mesh[i]=(float)i/100.0f;
 assert(c.finish(11,true,true,mesh,d));
 assert(c.state()==sv04next245::Result && c.confirmed() && d.page==63);
 assert(d.writes==17);
 // a pending abort cannot accidentally become a success
 assert(c.show_start(d));assert(c.touch(StartRequested,d));assert(c.begin(12,d));
 assert(c.touch(AbortRequested,d));assert(!c.finish(12,true,true,mesh,d));
 assert(c.state()==sv04next245::Error && !c.confirmed());
 puts("test257: UI rejection, proven result gating, abort race: PASS");
 return 0;
}
