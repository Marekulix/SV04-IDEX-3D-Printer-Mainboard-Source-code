#!/usr/bin/env python3
"""SV04 NEXT 257 reproducible OEM overlay & build gates, no flash."""
import argparse, hashlib, json, pathlib, shutil, subprocess, sys, time
ROOT=pathlib.Path(__file__).resolve().parent
OEM='1867fcba75354a5c65e0631d6972dd19f1bd6cbe'
MODES=('oem','merged_safe','observer','full_diagnostic','full_compile_probe')
BASE_FLAGS={
'SV04NEXT_G29_FAILSAFE_194':0,'SV04NEXT_G29_RESEND_194':0,
'SV04NEXT_G29_GUARD_LIVE_194':0,'SV04NEXT_G29_DEFER_LIVE_MESH_235':0,
'SV04NEXT_HMI_OBSERVER_232':0,'SV04NEXT_DGUS_244':0,
'SV04NEXT_UNIFIED_245':0,'SV04NEXT_AUTO60_249':0,
'SV04NEXT_RUNTIME_250':0,'SV04NEXT_RUNTIME_G29_251':0,
'SV04NEXT_MARLIN_HEAT_253':0,'SV04NEXT_AUTO60_RESULT_GATE_252':0,
'SV04NEXT_MARLIN_MACHINE_254':0,'SV04NEXT_REAL_BACKEND_255':0,
'SV04NEXT_G28_END_PROOF_255':0,'SV04NEXT_DISPLAY_ICL_VERIFIED_245':0,
}
DIAG_ON=['SV04NEXT_G29_DEFER_LIVE_MESH_235','SV04NEXT_HMI_OBSERVER_232',
'SV04NEXT_DGUS_244','SV04NEXT_UNIFIED_245','SV04NEXT_AUTO60_249',
'SV04NEXT_RUNTIME_250','SV04NEXT_RUNTIME_G29_251','SV04NEXT_MARLIN_HEAT_253',
'SV04NEXT_AUTO60_RESULT_GATE_252','SV04NEXT_MARLIN_MACHINE_254',
'SV04NEXT_REAL_BACKEND_255','SV04NEXT_G28_END_PROOF_255']
SOURCE='firmware/Marlin/src'

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*cmd,root):return subprocess.check_output(['git','-C',str(root),*cmd],text=True).strip()
def run(args):
 ap=argparse.ArgumentParser()
 ap.add_argument('oem_checkout',type=pathlib.Path)
 ap.add_argument('--mode',required=True,choices=MODES)
 ap.add_argument('--report',type=pathlib.Path,required=True)
 a=ap.parse_args(args)
 repo=a.oem_checkout.resolve();r=a.report.resolve();r.parent.mkdir(parents=True,exist_ok=True)
 result={'version':257,'mode':a.mode,'oem_commit_expected':OEM,'time_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'ready_to_flash':False,'files':[]}
 try:
  commit=git('rev-parse','HEAD',root=repo);result['oem_commit_actual']=commit
  if commit!=OEM:raise RuntimeError('Wrong OEM commit: '+commit)
  if not (repo/'platformio.ini').exists():raise RuntimeError('Missing platformio.ini')
  if a.mode=='oem':
   result['flags']='unmodified OEM';result['overlay']='none'
  else:
   src=ROOT/SOURCE;dst=repo/'Marlin/src'
   files=sorted(x for x in src.rglob('*') if x.is_file())
   if len(files)<15:raise RuntimeError('Overlay too small, expected >=15 files')
   for f in files:
    t=dst/f.relative_to(src)
    if t.exists() and t.is_symlink():raise RuntimeError('Refusing symlink target '+str(t))
    result['files'].append({'path':str(t.relative_to(repo)),'before':sha(t) if t.is_file() else None,'after':sha(f)})
   for f in files:
    t=dst/f.relative_to(src);t.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,t)
   flags=dict(BASE_FLAGS)
   if a.mode=='observer':flags['SV04NEXT_HMI_OBSERVER_232']=1
   if a.mode in ('full_diagnostic','full_compile_probe'):
    for n in DIAG_ON:flags[n]=1
    # Do not fabricate an ICL verification. This intentionally reveals the real dependency.
    flags['SV04NEXT_DISPLAY_ICL_VERIFIED_245']=1 if a.mode=='full_compile_probe' else 0
    if a.mode=='full_compile_probe':
     result['UNSAFE_TEST_OVERRIDE']='ILC PROOF FORCED TRUE IN THROWAWAY COMPILATION ONLY; SOURCE NOT FLASHABLE'
   result['flags']=flags
   prefix='// SV04NEXT-257 diagnostic-only compile flags; copied overlay is immutable.\n'+''.join('#define %s %s\n'%(k,v) for k,v in flags.items())
   for rel in ['Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp','Marlin/src/gcode/bedlevel/abl/G29.cpp','Marlin/src/gcode/calibrate/G28.cpp']:
    file=repo/rel
    if not file.exists():raise RuntimeError('Missing expected source '+rel)
    file.write_text(prefix+file.read_text(encoding='utf-8'),encoding='utf-8')
   result['overlay']='SV04 NEXT 257 corrected source + injected variant defines'
  result['status']='PREPARED'
 except Exception as exc:
  result['status']='FAILED';result['error']=str(exc)
 finally:
  r.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
  print(json.dumps({'status':result['status'],'mode':a.mode,'error':result.get('error')},ensure_ascii=False))
 if result['status']!='PREPARED':sys.exit(2)
if __name__=='__main__':run(sys.argv[1:])
