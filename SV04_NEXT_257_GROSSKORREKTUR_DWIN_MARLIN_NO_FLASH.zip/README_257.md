# SV04 NEXT 257 – großer Korrekturdurchgang

## Echte Änderungen (keine reine Planung)

- `dwin257/32_main_EXPERIMENTAL_NO_FLASH.icl` ist eine neu erzeugte DGUS_36-Bildbibliothek mit 64 Bildern; das originale Bildmaterial 0–58 bleibt als JPEG bytegenau erhalten, JPG 59–63 wurden eingebaut. Quelle: die echte OEM-ICL aus GitHub-Audit V256.
- `firmware/Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp`: Nach unabhängig akzeptierter EEPROM-Rücklesung wird das DWIN-Ergebnis erstmals an den Unified245-Controller übergeben, sofern er zur akzeptierten G29-Sitzung gehört. Ein G29-Abschluss allein reicht nicht.
- `firmware/Marlin/src/lcd/e3v2/creality/SV04NextUnified245.hpp`: Wenn reale Marlin-Startfreigabe scheitert, bleibt das UI nicht mehr in `Requested` hängen; die Fehlerseite erscheint.
- `test257.cpp` prüft beide Regressionsfälle und Abbruchrennen.

## Einordnung / Sicherheitsgrenzen

- Die ICL wurde **reverse-engineered**, nicht durch den offiziellen DGUS-Editor kompiliert. Ihr 10-Byte-JPEG-Metadatenfeld ist teilweise nur abgeleitet. Die Datei darf **NICHT** auf das DWIN geschrieben werden, bis DGUS-Editor/Display die Kompatibilität belegen.
- Die experimentellen Touch- und Anzeige-Binärdateien 13/14 sind weiterhin nicht hardwaregetestet.
- Die `SV04NextLockedCommands255` in `LCD_RTS.cpp` verweigert weiterhin sämtliche Bewegungs-/Speicheraktionen. Es gibt **keine** vollständige Maschinenanbindung, keine physische IDEX-Parkbestätigung und keine sichere unabhängige Marlin-EEPROM-Rücklesung.
- Die Korrekturen sind lokal auf Host-Basis kompiliert/getestet; es liegt **kein** neuer STM32-Build vor. Der V257-Auditworkflow liefert einen neuen Build-Nachweis, aber keine Flash-Datei.
- Auch eine erfolgreiche Firmwarekompilierung würde diese offenen Maschinen- und HMI-Hardwarefragen NICHT lösen.

## Prüfungen

- `python3 verify_icl257.py`
- `g++ -std=c++11 -O2 -Wall -Wextra -Werror -pedantic test257.cpp -o test257 && ./test257`
- `python3 host256.py logs257` (22 existierende Prüfschritte; manche historischen Tests wurden schon in V256 ausgeschlossen)
- `python3 verify_package257.py .`

**KEINE FLASHFREIGABE – weder für STM32 noch DWIN.**
