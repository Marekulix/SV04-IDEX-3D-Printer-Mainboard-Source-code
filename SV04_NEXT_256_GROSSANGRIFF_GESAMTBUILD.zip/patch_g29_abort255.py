from pathlib import Path
base=Path(__file__).parent/'firmware/Marlin/src'
g29=base/'gcode/bedlevel/abl/G29.cpp'
lcd=base/'lcd/e3v2/creality/LCD_RTS.cpp'
s=g29.read_text()
needle='''          abl.probePos = abl.probe_position_lf + abl.gridSpacing * abl.meshCount.asFloat();'''
assert s.count(needle)==1
s=s.replace(needle,'''          // SV04 NEXT 255: cooperative abort at safe BETWEEN-POINT boundary.\n          // Cannot interrupt an in-flight blocking probe_at_point() operation.\n          #if SV04NEXT_REAL_BACKEND_255\n            if (SV04Next_G29StopRequested255()) G29_RETURN(false);\n          #endif\n\n'''+needle,1)
needle='#if HAS_ABL_NOT_UBL'
assert s.count(needle)==1
s=s.replace(needle,'''#ifndef SV04NEXT_REAL_BACKEND_255\n#define SV04NEXT_REAL_BACKEND_255 0\n#endif\n#if SV04NEXT_REAL_BACKEND_255\nextern bool SV04Next_G29StopRequested255();\n#endif\n'''+needle,1)
g29.write_text(s)
s=lcd.read_text()
needle='''  bool read_queued_;'''; assert s.count(needle)==1
s=s.replace(needle,'''  bool read_queued_, g29_running_, g29_stop_requested_, g29_stop_ack_;''',1)
needle='''current_token_(0),read_queued_(false){}''';assert s.count(needle)==1
s=s.replace(needle,'''current_token_(0),read_queued_(false),g29_running_(false),g29_stop_requested_(false),g29_stop_ack_(false){}''',1)
needle='''  bool issue_abort() override {\n    // Without an independently verified G29/IDEX motion stop, do not issue\n    // quickstop or claim abort. G29 can be inside a blocking probe_at_point().\n    return false;\n  }\n  bool motion_stopped_proven() override {return false;}\n  void new_run(){read_queued_=false;proof_.invalidate();}'''
assert s.count(needle)==1
s=s.replace(needle,'''  bool issue_abort() override {\n    // Cooperative G29 abort ONLY. No uncontrolled quickstop of IDEX axes.\n    if(!g29_running_ || !sv04next250_runtime.abort_requested())return false;\n    g29_stop_requested_=true;return true;\n  }\n  bool motion_stopped_proven() override {\n    return g29_stop_ack_ && !g29_running_ && !planner.movesplanned();\n  }\n  bool stop_requested()const{return g29_stop_requested_ && g29_running_;}\n  void g29_begin(){g29_running_=true;g29_stop_requested_=g29_stop_ack_=false;}\n  void g29_exit(bool normal){\n    g29_stop_ack_=!normal && g29_stop_requested_;g29_running_=false;\n    g29_stop_requested_=false;\n  }\n  void new_run(){read_queued_=g29_running_=g29_stop_requested_=g29_stop_ack_=false;proof_.invalidate();}''',1)
needle='''void SV04Next_G28Finished255(bool axes_homed,bool idex_parked,bool z_homed){'''
assert s.count(needle)==1
s=s.replace(needle,'''bool SV04Next_G29StopRequested255(){return SV04Next_Backend255().stop_requested();}\n'''+needle,1)
needle='''  const uint32_t id=sv04next194_session.begin(s);'''
assert s.count(needle)==1
s=s.replace(needle,needle+'''\n  #if SV04NEXT_REAL_BACKEND_255\n    if (sv04next250_runtime.armed()) SV04Next_Backend255().g29_begin();\n  #endif''',1)
# In the real completion callback, mark G29 processing done when accepted G29 succeeds.
needle='''void SV04Next_G29Complete194(const uint32_t id, const bool successful, const bool dryrun, const bool faux) {'''
assert s.count(needle)==1
s=s.replace(needle,needle+'''\n  #if SV04NEXT_REAL_BACKEND_255\n    SV04Next_Backend255().g29_exit(successful && !dryrun && !faux);\n  #endif''',1)
needle='''void SV04Next_G29Abort194(const uint32_t id) {'''
assert s.count(needle)==1
s=s.replace(needle,needle+'''\n  #if SV04NEXT_REAL_BACKEND_255\n    SV04Next_Backend255().g29_exit(false);\n  #endif''',1)
needle='''  #if SV04NEXT_RUNTIME_250\n    sv04next250_runtime.external_fault();\n  #endif'''
assert s.count(needle)==1
s=s.replace(needle,'''  #if SV04NEXT_RUNTIME_250\n    #if SV04NEXT_REAL_BACKEND_255\n      // A requested cooperative abort remains CancelRequested until the\n      // action adapter proves that motion has fully stopped.\n      if (!sv04next250_runtime.abort_requested())\n        sv04next250_runtime.external_fault();\n    #else\n      sv04next250_runtime.external_fault();\n    #endif\n  #endif''',1)
lcd.write_text(s)
print('SV04 NEXT 255: G29 cooperative between-point abort hook integrated into REAL G29.cpp, not quickstop')
