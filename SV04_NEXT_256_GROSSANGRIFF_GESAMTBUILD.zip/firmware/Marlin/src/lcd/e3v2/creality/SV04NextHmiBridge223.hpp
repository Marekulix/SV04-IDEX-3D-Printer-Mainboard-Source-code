#pragma once
// SV04 NEXT 222: fixed-field compact HMI projection (HOST ONLY, no DGUS writes).
#include "SV04NextHmiBridge221.hpp"
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
namespace sv04next223 {
using sv04next221::Snapshot;
static const uint8_t kCapacity[31] = {32,96,24,24,32,8,12,12,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,8,8,8,8,41,81,32};
static const size_t kTextBytes=32+96+24+24+32+8+12+12+16*20+4*8+41+81+32;
struct Frame {
 uint32_t session,sequence;
 Snapshot::State state;
 char text[kTextBytes];
 Frame():session(0),sequence(0),state(Snapshot::Ready){memset(text,0,sizeof text);}
 const char* field(unsigned idx) const {
   if(idx>=31) return nullptr;
   size_t off=0;
   for(unsigned i=0;i<idx;i++) off+=kCapacity[i];
   return text+off;
 }
 bool put(unsigned idx,const char* str) {
   if(idx>=31||!str) return false;
   const size_t n=strlen(str);
   if(n>=kCapacity[idx]) return false; // never truncate a confirmed status
   char* to=const_cast<char*>(field(idx));
   memcpy(to,str,n+1);
   return true;
 }
};
static_assert(sizeof(Frame)<1200,"compact frame too large");
inline const char* status_utf8(Snapshot::State s) {
 static const char* const t[]={"Bereit","Bett aufheizen","Temperatur stabilisieren","Referenzfahrt","Vermessung läuft","Messwerte prüfen","Messung abgeschlossen – nicht gespeichert","Mesh aktiviert – nicht gespeichert","EEPROM-Schreiben bestätigt – Rücklesen offen","EEPROM-Rücklesen bestätigt","Steuerung meldet Fehler","Messung abgebrochen","Kommunikation unklar – Status unbekannt"};
 return (unsigned)s<13 ? t[(unsigned)s] : "";
}
inline bool valid_utf8(const char* p) {
 if(!p)return false;
 const unsigned char* s=(const unsigned char*)p;
 while(*s) {
   if(*s<0x80) {++s;continue;}
   const uint32_t a=*s++;
   unsigned more=0;uint32_t code=0,min=0;
   if(a>=0xC2 && a<=0xDF) {more=1;code=a&0x1F;min=0x80;}
   else if(a>=0xE0 && a<=0xEF) {more=2;code=a&0x0F;min=0x800;}
   else if(a>=0xF0 && a<=0xF4) {more=3;code=a&0x07;min=0x10000;}
   else return false;
   for(unsigned i=0;i<more;i++) {if(!*s || (*s&0xC0)!=0x80)return false;code=(code<<6)|(*s++&0x3F);}
   if(code<min || code>0x10FFFF || (code>=0xD800 && code<=0xDFFF))return false;
 }
 return true;
}
inline bool project(const Snapshot& s,Frame& f) {
 if(!sv04next221::valid(s) || !valid_utf8(s.error_code) || !valid_utf8(s.error_text)) return false;
 Frame next;
 next.session=s.session;next.sequence=s.sequence;next.state=s.state;
 unsigned j=0;
 for(unsigned i=0;i<38;i++){
   if(sv04next221::kBindings[i].kind==sv04next221::Touch) continue;
   const char* field=sv04next221::kBindings[i].field;
   char buffer[96]={0};
   if(!strcmp(field,"title")) snprintf(buffer,sizeof buffer,"Bettvermessung 60 °C");
   else if(!strcmp(field,"status")) snprintf(buffer,sizeof buffer,"%s",status_utf8(s.state));
   else if(!strcmp(field,"bed_actual")) {if(s.actual_set) snprintf(buffer,sizeof buffer,"%.1f °C",s.actual_c10/10.0);else snprintf(buffer,sizeof buffer,"—");}
   else if(!strcmp(field,"bed_target")) {if(s.target_set) snprintf(buffer,sizeof buffer,"%.1f °C",s.target_c10/10.0);else snprintf(buffer,sizeof buffer,"—");}
   else if(!strcmp(field,"stability")) snprintf(buffer,sizeof buffer,"%s",s.state!=Snapshot::Ready&&s.state!=Snapshot::Heating&&s.state!=Snapshot::Unknown?"Bestätigt":"Nicht bestätigt");
   else if(!strcmp(field,"current_point")) {if(s.state==Snapshot::Probing)snprintf(buffer,sizeof buffer,"%u",(unsigned)(s.completed<16?s.completed+1:16));else snprintf(buffer,sizeof buffer,"—");}
   else if(!strcmp(field,"count")) snprintf(buffer,sizeof buffer,"%u/16",(unsigned)s.completed);
   else if(!strcmp(field,"percent")) snprintf(buffer,sizeof buffer,"%u %%",(unsigned)(s.completed*100/16));
   else if(!strncmp(field,"cell_",5)) {unsigned n=(unsigned)(field[5]-'0')*10+(unsigned)(field[6]-'0');if(n>15)return false;if(s.mesh_confirmed)snprintf(buffer,sizeof buffer,"%+.3f mm",(double)s.mesh[n]);else snprintf(buffer,sizeof buffer,"—");}
   else if(!strcmp(field,"measured"))snprintf(buffer,sizeof buffer,"%s",s.mesh_confirmed?"Ja":"Nein");
   else if(!strcmp(field,"mesh_enabled"))snprintf(buffer,sizeof buffer,"%s",s.enabled_confirmed?"Ja":"Nein");
   else if(!strcmp(field,"eeprom_written"))snprintf(buffer,sizeof buffer,"%s",s.write_confirmed?"Ja":"Nein");
   else if(!strcmp(field,"eeprom_verified"))snprintf(buffer,sizeof buffer,"%s",s.readback_confirmed?"Ja":"Nein");
   else if(!strcmp(field,"error_code"))snprintf(buffer,sizeof buffer,"%s",s.error_code[0]?s.error_code:"—");
   else if(!strcmp(field,"error_text"))snprintf(buffer,sizeof buffer,"%s",s.error_text[0]?s.error_text:status_utf8(s.state));
   else if(!strcmp(field,"abort_status"))snprintf(buffer,sizeof buffer,"%s",s.state==Snapshot::Aborted?"Abgebrochen":"Nicht bestätigt");
   else return false;

   if(!next.put(j++,buffer)) return false;
 }
 if(j!=31) return false;
 f=next;
 return true;
}
struct Bridge {
 Snapshot current;
 Frame frame;
 bool has_current;
 enum Result { AcceptedFull,AcceptedUpdate,Duplicate,Rejected };
 Bridge():has_current(false){}
 Result accept(const Snapshot& s){
  Frame candidate;
  if(!project(s,candidate))return Rejected;
  bool full=!has_current;
  if(has_current){
   if(s.session<current.session)return Rejected;
   if(s.session==current.session){
    if(s.sequence<current.sequence)return Rejected;
    if(s.sequence==current.sequence)return sv04next221::same(s,current)?Duplicate:Rejected;
    if(current.sequence==UINT32_MAX||s.sequence!=current.sequence+1)return Rejected;
   } else {
    if(s.state!=Snapshot::Ready||s.sequence!=1)return Rejected;
    full=true;
   }
  }
  current=s;frame=candidate;has_current=true;
  if(s.state==Snapshot::Error||s.state==Snapshot::Aborted||s.state==Snapshot::Unknown)full=true;
  return full?AcceptedFull:AcceptedUpdate;
 }
 static bool touch_allowed(unsigned){return false;}
 static bool hardware_ready(){return false;}
};
} // namespace sv04next223
