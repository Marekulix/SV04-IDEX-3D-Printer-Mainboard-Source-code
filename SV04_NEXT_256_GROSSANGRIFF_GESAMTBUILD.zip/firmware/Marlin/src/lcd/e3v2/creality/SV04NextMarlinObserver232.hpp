#pragma once
// SV04 NEXT 232: read-only observer of the REAL Claude-194 Marlin G29 session.
// Opt-in only. No VP writes, no G-code, no EEPROM, no M420, no temperature or motion.
#include "SV04NextClaudeHmi231.hpp"
namespace sv04next232 {
class Observer {
  sv04next231::Adapter bridge_;
  sv04next231::Result last_;
public:
  Observer() : bridge_(), last_(sv04next231::RejectedState) {}
  void begin(const uint32_t id) { last_=bridge_.begin(id); }
  void probing(const uint32_t id,const sv04next194::Session& s) {
    last_=bridge_.probing(id,0,s); // never invent a completed-point count
  }
  void finish(const uint32_t id,const sv04next194::Session& s) {
    last_=bridge_.finish(id,s);
  }
  const sv04next223::Frame* frame() const {return bridge_.frame();}
  const sv04next221::Snapshot* snapshot() const {return bridge_.snapshot();}
  sv04next231::Result last_result() const {return last_;}
  bool may_transmit_to_dwin() const {return false;}
  bool may_write_eeprom() const {return false;}
  bool may_enable_leveling() const {return false;}
};
} // namespace sv04next232
