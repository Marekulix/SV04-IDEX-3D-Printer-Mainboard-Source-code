#pragma once
// SV04 NEXT 195 - DWIN-Mesh-Anzeige: VERIFIZIERTE Konstanten und Gueltigkeitsregeln. Jede Konstante nennt ihren Beleg im ECHTEN OEM-Code.
// Dieser Header sendet NICHTS. Gesendet wird ausschliesslich ueber die OEM-Funktion rtscheck.RTS_SndData (LCD_RTS.cpp:595-628).
// Nachweisstufen: [CODE] im OEM-Quelltext belegt | [HMI-BIN] nur durch die (hier nicht vorhandene) HMI-Binaerdatei belegbar -> OFFEN.
#include <stdint.h>
#include <math.h>

namespace sv04next195 {
static const unsigned kGrid = 4;
static const unsigned kCells = 16;
static const uint16_t kMeshBaseVp = 0x1100;      // [CODE] LCD_RTS.h:72  #define AUTO_BED_LEVEL_1POINT_VP 0x1100
static const unsigned kVpStep = 2;               // [CODE] LCD_RTS.cpp:335 / G29.cpp:679  AUTO_BED_LEVEL_1POINT_VP + showcount * 2
static const int kScale = 1000;                  // [CODE] LCD_RTS.cpp:335 / G29.cpp:679  z * 1000
static const uint16_t kChangePageKeyVp = 0x110E; // [CODE] LCD_RTS.h:247 (enum PROC_COM: ChangePageKey = Index 34) + :286 (Addrbuf[34] = 0x110E)
static const float kMaxAbsMm = 30.0f;            // NEXT-Plausibilitaet (nicht OEM): +-30 mm; |z|*1000 < 32768 -> immer ein 16-Bit-Wort (LCD_RTS.cpp:601 n > 0xFFFF)

// [CODE] Serpentine wie die OEM-Sendeschleife (LCD_RTS.cpp:311-337) und die Messreihenfolge in G29.cpp:612-640 (Zeile y=0,2: x absteigend; y=1,3: x aufsteigend).
inline unsigned show_index(unsigned x, unsigned y) { return y * kGrid + ((y & 1u) ? x : (kGrid - 1u - x)); }
inline uint16_t vp_of(unsigned x, unsigned y) { return static_cast<uint16_t>(kMeshBaseVp + kVpStep * show_index(x, y)); }

// Entspricht dem OEM-Ausdruck (int)(z * 1000) (LCD_RTS.cpp:628 RTS_SndData(float) = RTS_SndData((int)n)): float*int -> float, dann Abschneiden zur Null.
inline bool cell_valid(float z) { return isfinite(z) && z >= -kMaxAbsMm && z <= kMaxAbsMm; }
inline int16_t oem_value(float z) { return static_cast<int16_t>(static_cast<int>(z * static_cast<float>(kScale))); }   // nur fuer cell_valid(z) definiert

// Referenzmodell der OEM-Frames (nur fuer Tests): 5A A5 05 82 vp_hi vp_lo hi lo  [CODE] LCD_RTS.cpp:496-548, LCD_RTS.h:12-13,28
inline void ref_frame(uint16_t vp, int16_t v, uint8_t (&f)[8]) {
  const uint16_t w = static_cast<uint16_t>(v);
  const uint8_t d[8] = {0x5A, 0xA5, 0x05, 0x82, static_cast<uint8_t>(vp >> 8), static_cast<uint8_t>(vp & 0xFFu), static_cast<uint8_t>(w >> 8), static_cast<uint8_t>(w & 0xFFu)};
  for (unsigned i = 0; i < 8; i++) f[i] = d[i];
}
// Welche Mesh-Zelle teilt ihre Adresse mit dem OEM-Eingabeschluessel ChangePageKey? (Schluessel-Rueckmeldung eines Touch-Objekts auf VP 0x110E)
inline bool cell_for_vp(uint16_t vp, unsigned &x, unsigned &y) {
  for (unsigned yy = 0; yy < kGrid; yy++) for (unsigned xx = 0; xx < kGrid; xx++) if (vp_of(xx, yy) == vp) { x = xx; y = yy; return true; }
  return false;
}
}  // namespace sv04next195
