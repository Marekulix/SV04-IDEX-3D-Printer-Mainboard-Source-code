#pragma once
#include <stdint.h>
#include <math.h>
namespace sv04next252 {
class Gate {
 uint32_t session_; bool pending_; float mesh_[16];
 static bool valid(const float* a){if(!a)return false;for(int i=0;i<16;i++)if(!isfinite(a[i])||a[i]<-10.0f||a[i]>10.0f)return false;return true;}
public:
 Gate():session_(0),pending_(false),mesh_(){}
 void clear(){session_=0;pending_=false;for(int i=0;i<16;i++)mesh_[i]=0;}
 bool begin(uint32_t id,const float* mesh){clear();if(!id||!valid(mesh))return false;session_=id;for(int i=0;i<16;i++)mesh_[i]=mesh[i];pending_=true;return true;}
 bool pending() const{return pending_;}
 bool release(uint32_t id,bool independent_eeprom_read,bool stored_leveling,const float* eeprom_mesh){
   if(!pending_||id!=session_||!independent_eeprom_read||!stored_leveling||!valid(eeprom_mesh))return false;
   for(int i=0;i<16;i++)if(fabsf(eeprom_mesh[i]-mesh_[i])>0.0011f)return false;
   clear();return true;
 }
};
}
