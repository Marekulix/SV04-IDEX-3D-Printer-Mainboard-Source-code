#pragma once
// SV04 NEXT 250: real C++ contract glue between the existing DWIN touch events,
// Auto60 transaction and accepted G29 sessions. NO actuation / EEPROM writes.
// Consumer must present actual Marlin proofs; this file never invents them.
#include "SV04NextAuto60_248.hpp"
#include "SV04NextDgus244.hpp"
#include <stdint.h>
namespace sv04next250 {
class Runtime {
  sv04next248::Auto60 sequence_;
  bool armed_, abort_latched_;
  uint32_t session_id_;
public:
  Runtime():sequence_(),armed_(false),abort_latched_(false),session_id_(0){}
  const sv04next248::Auto60& sequence() const {return sequence_;}
  bool armed() const {return armed_;}
  bool abort_requested() const {return abort_latched_;}
  // Called ONLY after a decoded DWIN press (0x3080, data word 1).
  // The provided idle flag must be a real Marlin proof.
  bool touch_start(const bool proven_machine_idle,const uint32_t now_ms) {
    if((armed_ && sequence_.phase()!=sv04next248::Failed && sequence_.phase()!=sv04next248::Cancelled) || !proven_machine_idle) return false;
    if(!sequence_.start(true,now_ms))return false;
    armed_=true;abort_latched_=false;session_id_=0;return true;
  }
  bool touch_abort() {
    if(!armed_ || !sequence_.request_cancel())return false;
    abort_latched_=true;
    return true;
  }
  bool cancel_confirmed(const bool no_motion) {
    if(!abort_latched_ || !no_motion)return false;
    if(!sequence_.cancel_confirmed(sequence_.generation(),true))return false;
    armed_=false;abort_latched_=false;session_id_=0;return true;
  }
  bool heat_dispatched(){return armed_&&!abort_latched_&&sequence_.action_dispatched(sv04next248::Heat60);}
  bool temperature(uint32_t now,float bed_actual,float bed_target){return armed_&&!abort_latched_&&sequence_.temperature(now,bed_actual,bed_target);}
  bool home_dispatched(){return armed_&&!abort_latched_&&sequence_.action_dispatched(sv04next248::HomeSafe);}
  bool homed(bool tools_safe,bool axes_homed,bool bltouch_ok){return armed_&&!abort_latched_&&sequence_.homed(sequence_.generation(),tools_safe,axes_homed,bltouch_ok);}
  bool g29_dispatched(){return armed_&&!abort_latched_&&sequence_.action_dispatched(sv04next248::Probe16);}
  bool g29_started(uint32_t id){
    if(!armed_||abort_latched_||id==0||session_id_!=0)return false;
    if(!sequence_.g29_begin(sequence_.generation(),id))return false;
    session_id_=id;return true;
  }
  bool g29_point(uint32_t id,uint8_t n){return armed_&&!abort_latched_&&id==session_id_&&sequence_.point(sequence_.generation(),id,n);}
  bool g29_finished(uint32_t id,bool success,bool g29_closed,bool dryrun,bool faux,const float *mesh){
    if(!armed_||abort_latched_||id!=session_id_)return false;
    return sequence_.g29_complete(sequence_.generation(),id,success,g29_closed,dryrun,faux,mesh);
  }
  bool enable_dispatched(){return armed_&&!abort_latched_&&sequence_.action_dispatched(sv04next248::EnableLeveling);}
  bool leveling_proven(bool true_marlin_state){return armed_&&!abort_latched_&&sequence_.leveling_enabled(sequence_.generation(),true_marlin_state);}
  bool store_dispatched(){return armed_&&!abort_latched_&&sequence_.action_dispatched(sv04next248::StoreEeprom);}
  bool stored(bool settings_save_returned_success){return armed_&&!abort_latched_&&sequence_.eeprom_stored(sequence_.generation(),settings_save_returned_success);}
  bool readback_dispatched(){return armed_&&!abort_latched_&&sequence_.action_dispatched(sv04next248::ReadbackEeprom);}
  bool verified_readback(bool truly_independent_read,const float *read_mesh,bool leveling_saved){
    if(!armed_||abort_latched_)return false;
    if(!sequence_.eeprom_readback(sequence_.generation(),truly_independent_read,read_mesh,leveling_saved))return false;
    armed_=false;return true;
  }
  bool poll_watchdog(uint32_t now_ms){if(!armed_)return true;const bool ok=sequence_.watchdog(now_ms);if(!ok)armed_=false;return ok;}
  void mark_action_time(uint32_t now_ms){sequence_.mark_action_time(now_ms);}
  void external_fault(){sequence_.emergency_fault();armed_=false;abort_latched_=false;session_id_=0;}
};
}
