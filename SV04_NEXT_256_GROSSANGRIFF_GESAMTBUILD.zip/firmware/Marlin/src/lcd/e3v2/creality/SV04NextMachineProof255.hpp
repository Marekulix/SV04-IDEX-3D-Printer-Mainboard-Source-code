#pragma once
// SV04 NEXT 255: firmware backend for the previously unresolved Machine factory.
// Completion is accepted ONLY from instrumented Marlin completion sites.
// Nothing is inferred from queue-empty, elapsed time, or command submission.
// This is intentionally NOT proof of IDEX safety, persistent EEPROM readback,
// or a functioning motion abort until those modules call the proof hooks.
#include "SV04NextMarlinAdapter254.hpp"
#include <stdint.h>
namespace sv04next255 {
struct Commands {
  virtual bool machine_idle_and_idex_parked()=0;
  virtual bool enqueue_g28()=0;
  virtual bool enqueue_g29()=0;
  virtual bool enable_leveling()=0;
  virtual bool store_settings()=0;
  virtual bool request_safe_abort()=0;
  virtual ~Commands(){}
};
class Backend final : public sv04next254::Machine {
  Commands &cmd_;
  uint32_t epoch_;
  bool homing_issued_,g29_issued_,enable_issued_,store_issued_,abort_issued_;
  bool home_ok_,level_ok_,store_ok_,stopped_;
  // A fresh EEPROM snapshot must be supplied by a separate persistent-storage
  // reader; this buffer is never populated from z_values[] or the active mesh.
  bool persisted_, saved_leveling_;
  float persisted_mesh_[16];
  static bool valid(const float *z) {
    if(!z)return false;
    for(unsigned i=0;i<16;i++) if(!__builtin_isfinite(z[i])||z[i]<-10.f||z[i]>10.f)return false;
    return true;
  }
public:
  explicit Backend(Commands &c):cmd_(c),epoch_(0),homing_issued_(false),g29_issued_(false),enable_issued_(false),store_issued_(false),abort_issued_(false),home_ok_(false),level_ok_(false),store_ok_(false),stopped_(false),persisted_(false),saved_leveling_(false),persisted_mesh_(){}
  // CALL whenever Auto60 starts a fresh cycle. A previous epoch's completion
  // can never be accidentally accepted after this reset.
  uint32_t new_cycle() {
    if(epoch_==UINT32_MAX)return 0;
    ++epoch_;
    homing_issued_=g29_issued_=enable_issued_=store_issued_=abort_issued_=false;
    home_ok_=level_ok_=store_ok_=stopped_=persisted_=saved_leveling_=false;
    for(unsigned i=0;i<16;i++)persisted_mesh_[i]=0.f;
    return epoch_;
  }
  uint32_t epoch() const {return epoch_;}
  bool ready_idle_and_idex_safe() override {return epoch_!=UINT32_MAX && cmd_.machine_idle_and_idex_parked();}
  bool issue_home() override {if(!epoch_||homing_issued_||!cmd_.machine_idle_and_idex_parked())return false; if(!cmd_.enqueue_g28())return false;homing_issued_=true;home_ok_=false;return true;}
  bool home_finished_with_probe_and_park_proof() override {return homing_issued_&&home_ok_;}
  bool issue_g29() override {if(!home_ok_||g29_issued_)return false;if(!cmd_.enqueue_g29())return false;g29_issued_=true;return true;}
  bool issue_enable_leveling() override {if(!g29_issued_||enable_issued_)return false;if(!cmd_.enable_leveling())return false;enable_issued_=true;return true;}
  bool leveling_actually_enabled() override {return enable_issued_&&level_ok_;}
  bool issue_eeprom_store() override {if(!level_ok_||store_issued_)return false;if(!cmd_.store_settings())return false;store_issued_=true;return true;}
  bool eeprom_store_finished_successfully() override {return store_issued_&&store_ok_;}
  bool independent_eeprom_read(float out[16],bool &saved) override {
    if(!store_ok_||!persisted_||!out)return false;
    for(unsigned i=0;i<16;i++)out[i]=persisted_mesh_[i];
    saved=saved_leveling_;return true;
  }
  bool issue_abort() override {if(!epoch_||abort_issued_)return false;if(!cmd_.request_safe_abort())return false;abort_issued_=true;stopped_=false;return true;}
  bool motion_stopped_proven() override {return abort_issued_&&stopped_;}
  // Every callback below must be called ONLY at the corresponding REAL Marlin
  // completion site, never when the command is enqueued.
  bool witness_g28_completed(uint32_t epoch,bool all_axes_homed,bool idex_parked,bool probe_ok,bool planner_idle) {
    if(epoch!=epoch_||!homing_issued_||abort_issued_||!all_axes_homed||!idex_parked||!probe_ok||!planner_idle)return false;
    home_ok_=true;return true;
  }
  bool witness_leveling_state(uint32_t epoch,bool actual_leveling_enabled){
    if(epoch!=epoch_||!enable_issued_||abort_issued_||!actual_leveling_enabled)return false;
    level_ok_=true;return true;
  }
  bool witness_settings_save_return(uint32_t epoch,bool real_success) {
    if(epoch!=epoch_||!store_issued_||abort_issued_||!real_success)return false;
    store_ok_=true;return true;
  }
  bool witness_fresh_persistent_storage(uint32_t epoch,const float mesh[16],bool saved_leveling,bool independent_read) {
    if(epoch!=epoch_||!store_ok_||abort_issued_||!independent_read||!valid(mesh))return false;
    for(unsigned i=0;i<16;i++)persisted_mesh_[i]=mesh[i];
    saved_leveling_=saved_leveling;persisted_=true;return true;
  }
  bool witness_motion_stopped(uint32_t epoch,bool g29_inactive,bool planner_idle,bool steppers_stopped){
    if(epoch!=epoch_||!abort_issued_||!g29_inactive||!planner_idle||!steppers_stopped)return false;
    stopped_=true;return true;
  }
};
} // namespace sv04next255
