#pragma once
// SV04 NEXT 194 - Waechter fuer die echte G29.cpp (RAII). Wird von G29.cpp eingebunden; die Funktionen sind in LCD_RTS.cpp definiert.
// Konfiguration (Standard in Klammern):
//   SV04NEXT_G29_FAILSAFE_194 (1)  Mesh/Raster/Faktor nach einem Fehlschlag in der Messphase auf den Stand VOR dem Lauf zuruecksetzen (nur RAM).
//   SV04NEXT_G29_RESEND_194  (= FAILSAFE)  danach das wiederhergestellte Mesh ueber die OEM-Sendeschleife erneut an das Display senden (UART).
//   SV04NEXT_G29_GUARD_LIVE_194 (1)  OEM-Live-Anzeige jedes Messpunkts nur fuer endliche Werte im Bereich +-30 mm.
// Mit allen drei auf 0 ist das Verhalten der Anzeige und des Meshs identisch zum Original (Beobachtung + Sitzungsprotokoll bleiben).
#include <stdint.h>
#ifndef SV04NEXT_G29_FAILSAFE_194
  #define SV04NEXT_G29_FAILSAFE_194 1
#endif
#ifndef SV04NEXT_G29_RESEND_194
  #define SV04NEXT_G29_RESEND_194 SV04NEXT_G29_FAILSAFE_194
#endif
#ifndef SV04NEXT_G29_GUARD_LIVE_194
  #define SV04NEXT_G29_GUARD_LIVE_194 1
#endif
extern uint32_t SV04Next_G29Begin194();
extern void SV04Next_G29Probing194(const uint32_t id);
extern void SV04Next_G29Complete194(const uint32_t id, const bool successful, const bool dryrun, const bool faux);
extern void SV04Next_G29Abort194(const uint32_t id);
extern void SV04Next_SendCellLive194(const float z, const int index);

struct SV04Next_G29Guard194 {
  uint32_t id_;
  bool done_;
  SV04Next_G29Guard194() : id_(SV04Next_G29Begin194()), done_(false) {}
  ~SV04Next_G29Guard194() { if (!done_) SV04Next_G29Abort194(id_); }      // jeder Ausstieg ohne finish(): G29_RETURN, Fehlerpfade, break
  void probing() { SV04Next_G29Probing194(id_); }
  void finish(const bool successful, const bool dryrun, const bool faux) { done_ = true; SV04Next_G29Complete194(id_, successful, dryrun, faux); }
 private:
  SV04Next_G29Guard194(const SV04Next_G29Guard194 &);                    // nicht kopierbar (C++11-kompatibel ohne = delete)
  SV04Next_G29Guard194 &operator=(const SV04Next_G29Guard194 &);
};
