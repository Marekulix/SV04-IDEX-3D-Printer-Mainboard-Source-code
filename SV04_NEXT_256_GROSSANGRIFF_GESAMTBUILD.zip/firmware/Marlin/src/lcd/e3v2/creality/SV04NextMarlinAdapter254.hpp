#pragma once
// SV04 NEXT 254: one bounded adapter for REAL Auto60 actions and proofs.
// Runtime is the existing 248/250 controller, not a second state machine.
// A sent command is NEVER proof of completed homing/G29/save/readback.
// C++11 no heap. Backend must implement the machine-specific attestations.
#include "SV04NextRuntime250.hpp"
#include <stdint.h>
namespace sv04next254 {
using sv04next248::Action;
using sv04next248::Phase;
struct Machine {
  virtual bool ready_idle_and_idex_safe() = 0;
  virtual bool issue_home() = 0;  // queues G28 once, no synthetic completion
  virtual bool home_finished_with_probe_and_park_proof() = 0;
  virtual bool issue_g29() = 0;   // queues G29 once, 194/251 own point callbacks
  virtual bool issue_enable_leveling() = 0;
  virtual bool leveling_actually_enabled() = 0;
  virtual bool issue_eeprom_store() = 0;
  virtual bool eeprom_store_finished_successfully() = 0;
  // Must reload from NONVOLATILE storage, not z_values[] or stale RAM copy.
  virtual bool independent_eeprom_read(float mesh_serpentine[16],bool &leveling_saved) = 0;
  // Do not claim STOP succeeded just because the operator requested it.
  virtual bool issue_abort() = 0;
  virtual bool motion_stopped_proven() = 0;
  virtual ~Machine() {}
};
class Adapter {
  sv04next250::Runtime &rt_;
  Machine &m_;
  bool issued_, abort_issued_;
  Phase last_;
  uint32_t generation_;
  void sync(){
    const Phase p=rt_.sequence().phase();
    if(p!=last_ || rt_.sequence().generation()!=generation_){
      issued_=false;abort_issued_=false;last_=p;generation_=rt_.sequence().generation();
    }
  }
public:
  Adapter(sv04next250::Runtime &rt,Machine &m):rt_(rt),m_(m),issued_(false),abort_issued_(false),last_(sv04next248::Idle),generation_(0){}
  bool touch_start(uint32_t now){
    if(!m_.ready_idle_and_idex_safe())return false;
    const bool ok=rt_.touch_start(true,now);sync();return ok;
  }
  bool touch_abort(){const bool ok=rt_.touch_abort();sync();return ok;}
  void tick(uint32_t now){
    if(!rt_.poll_watchdog(now)){sync();return;}
    sync();
    if(!rt_.armed())return;
    const Phase p=rt_.sequence().phase();
    if(p==sv04next248::AwaitHome){
      if(!issued_){
        if(!m_.ready_idle_and_idex_safe() || !m_.issue_home()){rt_.external_fault();sync();return;}
        if(!rt_.home_dispatched()){rt_.external_fault();sync();return;}
        rt_.mark_action_time(now);issued_=true;
      }
      // Homing proof comes only after an actual G28 completion attestation.
      if(m_.home_finished_with_probe_and_park_proof()){
        if(!rt_.homed(true,true,true))rt_.external_fault();
        sync();
      }
    }
    else if(p==sv04next248::AwaitG29){
      if(!issued_){
        if(!m_.issue_g29() || !rt_.g29_dispatched()){rt_.external_fault();sync();return;}
        rt_.mark_action_time(now);issued_=true;
      }
      // G29 start/points/completion come EXCLUSIVELY from G29.cpp callbacks.
    }
    else if(p==sv04next248::CheckingMesh){
      if(!issued_){
        if(!m_.issue_enable_leveling() || !rt_.enable_dispatched()){rt_.external_fault();sync();return;}
        rt_.mark_action_time(now);issued_=true;
      }
      if(m_.leveling_actually_enabled()){
        if(!rt_.leveling_proven(true)) rt_.external_fault();
        sync();
      }
    }
    else if(p==sv04next248::AwaitStore){
      if(!issued_){
        if(!m_.issue_eeprom_store() || !rt_.store_dispatched()){rt_.external_fault();sync();return;}
        rt_.mark_action_time(now);issued_=true;
      }
      if(m_.eeprom_store_finished_successfully()){
        if(!rt_.stored(true)) rt_.external_fault();
        sync();
      }
    }
    else if(p==sv04next248::AwaitReadback){
      if(!issued_){
        if(!rt_.readback_dispatched()){rt_.external_fault();sync();return;}
        rt_.mark_action_time(now);issued_=true;
      }
      float mesh[16];bool leveling_saved=false;
      if(m_.independent_eeprom_read(mesh,leveling_saved)){
        if(!rt_.verified_readback(true,mesh,leveling_saved)) rt_.external_fault();
        sync();
      }
    }
    else if(p==sv04next248::CancelRequested){
      if(!abort_issued_){
        if(!m_.issue_abort()){rt_.external_fault();sync();return;}
        rt_.mark_action_time(now);abort_issued_=true;
      }
      if(m_.motion_stopped_proven()){
        if(!rt_.cancel_confirmed(true)) rt_.external_fault();
        sync();
      }
    }
  }
};
} // namespace sv04next254
