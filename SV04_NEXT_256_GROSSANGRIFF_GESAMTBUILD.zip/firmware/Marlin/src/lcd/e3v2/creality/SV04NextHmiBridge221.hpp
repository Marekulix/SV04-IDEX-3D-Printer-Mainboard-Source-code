#pragma once
// SV04 NEXT 221. Host C++11 HMI projection. NO HARDWARE ACTUATION.
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
namespace sv04next221 {
enum Kind : uint8_t { Display=0, Touch=1 };
struct Binding { const char* view; const char* field; Kind kind; };
static const Binding kBindings[38] = {
 {"overview","title",Display},
 {"overview","status",Display},
 {"overview","start",Touch},
 {"overview","back",Touch},
 {"temperature","bed_actual",Display},
 {"temperature","bed_target",Display},
 {"temperature","stability",Display},
 {"temperature","back",Touch},
 {"progress","current_point",Display},
 {"progress","count",Display},
 {"progress","percent",Display},
 {"progress","abort",Touch},
 {"mesh","cell_00",Display},
 {"mesh","cell_01",Display},
 {"mesh","cell_02",Display},
 {"mesh","cell_03",Display},
 {"mesh","cell_04",Display},
 {"mesh","cell_05",Display},
 {"mesh","cell_06",Display},
 {"mesh","cell_07",Display},
 {"mesh","cell_08",Display},
 {"mesh","cell_09",Display},
 {"mesh","cell_10",Display},
 {"mesh","cell_11",Display},
 {"mesh","cell_12",Display},
 {"mesh","cell_13",Display},
 {"mesh","cell_14",Display},
 {"mesh","cell_15",Display},
 {"mesh","back",Touch},
 {"result","measured",Display},
 {"result","mesh_enabled",Display},
 {"result","eeprom_written",Display},
 {"result","eeprom_verified",Display},
 {"result","back",Touch},
 {"error","error_code",Display},
 {"error","error_text",Display},
 {"error","abort_status",Display},
 {"error","back",Touch}
};
static_assert(sizeof(kBindings)/sizeof(kBindings[0])==38,"binding count");
struct Snapshot {
 uint32_t session, sequence;
 enum State:uint8_t { Ready, Heating, Stabilizing, Homing, Probing, Validating,
   Measured, Enabled, Saved, Verified, Error, Aborted, Unknown } state;
 int16_t actual_c10, target_c10;
 bool actual_set, target_set;
 uint8_t completed;
 float mesh[16];
 bool mesh_present, mesh_confirmed, enabled_confirmed, write_confirmed, readback_confirmed;
 char error_code[41], error_text[81];
 Snapshot():session(0),sequence(0),state(Ready),actual_c10(0),target_c10(0),
 actual_set(false),target_set(false),completed(0),mesh_present(false),mesh_confirmed(false),
 enabled_confirmed(false),write_confirmed(false),readback_confirmed(false) {
 for(unsigned i=0;i<16;i++) mesh[i]=0;
 error_code[0]=0;error_text[0]=0;
 }
};
// Fixed maximum lengths: text never allocates on heap.
struct DisplayValue { char value[96]; };
struct Frame { uint32_t session,sequence; Snapshot::State state; DisplayValue display[31]; };
static_assert(sizeof(DisplayValue)==96,"fixed field");
inline bool valid(const Snapshot& s) {
 if(!s.session||!s.sequence||s.completed>16) return false;
 if(s.state>Snapshot::Unknown) return false;
 if((s.actual_set && (s.actual_c10< -500||s.actual_c10>3000)) ||
    (s.target_set && (s.target_c10< -500||s.target_c10>3000))) return false;
 if(!memchr(s.error_code,0,sizeof(s.error_code)) || !memchr(s.error_text,0,sizeof(s.error_text))) return false;
 if(s.mesh_present) for(unsigned i=0;i<16;i++) if(!isfinite(s.mesh[i])||s.mesh[i]<-10||s.mesh[i]>10) return false;
 if(s.mesh_confirmed && (!s.mesh_present||s.completed!=16)) return false;
 if(s.enabled_confirmed&&!s.mesh_confirmed) return false;
 if(s.write_confirmed&&!s.enabled_confirmed) return false;
 if(s.readback_confirmed&&!s.write_confirmed) return false;
 if((s.state==Snapshot::Verified&&!s.readback_confirmed)||
    (s.state==Snapshot::Saved&&!s.write_confirmed)||
    (s.state==Snapshot::Enabled&&!s.enabled_confirmed))return false;
 if((s.state==Snapshot::Error||s.state==Snapshot::Aborted||s.state==Snapshot::Unknown)&&s.mesh_confirmed)return false;
 if(s.state!=Snapshot::Error&&s.state!=Snapshot::Aborted&&s.state!=Snapshot::Unknown&& (s.error_code[0]||s.error_text[0]))return false;
 return true;
}
inline const char* status(Snapshot::State s){
 static const char* const t[]={"Bereit","Bett aufheizen","Temperatur stabilisieren","Referenzfahrt","Vermessung laeuft","Messwerte pruefen","Messung abgeschlossen - nicht gespeichert","Mesh aktiviert - nicht gespeichert","EEPROM-Schreiben bestaetigt - Ruecklesen offen","EEPROM-Ruecklesen bestaetigt","Steuerung meldet Fehler","Messung abgebrochen","Kommunikation unklar - Status unbekannt"};return t[(unsigned)s];
}
inline void write_text(Frame& f,unsigned idx,const char* s){snprintf(f.display[idx].value,sizeof(f.display[idx].value),"%s",s);}
inline bool project(const Snapshot& s,Frame& f){
 if(!valid(s))return false;
 Frame next={};next.session=s.session;next.sequence=s.sequence;next.state=s.state;
 unsigned j=0;
 for(unsigned i=0;i<38;i++){
   if(kBindings[i].kind==Touch) continue;
   const char* field=kBindings[i].field;
   char buffer[96]={0};
   if(!strcmp(field,"title")) snprintf(buffer,sizeof buffer,"Bettvermessung 60 C");
   else if(!strcmp(field,"status")) snprintf(buffer,sizeof buffer,"%s",status(s.state));
   else if(!strcmp(field,"bed_actual")) {if(s.actual_set) snprintf(buffer,sizeof buffer,"%.1f C",s.actual_c10/10.0);else snprintf(buffer,sizeof buffer,"-");}
   else if(!strcmp(field,"bed_target")) {if(s.target_set) snprintf(buffer,sizeof buffer,"%.1f C",s.target_c10/10.0);else snprintf(buffer,sizeof buffer,"-");}
   else if(!strcmp(field,"stability")) snprintf(buffer,sizeof buffer,"%s",s.state!=Snapshot::Ready&&s.state!=Snapshot::Heating&&s.state!=Snapshot::Unknown?"Bestaetigt":"Nicht bestaetigt");
   else if(!strcmp(field,"current_point")) {if(s.state==Snapshot::Probing)snprintf(buffer,sizeof buffer,"%u",(unsigned)(s.completed<16?s.completed+1:16));else snprintf(buffer,sizeof buffer,"-");}
   else if(!strcmp(field,"count")) snprintf(buffer,sizeof buffer,"%u/16",(unsigned)s.completed);
   else if(!strcmp(field,"percent")) snprintf(buffer,sizeof buffer,"%u %%",(unsigned)(s.completed*100/16));
   else if(!strncmp(field,"cell_",5)) {unsigned n=(unsigned)(field[5]-'0')*10+(unsigned)(field[6]-'0');if(n>15)return false;if(s.mesh_confirmed)snprintf(buffer,sizeof buffer,"%+.3f mm",(double)s.mesh[n]);else snprintf(buffer,sizeof buffer,"-");}
   else if(!strcmp(field,"measured"))snprintf(buffer,sizeof buffer,"%s",s.mesh_confirmed?"Ja":"Nein");
   else if(!strcmp(field,"mesh_enabled"))snprintf(buffer,sizeof buffer,"%s",s.enabled_confirmed?"Ja":"Nein");
   else if(!strcmp(field,"eeprom_written"))snprintf(buffer,sizeof buffer,"%s",s.write_confirmed?"Ja":"Nein");
   else if(!strcmp(field,"eeprom_verified"))snprintf(buffer,sizeof buffer,"%s",s.readback_confirmed?"Ja":"Nein");
   else if(!strcmp(field,"error_code"))snprintf(buffer,sizeof buffer,"%s",s.error_code[0]?s.error_code:"-");
   else if(!strcmp(field,"error_text"))snprintf(buffer,sizeof buffer,"%s",s.error_text[0]?s.error_text:status(s.state));
   else if(!strcmp(field,"abort_status"))snprintf(buffer,sizeof buffer,"%s",s.state==Snapshot::Aborted?"Abgebrochen":"Nicht bestaetigt");
   else return false;
   write_text(next,j++,buffer);
 }
 if(j!=31)return false;
 f=next;return true;
}
inline bool same(const Snapshot& a,const Snapshot& b){
 // Compare every semantically meaningful field, not uninitialized struct padding.
 if(a.session!=b.session||a.sequence!=b.sequence||a.state!=b.state||a.actual_c10!=b.actual_c10||a.target_c10!=b.target_c10||a.actual_set!=b.actual_set||a.target_set!=b.target_set||a.completed!=b.completed||a.mesh_present!=b.mesh_present||a.mesh_confirmed!=b.mesh_confirmed||a.enabled_confirmed!=b.enabled_confirmed||a.write_confirmed!=b.write_confirmed||a.readback_confirmed!=b.readback_confirmed||strcmp(a.error_code,b.error_code)||strcmp(a.error_text,b.error_text))return false;
 if(a.mesh_present)for(unsigned i=0;i<16;i++)if(a.mesh[i]!=b.mesh[i])return false;
 return true;
}
struct Bridge {
 Snapshot current;Frame frame;bool has_current;
 enum Result { AcceptedFull,AcceptedUpdate,Duplicate,Rejected };
 Bridge():has_current(false){}
 Result accept(const Snapshot& s){
  Frame candidate={};if(!project(s,candidate))return Rejected;
  bool full=!has_current;
  if(has_current){
   if(s.session<current.session)return Rejected;
   if(s.session==current.session){
    if(s.sequence<current.sequence)return Rejected;
    if(s.sequence==current.sequence)return same(s,current)?Duplicate:Rejected;
    if(current.sequence==UINT32_MAX||s.sequence!=current.sequence+1)return Rejected;
   } else {
    if(s.state!=Snapshot::Ready||s.sequence!=1)return Rejected;
    full=true;
   }
  }
  current=s;frame=candidate;has_current=true;
  if(s.state==Snapshot::Error||s.state==Snapshot::Aborted||s.state==Snapshot::Unknown)full=true;
  return full?AcceptedFull:AcceptedUpdate;
 }
 static bool touch_allowed(unsigned){return false;}
 static bool hardware_ready(){return false;}
};
} // namespace sv04next221
