#pragma once
// SV04 NEXT 255: True callback receipts from Marlin G28 / M500 / M501.
// A command being queued is NEVER evidence of its successful completion.
// Session-linked receipts cannot be replayed into a later Auto60 generation.
// No heater, stepper, EEPROM or DWIN commands are issued by this header.
#include <stdint.h>
#include <math.h>
namespace sv04next255 {
struct Proof {
  uint32_t generation, home_token, store_token, read_token, level_token;
  bool home_issued, store_issued, read_issued, level_issued, home_ok, store_ok, read_ok, read_leveling, level_ok, level_seen;
  bool home_seen, store_seen, read_seen;
  float eeprom_mesh[16];
  Proof():generation(0),home_token(0),store_token(0),read_token(0),
    home_issued(false),store_issued(false),read_issued(false),level_issued(false),home_ok(false),store_ok(false),read_ok(false),read_leveling(false),level_ok(false),level_seen(false),
    home_seen(false),store_seen(false),read_seen(false),eeprom_mesh(){}
  void reset(uint32_t gen) {
    generation=gen;home_issued=store_issued=read_issued=level_issued=false;
    home_ok=store_ok=read_ok=read_leveling=level_ok=level_seen=false;
    home_seen=store_seen=read_seen=false;
    home_token=store_token=read_token=level_token=0;
    for(unsigned i=0;i<16;i++)eeprom_mesh[i]=0;
  }
  bool arm_home(uint32_t gen,uint32_t token) {
    if(gen==0||gen!=generation||token==0||home_issued)return false;
    home_issued=true;home_token=token;home_seen=false;home_ok=false;return true;
  }
  bool g28_complete(uint32_t gen,uint32_t token,bool all_axes_homed,bool idex_parked,bool probe_valid) {
    if(!home_issued||home_seen||gen!=generation||token!=home_token)return false;
    home_seen=true;home_ok=all_axes_homed&&idex_parked&&probe_valid;
    return home_ok;
  }
  bool home_proven(uint32_t gen) const {return home_issued&&home_seen&&home_ok&&gen==generation;}
  bool arm_leveling(uint32_t gen,uint32_t token){
    if(gen==0||gen!=generation||token==0||level_issued||!home_proven(gen))return false;
    level_issued=true;level_token=token;level_seen=level_ok=false;return true;
  }
  bool m420_complete(uint32_t gen,uint32_t token,bool actually_enabled){
    if(!level_issued||level_seen||gen!=generation||token!=level_token)return false;
    level_seen=true;level_ok=actually_enabled;return level_ok;
  }
  bool leveling_proven(uint32_t gen) const {return level_issued&&level_seen&&level_ok&&gen==generation;}
  bool arm_store(uint32_t gen,uint32_t token){
    if(gen==0||gen!=generation||token==0||store_issued)return false;
    store_issued=true;store_token=token;store_seen=false;store_ok=false;return true;
  }
  bool m500_complete(uint32_t gen,uint32_t token,bool settings_save_result){
    if(!store_issued||store_seen||gen!=generation||token!=store_token)return false;
    store_seen=true;store_ok=settings_save_result;return store_ok;
  }
  bool saved(uint32_t gen)const{return store_issued&&store_seen&&store_ok&&gen==generation;}
  bool arm_read(uint32_t gen,uint32_t token){
    if(gen==0||gen!=generation||token==0||read_issued||!saved(gen))return false;
    read_issued=true;read_token=token;read_seen=false;read_ok=false;return true;
  }
  bool m501_complete(uint32_t gen,uint32_t token,bool real_settings_load_result,
                     const float *mesh_serpentine,bool leveling_saved){
    if(!read_issued||read_seen||gen!=generation||token!=read_token)return false;
    read_seen=true;read_ok=false;
    if(!real_settings_load_result||!mesh_serpentine||!leveling_saved)return false;
    for(unsigned i=0;i<16;i++)
      if(!isfinite(mesh_serpentine[i])||mesh_serpentine[i]<-10.0f||mesh_serpentine[i]>10.0f)return false;
    for(unsigned i=0;i<16;i++)eeprom_mesh[i]=mesh_serpentine[i];
    read_leveling=leveling_saved;read_ok=true;return true;
  }
  bool readback(uint32_t gen,float out[16],bool &leveling)const {
    if(gen!=generation||!read_issued||!read_seen||!read_ok||!out)return false;
    for(unsigned i=0;i<16;i++)out[i]=eeprom_mesh[i];
    leveling=read_leveling;return true;
  }
  void invalidate(){reset(0);}
};
} // namespace sv04next255
