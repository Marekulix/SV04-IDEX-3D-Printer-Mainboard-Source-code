#pragma once
// SV04 NEXT 245: one fail-closed, no-heap integration contract for real Marlin call sites.
// This class does not initiate heating, homing, probing, G-code or EEPROM writing.
// A touch is an observed REQUEST, never authorization to start unsafe motion.
#include "SV04NextDgus244.hpp"
#include <stdint.h>
namespace sv04next245 {
using namespace sv04next244;
enum State : uint8_t { Closed, StartPage, Requested, Measuring, AbortPending, Result, Aborted, Error };
class Controller {
  State state_;
  uint32_t id_;
  bool requested_, active_, confirmed_;
  uint8_t points_;
  float mesh_[16];
public:
  Controller():state_(Closed),id_(0),requested_(false),active_(false),confirmed_(false),points_(0),mesh_(){}
  State state() const {return state_;}
  bool requested() const {return requested_;}
  bool active() const {return active_;}
  bool confirmed() const {return confirmed_;}
  uint8_t points() const {return points_;}
  uint32_t session() const {return id_;}
  bool show_start(Writer& w) {
    if(active_) return false;
    requested_=false;confirmed_=false;points_=0;state_=StartPage;
    w.change_page(PAGE_START);return true;
  }
  // The caller must already have decoded an allowed DGUS press with value 1.
  // START only sets a pending request: it deliberately does not send M190/G28/G29.
  bool touch(TouchResult t,Writer& w) {
    if(t==StartRequested && state_==StartPage && !active_) {
      requested_=true;confirmed_=false;state_=Requested;return true;
    }
    if(t==AbortRequested && state_==Requested && !active_) {
      // No real G29 started: cancel the pending request immediately.
      requested_=false;confirmed_=false;state_=Aborted;w.change_page(PAGE_ABORT);return true;
    }
    if(t==AbortRequested && state_==Measuring && active_) {
      // Request only. G29 must be cancelled by a separately validated Marlin abort path.
      requested_=false;confirmed_=false;state_=AbortPending;return true;
    }
    if(t==BackRequested && !active_ && (state_==Aborted||state_==Error||state_==Result))
      return show_start(w);
    return false;
  }
  // G29 has actually started under Claude's session gate. No invented session id.
  bool begin(uint32_t id,Writer &w) {
    if(!requested_ || active_ || id==0 || id<=id_)return false;
    id_=id;requested_=false;active_=true;confirmed_=false;points_=0;
    state_=Measuring;w.change_page(PAGE_RUNNING);return true;
  }
  // Progress indication alone is NOT proof of a complete G29 session.
  bool point(uint32_t id,uint8_t p,Writer& w) {
    if(!active_||state_!=Measuring||id!=id_||p==0||p>16||p<points_)return false;
    points_=p;
    // Existing version 243 numeric object 0x3004 on running page.
    w.write_word(0x3004,p);return true;
  }
  bool finish(uint32_t id,bool accepted,bool g29_closed,const float *mesh,Writer& w) {
    if(id==0||id!=id_||!active_)return false;
    const bool abort_was_requested = state_==AbortPending;
    active_=false;requested_=false;confirmed_=false;
    if(abort_was_requested||!accepted||!g29_closed||mesh==0){state_=Error;w.change_page(PAGE_ERROR);return false;}
    uint16_t words[16];
    if(!encode_mesh(mesh,words)){state_=Error;w.change_page(PAGE_ERROR);return false;}
    for(unsigned i=0;i<16;i++)mesh_[i]=mesh[i];
    // All 16 prevalidated: transactional relative to input; physical DWIN writes
    // may still fail (no transport ACK in the OEM protocol).
    for(unsigned i=0;i<16;i++)w.write_word(uint16_t(RESULT_MESH_BASE+2*i),words[i]);
    state_=Result;confirmed_=true;points_=16;w.change_page(PAGE_RESULT);return true;
  }
  bool abort(uint32_t id,Writer& w) {
    if(id==0||id!=id_||!active_)return false;
    active_=false;requested_=false;confirmed_=false;points_=0;
    state_=Aborted;w.change_page(PAGE_ABORT);return true;
  }
  // No safety claim: this gate protects the NEW pages, not the OEM display buffer.
  bool allow_eeprom_write() const {return false;}
  bool allow_leveling_enable() const {return false;}
  bool allow_motor_action() const {return false;}
};
}
