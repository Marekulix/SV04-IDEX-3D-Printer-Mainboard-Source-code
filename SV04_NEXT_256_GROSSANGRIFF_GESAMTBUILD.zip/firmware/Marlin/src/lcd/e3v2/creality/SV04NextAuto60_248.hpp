#pragma once
// SV04 NEXT 248: bounded, event-driven Auto60 transaction controller.
// There is NO G-code dispatch in this module. An adapter must acknowledge EACH
// requested action with trusted Marlin state before calling the next event.
// The saved EEPROM mesh is never declared verified merely on successful M500.
// C++11; no heap, no Arduino/Marlin dependencies.
#include <stdint.h>
#include <math.h>
namespace sv04next248 {
enum Phase : uint8_t {
  Idle, AwaitHeat, Stabilizing, AwaitHome, AwaitG29, CheckingMesh,
  AwaitEnable, AwaitStore, AwaitReadback, Verified, Failed, CancelRequested, Cancelled
};
enum Action : uint8_t { None, Heat60, HomeSafe, Probe16, EnableLeveling, StoreEeprom, ReadbackEeprom, StopRequested };
enum Failure : uint8_t { NoError, NotIdle, BadTemperature, HeatTimeout, BadHome, BadG29, InvalidMesh,
                           BadEnable, BadStore, BadReadback, CancelledByOperator, StaleEvent, ActionTimeout, CancelTimeout };
class Auto60 {
  Phase phase_;
  Failure failure_;
  Action pending_;
  uint32_t generation_, active_g29_;
  uint32_t heat_start_, stable_since_, action_since_;
  bool heat_dispatched_, g29_started_;
  uint8_t points_;
  float mesh_[16];
  bool measured_, enabled_, stored_, verified_;
  static bool valid_mesh(const float *mesh) {
    if(!mesh) return false;
    for(unsigned i=0;i<16;i++) if(!isfinite(mesh[i]) || mesh[i] < -10.0f || mesh[i] > 10.0f) return false;
    return true;
  }
  void fail(const Failure f) {failure_=f;phase_=Failed;pending_=None;heat_dispatched_=false;g29_started_=false;measured_=enabled_=stored_=verified_=false;points_=0;}
public:
  Auto60():phase_(Idle),failure_(NoError),pending_(None),generation_(0),active_g29_(0),
    heat_start_(0),stable_since_(0),action_since_(0),heat_dispatched_(false),g29_started_(false),points_(0),mesh_(),measured_(false),enabled_(false),stored_(false),verified_(false){}
  Phase phase() const {return phase_;}
  Failure failure() const {return failure_;}
  Action pending() const {return pending_;}
  uint32_t generation() const {return generation_;}
  uint8_t points() const {return points_;}
  bool mesh_validated() const {return measured_;}
  bool eeprom_verified() const {return verified_;}
  // `machine_idle` MUST be an external proof, not a UI-only claim.
  bool start(const bool machine_idle,const uint32_t now_ms) {
    if(phase_!=Idle && phase_!=Failed && phase_!=Cancelled && phase_!=Verified)return false;
    if(!machine_idle){fail(NotIdle);return false;}
    if(generation_==UINT32_MAX){fail(StaleEvent);return false;}
    ++generation_;active_g29_=0;points_=0;measured_=enabled_=stored_=verified_=false;
    failure_=NoError;heat_start_=now_ms;stable_since_=0;action_since_=now_ms;heat_dispatched_=false;g29_started_=false;phase_=AwaitHeat;pending_=Heat60;return true;
  }
  // Acknowledgement of submitting a Heat60 action, not proof that bed is warm.
  bool action_dispatched(Action a){
    if(a==None||a!=pending_)return false;
    if(a==Heat60)heat_dispatched_=true;
    pending_=None;return true;
  }
  // Periodic watchdog: compare elapsed time using unsigned wrap-safe subtraction.
  // Caller MUST invoke this even when no other events arrive.
  bool watchdog(const uint32_t now_ms){
    if(phase_==Idle||phase_==Verified||phase_==Failed||phase_==Cancelled)return true;
    const uint32_t elapsed=static_cast<uint32_t>(now_ms-action_since_);
    if(phase_==AwaitHeat||phase_==Stabilizing){
      if(static_cast<uint32_t>(now_ms-heat_start_)>900000u){fail(HeatTimeout);return false;}
      return true;
    }
    if(phase_==CancelRequested){
      if(elapsed>120000u){fail(CancelTimeout);return false;}
      return true;
    }
    if(elapsed>900000u){fail(ActionTimeout);return false;}
    return true;
  }
  // After each action completion the host supplies a fresh monotonic timestamp.
  // No timer is inferred from temperature or probe callbacks.
  void mark_action_time(const uint32_t now_ms){action_since_=now_ms;}
  // Stable 60C +/- 1C over >= 30 seconds, timeout after 15min.
  bool temperature(const uint32_t now_ms,const float actual_c,const float target_c) {
    if((phase_!=AwaitHeat && phase_!=Stabilizing)||!heat_dispatched_) return false;
    if(!isfinite(actual_c)||!isfinite(target_c)||actual_c<0||actual_c>150||target_c<59||target_c>61){fail(BadTemperature);return false;}
    if(static_cast<uint32_t>(now_ms-heat_start_)>900000u){fail(HeatTimeout);return false;}
    if(actual_c<59.0f||actual_c>61.0f){phase_=AwaitHeat;stable_since_=0;return true;}
    if(phase_==AwaitHeat){phase_=Stabilizing;stable_since_=now_ms;return true;}
    if(static_cast<uint32_t>(now_ms-stable_since_)>=30000u){phase_=AwaitHome;pending_=HomeSafe;}
    return true;
  }
  bool homed(const uint32_t gen,const bool tool_parked,const bool axes_homed,const bool probe_ok) {
    if(gen!=generation_ ||phase_!=AwaitHome||pending_!=None)return false;
    if(!tool_parked||!axes_homed||!probe_ok){fail(BadHome);return false;}
    phase_=AwaitG29;pending_=Probe16;return true;
  }
  bool g29_begin(const uint32_t gen,const uint32_t g29_id){
    if(gen!=generation_||phase_!=AwaitG29||pending_!=None||g29_id==0||g29_started_)return false;
    active_g29_=g29_id;g29_started_=true;return true;
  }
  bool point(const uint32_t gen,const uint32_t g29_id,const uint8_t n){
    if(gen!=generation_||phase_!=AwaitG29||active_g29_!=g29_id||!g29_started_||n!=points_+1||n>16)return false;
    points_=n;return true;
  }
  bool g29_complete(const uint32_t gen,const uint32_t g29_id,const bool success,const bool closed,
                    const bool dryrun,const bool faux,const float *mesh){
    if(gen!=generation_||phase_!=AwaitG29||active_g29_!=g29_id||!g29_started_)return false;
    if(!success||!closed||dryrun||faux||points_!=16||!valid_mesh(mesh)){fail(BadG29);return false;}
    for(unsigned i=0;i<16;i++)mesh_[i]=mesh[i];
    measured_=true;phase_=CheckingMesh;pending_=EnableLeveling;return true;
  }
  bool leveling_enabled(const uint32_t gen,const bool proof){
    if(gen!=generation_||phase_!=CheckingMesh||pending_!=None)return false;
    if(!proof){fail(BadEnable);return false;}
    enabled_=true;phase_=AwaitStore;pending_=StoreEeprom;return true;
  }
  bool eeprom_stored(const uint32_t gen,const bool success){
    if(gen!=generation_||phase_!=AwaitStore||pending_!=None)return false;
    if(!success){fail(BadStore);return false;}
    stored_=true;phase_=AwaitReadback;pending_=ReadbackEeprom;return true;
  }
  // Values MUST come from a new, independent EEPROM read, never the RAM mesh.
  bool eeprom_readback(const uint32_t gen,const bool independently_read,const float *read_mesh,
                       const bool leveling_saved){
    if(gen!=generation_||phase_!=AwaitReadback||pending_!=None)return false;
    if(!independently_read||!leveling_saved||!valid_mesh(read_mesh)){fail(BadReadback);return false;}
    for(unsigned i=0;i<16;i++)if(fabsf(read_mesh[i]-mesh_[i])>0.0011f){fail(BadReadback);return false;}
    verified_=true;phase_=Verified;return true;
  }
  // Request only. A real Marlin cancellation/stop must be proven separately.
  bool request_cancel(){
    if(phase_==Verified||phase_==Failed||phase_==Cancelled||phase_==Idle)return false;
    phase_=CancelRequested;pending_=StopRequested;measured_=enabled_=stored_=verified_=false;return true;
  }
  bool cancel_confirmed(const uint32_t gen,const bool no_active_motion){
    if(gen!=generation_||phase_!=CancelRequested||!no_active_motion)return false;
    pending_=None;phase_=Cancelled;failure_=CancelledByOperator;return true;
  }
  void emergency_fault(){fail(BadG29);}
};
}
