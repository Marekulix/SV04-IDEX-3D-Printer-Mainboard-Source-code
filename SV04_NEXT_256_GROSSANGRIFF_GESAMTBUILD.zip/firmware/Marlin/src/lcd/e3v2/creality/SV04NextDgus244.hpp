#pragma once
// SV04 NEXT 244: DGUS touch receiver + accepted-mesh display publisher.
// C++11, no dynamic allocation. Does not control G29, temperature, motors, M420 or EEPROM.
#include <stdint.h>
#include <math.h>
namespace sv04next244 {
static const uint16_t START=0x3080, ABORT=0x3082, BACK_ABORT=0x3084,
 BACK_ERROR=0x3086, BACK_RESULT=0x3088;
static const uint16_t RESULT_MESH_BASE=0x3020;
static const uint8_t PAGE_START=59, PAGE_RUNNING=60, PAGE_ABORT=61,
 PAGE_ERROR=62, PAGE_RESULT=63;
enum TouchResult { NotOurs, RejectedValue, StartRequested, AbortRequested, BackRequested };
struct TouchState {
 uint32_t start_count,abort_count,back_count;
 TouchState():start_count(0),abort_count(0),back_count(0){}
 // Counts are OBSERVATION ONLY. Not authorization to heat, move, or launch G29.
 TouchResult receive(uint16_t vp,uint16_t value){
  if(vp!=START&&vp!=ABORT&&vp!=BACK_ABORT&&vp!=BACK_ERROR&&vp!=BACK_RESULT) return NotOurs;
  if(value!=1) return RejectedValue;
  if(vp==START){++start_count;return StartRequested;}
  if(vp==ABORT){++abort_count;return AbortRequested;}
  ++back_count;return BackRequested;
 }
};
struct Writer {
 virtual void write_word(uint16_t vp,uint16_t raw)=0;
 virtual void change_page(uint8_t page)=0;
 virtual ~Writer(){}
};
// Adopts only confirmed *already accepted* 4x4 mesh, serpentine in view order.
// Atomic validation before any write. Signed 16bit scale x1000 with round-to-nearest.
inline bool encode_mesh(const float mesh[16],uint16_t out[16]){
 int16_t tmp[16];
 for(unsigned i=0;i<16;++i){
  const float mm=mesh[i];
  if(!isfinite(mm)||mm < -30.0f||mm > 30.0f)return false;
  const float scaled=mm*1000.0f;
  const long n=(long)(scaled>=0 ? floorf(scaled+0.5f):ceilf(scaled-0.5f));
  if(n<-32768L||n>32767L)return false;
  tmp[i]=(int16_t)n;
 }
 for(unsigned i=0;i<16;++i)out[i]=(uint16_t)tmp[i];
 return true;
}
inline bool publish_confirmed_mesh(Writer &w,bool accepted,bool session_open,
                                   const float mesh[16]){
 if(!accepted||session_open||mesh==0)return false;
 uint16_t encoded[16];
 if(!encode_mesh(mesh,encoded))return false;
 for(unsigned i=0;i<16;++i)w.write_word((uint16_t)(RESULT_MESH_BASE+2*i),encoded[i]);
 w.change_page(PAGE_RESULT);
 return true;
}
inline void publish_abort(Writer &w){w.change_page(PAGE_ABORT);}
inline void publish_error(Writer &w){w.change_page(PAGE_ERROR);}
} // namespace sv04next244
