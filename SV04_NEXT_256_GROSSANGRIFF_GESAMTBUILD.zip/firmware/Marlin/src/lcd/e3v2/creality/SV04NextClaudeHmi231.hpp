#pragma once
// SV04 NEXT 231: offline-only adapter from Claude 194 validated G29 sessions to
// the 223 HMI data contract. NO Marlin hooks, serial writes, G-code or EEPROM.
#include "SV04NextG29Session194.hpp"
#include "SV04NextDwinDisplay195.hpp"
#include "SV04NextHmiBridge223.hpp"
#include <stdint.h>
namespace sv04next231 {
  using sv04next221::Snapshot;
  enum Result { Accepted, RejectedStale, RejectedState, RejectedInvalid, RejectedHmi };
  class Adapter {
    uint32_t last_id_, sequence_, last_event_seq_;
    bool active_, terminal_;
    sv04next223::Frame frame_;
    Snapshot snapshot_;
    bool has_frame_;
    Result publish(const Snapshot& next) {
      sv04next223::Frame candidate;
      if (!sv04next223::project(next,candidate)) return RejectedHmi;
      snapshot_=next;frame_=candidate;has_frame_=true;sequence_=next.sequence;
      return Accepted;
    }
   public:
    Adapter():last_id_(0),sequence_(0),last_event_seq_(0),active_(false),terminal_(false),frame_(),snapshot_(),has_frame_(false){}
    Result begin(uint32_t id) {
      if (id==0 || id<=last_id_) return RejectedStale;
      // Invalidate before starting a new session: never expose an old mesh.
      has_frame_=false;active_=true;terminal_=false;last_id_=id;sequence_=0;
      Snapshot s; s.session=id;s.sequence=1;s.state=Snapshot::Ready;
      return publish(s);
    }
    Result probing(uint32_t id,uint8_t completed,const sv04next194::Session& session) {
      if(!active_||terminal_||id!=last_id_)return RejectedStale;
      if(session.active_id()!=id || !session.probing_reached())return RejectedState;
      if(completed>15||sequence_==UINT32_MAX)return RejectedInvalid;
      Snapshot s; s.session=id;s.sequence=sequence_+1;s.state=Snapshot::Probing;s.completed=completed;
      return publish(s);
    }
    // The caller MUST have called Claude Session::complete before calling finish.
    // A successful boolean supplied by UI alone is NOT evidence of success.
    Result finish(uint32_t id,const sv04next194::Session& session) {
      if(!active_||terminal_||id!=last_id_)return RejectedStale;
      sv04next194::Event event;
      if(!session.event(0,event)||event.id!=id||event.seq<=last_event_seq_)return RejectedState;
      sv04next194::MeshState accepted;
      const bool confirmed=event.outcome==sv04next194::OUT_ACCEPTED &&
             !session.session_open() && session.accepted_id()==id && session.snapshot(accepted);
      Snapshot s; s.session=id;
      if(sequence_==UINT32_MAX)return RejectedInvalid;
      s.sequence=sequence_+1;
      if(confirmed){
        // Deliberately use OEM serpentine viewing order, not x/y memory order.
        s.state=Snapshot::Measured;s.completed=16;s.mesh_present=true;s.mesh_confirmed=true;
        for(unsigned y=0;y<4;++y)for(unsigned x=0;x<4;++x)
          s.mesh[sv04next195::show_index(x,y)]=accepted.z[x][y];
      } else {
        s.state=(event.outcome==sv04next194::OUT_ABORTED_EARLY||event.outcome==sv04next194::OUT_ABORTED_PROBING)
          ? Snapshot::Aborted : Snapshot::Error;
        // No previously saved mesh or speculative EEPROM proof is inherited.
        const char* code= s.state==Snapshot::Aborted ? "G29_ABORT" : "G29_REJECT";
        const char* detail="G29 ohne bestaetigtes Mesh";
        for(unsigned i=0;code[i]&&i<40;++i)s.error_code[i]=code[i];
        for(unsigned i=0;detail[i]&&i<80;++i)s.error_text[i]=detail[i];
      }
      const Result result=publish(s);
      if(result==Accepted){terminal_=true;active_=false;last_event_seq_=event.seq;}
      return result;
    }
    Result abort(uint32_t id,const sv04next194::Session& session){return finish(id,session);}
    const sv04next223::Frame* frame() const{return has_frame_?&frame_:nullptr;}
    const Snapshot* snapshot() const{return has_frame_?&snapshot_:nullptr;}
    bool hardware_ready() const{return false;}
    bool touch_allowed(unsigned) const{return false;}
    bool permitted_eeprom_write() const{return false;}
    bool permitted_m420() const{return false;}
  };
}
