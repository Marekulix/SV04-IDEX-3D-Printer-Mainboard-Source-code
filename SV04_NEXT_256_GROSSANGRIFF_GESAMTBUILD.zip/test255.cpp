#include "firmware/Marlin/src/lcd/e3v2/creality/SV04NextRealProof255.hpp"
#include <cassert>
#include <cstdio>
#include <limits>
int main(){using sv04next255::Proof; unsigned n=0;Proof p;float m[16],out[16];for(int i=0;i<16;i++)m[i]=i*0.03f;bool l=false;
 for(unsigned gen=1;gen<=256;++gen){p.reset(gen);
  assert(!p.home_proven(gen));++n;
  assert(!p.arm_home(gen+1,11));++n;
  assert(p.arm_home(gen,11));++n;
  assert(!p.arm_home(gen,12));++n;
  assert(!p.g28_complete(gen,12,true,true,true));++n;
  assert(!p.g28_complete(gen+1,11,true,true,true));++n;
  assert(p.g28_complete(gen,11,true,true,true));++n;
  assert(p.home_proven(gen));++n;
  assert(!p.g28_complete(gen,11,true,true,true));++n;
  assert(!p.arm_leveling(gen+1,20));++n;
  assert(p.arm_leveling(gen,20));++n;
  assert(!p.m420_complete(gen,21,true));++n;
  assert(!p.leveling_proven(gen));++n;
  assert(p.m420_complete(gen,20,true));++n;
  assert(p.leveling_proven(gen));++n;
  assert(!p.m420_complete(gen,20,true));++n;
  assert(!p.arm_read(gen,31));++n;
  assert(p.arm_store(gen,21));++n;
  assert(!p.m500_complete(gen,22,true));++n;
  assert(p.m500_complete(gen,21,true));++n;
  assert(p.saved(gen));++n;
  assert(!p.m500_complete(gen,21,true));++n;
  assert(p.arm_read(gen,31));++n;
  assert(!p.m501_complete(gen,32,true,m,true));++n;
  assert(!p.m501_complete(gen,31,false,m,true));++n;
  assert(!p.readback(gen,out,l));++n;
  p.reset(gen);
  assert(!p.readback(gen,out,l));++n;
  assert(p.arm_home(gen,11));++n;
  assert(!p.g28_complete(gen,11,true,false,true));++n;
  assert(!p.home_proven(gen));++n;
  p.reset(gen);
  assert(p.arm_home(gen,11));++n;
  assert(p.g28_complete(gen,11,true,true,true));++n;
  assert(p.arm_leveling(gen,20));++n;
  assert(!p.m420_complete(gen,20,false));++n;
  assert(!p.leveling_proven(gen));++n;
  p.reset(gen);
  assert(p.arm_store(gen,21));++n;
  assert(!p.m500_complete(gen,21,false));++n;
  assert(!p.saved(gen));++n;
  p.reset(gen);
  assert(p.arm_store(gen,21));++n;
  assert(p.m500_complete(gen,21,true));++n;
  assert(p.arm_read(gen,31));++n;
  float bad[16];for(int j=0;j<16;j++)bad[j]=m[j];bad[3]=std::numeric_limits<float>::quiet_NaN();
  assert(!p.m501_complete(gen,31,true,bad,true));++n;
  assert(!p.readback(gen,out,l));++n;
  p.reset(gen);assert(p.arm_store(gen,21));++n;assert(p.m500_complete(gen,21,true));++n;assert(p.arm_read(gen,31));++n;
  assert(p.m501_complete(gen,31,true,m,true));++n;assert(p.readback(gen,out,l));++n;assert(l);++n;
  for(int j=0;j<16;j++){assert(m[j]==out[j]);++n;}
  assert(!p.readback(gen+1,out,l));++n;p.invalidate();assert(!p.readback(gen,out,l));++n;
 }
 printf("SV04 NEXT 255 real-event proof: %u assertions PASS (host only)\n",n);
}
