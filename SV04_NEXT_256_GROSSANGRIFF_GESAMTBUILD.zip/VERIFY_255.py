from pathlib import Path
import hashlib, subprocess, json, zipfile
root=Path(__file__).parent
marlin=root/'firmware/Marlin/src'
lcd=(marlin/'lcd/e3v2/creality/LCD_RTS.cpp').read_text()
g29=(marlin/'gcode/bedlevel/abl/G29.cpp').read_text()
proof=(marlin/'lcd/e3v2/creality/SV04NextRealProof255.hpp').read_text()
checks={
 'actual_LCD_RTS_has_backend': 'class SV04NextRealBackend255 :' in lcd,
 'actual_G29_has_cooperative_abort': 'if (SV04Next_G29StopRequested255()) G29_RETURN(false);' in g29,
 'actual_M500_receipt': 'void SV04Next_M500Finished255(bool saved)' in lcd,
 'actual_M420_receipt': 'void SV04Next_M420Finished255(bool leveling)' in lcd,
 'actual_M501_receipt': 'void SV04Next_M501Finished255(bool loaded' in lcd,
 'actual_G28_receipt': 'void SV04Next_G28Finished255(bool axes_homed' in lcd,
 'no_unproven_quickstop': 'quickstop_stepper();' not in lcd.split('class SV04NextRealBackend255 :',1)[1].split('static SV04NextRealBackend255 &',1)[0] and 'quickstop_stepper();' not in g29,
 'compile_off_by_default': '#define SV04NEXT_REAL_BACKEND_255 0' in lcd,
 'requires_original_gcode_hooks': 'SV04NEXT_PROOF_HOOKS_255' in lcd,
 'readback_nonvolatile_load': 'settings.load()' in (root/'install_marlin_hooks255.py').read_text(),
 'homing_state_from_real_marlin': 'active_extruder_parked' in (root/'install_marlin_hooks255.py').read_text(),
}
assert all(checks.values()),{k:v for k,v in checks.items() if not v}
print('SOURCE AUDIT:',len(checks),'checks PASS')
print(json.dumps(checks,indent=2))
