#!/usr/bin/env python3
"""Provenance and object checks. Never claim the new image library exists."""
import argparse,pathlib,subprocess,json,hashlib,sys,zipfile
p=argparse.ArgumentParser();p.add_argument('touchscreen_checkout',type=pathlib.Path);p.add_argument('--out',type=pathlib.Path,required=True);a=p.parse_args()
ref='5a3fae8c1ccdc04fb3372c077a61394e8a66ece4'
root=a.touchscreen_checkout
files={'DWIN_SET/13TouchFile.bin':'5f4184bb99aa9746165f660822d7891542173674',
'DWIN_SET/14ShowFile.bin':'844abd88422f98c5201245f4c1fb0ac78009112c',
'DWIN_SET/32_main.icl':'a326351036311e197c20947aa0e2bf867904a389',
'DWprj.hmi':'f7b60b6cae57b12eb109ceb37b833d7f38aa4b7d'}
result={'version':256,'original_ref':ref,'new_icl_compiled':False,'new_display_release':False,'objects_original':{},'original_icl_hash_ok':False,'status':'FAILED'}
try:
 actual=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()
 if actual!=ref:raise ValueError('DWIN OEM revision mismatch: '+actual)
 for f,expected in files.items():
  path=root/f
  if not path.is_file():raise ValueError('Missing '+f)
  got=subprocess.check_output(['git','-C',str(root),'hash-object',f],text=True).strip()
  result['objects_original'][f]={'bytes':path.stat().st_size,'expected_git_blob':expected,'actual_git_blob':got,'ok':got==expected}
  if got!=expected:raise ValueError('Blob mismatch: '+f)
 result['original_icl_hash_ok']=True
 orig=(root/'DWIN_SET/14ShowFile.bin').read_bytes()
 overlay=pathlib.Path(__file__).parent/'dwin/14ShowFile.bin'
 assert orig.startswith(b'\x14DGUS_2') and overlay.read_bytes().startswith(b'\x14DGUS_2')
 o=overlay.read_bytes()
 vps=set()
 for i in range(0,len(o)-24):
  if o[i:i+2]==b'\x5a\x10':
   vp=int.from_bytes(o[i+6:i+8],'big')
   if 0x1100<=vp<=0x111e and vp%2==0:vps.add(vp)
 if len(vps)!=16:raise ValueError('16 OEM mesh VPs not present in overlay')
 result['overlay_mesh_vps_count']=len(vps)
 result['new_icl_compiled']=False
 result['status']='EVIDENCE_OK_NOT_RELEASEABLE'
except Exception as e:result['error']=str(e)
a.out.parent.mkdir(parents=True,exist_ok=True)
a.out.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'status':result['status'],'error':result.get('error')}))
sys.exit(0 if result['status']=='EVIDENCE_OK_NOT_RELEASEABLE' else 1)
