# SV04 NEXT 255 — echte G28-Abschlussstelle und fehlendes Proof-Backend

**NICHT FLASHEN. KEINE INSTALLIERBARE FIRMWARE.**

## Konkret neu implementiert
- `SV04NextMachineProof255.hpp`: konkrete Implementierung der zuvor nur deklarierten `Machine`-Schnittstelle mit Sitzungs-Epochen, G28-, Leveling-, M500-, EEPROM-Rücklese- und Abbruchbestätigungen. Ereignisse älterer Sitzungen werden abgelehnt; ein abgeschickter Befehl ist nie eine Erfolgsbestätigung.
- `LCD_RTS.cpp`: bisher fehlende `SV04Next_MachineProofBackend254()`-Implementierung, fünf explizite Hooks, Epoch-Reset nach bestätigtem Start, keine künstlichen Erfolgswerte.
- `G28.cpp`: erstmals aus Claudes OEM_REFERENCE extrahiert und nach dem echten Homing-Ende ein opt-in-Callback mit tatsächlich ermitteltem `!axes_should_home()` ergänzt. Der Callback wird nicht im `G28 S`-Simulationspfad aufgerufen.
- `test255.cpp`: negatives und positives Testen von Epochen, ungültigen EEPROM-Messwerten, G28-/Store-/Abbruchbestätigungen sowie Wiederanlauf.

## Zwingende und ehrliche Einschränkungen
- Der konkrete `SV04NextLockedCommands255`-Backend verweigert absichtlich ALLE Maschinenaktionen und jede angebliche IDEX-Freigabe. Sein Vorhandensein beseitigt den fehlenden C++-Factory-Einstieg, aber es ist **KEINE fertige Maschinensteuerung**.
- Die G28-Endmeldung beweist nur die Achs-Homing-Flags, **nicht** Parkposition von T1 oder BLTouch-Status. Bis unabhängige echte APIs dafür integriert sind, wird `false` übergeben und Auto60 bleibt gesperrt.
- `witness_settings_save_return` und `witness_fresh_persistent_storage` akzeptieren künftig echte Belege. Die eigentlichen `settings.cpp`/persistentStore-Quellen und der sichere EEPROM-Rohlesepfad sind nicht im vorliegenden Archiv enthalten. Sie sind NICHT verbunden.
- Bewegungsabbruch benötigt einen realen sicheren Marlin-Abbruchpfad. `request_safe_abort` bleibt gesperrt.
- Der Compiler-Schalter `SV04NEXT_G28_END_PROOF_255` ist default 0. Die Auto60-Maschinenschalter bleiben wie in 254 default 0.
- **Es wurde KEIN STM32-Build durchgeführt**; im Archiv fehlen `platformio.ini`, die vollständigen Module und ARM-Toolchain. Nur die explizit protokollierten Hosttests sind durchgelaufen.
- DWIN-Bildbibliothek wird hier nicht als fertig behauptet.

## Nachgewiesene Hosttests
- 255 Proof-Backend mit `-std=c++11 -Wall -Wextra -Werror -pedantic` und UBSan bestanden
- 254 Aktionstest 266 Prüfungen bestanden
- 253 Host 12/12 bestanden
- 251 G29 65.572 bestanden
- 250 Runtime 65.621 bestanden
- 248 Auto60 150.069 bestanden
- Quellcode-Audit: Callback exakt einmal am erfolgreichen G28-Endpfad, nach bestehendem RTS-Homing-Aufruf.

## Nächste tatsächlich notwendigen Implementierungen
1. Sichere verifizierte T1-Parkposition und echte BLTouch-/Achsenbereitschaft aus dem OEM-Marlin, nicht aus der DWIN-Grafik.
2. Komplett instrumentierter G28-/G29- und Bewegungsabbruchpfad mit echten Abschlussrückmeldungen.
3. Persistenter EEPROM-Rohlesepfad mit Vergleich statt live RAM-Cache (inklusive Prüfung des OEM-Layouts).
4. Echte DWIN-Bildressource und STM32-Gesamtbuild, dann kontrollierter Hardwaretest.

Basis 254 bleibt als eigenes ZIP unverändert. Keine Firmwareflash-Freigabe.
