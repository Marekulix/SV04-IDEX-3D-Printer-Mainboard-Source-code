#!/usr/bin/env python3
"""Run all available local regressions without masking failures."""
import pathlib,subprocess,json,sys,shutil,time
p=pathlib.Path(__file__).resolve().parent
logs=pathlib.Path(sys.argv[1]);logs.mkdir(parents=True,exist_ok=True)
results=[]
def check(label,command):
 t=time.monotonic()
 try:
  r=subprocess.run(command,cwd=p,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
  code=r.returncode;body=r.stdout
 except Exception as e:code=127;body=str(e)
 (logs/(label+'.log')).write_text(body)
 results.append({'name':label,'returncode':code,'duration_seconds':round(time.monotonic()-t,2),'command':command})
 print(label,'PASS' if code==0 else 'FAIL',flush=True)
for n in ['244','245','246','248','250','251','252','253','254','255']:
 f=p/'tests'/('test'+n+'.cpp')
 if not f.exists():
  if n=='255':f=p/'test255.cpp'
 if not f.exists():continue
 out='/tmp/sv04next256_test'+n
 compiler=['g++','-std=c++11','-O1','-Wall','-Wextra','-Werror','-pedantic','-I',str(p/'tests'),'-I',str(p/'firmware/Marlin/src/lcd/e3v2/creality'),str(f),'-o',out]
 check('compile_'+n,compiler)
 if results[-1]['returncode']==0:check('run_'+n,[out])
check('source_audit_256',['python3',str(p/'current_source_audit256.py')])
check('source_integrity_249',['python3',str(p/'tests/test_integrity249.py')])
# Historical test_release247/test_source246 target V246, not V255; the old
# VERIFY_255.py targets an unmerged alternate proof backend. Do not misreport
# those incompatible assumptions as a current regression failure.
(logs/'historical_tests_not_applicable.txt').write_text(
 'NOT APPLICABLE: test_source246.py, test_release247.py (V246-specific contract); '
 'test_integration245.py (requires V244 ZIP at a hardcoded local path); '
 'VERIFY_255.py (expects an alternative real-backend implementation not present in actual V255 overlay).\n')
(logs/'results.json').write_text(json.dumps({'tests':results,'passed':sum(x['returncode']==0 for x in results),'failed':sum(x['returncode']!=0 for x in results)},indent=2))
sys.exit(1 if any(x['returncode'] for x in results) else 0)
