#include "../firmware/Marlin/src/lcd/e3v2/creality/SV04NextMarlinAdapter254.hpp"
#include <cassert>
#include <cstdio>
using namespace sv04next254;
using namespace sv04next248;
struct Fake : Machine {
 bool idle=true,home_ok=false,enable_ok=false,stored_ok=false,read_ok=false,stop_ok=false;
 bool wrong_mesh=false,fail_issue=false;
 unsigned homes=0,g29s=0,enables=0,stores=0,reads=0,stops=0;
 bool ready_idle_and_idex_safe(){return idle;}
 bool issue_home(){++homes;return !fail_issue;}
 bool home_finished_with_probe_and_park_proof(){return home_ok;}
 bool issue_g29(){++g29s;return !fail_issue;}
 bool issue_enable_leveling(){++enables;return !fail_issue;}
 bool leveling_actually_enabled(){return enable_ok;}
 bool issue_eeprom_store(){++stores;return !fail_issue;}
 bool eeprom_store_finished_successfully(){return stored_ok;}
 bool independent_eeprom_read(float m[16],bool &lv){++reads;if(!read_ok)return false;for(int i=0;i<16;i++)m[i]=float(i)*0.1f; if(wrong_mesh)m[7]+=0.5f;lv=true;return true;}
 bool issue_abort(){++stops;return !fail_issue;}
 bool motion_stopped_proven(){return stop_ok;}
};
int main(){
 unsigned checks=0;
 sv04next250::Runtime r;Fake f;Adapter a(r,f);
 f.idle=false;assert(!a.touch_start(10));++checks;
 f.idle=true;assert(a.touch_start(10));++checks;
 a.tick(11);assert(r.sequence().pending()==Heat60);++checks; // temperature actuator handled by 253
 assert(r.heat_dispatched());++checks;
 assert(r.temperature(12,60,60));++checks;
 assert(r.temperature(30013,60,60));++checks;
 assert(r.sequence().phase()==AwaitHome);++checks;
 a.tick(30014);assert(f.homes==1);++checks;
 for(unsigned i=0;i<100;i++){a.tick(30015+i);assert(f.homes==1);++checks;}
 assert(r.sequence().phase()==AwaitHome);++checks;
 f.home_ok=true;a.tick(30130);assert(r.sequence().phase()==AwaitG29);++checks;
 a.tick(30131);assert(f.g29s==1);++checks;
 for(unsigned i=0;i<100;i++){a.tick(30132+i);assert(f.g29s==1);++checks;}
 assert(r.g29_started(12));++checks;
 float mesh[16];for(int i=0;i<16;i++){mesh[i]=float(i)*0.1f;assert(r.g29_point(12,uint8_t(i+1)));++checks;}
 assert(r.g29_finished(12,true,true,false,false,mesh));++checks;
 a.tick(30240);assert(f.enables==1);++checks;
 a.tick(30241);assert(f.enables==1);++checks;
 assert(r.sequence().phase()==CheckingMesh);++checks;
 f.enable_ok=true;a.tick(30242);assert(r.sequence().phase()==AwaitStore);++checks;
 a.tick(30243);assert(f.stores==1);++checks;
 a.tick(30244);assert(f.stores==1);++checks;
 assert(!r.sequence().eeprom_verified());++checks;
 f.stored_ok=true;a.tick(30245);assert(r.sequence().phase()==AwaitReadback);++checks;
 a.tick(30246);assert(f.reads==1);++checks;
 assert(!r.sequence().eeprom_verified());++checks;
 f.read_ok=true;a.tick(30247);assert(r.sequence().phase()==Verified);++checks;
 assert(r.sequence().eeprom_verified());++checks;
 assert(f.homes==1&&f.g29s==1&&f.enables==1&&f.stores==1);++checks;
 assert(a.touch_start(40000));++checks;
 assert(r.heat_dispatched());++checks;
 assert(r.temperature(40001,60,60));++checks;
 assert(r.temperature(70002,60,60));++checks;
 a.tick(70003);assert(f.homes==2);++checks;
 assert(a.touch_abort());++checks;
 a.tick(70004);assert(f.stops==1);++checks;
 a.tick(70005);assert(f.stops==1);++checks;
 assert(r.sequence().phase()==CancelRequested);++checks;
 f.stop_ok=true;a.tick(70006);assert(r.sequence().phase()==Cancelled);++checks;
 assert(!r.sequence().eeprom_verified());++checks;
 // Failure to queue an action fails closed.
 f.fail_issue=true;f.stop_ok=false;f.home_ok=false;
 assert(a.touch_start(80000));++checks;
 assert(r.heat_dispatched());++checks;
 assert(r.temperature(80001,60,60));++checks;
 assert(r.temperature(110002,60,60));++checks;
 a.tick(110003);assert(r.sequence().phase()==Failed);++checks;
 // Independent readback cannot be fabricated from the RAM mesh.
 sv04next250::Runtime r2;Fake f2;Adapter a2(r2,f2);
 assert(a2.touch_start(1));++checks;assert(r2.heat_dispatched());++checks;
 assert(r2.temperature(2,60,60));++checks;assert(r2.temperature(30003,60,60));++checks;
 a2.tick(30004);f2.home_ok=true;a2.tick(30005);a2.tick(30006);
 assert(r2.g29_started(1));++checks;
 for(int i=0;i<16;i++)assert(r2.g29_point(1,uint8_t(i+1)));
 assert(r2.g29_finished(1,true,true,false,false,mesh));++checks;
 a2.tick(30007);f2.enable_ok=true;a2.tick(30008);a2.tick(30009);f2.stored_ok=true;a2.tick(30010);a2.tick(30011);f2.read_ok=true;f2.wrong_mesh=true;a2.tick(30012);
 assert(r2.sequence().phase()==Failed);++checks;
 assert(!r2.sequence().eeprom_verified());++checks;
 std::printf("SV04 254 action handshake: %u checks PASS (HOST ONLY)\n",checks);
}
