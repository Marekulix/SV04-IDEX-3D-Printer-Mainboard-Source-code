#include "../firmware/Marlin/src/lcd/e3v2/creality/SV04NextMachineProof255.hpp"
#include <assert.h>
#include <math.h>
#include <stdio.h>
struct Fake:sv04next255::Commands {
 bool safe=true;int home=0,g29=0,level=0,store=0,abort=0;
 bool machine_idle_and_idex_parked()override{return safe;}
 bool enqueue_g28()override{++home;return true;}
 bool enqueue_g29()override{++g29;return true;}
 bool enable_leveling()override{++level;return true;}
 bool store_settings()override{++store;return true;}
 bool request_safe_abort()override{++abort;return true;}
};
int main(){Fake f;sv04next255::Backend b(f);float a[16],v[16];bool enabled=false;for(int i=0;i<16;++i)a[i]=(float)i/100.f;
 assert(!b.issue_home());auto e=b.new_cycle();assert(e==1);assert(b.ready_idle_and_idex_safe());
 assert(b.issue_home());assert(f.home==1);assert(!b.issue_home());assert(!b.home_finished_with_probe_and_park_proof());
 assert(!b.witness_g28_completed(e,false,true,true,true));assert(!b.witness_g28_completed(e,true,true,true,false));
 assert(!b.witness_g28_completed(e-1,true,true,true,true));assert(b.witness_g28_completed(e,true,true,true,true));
 assert(b.home_finished_with_probe_and_park_proof());assert(b.issue_g29());assert(!b.issue_g29());
 assert(b.issue_enable_leveling());assert(!b.leveling_actually_enabled());assert(!b.witness_leveling_state(e-1,true));assert(b.witness_leveling_state(e,true));
 assert(b.issue_eeprom_store());assert(!b.eeprom_store_finished_successfully());assert(!b.witness_settings_save_return(e,false));
 assert(b.witness_settings_save_return(e,true));assert(!b.independent_eeprom_read(v,enabled));
 assert(!b.witness_fresh_persistent_storage(e,a,true,false));a[0]=NAN;assert(!b.witness_fresh_persistent_storage(e,a,true,true));a[0]=0;
 assert(!b.witness_fresh_persistent_storage(e-1,a,true,true));assert(b.witness_fresh_persistent_storage(e,a,true,true));
 assert(b.independent_eeprom_read(v,enabled));assert(enabled);for(int i=0;i<16;++i)assert(a[i]==v[i]);
 auto e2=b.new_cycle();assert(e2==2);assert(!b.independent_eeprom_read(v,enabled));assert(!b.home_finished_with_probe_and_park_proof());
 assert(!b.witness_settings_save_return(e,true));assert(!b.witness_g28_completed(e,true,true,true,true));
 f.safe=false;assert(!b.ready_idle_and_idex_safe());assert(!b.issue_home());f.safe=true;
 assert(b.issue_home());assert(b.issue_abort());assert(!b.motion_stopped_proven());assert(!b.witness_motion_stopped(e2,true,true,false));
 assert(!b.witness_motion_stopped(e,true,true,true));assert(b.witness_motion_stopped(e2,true,true,true));assert(b.motion_stopped_proven());
 assert(!b.witness_g28_completed(e2,true,true,true,true));
 puts("PASS: 255 backend / proof epochs / real-event gates / stale, abort, EEPROM, no synthetic completion");
}
