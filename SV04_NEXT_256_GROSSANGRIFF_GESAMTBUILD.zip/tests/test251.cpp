#include "../firmware/Marlin/src/lcd/e3v2/creality/SV04NextRuntime250.hpp"
#include <cassert>
#include <cstdio>
#include <cmath>
static void ready(sv04next250::Runtime &r) {
 assert(r.touch_start(true,10));assert(r.heat_dispatched());
 assert(r.temperature(11,60,60));assert(r.temperature(30012,60,60));
 assert(r.home_dispatched());assert(r.homed(true,true,true));
 assert(r.g29_dispatched());assert(r.g29_started(42));
}
int main(){
 sv04next250::Runtime r;ready(r);float m[16];
 unsigned checks=0;
 for(int i=0;i<16;++i){m[i]=float(i-8)*0.125f;assert(r.g29_point(42,(uint8_t)(i+1)));++checks;}
 assert(r.g29_finished(42,true,true,false,false,m));++checks;
 assert(r.sequence().phase()==sv04next248::CheckingMesh);++checks;
 // Negative, failure and stale session cannot bypass the 16-point contract.
 sv04next250::Runtime bad;ready(bad);
 for(int i=0;i<15;++i){assert(bad.g29_point(42,(uint8_t)(i+1)));++checks;}
 assert(!bad.g29_finished(42,true,true,false,false,m));++checks;
 assert(!bad.g29_point(123,16));++checks;
 bad.external_fault();assert(bad.sequence().phase()==sv04next248::Failed);++checks;
 for(int i=0;i<65536;++i){
    const auto v=sv04next244::TouchState().receive((uint16_t)i,1);
    if(i!=0x3080&&i!=0x3082&&i!=0x3084&&i!=0x3086&&i!=0x3088)assert(v==sv04next244::NotOurs);
    ++checks;
 }
 printf("SV04 251 host test PASS checks=%u\n",checks);
}
