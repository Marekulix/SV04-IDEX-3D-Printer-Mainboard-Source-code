from pathlib import Path
import hashlib, re
root=Path(__file__).resolve().parents[1]
fw=root/'firmware/Marlin/src/lcd/e3v2/creality'
lcd=(fw/'LCD_RTS.cpp').read_text()
g29=(root/'firmware/Marlin/src/gcode/bedlevel/abl/G29.cpp').read_text()
auto=(fw/'SV04NextAuto60_248.hpp').read_text()
assert 'SV04NextAuto60_248.hpp' in lcd
assert 'static sv04next248::Auto60 sv04next249_auto60' in lcd
assert '#define SV04NEXT_AUTO60_249 0' in lcd
assert '#define SV04NEXT_DGUS_244 0' in lcd
assert 'SV04NEXT_DISPLAY_ICL_VERIFIED_245' in lcd
assert 'SV04NEXT_G29_DEFER_LIVE_MESH_235' in g29
assert 'SV04Next_G29Begin194' in lcd and 'SV04Next_G29Abort194' in lcd
assert 'ReadbackEeprom' in auto and 'independently_read' in auto
assert 'SV04NextAuto60_246.hpp' not in lcd
assert not (root/'dwin/32_main.icl').exists()
for name,size in [('13TouchFile.bin',7426),('14ShowFile.bin',23872)]:
 assert (root/'dwin'/name).stat().st_size==size
for p in (root/'dwin').glob('*.jpg'):
 assert p.stat().st_size>500
print('PASS: actual Marlin overlay V249 references V248 controller; release gates intact; DWIN resources not fabricated')
