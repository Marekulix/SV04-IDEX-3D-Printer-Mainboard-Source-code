import pathlib, zipfile,hashlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
LCD=(ROOT/'firmware/Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp').read_text()
G29=(ROOT/'firmware/Marlin/src/gcode/bedlevel/abl/G29.cpp').read_text()
checks=[]
def ck(name,pred):
 assert pred,name
 checks.append(name)
ck('G29 uses Claude RAII guard', 'SV04Next_G29Guard194 sv04next194_guard' in G29)
ck('G29 provisional mesh guard compiled', '#if !SV04NEXT_G29_DEFER_LIVE_MESH_235' in G29)
ck('G29 deferred-live-mesh flag defaults off', '#define SV04NEXT_G29_DEFER_LIVE_MESH_235 0' in G29)
ck('LCD session entry', 'uint32_t SV04Next_G29Begin194()' in LCD)
ck('LCD explicit completion', 'void SV04Next_G29Complete194(' in LCD)
ck('LCD explicit abort', 'void SV04Next_G29Abort194(' in LCD)
ck('LCD touch code integrated', 'sv04next245_controller.touch(tr, sv04next245_writer)' in LCD)
ck('LCD session start integrated', 'sv04next245_controller.begin(id,sv04next245_writer)' in LCD)
ck('LCD result integrated', 'sv04next245_controller.finish(id, accepted,' in LCD)
ck('LCD abort integrated', 'sv04next245_controller.abort(id,display)' in LCD)
ck('New UI disabled by default', '#define SV04NEXT_UNIFIED_245 0' in LCD)
ck('Unverified ICL stops enabled build', '#error "SV04 NEXT 245: new DWIN background ICL not verified' in LCD)
ck('Only one controller', LCD.count('static sv04next245::Controller sv04next245_controller;')==1)
ck('No extra M500 command', LCD.count('"M500"')==0)
ck('No extra M190 command', LCD.count('"M190')==0)
ck('DWIN image 59..63 exists', all((ROOT/'dwin'/f'{i}.jpg').exists() for i in range(59,64)))
ck('DWIN touch binary exists', (ROOT/'dwin'/'13TouchFile.bin').stat().st_size==7426)
ck('DWIN show binary exists', (ROOT/'dwin'/'14ShowFile.bin').stat().st_size==23872)
with zipfile.ZipFile('/mnt/data/SV04_NEXT_244_DWIN_MARLIN_TOUCH_BRIDGE_NO_FLASH.zip') as z:
 for p in ('13TouchFile.bin','14ShowFile.bin'):
  original=z.read('DWIN_SET_NICHT_FLASHEN/'+p)
  ck('DWIN '+p+' preserved',original==(ROOT/'dwin'/p).read_bytes())
for p in (ROOT/'firmware/Marlin/src/lcd/e3v2/creality').glob('*.hpp'):
 ck('header nonempty '+p.name,p.stat().st_size>100)
print(f'PASS {len(checks)} integration245 source/binary checks')
