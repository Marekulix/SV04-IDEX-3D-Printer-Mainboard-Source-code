from pathlib import Path
p=Path('firmware/Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp')
s=p.read_text()
checks={
 'Default OFF': '#define SV04NEXT_AUTO60_246 0' in s,
 'New state machine included': '#include "SV04NextAuto60_246.hpp"' in s,
 'Runtime object inserted': 'static sv04next246::Auto60 sv04next246_auto60;' in s,
 'Real session requirement': 'SV04NEXT_AUTO60_246 && !SV04NEXT_UNIFIED_245' in s,
 'No new queue dispatch': 'sv04next246_auto60.start(' not in s and 'sv04next246_auto60.action_dispatched(' not in s,
 'Original OEM G29 events remain': 'SV04Next_G29Begin194()' in s and 'SV04Next_G29Abort194(' in s,
 'Original 245 controller remains': 'sv04next245_controller.finish(' in s,
 'No new EEPROM command in 246': 'M500' not in '\n'.join(line for line in s.splitlines() if 'SV04 NEXT 246' in line),
}
for k,v in checks.items():
 print(('PASS' if v else 'FAIL'),k)
assert all(checks.values())
print('PASS 246 Marlin structural checks:',len(checks))
