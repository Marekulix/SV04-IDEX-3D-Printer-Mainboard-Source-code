#include "SV04NextUnified245.hpp"
#include <cassert>
#include <cstdio>
#include <limits>
struct Fake:sv04next244::Writer {
 unsigned writes,pages;uint16_t addrs[32],values[32];uint8_t last_page;
 Fake():writes(0),pages(0),addrs(),values(),last_page(255){}
 void write_word(uint16_t a,uint16_t v){assert(writes<32);addrs[writes]=a;values[writes++]=v;}
 void change_page(uint8_t p){last_page=p;++pages;}
};
int main(){using namespace sv04next245;unsigned checks=0;
 Fake f;Controller c;
 assert(!c.begin(1,f));++checks;
 assert(c.show_start(f)&&c.state()==StartPage&&f.last_page==59);++checks;
 assert(c.touch(StartRequested,f)&&c.requested());++checks;
 assert(!c.finish(1,true,true,0,f));++checks;
 assert(c.begin(1,f)&&c.active()&&f.last_page==60);++checks;
 assert(!c.begin(2,f));++checks;
 assert(!c.point(2,1,f));++checks;
 assert(c.point(1,1,f)&&f.addrs[0]==0x3004);++checks;
 assert(!c.point(1,0,f));++checks;
 assert(c.point(1,16,f));++checks;
 assert(!c.point(1,17,f));++checks;
 float mesh[16];for(int i=0;i<16;i++)mesh[i]=(i-8)*.125f;
 assert(c.finish(1,true,true,mesh,f)&&c.confirmed()&&f.last_page==63);++checks;
 assert(f.writes==18&&f.pages==3);++checks;
 assert(f.addrs[2]==0x3020&&f.addrs[17]==0x303e);++checks;
 assert(!c.abort(1,f));++checks;
 assert(!c.begin(1,f));++checks;
 assert(c.touch(BackRequested,f)&&c.state()==StartPage);++checks;
 assert(c.touch(StartRequested,f)&&c.begin(2,f));++checks;
 assert(c.abort(2,f)&&!c.confirmed()&&f.last_page==61);++checks;
 assert(!c.finish(2,true,true,mesh,f));++checks;
 assert(c.touch(BackRequested,f)&&c.touch(StartRequested,f)&&c.begin(3,f));++checks;
 mesh[0]=std::numeric_limits<float>::quiet_NaN();
 const unsigned before=f.writes;
 assert(!c.finish(3,true,true,mesh,f)&&!c.confirmed()&&f.last_page==62);++checks;
 assert(f.writes==before);++checks;
 assert(!c.allow_motor_action()&&!c.allow_leveling_enable()&&!c.allow_eeprom_write());++checks;
 Controller beforeG29;Fake bg;assert(beforeG29.show_start(bg));
 assert(beforeG29.touch(StartRequested,bg));
 assert(beforeG29.touch(AbortRequested,bg)&&beforeG29.state()==Aborted&&bg.last_page==61);++checks;
 assert(!beforeG29.begin(5,bg));++checks;
 Controller pending;Fake pw;assert(pending.show_start(pw));
 assert(pending.touch(StartRequested,pw)&&pending.begin(99,pw));
 const unsigned np=pw.pages;assert(pending.touch(AbortRequested,pw));
 assert(pending.state()==AbortPending&&pw.pages==np);checks+=2;
 assert(!pending.finish(99,true,true,mesh,pw));
 assert(pending.state()==Error&&!pending.confirmed()&&pw.last_page==62);checks+=2;
 Controller confirmedAbort;Fake aw;confirmedAbort.show_start(aw);confirmedAbort.touch(StartRequested,aw);
 assert(confirmedAbort.begin(100,aw)&&confirmedAbort.touch(AbortRequested,aw));
 assert(confirmedAbort.abort(100,aw)&&confirmedAbort.state()==Aborted&&aw.last_page==61);++checks;
 // 65,536 arbitrary VP presses must never grant an actuator permission.
 for(unsigned vp=0;vp<65536;vp++){
  Controller a;Fake w; a.show_start(w);
  const auto t=(vp==0x3080?StartRequested:NotOurs);
  (void)a.touch(t,w);
  assert(!a.allow_motor_action()&&!a.allow_eeprom_write());++checks;
 }
 std::printf("PASS 245 %u checks, no machine commands\n",checks);
}
