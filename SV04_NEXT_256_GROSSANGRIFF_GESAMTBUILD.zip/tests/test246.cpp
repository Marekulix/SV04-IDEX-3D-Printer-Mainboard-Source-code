#include "../firmware/Marlin/src/lcd/e3v2/creality/SV04NextAuto60_246.hpp"
#include <assert.h>
#include <stdio.h>
#include <limits>
using namespace sv04next246;
static int checks=0;
#define T(x) do { ++checks; assert(x); } while(0)
static void march(Auto60 &a,float mesh[16]){
 T(a.start(true,100));const uint32_t gen=a.generation();
 T(a.pending()==Heat60);T(a.action_dispatched(Heat60));
 T(a.temperature(100,60,60));T(a.phase()==Stabilizing);
 T(a.temperature(30101,60,60));T(a.pending()==HomeSafe);
 T(a.action_dispatched(HomeSafe));T(a.homed(gen,true,true,true));
 T(a.pending()==Probe16);T(a.action_dispatched(Probe16));
 T(a.g29_begin(gen,123));
 for(int i=1;i<=16;i++){T(a.point(gen,123,i));mesh[i-1]=i*0.02f-0.2f;}
 T(a.g29_complete(gen,123,true,true,false,false,mesh));
 T(a.pending()==EnableLeveling);T(a.action_dispatched(EnableLeveling));
 T(a.leveling_enabled(gen,true));T(a.pending()==StoreEeprom);
 T(a.action_dispatched(StoreEeprom));T(a.eeprom_stored(gen,true));
 T(a.pending()==ReadbackEeprom);T(a.action_dispatched(ReadbackEeprom));
}
int main(){
 float mesh[16]={};Auto60 a;
 T(!a.start(false,0));T(a.failure()==NotIdle);
 march(a,mesh);T(!a.eeprom_verified());
 T(!a.eeprom_readback(a.generation()-1,true,mesh,true));
 T(a.eeprom_readback(a.generation(),true,mesh,true));T(a.eeprom_verified());
 Auto60 b;float m[16]={};march(b,m);m[0]+=0.003f;
 T(!b.eeprom_readback(b.generation(),true,m,true));T(b.phase()==Failed);T(!b.eeprom_verified());
 Auto60 c;T(c.start(true,1));T(c.request_cancel());T(c.phase()==CancelRequested);
 T(!c.cancel_confirmed(c.generation(),false));T(c.cancel_confirmed(c.generation(),true));
 T(c.phase()==Cancelled);T(!c.eeprom_verified());
 Auto60 d;T(d.start(true,10));T(d.action_dispatched(Heat60));
 T(d.temperature(11,50,60));T(!d.temperature(900012,50,60));T(d.phase()==Failed);
 Auto60 e;T(e.start(true,5));T(e.action_dispatched(Heat60));T(e.temperature(6,60,60));
 T(e.temperature(30006,60,60));T(e.action_dispatched(HomeSafe));T(!e.homed(e.generation(),false,true,true));
 Auto60 f;T(f.start(true,5));T(f.action_dispatched(Heat60));T(f.temperature(6,60,60));
 T(f.temperature(30006,60,60));T(f.action_dispatched(HomeSafe));T(f.homed(f.generation(),true,true,true));
 T(f.action_dispatched(Probe16));T(f.g29_begin(f.generation(),55));
 T(!f.point(f.generation(),55,2));T(f.point(f.generation(),55,1));
 T(!f.g29_complete(f.generation(),55,true,true,false,false,mesh));T(f.phase()==Failed);
 // An invalid byte/float cannot ever advance an active sequence
 Auto60 g;T(g.start(true,5));T(g.action_dispatched(Heat60));
 T(!g.temperature(6,std::numeric_limits<float>::quiet_NaN(),60));T(g.phase()==Failed);
 // Flood invalid events across all states; no accidental EEPROM success.
 for(int k=0;k<50000;k++){
   T(!g.eeprom_readback(g.generation(),true,mesh,true));
   T(!g.eeprom_verified());
 }
 printf("SV04 NEXT 246 PASS: %d assertions\n",checks);
}
