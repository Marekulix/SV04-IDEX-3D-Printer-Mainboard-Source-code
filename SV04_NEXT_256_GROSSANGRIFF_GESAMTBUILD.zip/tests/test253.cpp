#include "SV04NextRuntime250.hpp"
#include <cassert>
#include <cstdio>
int main(){
  sv04next250::Runtime r;
  assert(!r.touch_start(false,100));
  assert(r.touch_start(true,100));
  assert(r.sequence().pending()==sv04next248::Heat60);
  assert(r.heat_dispatched());
  assert(r.sequence().phase()==sv04next248::AwaitHeat);
  assert(r.temperature(101,25.0f,60.0f));
  assert(r.temperature(102,60.0f,60.0f));
  assert(r.temperature(30103,60.0f,60.0f));
  assert(r.sequence().phase()==sv04next248::AwaitHome);
  assert(r.sequence().pending()==sv04next248::HomeSafe);
  // Dispatching G29 before a proven homing action is prohibited.
  assert(!r.g29_dispatched());
  assert(!r.verified_readback(true,nullptr,true));
  std::puts("253 host: 12/12 assertions passed (no STM32 proof)");
}
