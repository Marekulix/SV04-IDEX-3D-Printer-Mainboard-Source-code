#include "../firmware/Marlin/src/lcd/e3v2/creality/SV04NextRuntime250.hpp"
#include <cassert>
#include <cstdio>
int main(){
  unsigned checks=0;
  float mesh[16];for(int i=0;i<16;i++)mesh[i]=(i-8)*0.125f;
  sv04next250::Runtime r;
  assert(!r.touch_start(false,100));++checks;
  assert(r.touch_start(true,100));++checks;
  assert(!r.touch_start(true,100));++checks;
  assert(!r.temperature(200,60,60));++checks;
  assert(r.heat_dispatched());++checks;
  assert(r.temperature(200,60,60));++checks;
  assert(r.temperature(30201,60,60));++checks;
  assert(r.sequence().pending()==sv04next248::HomeSafe);++checks;
  assert(!r.homed(true,true,true));++checks;
  assert(r.home_dispatched());++checks;
  assert(!r.homed(false,true,true));++checks; // safety proof fails closed
  assert(r.sequence().phase()==sv04next248::Failed);++checks;
  assert(r.touch_start(true,40000));++checks;
  assert(r.heat_dispatched());++checks;
  assert(r.temperature(40001,60,60));++checks;
  assert(r.temperature(70002,60,60));++checks;
  assert(r.home_dispatched());++checks;
  assert(r.homed(true,true,true));++checks;
  assert(r.g29_dispatched());++checks;
  assert(r.g29_started(71));++checks;
  assert(!r.g29_started(71));++checks;
  assert(!r.g29_point(71,2));++checks;
  for(int i=1;i<=16;i++){assert(r.g29_point(71,i));++checks;}
  assert(!r.g29_finished(70,true,true,false,false,mesh));++checks;
  assert(r.g29_finished(71,true,true,false,false,mesh));++checks;
  assert(r.enable_dispatched());++checks;
  assert(r.leveling_proven(true));++checks;
  assert(r.store_dispatched());++checks;
  assert(r.stored(true));++checks;
  assert(r.readback_dispatched());++checks;
  assert(!r.verified_readback(false,mesh,true));++checks;
  assert(r.sequence().phase()==sv04next248::Failed);++checks;
  assert(r.touch_start(true,80000));++checks;
  assert(r.touch_abort());++checks;
  assert(r.abort_requested());++checks;
  assert(!r.cancel_confirmed(false));++checks;
  assert(r.cancel_confirmed(true));++checks;
  assert(r.sequence().phase()==sv04next248::Cancelled);++checks;
  // Completely separate verified success with genuinely independent readback indicated.
  assert(r.touch_start(true,90000));++checks;
  assert(r.heat_dispatched());++checks;
  assert(r.temperature(90001,60,60));++checks;
  assert(r.temperature(120002,60,60));++checks;
  assert(r.home_dispatched());++checks;
  assert(r.homed(true,true,true));++checks;
  assert(r.g29_dispatched());++checks;
  assert(r.g29_started(72));++checks;
  for(int i=1;i<=16;i++){assert(r.g29_point(72,i));++checks;}
  assert(r.g29_finished(72,true,true,false,false,mesh));++checks;
  assert(r.enable_dispatched());++checks;
  assert(r.leveling_proven(true));++checks;
  assert(r.store_dispatched());++checks;
  assert(r.stored(true));++checks;
  assert(r.readback_dispatched());++checks;
  assert(r.verified_readback(true,mesh,true));++checks;
  assert(r.sequence().eeprom_verified());++checks;
  // Every new instance starts not armed; no hidden privileged start.
  for(unsigned i=0;i<65536;i++){
    sv04next244::TouchState t;
    const sv04next244::TouchResult v=t.receive((uint16_t)i,1);
    if(i!=sv04next244::START&&i!=sv04next244::ABORT&&i!=sv04next244::BACK_ABORT&&i!=sv04next244::BACK_ERROR&&i!=sv04next244::BACK_RESULT)assert(v==sv04next244::NotOurs);
    ++checks;
  }
  std::printf("SV04 NEXT 250 runtime tests PASS, checks=%u\\n",checks);
}
