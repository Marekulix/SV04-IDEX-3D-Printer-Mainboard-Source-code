#include "../firmware/Marlin/src/lcd/e3v2/creality/SV04NextAuto60_248.hpp"
#include <assert.h>
#include <stdio.h>
using namespace sv04next248;
static int checks=0;
#define T(x) do {++checks; if(!(x)){fprintf(stderr,"FAIL line %d: %s\n", __LINE__,#x);return 2;}}while(0)
int main(){
  Auto60 a;float mesh[16],copy[16];for(int i=0;i<16;i++)mesh[i]=copy[i]=0.1f*i-0.7f;
  T(a.start(true,100));const uint32_t g=a.generation();
  T(!a.temperature(100,60,60)); // reject pre-dispatch temperature
  T(a.pending()==Heat60);T(a.action_dispatched(Heat60));
  T(a.temperature(100,60,60));T(a.phase()==Stabilizing);
  T(a.temperature(30100,60,60));T(a.pending()==HomeSafe);
  T(a.action_dispatched(HomeSafe));T(a.homed(g,true,true,true));
  T(a.pending()==Probe16);T(a.action_dispatched(Probe16));
  T(a.g29_begin(g,77));T(!a.g29_begin(g,77));T(!a.g29_begin(g,78));
  for(int n=1;n<=16;n++)T(a.point(g,77,n));
  T(a.g29_complete(g,77,true,true,false,false,mesh));
  T(a.action_dispatched(EnableLeveling));T(a.leveling_enabled(g,true));
  T(a.action_dispatched(StoreEeprom));T(a.eeprom_stored(g,true));
  T(a.action_dispatched(ReadbackEeprom));T(!a.eeprom_verified());
  T(a.eeprom_readback(g,true,copy,true));T(a.eeprom_verified());
  T(a.phase()==Verified);T(!a.request_cancel());
  Auto60 b;T(b.start(true,5));T(b.action_dispatched(Heat60));
  T(!b.watchdog(900006));T(b.failure()==HeatTimeout);T(!b.eeprom_verified());
  Auto60 c;T(c.start(true,20));T(c.request_cancel());T(c.phase()==CancelRequested);
  T(!c.cancel_confirmed(c.generation(),false));T(c.cancel_confirmed(c.generation(),true));
  T(!c.eeprom_verified());
  Auto60 d;T(d.start(true,8));T(d.action_dispatched(Heat60));T(d.temperature(10,60,60));
  T(d.temperature(30010,60,60));T(d.action_dispatched(HomeSafe));
  d.mark_action_time(30010);T(!d.watchdog(930012));T(d.failure()==ActionTimeout);
  Auto60 e;T(e.start(true,4));T(e.request_cancel());e.mark_action_time(4);
  T(!e.watchdog(120005));T(e.failure()==CancelTimeout);
  Auto60 f;T(f.start(true,UINT32_MAX-100));T(f.action_dispatched(Heat60));
  T(f.temperature(UINT32_MAX-50,60,60));T(f.temperature(30000,60,60));T(f.phase()==AwaitHome);
  for(int i=0;i<50000;i++){
    T(!a.eeprom_readback(g,true,copy,true));
    T(a.eeprom_verified());
    T(!c.eeprom_readback(c.generation(),true,copy,true));
  }
  printf("SV04 NEXT 248 PASS: %d checks\n",checks);
}
