#include "../firmware/Marlin/src/lcd/e3v2/creality/SV04NextResultGate252.hpp"
#include <cassert>
#include <cstdio>
int main(){sv04next252::Gate g;float m[16];for(int i=0;i<16;i++)m[i]=(float)(i-8)/16;
 assert(g.begin(42,m));assert(g.pending());assert(!g.release(42,false,true,m));
 assert(!g.release(42,true,false,m));assert(!g.release(41,true,true,m));
 float n[16];for(int i=0;i<16;i++)n[i]=m[i];n[7]+=0.01f;
 assert(!g.release(42,true,true,n));assert(g.pending());assert(g.release(42,true,true,m));
 assert(!g.pending());assert(!g.release(42,true,true,m));
 unsigned checks=9;
 for(unsigned i=0;i<65536;i++){assert(!g.release(i,true,true,m));checks++;}
 for(int k=0;k<16;k++){assert(g.begin(43,m));g.clear();assert(!g.release(43,true,true,m));checks+=3;}
 printf("SV04 NEXT 252 host gate PASS checks=%u\n",checks);
}
