#include "SV04NextDgus244.hpp"
#include <cassert>
#include <cstdio>
#include <limits>
struct Fake:sv04next244::Writer{
 unsigned writes=0,pages=0; uint16_t addr[16],vals[16];uint8_t page=0;
 void write_word(uint16_t a,uint16_t v){assert(writes<16);addr[writes]=a;vals[writes++]=v;}
 void change_page(uint8_t p){page=p;++pages;}
};
int main(){
 using namespace sv04next244;
 TouchState t; unsigned checks=0;
 for(unsigned a=0;a<65536;++a){
  const TouchResult r=t.receive((uint16_t)a,0);
  assert(r==((a==START||a==ABORT||a==BACK_ABORT||a==BACK_ERROR||a==BACK_RESULT)?RejectedValue:NotOurs));++checks;
 }
 assert(t.receive(START,1)==StartRequested);assert(t.receive(ABORT,1)==AbortRequested);
 assert(t.receive(BACK_ABORT,1)==BackRequested);assert(t.receive(BACK_ERROR,1)==BackRequested);
 assert(t.receive(BACK_RESULT,1)==BackRequested);checks+=5;
 assert(t.start_count==1&&t.abort_count==1&&t.back_count==3);
 float m[16];for(unsigned i=0;i<16;++i)m[i]=(float)((int)i-8)*0.125f;
 uint16_t raw[16];assert(encode_mesh(m,raw));assert(raw[0]==(uint16_t)(int16_t)-1000);checks+=2;
 Fake w;assert(!publish_confirmed_mesh(w,false,false,m));assert(!publish_confirmed_mesh(w,true,true,m));
 assert(w.writes==0&&w.pages==0);checks+=3;
 assert(publish_confirmed_mesh(w,true,false,m));assert(w.writes==16&&w.pages==1&&w.page==PAGE_RESULT);checks+=3;
 for(unsigned i=0;i<16;++i){assert(w.addr[i]==0x3020+2*i);checks++;}
 m[7]=std::numeric_limits<float>::quiet_NaN();Fake no;
 assert(!publish_confirmed_mesh(no,true,false,m));assert(no.writes==0&&no.pages==0);checks+=2;
 m[7]=40.0f;assert(!publish_confirmed_mesh(no,true,false,m));checks++;
 m[7]=-.520f;uint16_t enc[16];assert(encode_mesh(m,enc));assert(enc[7]==0xfdf8);checks+=2;
 Fake end;publish_abort(end);assert(end.page==61);publish_error(end);assert(end.page==62);checks+=2;
 printf("PASS SV04NEXT244 %u host assertions; serial/actuator commands NONE\n",checks);
}
