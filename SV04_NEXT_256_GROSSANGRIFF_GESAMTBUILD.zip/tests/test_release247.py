from pathlib import Path
import zipfile,hashlib,re
root=Path(__file__).resolve().parents[1]
lcd=(root/'firmware/Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp').read_text()
auto=(root/'firmware/Marlin/src/lcd/e3v2/creality/SV04NextAuto60_246.hpp').read_text()
g29=(root/'firmware/Marlin/src/gcode/bedlevel/abl/G29.cpp').read_text()
assert '#define SV04NEXT_AUTO60_246 0' in lcd
assert '#define SV04NEXT_DGUS_244 0' in lcd
assert '#error "SV04 NEXT 245: new DWIN background ICL not verified' in lcd
assert 'No automatic dispatch of M190, G28, G29, M420 or M500' in lcd
assert 'independently_read' in auto and 'read_mesh' in auto
assert 'StopRequested' in auto and 'cancel_confirmed' in auto
assert 'SV04NEXT_G29_DEFER_LIVE_MESH_235' in g29
assert not (root/'dwin/32_main.icl').exists(), 'No unvalidated ICL allowed'
assert (root/'dwin/13TouchFile.bin').stat().st_size==7426
assert (root/'dwin/14ShowFile.bin').stat().st_size==23872
print('PASS: source safety gates, readback contract, DWIN artifacts and missing-ICL lock')
