#!/usr/bin/env python3
"""Audit the actual V255 integration, not stale assumptions from V246."""
import pathlib,json,sys
root=pathlib.Path(__file__).resolve().parent
fw=root/'firmware/Marlin/src'
lcd=(fw/'lcd/e3v2/creality/LCD_RTS.cpp').read_text()
g28=(fw/'gcode/calibrate/G28.cpp').read_text()
g29=(fw/'gcode/bedlevel/abl/G29.cpp').read_text()
checks={
 'V255 machine backend entry really implemented':'SV04Next_MachineProofBackend254() {' in lcd,
 'V255 machine command implementation locked (NOT READY)':'class SV04NextLockedCommands255 final' in lcd and 'bool request_safe_abort() override { return false; }' in lcd,
 'G28 completion callback at real end':'SV04Next_G28PhysicalEnd255(!axes_should_home())' in g28,
 'G29 guard exists':'SV04Next_G29Begin194' in lcd and 'SV04Next_G29Abort194' in lcd,
 'G29 guarded live mesh exists':'SV04NEXT_G29_DEFER_LIVE_MESH_235' in g29,
 'ICL fail-closed build guard':'#error "SV04 NEXT 245: new DWIN background ICL not verified' in lcd,
 'Default machine off':'#define SV04NEXT_MARLIN_MACHINE_254 0' in lcd,
 'Default live display off':'#define SV04NEXT_DGUS_244 0' in lcd,
 'No new ICL in input':not (root/'dwin/32_main.icl').exists(),
 'Old EEPROM command not manufactured':'bool independent_eeprom_read' in (fw/'lcd/e3v2/creality/SV04NextMarlinAdapter254.hpp').read_text(),
}
result={'version':256,'source':'SV04 NEXT 255 actual overlay','checks':checks,'all_pass':all(checks.values()),'machine_feature_ready':False,'new_display_icl_ready':False}
print(json.dumps(result,indent=2))
sys.exit(0 if result['all_pass'] else 1)
