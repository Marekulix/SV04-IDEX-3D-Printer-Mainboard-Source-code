#!/usr/bin/env python3
"""Strictly guarded real Marlin G28/M500/M501 hook installer for pinned SV04 OEM tree.
No flashing, no file overwrite unless all required anchors are verified first.
"""
from pathlib import Path
import argparse, hashlib, sys

REPO_FILES={
 'G28':'Marlin/src/gcode/calibrate/G28.cpp',
 'EEPROM':'Marlin/src/gcode/eeprom/M500-M504.cpp',
 'M420':'Marlin/src/gcode/bedlevel/M420.cpp',
}
ORIGINAL_SHA={
 'G28':'5700ac25228ef7405797a80b840bab1dacddfcc7',
 'EEPROM':'a06e98ad1ea79d499c9bf17789d9cd8d916aaecd',
 'M420':'d76e08dee6107964b4dc48390830409980e6a971',
}
def git_blob_sha(s):
 b=s.encode('utf-8');return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()

def patched_g28(src):
 marker='void GcodeSuite::G28() {'
 trailer='  TERN_(FULL_REPORT_TO_HOST_FEATURE, set_and_report_grblstate(M_IDLE));'
 if src.count(marker)!=1 or src.count(trailer)!=1:raise ValueError('G28 anchor mismatch')
 # Uses ACTUAL Marlin axes home flag and genuine IDEX parked state.
 # No callback on early G28 returns.
 pre='''// SV04 NEXT 255: Real G28-end attestation (compile-time opt-in, no commands).\n#ifndef SV04NEXT_PROOF_HOOKS_255\n#define SV04NEXT_PROOF_HOOKS_255 0\n#endif\n#if SV04NEXT_PROOF_HOOKS_255\nextern void SV04Next_G28Finished255(bool axes_homed, bool idex_parked, bool z_homed);\n#endif\n'''
 src=src.replace(marker,pre+'\n'+marker,1)
 hook='''  #if SV04NEXT_PROOF_HOOKS_255\n    // Completed G28 execution; not merely the queue acknowledgement.\n    // A failed/early-returning G28 never reaches this callback.\n    const bool sv04next255_axes_homed = !axes_should_home();\n    #if ENABLED(DUAL_X_CARRIAGE)\n      const bool sv04next255_parked = active_extruder_parked;\n    #else\n      const bool sv04next255_parked = true;\n    #endif\n    SV04Next_G28Finished255(sv04next255_axes_homed, sv04next255_parked, !axis_should_home(Z_AXIS));\n  #endif\n'''
 src=src.replace(trailer,hook+'\n'+trailer,1)
 return src

def patched_eeprom(src):
 anchor='#include "../../inc/MarlinConfig.h"'
 m500='void GcodeSuite::M500() {\n  (void)settings.save();\n}'
 m501='void GcodeSuite::M501() {\n  (void)settings.load();\n}'
 for x in (anchor,m500,m501):
  if src.count(x)!=1:raise ValueError('EEPROM anchor mismatch')
 src=src.replace(anchor,anchor+'''\n\n#ifndef SV04NEXT_PROOF_HOOKS_255\n#define SV04NEXT_PROOF_HOOKS_255 0\n#endif\n#if SV04NEXT_PROOF_HOOKS_255\n#include "../../feature/bedlevel/abl/abl.h"\n#include "../../module/planner.h"\nextern void SV04Next_M500Finished255(bool settings_saved);\nextern void SV04Next_M501Finished255(bool actually_loaded, const float *mesh_serpentine, bool leveling_saved);\n#endif''',1)
 src=src.replace(m500,'''void GcodeSuite::M500() {\n  #if SV04NEXT_PROOF_HOOKS_255\n    const bool sv04next255_saved = settings.save();\n    SV04Next_M500Finished255(sv04next255_saved);\n  #else\n    (void)settings.save();\n  #endif\n}''',1)
 src=src.replace(m501,'''void GcodeSuite::M501() {\n  #if SV04NEXT_PROOF_HOOKS_255\n    const bool sv04next255_loaded = settings.load();\n    #if ENABLED(AUTO_BED_LEVELING_BILINEAR)\n      // Readback only after a real nonvolatile settings.load(), never a RAM cache.\n      // Preserve the OEM serpentine display order.\n      float sv04next255_saved_mesh[16];\n      bool sv04next255_mesh_shape = GRID_MAX_POINTS_X == 4 && GRID_MAX_POINTS_Y == 4;\n      if (sv04next255_mesh_shape) {\n        unsigned n = 0;\n        for (int y = 0; y < 4; ++y)\n          for (int j = 0; j < 4; ++j) {\n            const int x = (y & 1) ? j : 3 - j;\n            sv04next255_saved_mesh[n++] = z_values[x][y];\n          }\n      }\n      SV04Next_M501Finished255(sv04next255_loaded && sv04next255_mesh_shape,\n                               sv04next255_mesh_shape ? sv04next255_saved_mesh : nullptr,\n                               planner.leveling_active);\n    #else\n      SV04Next_M501Finished255(false, nullptr, false);\n    #endif\n  #else\n    (void)settings.load();\n  #endif\n}''',1)
 return src

def patched_m420(src):
 marker='void GcodeSuite::M420() {'
 end='  serialprintln_onoff(planner.leveling_active);'
 if src.count(marker)!=1 or src.count(end)<1:raise ValueError('M420 anchor mismatch')
 pre='// SV04 NEXT 255: true M420 command-completion acknowledgement.\n#ifndef SV04NEXT_PROOF_HOOKS_255\n#define SV04NEXT_PROOF_HOOKS_255 0\n#endif\n#if SV04NEXT_PROOF_HOOKS_255\nextern void SV04Next_M420Finished255(bool leveling);\n#endif\n'
 src=src.replace(marker,pre+'\n'+marker,1)
 hook='  #if SV04NEXT_PROOF_HOOKS_255\n    SV04Next_M420Finished255(planner.leveling_active);\n  #endif\n'
 src=src.replace(end,end+'\n'+hook,1)
 return src

def main():
 ap=argparse.ArgumentParser();ap.add_argument('repository',type=Path);ap.add_argument('--out',type=Path,required=True)
 args=ap.parse_args()
 originals={};modified={}
 for name,rel in REPO_FILES.items():
  src=(args.repository/rel).read_text(encoding='utf-8')
  got=git_blob_sha(src)
  if got!=ORIGINAL_SHA[name]:raise RuntimeError(f'{name} ORIGINAL SHA mismatch: {got}, expected {ORIGINAL_SHA[name]}; refusing patch')
  originals[name]=src
  modified[name]=patched_g28(src) if name=='G28' else patched_eeprom(src) if name=='EEPROM' else patched_m420(src)
 # All checks succeed before any output modifications.
 for name,rel in REPO_FILES.items():
  dest=args.out/rel;dest.parent.mkdir(parents=True,exist_ok=True)
  if dest.exists():raise RuntimeError(f'output already exists {dest} (no overwrite)')
  dest.write_text(modified[name],encoding='utf-8')
 print('SV04 NEXT 255: three real OEM G28/M420/M500/M501 source files patched; ALL ORIGINAL HASHES VERIFIED; NOT FLASHABLE')
if __name__=='__main__':main()
