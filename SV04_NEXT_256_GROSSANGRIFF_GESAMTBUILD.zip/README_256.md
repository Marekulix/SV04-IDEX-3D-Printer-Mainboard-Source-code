# SV04 NEXT 256 – ein großer GitHub-Integrationsangriff, KEIN FLASH

Dies ist ein **Test- und Diagnosepaket**, keine installierbare Firmware.

## Fünf STM32-Builds in einem Actions-Start
- `oem`: unveränderter OEM-Referenzbuild am festgelegten Commit.
- `merged_safe`: gesamter V255-Quellstand, alle experimentellen Funktionen ausdrücklich aus.
- `observer`: wie safe, nur der Claude/HMI-Observer an.
- `full_diagnostic`: alle Auto60-/DWIN-Maschinenfunktionen aktiviert, ICL-Verifizierung absichtlich nicht behauptet. Sollte an der Freigabesperre scheitern.
- `full_compile_probe`: Wegwerf-Kompilierung mit **künstlich gesetztem ICL-Prüfschalter** nur, um nachfolgende Compiler-/Linkfehler sichtbar zu machen. **Dieser Build ist unabhängig vom Erfolg niemals installierbar oder freigegeben.**

Host-Regressionen laufen unabhängig davon. Die DWIN-Spur lädt die **originale** `32_main.icl` von `bphillips09/SV04-Touchscreen`, Commit `5a3fae8c1ccdc04fb3372c077a61394e8a66ece4`, herunter. Sie prüft deren Git-Blob-ID sowie die originale `13TouchFile.bin` und `14ShowFile.bin`. Das löst **nicht** automatisch die fehlende Neukompilierung der Bilder 59–63. Die experimentellen 13/14-Dateien werden separat als NO FLASH ausgewiesen.

## Was das Paket NICHT behauptet
- Keine volle Ein-Knopf-Bettvermessung mit freigegebenem Homing und garantiertem G29-Abbruch.
- Keine nachgewiesene unabhängige EEPROM-Prüfung und keine sichere IDEX-Parkposition.
- Keine fertige neue DWIN-ICL. Keine installierbare Firmware. Kein Hardwaretest.
- Auch ein erfolgreicher STM32-Build bedeutet **keine Flashfreigabe**.

## Android-GitHub-Anleitung
1. `SV04_NEXT_256_GROSSANGRIFF_GESAMTBUILD.zip` in das **Wurzelverzeichnis** deines Repositories hochladen.
2. `256.yml` in `.github/workflows/256.yml` hochladen.
3. GitHub → Actions → `256 - SV04 NEXT GROSSANGRIFF ...` → Run workflow.
4. Alle **7 Ergebnisarchive** hochladen: 1× Host, 5× STM32 (oem/safe/observer/full_diagnostic/full_compile_probe), 1× DWIN, 1× Gesamtbericht.

Der Workflow führt keine Firmwareinstallation, keinen Flash und keinen Commit aus. Das originale V255-ZIP ist unverändert als `ORIGINAL_VERSION_255_UNVERAENDERT.zip` enthalten. Neue Versionsnummer 256, alte Dateien werden nicht überschrieben.
