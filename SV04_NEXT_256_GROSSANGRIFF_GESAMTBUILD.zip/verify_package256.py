#!/usr/bin/env python3
import hashlib,json,pathlib,sys
root=pathlib.Path(sys.argv[1]).resolve()
checks=json.loads((root/'SHA256_MANIFEST_256.json').read_text())
errors=[]
for rel,expected in checks.items():
 p=root/rel
 if not p.is_file():errors.append('MISSING '+rel)
 elif hashlib.sha256(p.read_bytes()).hexdigest()!=expected:errors.append('SHA256 MISMATCH '+rel)
res={'version':256,'entries':len(checks),'status':'PASS' if not errors else 'FAIL','errors':errors}
print(json.dumps(res,indent=2))
if errors:sys.exit(1)
