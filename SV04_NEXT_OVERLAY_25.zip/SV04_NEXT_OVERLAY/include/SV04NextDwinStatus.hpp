// SV04 NEXT 18: PASSIVE Statusversorgung fuers DWIN: reine Rechenlogik, die aus dem Zustand der Auto60-Maschine und dem 4x4-Mesh eine LISTE von (VP, Wert)-Schreibauftraegen erzeugt.
// NICHT verdrahtet: nichts in dieser Datei ruft RTS_SndData auf, startet etwas oder liest Touch-Ereignisse. Sie wird weder vom Patcher eingefuegt noch kompiliert die CI sie; sie ist ein getesteter Baustein fuer eine spaetere, ausdruecklich freigegebene Anbindung.
// NUR zwei VERIFIZIERTE, bereits vom OEM beschriebene VP-Familien (LCD_RTS.h, maschinell belegt in docs/DWIN_VP_MAP.md): Fortschrittsicon (AUTO_BED_LEVEL_ICON_VP) und die 16 Messwerte (AUTO_BED_LEVEL_1POINT_VP + 2*i).
// NICHT abgedeckt, weil kein verifiziertes freies VP existiert: Zustand/Fehlercode, Gueltig-/Ungueltig-Markierung, Abbruchstatus, Temperatur (die schreibt der OEM bereits selbst). Das steht in not_connected().
#pragma once
#include <stdint.h>
#include <math.h>
namespace sv04next {
namespace dwinstatus {
struct Write { uint16_t vp; int16_t value; };
struct Input { uint8_t progress = 0; bool run_active = false; bool mesh_valid[16] = {}; float mesh_z[16] = {}; };     // Index = Messpunktnummer 0..15 (Reihenfolge wie die OEM-Anzeige: n-1)
struct Addresses { uint16_t icon_vp, point1_vp; };                         // vom Aufrufer aus LCD_RTS.h eingesetzt (AUTO_BED_LEVEL_ICON_VP, AUTO_BED_LEVEL_1POINT_VP): hier KEINE eigenen Zahlen
constexpr uint8_t kMaxWrites = 17;
// Schreibt hoechstens kMaxWrites Auftraege nach out und liefert deren Anzahl. Ungueltige/nicht gemessene Punkte werden als 0 angezeigt (die Anzeige hat keine Markierung dafuer).
inline uint8_t render(const Input &in, const Addresses &a, Write out[kMaxWrites]) {
  uint8_t n = 0; const uint8_t p = in.progress > 16 ? 16 : in.progress;
  out[n++] = { a.icon_vp, (int16_t)p };
  for (uint8_t i = 0; i < 16; ++i) {
    int32_t v = 0; if (in.mesh_valid[i] && isfinite(in.mesh_z[i]) && fabsf(in.mesh_z[i]) <= 3.0f) v = (int32_t)lroundf(in.mesh_z[i] * 1000.0f);   // wie die OEM-Anzeige: z*1000; 3 mm = Plausibilitaetsgrenze der Maschine
    out[n++] = { (uint16_t)(a.point1_vp + 2u * i), (int16_t)v };
  }
  return n;
}
inline const char *not_connected() { return "Zustand/Fehlercode, Gueltig-Markierung, Abbruchstatus, Farbkarte, Start/Abbruch-Taster: kein verifiziertes freies VP bzw. Touchbereich ohne Display-Projekt"; }
}  // namespace dwinstatus
}  // namespace sv04next
