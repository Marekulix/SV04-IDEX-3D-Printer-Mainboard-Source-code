// SV04 NEXT 13: EINE auslieferbare Zustandsmaschine fuer "Bettvermessung 60 C". C++11, kein Heap, keine Marlin-Includes.
// Sie LIEST nur eine Beobachtungsstruktur und gibt pro tick() HOECHSTENS EINE Aktion zurueck; die Ausfuehrung liegt bei der Bruecke (SV04NextAuto60Glue.hpp).
// Vertrag:
//  * Befehlsannahme ist KEIN Abschluss: Home/Measure gelten erst als erledigt, wenn ein NEUER Beleg (andere Sequenz) mit Endzustand vorliegt.
//  * Jede Aktion wird pro Zustandseintritt genau einmal ausgegeben; es gibt keine Wiederholungen.
//  * Jede Unstimmigkeit fuehrt zu ABORT_LOCKED mit Grundcode; Rueckkehr nur nach ausdruecklicher Quittung bei ruhiger Maschine.
//  * EEPROM: hoechstens EIN Commit je Lauf, nur nach RamOnlySuccess derselben Messung, nur wenn die Plattform ihn unterstuetzt UND er bestaetigt wurde (oder auto_commit gesetzt ist).
//  * Die Maschine heizt nie auf etwas anderes als 60 C (Aktion SetBed60) und schaltet nur ab (SetBedOff). Nichts startet ohne request_start().
#pragma once
#include <stdint.h>
#include <math.h>   // NAN
#include "SV04NextG28PassiveReceipt.hpp"
#include "SV04NextG29UReceipt.hpp"
#include "SV04NextSafeFloat.hpp"
namespace sv04next {
class Auto60Engine final {
public:
  enum class State : uint8_t { Idle, StartRequested, Precheck, Heat60, TempStable, HomeG28, VerifyHome, MeasureG29, VerifyRamMesh, VerifyLeveling, CommitPending, EepromReadback, Done, DoneRamOnly, AbortLocked };
  enum class Action : uint8_t { None, SetBed60, SetBedOff, Home, Measure, Commit };
  enum class Reason : uint8_t { None, UserAbort, NotIdle, Precondition, ObservationInvalid, HeatTimeout, HeatTargetNotApplied, TempOvershoot, TempLost, ExternalActivity, Stopped,
                                HomeTimeout, HomeFailed, HomeStale, MeasureTimeout, MeshFailed, LevelingInactive, OffsetChanged, CommitTimeout, ReadbackMismatch, CommitNotAvailable, CommitNotConfirmed, ActionFailed };
  enum class Eeprom : uint8_t { Unknown, ReadbackMatch, ReadbackMismatch, SaveFailed };
  struct Config {
    bool auto_commit = false;                       // false: Commit nur nach ausdruecklicher Quittung des Benutzers
    uint32_t target_apply_ms = 10000u, heat_timeout_ms = 20u * 60u * 1000u, home_timeout_ms = 5u * 60u * 1000u, thermal_wait_ms = 60000u,
             measure_timeout_ms = 15u * 60u * 1000u, commit_timeout_ms = 30000u, confirm_wait_ms = 10u * 60u * 1000u, max_receipt_age_ms = 120000u;
    float overshoot_c = 65.0f;                      // Notgrenze: darueber wird abgebrochen
  };
  struct Obs {                                      // wird von der Bruecke je tick() befuellt; "unbekannt" heisst false bzw. NaN
    uint32_t now_ms = 0; float bed_c = NAN, bed_target_c = NAN, probe_offset_z = NAN;
    bool stopped = true, printing = true, paused = false, motion_queued = true, queue_busy = true, tool0 = false, dual_auto_park = false, xyz_trusted = false,
         leveling_active = false, thermal_ready = false, thermal_safe = false;
    uint32_t g28_seq = 0, g28_ended_ms = 0; G28PassiveReceipt::Phase g28_phase = G28PassiveReceipt::Phase::Never; bool g28_trusted = false, g28_tool0 = false;
    uint32_t g29_seq = 0; G29UReceipt::Phase g29_phase = G29UReceipt::Phase::Never; G29UReceipt::Failure g29_failure = G29UReceipt::Failure::None; uint8_t g29_completed = 0;
    bool user_abort = false, user_ack = false;      // Ereignisse, je tick hoechstens einmal wahr
    bool t1_parked_electrically = false;            // Stand 16: unabhaengige ELEKTRISCHE Bestaetigung (X_MAX-Pegel); false = unbekannt/nicht bestaetigt
    bool eeprom_commit_supported = false; Eeprom eeprom = Eeprom::Unknown;
  };
  struct View {
    State state = State::Idle; Reason reason = Reason::None; uint32_t run = 0; uint8_t progress = 0; float bed_c = NAN, bed_target_c = NAN; uint32_t elapsed_ms = 0;
    G29UReceipt::Failure mesh_failure = G29UReceipt::Failure::None; bool eeprom_may_have_changed = false; uint8_t commits = 0; uint8_t duplicate_starts = 0;
  };
  Auto60Engine() : cfg_() {}
  explicit Auto60Engine(const Config &c) : cfg_(c) {}
  bool request_start() {                            // nur aus Idle; ein zweiter Start beeinflusst einen laufenden Ablauf NICHT
    if (state_ != State::Idle) { if (dup_ < 255) ++dup_; return false; }
    ++run_; if (run_ == 0) ++run_; reset_run(); state_ = State::StartRequested; return true;
  }
  Action tick(const Obs &o) {
    now_ = o.now_ms; bed_ = o.bed_c; tgt_ = o.bed_target_c;
    if (fail_pending_) { fail_pending_ = false; if (active(state_)) return abort_(Reason::ActionFailed); }
    if (active(state_)) {
      if (o.user_abort) return abort_(Reason::UserAbort);
      if (!float_is_finite(o.bed_c) || !float_is_finite(o.bed_target_c) || !float_is_finite(o.probe_offset_z)) return abort_(Reason::ObservationInvalid);
      if (o.stopped) return abort_(Reason::Stopped);
      if (o.bed_c >= cfg_.overshoot_c) return abort_(Reason::TempOvershoot);
      if (state_ != State::StartRequested && state_ != State::Precheck && (o.printing || o.paused)) return abort_(Reason::ExternalActivity);
    }
    switch (state_) {
      case State::Idle: return Action::None;
      case State::StartRequested: enter(State::Precheck); return Action::None;
      case State::Precheck:
        if (o.stopped || o.printing || o.paused || o.motion_queued || o.queue_busy || o.g28_phase == G28PassiveReceipt::Phase::Entered || o.g29_phase == G29UReceipt::Phase::Running) return abort_(Reason::NotIdle);
        if (!o.tool0 || !o.dual_auto_park || !float_is_finite(o.bed_c) || !float_is_finite(o.probe_offset_z) || o.bed_c >= cfg_.overshoot_c) return abort_(Reason::Precondition);
        z0_ = o.probe_offset_z; enter(State::Heat60); heater_on_ = true; return Action::SetBed60;
      case State::Heat60:
        if (elapsed() > cfg_.heat_timeout_ms) return abort_(Reason::HeatTimeout);
        if (o.bed_target_c == 60.0f) target_seen_ = true;
        else if (target_seen_) return abort_(Reason::ExternalActivity);                        // jemand anderes hat das Soll geaendert
        else if (elapsed() > cfg_.target_apply_ms) return abort_(Reason::HeatTargetNotApplied); // Befehl angenommen, aber nicht wirksam
        if (target_seen_ && o.thermal_ready && o.thermal_safe) enter(State::TempStable);
        return Action::None;
      case State::TempStable:
        if (!o.thermal_ready || !o.thermal_safe || o.bed_target_c != 60.0f) return abort_(Reason::TempLost);
        if (!quiet(o)) { if (elapsed() > cfg_.target_apply_ms) return abort_(Reason::NotIdle); return Action::None; }
        home_seq_ = o.g28_seq; enter(State::HomeG28); return Action::Home;
      case State::HomeG28:
        if (elapsed() > cfg_.home_timeout_ms) return abort_(Reason::HomeTimeout);
        if (!o.thermal_safe || o.bed_target_c != 60.0f) return abort_(Reason::TempLost);
        if (o.g28_seq == home_seq_ || o.g28_seq == 0) return Action::None;                      // noch keine NEUE Rueckmeldung: Annahme ist kein Abschluss
        if (o.g28_phase == G28PassiveReceipt::Phase::Entered) return Action::None;
        if (o.g28_phase != G28PassiveReceipt::Phase::EndObservedTrusted || !o.g28_trusted || !o.g28_tool0) return abort_(Reason::HomeFailed);
        if ((uint32_t)(o.now_ms - o.g28_ended_ms) > cfg_.max_receipt_age_ms) return abort_(Reason::HomeStale);
        enter(State::VerifyHome); return Action::None;
      case State::VerifyHome:
        if (!o.xyz_trusted || !o.tool0 || !o.dual_auto_park) return abort_(Reason::Precondition);
        if (!o.t1_parked_electrically) return abort_(Reason::Precondition);                      // Stand 16: Buchfuehrung allein genuegt nicht
        if (!o.thermal_safe || o.bed_target_c != 60.0f) return abort_(Reason::TempLost);
        if (!o.thermal_ready || !quiet(o)) { if (elapsed() > cfg_.thermal_wait_ms) return abort_(o.thermal_ready ? Reason::NotIdle : Reason::TempLost); return Action::None; }
        if (ABSF(o.probe_offset_z - z0_) > 0.00001f) return abort_(Reason::OffsetChanged);
        meas_seq_ = o.g29_seq; enter(State::MeasureG29); return Action::Measure;
      case State::MeasureG29:
        if (elapsed() > cfg_.measure_timeout_ms) return abort_(Reason::MeasureTimeout);
        if (!o.thermal_safe || o.bed_target_c != 60.0f) return abort_(Reason::TempLost);
        if (o.g29_seq == meas_seq_ || o.g29_seq == 0) return Action::None;
        progress_ = o.g29_completed > 16 ? 16 : o.g29_completed;
        if (o.g29_phase == G29UReceipt::Phase::Running) return Action::None;
        if (o.g29_phase != G29UReceipt::Phase::RamOnlySuccess) { mesh_failure_ = o.g29_failure; return abort_(Reason::MeshFailed); }
        enter(State::VerifyRamMesh); return Action::None;
      case State::VerifyRamMesh:
        if (o.g29_phase != G29UReceipt::Phase::RamOnlySuccess || o.g29_completed != 16 || o.g29_seq == meas_seq_) return abort_(Reason::MeshFailed);
        progress_ = o.g29_completed > 16 ? 16 : o.g29_completed; enter(State::VerifyLeveling); return Action::None;
      case State::VerifyLeveling:
        if (!o.leveling_active) return abort_(Reason::LevelingInactive);
        if (ABSF(o.probe_offset_z - z0_) > 0.00001f) return abort_(Reason::OffsetChanged);
        if (!quiet(o) || !o.thermal_safe) return abort_(Reason::NotIdle);
        enter(State::CommitPending); return Action::None;
      case State::CommitPending:
        if (!o.eeprom_commit_supported) return finish(State::DoneRamOnly, Reason::CommitNotAvailable);
        if (cfg_.auto_commit || o.user_ack) { ++commits_; may_change_ = true; enter(State::EepromReadback); return Action::Commit; }
        if (elapsed() > cfg_.confirm_wait_ms) return finish(State::DoneRamOnly, Reason::CommitNotConfirmed);
        return Action::None;
      case State::EepromReadback:
        if (o.eeprom == Eeprom::ReadbackMatch) { may_change_ = false; return finish(State::Done, Reason::None); }
        if (o.eeprom == Eeprom::ReadbackMismatch || o.eeprom == Eeprom::SaveFailed) return abort_(Reason::ReadbackMismatch);
        if (elapsed() > cfg_.commit_timeout_ms) return abort_(Reason::CommitTimeout);
        return Action::None;
      case State::Done: case State::DoneRamOnly: case State::AbortLocked:
        if (heater_on_ && !off_issued_) { off_issued_ = true; heater_on_ = false; return Action::SetBedOff; }
        if (o.user_ack && quiet(o) && o.g28_phase != G28PassiveReceipt::Phase::Entered && o.g29_phase != G29UReceipt::Phase::Running) { state_ = State::Idle; reason_ = Reason::None; }
        return Action::None;
    }
    return Action::None;
  }
  View view() const { View v; v.state = state_; v.reason = reason_; v.run = run_; v.progress = progress_; v.bed_c = bed_; v.bed_target_c = tgt_; v.elapsed_ms = active(state_) ? elapsed() : 0u; v.mesh_failure = mesh_failure_; v.eeprom_may_have_changed = may_change_; v.commits = commits_; v.duplicate_starts = dup_; return v; }
  void notify_action_failed() { fail_pending_ = true; }   // die Bruecke konnte den angeforderten Befehl nicht einreihen: Ablauf abbrechen (Heizung wird im naechsten tick abgeschaltet)
  State state() const { return state_; }
  Reason reason() const { return reason_; }
  bool allow_motion() const { return false; }        // die Maschine selbst bewegt nichts; Home/Measure sind Anforderungen an die Bruecke
private:
  static float ABSF(float x) { return x < 0 ? -x : x; }
  static bool active(State s) { return s != State::Idle && s != State::Done && s != State::DoneRamOnly && s != State::AbortLocked; }
  uint32_t elapsed() const { return (uint32_t)(now_ - state_ms_); }
  void enter(State s) { state_ = s; state_ms_ = now_; }
  bool quiet(const Obs &o) const { return !o.motion_queued && !o.queue_busy && o.g28_phase != G28PassiveReceipt::Phase::Entered && o.g29_phase != G29UReceipt::Phase::Running; }
  void reset_run() { fail_pending_ = false; reason_ = Reason::None; z0_ = 0; home_seq_ = meas_seq_ = 0; progress_ = 0; heater_on_ = off_issued_ = target_seen_ = may_change_ = false; commits_ = 0; mesh_failure_ = G29UReceipt::Failure::None; }
  Action finish(State s, Reason r) { state_ = s; reason_ = r; state_ms_ = now_; return heater_off_action(); }
  Action abort_(Reason r) { state_ = State::AbortLocked; reason_ = r; state_ms_ = now_; return heater_off_action(); }
  Action heater_off_action() { if (heater_on_ && !off_issued_) { off_issued_ = true; heater_on_ = false; return Action::SetBedOff; } return Action::None; }
  Config cfg_; State state_ = State::Idle; Reason reason_ = Reason::None; uint32_t now_ = 0, state_ms_ = 0, run_ = 0, home_seq_ = 0, meas_seq_ = 0; float z0_ = 0, bed_ = NAN, tgt_ = NAN;
  uint8_t progress_ = 0, commits_ = 0, dup_ = 0; bool heater_on_ = false, off_issued_ = false, target_seen_ = false, may_change_ = false, fail_pending_ = false; G29UReceipt::Failure mesh_failure_ = G29UReceipt::Failure::None;
};
} // namespace sv04next
