// SV04 NEXT 13: Marlin-Bruecke fuer Auto60Engine. STANDARDMAESSIG NICHT einkompiliert: der gesamte Inhalt steht unter #if defined(SV04_NEXT_AUTO60_ENGINE).
// Auch wenn das Makro gesetzt ist, STARTET NICHTS ohne sv04next::auto60_request_start(). Dieser Aufruf wird von KEINEM OEM- oder Overlay-Code ausgefuehrt
// (kein DWIN-Knopf, kein G-Code). Die Bruecke kennt nur vier Aktionen: Soll 60 C, Soll 0 C, "G28", "G29 U". EEPROM/M500 ist NICHT verdrahtet
// (eeprom_commit_supported bleibt false; die Maschine endet daher in DoneRamOnly). Die Marlin-Namen der drei Makros SV04_NEXT_* sind UNVERIFIZIERT und koennen
// nach dem ersten CI-Compile mit -D oder #define vor dem Include angepasst werden.
#pragma once
#if defined(SV04_NEXT_AUTO60_ENGINE)
#include "SV04NextAuto60Engine.hpp"
#include "SV04NextNativeThermalGate.hpp"
#include "SV04NextG28PassiveReceipt.hpp"
#include "SV04NextG29UReceipt.hpp"
#include "SV04NextT1ParkSense.hpp"
#ifndef SV04_NEXT_SET_BED_TARGET
  #define SV04_NEXT_SET_BED_TARGET(c) thermalManager.setTargetBed(c)   // Literal 60/0: passt zu float, int16_t und celsius_t (celsius_t gibt es erst ab Marlin 2.0.9)
#endif
#ifndef SV04_NEXT_ENQUEUE                       // nicht blockierend: true = eingereiht (enqueue_now_P wuerde bei voller Warteschlange idle() und damit RTSUpdate() erneut aufrufen)
  #define SV04_NEXT_ENQUEUE(s) queue.enqueue_one_P(PSTR(s))
#endif
#ifndef SV04_NEXT_QUEUE_BUSY
  #define SV04_NEXT_QUEUE_BUSY() (queue.has_commands_queued())
#endif
namespace sv04next {
extern G28PassiveReceipt g28_passive_receipt;
extern G29UReceipt g29u_receipt;
extern NativeThermalGate native_thermal_gate;
extern Auto60Engine auto60_engine;
inline bool &auto60_abort_flag() { static bool f = false; return f; }
inline bool &auto60_ack_flag() { static bool f = false; return f; }
inline bool &auto60_in_tick() { static bool f = false; return f; }
inline bool auto60_request_start() { return auto60_engine.request_start(); }   // NICHT aufgerufen: es gibt keinen Ausloeser
inline void auto60_user_abort() { auto60_abort_flag() = true; }
inline void auto60_user_ack() { auto60_ack_flag() = true; }
inline void auto60_glue_tick() {
  if (auto60_in_tick()) return;                  // Wiedereintritt (z. B. ueber idle() -> RTSUpdate()) darf keine zweite Aktion ausloesen
  auto60_in_tick() = true;
  Auto60Engine::Obs o; const uint32_t now = (uint32_t)millis();
  o.now_ms = now; o.bed_c = thermalManager.degBed(); o.bed_target_c = (float)thermalManager.degTargetBed(); o.probe_offset_z = probe.offset.z;
  o.stopped = IsStopped(); o.printing = printJobOngoing(); o.paused = printingIsPaused(); o.motion_queued = planner.has_blocks_queued(); o.queue_busy = SV04_NEXT_QUEUE_BUSY();
  o.tool0 = active_extruder == 0; o.dual_auto_park = dual_x_carriage_mode == DXC_AUTO_PARK_MODE; o.xyz_trusted = axis_is_trusted(X_AXIS) && axis_is_trusted(Y_AXIS) && axis_is_trusted(Z_AXIS);
  o.leveling_active = planner.leveling_active; o.thermal_ready = native_thermal_gate.ready(now); o.thermal_safe = NativeThermalGate::live_sample_safe(o.bed_c, o.bed_target_c);
  const G28PassiveReceipt::View &g = g28_passive_receipt.view(); o.g28_seq = g.sequence; o.g28_ended_ms = g.ended_ms; o.g28_phase = g.phase; o.g28_trusted = g.xyz_trusted; o.g28_tool0 = g.tool0;
  o.g29_seq = g29u_receipt.sequence(); o.g29_phase = g29u_receipt.phase(); o.g29_failure = g29u_receipt.failure(); o.g29_completed = g29u_receipt.completed();
  o.t1_parked_electrically = t1_parked_electrically();   // Stand 16: elektrischer X_MAX-Pegel, nicht die Firmware-Buchfuehrung
  o.user_abort = auto60_abort_flag(); o.user_ack = auto60_ack_flag(); auto60_abort_flag() = false; auto60_ack_flag() = false;
  o.eeprom_commit_supported = false; o.eeprom = Auto60Engine::Eeprom::Unknown;   // EEPROM-Commit bewusst NICHT verdrahtet
  const Auto60Engine::Action a = auto60_engine.tick(o);
  switch (a) {
    case Auto60Engine::Action::SetBed60: SV04_NEXT_SET_BED_TARGET(60); break;
    case Auto60Engine::Action::SetBedOff: SV04_NEXT_SET_BED_TARGET(0); break;
    case Auto60Engine::Action::Home: if (!SV04_NEXT_ENQUEUE("G28")) auto60_engine.notify_action_failed(); break;
    case Auto60Engine::Action::Measure: if (!SV04_NEXT_ENQUEUE("G29 U")) auto60_engine.notify_action_failed(); break;
    case Auto60Engine::Action::Commit: auto60_engine.notify_action_failed(); break;   // darf wegen eeprom_commit_supported=false nie vorkommen; falls doch: abbrechen
    case Auto60Engine::Action::None: break;
  }
  auto60_in_tick() = false;
}
} // namespace sv04next
#endif // SV04_NEXT_AUTO60_ENGINE
