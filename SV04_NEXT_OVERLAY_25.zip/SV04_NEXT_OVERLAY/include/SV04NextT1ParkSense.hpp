// SV04 NEXT 16: UNABHAENGIGE ELEKTRISCHE Bestaetigung, dass der zweite Schlitten (T1) am X_MAX-Endstop geparkt ist.
// Gelesen wird der PEGEL des Schalters (READ(X_MAX_PIN) != X_MAX_ENDSTOP_INVERTING, wie Marlins Endstops::update), NICHT die Firmware-Buchfuehrung
// (inactive_extruder_x, axis_is_trusted). Die Buchfuehrung hat schon vor der ersten Referenzfahrt einen Standardwert (inactive_extruder_x = X2_MAX_POS = 362, motion.cpp 1120), nach G28 den Heimatwert von T1 (am Original-Geraet 365,35 per M218 T1 X365.35, motion.cpp 1128-1138); beides beweist nichts. Hier wird nur gelesen:
// kein WRITE/OUT_WRITE/SET_OUTPUT, keine Bewegung, keine Heizung, kein EEPROM. Der Aufrufer MUSS MarlinConfig.h vorher eingebunden haben.
// FAIL CLOSED: fehlt der Pin oder ist DUAL_X_CARRIAGE nicht aktiv, liefert t1_parked_electrically() immer false (Guard verweigert).
// ANNAHMEN, die erst am Geraet belegt werden (HIL): (1) X_MAX_PIN ist der Schalter des T1-Schlittens (am ORIGINAL-Geraet am 02.11.2026 signalseitig bestaetigt, H02/H03: x_max TRIGGERED nur mit T1 rechts, x_min mit T0 links; der T1-Heimatwert ist dort 365,35, nicht 362; fuer DIESE Firmware weiterhin kein Hardwaretest); (2) bei der echten Konfiguration
// (X_MAX_ENDSTOP_INVERTING=true, Pull-up) liest ein Kabelbruch als NICHT ausgeloest, die Pruefung faellt dann geschlossen; (3) nach G28 bleibt der
// Schalter gedrueckt (HOMING_BACKOFF_POST_MM ist in der echten Configuration_adv.h auskommentiert). Ein gedrueckter Schalter allein ist KEIN Beweis fuer
// Kollisionsfreiheit; er ist eine zusaetzliche, von der Software-Buchfuehrung unabhaengige Verweigerungsbedingung.
// GRENZE (Stand 20, praezisiert): X_MAX_PIN (PE15) ist der Schalter von T1; endstops.cpp 634-635 wertet ihn nur fuer Bewegungen von T1 aus (X_MAX_TEST), T0 hat X_MIN_PIN (PD10). Bei save_dual_x_carriage_mode 1/4 erlaubt der OEM T0 softwareseitig bis dual_max_x (365,35; motion.cpp 718-733): ein Pegel an X_MAX wuerde T0 dort NICHT stoppen. Gedrueckt beweist daher nicht, dass T1 ihn drueckt.
// Deshalb muss zusaetzlich die gefuehrte X-Position des aktiven Werkzeugs (T0) <= X_MAX_POS sein (NaN verweigert); T0 kann dann den Schalter (T1-Heimatposition, 365,35 am Geraet) nicht beruehren: das ist Buchfuehrung, KEIN Hardwarebeweis.
#pragma once
namespace sv04next {
#if ENABLED(DUAL_X_CARRIAGE) && PIN_EXISTS(X_MAX)
  constexpr bool t1_park_sense_available = true;
  inline bool t1_parked_electrically() { return READ(X_MAX_PIN) != X_MAX_ENDSTOP_INVERTING && current_position.x <= X_MAX_POS; }
#else
  constexpr bool t1_park_sense_available = false;
  inline bool t1_parked_electrically() { return false; }   // fail closed
#endif
}  // namespace sv04next
