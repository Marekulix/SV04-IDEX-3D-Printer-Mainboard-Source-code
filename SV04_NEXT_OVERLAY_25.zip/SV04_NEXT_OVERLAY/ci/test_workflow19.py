"""Neue Schritte von 19.yml gegen ein ECHTES Test-ELF mit echten Binutils: Commit-SHA, Erreichbarkeitsanalyse (gruener/roter Pfad, ohne Toolchain), Reproduzierbarkeitspruefung
(identisch/verschieden), Repository-Inventar, Host-Test-Job. Auf GitHub NICHT ausgefuehrt."""
import json, os, shutil, stat, subprocess, tempfile
from pathlib import Path
import yaml
HERE = Path(__file__).resolve().parent


def test_19_steps():
    ok = 0
    def ck(c, m=''):
        nonlocal ok; assert c, m; ok += 1
    d19 = yaml.safe_load((HERE / '19.yml').read_text()); tree = HERE.parent
    ck(set(d19['jobs']) == {'diagnose', 'host-tests', 'build'} and d19['permissions'] == {'contents': 'read'}, 'Jobs/Rechte')
    for jn, j in d19['jobs'].items():
        ups = [st for st in j['steps'] if st.get('uses', '').startswith('actions/upload-artifact')]; ck(len(ups) == 1 and ups[0]['if'] == 'always()', f'{jn}: Upload nicht immer')
    bstep = {x['name']: x['run'] for x in d19['jobs']['build']['steps'] if 'run' in x and 'name' in x}['Commit-SHA, Binary-Erreichbarkeit und Reproduzierbarkeit']
    istep = {x['name']: x['run'] for x in d19['jobs']['diagnose']['steps'] if 'run' in x and 'name' in x}['Repository-Inventar (Workflow-Nummern, Display-Ressourcen, Zeitstempel im Quelltext)']
    work = Path(tempfile.mkdtemp()); (work / 'out').mkdir()
    (work / 't.cpp').write_text('namespace sv04next { int g29u_receipt = 1, native_thermal_gate = 2, t1_endstop_observer = 3; }\nstruct GcodeSuite { static void G29(); }; void GcodeSuite::G29() { sv04next::g29u_receipt++; }\nvoid RTSUpdate() { GcodeSuite::G29(); }\nint main() { RTSUpdate(); return 0; }\n')
    ck(subprocess.run(['g++', '-O0', '-o', str(work / 'fw.elf'), str(work / 't.cpp')]).returncode == 0, 'Test-ELF')
    home = work / 'home'; tc = home / '.platformio/packages/toolchain-gccarmnoneeabi/bin'; tc.mkdir(parents=True)
    for tool in ('nm', 'size', 'objdump', 'strings'):
        w = tc / f'arm-none-eabi-{tool}'; w.write_text(f'#!/usr/bin/env bash\nexec {tool} "$@"\n'); w.chmod(w.stat().st_mode | stat.S_IEXEC)
    fb = work / 'fb'; fb.mkdir(); pio = fb / 'pio'
    pio.write_text('#!/usr/bin/env bash\nB=.pio/build/STM32F103RET6_creality; mkdir -p $B; cp "$FAKE_ELF" $B/firmware.elf; if [ "$FAKE_NONDET" = "1" ]; then echo "SV04 NEXT G29U built $(date +%s%N) 2026" > $B/firmware.bin; else echo "SV04 NEXT G29U fw" > $B/firmware.bin; fi; echo SUCCESS\n'); pio.chmod(pio.stat().st_mode | stat.S_IEXEC)
    shutil.copytree(tree / 'tools', work / 'SV04_NEXT_OVERLAY/tools', ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    def fill(txt, V, repro='yes'): return txt.replace('${{ inputs.overlay_dir }}', 'SV04_NEXT_OVERLAY').replace('${{ matrix.variant }}', V).replace('${{ inputs.env_name }}', 'STM32F103RET6_creality').replace('${{ inputs.repro_check }}', repro)
    def run(txt, **kw):
        env = dict(os.environ, HOME=str(home), GITHUB_STEP_SUMMARY=str(work / 'sum.md'), GITHUB_WORKSPACE=str(work), GITHUB_SHA='abcdef0123456789', PATH=str(fb) + ':' + os.environ['PATH'], FAKE_ELF=str(work / 'fw.elf'), **kw)
        return subprocess.run(['bash', '-c', txt], cwd=work, capture_output=True, text=True, env=env)
    def fresh():
        shutil.rmtree(work / 'out', ignore_errors=True); (work / 'out').mkdir()
    subprocess.run(['git', 'init', '-q'], cwd=work, check=True); subprocess.run(['git', '-c', 'user.email=t@t', '-c', 'user.name=t', 'commit', '-q', '--allow-empty', '-m', 'x'], cwd=work, check=True)
    rd = lambda f: (work / 'out' / f).read_text().strip()
    seed = 'mkdir -p .pio/build/STM32F103RET6_creality; cp "$FAKE_ELF" .pio/build/STM32F103RET6_creality/firmware.elf; echo "SV04 NEXT G29U fw" > .pio/build/STM32F103RET6_creality/firmware.bin'
    run(seed); r = run(fill(bstep, 'overlay')); ck(r.returncode == 0, r.stderr[-300:]); head = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=work, capture_output=True, text=True).stdout.strip()
    ck(head in rd('commit.txt') and 'GITHUB_SHA=abcdef0123456789' in rd('commit.txt'), 'Commit-SHA')
    ck(not (work / 'out/reach.skipped').exists() and (work / 'out/reach.json').is_file() and (work / 'out/symbols.txt').stat().st_size > 0, 'Analyse nicht gelaufen')
    rep = json.loads((work / 'out/reach.json').read_text()); bad = [x['name'] for x in rep['results'] if not x['passed']]
    ck(rd('reach.exit') == '0' and not bad and rep['all_expectations_met'], 'gruener Pfad: das Test-ELF erfuellt das Profil overlay vollstaendig: ' + str(bad))
    ck('SV04 NEXT G29U' in rd('bin-strings-sv04.txt'), 'strings des Binary')
    fresh(); r = run(fill(bstep, 'overlay-auto60')); rep = json.loads((work / 'out/reach.json').read_text()); ck(r.returncode == 0 and rd('reach.exit') == '1' and any(not x['passed'] and 'Auto60' in x['name'] for x in rep['results']), 'roter Pfad: Profil overlay-auto60 verlangt Auto60-Symbole, die das Test-ELF nicht hat')
    fresh(); r = run(fill(bstep, 'probe')); ck(r.returncode == 0 and rd('reach.exit') == '1', 'probe wird wie baseline bewertet; Test-ELF enthaelt sv04next-Symbole -> Verletzung')
    fresh(); r = run(fill(bstep, 'baseline'), FAKE_NONDET='0'); ck(r.returncode == 0 and rd('repro.txt').endswith('IDENTISCH') and rd('repro.exit') == '0', r.stderr[-300:] + (work / 'out/repro.txt').read_text())
    fresh(); run('mkdir -p .pio/build/STM32F103RET6_creality; echo "SV04 NEXT G29U built 111 2026" > .pio/build/STM32F103RET6_creality/firmware.bin; cp "$FAKE_ELF" .pio/build/STM32F103RET6_creality/firmware.elf')
    r = run(fill(bstep, 'baseline'), FAKE_NONDET='1'); ck(r.returncode == 0 and rd('repro.txt').endswith('VERSCHIEDEN') and int(rd('repro-diff-bytes.txt')) > 0 and '2026' in (work / 'out/repro-datestrings.txt').read_text(), (work / 'out/repro.txt').read_text())
    fresh(); run(seed); r = run(fill(bstep, 'baseline', 'no')); ck(not (work / 'out/repro.txt').exists(), 'repro_check=no muss ueberspringen')
    fresh(); run(seed); shutil.rmtree(home / '.platformio'); r = run(fill(bstep, 'overlay')); ck(r.returncode == 0 and (work / 'out/reach.skipped').is_file() and not (work / 'out/reach.exit').exists(), 'ohne Toolchain muss sauber uebersprungen werden')
    (work / '.github/workflows').mkdir(parents=True); [(work / '.github/workflows' / n).write_text('x') for n in ('2.yml', '10.yml', '9.yml', '18.yml')]; (work / 'DWIN_SET').mkdir(); (work / 'DWIN_SET/13touch.bin').write_text('x'); (work / 'Marlin').mkdir(); (work / 'Marlin/Version.h').write_text('#define D __DATE__ " " __TIME__\n')
    subprocess.run(['git', 'add', '-A'], cwd=work, check=True); subprocess.run(['git', '-c', 'user.email=t@t', '-c', 'user.name=t', 'commit', '-q', '-m', 'y'], cwd=work, check=True); fresh()
    r = run(istep); ck(r.returncode == 0 and rd('workflows-present.txt').split() == ['2.yml', '9.yml', '10.yml', '18.yml'] and 'DWIN_SET/13touch.bin' in rd('display-assets.txt') and '__DATE__' in rd('timestamp-sources.txt'), r.stderr[-300:] + (work / 'out/workflows-present.txt').read_text())
    hs = {x['name']: x['run'] for x in d19['jobs']['host-tests']['steps'] if 'run' in x and 'name' in x}; ck('run_all_local.sh' in hs['Host-Testsuite auf sauberer CI-Maschine'] and 'pyyaml' in hs['Hilfspakete fuer die Tests'], 'host-tests')
    print(f'PASS 19.yml neue Schritte: {ok} Pruefungen (Commit-SHA, Erreichbarkeit gegen ECHTES Test-ELF mit Binutils, Reproduzierbarkeit identisch/verschieden, Inventar mit Workflow-Nummern, Host-Test-Job); auf GitHub NICHT ausgefuehrt')


if __name__ == '__main__': test_19_steps()
