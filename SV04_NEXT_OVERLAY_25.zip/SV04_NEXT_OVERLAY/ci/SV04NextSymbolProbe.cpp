// SV04 NEXT 14: Symbol-Probe. NUR Build-Diagnose, KEIN Laufzeitcode, wird nur in der CI-Variante "probe" in die Laufzeitkopie kopiert (nie ins Repository).
// Zweck: jeden Marlin-Namen, den die Bruecke (SV04NextAuto60Glue.hpp) und der eingefuegte G28/G29/RTS-Code verwenden, EINZELN gegen den echten Quelltext zu uebersetzen,
// damit der Compiler ALLE fehlenden oder falsch geschriebenen Namen auf einmal meldet. Zusaetzlich meldet sie die aktive Konfiguration ("SV04PROBE ..." im Build-Log).
#include "../../inc/MarlinConfig.h"
#include <string.h>   // memcpy (vom eingefuegten G29-Rollback benutzt)
#include <math.h>     // isfinite, isnan

#if __has_include("../../MarlinCore.h")
  #include "../../MarlinCore.h"
#else
  #error "SV04PROBE: fehlt src/MarlinCore.h"
#endif
#if __has_include("../../module/temperature.h")
  #include "../../module/temperature.h"
#else
  #error "SV04PROBE: fehlt src/module/temperature.h"
#endif
#if __has_include("../../module/planner.h")
  #include "../../module/planner.h"
#else
  #error "SV04PROBE: fehlt src/module/planner.h"
#endif
#if __has_include("../../module/motion.h")
  #include "../../module/motion.h"
#else
  #error "SV04PROBE: fehlt src/module/motion.h"
#endif
#if __has_include("../../module/probe.h")
  #include "../../module/probe.h"
#else
  #error "SV04PROBE: fehlt src/module/probe.h"
#endif
#if __has_include("../../gcode/queue.h")
  #include "../../gcode/queue.h"
#else
  #error "SV04PROBE: fehlt src/gcode/queue.h"
#endif
#if __has_include("../../gcode/gcode.h")
  #include "../../gcode/gcode.h"
#else
  #error "SV04PROBE: fehlt src/gcode/gcode.h"
#endif
#if __has_include("../bedlevel/bedlevel.h")
  #include "../bedlevel/bedlevel.h"
#else
  #error "SV04PROBE: fehlt src/feature/bedlevel/bedlevel.h"
#endif
#if ENABLED(RTS_AVAILABLE)
  #if __has_include("../../lcd/e3v2/creality/LCD_RTS.h")
    #include "../../lcd/e3v2/creality/LCD_RTS.h"
  #else
    #error "SV04PROBE: RTS_AVAILABLE, aber fehlt src/lcd/e3v2/creality/LCD_RTS.h"
  #endif
#endif

// ---- Konfigurations-Fingerabdruck (erscheint als "note: #pragma message" im Build-Log)
#if ENABLED(DUAL_X_CARRIAGE)
  #pragma message("SV04PROBE DUAL_X_CARRIAGE=AN")
#else
  #pragma message("SV04PROBE DUAL_X_CARRIAGE=AUS")
#endif
#if ENABLED(AUTO_BED_LEVELING_BILINEAR)
  #pragma message("SV04PROBE AUTO_BED_LEVELING_BILINEAR=AN")
#else
  #pragma message("SV04PROBE AUTO_BED_LEVELING_BILINEAR=AUS")
#endif
#if ENABLED(PROBE_MANUALLY)
  #pragma message("SV04PROBE PROBE_MANUALLY=AN")
#else
  #pragma message("SV04PROBE PROBE_MANUALLY=AUS")
#endif
#if ENABLED(RTS_AVAILABLE)
  #pragma message("SV04PROBE RTS_AVAILABLE=AN")
#else
  #pragma message("SV04PROBE RTS_AVAILABLE=AUS")
#endif
#if ENABLED(G29_RETRY_AND_RECOVER)
  #pragma message("SV04PROBE G29_RETRY_AND_RECOVER=AN")
#else
  #pragma message("SV04PROBE G29_RETRY_AND_RECOVER=AUS")
#endif
#if ENABLED(FULL_REPORT_TO_HOST_FEATURE)
  #pragma message("SV04PROBE FULL_REPORT_TO_HOST_FEATURE=AN")
#else
  #pragma message("SV04PROBE FULL_REPORT_TO_HOST_FEATURE=AUS")
#endif

// ---- Marlin-Namen der Bruecke (jede Funktion getrennt, damit der Compiler jeden Fehler einzeln meldet)
void sv04probe_set_bed_target()   { thermalManager.setTargetBed(60); }
void sv04probe_enqueue()          { (void)queue.enqueue_one_P(PSTR("G28")); }
void sv04probe_queue_busy()       { (void)queue.has_commands_queued(); }
void sv04probe_temperatures()     { (void)thermalManager.degBed(); (void)thermalManager.degTargetBed(); }
void sv04probe_planner()          { (void)planner.has_blocks_queued(); (void)planner.leveling_active; }
void sv04probe_status()           { (void)IsStopped(); (void)printJobOngoing(); (void)printingIsPaused(); }
void sv04probe_probe_offset()     { (void)probe.offset.z; }
void sv04probe_time()             { (void)millis(); }
void sv04probe_extruder()         { (void)active_extruder; }

// ---- Namen des eingefuegten G28/G29/RTS-Codes (nur wenn die Overlay-Bedingung gilt)
#if ENABLED(DUAL_X_CARRIAGE)
  void sv04probe_idex1()          { (void)dual_x_carriage_mode; (void)DXC_AUTO_PARK_MODE; }
  void sv04probe_idex2()          { (void)inactive_extruder_x; }
  void sv04probe_idex3()          { (void)X2_MAX_POS; }
#endif
void sv04probe_trust()            { (void)axis_is_trusted(X_AXIS); (void)axis_is_trusted(Y_AXIS); (void)axis_is_trusted(Z_AXIS); }
#if ENABLED(AUTO_BED_LEVELING_BILINEAR)
  void sv04probe_mesh1()          { (void)z_values[0][0]; }
  void sv04probe_mesh2()          { (void)bilinear_start.x; (void)bilinear_grid_spacing.x; }
  void sv04probe_mesh3()          { refresh_bed_level(); }
  void sv04probe_mesh4()          { set_bed_leveling_enabled(false); }
  void sv04probe_mesh5()          { (void)GRID_MAX_POINTS_X; (void)GRID_MAX_POINTS_Y; }
#endif
#if ENABLED(RTS_AVAILABLE)
  void sv04probe_rts1()           { rtscheck.RTS_SndData(0, AUTO_BED_LEVEL_1POINT_VP); }
  void sv04probe_rts2()           { RTS_AutoBedLevelPage(); }
  void sv04probe_rts3()           { (void)AUTO_BED_LEVEL_ICON_VP; }
#endif

// ---- weitere Namen aus dem eingefuegten RTS-/G29-Code (seit v9 nie gegen echten Marlin-Code uebersetzt)
#if PIN_EXISTS(X_MAX)
  void sv04probe_xmax_pin()       { (void)(READ(X_MAX_PIN) != X_MAX_ENDSTOP_INVERTING); }
  #pragma message("SV04PROBE X_MAX_PIN vorhanden")
#else
  #pragma message("SV04PROBE X_MAX_PIN FEHLT: der Endschalter-Beobachter im RTS-Code wird dann nicht aktiv")
#endif
void sv04probe_types()            { xy_pos_t p; xy_float_t f; (void)p; (void)f; int8_t i = 0; (void)i; }
void sv04probe_parser()           { (void)parser.seen_test('U'); }
void sv04probe_serial()           { SERIAL_ECHOLNPGM("SV04PROBE"); SERIAL_ERROR_MSG("SV04PROBE"); }
void sv04probe_math()             { (void)ABS(-1.0f); (void)NAN; }
void sv04probe_math2()            { float a = 1.0f; (void)isfinite(a); (void)isnan(a); float b[2][2] = {{0, 0}, {0, 0}}, c[2][2]; memcpy(c, b, sizeof(c)); (void)c; }
