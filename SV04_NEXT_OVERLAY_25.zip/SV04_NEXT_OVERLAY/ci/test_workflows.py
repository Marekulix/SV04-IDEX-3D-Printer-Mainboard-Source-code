"""Lokaler Test der Workflow-Skripte auf SYNTHETISCHEN Repositories (kein GitHub, kein echtes OEM). Extrahiert die Heredoc-Skripte aus den YAML-Dateien und führt sie aus."""
import base64, gzip, hashlib, io, json, os, re, shutil, subprocess, sys, tarfile, tempfile
from pathlib import Path
import yaml
HERE = Path(__file__).resolve().parent
def blob(b): return hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
def steps(wf, job): return yaml.safe_load((HERE / wf).read_text(encoding='utf-8'))['jobs'][job]['steps']
def heredoc(run, tag='PY'):
    m = re.search(r"<<'%s'\n(.*?)\n%s\n" % (tag, tag), run, re.S); assert m, 'kein Heredoc'; return m.group(1)
def git(cwd, *a): return subprocess.run(['git', *a], cwd=cwd, capture_output=True, text=True, check=True).stdout.strip()
def mk_repo():
    d = Path(tempfile.mkdtemp()); git(d, 'init', '-q'); git(d, 'config', 'user.email', 't@t'); git(d, 'config', 'user.name', 't')
    files = {'Marlin/Configuration.h': b'#define X 1\n', 'Marlin/src/module/probe.cpp': b'// probe\r\nint a;\r\n', 'Marlin/src/gcode/bedlevel/abl/G29.cpp': '// G29 注释\n'.encode('gbk'), 'Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp': b'// rts v1\n'}
    for n, b in files.items(): p = d / n; p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(b)
    (d / 'platformio.ini').write_text('[platformio]\ndefault_envs = STM32F103RET6_creality\n[env:STM32F103RET6_creality]\nbuild_flags = -std=gnu++14 -ffast-math -Os\n[env:other]\n')
    # Payload 1: gzip(tar) mit zwei Dateien und einem Path-Traversal-Eintrag
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode='w') as t:
        for name, data in (('SV04NextG29UReceipt.hpp', b'// receipt\n'), ('integration/apply_native_guard_v2.py', b'# v2\n'), ('docs/big.bin', os.urandom(4000)), ('../evil.txt', b'EVIL')):
            ti = tarfile.TarInfo(name); ti.size = len(data); t.addfile(ti, io.BytesIO(data))
    b64 = base64.b64encode(gzip.compress(buf.getvalue(), 9)).decode(); wrapped = '\n'.join(b64[i:i + 76] for i in range(0, len(b64), 76))
    wf = d / '.github/workflows'; wf.mkdir(parents=True)
    (wf / '1.yml').write_text("name: '1'\non:\n  workflow_dispatch:\npermissions:\n  contents: read\njobs:\n  j:\n    runs-on: ubuntu-22.04\n    steps:\n      - run: |\n          echo restore\n          cat <<'EOF' | base64 -d | gunzip | tar x\n" + '\n'.join('          ' + l for l in wrapped.splitlines()) + "\n          EOF\n")
    txt = base64.b64encode(('# Quelle\n' + 'x = 1\n' * 300).encode()).decode()
    (wf / '2.yml').write_text("name: '2'\non:\n  workflow_dispatch:\npermissions:\n  contents: read\njobs:\n  j:\n    runs-on: ubuntu-22.04\n    steps:\n      - run: echo " + txt + " | base64 -d > a.txt\n")
    (wf / '3.yml').write_text("name: '3'\non:\n  workflow_dispatch:\npermissions:\n  contents: read\njobs:\n  j:\n    runs-on: ubuntu-22.04\n    steps:\n      - run: echo hallo\n")
    (wf / '9.yml').write_text("name: kaputt\non: [\n  - run: " + txt + "\n")   # ungültiges YAML mit Payload
    git(d, 'add', '-A'); git(d, 'commit', '-qm', 'c1')
    old = {n: blob(b) for n, b in files.items()}
    (d / 'Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp').write_bytes(b'// rts v2 geaendert\n'); git(d, 'commit', '-qam', 'c2')   # Arbeitsbaum weicht ab, c1 hatte den erwarteten Blob
    exp = dict(old); exp['Marlin/src/gcode/calibrate/G28.cpp'] = '5' * 40   # Datei fehlt
    return d, exp
def run_inventur():
    d, exp = mk_repo(); code = heredoc(steps('5.yml', 'inventur')[2]['run']); env = dict(os.environ, SV04_OEM_BLOBS_JSON=json.dumps(exp))
    r = subprocess.run([sys.executable, '-'], input=code, cwd=d, capture_output=True, text=True, env=env); assert r.returncode == 0, r.stderr[-800:]
    inv = json.loads((d / 'out/inventur.json').read_text()); return d, exp, inv, r.stdout
def main():
    ok = 0
    def ck(c, m):
        nonlocal ok; assert c, m; ok += 1
    d, exp, inv, out = run_inventur()
    wfs = {w['file']: w for w in inv['workflows']}
    ck(set(wfs) == {'1.yml', '2.yml', '3.yml', '9.yml'}, 'Workflow-Liste'); ck(len(wfs['1.yml']['payloads']) == 1 and wfs['1.yml']['payloads'][0]['type'] == 'gzip' and wfs['1.yml']['payloads'][0]['inner']['type'] == 'tar', 'gzip+tar nicht erkannt')
    mem = {m['name']: m for m in wfs['1.yml']['payloads'][0]['inner']['members']}; ck(mem['SV04NextG29UReceipt.hpp']['sha256'] == hashlib.sha256(b'// receipt\n').hexdigest(), 'Hash eines Mitglieds'); ck(mem['../evil.txt']['safe_path'] is False and mem['../evil.txt']['sha256'] is None, 'Traversal nicht gemeldet')
    ck((d / 'out/payloads/1/01/SV04NextG29UReceipt.hpp').is_file() and (d / 'out/payloads/1/01/integration/apply_native_guard_v2.py').is_file(), 'Mitglieder nicht entpackt'); ck(not (d / 'out/payloads/1/evil.txt').exists() and not (d / 'out/payloads/evil.txt').exists() and not (d / 'evil.txt').exists() and not (d.parent / 'evil.txt').exists(), 'Path-Traversal wurde GESCHRIEBEN')
    ck(wfs['2.yml']['payloads'][0]['type'] == 'text' and wfs['2.yml']['payloads'][0]['first_lines'][0] == '# Quelle', 'Textpayload'); ck(wfs['3.yml']['payloads'] == [], 'Workflow ohne Payload'); ck('yaml_error' in wfs['9.yml'] and len(wfs['9.yml']['payloads']) == 1, 'defektes YAML: Rohscan fehlt')
    ck(wfs['1.yml']['permissions'] == {'contents': 'read'} and wfs['1.yml']['triggers'] == ['workflow_dispatch'], 'Trigger/Rechte')
    oem = inv['oem']; ck(oem['Marlin/Configuration.h']['match_worktree'] is True, 'Blob passt'); ck(oem['Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp']['match_worktree'] is False and len(oem['Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp']['commits_with_expected_blob']) == 1, 'Historiensuche'); ck(oem['Marlin/src/gcode/calibrate/G28.cpp']['exists'] is False, 'fehlende Datei')
    e = inv['encoding']; ck(e['crlf'] >= 1 and any('G29.cpp' in p for p in e['not_utf8']) and e['oem']['Marlin/src/module/probe.cpp']['crlf'] is True, 'Kodierung/CRLF'); ck(inv['build']['fast_math_lines'] == ['build_flags = -std=gnu++14 -ffast-math -Os'] and inv['build']['has_STM32F103RET6_creality'], 'Build-Flags')
    st = git(d, 'status', '--porcelain'); ck(all(l.strip().endswith('out/') for l in st.splitlines()), 'Skript hat ausserhalb von out/ geschrieben: ' + st)
    ck(out.count('ABWEICHEND') == 1 and 'FEHLT' in out, 'Zusammenfassung')
    print(f'PASS 5.yml-Inventur auf synthetischem Repository: {ok} Prüfungen; Workflow wurde NICHT auf GitHub ausgeführt')
if __name__ == '__main__': main()

# ---------------------------------------------------------------- 4.yml und 6.yml
def sub_expr(s): return re.sub(r'\$\{\{\s*([^}]*?)\s*\}\}', lambda m: {'matrix.variant': 'overlay'}.get(m.group(1), 'X'), s)
def wf_repo(files):
    d = Path(tempfile.mkdtemp()); (d / '.github/workflows').mkdir(parents=True)
    for n, t in files.items(): (d / '.github/workflows' / n).write_text(t)
    return d
GOOD = "name: '{n}'\non:\n  workflow_dispatch:\npermissions:\n  contents: read\njobs:\n  j:\n    runs-on: ubuntu-22.04\n    steps:\n      - uses: actions/checkout@v4\n      - run: echo hallo\n"
def run4(files, workflow='4.yml', env=None):
    run = yaml.safe_load((HERE / workflow).read_text())['jobs']['audit']['steps'][2 if workflow == '4.yml' else 1]['run']
    d = wf_repo(files); r = subprocess.run(['bash', '-c', sub_expr(run)], cwd=d, capture_output=True, text=True, env=dict(os.environ, **(env or {}))); return r.returncode, r.stdout, r.stderr
def test_4():
    ok = 0
    def ck(c, m):
        nonlocal ok; assert c, m; ok += 1
    good = {f'{i}.yml': GOOD.format(n=i) for i in (1, 2, 3)}
    rc, out, err = run4(good); ck(rc == 0 and 'PASS' in out, 'gutes Repo: ' + err[-200:])
    for label, files, want in [
      ('Schreibrecht', {**good, '1.yml': GOOD.format(n=1).replace('contents: read', 'contents: write')}, 'Schreibrecht'),
      ('write-all auf Job-Ebene', {**good, '2.yml': GOOD.format(n=2).replace('    runs-on', '    permissions: write-all\n    runs-on')}, 'Schreibrecht'),
      ('Flash-Werkzeug', {**good, '3.yml': GOOD.format(n=3).replace('echo hallo', 'dfu-util -a 0 -D fw.bin')}, 'Flash-Werkzeug'),
      ('Workflow fehlt', {k: v for k, v in good.items() if k != '2.yml'}, 'FEHLT'),
      ('kaputtes YAML', {**good, '1.yml': 'name: [kaputt\n'}, 'YAML nicht lesbar'),
      ('Kommentar tarnt Schreibrecht', {**good, '1.yml': GOOD.format(n=1).replace('  contents: read', '  contents: write   # contents: read')}, 'Schreibrecht')]:
        rc, out, err = run4(files); ck(rc == 1 and want in err, f'{label}: rc={rc} {err[-200:]}')
    rc, out, err = run4({**good, '1.yml': GOOD.format(n=1).replace('workflow_dispatch:', 'pull_request_target:\n  workflow_dispatch:')}); ck(rc == 0 and 'WARNUNG' in out and 'pull_request_target' in out, 'Ausloeser-Warnung')
    rc, out, err = run4({**good, '1.yml': GOOD.format(n=1).replace('checkout@v4', 'checkout@main')}); ck(rc == 0 and 'Branch' in out, 'Branch-Referenz-Warnung')
    # Gegenbeweis: das Skript des ORIGINAL-Entwurfs meldet PASS, obwohl contents: write gesetzt ist
    bad = {**good, '1.yml': GOOD.format(n=1).replace('  contents: read', '  contents: write   # contents: read')}
    orig = yaml.safe_load((HERE / '4_original_entwurf.yml').read_text())['jobs']['audit']['steps'][1]['run']; d = wf_repo(bad); r = subprocess.run(['bash', '-c', orig], cwd=d, capture_output=True, text=True)
    print('   Original-Entwurf gegen "contents: write" + Kommentar: Exit', r.returncode, '|', (r.stdout.strip().splitlines() or [''])[-2][:90]); ck(r.returncode == 0, 'Original-Entwurf hätte hier durchfallen sollen (Erwartung: false green)')
    print(f'PASS 4.yml: {ok} Prüfungen (inkl. Beleg, dass der Original-Entwurf ein Schreibrecht übersieht)')
def test_6():
    ok = 0
    def ck(c, m):
        nonlocal ok; assert c, m; ok += 1
    d6 = yaml.safe_load((HERE / '6.yml').read_text()); inp = d6[True]['workflow_dispatch']['inputs']; ck(inp['upload_binary']['default'] == 'no' and inp['upload_binary']['options'] == ['no', 'yes'], 'Binär-Upload nicht standardmäßig aus')
    ck(d6['permissions'] == {'contents': 'read'}, 'Rechte'); allrun = []
    ck(d6['jobs']['build']['strategy']['matrix']['variant'] == ['baseline', 'overlay', 'overlay-auto60'], 'Build-Varianten')
    t6 = (HERE / '6.yml').read_text(); ck(t6.count('-DSV04_NEXT_AUTO60_ENGINE') == 2 and t6.count("PLATFORMIO_BUILD_FLAGS='-DSV04_NEXT_AUTO60_ENGINE'") == 1 and "= 'overlay-auto60' ]; then export PLATFORMIO_BUILD_FLAGS" in t6, 'Makro nur fuer overlay-auto60')
    ck('apply_native_guard_v16.py' in t6 and 'apply_native_guard_v15.py' not in t6, 'Overlay-Skript v16')
    for jn, j in d6['jobs'].items():
        ck('permissions' not in j or j['permissions'] == {'contents': 'read'}, 'Job-Rechte')
        for s in j['steps']:
            if 'run' in s:
                t = sub_expr(s['run']); r = subprocess.run(['bash', '-n'], input=t, capture_output=True, text=True); ck(r.returncode == 0, f'bash -n {jn}/{s.get("name")}: {r.stderr[:200]}'); allrun.append(s['run'])
    txt = '\n'.join(allrun); ck(not re.search(r'git\s+(push|commit)|gh\s+|--force|settings\.save|M500', txt), 'Push/Commit/EEPROM im Workflow'); ck('NOT_FLASHABLE' in txt and 'UNVERIFIED-DO-NOT-FLASH' in txt, 'Warnnamen')
    # Overlay-ZIP-Schritt: entpackt nur in die Laufzeitkopie, prüft SHA256, verweigert bei Abweichung
    import zipfile
    zs = [s for s in d6['jobs']['build']['steps'] if s.get('name', '').startswith('Overlay-ZIP')][0]['run']; dz = Path(tempfile.mkdtemp()); (dz / 'o').mkdir(); (dz / 'o/a.txt').write_text('x')
    with zipfile.ZipFile(dz / 'SV04_NEXT_OVERLAY.zip', 'w') as z: z.write(dz / 'o/a.txt', 'SV04_NEXT_OVERLAY/a.txt')
    good_h = hashlib.sha256((dz / 'SV04_NEXT_OVERLAY.zip').read_bytes()).hexdigest(); envz = dict(os.environ, GITHUB_STEP_SUMMARY=str(dz / 's.md'))
    r = subprocess.run(['bash', '-c', zs.replace("${{ inputs.overlay_zip_sha256 }}", '').replace("${{ inputs.overlay_dir }}", 'SV04_NEXT_OVERLAY')], cwd=dz, capture_output=True, text=True, env=envz); ck(r.returncode == 0 and (dz / 'SV04_NEXT_OVERLAY/a.txt').is_file(), 'ZIP entpacken (ohne erwartetes SHA): ' + r.stderr[-200:])
    r = subprocess.run(['bash', '-c', zs.replace("${{ inputs.overlay_zip_sha256 }}", good_h).replace("${{ inputs.overlay_dir }}", 'SV04_NEXT_OVERLAY')], cwd=dz, capture_output=True, text=True, env=envz); ck(r.returncode == 0, 'ZIP mit passendem SHA')
    r = subprocess.run(['bash', '-c', zs.replace("${{ inputs.overlay_zip_sha256 }}", '0' * 64).replace("${{ inputs.overlay_dir }}", 'SV04_NEXT_OVERLAY')], cwd=dz, capture_output=True, text=True, env=envz); ck(r.returncode == 1 and 'abgebrochen' in r.stdout, 'ZIP mit falschem SHA muss abbrechen')
    # Blob-Prüfung (Heredoc des Build-Jobs) auf synthetischem Repository
    d, exp = mk_repo(); step = [s for s in d6['jobs']['build']['steps'] if s.get('name', '').startswith('OEM-Quellstand')][0]['run']
    (d / 'out').mkdir(exist_ok=True); r = subprocess.run(['bash', '-c', sub_expr(step)], cwd=d, capture_output=True, text=True, env=dict(os.environ, SV04_OEM_BLOBS_JSON=json.dumps(exp), GITHUB_STEP_SUMMARY=str(d / 'sum.md')))
    ck(r.returncode == 0 and (d / 'out/oem-blobs.ok').read_text() == '0' and r.stdout.count('ABWEICHUNG') == 2, 'Blob-Prüfung (2 Abweichungen erwartet: geänderte und fehlende Datei): ' + r.stdout[-300:])
    exp2 = {k: v for k, v in exp.items() if k != 'Marlin/src/gcode/calibrate/G28.cpp' and k != 'Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp'}; r = subprocess.run(['bash', '-c', sub_expr(step)], cwd=d, capture_output=True, text=True, env=dict(os.environ, SV04_OEM_BLOBS_JSON=json.dumps(exp2), GITHUB_STEP_SUMMARY=str(d / 'sum.md'))); ck((d / 'out/oem-blobs.ok').read_text() == '1' and 'ABWEICHUNG' not in r.stdout, 'passender Stand')
    print(f'PASS 6.yml: {ok} Prüfungen (Syntax aller Skripte, Rechte, Binär-Upload aus, Blob-Prüfung); pio-Build und Overlay-Anwendung NICHT lokal ausführbar')

# ---------------------------------------------------------------- 7.yml
def test_7():
    import shutil
    ok = 0
    def ck(c, m=''):
        nonlocal ok; assert c, m; ok += 1
    t7 = (HERE / '7.yml').read_text(); d7 = yaml.safe_load(t7); inp = d7[True]['workflow_dispatch']['inputs']
    ck(d7['permissions'] == {'contents': 'read'} and inp['upload_binary']['default'] == 'no' and inp['upload_binary']['options'] == ['no', 'yes'], 'Rechte/Binaer-Upload')
    ck(d7['jobs']['build']['strategy']['matrix']['variant'] == ['baseline', 'probe', 'overlay', 'overlay-auto60'] and d7['jobs']['build']['strategy']['fail-fast'] is False, 'Varianten')
    for jn, j in d7['jobs'].items():
        ck('permissions' not in j or j['permissions'] == {'contents': 'read'}, 'Job-Rechte')
        ups = [st for st in j['steps'] if st.get('uses', '').startswith('actions/upload-artifact')]; ck(len(ups) == 1 and ups[0]['if'] == 'always()', f'{jn}: Upload nicht immer')
    alltxt = '\n'.join(st['run'] for j in d7['jobs'].values() for st in j['steps'] if 'run' in st)
    ck(not re.search(r'git\s+(push|commit|add)|gh\s+|--force|settings\.save|M500|enqueue_now', alltxt), 'Push/Commit/EEPROM im Workflow')
    ck(t7.count("PLATFORMIO_BUILD_FLAGS='-DSV04_NEXT_AUTO60_ENGINE'") == 1 and "= \"overlay-auto60\" ]; then export" in alltxt and 'apply_native_guard_v16.py' in alltxt and 'apply_native_guard_v15.py' not in alltxt, 'Makro/Overlay-Skript')
    ck(alltxt.count('sv04_next_symbol_probe.cpp') == 1 and 'cp "$D/ci/SV04NextSymbolProbe.cpp" Marlin/src/feature/sv04_next/sv04_next_symbol_probe.cpp' in alltxt, 'Probe nur in die Laufzeitkopie')
    for jn, j in d7['jobs'].items():
        for st in j['steps']:
            if 'run' in st: r = subprocess.run(['bash', '-n'], input=sub_expr(st['run']), capture_output=True, text=True); ck(r.returncode == 0, f'bash -n {jn}/{st.get("name")}: {r.stderr[:200]}')
    # --- Skripte auf synthetischer Git-Wurzel mit dem ECHTEN Overlay-Ordner
    d, exp = mk_repo(); ov = d / 'SV04_NEXT_OVERLAY'; shutil.copytree(HERE.parent, ov, ignore=shutil.ignore_patterns('__pycache__', '*.pyc', 'harness', 'ci-evidence', 'proof'))
    (d / 'out').mkdir(exist_ok=True); summ = d / 'sum.md'; env0 = dict(os.environ, GITHUB_STEP_SUMMARY=str(summ), PYTHONDONTWRITEBYTECODE='1')
    def step(name, variant='baseline', extra=None):
        st = [x for x in d7['jobs']['build']['steps'] if x.get('name', '').startswith(name)][0]['run']
        t = st.replace('${{ inputs.overlay_dir }}', 'SV04_NEXT_OVERLAY').replace('${{ matrix.variant }}', variant).replace('${{ inputs.overlay_zip_sha256 }}', '').replace('${{ inputs.env_name }}', 'STM32F103RET6_creality').replace('${{ inputs.platformio_version }}', '6.1.18').replace('${{ inputs.upload_binary }}', 'no').replace('${{ inputs.repro_check }}', 'no').replace('${{ matrix.variant }}', variant)
        return subprocess.run(['bash', '-c', t], cwd=d, capture_output=True, text=True, env=dict(env0, **(extra or {})))
    # probe: Datei kommt nur in die Laufzeitkopie, an genau den vorgesehenen Pfad
    r = step('Variante vorbereiten', 'probe'); ck(r.returncode == 0 and (d / 'Marlin/src/feature/sv04_next/sv04_next_symbol_probe.cpp').is_file() and (d / 'out/probe.copied').read_text().strip() == 'kopiert', r.stderr[-200:])
    ck(open(d / 'Marlin/src/feature/sv04_next/sv04_next_symbol_probe.cpp').read() == (HERE / 'SV04NextSymbolProbe.cpp').read_text(), 'Probe-Inhalt')
    shutil.rmtree(d / 'Marlin/src/feature')
    # overlay: synthetische OEM-Dateien -> SHA-Abweichung -> Trockenlauf scheitert, Anwendung SKIPPED, Wurzel unveraendert
    before = {n: (d / n).read_bytes() for n in exp if (d / n).is_file()}
    r = step('Variante vorbereiten', 'overlay'); ck(r.returncode == 0 and (d / 'out/overlay-dry-run.exit').read_text().strip() != '0' and (d / 'out/overlay-apply.exit').read_text().strip() == 'SKIPPED', r.stdout + r.stderr)
    ck('SHA mismatch' in (d / 'out/overlay-dry-run.stderr').read_text(), (d / 'out/overlay-dry-run.stderr').read_text()[-300:]); ck(all((d / n).read_bytes() == b for n, b in before.items()), 'Quelltext veraendert')
    # build-Schritt ueberspringt, wenn das Overlay nicht angewendet wurde (kein falscher "overlay"-Build), und meldet es
    r = step('PlatformIO installieren', 'overlay'); ck(r.returncode == 0 and (d / 'out/build.exit').read_text().strip() == 'SKIPPED' and (d / 'out/build.skipped').is_file(), r.stdout + r.stderr)
    ck('SHA mismatch' in summ.read_text() or 'Build uebersprungen' in summ.read_text())
    # Bewertung: SKIPPED/fehlend = rot, 0 = gruen
    for val, want in (('0', 0), ('SKIPPED', 1), ('2', 1)):
        (d / 'out/build.exit').write_text(val + '\n'); r = step('Ergebnis bewerten'); ck(r.returncode == want, f'Bewertung {val}: {r.returncode}')
    (d / 'out/build.exit').unlink(); r = step('Ergebnis bewerten'); ck(r.returncode == 1, 'fehlendes build.exit muss rot sein')
    # Diagnose-Schritt auf der synthetischen Wurzel: laeuft durch, schreibt Bericht, Exit 0 (strenger Trockenlauf scheitert dort an der SHA-Abweichung: erwartet)
    st = [x for x in d7['jobs']['diagnose']['steps'] if x.get('name', '').startswith('Diagnose')][0]['run']; t = st.replace('${{ inputs.overlay_dir }}', 'SV04_NEXT_OVERLAY')
    shutil.rmtree(d / 'out'); r = subprocess.run(['bash', '-c', t], cwd=d, capture_output=True, text=True, env=env0); ck(r.returncode == 0 and (d / 'out/diagnose/DIAGNOSE.md').is_file() and (d / 'out/diagnose.exit').read_text().strip() == '0', r.stdout + r.stderr)
    dj = json.loads((d / 'out/diagnose/diagnose.json').read_text(encoding='utf-8')); ck(dj['strict_dry_run']['ok'] is False and 'SHA mismatch' in dj['strict_dry_run']['exception']); ck((d / 'out/diagnose/oem-sources/Marlin/src/gcode/calibrate/G28.cpp').is_file() or not (d / 'Marlin/src/gcode/calibrate/G28.cpp').is_file())
    # ohne Overlay-Ordner: Diagnose meldet es, Lauf bleibt gruen (Exit 0), Artefakt wird trotzdem erzeugt
    shutil.rmtree(d / 'out'); shutil.rmtree(ov); r = subprocess.run(['bash', '-c', t], cwd=d, capture_output=True, text=True, env=env0); ck(r.returncode == 0 and (d / 'out/diagnose.exit').read_text().strip() == '2' and 'fehlt' in (d / 'out/diagnose.stderr').read_text())
    print(f'PASS 7.yml: {ok} Pruefungen (Struktur, Rechte, Upload immer, Skripte auf synthetischer Git-Wurzel mit echtem Overlay-Ordner); auf GitHub NICHT ausgefuehrt')

# ---------------------------------------------------------------- 17.yml: Erfolgs- UND Fehlerpfad auf einem Git-Repository mit den ECHTEN OEM-Dateien
def test_17(wf='17.yml', num='17', zipname='SV04_NEXT_OVERLAY_STAND15.zip', nhead=16):
    import shutil, stat
    ok = 0
    def ck(c, m=''):
        nonlocal ok; assert c, m; ok += 1
    t17 = (HERE / wf).read_text(); d17 = yaml.safe_load(t17); inp = d17[True]['workflow_dispatch']['inputs']; tree = HERE.parent; real = tree / 'tests/oem_real'
    ck(d17['permissions'] == {'contents': 'read'} and inp['upload_binary']['default'] == 'no' and d17['jobs']['build']['strategy']['matrix']['variant'] == ['baseline', 'probe', 'overlay', 'overlay-auto60'], 'Struktur')
    ck((num + '-build-${{ matrix.variant }}') in t17 and (num + '-diagnose') in t17 and not re.search(r'git\s+(push|commit|add)|gh\s+|secrets\.|settings\.save|M500', t17), 'Namen/Schreibrechte/Secrets')
    for jn, j in d17['jobs'].items():
        ups = [st for st in j['steps'] if st.get('uses', '').startswith('actions/upload-artifact')]; ck(len(ups) == 1 and ups[0]['if'] == 'always()', f'{jn}: Upload nicht immer')
        for st in j['steps']:
            if 'run' in st: r = subprocess.run(['bash', '-n'], input=sub_expr(st['run']), capture_output=True, text=True); ck(r.returncode == 0, f'bash -n {jn}/{st.get("name")}: {r.stderr[:200]}')
    steps = {x['name']: x['run'] for x in d17['jobs']['build']['steps'] if 'run' in x and 'name' in x}
    def fill(txt, V): return txt.replace('${{ inputs.overlay_dir }}', 'SV04_NEXT_OVERLAY').replace('${{ matrix.variant }}', V).replace('${{ inputs.overlay_zip_sha256 }}', '').replace('${{ inputs.env_name }}', 'STM32F103RET6_creality').replace('${{ inputs.platformio_version }}', '6.1.18').replace('${{ inputs.upload_binary }}', 'no').replace('${{ inputs.repro_check }}', 'no')
    def mkrepo():
        d = Path(tempfile.mkdtemp()); (d / 'Marlin').mkdir(exist_ok=True)
        for p in real.rglob('*'):
            if p.is_file(): t = d / p.relative_to(real); t.parent.mkdir(parents=True, exist_ok=True); t.write_bytes(p.read_bytes())
        (d / 'platformio.ini').write_text('[platformio]\ndefault_envs = STM32F103RET6_creality\n'); shutil.copytree(tree, d / 'SV04_NEXT_OVERLAY', ignore=shutil.ignore_patterns('__pycache__', '*.pyc', 'harness', 'ci-evidence', 'proof', 'oem_real'))
        for g in (['init', '-q'], ['config', 'user.email', 't@t'], ['config', 'user.name', 't'], ['add', '-A'], ['commit', '-qm', 'oem']): subprocess.run(['git', *g], cwd=d, check=True, capture_output=True)
        (d / 'out').mkdir(); return d
    fb = Path(tempfile.mkdtemp()); pio = fb / 'pio'; pio.write_text('#!/usr/bin/env bash\nif [ "$1" = "--version" ]; then echo "PlatformIO Core, version 6.1.18"; exit 0; fi\necho "FLAGS=$PLATFORMIO_BUILD_FLAGS" > "$FAKE_PIO_ENV"\nif [ "$FAKE_PIO_FAIL" = "1" ]; then echo "src/x.cpp:1:1: error: boom"; exit 1; fi\nmkdir -p .pio/build/STM32F103RET6_creality; echo fw > .pio/build/STM32F103RET6_creality/firmware.bin\necho "RAM:   [=  ]  14.1% (used 9260 bytes from 65536 bytes)"; echo "SUCCESS"; exit 0\n'); pio.chmod(pio.stat().st_mode | stat.S_IEXEC)
    def run(d, step, V, fail=False):
        env = dict(os.environ, GITHUB_STEP_SUMMARY=str(d / 'sum.md'), GITHUB_WORKSPACE=str(d), GITHUB_SHA='abcdef0123456789', PATH=str(fb) + ':' + os.environ['PATH'], FAKE_PIO_ENV=str(d / 'pio-env.txt'), PYTHONDONTWRITEBYTECODE='1', **({'FAKE_PIO_FAIL': '1'} if fail else {}))
        txt = fill(steps[step], V).replace('python3 -m pip install --quiet "platformio==6.1.18"', 'true'); return subprocess.run(['bash', '-c', txt], cwd=d, capture_output=True, text=True, env=env)
    rd = lambda d, f: (d / 'out' / f).read_text().strip()
    for V in ('baseline', 'probe', 'overlay', 'overlay-auto60'):
        d = mkrepo(); r = run(d, 'OEM-Quellstand pruefen (Git-Blob-SHA1)', V); ck(r.returncode == 0 and rd(d, 'oem-blobs.ok') == '1', 'OEM-Blobs der ECHTEN Dateien: ' + r.stdout + r.stderr)
        r = run(d, 'Variante vorbereiten (Overlay anwenden bzw. Probe einsetzen; nur Laufzeitkopie)', V); ck(r.returncode == 0, r.stderr[-300:]); st = '\n'.join(l for l in subprocess.run(['git', 'status', '--short'], cwd=d, capture_output=True, text=True).stdout.splitlines() if l[3:] not in ('out/', '.pio/', 'sum.md', 'pio-env.txt'))
        if V in ('overlay', 'overlay-auto60'):
            ck(rd(d, 'overlay-dry-run.exit') == '0' and rd(d, 'overlay-apply.exit') == '0', f'{V}: Trockenlauf/Anwendung auf ECHTEN Dateien: ' + (d / 'out/overlay-dry-run.stderr').read_text()[-300:])
            mod = sorted(l[3:] for l in st.splitlines() if l.startswith(' M')); ck(mod == ['Marlin/src/gcode/bedlevel/abl/G29.cpp', 'Marlin/src/gcode/calibrate/G28.cpp', 'Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp'], mod)
            ck('?? Marlin/src/feature/' in st and len(list((d / 'Marlin/src/feature/sv04_next').glob('*.hpp'))) == nhead and (d / 'out/overlay-review.diff').is_file() and (d / 'out/overlay-evidence.json').is_file(), st)
            ck('Configuration.h' not in st and 'probe.cpp' not in st, 'Configuration.h/probe.cpp veraendert')
            ck((d / 'Marlin/src/gcode/calibrate/G28.cpp').read_text().count('saw_x2_homeaxis_return(') == 2)
        elif V == 'probe': ck(rd(d, 'probe.copied') == 'kopiert' and (d / 'Marlin/src/feature/sv04_next/sv04_next_symbol_probe.cpp').is_file() and not [l for l in st.splitlines() if l.startswith(' M')], st)
        else: ck(st.strip() == '', 'baseline hat den Quelltext veraendert: ' + st)
        r = run(d, 'PlatformIO installieren und bauen', V); ck(r.returncode == 0 and rd(d, 'build.exit') == '0' and (d / 'out/firmware.sha256').is_file() and (d / 'out/NOT_FLASHABLE.txt').is_file(), r.stdout + r.stderr)
        flags = (d / 'pio-env.txt').read_text().strip(); ck((flags == 'FLAGS=-DSV04_NEXT_AUTO60_ENGINE') == (V == 'overlay-auto60'), f'{V}: Makro nur bei overlay-auto60: {flags}')
        ck(not list((d / 'out').glob('firmware-UNVERIFIED*.bin')), 'Binaerdatei ohne Wunsch hochgeladen'); r = run(d, 'Ergebnis bewerten (Artefakte sind bereits hochgeladen)', V); ck(r.returncode == 0)
    # Entpackschritt: eindeutiger ZIP-Name, alter Ordner wird in der Laufzeitkopie geloescht (kein Altbestand), SHA-Pruefung, fehlende ZIP nennt Kandidaten
    import zipfile
    zst = [x for x in d17['jobs']['build']['steps'] if x.get('name', '').startswith('Overlay-ZIP')][0]['run']
    def zrun(d, name, sha=''):
        txt = zst.replace('${{ inputs.overlay_zip }}', name).replace('${{ inputs.overlay_dir }}', 'SV04_NEXT_OVERLAY').replace('${{ inputs.overlay_zip_sha256 }}', sha)
        return subprocess.run(['bash', '-c', txt], cwd=d, capture_output=True, text=True, env=dict(os.environ, GITHUB_STEP_SUMMARY=str(d / 'sum.md')))
    dz = Path(tempfile.mkdtemp()); (dz / 'out').mkdir(); (dz / 'SV04_NEXT_OVERLAY').mkdir(); (dz / 'SV04_NEXT_OVERLAY/ALTLAST.txt').write_text('alt')
    with zipfile.ZipFile(dz / zipname, 'w') as zf: zf.writestr('SV04_NEXT_OVERLAY/neu.txt', 'neu')
    zh = hashlib.sha256((dz / zipname).read_bytes()).hexdigest(); r = zrun(dz, zipname, zh)
    ck(r.returncode == 0 and (dz / 'SV04_NEXT_OVERLAY/neu.txt').is_file() and not (dz / 'SV04_NEXT_OVERLAY/ALTLAST.txt').exists(), r.stderr + r.stdout); ck(zrun(dz, zipname, '0' * 64).returncode != 0, 'falsches SHA muss abbrechen')
    r = zrun(dz, 'SV04_NEXT_OVERLAY (1).zip'); ck(zipname in (dz / 'out/overlay-zip.sha256').read_text(), 'fehlende ZIP muss Kandidaten nennen')
    # Fehlerpfad: Build schlaegt fehl -> Fehlerzeilen werden gesammelt, Bewertung rot, keine Binaerdatei
    d = mkrepo(); run(d, 'Variante vorbereiten (Overlay anwenden bzw. Probe einsetzen; nur Laufzeitkopie)', 'overlay'); r = run(d, 'PlatformIO installieren und bauen', 'overlay', fail=True)
    ck(rd(d, 'build.exit') == '1' and 'error:' in (d / 'out/build-errors.txt').read_text() and not (d / 'out/firmware.sha256').exists(), r.stdout + r.stderr); ck(run(d, 'Ergebnis bewerten (Artefakte sind bereits hochgeladen)', 'overlay').returncode == 1)
    # Overlay-Anwendung scheitert (veraenderte OEM-Datei): Build wird UEBERSPRUNGEN und nie als gruen gemeldet
    d = mkrepo(); (d / 'Marlin/src/gcode/calibrate/G28.cpp').write_text((d / 'Marlin/src/gcode/calibrate/G28.cpp').read_text() + '\n// geaendert\n'); run(d, 'Variante vorbereiten (Overlay anwenden bzw. Probe einsetzen; nur Laufzeitkopie)', 'overlay'); r = run(d, 'PlatformIO installieren und bauen', 'overlay')
    ck(rd(d, 'overlay-dry-run.exit') != '0' and rd(d, 'overlay-apply.exit') == 'SKIPPED' and rd(d, 'build.exit') == 'SKIPPED' and (d / 'out/build.skipped').is_file(), r.stdout); ck(run(d, 'Ergebnis bewerten (Artefakte sind bereits hochgeladen)', 'overlay').returncode == 1, 'SKIPPED darf nie gruen sein')
    print(f'PASS {wf}: {ok} Pruefungen (alle 4 Varianten auf Git-Repository mit den ECHTEN OEM-Dateien: Trockenlauf, Anwendung, Build mit Ersatz-pio, Erfolgs- und Fehlerpfad, SKIPPED nie gruen); auf GitHub NICHT ausgefuehrt')
if __name__ == '__main__':
    test_4(); test_6(); test_7(); test_17()
    test_17('19.yml', '19', 'SV04_NEXT_OVERLAY_STAND16.zip', 17)
    import test_workflow19; test_workflow19.test_19_steps()
