#!/usr/bin/env python3
"""Statischer Audit eines GitHub-Actions-Workflows VOR der Ausfuehrung (Rechte, Trigger, Geheimnisse, Skript-Injektion, Pinning, Fehlerindikatoren, Artefakte, Dateinamen, Kodierung).
Ausgabe: Befunde mit Schweregrad HOCH/MITTEL/NIEDRIG/INFO und Beleg (Job/Schritt). Exit 1 bei HOCH. Aufruf: python3 ci/audit_workflow.py DATEI.yml [--zip OVERLAY.zip]"""
import hashlib, json, re, sys
from pathlib import Path
import yaml


def audit(path: Path, zip_path: Path | None = None):
    raw = path.read_bytes(); txt = raw.decode('utf-8', errors='replace'); F = []
    add = lambda sev, what, where='': F.append({'sev': sev, 'what': what, 'where': where})
    if b'\r\n' in raw: add('MITTEL', 'CRLF-Zeilenenden (YAML kann zickig werden)')
    if any(c > 127 for c in raw): add('NIEDRIG', 'Nicht-ASCII-Zeichen in der YAML')
    if b'\t' in raw: add('HOCH', 'Tabulatoren in der YAML')
    if re.search(r' \(\d+\)\.ya?ml$', path.name): add('HOCH', 'Android-Dateiname mit " (1)"', path.name)
    try: d = yaml.safe_load(txt)
    except Exception as e: add('HOCH', f'YAML nicht lesbar: {e}'); return F
    on = d.get(True, d.get('on')) or {}
    if set(on) != {'workflow_dispatch'}: add('HOCH' if {'pull_request_target', 'push'} & set(on) else 'MITTEL', f'Trigger nicht nur workflow_dispatch: {sorted(on)}')
    perm = d.get('permissions'); 
    if perm != {'contents': 'read'}: add('HOCH', f'permissions nicht genau contents: read ({perm})')
    if re.search(r'secrets\.', txt): add('HOCH', 'Verwendet secrets.*')
    if re.search(r'git\s+(push|commit)|gh\s+(release|pr)|--force|curl[^\n|]*\|\s*(ba)?sh|wget[^\n|]*\|\s*(ba)?sh', txt): add('HOCH', 'Schreibende/unsichere Befehle (push/commit/curl|sh)')
    inputs = on.get('workflow_dispatch', {}).get('inputs', {}) or {}
    names = [str(d.get('name', ''))]; m = re.match(r'(\d+)', names[0]); num = m.group(1) if m else None
    for jn, job in (d.get('jobs') or {}).items():
        if 'timeout-minutes' not in job: add('NIEDRIG', 'kein timeout-minutes', jn)
        for st in job.get('steps', []):
            u = st.get('uses', ''); sn = st.get('name') or u
            if u and not re.search(r'@[0-9a-f]{40}$', u): add('NIEDRIG', f'Action nicht auf Commit-SHA gepinnt ({u}); Lieferkettenrisiko', f'{jn}/{sn}')
            if u.startswith('actions/checkout') and (st.get('with') or {}).get('persist-credentials') is not False: add('MITTEL', 'checkout ohne persist-credentials: false', f'{jn}/{sn}')
            run = st.get('run', '')
            for inp in sorted(set(re.findall(r'\$\{\{\s*inputs\.(\w+)\s*\}\}', run))):
                spec = inputs.get(inp, {}); typ = spec.get('type', 'string')
                if typ == 'choice': continue
                add('NIEDRIG', f'Freitext-Eingabe "{inp}" wird direkt in ein Shell-Skript interpoliert (Skript-Injektion/Quoting). Ausloeser sind nur Nutzer mit Schreibrecht; Abhilfe: per env: uebergeben', f'{jn}/{sn}')
            if re.search(r'\bcd\s+(?!"?\$|/)\S', run): add('NIEDRIG', 'cd auf relativen Pfad (frueheres Problem: relative Pfade)', f'{jn}/{sn}')
        ups = [s for s in job.get('steps', []) if s.get('uses', '').startswith('actions/upload-artifact')]
        if not ups: add('MITTEL', 'kein Artefakt-Upload', jn)
        for s in ups:
            if s.get('if') != 'always()': add('HOCH', 'Upload nicht mit if: always() (rote Laeufe liefern keine Artefakte)', jn)
            nm = (s.get('with') or {}).get('name', '')
            if num and not nm.startswith(num + '-'): add('MITTEL', f'Artefaktname "{nm}" beginnt nicht mit der Workflow-Nummer {num}', jn)
    # Fehlerindikatoren: jeder Job braucht einen Auswertungsschritt, der rot wird
    for jn, job in (d.get('jobs') or {}).items():
        last = (job.get('steps') or [{}])[-1]; run = last.get('run', '')
        if not re.search(r'exit\s+1', run): add('HOCH', 'letzter Schritt kann nie rot werden (kein exit 1)', jn)
    if 'SKIPPED' not in txt: add('MITTEL', 'kein SKIPPED-Zustand fuer nicht angewendete Overlay-Builds')
    if re.search(r'reach\.exit', txt) and 'reach.exit' not in ''.join((s.get('run', '') for j in d['jobs'].values() for s in j.get('steps', []) if 'Ergebnis' in str(s.get('name', '')))): add('INFO', 'Erreichbarkeitsanalyse (reach.exit) macht den Job NICHT rot (Absicht: Artefakte bleiben nutzbar); ein gruener Job ist daher KEIN Beleg fuer Erreichbarkeit. Auswertung: tools/evaluate_ci_artifacts.py')
    if re.search(r'pip install (?!--quiet\s+\S+==)', txt) and 'pyyaml' in txt and 'pyyaml==' not in txt: add('NIEDRIG', 'pip install pyyaml ohne feste Version')
    shas = re.findall(r"default: '([0-9a-f]{64})'", txt)
    if shas and zip_path is not None:
        h = hashlib.sha256(zip_path.read_bytes()).hexdigest()
        if h not in shas: add('HOCH', f'vorbelegter ZIP-SHA256 passt NICHT zur Overlay-ZIP ({h[:12]}...)')
        else: add('INFO', 'vorbelegter ZIP-SHA256 stimmt mit der Overlay-ZIP ueberein')
    if '@@ZIP_SHA@@' in txt: add('HOCH', 'unausgefuellter Platzhalter @@ZIP_SHA@@')
    dflt = [v.get('default') for k, v in inputs.items() if k == 'overlay_zip']
    for z in dflt:
        if z and re.search(r'\(\d+\)', z): add('HOCH', f'overlay_zip-Vorgabe mit " (1)": {z}')
    return F


def main():
    p = Path(sys.argv[1]); z = Path(sys.argv[sys.argv.index('--zip') + 1]) if '--zip' in sys.argv else None; F = audit(p, z)
    order = {'HOCH': 0, 'MITTEL': 1, 'NIEDRIG': 2, 'INFO': 3}
    for f in sorted(F, key=lambda x: order[x['sev']]): print(f"{f['sev']:8} {f['what']}" + (f"  [{f['where']}]" if f['where'] else ''))
    print(f"--- {p.name}: HOCH {sum(f['sev'] == 'HOCH' for f in F)}, MITTEL {sum(f['sev'] == 'MITTEL' for f in F)}, NIEDRIG {sum(f['sev'] == 'NIEDRIG' for f in F)}, INFO {sum(f['sev'] == 'INFO' for f in F)}")
    return 1 if any(f['sev'] == 'HOCH' for f in F) else 0


if __name__ == '__main__': sys.exit(main())
