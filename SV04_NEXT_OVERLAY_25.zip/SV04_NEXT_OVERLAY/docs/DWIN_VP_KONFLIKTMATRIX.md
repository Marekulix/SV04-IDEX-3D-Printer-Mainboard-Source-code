# DWIN VP-Konfliktmatrix (maschinell aus dem ECHTEN LCD_RTS, `tools/dwin_conflicts.py`)

Nur Quellenfakten. Das Display-Projekt (T5UID1/DGUS) liegt NICHT vor; eine Adresse, die hier "frei" erscheint, ist damit nicht als frei im Display belegt.

## Alias (mehrere Namen, eine Adresse)

keine

## Adressfamilien (Wertebereiche)

| Familie | Anzahl | von | bis | Schritt | regulaer | Zeilen | Nutzung per Arithmetik (cpp-Zeilen) |
|---|---|---|---|---|---|---|---|
| `AUTO_BED_LEVEL_nPOINT_VP` | 16 | `0x1100` | `0x111E` | [2] | True | [72, 87] | [334, 2299] |

## Tastenadressen im Wertebereich einer Familie

| Taste | Adresse | Familie | entspricht Punkt | genau auf Wertplatz |
|---|---|---|---|---|
| `ChangePageKey` | `0x110E` | AUTO_BED_LEVEL | 8 | True |

## Tastenadressen, die zugleich als VP-Name definiert sind

| Taste | Adresse | VP-Namen |
|---|---|---|
| `PrintSpeedKey` | `0x1006` | PRINT_SPEED_RATE_VP |
| `ZOffsetKey` | `0x1026` | AUTO_BED_LEVEL_ZOFFSET_VP |
| `Heater0TempEnterKey` | `0x1034` | HEAD0_SET_TEMP_VP |
| `Heater1TempEnterKey` | `0x1038` | HEAD1_SET_TEMP_VP |
| `HotBedTempEnterKey` | `0x103A` | BED_SET_TEMP_VP |
| `XaxismoveKey` | `0x1048` | AXIS_X_COORD_VP |
| `YaxismoveKey` | `0x104A` | AXIS_Y_COORD_VP |
| `ZaxismoveKey` | `0x104C` | AXIS_Z_COORD_VP |
| `Heater0LoadEnterKey` | `0x1054` | HEAD0_FILAMENT_LOAD_DATA_VP |
| `Heater1LoadEnterKey` | `0x1058` | HEAD1_FILAMENT_LOAD_DATA_VP |
| `XhotendOffsetKey` | `0x1092` | TWO_EXTRUDER_HOTEND_XOFFSET_VP |
| `YhotendOffsetKey` | `0x1094` | TWO_EXTRUDER_HOTEND_YOFFSET_VP |
| `ZhotendOffsetKey` | `0x1096` | TWO_EXTRUDER_HOTEND_ZOFFSET_VP |
| `ChangePageKey` | `0x110E` | AUTO_BED_LEVEL_8POINT_VP |

## Overlay-Nutzung (nur der EINGEFUEGTE Code)

Verwendete VPs: AUTO_BED_LEVEL_1POINT_VP, AUTO_BED_LEVEL_ICON_VP. Unbekannte VP-Namen oder eigene Adressliterale: **0**. Ergebnis: **nur vorhandene OEM-VPs**.
