# HOMING_AND_TOOLCHANGE_GROUND_TRUTH: Referenzfahrt, Werkzeugwechsel und Endschalter am ORIGINAL (Stand 20)
Maschinell erzeugt (`tools/make_ground_truth_doc.py`) aus `tools/hw_ground_truth.py`; Zeilenverweise sind aus dem OEM-Auszug `hardware/oem_excerpt/` (SHA256 in `hardware/OEM_EXCERPT_SHA256.txt`) gesucht, nicht von Hand getippt.

**Stufe:** Rechenmodell (c) gegen Terminalwerte des ORIGINAL-Sovol-Druckers (a) vom 02.11.2026 (Abschrift; keine Rohlogs/Fotos). **KEIN Hardwaretest von SV04 NEXT.** Nichts hier ist eine Freigabe zum Flashen, Fahren, Heizen oder Schreiben.

## 1. Quellenlage
Vorhanden: `Configuration.h`, `Configuration_adv.h`, `motion.cpp`, `G28.cpp`, `probe.cpp`, `endstops.cpp`, `settings.cpp`, `gcode.cpp/.h`, `pins_CREALITY_V4.h`, `planner.cpp`, `LCD_RTS.cpp`.
**Fehlt** (daher OPEN, siehe `OPEN_ISSUES.md`): `tool_change.cpp` (Parkbewegung beim Werkzeugwechsel, Y/Z-Versatz), `M605.cpp` (Verhalten ohne Parameter), `M106_M107.cpp` + `temperature.cpp` (Luefter `P`), `bltouch.cpp` (Deploy/Stow/Alarm), `M17_M18_M84.cpp` (Vertrauen nach `M18`), `motion.h` (`do_z_raise`).

## 2. G28 am Original: Quelle -> Beobachtung (H07)
Ablauf laut Quelltext: (1) Z anheben auf `Z_HOMING_HEIGHT` 10 (G28.cpp:377; Konfiguration Configuration.h:1360); (2) `bltouch.init()`; (3) **T1 zuerst** (`active_extruder = 1`), dann T0, danach `idex_set_parked()` (G28.cpp:399, G28.cpp:465); (4) Y (G28.cpp:391, G28.cpp:421); (5) Z **sicher**: `home_z_safely()` (G28.cpp:124, aktiv: Configuration.h:1745) faehrt zum Punkt (X_CENTER, Y_CENTER) abzueglich Sonden-Offset (G28.cpp:136; G28.cpp:151; Sondenoffset Configuration.h:1187 + EEPROM `M851 X0 Y25 Z-1.10`), dann `homeaxis(Z)` (schnell, Zwischen-STOW/-DEPLOY, langsam: **zwei Antastungen**, `motion.cpp:1815/1849`).
Z danach: `set_axis_is_at_home` setzt Z auf `0 - probe.offset.z = +1,10` (motion.cpp:2117), dann hebt `probe.stow()` (motion.cpp:2035) bei BLTouch **immer** um `max(Z_CLEARANCE_BETWEEN_PROBES 5, Z_CLEARANCE_DEPLOY_PROBE 10) = 10 mm` an (probe.cpp:418) -> **11,10**.
**Folge:** Nach `G28` steht **T0 NICHT links geparkt**, sondern bei (151, 126, 11,10): T1 steht an seinem Schalter rechts (365,35), T0 mittig.

| Ereignis | beobachtet (X, Y, Z, Zaehler X/Y/Z) | aus Quelltext + EEPROM berechnet | gleich |
|---|---|---|:-:|
| H07 nach G28 | (151.0, 126.0, 11.1, 9664, 10080, 4440) | (151.0, 126.0, 11.1, 9664, 10080, 4440) | JA |
| H08 nach T1 | (365.35, 124.1, 11.1, 23382, 9928, 4440) | (365.35, 124.1, 11.1, 23382, 9928, 4440) | JA |
| H08 nach T0 | (-62.0, 126.0, 11.1, -3968, 10080, 4440) | (-62.0, 126.0, 11.1, -3968, 10080, 4440) | JA |

18 Zahlen stimmen exakt. Fuenf eingesetzte Modellfehler (T1-Override ignoriert, Y-Vorzeichen, kein Stow-Anhub, kein Sondenoffset, nur Z_HOMING_HEIGHT) werden erkannt (`tests/test_hw_ground_truth.py`).

## 3. Werkzeugwechsel (H08)
* **Quelle (belegt):** `set_axis_is_at_home(X)` bei aktivem T1 setzt `X = x_home_pos(1)` (motion.cpp:2097), und `x_home_pos(1) = hotend_offset[1].x`, wenn > 0, sonst `X2_HOME_POS` (motion.cpp:1138). Am Geraet gilt `M218 T1 X365.35`, also **365,35 und nicht 362**: 362 ist nur der Code-Default `X2_MAX_POS`/`inactive_extruder_x` vor der ersten Referenzfahrt (`motion.cpp:1120`). T0 liegt bei `X_MIN_POS` = -62 (Configuration.h:1381).
* **Modell (nur an zwei Messwerten gestuetzt):** Y wird um `Offset_neu - Offset_alt` verschoben: T1 -> 126 + (-1,90) = 124,10; zurueck T0 -> 126,00. Die Formel stammt aus Marlin-Upstream; `tool_change.cpp` liegt mir nicht vor.
* **Beobachtung (Sicht, Klasse C):** `T1`: T0 faehrt an den linken Schalter, T1 bleibt rechts, **kein Wechsel an den Druckraum**. `T0`: keine sichtbare Bewegung, beide Koepfe aussen. Das passt zur Auto-Park-Vorgabe (Configuration_adv.h:766) und zu den Positionsformeln, ist aber **nicht** aus dem OEM-`tool_change.cpp` belegt.
* `M605` ohne Parameter setzt laut Uebergabe auf `DEFAULT_DUAL_X_CARRIAGE_MODE` zurueck, nicht nur Status: **durch mich nicht gegen die OEM-Datei geprueft** (`M605.cpp` fehlt).
* X-Koordinaten in `M114` zeigen den Heimatwert/Offset des aktiven Schlittens, **keinen** gemessenen Weg.

## 4. Zwei Endschalter (Auftragspunkt 4)
* Pins: `X_MIN_PIN PD10` (pins_CREALITY_V4.h:83) und `X_MAX_PIN PE15` (pins_CREALITY_V4.h:84). **Es gibt keinen `X2_MIN_PIN`/`X2_MAX_PIN`.**
* Zuordnung beim Fahren: `X_MIN_TEST()` zaehlt nur, wenn der zuletzt bewegte Extruder T0 ist (endstops.cpp:634); `X_MAX_TEST()` nur fuer T1 (endstops.cpp:635; `X2_HOME_DIR 1`: Configuration_adv.h:758). `M119` zeigt dagegen die **Rohpegel beider Pins**, deshalb erschienen `x_min` und `x_max` am Original unabhaengig (H02, H03, H09).
* Hardware bestaetigt (Original): `x_max TRIGGERED` nur mit T1 rechts, `x_min TRIGGERED` mit T0 links. **Nicht** belegt: Prellen, Pegel, schnelle Bewegung, und ob T0 den `X_MAX`-Schalter mechanisch erreichen kann (bewusst nicht gefahren).
* **Korrigierte frueher ungenaue Aussage:** "X_MAX ist EIN Schalter fuer BEIDE Schlitten" -> richtig ist: `X_MAX_PIN` ist der Schalter von T1; ein Pegel dort **stoppt T0 nicht** (X_MAX_TEST gilt nur fuer T1). Gefahr bleibt, weil das Softlimit von T0 in den Modi 1/4 bis 365.35 reicht.

| Modus (Creality `save_dual_x_carriage_mode`) | Softlimit X |
|---|---|
| Modus 0 (Single, T0) | T0: -62 bis 302 |
| Modus 0, T1 aktiv | T1: 0 bis 365.35 |
| Modus 1 (Two-color) oder 4 (Single T1) | T0 und T1: 0 bis 365.35 |

Folge fuer SV04 NEXT: `t1_parked_electrically()` verlangt zusaetzlich `T0-X <= X_MAX_POS` (302). Das ist **Buchfuehrung**, kein Hardwarebeweis.

## 5. `M503`-Ausgabe: `Error: M605 S0` und `Error: T0` (Auftragspunkt 12)
Absichtliche Statuszeilen des OEM-Codes: `SERIAL_ERROR_MSG("  M605 S", dualXPrintingModeStatus)` (settings.cpp:3324) und `... "  T", active_extruder_font` (settings.cpp:3328), Ueberschrift "0:Single 1:Two-color 2:Copy 3:Mirror". Es ist der **Display-Modus**, nicht Marlins DXC-Modus. **Wer M503-Text als G-Code zurueckspielt, fuehrt `M605 S0` (Marlin: FULL_CONTROL) aus.** M503 ist keine Sicherungsdatei.

## 6. Zustand nach `M18` und manuellem Schieben (Auftragspunkt 8)
Physik: ohne Haltemoment kennt die Firmware die Lage nicht mehr. **Offen:** ob die OEM-Firmware dabei das Vertrauens-Flag entzieht (`motion.cpp` kennt `set_axis_never_homed`; der Aufrufer bei `M18` fehlt). Belegte Rueckkehr am ORIGINAL ist nur: **volle Original-`G28`** unter den Vorbedingungen aus H07-1 (Platte leer, kalt, Duesen frei, Kabel frei, beobachtet). SV04 NEXT darf daraus **keine** Automatik ableiten; es bleibt bei Verweigerung ohne frische Referenzfahrt und ohne elektrischen T1-Nachweis.

## 7. Fruehere Aussagen: korrigiert
| fruehere Aussage | jetzt | Beleg |
|---|---|---|
| X_MAX gilt fuer beide Schlitten | `X_MAX_PIN` = Schalter von T1; stoppt T0 nicht | endstops.cpp, H02/H03 |
| T1 steht bei 362 | T1-Heimat 365,35 (M218), 362 nur Code-Default | motion.cpp, H08 |
| Platine laut Konfiguration V4, nicht V5.2.1 | kein Widerspruch: "Creality V5.2.1" steht in der V4-Pinbelegung | pins_CREALITY_V4.h:37 |
| `Error: M605 S0 / T0` ungeklaert | absichtliche Statuszeilen | settings.cpp |
| T0 steht nach G28 links | T0 steht bei (151, 126, 11,10) | G28.cpp, H07 |
