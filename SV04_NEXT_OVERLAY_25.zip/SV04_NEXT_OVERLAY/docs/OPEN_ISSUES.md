# OPEN_ISSUES (Stand 20)  |  Prioritaet P0 = blockiert jede Freigabe

| ID | P | Offener Punkt | Was fehlt / naechster Schritt |
|---|---|---|---|
| Q1 | P0 | `M605` ohne Parameter = Reset auf Default? (Uebergabe, **nicht** gegen OEM-Datei geprueft) | `Marlin/src/gcode/control/M605.cpp` |
| Q2 | P0 | Parkbewegung/Y-Z-Versatz beim Werkzeugwechsel; Auto-Park-Zustandsmaschine | `Marlin/src/module/tool_change.cpp` |
| Q3 | P1 | Vertrauensverlust nach `M18`/`M84` | `Marlin/src/gcode/control/M17_M18_M84.cpp`, ggf. Teil von `stepper.cpp` |
| Q4 | P1 | Luefter `P0`/`P1` gemeinsam | `M106_M107.cpp`, `temperature.cpp`; optional Foto der Luefterstecker (stromlos) |
| Q5 | P1 | BLTouch Deploy/Stow/Alarm, `z_min TRIGGERED` im Ruhezustand (H09-1) | `Marlin/src/feature/bltouch.cpp`; ein passives `M119` bei eingefahrenem Stift |
| Q6 | P0 | Quelltext <-> Original-Binary nicht identitaetsgeprueft (Ruck X/Y 8 gegen 10) | Binaerpruefsumme der Original-Firmware oder Herkunft der Datei; vor jedem Flash |
| Q7 | P1 | Rohlogs und Fotos der Hardwaretests liegen nicht vor (nur Abschrift) | Terminal-Log-Dateien und Fotos mit Dateinamen liefern |
| Q8 | P1 | Heizkurve: ein Lauf, Probenabstand ca. 30 s, kein PWM-Zeitverlauf | Wiederholung mit `M155 S1` und Mitschnitt (siehe `HIL_NAECHSTE_SCHRITTE.md`) |
| Q9 | P2 | Stand 20 nicht in der ARM-CI gebaut | optional Workflow 20 mit `SV04_NEXT_OVERLAY_S20.zip` (zwei Felder), kein neuer Workflow |
| Q10 | P0 | Hardwaretest der NEUEN Firmware: **nicht** erfolgt | erst nach Recovery-/Gefaehrdungsanalyse und gesonderter Freigabe |
| Q11 | P2 | Katalog kennt keine H-Nachweise (alle 23 Kriterien "nicht definiert"); OEM-Messungen sind keine H-Nachweise der neuen Firmware | Katalogvorschlag `docs/KATALOGVORSCHLAG.md` (nicht angewendet) |
| Q12 | P2 | DWIN: keine Anzeigedateien, keine VP-Adressen | echte Displaydateien |
| Q13 | P1 | EEPROM-Recovery nur als Modell | `sizeof(SettingsData)`, Ladepfad, Stromausfall am Geraet |
| Q14 | P2 | Mesh nicht neu gemessen, Aktualitaet unbekannt | kein neues G29 gewuenscht |
| Q15 | P2 | Y-Formel des Werkzeugwechsels nur durch zwei Messwerte gestuetzt | `tool_change.cpp` (Q2) |

**Geklaert in Stand 20:** `Error: M605 S0`/`Error: T0` (absichtliche Statuszeilen), Platine "Creality V5.2.1" (steht in der V4-Pinbelegung), T1-Heimat 365,35 gegen 362, Endschalter-Zuordnung (`X_MIN` nur T0, `X_MAX` nur T1), Z11,10 und X151/Y126 nach `G28`, `M422` (Z-Stepper-Ausrichtung), `M413 S1` (Powerloss-Recovery an).
