# README_ANDROID (Stand 20)  |  NICHT FLASHEN

* **Lesen:** alle `.md`-Dateien in `docs/`; Anfang: `STATUS_20.md`, dann `OPEN_ISSUES.md`, `SAFETY_CASE.md`, `HARDWARE_EVIDENCE.md`, `HOMING_AND_TOOLCHANGE_GROUND_TRUTH.md`.
* **Hochladen zu GitHub (nur falls Sie Stand 20 bauen lassen wollen):** nichts in `.github/workflows` aendern, **keinen** neuen Workflow anlegen. Schritte und die SHA256 des ZIP stehen in `GITHUB_ANDROID_SCHRITTE_S20.md` (ausserhalb dieses ZIP, weil ein ZIP seine eigene Pruefsumme nicht enthalten kann).
* **ZIP-Regeln (Android):** Dateiname ohne ` (1)`; das ZIP wurde mit `tools/make_android_zip.py` in die Form gepackt, die sich frueher vom Tablet hochladen liess (Ursache fruherer Ablehnungen nicht bewiesen).
* **Nicht tun:** flashen, `M500`/`M502`, YAML aendern, Zugangsdaten eintragen.
