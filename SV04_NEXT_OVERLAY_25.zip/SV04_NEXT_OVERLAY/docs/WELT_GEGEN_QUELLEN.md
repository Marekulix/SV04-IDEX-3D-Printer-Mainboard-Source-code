# Weltmodell gegen die echten Quellen (Stand 19)  |  nur belegte Aussagen mit Datei:Zeile

Meine Host-Tests (`harness/real_g29/`) kompilieren den ECHTEN `G29.cpp` gegen eine **nachgebildete Welt** (`world.h`, `driver_real.cpp`). Diese Tabelle trennt, was ich gegen den echten Quelltext verglichen habe, von dem, was ich **nicht** verglichen habe.

## Gegen den echten Quelltext verglichen
| Gegenstand | Befund | Beleg |
|---|---|---|
| `bilinear_z_offset` | echte Funktion mit **statischem Cache** der Eckwerte (nur bei Zellwechsel neu geladen), `EXTRAPOLATE_BEYOND_GRID` aktiv, keine Unterteilung; Welt rechnet jetzt exakt so | `abl.cpp` 268-345, `Configuration.h` 1621/1627 |
| `refresh_bed_level` | setzt nur den Faktor, **invalidiert den Cache nicht** | `abl.cpp` 248-251 |
| Reziprokwert | `_RECIP` liefert 0 bei 0 (Welt rechnete 1/0 = inf und stuerzte ab) | `types.h` 159, `macros.h` 342 |
| Fade | Hoehe 1,0 mm; Faktor `1 - z/zfh`, ab Hoehe 0; Korrektur nur wenn Faktor != 0 | `Configuration.h` 1583, `planner.h` 584-598, `planner.cpp` 1590 |
| `set_bed_leveling_enabled` / `reset_bed_level` | wie in der Welt nachgebildet (Mesh -> NAN, Raster 0, Leveling aus; Aktivierung nur bei gueltigem Raster) | `bedlevel.cpp` 49-139 |
| OEM-G29-Nachlauf | rechnet **selbst** `current_position.z -= fade * bilinear_z_offset(...)` und setzt dann das Leveling direkt | `G29.cpp` 874-883 |
| `probe_at_point` | Standard `probe_relative = true`: Duese = Sondenposition - Offset; nicht erreichbar -> `NAN`; Z-Hub nur bei `PROBE_PT_RAISE` | `probe.cpp` 750-780, `probe.h` 112-115 |
| Parser | `seen_test(c)` und einargumentiges `boolval` wie in der Welt; **nicht** gleichwertig: Werte (`D0`), Kleinbuchstaben, `strgchr`-Variante | `parser.h` 176-216, `G29.cpp` 231-338 |
| Endstop-Entprellung | `ENDSTOP_NOISE_THRESHOLD` kommt in `Configuration_adv.h` nicht vor: **keine Entprellung** | `endstops.cpp` 66, 365, 620, 843 |

## Weiterhin NICHT verglichen / vereinfacht
- **`sync_plan_position`:** echt `planner.set_position_mm(current_position)` (`motion.cpp` 345); es **veraendert `current_position` nicht**, der No-Op der Welt ist fuer die Koordinaten also korrekt; unmodelliert bleibt nur der interne Planner-Zustand.
- **Z-Hub** (`do_blocking_move_to_z`, `Z_CLEARANCE_BETWEEN_PROBES`, `PROBE_PT_RAISE`): nicht modelliert. Einordnung: Nach jeder Sondierung steht die Duese mindestens ein Clearance-Mass ueber dem Bett, also **ueber der Fade-Hoehe (1,0 mm)**; dort ist die Leveling-Transformation die Identitaet. Die in-Band-Szenarien Z01 bis Z04 sind deshalb Grenzfaelle des Modells, keine typischen Betriebsfaelle; der Stoerfall betrifft vor allem spaetere Bewegungen der ersten Schicht, nicht das Ende von `G29 U`.
- `bltouch.cpp` (nicht im Repository-Auszug), Deploy/Stow, `G29_RETRY_AND_RECOVER`, `LCD_MESSAGEPGM`.
- Echte `G28.cpp` wird nicht ausgefuehrt (nur ihre Topologie als Text geprueft).
- Z-Erwartungswerte sind **nur gueltig**, wenn Start- und Endzelle verschieden sind (sonst nutzt der OEM-Nachlauf selbst veraltete Eckwerte); die Szenarien Z01 bis Z04 sind entsprechend gewaehlt.
