# AUDIT (Stand 20): Aussagen gegen Dokumente, Quelltext und Messungen  |  NICHT FLASHEN

Pruefreihenfolge laut Auftrag: zuerst Luecken und Widersprueche, dann Umsetzung. Frueher genannte Prozentwerte wurden **nicht** unkritisch uebernommen.

## 1. Fruehere Behauptungen, neu bewertet
| Behauptung | Ergebnis | Beleg |
|---|---|---|
| "X_MAX ist EIN Schalter fuer BEIDE Schlitten" | **korrigiert:** zwei Pins; `X_MAX` gilt fuer Bewegungen nur bei T1; Pegel stoppt T0 nicht | endstops.cpp:634-635; H02/H03 (Original) |
| "T1 steht bei 362" | **korrigiert:** nach G28 und per `M218` 365,35; 362 nur Code-Default vor G28 | motion.cpp:1120, 1128-1138; H08 |
| "Platine laut Konfiguration V4, nicht V5.2.1" | **geklaert:** Name steht in der V4-Pinbelegung | pins_CREALITY_V4.h:37 |
| "`Error: M605 S0/T0` ungeklaert" | **geklaert:** absichtliche Statuszeilen (Display-Modus) | settings.cpp:3321-3328 |
| "Nach G28 steht T0 links geparkt" (Annahme) | **widerlegt:** T0 bei (151, 126, 11,10) | G28.cpp, motion.cpp, probe.cpp; H07 (18 Zahlen exakt) |
| "G28 referenziert T1 vor T0" | **bestaetigt** | G28.cpp:396-410; `NativeIdexHomingTrace` passt |
| "`M48` ist ausgeschaltet" | **bestaetigt** | Configuration.h:1267 |
| "Heiz-Timeout 12 min plausibel" | **gestuetzt, ein Lauf:** Reserve 3,05x zur gemessenen Aufheizzeit 236 s | tools/thermal_trace_analyze.py |
| "natives Gate: MaxSpread 0,8 C unvalidiert" | **mit einer echten Kurve vereinbar:** Spreizung nach Erreichen 0,21 C; weiter nur ein Lauf | tests/test_thermal_real_trace.cpp |
| "Stand 19 konservativ 20,25 %" | **nicht reproduzierbar:** das unveraenderte Skript ergibt 39,50 (formal, mit den CI-Nachweisen frueherer Staende) fuer Stand 19 und Stand 20; ohne jeden CI-Ordner 17,85 in meiner Nachrechnung; Baumkonfiguration der Zahl 20,25 ist nicht dokumentiert | tools/score_progress.py, proof/progress-stand20-ohne-ci.txt |
| "Zweiter Workflow-20-Lauf erfolgreich" | **weiter unbelegt:** Artefakte nie vorgelegt | - |
| "M605 ohne Parameter setzt auf Default zurueck" | **offen:** M605.cpp fehlt | OPEN_ISSUES Q1 |

## 2. Neue Befunde dieser Runde
* Geraet <-> Quelltext: 11 von 13 verglichenen Werten gleich; **Ruck X/Y 8 am Geraet, 10 im Quelltext** (Q6). Version `V1.1.0` und `Creality V5.2.1` passen, ein Identitaetsnachweis ist das nicht.
* `M115` gibt `__DATE__ __TIME__` des Compilers aus: das Geraetedatum ist die Build-Zeit der Original-Binary (M115.cpp:52 laut CI-Datei).
* Eine Kurve, ein Sensor: der Stagnationswaechter ist konservativ und nicht optimiert. Ein Mutant (Fensterreferenz nicht nachgefuehrt) ueberlebte zuerst: Testluecke "Heizung faellt mitten im Aufheizen aus" geschlossen.
* Beim echten-G29-Harness: derselbe Test mit dem **realen** Mesh als altes Mesh: 156 von 156; OEM-`bilinear_z_offset` stimmt mit unabhaengiger Python-Formel (groesste Abweichung 8e-8 mm).

## 3. Evidenz nach Ebene (getrennt berichten)
| Ebene | Stand 20 |
|---|---|
| (a) Original-Hardware (Abschrift, ohne Rohlogs/Fotos) | 33 Eintraege in `HARDWARE_EVIDENCE.md`; 13 mit Zuverlaessigkeit "A" (12 Terminalzeilen, 1 Quelltextbeleg), 12 "B", 4 "C", Rest "D" |
| (b) OEM-Quelltext | 11 Dateien als Auszug mit SHA256; 4 weitere Dateien fehlen |
| (c) Simulation/Host | gesamte lokale Staffel gruen (`proof/stand20-all-tests.log`), dazu neu: Thermal-Witness 89 928, Thermal-Realkurve 904, Mesh-Zweiwege 1260, Hardwaremodell 35, Belegmatrix 33 Pruefungen, 8/8 Thermal-Mutanten |
| (d) ARM-CI | **Stand 20 nicht gebaut**; zuletzt gebaut: Stand 15 (Workflow 18) und Stand 17 (Workflow 20, Lauf 1: baseline/probe/overlay/host-tests; Auto60 scheiterte vor dem Kompilieren) |
| (e) Hardware der NEUEN Firmware | **nicht erfolgt** |
