# SAFETY_CASE: Gefaehrdungen, Evidenz und Grenzen (Stand 20)  |  NICHT FLASHEN

**Keine Freigabe.** SV04 NEXT bleibt: nicht geflasht, `SV04_NEXT_AUTO60_ENGINE` aus und ohne Ausloeser, kein EEPROM-Commit, keine freigegebene DWIN-Schaltflaeche, keine Heiz-/Bewegungs-/EEPROM-Aufrufer. Evidenzklassen: (a) Original-Drucker, (b) OEM-Quelltext, (c) Simulation, (d) ARM-CI, (e) Hardware der NEUEN Firmware (**hat nicht stattgefunden**).

| Nr | Gefaehrdung | Evidenz | Massnahme in SV04 NEXT / Prozess | Restrisiko |
|---|---|---|---|---|
| S1 | T0 faehrt in Richtung/auf den X_MAX-Schalter von T1 (Modus 1/4: Softlimit bis 365,35); der X_MAX-Pegel stoppt T0 **nicht** | (b) endstops.cpp:634-635, motion.cpp:718-733; (a) Signalzuordnung H02/H03 | zusaetzlich gefuehrte T0-X <= 302 in `t1_parked_electrically()`; nur lesen | **offen:** mechanische Erreichbarkeit unbewiesen; Buchfuehrung statt Hardwarebeweis |
| S2 | Annahme "T0 steht nach G28 links" | (a)(b) H07: T0 bei (151,126,11,10), exakt herleitbar | keine Position links annehmen; Zustand lesen, nicht ableiten | Parkbewegung bei Werkzeugwechsel nicht aus OEM-Datei belegt (tool_change.cpp fehlt) |
| S3 | T1 aktiv, aber physisch rechts geparkt (nach `T1` bleibt T1 am Schalter) | (a) H08, (b) motion.cpp:2096 | Auto60 verlangt T0 aktiv und elektrischen T1-Parknachweis | Kollisionssicherheit nie nachgewiesen |
| S4 | Positionsverlust nach `M18` und manuellem Schieben | (a) H03/H09 | Verweigerung ohne frische Referenzfahrt; keine Automatik zum Wiederreferenzieren | **offen:** ob OEM das Vertrauens-Flag bei M18 entzieht (M17_M18_M84.cpp fehlt) |
| S5 | Heizung faellt aus / Fuehler haengt / Bett kuehlt beim Aufheizen | (a) H06 eine Kurve; (c) Stagnationswaechter, 8/8 Mutanten | **neu Stand 20:** Fortschritt >= 1,0 C je 30 s unter 55 C, sonst Abbruch; 12-min-Timeout; TooHot > 65 C | ein Lauf, ein Sensor, kein Dauerlauf; ab 55 C nur Timeout; keine unabhaengige Temperaturmessung |
| S6 | Zuruckspielen von `M503`-Text als G-Code fuehrt `M605 S0` (Full Control) aus | (b) settings.cpp:3321-3328 | M503 nie als Wiederherstellung verwenden; Recovery nur ueber Original-Firmware | EEPROM-Backup existiert nicht (nur Fotos/Abschriften) |
| S7 | EEPROM-Schreiben unterbrochen (Stromausfall) | (b) I2C-24C16, byteweise 2 ms, nicht atomar (Belegmatrix) | kein Schreibaufrufer; A/B-Verfahren nur als Modell | Powerloss-Recovery (`M413 S1`) und EEPROM-Wechselwirkung nicht untersucht |
| S8 | Binary und Quelltext nicht identisch | (a)(b) Ruck X/Y: Geraet 8, Quelle 10; sonst 11/13 Werte gleich | vor jedem Flash Build-Identitaet und Recovery klaeren | **offen:** keine Binaerpruefsumme der Original-Firmware |
| S9 | BLTouch: keine Wiederholgenauigkeit, `z_min TRIGGERED` im Ruhezustand ungeklaert (H09-1) | (a) H04/H09; (b) M48 ausgeschaltet (Configuration.h:1267) | kein M48 automatisch; passiver `M119`-Check vorgeschlagen | Ursache offen |
| S10 | Luefter: keine getrennte Steuerung belegt | (a)(b) FAN_TEST.md | keine Luefterbefehle, kein Versprechen | Ursache offen |
| S11 | Mesh nicht mehr aktuell | (a) 16 Werte, nicht neu gemessen | Rollback stellt das alte Mesh wieder her (156 Pruefungen auch mit realem Mesh) | Alter/Gueltigkeit unbekannt; kein G29 gewuenscht |

## Tore (alle geschlossen, keine Aenderung ohne gesonderte Freigabe)
Flashen: **zu**. Heizen durch SV04 NEXT: **zu**. Bewegen durch SV04 NEXT: **zu**. EEPROM schreiben: **zu**. DWIN-Funktion: **zu**.
