# FAN_TEST: Bauteilluefter `M106`/`M107` (Auftragspunkt 10)  |  NICHT FLASHEN

**Ergebnis: Die Ursache fuer "P0 und P1 treiben dieselben zwei Luefter" ist NICHT bewiesen.** SV04 NEXT verspricht keine getrennte Ansteuerung.

## 1. Beobachtung am ORIGINAL (H10-1, Sichtbeobachtung Klasse C, Abschrift)
`M106 P0 S128` -> beide vorderen Radial-Bauteilluefter (T0/T1) drehen; `M107 P0` aus. `M106 P1 S128` -> **dieselben beiden** drehen; `M107` stoppt. Wiederholt gegengeprueft. Es sind NICHT die Kuehlkoerper-/Heatbreak-Luefter.

## 2. Quellenbefund (OEM-Auszug `hardware/oem_excerpt/`)
| Fakt | Beleg |
|---|---|
| zwei verschiedene Luefter-Ausgaenge: `FAN_PIN PB14`, `FAN1_PIN PB12`, Soft-PWM | `pins_CREALITY_V4.h:177-179` |
| zwei benutzergesteuerte Luefter | `Configuration.h:2831 NUM_M106_FANS 2` |
| kein Luefter-Multiplexer | `Configuration_adv.h:613-615 FANMUX0/1/2_PIN -1` |
| keine Auto-Luefter (Hotend/Controller) konfiguriert | `Configuration_adv.h:587-588 E0/E1_AUTO_FAN_PIN -1`; kein `USE_CONTROLLER_FAN` |
| `M106`/`M107` sind nur deklariert/verteilt | `gcode.h:689-690`, `gcode.cpp:557-558` |
| **Implementierung** (`M106_M107.cpp`) und `temperature.cpp` | **fehlen** |

Die Firmware kennt also zwei getrennte Luefterindizes. Dass beide Befehle dieselben zwei Luefter bewegen, passt NICHT zu "P wird einfach ignoriert und ein Pin gesteuert", wenn die Luefter an getrennten Ausgaengen haengen.

## 3. Hypothesen (alle offen, keine bevorzugt)
1. **Verdrahtung:** beide Bauteilluefter haengen parallel an einem Ausgang, der andere Ausgang treibt etwas anderes oder nichts; dann muss `P0` und `P1` dennoch denselben Ausgang erreichen (setzt Hypothese 2 oder 3 voraus).
2. **OEM-`M106`:** der Creality-Code schreibt beide Luefter (oder ignoriert `P`).
3. **Hardware:** beide Ausgaenge speisen beide Luefter (ODER-Verschaltung), unwahrscheinlich.
4. **`M107` ohne P** stoppt alle; das erklaert nur das Abschalten.

## 4. Folge fuer SV04 NEXT
Keine Luefterbefehle in der Auto60-Kette, kein pro-Luefter-Versprechen, kein Pin-Zugriff. Die Auto60-Kette bleibt bei Bett 60 C und Abbruch bei Fehlern ohne Luefter.

## 5. Diagnosevorschlag ohne neues Risiko (nur wenn Sie es wollen; alles am ORIGINAL, Heizung aus, keine Bewegung)
* Mit `M106 S128` (ohne `P`) und `M107` testen: drehen beide? Nur zur Vollstaendigkeit der Tabelle.
* **Dateien:** `Marlin/src/gcode/temperature/M106_M107.cpp` (oder wo es im Repository liegt) und `Marlin/src/module/temperature.cpp` liefern; damit laesst sich Hypothese 2 sofort entscheiden.
* Optional, **stromlos**: Foto der beiden Luefterstecker an der Platine (FAN/FAN1) mit Beschriftung; das entscheidet Hypothese 1/3 ohne jede Messung.
