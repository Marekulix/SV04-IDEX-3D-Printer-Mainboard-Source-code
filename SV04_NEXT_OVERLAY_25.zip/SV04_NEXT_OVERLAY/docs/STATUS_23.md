# SV04 NEXT Stand 23 - aktive Codearbeit, kein Flash

- `tools/endstop_evidence.py`: Python-3.11-Syntaxfehler (raw regex in f-string expression) beseitigt.
- `tools/check_python311.py`: eigenes fruehes Python-3.11-Syntax-Gate fuer die gesamte Host-Toolchain.
- `include/SV04NextAuto60Policy.hpp`: sechs Compilezeit-Sicherheitsinvarianten hinzugefuegt.
- Der Auto60-Startpfad ist weiterhin NICHT vorhanden; kein DWIN-Startknopf, keine Heiz- oder Bewegungsfreigabe.
- Stand 23 verwendet den bestehenden Stand-20-Marlin-Patch unveraendert. Das sind echte Codeaenderungen an einem Sicherheitsmodul, aber KEINE vollstaendige neue Firmwarefunktion.
- CI 23 muss ARM und Host-Pruefungen nachweisen, bevor weitere Firmwarearbeit/freigaben folgen.
- ZIP und YAML beide 23. Nie auf alte Workflow-Nummern zurueckgehen.
