# D1: EEPROM-Persistenz, belegt am ECHTEN `settings.cpp` (maschinell, `tools/eeprom_audit.py`)

**Ergebnis: die Katalogklausel "Fehler ueberschreiben das alte Mesh nie" ist mit `settings.save()` NICHT erfuellbar. D1 bleibt offen; es wird nichts verdrahtet.**

| Tatsache | gefunden | Zeile | Bedeutung |
|---|---|---|---|
| `version_placeholder_ERR` | ja | 655 | save() legt den Platzhalter-Header "ERR" an |
| `header_written_first_unless_flash` | ja | 662 | ohne Flash-Emulation wird "ERR" ZUERST an EEPROM_OFFSET geschrieben |
| `crc_slot_skipped` | ja | 664 | der CRC-Platz bleibt zunaechst unbeschrieben (alter Wert) |
| `mesh_written_in_save` | ja | 821 | das bilineare Mesh wird nur als Teil des gesamten Einstellungsblocks gespeichert |
| `final_header_only_without_error` | ja | 1456 | echte Version und CRC werden nur geschrieben, wenn waehrend des Speicherns KEIN Fehler auftrat |
| `final_header_written_last` | ja | 1463 | Version und CRC werden als LETZTES geschrieben (nach allen Daten) |
| `finish_after_header` | ja | 1471 | EEPROM_FINISH() folgt dem Header |
| `load_version_mismatch_is_error` | ja | 1501 | abweichende Version beim Laden ist ein Fehler |
| `load_crc_mismatch_is_error` | ja | 2383 | abweichende CRC beim Laden ist ein Fehler |
| `validate_does_not_apply_data` | ja | 2395 | validate() prueft nur (Version, Groesse, CRC); es uebernimmt keine Daten in den RAM |
| `validate_is_readonly_check` | ja | 2444 | validate() = _load() mit validating=true (nur lesend) |
| `failed_load_resets_everything` | ja | 2464 | ungueltiger EEPROM -> reset(): ALLE Einstellungen fallen auf die Konfigurationswerte zurueck |
| `auto_init_disabled` | ja | 1835 | EEPROM_AUTO_INIT ist AUSkommentiert: nach dem Zuruecksetzen wird NICHT automatisch neu gespeichert |

## Schlussfolgerung (nur aus den gefundenen Tatsachen abgeleitet)

- **all_required_facts_found**: True
- **failed_or_interrupted_save_invalidates_stored_image**: True
- **old_mesh_survives_failed_save**: False
- **consequence_if_invalid**: beim naechsten Start wird NICHT nur das Mesh, sondern der GESAMTE Einstellungsblock verworfen (reset() auf Konfigurationswerte, ohne EEPROM_AUTO_INIT keine Neuspeicherung)
- **readback_possible**: True
- **readback_strength**: validate() bestaetigt nur Version, Groesse und CRC des gespeicherten Abbilds; es vergleicht NICHT das Mesh mit dem RAM
- **catalog_clause_never_overwrite_old_mesh_on_error**: NICHT erfuellbar mit settings.save()
- **backend**: UNVERIFIZIERT: Configuration.h legt den EEPROM-Typ nicht fest; er kommt aus der Board-Pinbelegung (nicht im Nachweis). Ob I2C-EEPROM (Seitenschreiben, sequenziell) oder Flash-Emulation (Seite loeschen+schreiben): unbekannt; beide sind nicht atomar gegenueber Stromausfall.

## Was daraus folgt

1. Ein fehlgeschlagener ODER unterbrochener `M500` hinterlaesst den Platzhalter-Header `"ERR"`: beim naechsten Start gilt der EEPROM als ungueltig, **alle** gespeicherten Einstellungen (auch ein kalibrierter Z-Offset, Schrittzahlen, PID) fallen auf die Konfigurationswerte zurueck. Das ist ein Risiko des OEM-Speicherns insgesamt, nicht nur des Meshs.
2. Solange kein Stromausfall mitten im Speichern passiert, bleibt der RAM gueltig; ein fehlgeschlagenes `save()` kann wiederholt werden. Das ist ein Mitigationsgedanke, keine Garantie.
3. `validate()` kann nach dem Speichern als Pruefung der Abbild-Konsistenz dienen, ersetzt aber keine atomare Wiederherstellung.
4. Deshalb: die Auto60-Maschine endet in `DoneRamOnly` (nur RAM). Das Persistieren bleibt eine bewusste Handlung des Nutzers (OEM-Taste bzw. `M500`) nach Sichtpruefung des Meshs. Ein automatischer Commit waere nur mit einem echten Doppelpuffer-/Zweiseiten-Konzept verantwortbar, das hier nicht existiert.
