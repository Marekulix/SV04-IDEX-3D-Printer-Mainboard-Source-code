# Katalogvorschlag (Stand 19)  |  NUR EIN VORSCHLAG: der Katalog ist unveraendert, die Entscheidung liegt beim Nutzer

Heute haben **C3, D1, E1, E2, G3** keine S/C-Nachweise definiert (E3 hat 5 S-Nachweise, keinen C-Nachweis), und fuer **H** ist bei allen 23 Kriterien nichts hinterlegt. Das Skript `tools/score_progress.py` zaehlt nur, was der Katalog verlangt; **ich habe nichts davon eingetragen.** Jeder Vorschlag unten ist maschinell pruefbar (Datei plus Inhalt), nennt aber **keine Punktzahl**.

## Allgemeines H-Format (fuer alle Kriterien mit H-Anteil)
Datei `hardware/protocols/<Stufe>-<Datum>.json` nach `hardware/templates/`; geprueft von `tools/h_protocol_check.py` (Ergebnis berechnet, leere Vorlage besteht nie, `overlay_zip_sha256` gegen `RELEASE_REGISTER.json`, `bewegung_ausgeloest` und `heizung_ausgeloest` false fuer H0 bis H3). **Voraussetzung:** der Katalog bekommt pro Kriterium ein `H`-Nachweisfeld, das auf Stufe und Messung zeigt. Bis dahin vergibt das Skript keine H-Punkte, auch bei sauberen Protokollen.

## Je Kriterium
| Kriterium | Vorschlag S (Simulation) | Vorschlag C (CI) | H | Offene Entscheidung |
|---|---|---|---|---|
| **C3** T1-Park-/Kollisionsinterlock (5) | `proof/real-g29-*.log` enthaelt die Szenarien V15, V16, V17, E00 bis E15 mit PASS; `docs/T1_ENDSTOP_BELEGMATRIX.json` mit `alle_belege_gefunden` | CI-Artefakt `bin-strings-sv04.txt` enthaelt die beiden T1-Texte (REFUSED/ABORT) im ARM-Binary | H1 (M119-Pegel) und H3 (Abstand) | ob "unabhaengig" (physisch) schon mit S/C teilbewertet werden soll |
| **D1** nativer EEPROM-Commit (10) | **nicht ohne Entscheidung:** das Kriterium verlangt `M500` mit Readback. Das widerspricht dem aktuellen Sicherheitsrahmen (kein EEPROM-Schreiben). | - | - | **Aufteilen?** D1a "RAM-Rollback altes Mesh" (gebaut, getestet) und D1b "EEPROM-Commit" (blockiert: `sizeof(SettingsData)`, nicht-atomarer `save()`, Ladepfad) |
| **E1** Ein-Knopf-Taste (4) | - (kein Display-Projekt) | Hash der Display-Projektdatei plus gebauter Handler | Touch-Protokoll | erst nach Display-Projekt (`docs/DWIN_DISPLAY_SPEZIFIKATION.md`) |
| **E2** Anzeige (6) | Test des Statusmoduls (`tests/test_stage18_modules.py`) | CI-Build mit eingebundenem Modul und 0 neuen Fehlern | H2 | Statusmodul einbinden (Freigabe) |
| **E3** manuelle Justage unveraendert (4) | vorhanden (5 S-Nachweise) | CI: Host-Tests-Log enthaelt `PASS Overlay gegen ECHTE OEM-Dateien` und `Quellpatch (git apply)` | H2 (Bettmenue unveraendert) | - |
| **G3** offene Quellen statt base64 (2) | `patches/0001-*.patch` plus `tests/test_patch_apply.py` PASS | CI-`host-tests.log` enthaelt `PASS Quellpatch` | - | ob der Workflow kuenftig den Patch statt der Overlay-ZIP anwendet |

## Hinweis zu den Punkten
Nichts hiervon erhoeht den Fortschritt, solange der Katalog nicht erweitert wird. Der heutige Hoechstwert ohne Hardwarestufe bleibt 55,00. Eine Erweiterung um S/C-Nachweise fuer C3, E3 und G3 koennte hoechstens deren S/C-Anteil freischalten.
