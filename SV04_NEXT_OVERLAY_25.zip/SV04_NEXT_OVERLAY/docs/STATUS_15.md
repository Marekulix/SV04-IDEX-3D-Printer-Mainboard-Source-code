# SV04 NEXT: Stand 15 (Claude, 31.10.2026)  |  NICHT FLASHEN

Anlass: Das Komplettpaket enthielt erstmals die ECHTEN OEM-Quelltexte (G28/G29/LCD_RTS/probe/Configuration) und Marlin-Header sowie die Ergebnisse von Workflow 15
(baseline gruen, Symbol-Probe gruen, beide Overlay-Varianten SKIPPED).
Ursachen: (1) mein CLI fand seine Header relativ zum Arbeitsverzeichnis (Workflow 15 rief aus der Repository-Wurzel auf), mein Workflow-Test hatte den Erfolgspfad nie ausgefuehrt;
(2) die Sperre "RTS automation forbidden" war ein Fehlalarm auf OEM-Code (der echte LCD_RTS.cpp enthaelt settings.save() sechsmal); (3) die echte G28.cpp hat die Struktur 2-1-2-1-1
(Normalpaar, Duplikationspaar, ungepaarter T0-Aufruf NUR waehrend eines Drucks, toter Nicht-IDEX-Zweig) und widerlegte die Annahme "genau 2+2".
Aenderungen: differenzielle Sperre (nur was das Overlay ZUSAETZLICH einbringt); strukturelle G28-Analyse mit Klassifikation jedes homeaxis(X_AXIS)-Aufrufs, Neuberechnung vor der Instrumentierung;
ortsunabhaengiges CLI; Workflow 17 (freie Nummer) mit eindeutigem ZIP-Namen; Real-OEM-Test (92 Pruefungen); Shim-Typpruefung des eingefuegten Codes im Kontext der echten Dateien.
Nachweisebene: Simulation/Text. KEIN Marlin-Build des Overlays, KEIN CI-Lauf des Overlays, KEIN Hardwaretest. baseline und probe sind real gebaut (Workflow 15).
Fortschritt laut unveraendertem Katalog: 20,25 von 100 (Stand 14: 16,85).
