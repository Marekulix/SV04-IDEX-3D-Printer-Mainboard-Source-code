# DWIN-Ressourcen fuer die Ein-Knopf-Bettvermessung: Beschaffungsliste (Stand 17)  |  keine Adresse erfunden

**Ausgangslage (belegt):** Soll-/Ist-Bettemperatur (`BED_SET_TEMP_VP` 0x103A, `BED_CURRENT_TEMP_VP` 0x103C), Fortschrittsicon (`AUTO_BED_LEVEL_ICON_VP` 0x108D) und 16 Messwerte (`AUTO_BED_LEVEL_1POINT_VP` + 2*(n-1), 0x1100 bis 0x111E) gibt es im OEM-Code. Das Display-Projekt (T5UID1/DGUS: Konfiguration, Bilder, Touchbereiche) liegt **nicht** im Repository (Inventar in CI 18 ohne Display-Dateien; Workflow 19 listet sie erneut). Deshalb sind alle folgenden Punkte **blockiert**, bis jemand das Projekt liefert.

| Nr | Benoetigt | Warum | Abnahme |
|---|---|---|---|
| 1 | Das **Original-DWIN-Projekt** der installierten SV04-Displayfirmware (Konfigurations- und Bilddateien, passend zur Version auf dem Display) | Ohne das ist unbekannt, welche VPs/Touchbereiche das Display wirklich hat | Dateiliste im Repository; Version stimmt mit dem Display ueberein |
| 2 | **Windows-Werkzeug des Displayherstellers (DGUS/T5UID1)** und ein Rechner dafuer | Neue Seiten/Touchbereiche koennen nur dort erstellt werden. **Das widerspricht der Vorgabe "nur Android-Tablet":** diesen Schritt muss eine dritte Person oder die Community uebernehmen | Neues Projekt als Datei geliefert |
| 3 | Eine neue **Seite "Bettvermessung 60 C"** | Eigener Bildschirm statt Eingriff in das bestehende Bettmenue (E3: unveraendert lassen) | Seitennummer festgelegt, Rueckweg zum Hauptmenue |
| 4 | **Drei Touchbereiche**: Start, Abbruch, Quittieren (je ein Rueckgabecode) | Es gibt heute keinen Start/Abbruch ueber das Display | Adressen vom Display-Designer vergeben, **nicht** aus `docs/DWIN_VP_KONFLIKTMATRIX.md` belegt |
| 5 | Anzeigevariablen: Status-Text (feste Laenge), Fehlercode (Zahl), Fortschritt 0 bis 16 | Heute gibt es keine freie Statuszeile | wie oben |
| 6 | Optional farbige Messkarte (16 Icons) | Heute nur Zahlenwerte | Icon-Satz |
| 7 | Adressplan | Neue Adressen **muessen** Bereich 0x1100 bis 0x111E meiden (dort liegt auch `ChangePageKey` auf Messpunkt 8) und duerfen keine bestehende VP-/Tastenadresse treffen | `python3 tools/dwin_conflicts.py --h LCD_RTS.h --cpp LCD_RTS.cpp --check 0x....` je Adresse: "kein Konflikt in der bekannten Karte" (das beweist NICHT, dass sie im Display frei ist; der Display-Designer muss das im Projekt bestaetigen) |
| 8 | Firmware-Seite (erst nach 1 bis 7 und ausdruecklicher Freigabe) | Neue Eintraege in `Addrbuf`, `enum PROC_COM` und `RTS_HandleData`; Start nur ueber `auto60_request_start()` hinter einem eigenen Compile-Makro | eigener Patch mit Tests; **nicht** Teil dieses Standes |

Diese Liste enthaelt bewusst **keine** vorgeschlagene Adresse. Das Werkzeug `tools/dwin_conflicts.py` schlaegt nie eine Adresse vor und kann nicht belegen, dass eine Adresse im Display-Projekt frei ist.
