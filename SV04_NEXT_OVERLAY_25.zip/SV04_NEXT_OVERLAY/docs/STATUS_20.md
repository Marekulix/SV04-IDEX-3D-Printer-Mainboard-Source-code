# STATUS_20  |  NICHT FLASHEN

Drei getrennte Ebenen (Versionschaos vermeiden):
* **Stand (Claude): 20.** Neu gegenueber Stand 19: Hardware-Evidenz des Originals, Rechenmodell, Stagnationswaechter, reales Mesh im G29-Harness, korrigierte Kommentare/Belegmatrix, Dokumente.
* **Workflow (GitHub):** Nummern 17-20 vergeben; zuletzt gebaut Stand 17 (Workflow 20, Lauf 1). **Stand 20 ist nicht gebaut.** Kein neuer Workflow noetig; falls gebaut werden soll: Workflow 20 mit `SV04_NEXT_OVERLAY_S20.zip` (zwei Felder), siehe `GITHUB_ANDROID_SCHRITTE_S20.md`.
* **Patch-v-Schicht:** unveraendert v17 (`integration/apply_native_guard_v17.py`, 17 Header). Der ausgelieferte Quellpatch `patches/0001-sv04next-overlay.patch` wurde neu erzeugt (2027 Zeilen), weil drei Header geaendert wurden.

## Firmware-Diff gegen Stand 19 (`docs/DIFF_FIRMWARE_STAND20_GEGEN_STAND19.diff`)
Drei Dateien, +24/-8 Zeilen:
1. `SV04NextAuto60Policy.hpp`: drei Konstanten `ProgressWindowMs` 30000, `MinProgressC` 1,0, `ProgressUntilC` 55,0.
2. `SV04NextThermalWitness.hpp`: Fehler `Stagnation` (ANGEHAENGT, bisherige Zahlenwerte unveraendert), Fortschrittsfenster beim Aufheizen. **Verhaltensaenderung** im Host-Modell: Aufheizen ohne Anstieg (Heizung aus, Fuehler haengt, Bett kuehlt) bricht nach einem Fenster ab statt nach 12 Minuten. Der Witness gibt weiter **keine** G-Codes aus und genehmigt kein EEPROM.
3. `SV04NextT1ParkSense.hpp`: nur Kommentare (365,35 statt 362; `X_MAX` nur fuer T1). **Logik unveraendert.**

Gegenueber dem in CI 20 gebauten Stand 17 gelten zusaetzlich die Aenderungen von Stand 19 (`G29.cpp` +4 Zeilen Cache-Invalidierung, `SV04NextAuto60Engine.hpp` Fortschritt auf 16 begrenzt). Der gesamte Firmwarebestand ist **nicht** neu fuer ARM gebaut.

## Nachweise (lokal, Host)
Gesamtstaffel gruen (`proof/stand20-all-tests.log`). **NOT_RUN:** nativer STM32-Build, Hardwaretests, echte GitHub-Laeufe. Kein Beweis fuer Marlin-Kompatibilitaet oder Sicherheit am Geraet.
Neue Pruefungen: Thermal-Witness 89 928 (-O0/-O2), Thermal-Realkurve 904, Mesh-Zweiwege 1260, Hardwaremodell 35, Belegmatrix 33 (19 Zeilen), Evidenzmatrix 33 Eintraege (streng validiert), Real-G29 je 156 mit synthetischem und realem Mesh, Thermal-Mutationspruefung 8/8.

## Lesehinweis Android
Dateien sind UTF-8-Markdown. ZIP-Name ohne ` (1)`. Siehe `GITHUB_ANDROID_SCHRITTE_S20.md` (ausserhalb des ZIP, mit SHA256).
