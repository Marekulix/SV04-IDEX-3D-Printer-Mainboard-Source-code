# DWIN-Display: Spezifikation fuer das fehlende Display-Projekt (aus dem Quelltext erzeugt)  |  NICHT UMGESETZT, KEIN FIRMWARE-ANSCHLUSS

Dieses Dokument ist die **Vorlage fuer eine Person mit Windows und dem DGUS-Werkzeug**. Es enthaelt **keine neu erfundene VP-Adresse**. Alles mit "ADRESSE: festzulegen" muss der Display-Designer im Projekt vergeben und danach mit `tools/dwin_conflicts.py --check` gegen die bekannte Karte pruefen (das beweist NICHT, dass die Adresse im Display frei ist). Es gibt weiterhin **keinen** Touch-Start in der Firmware.

## 1. Bereits vorhandene, verifizierte VPs (OEM schreibt sie selbst; nur lesen/anzeigen)

- Soll-/Ist-Bettemperatur: `BED_SET_TEMP_VP` = 0x103A, `BED_CURRENT_TEMP_VP` = 0x103C
- Fortschrittsicon: `AUTO_BED_LEVEL_ICON_VP` = 0x108D
- 16 Messwerte (Familie, Schritt 2): `AUTO_BED_LEVEL_1POINT_VP` = 0x1100 bis +30; **Achtung:** `ChangePageKey` liegt auf Messpunkt 8 (0x110E), siehe `docs/DWIN_VP_KONFLIKTMATRIX.md`

## 2. Neue Elemente (ADRESSE: vom Display-Designer festzulegen)

| Element | Art | Inhalt / Rueckgabe | Anforderung |
|---|---|---|---|
| Seite "Bettvermessung 60 C" | Seite | Rueckweg zum Hauptmenue | eigene Seitennummer, Bettmenue des OEM **unveraendert** |
| Taste START | Touchbereich | Rueckgabecode START | Verriegelung: nur sichtbar/aktiv in Zustand Bereit; **in der Firmware heute nicht angeschlossen** |
| Taste ABBRUCH | Touchbereich | Rueckgabecode ABBRUCH | immer aktiv waehrend des Laufs |
| Taste QUITTIEREN | Touchbereich | Rueckgabecode QUIT | nach Ende/Abbruch; bestaetigt nur die Kenntnisnahme, **kein Speichern** |
| Statuszeile | Textvariable | bis 24 Zeichen, ASCII | Texte siehe Abschnitt 3 |
| Fehlercode | Zahlvariable | 0 bis 22 (Abbruchgrund der Maschine) | nur Anzeige |
| Fortschritt | Zahlvariable/Icon | 0 bis 16 | nicht die OEM-Variable doppelt beschreiben, ausser abgestimmt |
| Gueltig-Markierung je Messpunkt (optional) | 16 Icons | gueltig / ungueltig / nicht gemessen | heute nicht darstellbar (kein VP) |

## 3. Statustexte je Abbruchgrund (Zuordnung Code = Aufzaehlungswert der Maschine)

| Code | Grund (Maschine) | Anzeigetext (max. 24 Zeichen) |
|---|---|---|
| 0 | `None` | OK |
| 1 | `UserAbort` | Abbruch durch Sie |
| 2 | `NotIdle` | Drucker nicht bereit |
| 3 | `Precondition` | Voraussetzung fehlt |
| 4 | `ObservationInvalid` | Messwert ungueltig |
| 5 | `HeatTimeout` | Aufheizen zu langsam |
| 6 | `HeatTargetNotApplied` | Heizung ohne Reaktion |
| 7 | `TempOvershoot` | Bett zu heiss |
| 8 | `TempLost` | Temperatur verloren |
| 9 | `ExternalActivity` | Anderweitig aktiv |
| 10 | `Stopped` | Not-Aus/Stopp |
| 11 | `HomeTimeout` | Referenzfahrt zu lang |
| 12 | `HomeFailed` | Referenzfahrt fehlerhaft |
| 13 | `HomeStale` | Referenzfahrt veraltet |
| 14 | `MeasureTimeout` | Messung zu lang |
| 15 | `MeshFailed` | Messung fehlgeschlagen |
| 16 | `LevelingInactive` | Leveling nicht aktiv |
| 17 | `OffsetChanged` | Z-Offset geaendert |
| 18 | `CommitTimeout` | Speichern zu lang |
| 19 | `ReadbackMismatch` | Speichern fehlerhaft |
| 20 | `CommitNotAvailable` | Fertig, ungespeichert |
| 21 | `CommitNotConfirmed` | Nicht bestaetigt |
| 22 | `ActionFailed` | Befehl abgelehnt |

## 4. Zustandstexte (Vorschlag)

"Bereit", "Heizt auf (60 C)", "Referenzfahrt", "Messung n/16", "Fertig, NICHT gespeichert", "Abgebrochen: <Grund>". Kein Text darf Speichern vortaeuschen: die Firmware speichert nie automatisch.

## 5. Abnahme des Display-Projekts (vom Designer zu erfuellen)

1. Liste aller verwendeten Adressen und Rueckgabecodes als Datei; keine Ueberschneidung mit Abschnitt 1 und mit `docs/DWIN_VP_KONFLIKTMATRIX.json`.
2. Das Bettmenue und die OEM-Seiten sind unveraendert (Vergleich der Projektdateien).
3. Keine Taste loest ohne Firmware-Handler etwas aus (Rueckgabecode ohne Handler wird vom OEM verworfen, `RTS_RecData`: unbekannter Befehl wird ignoriert).
4. Frameformat und Quittungen siehe `docs/DWIN_FRAMES.md` (keine Pruefsumme).

**Nicht untersucht:** Puffergroessen und Timing der Displayfirmware, Schriftarten/Zeichensatz (Umlaute vermieden).
