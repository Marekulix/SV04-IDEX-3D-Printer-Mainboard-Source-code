# PROGRESS (Stand 20)  |  Skript unveraendert: `tools/score_progress.py` (SHA256 siehe unten)

Der Katalog wurde **nicht** angepasst und **nicht manuell neu bewertet**.

| Sicht | Punkte |
|---|---|
| Formal, Baum mit den CI-Nachweisen frueherer Staende (CI 18, CI 20) | **39,50** (Stand 19: 39,50; Stand 20: 39,50) |
| Dieselbe Rechnung ohne jeden `ci-evidence`-Ordner | 17,85 (Stand 19: 17,85; Stand 20: 17,85) |
| Hoechstwert ohne Hardwarestufe | 55,00 |

**Bedeutung:** Die neuen Stand-20-Ergebnisse (Hardware-Evidenz des Originals, Stagnationswaechter, reales Mesh) erhoehen den Katalogwert **nicht**: der Katalog definiert fuer alle 23 Kriterien keinen H-Nachweis, und Messungen am Original-Drucker sind kein H-Nachweis der SV04-NEXT-Firmware. Auch hat kein ARM-Build von Stand 20 stattgefunden.

Die frueher genannte Zahl 20,25 (Stand 19 ohne CI) konnte ich mit dieser einfachen Methode nicht nachbilden, weil die damalige Baumkonfiguration nicht dokumentiert ist; ich verwende sie nicht weiter.

Pruefsummen: `progress/catalog.json` 844f445d54239e15fd233da12b29724d9bd96af5d0b84a727db294e7b503d336; `tools/score_progress.py` 02b0a101655535b4492b112c596e87f5761790768f623bbfe1ec6656342296f3. Ausgabe: `proof/progress-stand20-ohne-ci.txt` (Baum mit CI-Nachweisen).
