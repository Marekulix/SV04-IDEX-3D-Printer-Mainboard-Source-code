# DWIN/RTS-Frameprotokoll (aus dem ECHTEN LCD_RTS, `tools/dwin_frames.py`)

Nur Quelltextfakten mit Zeilen. **Keine Pruefsumme im Frame.** Schreibquittungen des Displays erzeugen kein Touch-Ereignis. Nicht untersucht: Puffergroessen bei ueberlangen Frames, Timing, das Verhalten der Displayfirmware selbst.

| Aussage | Beleg |
|---|---|
| Frame-Kopf 0x5A 0xA5 | LCD_RTS.h:12; LCD_RTS.h:13 |
| Senden: len+3 Byte werden geschrieben | LCD_RTS.cpp:537; LCD_RTS.cpp:539 |
| VP schreiben = Befehl 0x82 (Adresse hi/lo, Worte big-endian) | LCD_RTS.cpp:519; LCD_RTS.cpp:522; LCD_RTS.cpp:526 |
| Register schreiben 0x80 / lesen 0x81; VP lesen 0x83 | LCD_RTS.cpp:505; LCD_RTS.cpp:513; LCD_RTS.cpp:530 |
| Empfang: Schreibquittung "OK" (0x4F 0x4B) wird erkannt und verworfen (kein Ereignis) | LCD_RTS.cpp:459; LCD_RTS.cpp:460 |
| Empfang 0x83: Adresse, Bytelaenge, Worte big-endian (Touch-/Variablenereignis) | LCD_RTS.cpp:465; LCD_RTS.cpp:469 |
| Empfang: Zeitueberschreitung 50 Durchlaeufe | LCD_RTS.cpp:441 |
| Schnittstelle: LCD_SERIAL (Zeichenweise read/write) | LCD_RTS.cpp:400; LCD_RTS.cpp:405 |
