# HIL_NAECHSTE_SCHRITTE: Vorschlaege fuer weitere Messungen am ORIGINAL  |  nur mit Ihrer Entscheidung, kein Muss

Alles am **Original-Sovol**, **keine SV04-NEXT-Firmware**, kein Flash, kein `G29`, kein `M500`/`M502`, kein T0 an die rechte Seite. Jede Zeile haengt an einer offenen Frage.

| Nr | Was | Warum | Risiko |
|---|---|---|---|
| A | `M119` im Ruhezustand mit **eingefahrenem** BLTouch-Stift (`M280 P0 S90`), Heizung aus, keine Bewegung | klaert Q5 / H09-1 (`z_min TRIGGERED` im Ruhezustand) | keines (nur lesen) |
| B | Bett-Aufheizen wie H06 mit `M155 S1` (Meldung jede Sekunde), 60 C halten ca. 10 Minuten, Terminal-Log speichern, danach `M140 S0` | Heizkurve mit Probenabstand 1 s statt 30 s, mehrere Minuten Nachlauf, PWM-Verlauf (`B@`) fuer Q8 | wie bereits durchgefuehrt (Bett 60 C, beobachtet) |
| C | `M106 S128` ohne `P` und `M107`; Foto der Luefterstecker stromlos | Q4 | keines |
| D | Terminal-**Log-Datei** und die Fotos der Messungen als Dateien liefern | Q7 | keines |
| E | Dateien liefern: `tool_change.cpp`, `M605.cpp`, `M106_M107.cpp`, `temperature.cpp`, `bltouch.cpp`, `M17_M18_M84.cpp` (eine ZIP ohne ` (1)` im Namen) | Q1 bis Q5 | keines |
| F | Herkunft/Pruefsumme der **Original-Firmware** (`.bin`), falls vorhanden | Q6 | keines |

Nicht vorgeschlagen: `G29`, `G34`, `M48`, `M500`, `M502`, Fahren von T0 nach rechts, Flashen. Fuer `M48` gibt es **keinen** Aufrufer; eine optionale Diagnosefunktion waere erst nach Q5 und mit gesonderter Freigabe zu entwerfen (im OEM-Build ist sie ausgeschaltet).
