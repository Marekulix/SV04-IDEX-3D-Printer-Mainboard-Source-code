# SV04 NEXT: Stand 17 (Claude, 01.11.2026)  |  NICHT FLASHEN

Firmware gegenueber Stand 16: NUR `SV04NextT1ParkSense.hpp` aendert sich (T0-Positionsunterscheidung, siehe docs/DIFF_FIRMWARE_STAND17_GEGEN_STAND16.diff); `G29.cpp`, `LCD_RTS.cpp`, `G28.cpp` sind byte-identisch zu Stand 16.
Nicht in CI gebaut (weder Stand 16 noch 17). CI 18 baute den Stand-15-Code. Katalogwert formal 39.50; konservativ fuer den ausgelieferten Code 20.25; Hoechstwert ohne Hardwarestufe 55,00. Keine Firmware freigegeben.
Nicht verdrahtet und nicht aktiviert: Auto60-Ausloeser, EEPROM-Schreiben, DWIN-Bedienung, A/B-Slot-Entwurf.
