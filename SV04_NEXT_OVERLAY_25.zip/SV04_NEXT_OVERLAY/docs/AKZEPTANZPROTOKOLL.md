# Akzeptanzprotokoll fuer spaetere Hardware-Stufen  |  NICHTS DAVON IST DURCHGEFUEHRT

**Dieses Dokument verbucht keinen Test.** Jede Stufe ist nur mit ausdruecklicher Freigabe des Nutzers auszufuehren; Stufen H0 und H1 bewegen nichts und heizen nichts. Ergebnisfelder bleiben leer, bis jemand misst. Abbruch bei jeder Abweichung.

| Stufe | Voraussetzung | Handlung (keine Bewegung/Heizung bis H3) | Messbares Kriterium | Ergebnis |
|---|---|---|---|---|
| H0 (Papier) | gruener CI-Lauf des Stands, vom Auswerter bestaetigt | Firmware **nicht** flashen; Pruefsummen, Release-Register, Overlay-Hash vergleichen | Auswerter meldet "GRUEN" fuer Stand N; `overlay-zip.sha256` == Register | |
| H1 (Pegel) | H0 | Drucker stromlos; nur Sichtpruefung Kabel X_MAX; spaeter bei eingeschaltetem Geraet **ohne** G-Code mit `M119` (Endstop-Status, nur lesend) | `M119` zeigt `x_max` **TRIGGERED** bei bekannt gedruecktem Schalter, **open** bei losgelassenem; Kabel abgezogen zeigt **open** (Pull-up) | |
| H2 (Anzeige) | H1 | nur Display: pruefen, dass kein neuer Touchbereich existiert und die Bettvermessung-Seite des OEM unveraendert ist | keine neue Taste; OEM-Messwerte 1 bis 16 unveraendert | |
| H3 (Mechanik, handbewegt) | H1, Nutzer-Freigabe | **Von Hand** (Motoren aus): T0 bis x=277 schieben, T1 im Park; Abstand der Schlitten mit Messschieber | Abstand >= 20 mm (Vorschlag, vom Nutzer zu bestaetigen); X_MAX bleibt bei T1 im Park **TRIGGERED**, bei T0 an x<=302 **open** | |
| H4 (erste Bewegung, NICHT Teil dieses Auftrags) | H0 bis H3 und ausdrueckliche schriftliche Freigabe | erst dann: `G28`, dann `G29 U` unter Aufsicht (Hand am Netzschalter) | wird in einer spaeteren Runde festgelegt | |
**Dry-run ohne Heizung/Bewegung (Software):** `tests/run_all_local.sh` und CI. Operator-Failsafes (bereits im Code, nur simuliert): jeder Fehler -> altes Mesh zurueck (RAM), `G29 U` und Auto60 sind getrennt von manuellem Leveling, Abbruch immer moeglich, **kein** stilles Speichern (kein `M500`).
Begriffe fuer die Anzeige (Vorschlag, noch nicht verbaut): "Messung laeuft (n/16)", "Abgebrochen: Werkzeug 1 nicht geparkt", "Abgebrochen: Bett nicht auf Temperatur", "Fertig, NICHT gespeichert".
