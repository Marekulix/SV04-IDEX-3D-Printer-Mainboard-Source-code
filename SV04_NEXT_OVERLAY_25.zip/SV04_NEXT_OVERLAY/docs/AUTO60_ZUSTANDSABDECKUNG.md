# Auto60-Maschine: Abdeckung der Abbruchgruende durch Tests (Stand 18)  |  NICHT AUFRUFBAR, KEIN AUSLOESER

Gezaehlt werden Verweise `Reason::X`/`Rs::X` in `tests/test_auto60_engine.cpp`, `harness/driver_e2e.cpp`, `harness/driver.cpp` (Text-Zaehlung, **keine** Verzweigungsueberdeckung). Die Maschine hat **keinen** Aufrufer von `request_start()`; ihre Einbindung ist nur mit `SV04_NEXT_AUTO60_ENGINE` kompilierbar und in CI 20 **nicht** gebaut (Infrastrukturfehler).

| Abbruchgrund | Verweise in Tests |
|---|---|
| `None` | 3 |
| `UserAbort` | 2 |
| `NotIdle` | 2 |
| `Precondition` | 4 |
| `ObservationInvalid` | 1 |
| `HeatTimeout` | 1 |
| `HeatTargetNotApplied` | 1 |
| `TempOvershoot` | 1 |
| `TempLost` | 2 |
| `ExternalActivity` | 3 |
| `Stopped` | 2 |
| `HomeTimeout` | 3 |
| `HomeFailed` | 4 |
| `HomeStale` | 1 |
| `MeasureTimeout` | 4 |
| `MeshFailed` | 5 |
| `LevelingInactive` | 1 |
| `OffsetChanged` | 1 |
| `CommitTimeout` | 1 |
| `ReadbackMismatch` | 2 |
| `CommitNotAvailable` | 2 |
| `CommitNotConfirmed` | 1 |
| `ActionFailed` | 4 |

Ohne jeden Testverweis: (keine).
**Zuordnung der geforderten Faelle:** fehlendes Idle -> `NotIdle`; Druck/Pause -> `Precondition`/`ExternalActivity`; T1 nicht geparkt -> `Precondition` (Beobachtung `t1_parked_electrically`); Heizungs-/Sensorfehler -> `ObservationInvalid`/`TempLost`; Aufheiz-Timeout -> `HeatTimeout`; Drift/Ueberschwingen -> `TempLost`/`TempOvershoot`; Homing -> `HomeTimeout`/`HomeFailed`/`HomeStale`; G29-Teilfehler -> `MeshFailed` plus Fehlercode `mesh_failure`; Abbruch jederzeit -> `UserAbort`; Z-Offset-Aenderung -> `OffsetChanged`; Mesh/Leveling -> `LevelingInactive`.
**NICHT abgedeckt:** BLTouch haengt/loest nicht aus als EIGENER Befund: nur indirekt als `MeshFailed`/`MeasureTimeout`; die Quellen `bltouch.cpp`/`bltouch.h`-Zustand liegen im Repository-Auszug nicht vor. Z-Offset (-1,10 mm): die Maschine liest `probe_offset_z` nur und bricht bei Aenderung ab (`OffsetChanged`), sie schreibt ihn nie.
