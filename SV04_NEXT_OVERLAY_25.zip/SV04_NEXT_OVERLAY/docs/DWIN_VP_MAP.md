# DWIN/RTS-Karte aus dem ECHTEN `LCD_RTS.h` / `LCD_RTS.cpp` (maschinell erzeugt, `tools/dwin_map.py`)

Jede Zeile traegt Quelle und Zeile. **Nichts ist erfunden**; was der Quelltext nicht hergibt, steht als unbekannt/blockiert. Das Display-Projekt (T5UID1/DGUS-Konfiguration, Bilder) liegt NICHT vor.

**Befund (OEM, nicht von uns):** Tastenadressen im Wertebereich der 16 Messpunkte (AUTO_BED_LEVEL_1POINT_VP + 2*(n-1)): `ChangePageKey` = 0x110E = Punkt 8. Neue Adressen muessen diesen Bereich meiden; ob das im Display-Projekt ein echtes Problem ist, ist aus dem Quelltext nicht belegbar.

VP-Definitionen: 86 aktiv, 15 auskommentiert. Tasten (Enum PROC_COM): 35.

## Anforderungen an die Ein-Knopf-Funktion

| Element | Status | Beleg / Grund |
|---|---|---|
| Fortschritt 1 bis 16 | **BELEGT (OEM)** | AUTO_BED_LEVEL_ICON_VP und je Punkt AUTO_BED_LEVEL_1POINT_VP + (n-1)*2; der OEM-G29 beschreibt sie selbst, G29 U nutzt dieselbe Schleife. Ob das Display-Projekt alle 16 Adressen darstellt: NICHT aus dem Quelltext belegbar. |
| Temperatur Soll/Ist Bett | **BELEGT (OEM)** | BED_SET_TEMP_VP und BED_CURRENT_TEMP_VP existieren; auf welcher Seite sie sichtbar sind: unbekannt (Display-Projekt). |
| Messwert je Punkt (Zahl) | **BELEGT (OEM)** | AUTO_BED_LEVEL_1POINT_VP + (n-1)*2, Wert z*1000. |
| Schaltflaeche "Bettvermessung 60 C" | **BLOCKIERT** | Braucht einen NEUEN Touch-Bereich im DWIN-Projekt samt neuer Adresse, Eintrag in Addrbuf, neuem Enum-Wert und Handler. Ohne Display-Projekt (T5UID1-Konfiguration/Bilder) nicht verantwortbar; keine Adresse wird erfunden. |
| Abbruch-Schaltflaeche | **BLOCKIERT** | Wie oben; Abbruch ueber das Display existiert fuer diese Funktion nicht. |
| Farbige Messkarte | **BLOCKIERT** | Kein VP/Icon-Mapping fuer Farbzustaende der 16 Punkte im Quelltext; braucht Display-Ressourcen. |
| Fehlercode-/Statuszeile | **BLOCKIERT** | Es gibt nur feste Text-VPs (PRINTER_*_TEXT_VP); keine freie Statuszeile belegt. |
| Erfolgs-/Fehlerseite | **BLOCKIERT** | Seitenwechsel laufen ueber ExchangePageBase + Seitennummer; neue Seiten gibt es nur im Display-Projekt. Der OEM wechselt am Ende von G29 selbst via RTS_AutoBedLevelPage(). |

## Bettbezogene VPs

| Name | Adresse | Zeile |
|---|---|---|
| `AUTO_BED_LEVEL_ZOFFSET_VP` | `0x1026` | LCD_RTS.h:48 |
| `BED_SET_TEMP_VP` | `0x103A` | LCD_RTS.h:54 |
| `BED_CURRENT_TEMP_VP` | `0x103C` | LCD_RTS.h:55 |
| `AUTO_BED_LEVEL_ICON_VP` | `0x108D` | LCD_RTS.h:66 |
| `TWO_EXTRUDER_HOTEND_ZOFFSET_VP` | `0x1096` | LCD_RTS.h:70 |
| `AUTO_BED_LEVEL_1POINT_VP` | `0x1100` | LCD_RTS.h:72 |

## Tasten mit Bezug zum Bettnivellieren oder zu G29/G28

| Key | Index | Adresse | Daten | Befehle | Zeilen |
|---|---|---|---|---|---|
| `AdjustmentKey` | 1 | `0x1004` | [1, 2, 3, 4] |  | LCD_RTS.cpp:850-894 |
| `ResumePrintKey` | 5 | `0x100C` | [1, 2, 3, 4] | M24 | LCD_RTS.cpp:948-1133 |
| `SettingScreenKey` | 12 | `0x103E` | [1, 2, 3, 4, 5, 6, 7] | G1 F200 Z0.0, G28, M84 | LCD_RTS.cpp:1311-1423 |
| `BedLevelFunKey` | 14 | `0x1044` | [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11] | G1 F200 Z0.0, G1 F600 Z0, G1 F600 Z3, G1 X150 Y150 F3000, G1 X275 Y275 | LCD_RTS.cpp:1459-1603 |
| `AxisPageSelectKey` | 15 | `0x1046` | [1, 2, 3, 4] | G28 | LCD_RTS.cpp:1281-1311 |
| `SelectExtruderKey` | 19 | `0x104E` | [1, 2] | G28 X, T0, T1 | LCD_RTS.cpp:1718-1778 |
| `PowerContinuePrintKey` | 25 | `0x105F` | [1, 2] | M1000, M605 S0, M605 S1, M605 S2, M605 S2 X68 R0, M605 S3 | LCD_RTS.cpp:1976-2048 |
| `StoreMemoryKey` | 30 | `0x1098` | [0] | M420 S1 | LCD_RTS.cpp:2272-2327 |
| `PrintFileKey` | 31 | `0x2198` | [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12] | M24, M605 S0, M605 S1, M605 S2, M605 S2 X68 R0, M605 S3 | LCD_RTS.cpp:2074-2214 |
| `ChangePageKey` | 34 | `0x110E` | [] | G0 F3000 X-62 Y0, G0 F3000 X362 Y0 | LCD_RTS.cpp:2363-2918 |

## Alle Tasten (Adresse -> Key -> Handler)

| Index | Key | Adresse | Handler (Zeilen) | Daten | M500/settings.save |
|---|---|---|---|---|---|
| 0 | `MainPageKey` | `0x1002` | 743-850 | [1, 2, 3, 4, 5] |  |
| 1 | `AdjustmentKey` | `0x1004` | 850-894 | [1, 2, 3, 4] | JA |
| 2 | `PrintSpeedKey` | `0x1006` | 894-899 | [] |  |
| 3 | `StopPrintKey` | `0x1008` | 899-928 | [0, 1] |  |
| 4 | `PausePrintKey` | `0x100A` | 928-948 | [0] |  |
| 5 | `ResumePrintKey` | `0x100C` | 948-1133 | [1, 2, 3, 4] |  |
| 6 | `ZOffsetKey` | `0x1026` | kein case |  |  |
| 7 | `TempScreenKey` | `0x1030` | 1133-1193 | [0, 1, 2, 3, 4] |  |
| 8 | `CoolScreenKey` | `0x1032` | 1193-1255 | [1, 2, 3, 4, 5, 6, 7, 8] |  |
| 9 | `Heater0TempEnterKey` | `0x1034` | 1255-1261 | [] |  |
| 10 | `Heater1TempEnterKey` | `0x1038` | 1261-1267 | [] |  |
| 11 | `HotBedTempEnterKey` | `0x103A` | 1267-1273 | [] |  |
| 12 | `SettingScreenKey` | `0x103E` | 1311-1423 | [1, 2, 3, 4, 5, 6, 7] |  |
| 13 | `SettingBackKey` | `0x1040` | 1423-1459 | [1, 2, 3] | JA |
| 14 | `BedLevelFunKey` | `0x1044` | 1459-1603 | [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11] |  |
| 15 | `AxisPageSelectKey` | `0x1046` | 1281-1311 | [1, 2, 3, 4] |  |
| 16 | `XaxismoveKey` | `0x1048` | 1603-1673 | [] |  |
| 17 | `YaxismoveKey` | `0x104A` | 1673-1696 | [] |  |
| 18 | `ZaxismoveKey` | `0x104C` | 1696-1718 | [] |  |
| 19 | `SelectExtruderKey` | `0x104E` | 1718-1778 | [1, 2] |  |
| 20 | `Heater0LoadEnterKey` | `0x1054` | 1273-1277 | [] |  |
| 21 | `FilamentLoadKey` | `0x1056` | 1778-1950 | [0, 1, 2, 3, 4, 5, 6, 7, 8] |  |
| 22 | `Heater1LoadEnterKey` | `0x1058` | 1277-1281 | [] |  |
| 23 | `SelectLanguageKey` | `0x105C` | kein case |  |  |
| 24 | `FilamentCheckKey` | `0x105E` | 1950-1976 | [1, 2] |  |
| 25 | `PowerContinuePrintKey` | `0x105F` | 1976-2048 | [1, 2] |  |
| 26 | `PrintSelectModeKey` | `0x1090` | 2214-2272 | [1, 2, 3, 4, 5, 6] | JA |
| 27 | `XhotendOffsetKey` | `0x1092` | 2327-2342 | [] |  |
| 28 | `YhotendOffsetKey` | `0x1094` | 2342-2357 | [] |  |
| 29 | `ZhotendOffsetKey` | `0x1096` | kein case |  |  |
| 30 | `StoreMemoryKey` | `0x1098` | 2272-2327 | [0] | JA |
| 31 | `PrintFileKey` | `0x2198` | 2074-2214 | [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12] |  |
| 32 | `SelectFileKey` | `0x2199` | 2048-2074 | [] |  |
| 33 | `SaveEEPROM` | `0x2202` | 2357-2363 | [1] | JA |
| 34 | `ChangePageKey` | `0x110E` | 2363-2918 | [] |  |
