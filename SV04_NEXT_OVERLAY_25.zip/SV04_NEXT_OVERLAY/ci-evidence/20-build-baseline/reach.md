# Erreichbarkeitsanalyse (baseline)
Funktionen 1072, direkte Kanten 3010, nm-Symbole 1611. **ALLE Erwartungen erfuellt**

| Pruefung | Erwartung | Ergebnis | Treffer |
|---|---|---|---|
| kein Overlay-Objekt im Binary | absent | OK | 0:  |
| RTSUpdate vorhanden (OEM) | present | OK | 1: RTSUpdate() |

Grenzen: nur direkte Sprung-/Aufrufkanten; indirekte Aufrufe, Funktionszeiger, Literal-Pool-Adressen werden nicht verfolgt; Inlining kann Symbole verbergen
