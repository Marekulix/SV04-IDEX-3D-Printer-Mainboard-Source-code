# Overlay-Diagnose gegen den echten Quelltext

Python 3.10.12, HEAD 840143cd691ecb2d204d8e3a9376571be0467831

## 1. Integritaet des Overlay-Ordners
Hashliste: SHA256SUMS_17_ALL.txt | ok: True | veraendert: keine | fehlend: keine | zusaetzliche .py/.hpp/.cpp: keine


## 2. OEM-Dateien
| Datei | vorhanden | SHA1 passt | Zeilen | CRLF | UTF-8 | Overlay-Marker im Text |
|---|---|---|---|---|---|---|
| Marlin/Configuration.h | True | True | 2967 | 0 | True | keine |
| Marlin/src/module/probe.cpp | True | True | 912 | 0 | True | keine |
| Marlin/src/gcode/bedlevel/abl/G29.cpp | True | True | 913 | 0 | True | keine |
| Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp | True | True | 2917 | 0 | True | keine |
| Marlin/src/gcode/calibrate/G28.cpp | True | True | 566 | 0 | True | keine |

## 3. G28.cpp: IDEX-Topologie
```
{
 "x2": 2,
 "x1": 2,
 "x2_lines": [
  400,
  466
 ],
 "x1_lines": [
  407,
  473
 ],
 "pairs": [
  {
   "x2_line": 400,
   "x1_line": 407,
   "x2_idx": 399,
   "x1_idx": 406
  },
  {
   "x2_line": 466,
   "x1_line": 473,
   "x2_idx": 465,
   "x1_idx": 472
  }
 ],
 "singles": [
  {
   "line": 486,
   "reason": "T0-only homing, guarded by isPrinting() (not taken while idle); NOT instrumented"
  }
 ],
 "non_idex": [
  {
   "line": 414,
   "reason": "non-IDEX branch (#else of #if ENABLED(DUAL_X_CARRIAGE)); dead while DUAL_X_CARRIAGE is enabled"
  }
 ],
 "problems": [],
 "interleaved": true,
 "order": "21o211",
 "other_homeaxis_x": 2
}
```

### Zeilen mit homeaxis/active_extruder/IDEX/Praeprozessor
```
30: #if HAS_MULTI_HOTEND
32: #endif
34: #if HAS_LEVELING
36: #endif
38: #if ENABLED(SENSORLESS_HOMING)
40: #endif
44: #if ENABLED(BLTOUCH)
46: #endif
50: #if ENABLED(EXTENSIBLE_UI)
52: #elif ENABLED(DWIN_CREALITY_LCD)
54: #elif ENABLED(DWIN_CREALITY_LCD_ENHANCED)
56: #elif ENABLED(RTS_AVAILABLE)
58: #endif
60: #if HAS_L64XX                         // set L6470 absolute position registers to counts
62: #endif
64: #if ENABLED(LASER_MOVE_G28_OFF)
66: #endif
71: #if ENABLED(QUICK_HOME)
79:     const int x_axis_home_dir = TOOL_X_HOME_DIR(active_extruder);
86:     #if ENABLED(SENSORLESS_HOMING)
92:           #if AXIS_HAS_STALLGUARD(X2)
94:           #endif
96:           #if AXIS_HAS_STALLGUARD(Y2)
98:           #endif
100:     #endif
108:     #if ENABLED(SENSORLESS_HOMING) && DISABLED(ENDSTOPS_ALWAYS_ON_DEFAULT)
111:       #if AXIS_HAS_STALLGUARD(X2)
113:       #endif
114:       #if AXIS_HAS_STALLGUARD(Y2)
116:       #endif
117:     #endif
120: #endif // QUICK_HOME
122: #if ENABLED(Z_SAFE_HOMING)
128:     if (homing_needed_error(_BV(X_AXIS) | _BV(Y_AXIS))) return;
137:     #if HAS_HOME_OFFSET
140:     #else
142:     #endif
146:     #if ENABLED(DUAL_X_CARRIAGE)
149:     #endif
158:       TERN_(DUAL_X_CARRIAGE, idex_set_parked(false));
163:       homeaxis(Z_AXIS);
171: #endif // Z_SAFE_HOMING
173: #if ENABLED(IMPROVE_HOMING_RELIABILITY)
184:     #if HAS_CLASSIC_JERK
187:     #endif
189:     return motion_state;
200: #endif // IMPROVE_HOMING_RELIABILITY
226:   TERN_(FULL_REPORT_TO_HOST_FEATURE, set_and_report_grblstate(M_HOMING));
228:   #if ENABLED(DUAL_X_CARRIAGE)
230:     DualXMode IDEX_saved_mode = dual_x_carriage_mode;
231:   #endif
233:   #if ENABLED(MARLIN_DEV_MODE)
239:       return;
241:   #endif
246:     return;
257:   #if CAN_SET_LEVELING_AFTER_G28
259:   #endif
274:   #if HAS_CURRENT_HOME(X) || HAS_CURRENT_HOME(X2) || HAS_CURRENT_HOME(Y) || HAS_CURRENT_HOME(Y2) || (ENABLED(DELTA) && HAS_CURRENT_HOME(Z))
276:   #endif
278:   #if HAS_HOMING_CURRENT
282:     #if HAS_CURRENT_HOME(X)
286:     #endif
287:     #if HAS_CURRENT_HOME(X2)
291:     #endif
292:     #if HAS_CURRENT_HOME(Y)
296:     #endif
297:     #if HAS_CURRENT_HOME(Y2)
301:     #endif
302:     #if HAS_CURRENT_HOME(Z) && ENABLED(DELTA)
306:     #endif
307:   #endif
309:   #if ENABLED(IMPROVE_HOMING_RELIABILITY)
311:   #endif
314:   #if HAS_MULTI_HOTEND
315:     #if DISABLED(DELTA) || ENABLED(DELTA_HOME_TO_SAFE_ZONE)
316:       const uint8_t old_tool_index = active_extruder;
317:     #endif
319:     #if ENABLED(PARKING_EXTRUDER)
321:     #endif
323:   #endif
331:   #if ENABLED(DELTA)
339:   #elif ENABLED(AXEL_TPARA)
345:   #else
369:     #if HAS_Z_AXIS
371:     #else
373:     #endif
375:     TERN_(HOME_Z_FIRST, if (doZ) homeaxis(Z_AXIS));
391:       homeaxis(Y_AXIS);
396:       #if ENABLED(DUAL_X_CARRIAGE)
399:         active_extruder = 1;
400:         homeaxis(X_AXIS);
403:         inactive_extruder_x = current_position.x;
406:         active_extruder = 0;
407:         homeaxis(X_AXIS);
410:         idex_set_parked();
412:       #else
414:         homeaxis(X_AXIS);
416:       #endif
421:       homeaxis(Y_AXIS);
426:     #if HAS_Z_AXIS && DISABLED(HOME_Z_FIRST)
428:         #if EITHER(Z_MULTI_ENDSTOPS, Z_STEPPER_AUTO_ALIGN)
431:         #endif
433:         TERN(Z_SAFE_HOMING, home_z_safely(), homeaxis(Z_AXIS));
436:     #endif
438:     #if LINEAR_AXES >= 4
439:       if (doI) homeaxis(I_AXIS);
440:     #endif
441:     #if LINEAR_AXES >= 5
442:       if (doJ) homeaxis(J_AXIS);
443:     #endif
444:     #if LINEAR_AXES >= 6
445:       if (doK) homeaxis(K_AXIS);
446:     #endif
450:   #endif
453:    * Preserve DXC mode across a G28 for IDEX printers in DXC_DUPLICATION_MODE.
458:   #if ENABLED(DUAL_X_CARRIAGE)
460:     if (idex_is_duplicating()) {
465:       active_extruder = 1;
466:       homeaxis(X_AXIS);
469:       inactive_extruder_x = current_position.x;
472:       active_extruder = 0;
473:       homeaxis(X_AXIS);
476:       idex_set_parked();
478:       dual_x_carriage_mode = IDEX_saved_mode;
483:     else if((save_dual_x_carriage_mode == 4) && card.isPrinting()){
485:       active_extruder = 0;
486:       homeaxis(X_AXIS);
490:   #endif // DUAL_X_CARRIAGE
505:   #if HAS_MULTI_HOTEND && (DISABLED(DELTA) || ENABLED(DELTA_HOME_TO_SAFE_ZONE))
506:     tool_change(old_tool_index, TERN(PARKING_EXTRUDER, !pe_final_change_must_unpark, DISABLED(DUAL_X_CARRIAGE)));   // Do move if one of the
507:   #endif
509:   #if HAS_HOMING_CURRENT
511:     #if HAS_CURRENT_HOME(X)
513:     #endif
514:     #if HAS_CURRENT_HOME(X2)
516:     #endif
517:     #if HAS_CURRENT_HOME(Y)
519:     #endif
520:     #if HAS_CURRENT_HOME(Y2)
522:     #endif
523:     #if HAS_CURRENT_HOME(Z) && ENABLED(DELTA)
525:     #endif
526:     #if HAS_CURRENT_HOME(I)
528:     #endif
529:     #if HAS_CURRENT_HOME(J)
531:     #endif
532:     #if HAS_CURRENT_HOME(K)
534:     #endif
535:   #endif // HAS_HOMING_CURRENT
548:   TERN_(FULL_REPORT_TO_HOST_FEATURE, set_and_report_grblstate(M_IDLE));
550:   #if HAS_L64XX
565:   #endif
```

## 4. Fehlgeschlagene Anker der gesamten Patch-Kette (toleranter Lauf): 0
Folgefehler moeglich: ein nicht eingefuegter Text laesst spaetere Anker scheitern; der ERSTE Eintrag ist massgeblich.

Erste Audit-Ausnahme nach tolerantem Lauf: None

## 5. Strenger Trockenlauf
OK, geaenderte Dateien: Marlin/src/feature/sv04_next/SV04NextAuto60Engine.hpp, Marlin/src/feature/sv04_next/SV04NextAuto60Glue.hpp, Marlin/src/feature/sv04_next/SV04NextG28G29OrderWitness.hpp, Marlin/src/feature/sv04_next/SV04NextG28PassiveReceipt.hpp, Marlin/src/feature/sv04_next/SV04NextG29UReceipt.hpp, Marlin/src/feature/sv04_next/SV04NextMeshMapPacket.hpp, Marlin/src/feature/sv04_next/SV04NextNativeEventTimeline.hpp, Marlin/src/feature/sv04_next/SV04NextNativeIdexEvidence.hpp, Marlin/src/feature/sv04_next/SV04NextNativeIdexHomingTrace.hpp, Marlin/src/feature/sv04_next/SV04NextNativeReadiness.hpp, Marlin/src/feature/sv04_next/SV04NextNativeStatusPacket.hpp, Marlin/src/feature/sv04_next/SV04NextNativeThermalGate.hpp, Marlin/src/feature/sv04_next/SV04NextSafeFloat.hpp, Marlin/src/feature/sv04_next/SV04NextT1CorrelationAudit.hpp, Marlin/src/feature/sv04_next/SV04NextT1EndstopObserver.hpp, Marlin/src/feature/sv04_next/SV04NextT1ParkSense.hpp, Marlin/src/feature/sv04_next/SV04NextVisitProof.hpp, Marlin/src/gcode/bedlevel/abl/G29.cpp, Marlin/src/gcode/calibrate/G28.cpp, Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp

## 6. Konfigurationsmakros
- PROBE_MANUALLY: ['Configuration.h:1072: AUSKOMMENTIERT //#define PROBE_MANUALLY']
- AUTO_BED_LEVELING_BILINEAR: ['Configuration.h:1544: AKTIV #define AUTO_BED_LEVELING_BILINEAR']
- ENABLE_LEVELING_FADE_HEIGHT: ['Configuration.h:1581: AKTIV #define ENABLE_LEVELING_FADE_HEIGHT']
- EEPROM_SETTINGS: ['Configuration.h:1830: AKTIV #define EEPROM_SETTINGS     // Persistent storage with M500 and M501']
- EXTENSIBLE_UI: ['Configuration.h:2630: AUSKOMMENTIERT //#define EXTENSIBLE_UI']
- RTS_AVAILABLE: ['Configuration.h:2787: AKTIV #define RTS_AVAILABLE']
- DUAL_X_CARRIAGE: ['Configuration_adv.h:752: AKTIV #define DUAL_X_CARRIAGE']
- G29_RETRY_AND_RECOVER: ['Configuration_adv.h:1975: AUSKOMMENTIERT //#define G29_RETRY_AND_RECOVER']
- FULL_REPORT_TO_HOST_FEATURE: ['Configuration_adv.h:2233: AUSKOMMENTIERT //#define FULL_REPORT_TO_HOST_FEATURE   // Auto-report the machine status like Grbl CNC']

## 7. Marlin-Namen aus Bruecke und G29-Code im echten Quelltext
| Name | Dateien | Treffer | Header-Treffer (bis 3) |
|---|---|---|---|
| setTargetBed | 16 | 44 | src/module/temperature.h:747: static void setTargetBed(const celsius_t celsius) { |
| degBed | 5 | 14 | src/module/temperature.h:738: static inline celsius_float_t degBed()  { return temp_bed.celsius; } ; src/module/temperature.h:739: static inline celsius_t wholeDegBed()   { return static_cast<celsius_t>(degBed() ; src/module/temperature.h:745: static inline void start_watching_bed() { TERN_(WATCH_BED, watch_bed.restart(deg |
| degTargetBed | 26 | 47 | src/module/temperature.h:740: static inline celsius_t degTargetBed()  { return temp_bed.target; } ; src/module/temperature.h:745: static inline void start_watching_bed() { TERN_(WATCH_BED, watch_bed.restart(deg |
| enqueue_one_P | 5 | 6 | src/gcode/queue.h:148: static bool enqueue_one_P(PGM_P const pgcode); |
| enqueue_now_P | 13 | 111 | src/gcode/queue.h:153: static void enqueue_now_P(PGM_P const cmd); |
| has_commands_queued | 3 | 3 | src/gcode/queue.h:158: static bool has_commands_queued() { return ring_buffer.length || injected_commands_P || |
| has_blocks_queued | 10 | 37 | src/module/planner.h:881: FORCE_INLINE static bool has_blocks_queued() { return (block_buffer_head != block_bu ; src/module/planner.h:898: if (has_blocks_queued()) |
| leveling_active | 31 | 70 | src/module/planner.h:392: static bool leveling_active;          // Flag that bed leveling is enabled ; src/module/planner.h:400: static constexpr bool leveling_active = false; ; src/module/planner.h:652: leveling_active = true; |
| refresh_bed_level | 5 | 5 | src/feature/bedlevel/abl/abl.h:34: void refresh_bed_level(); |
| set_bed_leveling_enabled | 20 | 61 | src/feature/bedlevel/bedlevel.h:37: void set_bed_leveling_enabled(const bool enable=true); ; src/feature/bedlevel/bedlevel.h:56: ~TemporaryBedLevelingState() { set_bed_leveling_enabled(saved); } |
| z_values | 22 | 146 | src/feature/bedlevel/abl/abl.h:29: extern bed_mesh_t z_values; ; src/feature/bedlevel/abl/abl.h:46: #define Z_VALUES_ARR  z_values ; src/feature/bedlevel/ubl/ubl.h:115: static bed_mesh_t z_values; |
| bilinear_start | 6 | 18 | src/feature/bedlevel/abl/abl.h:27: extern xy_pos_t bilinear_grid_spacing, bilinear_start; ; src/feature/bedlevel/abl/abl.h:44: #define _GET_MESH_X(I) float(bilinear_start.x + (I) * bilinear_grid_spacing ; src/feature/bedlevel/abl/abl.h:45: #define _GET_MESH_Y(J) float(bilinear_start.y + (J) * bilinear_grid_spacing |
| bilinear_grid_spacing | 6 | 18 | src/feature/bedlevel/abl/abl.h:27: extern xy_pos_t bilinear_grid_spacing, bilinear_start; ; src/feature/bedlevel/abl/abl.h:44: #define _GET_MESH_X(I) float(bilinear_start.x + (I) * bilinear_grid_spacing ; src/feature/bedlevel/abl/abl.h:45: #define _GET_MESH_Y(J) float(bilinear_start.y + (J) * bilinear_grid_spacing |
| axis_is_trusted | 9 | 11 | src/module/motion.h:416: inline bool axis_is_trusted(const AxisEnum axis)      { return TEST(axis_trusted, axi |
| dual_x_carriage_mode | 9 | 26 | src/module/motion.h:579: extern DualXMode dual_x_carriage_mode; ; src/module/motion.h:588: FORCE_INLINE bool idex_is_duplicating() { return dual_x_carriage_mode >= DXC_DUPLICAT ; src/module/motion.h:589: FORCE_INLINE bool dxc_is_parked() { return dual_x_carriage_mode >= DXC_AUTO_PARK_MODE |
| DXC_AUTO_PARK_MODE | 4 | 9 | src/module/motion.h:574: DXC_AUTO_PARK_MODE, ; src/module/motion.h:589: FORCE_INLINE bool dxc_is_parked() { return dual_x_carriage_mode >= DXC_AUTO_PARK_MODE |
| inactive_extruder_x | 5 | 9 | src/module/motion.h:580: extern float inactive_extruder_x,                 // Used in mode 0 & 1 |
| X2_MAX_POS | 6 | 21 | src/module/motion.h:549: return COORDINATE_OKAY(rx, X2_MIN_POS - fslop, X2_MAX_POS + fslop); ; src/inc/SanityCheck.h:1945: #elif !defined(X2_HOME_POS) || !defined(X2_MIN_POS) || !defined(X2_MAX_POS) ; src/inc/SanityCheck.h:1946: #error "DUAL_X_CARRIAGE requires X2_HOME_POS, X2_MIN_POS, and X2_MAX_POS." |
| RTS_SndData | 9 | 506 | src/lcd/e3v2/creality/LCD_RTS.h:189: void RTS_SndData(void); ; src/lcd/e3v2/creality/LCD_RTS.h:190: void RTS_SndData(const String &, unsigned long, unsigned char = VarAddr_W ; src/lcd/e3v2/creality/LCD_RTS.h:191: void RTS_SndData(const char[], unsigned long, unsigned char = VarAddr_W); |
| RTS_AutoBedLevelPage | 3 | 3 | src/lcd/e3v2/creality/LCD_RTS.h:304: void RTS_AutoBedLevelPage(); |
| printJobOngoing | 5 | 8 | src/MarlinCore.h:60: bool printJobOngoing(); |
| printingIsPaused | 11 | 21 | src/MarlinCore.h:61: bool printingIsPaused(); |
| IsStopped | 4 | 4 | src/MarlinCore.h:57: inline bool IsStopped() { return marlin_state == MF_STOPPED; } |
| active_extruder | 66 | 367 | src/feature/powerloss.h:74: uint8_t active_extruder; ; src/feature/runout.h:136: const bool ran_out = TEST(runout_flags, active_extruder);  // suppress non active ex ; src/feature/runout.h:137: uint8_t extruder = active_extruder; |
| millis | 93 | 298 | src/feature/binary_stream.h:138: const millis_t ms = millis(); ; src/feature/binary_stream.h:146: transfer_timeout = millis() + TIMEOUT; ; src/feature/binary_stream.h:248: timeout = millis() + PACKET_MAX_WAIT; |
| AUTO_BED_LEVEL_1POINT_VP | 3 | 4 | src/lcd/e3v2/creality/LCD_RTS.h:72: #define AUTO_BED_LEVEL_1POINT_VP           0x1100 |
