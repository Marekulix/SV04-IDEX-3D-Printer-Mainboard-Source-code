# Erreichbarkeitsanalyse (overlay)
Funktionen 1084, direkte Kanten 3046, nm-Symbole 1636. **ALLE Erwartungen erfuellt**

| Pruefung | Erwartung | Ergebnis | Treffer |
|---|---|---|---|
| G29 vorhanden | present | OK | 2: GcodeSuite::G29(), GcodeSuite::G29()::SV04NextMeshRollback::revert() |
| RTSUpdate vorhanden | present | OK | 1: RTSUpdate() |
| G29-U-Beleg (Objekt) gelinkt | present | OK | 1: sv04next::g29u_receipt |
| Thermotor (Objekt) gelinkt | present | OK | 1: sv04next::native_thermal_gate |
| T1-Endstop-Beobachter (Objekt) gelinkt | present | OK | 1: sv04next::t1_endstop_observer |
| Auto60-Maschine NICHT im Standard-Overlay | absent | OK | 0:  |
| Auto60 tick NICHT im Standard-Overlay | absent | OK | 0:  |
| kein Startpfad der Maschine (request_start) | absent | OK | 0:  |

Grenzen: nur direkte Sprung-/Aufrufkanten; indirekte Aufrufe, Funktionszeiger, Literal-Pool-Adressen werden nicht verfolgt; Inlining kann Symbole verbergen
