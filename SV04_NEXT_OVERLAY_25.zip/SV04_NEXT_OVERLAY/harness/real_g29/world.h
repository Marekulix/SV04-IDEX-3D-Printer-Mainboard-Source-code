// WELT fuer die AUSFUEHRUNG des ECHTEN, GEPATCHTEN G29.cpp (bilinearer Zweig). Nachbildung, KEIN Marlin: Typen, Funktionen und ein Fake-Geraet (Sonde, Temperatur, Zeit).
#pragma once
#include <deque>
#include <string>
#include <vector>
#include <functional>
#include <map>
#include <string.h>
#include <stdlib.h>
#define GRID_MAX_POINTS (GRID_MAX_POINTS_X * GRID_MAX_POINTS_Y)
#define G29_TYPE void
#define STRINGIFY(x) #x
#define WITHIN(N, L, H) ((N) >= (L) && (N) <= (H))
#define LIMIT(v, n, x) ((v) = (v) < (n) ? (n) : ((v) > (x) ? (x) : (v)))
#define _MAX(a, b) ((a) > (b) ? (a) : (b))
#define MMM_TO_MMS(x) ((x) / 60.0f)
#define XY_PROBE_FEEDRATE 4000
#define X_CENTER 151.0f
#define Y_CENTER 151.0f
#define Z_CLEARANCE_DEPLOY_PROBE 10
#define RAW_X_POSITION(v) (v)
#define RAW_Y_POSITION(v) (v)
#define RAW_Z_POSITION(v) (v)
#define G28_STR "G28"
#define DEBUGGING(x) (false)
#define DEBUG_SECTION(...) do {} while (0)
#define DEBUG_ECHOLNPGM(...) do {} while (0)
#define DEBUG_ECHOPGM(...) do {} while (0)
#define DEBUG_ECHOLNPGM_P(...) do {} while (0)
#define DEBUG_POS(...) do {} while (0)
#define SERIAL_ECHOPGM(...) do {} while (0)
#define SERIAL_EOL() do {} while (0)
struct xy_float_t { float x, y; xy_float_t() : x(0), y(0) {} xy_float_t(float a, float b) : x(a), y(b) {} void set(float a, float b) { x = a; y = b; } };
typedef xy_float_t xy_pos_t;
inline bool operator!=(const xy_float_t &a, const xy_float_t &b) { return a.x != b.x || a.y != b.y; }
inline bool operator==(const xy_float_t &a, const xy_float_t &b) { return !(a != b); }
inline xy_float_t operator*(const xy_float_t &a, const xy_float_t &b) { return xy_float_t(a.x * b.x, a.y * b.y); }
inline xy_float_t operator+(const xy_float_t &a, const xy_float_t &b) { return xy_float_t(a.x + b.x, a.y + b.y); }
struct xy_int8_t { int8_t x, y; xy_float_t asFloat() const { return xy_float_t((float)x, (float)y); } };
struct xy_uint8_t { uint8_t x, y; };
struct xyz_pos_t { float x, y, z; };
struct xyze_pos_t { float x, y, z, e; void set(float a, float b) { x = a; y = b; } };
extern xyze_pos_t current_position;
enum ProbePtRaise : uint8_t { PROBE_PT_NONE, PROBE_PT_STOW, PROBE_PT_RAISE, PROBE_PT_BIG_RAISE };
enum DualXMode : char { DXC_FULL_CONTROL_MODE = 0, DXC_AUTO_PARK_MODE = 1, DXC_DUPLICATION_MODE = 2, DXC_MIRRORED_MODE = 3 };
typedef float bed_mesh_t[GRID_MAX_POINTS_X][GRID_MAX_POINTS_Y];
// ---------------------------------------------------------------- Fake-Geraet
struct World {
  std::string parser_letters; bool stopped = false, printing = false, paused = false, blocks = false, homing_needed = false; bool trusted[3] = {true, true, true};
  int target = 60; float bed = 60.0f; uint32_t now_ms = 100000; int sync_calls = 0, probe_calls = 0, eeprom_saves = 0, levelling_toggles = 0, refresh_calls = 0, reset_calls = 0, rts_sends = 0, rts_pages = 0, rts_icon_zero = 0, progress_msgs = 0, restore_msgs = 0, errors = 0, idle_calls = 0;
  float rts_vals[16]; int rts_seen = 0; std::vector<std::string> log; std::vector<float> probe_script; std::vector<xy_pos_t> call_pos;
  std::function<void(int)> before_probe, on_progress; float g29_z_param = 0; std::map<int, float> ovr; bool xmax_triggered = true;   // Stand 16: elektrischer Pegel des X_MAX-Schalters von T1 (gedrueckt = geparkt)
};
extern World w;
#define X_MAX_PIN 1
#define X_MAX_ENDSTOP_INVERTING true
#define READ(p) ((w.xmax_triggered) != (X_MAX_ENDSTOP_INVERTING))   // roher Pin-Pegel; Overlay vergleicht mit X_MAX_ENDSTOP_INVERTING
extern uint8_t active_extruder; extern DualXMode dual_x_carriage_mode; extern float inactive_extruder_x;
extern bed_mesh_t z_values; extern xy_pos_t bilinear_start, bilinear_grid_spacing; extern float xy_probe_feedrate_mm_s;
unsigned long millis(void); inline long random(long a, long) { return a; }
inline bool axis_is_trusted(const AxisEnum a) { return w.trusted[a]; }
#define X2_MAX_POS 362
#define X_MAX_POS 302   // Configuration.h: X_MAX_POS = X_BED_SIZE = 302
inline bool IsStopped() { return w.stopped; } inline bool printJobOngoing() { return w.printing; } inline bool printingIsPaused() { return w.paused; }
struct Temperature { static celsius_float_t degBed() { return w.bed; } static celsius_t degTargetBed() { return (celsius_t)w.target; } static void setTargetBed(const celsius_t c) { w.target = c; } }; extern Temperature thermalManager;
// echte Fade-Formel (planner.h 584-598): kein Fade bei z_fade_height 0 -> 1; ab z_fade_height -> 0; sonst 1 - z/z_fade_height. DEFAULT_LEVELING_FADE_HEIGHT = 1.0 mm (Configuration.h 1583).
struct Planner { static bool leveling_active; static float z_fade_height; static bool has_blocks_queued() { return w.blocks; } static void synchronize() {}
  static float fade_scaling_factor_for_z(float rz) { if (!z_fade_height) return 1; if (rz >= z_fade_height) return 0; return 1 - rz * (1.0f / z_fade_height); } }; extern Planner planner;
struct Probe { static xyz_pos_t offset; static float probe_at_point(const xy_pos_t &pos, const ProbePtRaise raise_after = PROBE_PT_NONE, const uint8_t verbose_level = 0, const bool probe_relative = true, const bool sanity_check = true);
  static float min_x() { return 25; } static float max_x() { return 277; } static float min_y() { return 25; } static float max_y() { return 277; } static bool good_bounds(const xy_pos_t &, const xy_pos_t &) { return true; } static bool deploy() { return false; } static bool stow() { return false; } static void move_z_after_probing() {} }; extern Probe probe;
struct GCodeParser { static bool seen_test(const char c) { return w.parser_letters.find(c) != std::string::npos; } static bool seen(const char c) { return seen_test(c); } static bool boolval(const char c, const bool d = false) { return seen_test(c) ? true : d; }
  static int intval(const char, const int d = 0) { return d; } static uint8_t byteval(const char, const uint8_t d = 0) { return d; } static bool seenval(const char) { return false; } static float linearval(const char c, const float d = 0) { return c == 'Z' ? w.g29_z_param : d; } static float value_linear_units() { return 0; } static int value_int() { return 0; } }; extern GCodeParser parser;
struct RTSSHOW { void RTS_SndData(float v, unsigned long vp, unsigned char = 0x82) { ++w.rts_sends; if (vp == 0x108D && v == 0) ++w.rts_icon_zero; long i = ((long)vp - 0x1100) / 2; if (vp >= 0x1100 && i >= 0 && i < 16) { w.rts_vals[i] = v; ++w.rts_seen; } }
  void RTS_SndData(int v, unsigned long vp, unsigned char b = 0x82) { RTS_SndData((float)v, vp, b); } void RTS_SndData(unsigned long v, unsigned long vp, unsigned char b = 0x82) { RTS_SndData((float)v, vp, b); } void RTS_SndData(unsigned char v, unsigned long vp, unsigned char b = 0x82) { RTS_SndData((float)v, vp, b); } }; extern RTSSHOW rtscheck;
#define AUTO_BED_LEVEL_ICON_VP 0x108D
#define AUTO_BED_LEVEL_1POINT_VP 0x1100
inline void RTS_AutoBedLevelPage() { ++w.rts_pages; }
inline void extrapolate_unprobed_bed_level() {} inline void print_bilinear_leveling_grid() {}
// ECHTE bilinear_z_offset (abl.cpp 268-345) MIT statischem Zwischenspeicher; EXTRAPOLATE_BEYOND_GRID aktiv (Configuration.h 1621) -> FAR_EDGE_OR_BOX = 2, Verhaeltnis wird nicht begrenzt; ABL_BILINEAR_SUBDIVISION aus.
// Der Cache haelt Zellindex und Eckwerte (z1..d4) und wird NUR bei geaenderter Zelle neu geladen; refresh_bed_level() invalidiert ihn NICHT.
struct BilinearCache { float z1, d2, z3, d4, L, D; xy_pos_t prev, ratio; int thisgx, thisgy, nextgx, nextgy, lastgx, lastgy; void reset() { z1 = d2 = z3 = d4 = L = D = 0; prev.set(-999.999f, -999.999f); ratio.set(0, 0); thisgx = thisgy = nextgx = nextgy = 0; lastgx = lastgy = -99; } }; extern BilinearCache bcache; extern xy_pos_t bilinear_grid_factor;
// float->int von NAN ergibt auf ARM 0 (hier per isnan nachgebildet)
inline float bilinear_z_offset(const xyze_pos_t &raw) {
  BilinearCache &c = bcache; const float relx = raw.x - bilinear_start.x, rely = raw.y - bilinear_start.y; const int PX = GRID_MAX_POINTS_X, PY = GRID_MAX_POINTS_Y;
  if (c.prev.x != relx) { c.prev.x = relx; c.ratio.x = relx * bilinear_grid_factor.x; float gx = floorf(c.ratio.x); if (gx < 0) gx = 0; if (gx > PX - 2) gx = PX - 2; c.ratio.x -= gx; c.thisgx = std::isnan(gx) ? 0 : (int)gx; c.nextgx = (c.thisgx + 1 < PX - 1) ? c.thisgx + 1 : PX - 1; }
  if (c.prev.y != rely || c.lastgx != c.thisgx) {
    if (c.prev.y != rely) { c.prev.y = rely; c.ratio.y = rely * bilinear_grid_factor.y; float gy = floorf(c.ratio.y); if (gy < 0) gy = 0; if (gy > PY - 2) gy = PY - 2; c.ratio.y -= gy; c.thisgy = std::isnan(gy) ? 0 : (int)gy; c.nextgy = (c.thisgy + 1 < PY - 1) ? c.thisgy + 1 : PY - 1; }
    if (c.lastgx != c.thisgx || c.lastgy != c.thisgy) { c.lastgx = c.thisgx; c.lastgy = c.thisgy; c.z1 = z_values[c.thisgx][c.thisgy]; c.d2 = z_values[c.thisgx][c.nextgy] - c.z1; c.z3 = z_values[c.nextgx][c.thisgy]; c.d4 = z_values[c.nextgx][c.nextgy] - c.z3; }
    const float L = c.z1 + c.d2 * c.ratio.y, R = c.z3 + c.d4 * c.ratio.y; c.L = L; c.D = R - L;
  }
  return c.L + c.ratio.x * c.D;
}
inline float bilinear_z_offset(const xy_pos_t &p) { xyze_pos_t q; q.x = p.x; q.y = p.y; q.z = 0; q.e = 0; return bilinear_z_offset(q); }   // echte Signatur: const xy_pos_t &
// reine, ungecachte Berechnung (Referenz fuer Kohaerenzpruefungen)
inline float bilinear_z_offset_uncached(const xyze_pos_t &raw) { BilinearCache save = bcache; bcache.reset(); const float v = bilinear_z_offset(raw); bcache = save; return v; }
// --- Semantik wie im ECHTEN bedlevel.cpp (Zeilen 49 bis 121, 123 bis 139): leveling_is_valid() = !!bilinear_grid_spacing.x; set_bed_leveling_enabled(true) tut OHNE gueltiges Raster NICHTS;
// reset_bed_level() schaltet das Leveling aus, setzt Raster-Start und -Abstand auf 0 und das Mesh auf NAN.
inline bool leveling_is_valid() { return !!bilinear_grid_spacing.x; }
inline void set_bed_leveling_enabled(const bool e = true) { const bool can_change = !e || leveling_is_valid(); if (can_change && e != Planner::leveling_active) {
    if (Planner::leveling_active) { const float f = Planner::fade_scaling_factor_for_z(current_position.z); current_position.z += f ? f * bilinear_z_offset(current_position) : 0.0f; Planner::leveling_active = false; }   // an -> aus: apply_leveling (planner.cpp 1567-1596), danach erst deaktivieren
    else { Planner::leveling_active = true; const float f = Planner::fade_scaling_factor_for_z(current_position.z); current_position.z -= f ? f * bilinear_z_offset(current_position) : 0.0f; }                          // aus -> an: erst aktivieren, dann unapply_leveling (planner.cpp 1597-1630) mit dem AKTUELLEN Mesh; Faktor aus der PHYSISCHEN Hoehe
    ++w.levelling_toggles; ++w.sync_calls; } }
inline void reset_bed_level() { ++w.reset_calls; set_bed_leveling_enabled(false); bilinear_start.set(0, 0); bilinear_grid_spacing.set(0, 0); for (int x = 0; x < GRID_MAX_POINTS_X; ++x) for (int y = 0; y < GRID_MAX_POINTS_Y; ++y) z_values[x][y] = NAN; }
inline void refresh_bed_level() { ++w.refresh_calls; bilinear_grid_factor.set(bilinear_grid_spacing.x ? 1.0f / bilinear_grid_spacing.x : 0.0f, bilinear_grid_spacing.y ? 1.0f / bilinear_grid_spacing.y : 0.0f); }   // echt: _RECIP (types.h 159) liefert 0 bei 0; echt (abl.cpp 248-251): nur der Faktor; der Cache von bilinear_z_offset bleibt
inline void sync_plan_position() {} inline void report_current_position() {} inline bool homing_needed_error() { return w.homing_needed; } inline void do_z_clearance(float) {} inline void tool_change(uint8_t, bool = false) {}
inline void remember_feedrate_scaling_off() {} inline void restore_feedrate_and_scaling() {} inline void reset_stepper_timeout() {} inline void process_subcommands_now_P(const char *) {} 
inline void idle_no_sleep() { w.now_ms += 20; ++w.idle_calls; }
inline void sv_log(const char *m) { w.log.push_back(m); ++w.errors; }
#define SERIAL_ERROR_MSG(m) do { sv_log(m); if (strstr(m, "restored")) ++w.restore_msgs; } while (0)
template <class... A> void sv_echo(const char *m, A...) { w.log.push_back(m); if (strstr(m, "PROGRESS")) { ++w.progress_msgs; if (w.on_progress) w.on_progress(w.progress_msgs - 1); } }
#undef SERIAL_ECHOLNPGM
#define SERIAL_ECHOLNPGM(...) sv_echo(__VA_ARGS__)
constexpr bool g29_in_progress = false;   // wie im echten bedlevel.h ohne PROBE_MANUALLY
class GcodeSuite { public: static void G28(); static G29_TYPE G29(); };
