#!/usr/bin/env python3
"""Mutationskampagne gegen den ECHTEN gepatchten G29.cpp, geprueft vom Real-G29-Harness. Die Mutanten stammen aus harness/mutate_g29.py (gleicher eingefuegter Code)."""
import ast, os, subprocess, sys, tempfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
HERE = Path(__file__).resolve().parent; sys.path.insert(0, str(HERE)); import run_real_g29 as RR
src = (HERE / 'mutate_g29.py').read_text(encoding='utf-8'); tree = ast.parse(src); M = None
for node in tree.body:
    if isinstance(node, ast.Assign) and getattr(node.targets[0], 'id', '') == 'M': M = ast.literal_eval(node.value)
base = Path(tempfile.mkdtemp()); RR.build_tree(base); orig = (base / 'patched' / RR.G29).read_text(encoding='utf-8')
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'integration'))
import apply_native_guard_v17 as _V17
NREV = _V17.N_REVERT   # Stand 18: Cache-Invalidierung zwischen refresh_bed_level() und der Reaktivierung
EXTRA = [('X01', 'Rollback VERSCHIEBT das Wiedereinschalten des Levelings VOR das Zurueckschreiben des Rasters (echte Semantik: set_bed_leveling_enabled(true) tut ohne gueltiges Raster nichts)',
          "        set_bed_leveling_enabled(false);\n        memcpy(z_values, old_values, sizeof(old_values));\n        bilinear_start = old_start;\n        bilinear_grid_spacing = old_spacing;\n        probe.offset.z = old_probe_offset;\n        refresh_bed_level();\n" + NREV + "        set_bed_leveling_enabled(old_active);",
          "        set_bed_leveling_enabled(false);\n        set_bed_leveling_enabled(old_active);\n        memcpy(z_values, old_values, sizeof(old_values));\n        bilinear_start = old_start;\n        bilinear_grid_spacing = old_spacing;\n        probe.offset.z = old_probe_offset;\n        refresh_bed_level();\n" + NREV),
         ('X02', 'Rollback schaltet das Leveling gar nicht wieder ein', "        refresh_bed_level();\n" + NREV + "        set_bed_leveling_enabled(old_active);", "        refresh_bed_level();\n" + NREV),
         ('X03', 'Rollback schaltet das Leveling IMMER ein (auch wenn es vorher aus war)', "        set_bed_leveling_enabled(old_active);\n        // OEM G29 sends", "        set_bed_leveling_enabled(true);\n        // OEM G29 sends")]
M = list(M) + [(a, b, c, d) for a, b, c, d in EXTRA]
def mutated(mid, old, new):
    if mid == 'M29': return orig.replace('~SV04NextMeshRollback() { revert(); }', '~SV04NextMeshRollback() { }').replace('        sv04next::g29u_receipt.fail();\n        sv04_mesh_guard.revert();', '        sv04next::g29u_receipt.fail();')
    if mid == 'M30': return orig.replace('ABS(z) > 3.0f', 'ABS(z) > 30.0f')
    return orig.replace(old, new) if orig.count(old) == 1 else None
def one(item):
    mid, why, old, new = item; t = mutated(mid, old, new)
    if t is None or t == orig: return (mid, why, 'UNGUELTIG', '')
    w = Path(tempfile.mkdtemp()); RR.build_tree(w)
    if mid == 'M30': h = w / 'patched/Marlin/src/feature/sv04_next/SV04NextG29UReceipt.hpp'; h.write_text(h.read_text(encoding='utf-8').replace('MaxAbsZmm = 3.0f', 'MaxAbsZmm = 30.0f'), encoding='utf-8')
    r = RR.build(w, t, 'real_mut')
    if r.returncode: return (mid, why, 'INVALID', 'Compilefehler')
    p = subprocess.run([str(w / 'real_mut')], capture_output=True, text=True, timeout=120); fl = [l[6:70].strip() for l in p.stdout.splitlines() if l.startswith('FAIL')]
    return (mid, why, 'killed' if p.returncode else 'SURVIVED', f'{len(fl)} Pruefungen, z. B. {fl[0]}' if fl else '')
if len(sys.argv) > 1: M = [x for x in M if x[0].startswith(sys.argv[1])]   # optional: nur Mutanten mit diesem Praefix (z. B. X)
with ThreadPoolExecutor(max_workers=2) as ex: res = list(ex.map(one, M))
for mid, why, st, info in res: print(f'{mid} {st:9} {why}' + (f'  <- {info}' if info else ''))
k = sum(r[2] == 'killed' for r in res); s = [r[0] for r in res if r[2] == 'SURVIVED']; bad = [r[0] for r in res if r[2] in ('UNGUELTIG', 'INVALID')]
print(f'--- erkannt {k}, UEBERLEBT {len(s)}: {s}, ungueltig {len(bad)} {bad} von {len(res)}')
