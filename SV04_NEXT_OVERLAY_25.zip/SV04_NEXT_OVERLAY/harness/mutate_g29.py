#!/usr/bin/env python3
"""Mutationskampagne auf dem vom Overlay ERZEUGTEN G29.cpp: gezielte Fehler einbauen, Harness neu übersetzen und ausführen. killed / SURVIVED / INVALID."""
import os, shutil, subprocess, sys, tempfile
from pathlib import Path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); import run_harness as RH
G = RH.G29; BASE = RH.build_tree(Path(tempfile.mkdtemp())); orig = (BASE / G).read_text(encoding='utf-8')
M = [
 ('M01', 'accept() entfernt (Erfolg wird zurückgerollt)', "sv04_mesh_guard.accept();\n        SERIAL_ECHOLNPGM(\"SV04 NEXT: G29 U 16/16 OK", "SERIAL_ECHOLNPGM(\"SV04 NEXT: G29 U 16/16 OK"),
 ('M02', '16 Punkte nicht mehr verlangt (>= 15)', "sv04_measured_points == 16 &&", "sv04_measured_points >= 15 &&"),
 ('M03', 'Plausibilität 30 mm statt 3 mm', "ABS(z) > 3.0f", "ABS(z) > 30.0f"),
 ('M04', 'Zwei-Antastungs-Toleranz 0,6 statt 0,06 mm', "ABS(first_z - second_z) > 0.06f", "ABS(first_z - second_z) > 0.6f"),
 ('M05', 'Prüfung vor jedem Punkt: Werkzeug/DXC entfernt', "                 active_extruder != 0 ||\n                 dual_x_carriage_mode != DXC_AUTO_PARK_MODE ||\n", "                 false ||\n"),
 ('M06', 'Prüfung vor jedem Punkt: Z-Offset entfernt', "                 ABS(probe.offset.z - sv04_mesh_guard.old_probe_offset) > 0.00001f ||\n", ""),
 ('M07', 'Prüfung vor jedem Punkt: Druck/Stopp entfernt', "            if (sv04_transactional_run &&\n                (IsStopped() || printJobOngoing() || printingIsPaused() ||\n                 !isfinite(thermalManager.degBed()) ||", "            if (sv04_transactional_run &&\n                (false ||\n                 !isfinite(thermalManager.degBed()) ||"),
 ('M08', 'Abschlussprüfung (Druck/Stopp/IDEX/Vertrauen) entfernt', "if (sv04_good && (IsStopped() || printJobOngoing() || printingIsPaused() ||", "if (false && (IsStopped() || printJobOngoing() || printingIsPaused() ||"),
 ('M09', 'finish_ram_only() nicht mehr verlangt', "if (sv04_good && !sv04next::g29u_receipt.finish_ram_only())", "if (false)"),
 ('M10', 'VisitProof.complete() nicht mehr verlangt', "sv04_visit_proof.complete() &&", "true &&"),
 ('M11', 'Rollback: z_values nicht zurückgeschrieben', "        memcpy(z_values, old_values, sizeof(old_values));\n", ""),
 ('M12', 'Rollback: Z-Offset nicht zurückgesetzt', "        probe.offset.z = old_probe_offset;\n", ""),
 ('M13', 'Rollback: Leveling-Zustand nicht wiederhergestellt', "        set_bed_leveling_enabled(old_active);\n", ""),
 ('M14', 'Rollback: refresh_bed_level() entfernt', "        refresh_bed_level();\n        // Stand 18: bilinear_z_offset() cached", "        // Stand 18: bilinear_z_offset() cached"),
 ('M15', 'Rollback: Gitterstart nicht zurückgesetzt', "        bilinear_start = old_start;\n", ""),
 ('M16', 'Rollback: Anzeige (RTS) nicht neu gezeichnet', "                rtscheck.RTS_SndData(isfinite(z_values[x][y]) ? z_values[x][y] * 1000 : 0,\n                                     AUTO_BED_LEVEL_1POINT_VP + (index++) * 2);\n            }\n            else {", "                (void)index;\n            }\n            else {"),
 ('M17', 'Vorab: Bett-Fenster 10 C statt 1 C', "ABS(bed_c - 60.0f) > 1.0f", "ABS(bed_c - 60.0f) > 10.0f"),
 ('M18', 'Vorab: Soll-Temperatur nicht geprüft', "thermalManager.degTargetBed() != 60 || !isfinite(probe.offset.z)) {\n        sv04next::g29u_receipt.refuse(sv04next::G29UReceipt::Failure::Temperature);", "false || !isfinite(probe.offset.z)) {\n        sv04next::g29u_receipt.refuse(sv04next::G29UReceipt::Failure::Temperature);"),
 ('M19', 'Vorab: Warteschlange nicht geprüft', "printingIsPaused() || planner.has_blocks_queued())", "printingIsPaused())"),
 ('M20', 'Vorab: Thermotor ready() ignoriert', "!sv04next::native_thermal_gate.ready((uint32_t)millis())", "false"),
 ('M21', 'Vorab: X2-Position nicht geprüft', "          ABS(inactive_extruder_x - X2_MAX_POS) > 1.0f) {\n        sv04next::g29u_receipt.refuse(sv04next::G29UReceipt::Failure::UnsafeIDEX);", "          false) {\n        sv04next::g29u_receipt.refuse(sv04next::G29UReceipt::Failure::UnsafeIDEX);"),
 ('M22', 'Vorab: Wiedereintritt nicht geprüft', "    if (sv04_transactional_run && sv04_next_g29_u_active) {\n      sv04next::g29u_receipt.refuse(sv04next::G29UReceipt::Failure::Reentry);", "    if (false) {\n      sv04next::g29u_receipt.refuse(sv04next::G29UReceipt::Failure::Reentry);"),
 ('M23', 'Lauf-Flag wird nicht zurückgesetzt', "~SV04NextScopedProbeMode() { sv04_next_g29_u_active = prior; }", "~SV04NextScopedProbeMode() { }"),
 ('M24', 'Temperaturprüfung nach der Antastung entfernt', "                !sv04next::NativeThermalGate::live_sample_safe(\n                  thermalManager.degBed(), (float)thermalManager.degTargetBed())) {\n              sv04next::g29u_receipt.fail(sv04next::G29UReceipt::Failure::Temperature);", "                false) {\n              sv04next::g29u_receipt.fail(sv04next::G29UReceipt::Failure::Temperature);"),
 ('M25', 'Rollback nur noch ausdrücklich (Destruktor leer)', "~SV04NextMeshRollback() { revert(); }", "~SV04NextMeshRollback() { }"),
 ('M26', 'ausdrücklicher Rollback im Fehlerzweig entfernt', "        sv04next::g29u_receipt.fail();\n        sv04_mesh_guard.revert();", "        sv04next::g29u_receipt.fail();"),
 ('M27', 'Erster Probenfehler (NaN) wird nicht zum Abbruch', "if (!isfinite(first_z)) abl.measured_z = NAN;\n            else {", "if (!isfinite(first_z)) abl.measured_z = 1.0f;\n            else {"),
 ('M29', 'BEIDE Rollbackpfade entfernt (Destruktor und ausdrücklich)', None, None),
 ('M30', 'Plausibilitätsgrenze 3 mm in G29.cpp UND im Receipt entfernt', None, None),
 ('M28', 'Guard schon für normalen G29 scharf', "} sv04_mesh_guard(sv04_transactional_run);", "} sv04_mesh_guard(true);"),
]
work = tempfile.mkdtemp(); shutil.copytree(BASE / 'Marlin', work + '/Marlin'); shutil.copy(BASE / 'driver.cpp', work)
res = {}
for mid, why, old, new in M:
    if mid == 'M30':
        t = orig.replace('ABS(z) > 3.0f', 'ABS(z) > 30.0f'); assert t != orig; old, new = orig, t
    if mid == 'M29':
        t = orig.replace("~SV04NextMeshRollback() { revert(); }", "~SV04NextMeshRollback() { }").replace("        sv04next::g29u_receipt.fail();\n        sv04_mesh_guard.revert();", "        sv04next::g29u_receipt.fail();"); assert t != orig; old, new = orig, t
    if orig.count(old) != 1 and mid not in ('M29', 'M30'): print(f'{mid} UNGÜLTIG ({orig.count(old)} Fundstellen): {why}'); res[mid] = 'BAD'; continue
    open(os.path.join(work, G), 'w', encoding='utf-8').write(new if mid in ('M29', 'M30') else orig.replace(old, new))
    hdr = os.path.join(work, 'Marlin/src/feature/sv04_next/SV04NextG29UReceipt.hpp'); h0 = open(hdr, encoding='utf-8').read()
    open(hdr, 'w', encoding='utf-8').write(h0.replace('MaxAbsZmm = 3.0f', 'MaxAbsZmm = 30.0f') if mid == 'M30' else h0)
    c = subprocess.run(['g++', '-std=gnu++14', '-O0', '-w', '-I.', 'driver.cpp', G, '-o', 'h_mut'], cwd=work, capture_output=True, text=True)
    if c.returncode: print(f'{mid} INVALID (Compilefehler)  {why}'); res[mid] = 'INVALID'; continue
    r = subprocess.run(['./h_mut'], cwd=work, capture_output=True, text=True, timeout=60); fails = [l.split('  ')[1].strip()[:44] for l in r.stdout.splitlines() if l.startswith('FAIL')]
    res[mid] = 'killed' if r.returncode else 'SURVIVED'; print(f'{mid} {res[mid]:9} {why}' + (f'  <- {len(fails)} Szenarien, z. B. {fails[0]}' if fails else ''), flush=True)
k = sum(v == 'killed' for v in res.values()); s = [m for m, v in res.items() if v == 'SURVIVED']; print(f'--- erkannt {k}, ÜBERLEBT {len(s)}: {s}, ungültig {sum(v in ("BAD", "INVALID") for v in res.values())} von {len(res)}')
