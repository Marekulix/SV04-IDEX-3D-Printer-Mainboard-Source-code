#!/usr/bin/env python3
"""SV04 NEXT 11.33-11.52: native G29 U diagnostics with lifecycle receipt.

Adds a read-only per-run status registry on top of v6. This does NOT add a
DWIN HMI button, physical X2 parking proof, heater movement, or EEPROM writes.
Normal G29 and OEM probe.cpp/Configuration.h remain unchanged. Do not flash.
"""
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path
import apply_native_guard_v6 as previous

OEM_BLOBS=previous.OEM_BLOBS
PatchRefused=previous.PatchRefused
replace_one=previous.replace_one
THERMAL_TARGET=previous.THERMAL_TARGET
VISIT_TARGET=previous.VISIT_TARGET
RECEIPT_TARGET='Marlin/src/feature/sv04_next/SV04NextG29UReceipt.hpp'
G29='Marlin/src/gcode/bedlevel/abl/G29.cpp'


def render(original:dict[str,str],thermal_header:str,visit_header:str,receipt_header:str)->dict[str,str]:
    if not receipt_header.startswith('// SV04 NEXT 11.33-11.52: G29 U native result receipt (READ ONLY).'):
        raise PatchRefused('receipt header provenance mismatch')
    required=('enum class Phase', 'RamOnlySuccess', 'eeprom_authorized() const { return false; }',
              'hardware_verified() const { return false; }', 'class Scope final', 'point(uint8_t x, uint8_t y, float z)')
    if not all(x in receipt_header for x in required):
        raise PatchRefused('receipt header missing safety contract')
    out=previous.render(original,thermal_header,visit_header)
    code=out[G29]
    code=replace_one(code,
        '#include "../../../feature/sv04_next/SV04NextVisitProof.hpp"',
        '#include "../../../feature/sv04_next/SV04NextVisitProof.hpp"\n'
        '  #include "../../../feature/sv04_next/SV04NextG29UReceipt.hpp"',G29)
    code=replace_one(code,
        '  bool sv04_next_g29_u_active = false;',
        '  bool sv04_next_g29_u_active = false;\n'
        '  namespace sv04next { G29UReceipt g29u_receipt; }',G29)
    # All early exits, even if forgotten by new preflight branches later, leave
    # a definite failure status due to the RAII Scope destructor.
    code=replace_one(code,
        'G29_TYPE GcodeSuite::G29() {',
        '''G29_TYPE GcodeSuite::G29() {
  #if ENABLED(AUTO_BED_LEVELING_BILINEAR) && DISABLED(PROBE_MANUALLY)
    const bool sv04_receipt_requested = parser.seen_test('U');
    sv04next::G29UReceipt::Scope sv04_receipt_scope(sv04_receipt_requested, sv04next::g29u_receipt);
    if (sv04_receipt_requested && !sv04_receipt_scope.armed()) {
      SERIAL_ERROR_MSG("SV04 NEXT G29U REFUSED: a transaction is already running");
      G29_RETURN(true);
    }
  #endif''',G29)
    # Under the existing v6 G29 branch, the native VisitProof already rejects
    # duplicate/out-of-bounds XY before movement. The receipt records only AFTER
    # the mesh value is accepted for that point; never mark attempts as success.
    before='''            z_values[abl.meshCount.x][abl.meshCount.y] = z;
            #if ENABLED(AUTO_BED_LEVELING_BILINEAR) && DISABLED(PROBE_MANUALLY)
              if (sv04_transactional_run) {'''
    after='''            z_values[abl.meshCount.x][abl.meshCount.y] = z;
            #if ENABLED(AUTO_BED_LEVELING_BILINEAR) && DISABLED(PROBE_MANUALLY)
              if (sv04_transactional_run &&
                  !sv04next::g29u_receipt.point(abl.meshCount.x, abl.meshCount.y, z)) {
                SERIAL_ERROR_MSG("SV04 NEXT G29U ABORT: receipt could not accept point");
                abl.measured_z = NAN;
                break;
              }
              if (sv04_transactional_run) {'''
    code=replace_one(code,before,after,G29)
    # A ram success is accepted ONLY when all 16 point receipts have been
    # registered, so an in-progress or partial run cannot be reported as OK.
    before='''      if (sv04_good) {
        sv04_mesh_guard.accept();
        SERIAL_ECHOLNPGM("SV04 NEXT: G29 U 16/16 OK, RAM mesh only");
      }'''
    after='''      if (sv04_good && !sv04next::g29u_receipt.finish_ram_only())
        sv04_good = false;
      if (sv04_good) {
        sv04_mesh_guard.accept();
        SERIAL_ECHOLNPGM("SV04 NEXT: G29 U 16/16 OK, RAM mesh only");
      }'''
    code=replace_one(code,before,after,G29)
    code=replace_one(code,
        '''      else {
        sv04_mesh_guard.revert();
        abl.measured_z = NAN;
      }''',
        '''      else {
        sv04next::g29u_receipt.fail();
        sv04_mesh_guard.revert();
        abl.measured_z = NAN;
      }''',G29)
    # Explicit refusal receipts for recognizable preflight outcomes.
    for marker,kind in (
      ('SV04 NEXT G29U REFUSED: modifiers not allowed','Preconditions'),
      ('SV04 NEXT G29U REFUSED: bed not stable for 20s','Temperature'),
      ('SV04 NEXT G29U REFUSED: no native DWIN temperature monitor','Preconditions'),
      ('SV04 NEXT G29U REFUSED: unsupported parameter/grid','Preconditions'),
      ('SV04 NEXT G29U REFUSED: printing or moving','Busy'),
      ('SV04 NEXT G29U REFUSED: IDEX/homing preflight','UnsafeIDEX'),
      ('SV04 NEXT G29U REFUSED: bed not stable at 60C','Temperature'),
      ('SV04 NEXT: reentrant G29 U refused','Reentry'),
      ('SV04 NEXT: G29 U requires tool T0','UnsafeIDEX'),
    ):
        needle='SERIAL_ERROR_MSG("'+marker+'");'
        code=replace_one(code,needle,
          'sv04next::g29u_receipt.refuse(sv04next::G29UReceipt::Failure::'+kind+');\n      '+needle,G29)
    # Ensure a failed native point cannot later turn into a successful receipt.
    code=replace_one(code,
      'SERIAL_ERROR_MSG("SV04 NEXT G29U ABORT: repeated/out-of-grid point");',
      'sv04next::g29u_receipt.fail(sv04next::G29UReceipt::Failure::Duplicate);\n'
      '              SERIAL_ERROR_MSG("SV04 NEXT G29U ABORT: repeated/out-of-grid point");',G29)
    code=replace_one(code,
      'SERIAL_ERROR_MSG("SV04 NEXT G29U ABORT: heat changed during probe");',
      'sv04next::g29u_receipt.fail(sv04next::G29UReceipt::Failure::Temperature);\n'
      '              SERIAL_ERROR_MSG("SV04 NEXT G29U ABORT: heat changed during probe");',G29)
    if code.count('sv04next::g29u_receipt') < 3:
        raise PatchRefused('receipt lifecycle incomplete')
    import apply_native_guard_v2 as _v2
    _v2.no_new_tokens(original[G29], code, ('settings.save()', 'queue.enqueue', 'setTargetBed(', 'M500'), 'not read-only G29 patch')
    if out['Marlin/Configuration.h'] != original['Marlin/Configuration.h'] or out['Marlin/src/module/probe.cpp'] != original['Marlin/src/module/probe.cpp']:
        raise PatchRefused('OEM probe/config mutation')
    out[G29]=code
    out[RECEIPT_TARGET]=receipt_header
    return out


def apply(root:Path, thermal_header:Path, visit_header:Path, receipt_header:Path,evidence:Path|None=None):
    if any((root/p).exists() for p in (THERMAL_TARGET,VISIT_TARGET,RECEIPT_TARGET)):
        raise PatchRefused('native headers already present: refusing repeat patch')
    originals={}
    for name,sha in OEM_BLOBS.items():
        raw=(root/name).read_bytes()
        if previous.previous.git_blob_sha(raw)!=sha:
            raise PatchRefused('OEM drift: '+name)
        originals[name]=raw.decode('utf-8')
    updated=render(originals,thermal_header.read_text(),visit_header.read_text(),receipt_header.read_text())
    details={'phase_range':'11.33-11.52','result':'NATIVE_PATCH_NOT_BUILT_NOT_FLASHABLE',
             'ordinary_sovol_g29_modified':False,'new_dwin_button':False,
             't1_physically_verified':False,'eeprom_write_authorized':False,
             'automatic_heat_homing':False,'stm32_build_proven':False,'patched_sha256':{}}
    for name,content in updated.items():
        if name not in originals or content!=originals[name]:
            details['patched_sha256'][name]=hashlib.sha256(content.encode()).hexdigest()
    for name,content in updated.items():
        if name not in originals or content!=originals[name]:
            target=root/name; target.parent.mkdir(parents=True,exist_ok=True)
            target.write_text(content,encoding='utf-8')
    if evidence:
        evidence.parent.mkdir(parents=True,exist_ok=True)
        evidence.write_text(json.dumps(details,indent=2)+'\n')
    return details

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--root',type=Path,default=Path('.'))
    p.add_argument('--thermal-header',type=Path,default=Path('include/SV04NextNativeThermalGate.hpp'))
    p.add_argument('--visit-header',type=Path,default=Path('include/SV04NextVisitProof.hpp'))
    p.add_argument('--receipt-header',type=Path,default=Path('include/SV04NextG29UReceipt.hpp'))
    p.add_argument('--evidence',type=Path)
    args=p.parse_args()
    print(json.dumps(apply(args.root,args.thermal_header,args.visit_header,args.receipt_header,args.evidence),indent=2))
