#!/usr/bin/env python3
"""Stand 11: gehärteter Einstieg für das v14-Overlay (v14.render bleibt die einzige Quelle der OEM-Transformationen).

Unterschiede zu v14.apply():
 * SV04NextSafeFloat.hpp wird mitinstalliert (bitbasierter Finite-Check, unabhängig von -ffast-math); native Header dürfen kein rohes isfinite() mehr enthalten.
 * ATOMAR: alle neuen Inhalte werden zuerst gestaged (Temp-Dateien im Zielordner, fsync) und erst danach ersetzt; bei JEDEM Fehler werden bereits ersetzte Dateien
   byte-genau zurückgesetzt und neu angelegte Header gelöscht. v14 ließ nach einem Schreibfehler eine halb gepatchte Wurzel zurück, die ein Neustart wegen SHA-Abweichung verweigerte.
 * Klare Ablehnung (PatchRefused mit Dateiname, nichts verändert) bei CRLF-Zeilenenden und Nicht-UTF-8 statt rohem UnicodeDecodeError oder unklarer Ankermeldung.
 * --dry-run (nichts schreiben) und --diff-out (Unified Diff der drei OEM-Dateien zur Prüfung vor dem Anwenden).
Weiterhin: exakte Git-Blob-SHA1 der fünf OEM-Dateien nötig, Configuration.h und probe.cpp bleiben byte-identisch, kein Flash, keine Aktuation.
"""
from __future__ import annotations
import argparse, difflib, hashlib, json, os, tempfile
from pathlib import Path
import apply_native_guard_v14 as v14

base = v14.base
PatchRefused = v14.PatchRefused
HEADERS = list(v14.HEADERS) + ['SV04NextSafeFloat.hpp']
HEADER_SAFE = 'Marlin/src/feature/sv04_next/SV04NextSafeFloat.hpp'
NATIVE_FLOAT_USERS = ('SV04NextG29UReceipt.hpp', 'SV04NextNativeReadiness.hpp', 'SV04NextNativeThermalGate.hpp', 'SV04NextMeshMapPacket.hpp')


def render(original: dict[str, str], *headers: str) -> dict[str, str]:
    if len(headers) != 14: raise PatchRefused('14 headers required (13 of v14 + SV04NextSafeFloat.hpp)')
    safe = headers[-1]
    if 'float_is_finite' not in safe or '0xFFu' not in safe or 'memcpy' not in safe: raise PatchRefused('SafeFloat contract missing')
    out = v14.render(original, *headers[:13])
    out[HEADER_SAFE] = safe
    for name in NATIVE_FLOAT_USERS:
        key = 'Marlin/src/feature/sv04_next/' + name
        text = out.get(key)
        if text is None: raise PatchRefused('native header missing from overlay: ' + name)
        if 'isfinite(' in text.replace('float_is_finite(', ''): raise PatchRefused('raw isfinite() in native header (breaks under -ffast-math): ' + name)
        if '#include "SV04NextSafeFloat.hpp"' not in text and name != 'SV04NextMeshMapPacket.hpp' and 'SV04NextG29UReceipt.hpp' not in text and 'float_is_finite' in text:
            raise PatchRefused('native header uses float_is_finite without including SafeFloat: ' + name)
    return out


def _read_oem(root: Path):
    originals, raws = {}, {}
    for name, sha in v14.OEM_BLOBS.items():
        try: raw = (root / name).read_bytes()
        except OSError as e: raise PatchRefused(f'{name}: not readable ({type(e).__name__})')
        if base.git_blob_sha(raw) != sha: raise PatchRefused('OEM SHA mismatch: ' + name)
        if b'\r' in raw: raise PatchRefused(f'{name}: CRLF line endings; overlay anchors assume LF; file NOT modified')
        try: originals[name] = raw.decode('utf-8')
        except UnicodeDecodeError as e: raise PatchRefused(f'{name}: not valid UTF-8 (byte {e.start}); file NOT modified')
        raws[name] = raw
    return originals, raws


def apply(root: Path, headers: list[Path], evidence: Path | None = None, dry_run: bool = False, diff_out: Path | None = None, render_fn=None, block: int = 11, extra_report: dict | None = None) -> dict:
    originals, raws = _read_oem(root)
    texts = []
    for h in headers:
        try: texts.append(h.read_text(encoding='utf-8'))
        except (OSError, UnicodeDecodeError) as e: raise PatchRefused(f'{h.name}: header not readable as UTF-8 ({type(e).__name__}): {h}')
    out = (render_fn or render)(originals, *texts)
    if any(out[n] != originals[n] for n in ('Marlin/Configuration.h', 'Marlin/src/module/probe.cpp')): raise PatchRefused('OEM config/probe unexpectedly modified')
    plan = {}
    for name, content in out.items():
        if name in originals:
            if content != originals[name]: plan[name] = content.encode('utf-8')
        else:
            if (root / name).exists(): raise PatchRefused('target already exists, refusing to overwrite: ' + name)
            plan[name] = content.encode('utf-8')
    report = {'block': block, 'dry_run': dry_run, 'stm32_build': False, 'physical_t1_witness': False, 'automatic_motion': False, 'automatic_heat': False, 'eeprom_write': False,
              'dwin_button': False, 'flash_approved': False, 'before_git_blob_sha1': {n: v14.OEM_BLOBS[n] for n in originals}, 'changed_sha256': {}, 'new_files': []}
    if extra_report: report.update(extra_report)
    diff = []
    for name, data in plan.items():
        report['changed_sha256'][name] = hashlib.sha256(data).hexdigest()
        if name in originals: diff += list(difflib.unified_diff(originals[name].splitlines(True), data.decode('utf-8').splitlines(True), 'a/' + name, 'b/' + name))
        else: report['new_files'].append(name)
    if diff_out: diff_out.parent.mkdir(parents=True, exist_ok=True); diff_out.write_text(''.join(diff), encoding='utf-8')
    if not dry_run:
        staged: dict[str, str] = {}; done: list[tuple[Path, bytes | None]] = []
        try:
            for name, data in plan.items():
                dest = root / name; dest.parent.mkdir(parents=True, exist_ok=True)
                fd, tmp = tempfile.mkstemp(dir=str(dest.parent), prefix='.sv04tmp-'); staged[name] = tmp
                with os.fdopen(fd, 'wb') as f: f.write(data); f.flush(); os.fsync(f.fileno())
            for name in plan:
                dest = root / name; os.replace(staged[name], dest); done.append((dest, raws.get(name)))
        except BaseException:
            for dest, prev in reversed(done):
                try:
                    if prev is None: dest.unlink()
                    else: dest.write_bytes(prev)
                except OSError: pass
            for tmp in staged.values():
                try: os.unlink(tmp)
                except OSError: pass
            raise
    if evidence and not dry_run:
        evidence.parent.mkdir(parents=True, exist_ok=True); evidence.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    return report


if __name__ == '__main__':
    p = argparse.ArgumentParser(description='SV04 NEXT Overlay (Stand 11, atomar). NICHT FLASHEN.')
    p.add_argument('--root', type=Path, default=Path('.')); p.add_argument('--evidence', type=Path); p.add_argument('--dry-run', action='store_true'); p.add_argument('--diff-out', type=Path)
    for name in HEADERS: p.add_argument('--' + name[:-4].lower(), type=Path, default=Path('include') / name)
    a = p.parse_args()
    print(json.dumps(apply(a.root, [getattr(a, n[:-4].lower()) for n in HEADERS], a.evidence, a.dry_run, a.diff_out), indent=2))
