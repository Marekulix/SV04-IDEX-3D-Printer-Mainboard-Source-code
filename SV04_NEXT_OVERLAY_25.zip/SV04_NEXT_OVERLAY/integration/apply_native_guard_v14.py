#!/usr/bin/env python3
"""Block 10: instrument the two OEM IDEX G28 carriage return paths.

Read-only. No auto-heat/motion/BLTouch action/EEPROM or DWIN VP. The two
X homeaxis returns are *not* proof of physical parking or switch validation.
Requires exact original Sovol OEM Git object bytes; rejects drift and repatch.
"""
from __future__ import annotations
import argparse,hashlib,json,re
from pathlib import Path
import apply_native_guard_v13 as previous
import apply_native_guard_v5 as base

OEM_BLOBS=previous.OEM_BLOBS
PatchRefused=previous.PatchRefused
G28=previous.G28
RTS=previous.RTS
HEADER_IDEX='Marlin/src/feature/sv04_next/SV04NextNativeIdexHomingTrace.hpp'
HEADER_EVIDENCE='Marlin/src/feature/sv04_next/SV04NextNativeIdexEvidence.hpp'
HEADER_AUDIT='Marlin/src/feature/sv04_next/SV04NextT1CorrelationAudit.hpp'
HEADERS=['SV04NextNativeThermalGate.hpp','SV04NextVisitProof.hpp',
         'SV04NextG29UReceipt.hpp','SV04NextNativeReadiness.hpp',
         'SV04NextT1EndstopObserver.hpp','SV04NextNativeEventTimeline.hpp',
         'SV04NextNativeStatusPacket.hpp','SV04NextMeshMapPacket.hpp',
         'SV04NextG28PassiveReceipt.hpp','SV04NextG28G29OrderWitness.hpp',
         'SV04NextNativeIdexHomingTrace.hpp','SV04NextT1CorrelationAudit.hpp',
         'SV04NextNativeIdexEvidence.hpp']


# Stand 15: STRUKTURELLE Analyse der X-Referenzfahrten im echten G28.cpp (frueher: Regex-Zaehlung "genau 2+2" bzw. "X2,X1,X2,X1").
# Der echte Sovol-Text hat: Normalpfad-Paar, Duplikationsmodus-Paar (danach, in `if (idex_is_duplicating())`), einen ungepaarten T0-Aufruf NUR waehrend eines Drucks
# (`else if((save_dual_x_carriage_mode == 4) && card.isPrinting())`) und einen toten Nicht-IDEX-Zweig (`#else homeaxis(X_AXIS);`).
# Jeder Aufruf wird einzeln klassifiziert; UNKLASSIFIZIERTES wird verweigert. Nur Paare (X2 dann X1) werden instrumentiert.
HOMEAXIS_X=re.compile(r'\bhomeaxis\(\s*X_AXIS\s*\)\s*;')
ACTIVE_EXT=re.compile(r'^\s*active_extruder\s*=\s*([01])\s*;\s*(//.*)?$')
PP_DIRECTIVE=re.compile(r'^\s*#\s*(if|ifdef|ifndef|elif|else|endif)\b(.*)$')
OVERLAY_MARKERS=('saw_x2_homeaxis_return(','saw_x1_homeaxis_return(','sv04_g28_scope','sv04_idex_scope','sv04next::','SV04 NEXT')
MAX_IDEX_PAIRS=4
HOOK_GUARD='#if ENABLED(DUAL_X_CARRIAGE) && ENABLED(AUTO_BED_LEVELING_BILINEAR) && DISABLED(PROBE_MANUALLY)'
LAST_TOPOLOGY:dict={}


def idex_topology(text:str)->dict:
    """Read-only structural analysis of every `homeaxis(X_AXIS);` call in a G28.cpp text. Changes nothing."""
    lines=text.split('\n');stack=[];occ=[];offs=[0]
    for l in lines:offs.append(offs[-1]+len(l)+1)
    def significant_before(i):
        j=i-1
        while j>=0 and (not lines[j].strip() or lines[j].strip().startswith('//')):j-=1
        return j
    for i,l in enumerate(lines):
        m=PP_DIRECTIVE.match(l)
        if m:
            kind,rest=m.group(1),m.group(2).strip()
            if kind in('if','ifdef','ifndef'):stack.append([kind+' '+rest,'if'])
            elif kind=='elif' and stack:stack[-1]=[stack[-1][0],'elif']
            elif kind=='else' and stack:stack[-1][1]='else'
            elif kind=='endif' and stack:stack.pop()
            continue
        if l.strip().startswith('//') or not HOMEAXIS_X.search(l):continue
        j=significant_before(i);am=ACTIVE_EXT.match(lines[j]) if j>=0 else None
        occ.append({'line':i+1,'idx':i,'kind':{'1':'x2','0':'x1'}[am.group(1)] if am else 'other','pp':[tuple(e) for e in stack],
                    'recent':' '.join(x.strip() for x in lines[max(0,i-8):i])})
    pairs=[];singles=[];other=[];problems=[];open_=None
    for o in occ:
        if o['kind']=='x2':
            if open_ is not None:problems.append('line %d: X2 homing while the pair of line %d is still open'%(o['line'],open_['line']))
            open_=o
        elif o['kind']=='x1':
            if open_ is not None:
                pairs.append((open_,o));open_=None
            elif 'isPrinting()' in o['recent']:
                singles.append({'line':o['line'],'reason':'T0-only homing, guarded by isPrinting() (not taken while idle); NOT instrumented'})
            else:problems.append('line %d: T0 homing without a preceding X2 homing and without an isPrinting() guard'%o['line'])
        else:
            if any('DUAL_X_CARRIAGE' in c and br=='else' for c,br in o['pp']):
                other.append({'line':o['line'],'reason':'non-IDEX branch (#else of #if ENABLED(DUAL_X_CARRIAGE)); dead while DUAL_X_CARRIAGE is enabled'})
            else:problems.append('line %d: homeaxis(X_AXIS) is not preceded by active_extruder = 0/1 and not in a non-IDEX #else branch'%o['line'])
    if open_ is not None:problems.append('line %d: X2 homing is never followed by a T0 homing'%open_['line'])
    if not pairs and not problems:problems.append('no X2->X1 pair found')
    if len(pairs)>MAX_IDEX_PAIRS:problems.append('more than %d X2->X1 pairs'%MAX_IDEX_PAIRS)
    sym={'x2':'2','x1':'1','other':'o'}
    return {'x2':len(pairs),'x1':len(pairs),'x2_lines':[p[0]['line'] for p in pairs],'x1_lines':[p[1]['line'] for p in pairs],
            'pairs':[{'x2_line':a_['line'],'x1_line':b_['line'],'x2_idx':a_['idx'],'x1_idx':b_['idx']} for a_,b_ in pairs],
            'singles':singles,'non_idex':other,'problems':problems,'interleaved':not problems and bool(pairs),
            'order':''.join(sym[o['kind']] for o in occ),'other_homeaxis_x':len(singles)+len(other)}


def instrument_idex_pairs(text:str,topo:dict)->str:
    """Insert one read-only hook directly behind each homeaxis(X_AXIS) call that belongs to a pair (bottom-up so line indices stay valid)."""
    lines=text.split('\n');todo=[]
    for pr in topo['pairs']:todo+= [(pr['x2_idx'],'x2'),(pr['x1_idx'],'x1')]
    for idx,k in sorted(todo,reverse=True):
        indent=lines[idx][:len(lines[idx])-len(lines[idx].lstrip())]
        lines[idx+1:idx+1]=[indent+HOOK_GUARD,indent+'  sv04next::native_idex_homing_trace.saw_%s_homeaxis_return((uint32_t)millis(),active_extruder);'%k,indent+'#endif']
    return '\n'.join(lines)


def render(original:dict[str,str],*headers:str)->dict[str,str]:
    if len(headers)!=13:raise PatchRefused('13 headers required')
    idex,audit,evidence=headers[-3:]
    required_idex=('both_x_homeaxis_returned', 'bool physical_t1_park_proven()const{return false;}',
                   'bool allows_motion()const{return false;}',
                   'bool allows_eeprom()const{return false;}')
    required_evidence=('frame_.t1_physically_parked=false;',
                       'frame_.allow_motion=false;',
                       'frame_.allow_heat=false;frame_.allow_eeprom=false;',
                       'bool permits_motion()const{return false;}',
                       'bool permits_eeprom()const{return false;}')
    required_audit=('bool physical_t1_park_proven()const{return false;}',
                    'bool permit_motion()const{return false;}')
    if (any(x not in idex for x in required_idex) or
        any(x not in evidence for x in required_evidence) or
        any(x not in audit for x in required_audit)):
        raise PatchRefused('passive security contract missing')
    dangerous=('queue.enqueue','settings.save(', 'setTargetBed(',
               'process_subcommands_now', 'do_blocking_move_to', 'M500')
    if any(x in idex+audit+evidence for x in dangerous):
        raise PatchRefused('observer headers may not contain actuator commands')
    for name,text in original.items():
        for mk in OVERLAY_MARKERS:
            if mk in text:raise PatchRefused(f'{name}: already contains SV04 NEXT marker {mk!r} (already patched or not the OEM file); nothing was modified')
    out=previous.render(original,*headers[:10])
    g28=out[G28]
    topo=idex_topology(g28);LAST_TOPOLOGY.clear();LAST_TOPOLOGY.update(topo)
    if topo['problems']:
        raise PatchRefused('OEM G28 IDEX homeaxis topology mismatch: '+'; '.join(topo['problems'])+'; structure: '+repr({k:topo[k] for k in ('x2_lines','x1_lines','singles','non_idex','order')}))
    g28=previous.replace_one(g28,
      '#include "../../feature/sv04_next/SV04NextG28PassiveReceipt.hpp"',
      '#include "../../feature/sv04_next/SV04NextG28PassiveReceipt.hpp"\n'
      '  #include "../../feature/sv04_next/SV04NextNativeIdexHomingTrace.hpp"',G28)
    g28=previous.replace_one(g28,
      'namespace sv04next { G28PassiveReceipt g28_passive_receipt; }',
      'namespace sv04next { G28PassiveReceipt g28_passive_receipt; }\n'
      '  namespace sv04next { NativeIdexHomingTrace native_idex_homing_trace; }',G28)
    g28=previous.replace_one(g28,
      'sv04next::G28PassiveReceipt::Scope sv04_g28_scope(sv04next::g28_passive_receipt, (uint32_t)millis());',
      'sv04next::G28PassiveReceipt::Scope sv04_g28_scope(sv04next::g28_passive_receipt, (uint32_t)millis());\n'
      '    sv04next::NativeIdexHomingTrace::Scope sv04_idex_scope(\n'
      '      sv04next::native_idex_homing_trace,(uint32_t)millis(),\n'
      '      sv04next::g28_passive_receipt.view().sequence);',G28)
    g28=previous.replace_one(g28,
      'sv04_g28_scope.finish((uint32_t)millis(),',
      'sv04_idex_scope.finish((uint32_t)millis());\n'
      '    sv04_g28_scope.finish((uint32_t)millis(),',G28)
    # Every IDEX X2->X1 pair found by the structural analysis is instrumented; singles (printing-only T0 homing) and the non-IDEX branch stay untouched.
    # Probe only after the native `homeaxis()` call has returned. Counts do NOT testify that a switch was hit, nor that T1 is physically parked.
    topo2=idex_topology(g28)   # NEU berechnen: die Einfuegungen oben haben Zeilen hinzugefuegt, die Indizes der ersten Analyse waeren veraltet
    if topo2['problems'] or [(len(topo2[k])) for k in ('pairs','singles','non_idex')]!=[len(topo[k]) for k in ('pairs','singles','non_idex')]:
        raise PatchRefused('OEM G28 IDEX homeaxis topology mismatch: structure changed between analysis and instrumentation; '+repr((topo2['problems'],topo2['order'],topo['order'])))
    g28=instrument_idex_pairs(g28,topo2)
    out[G28]=g28
    rt=out[RTS]
    rt=previous.replace_one(rt,
      '#include "../../../feature/sv04_next/SV04NextG28G29OrderWitness.hpp"',
      '#include "../../../feature/sv04_next/SV04NextG28G29OrderWitness.hpp"\n'
      '  #include "../../../feature/sv04_next/SV04NextNativeIdexHomingTrace.hpp"\n'
      '  #include "../../../feature/sv04_next/SV04NextT1CorrelationAudit.hpp"\n'
      '  #include "../../../feature/sv04_next/SV04NextNativeIdexEvidence.hpp"',RTS)
    rt=previous.replace_one(rt,
      'namespace sv04next { G28G29OrderWitness g28_g29_order_witness; }',
      'namespace sv04next { G28G29OrderWitness g28_g29_order_witness; }\n'
      '  namespace sv04next { T1CorrelationAudit t1_correlation_audit; }\n'
      '  namespace sv04next { NativeIdexEvidence native_idex_evidence; }',RTS)
    anchor='''      sv04next::g28_passive_receipt.view(), sv04next::g29u_receipt);'''
    rt=previous.replace_one(rt,anchor,anchor+'''
    // Read-only G28 X2/X1 path, X_MAX electrical edge and G29 observation.
    sv04next::t1_correlation_audit.observe((uint32_t)millis(),
      sv04next::g28_passive_receipt.view(),sv04next::t1_endstop_observer);
    sv04next::native_idex_evidence.observe((uint32_t)millis(),
      sv04next::g28_passive_receipt.view(),
      sv04next::native_idex_homing_trace.view(),
      sv04next::t1_correlation_audit.view(),
      sv04next::g28_g29_order_witness.view());''',RTS)
    out[RTS]=rt
    out[HEADER_IDEX]=idex;out[HEADER_AUDIT]=audit;out[HEADER_EVIDENCE]=evidence
    if any(out[n]!=original[n] for n in ('Marlin/Configuration.h','Marlin/src/module/probe.cpp')):
        raise PatchRefused('OEM config/probe unexpectedly modified')
    if g28.count('saw_x2_homeaxis_return(')!=topo['x2'] or g28.count('saw_x1_homeaxis_return(')!=topo['x1']:
        raise PatchRefused('G28 homing path audit incomplete: x2 hooks %d/%d, x1 hooks %d/%d'%(g28.count('saw_x2_homeaxis_return('),topo['x2'],g28.count('saw_x1_homeaxis_return('),topo['x1']))
    hooked=lambda k:len(re.findall(r'homeaxis\(X_AXIS\);\n\s*'+re.escape(HOOK_GUARD)+r'\n\s*sv04next::native_idex_homing_trace\.saw_x'+k+r'_homeaxis_return\(',g28))
    if hooked('2')!=topo['x2'] or hooked('1')!=topo['x1']:raise PatchRefused('G28 homing path audit incomplete: a hook is not directly behind its homeaxis(X_AXIS) call')
    if g28.count('homeaxis(X_AXIS);')!=topo['x2']*2+topo['other_homeaxis_x']:raise PatchRefused('G28 homing path audit incomplete: number of homeaxis(X_AXIS) calls changed by the overlay')
    if rt.count('native_idex_evidence.observe(')!=1 or rt.count('t1_correlation_audit.observe(')!=1:
        raise PatchRefused('RTS observer hook incomplete')
    return out


def apply(root:Path,headers:list[Path],evidence:Path|None=None):
    originals={}
    for name,sha in OEM_BLOBS.items():
        raw=(root/name).read_bytes()
        if base.git_blob_sha(raw)!=sha:raise PatchRefused('OEM SHA mismatch: '+name)
        originals[name]=raw.decode('utf-8')
    out=render(originals,*[h.read_text(encoding='utf-8') for h in headers])
    report={'block':10,'stm32_build':False,'physical_t1_witness':False,
            'automatic_motion':False,'automatic_heat':False,
            'eeprom_write':False,'dwin_button':False,'flash_approved':False,
            'changed_sha256':{}}
    for name,content in out.items():
        if name not in originals or content!=originals[name]:
            report['changed_sha256'][name]=hashlib.sha256(content.encode()).hexdigest()
            dest=root/name;dest.parent.mkdir(parents=True,exist_ok=True)
            dest.write_text(content,encoding='utf-8')
    if evidence:
        evidence.parent.mkdir(parents=True,exist_ok=True)
        evidence.write_text(json.dumps(report,indent=2)+'\n')
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path('.'))
    p.add_argument('--evidence',type=Path)
    for name in HEADERS:p.add_argument('--'+name[:-4].lower(),type=Path,default=Path('include')/name)
    a=p.parse_args()
    print(json.dumps(apply(a.root,[getattr(a,n[:-4].lower()) for n in HEADERS],a.evidence),indent=2))
