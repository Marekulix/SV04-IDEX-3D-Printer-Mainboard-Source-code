#!/usr/bin/env python3
"""SV04 NEXT phase 10.41..10.46 -- tightly scoped experimental Marlin G29 U overlay.

Scope: only the temporary CI checkout. EEPROM writes and DWIN button creation are
NOT enabled.  Rejects mismatched OEM Git blob IDs and changed/duplicate anchors.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path

OEM_BLOBS = {
    'Marlin/Configuration.h': 'b226c55234de47fe7bf592dbb3b3b12733098532',
    'Marlin/src/module/probe.cpp': '638bb6be817a98cdcdbb8e5d28bc0a74e7cb1193',
    'Marlin/src/gcode/bedlevel/abl/G29.cpp': '02df6e4c8d017cf4dd1d4c9e6986a8967a317a8b',
}

class PatchRefused(ValueError): pass

def replace_one(value: str, before: str, after: str, name: str):
    n=value.count(before)
    if n != 1:
        raise PatchRefused(f'{name}: expected exactly one anchor, found {n}: {before[:120]!r}')
    return value.replace(before,after,1)

def no_new_tokens(original:str, patched:str, tokens, label:str):
    """Differenzielle Sperre: verweigert nur, was das OVERLAY gegenueber dem unveraenderten OEM-Text ZUSAETZLICH einbringt.
    Der OEM-Code (z. B. der Creality-Displaycode mit settings.save()) darf diese Zeichenketten legitim enthalten."""
    for tok in tokens:
        extra = patched.count(tok) - original.count(tok)
        if extra > 0: raise PatchRefused(f'{label}: overlay adds {extra}x {tok!r} (unmodified OEM text contains {original.count(tok)}x)')

def render(src:dict[str,str])->dict[str,str]:
    if set(src)!=set(OEM_BLOBS): raise PatchRefused('Source set mismatch')
    output = dict(src)
    cf='Marlin/Configuration.h'
    output[cf]=replace_one(src[cf], '//#define MULTIPLE_PROBING 2',
                           '#define MULTIPLE_PROBING 2 // SV04 NEXT experimental: two touches per point',cf)

    g='Marlin/src/gcode/bedlevel/abl/G29.cpp'
    p='Marlin/src/module/probe.cpp'

    # Scoped guard limits the new agreement rejection to the opt-in G29 U command.
    # It avoids changing ordinary manual leveling and other uses of the probe.
    output[g]=replace_one(output[g],
        '#define G29_RETURN(b) return TERN_(G29_RETRY_AND_RECOVER, b)',
        '''#define G29_RETURN(b) return TERN_(G29_RETRY_AND_RECOVER, b)

#if ENABLED(AUTO_BED_LEVELING_BILINEAR) && DISABLED(PROBE_MANUALLY)
  bool sv04_next_g29_u_active = false;
#endif''',g)

    output[p]=replace_one(output[p],
        'Probe probe;\n',
        '''// Read-only for the probe: true ONLY inside experimental G29 U.
#if ENABLED(AUTO_BED_LEVELING_BILINEAR) && DISABLED(PROBE_MANUALLY)
  extern bool sv04_next_g29_u_active;
#endif

Probe probe;
''',p)
    output[p]=replace_one(output[p],
        '    const float z2 = current_position.z;\n\n    if (DEBUGGING(LEVELING))',
        '''    const float z2 = current_position.z;

    #if ENABLED(AUTO_BED_LEVELING_BILINEAR) && DISABLED(PROBE_MANUALLY)
      // Reject unstable double-probe readings in G29 U only.
      // Experimental tolerance 0.06 mm (not hardware validated).
      if (sv04_next_g29_u_active &&
          (!isfinite(first_probe_z) || !isfinite(z2) || ABS(first_probe_z - z2) > 0.06f)) {
        SERIAL_ERROR_MSG("SV04 NEXT: G29 U BLTouch discrepancy");
        return NAN;
      }
    #endif

    if (DEBUGGING(LEVELING))''',p)

    guard = '''
  // SV04 NEXT: this optional G29 U command is RAM-only and NEVER saves EEPROM.
  // Earlier G29 commands keep their existing control flow and mesh handling.
  #if ENABLED(AUTO_BED_LEVELING_BILINEAR) && DISABLED(PROBE_MANUALLY)
    const bool sv04_transactional_run = parser.seen_test('U');
    if (sv04_transactional_run && sv04_next_g29_u_active) {
      SERIAL_ERROR_MSG("SV04 NEXT: reentrant G29 U refused");
      G29_RETURN(true);
    }
    // We cannot yet verify the parked physical X2 carriage: no automated UI
    // start is authorized.  Refuse active tool 1 before native G29 changes tools.
    if (sv04_transactional_run && active_extruder != 0) {
      SERIAL_ERROR_MSG("SV04 NEXT: G29 U requires tool T0");
      G29_RETURN(true);
    }
    struct SV04NextScopedProbeMode {
      bool prior;
      SV04NextScopedProbeMode(bool enabled) : prior(sv04_next_g29_u_active) {
        if (enabled) sv04_next_g29_u_active = true;
      }
      ~SV04NextScopedProbeMode() { sv04_next_g29_u_active = prior; }
    } sv04_probe_mode(sv04_transactional_run);

    struct SV04NextMeshRollback {
      bool armed, old_active;
      float old_values[GRID_MAX_POINTS_X][GRID_MAX_POINTS_Y];
      xy_pos_t old_start;
      xy_float_t old_spacing;
      float old_probe_offset;
      SV04NextMeshRollback(const bool enabled)
        : armed(enabled), old_active(planner.leveling_active),
          old_start(bilinear_start), old_spacing(bilinear_grid_spacing),
          old_probe_offset(probe.offset.z) {
        if (armed) memcpy(old_values, z_values, sizeof(old_values));
      }
      void revert() {
        if (!armed) return;
        armed = false;
        set_bed_leveling_enabled(false);
        memcpy(z_values, old_values, sizeof(old_values));
        bilinear_start = old_start;
        bilinear_grid_spacing = old_spacing;
        refresh_bed_level();
        set_bed_leveling_enabled(old_active);
        // OEM G29 sends intermediate points to the existing RTS mesh fields.
        // After a failed G29 U, redraw the original values, not a partial mesh.
        #if ENABLED(RTS_AVAILABLE)
          uint8_t index = 0;
          bool zig = false;
          for (uint8_t y=0; y<GRID_MAX_POINTS_Y; ++y) {
            if (zig) {
              for (uint8_t x=0; x<GRID_MAX_POINTS_X; ++x)
                rtscheck.RTS_SndData(isfinite(z_values[x][y]) ? z_values[x][y] * 1000 : 0,
                                     AUTO_BED_LEVEL_1POINT_VP + (index++) * 2);
            }
            else {
              for (int8_t x=GRID_MAX_POINTS_X - 1; x>=0; --x)
                rtscheck.RTS_SndData(isfinite(z_values[x][y]) ? z_values[x][y] * 1000 : 0,
                                     AUTO_BED_LEVEL_1POINT_VP + (index++) * 2);
            }
            zig = !zig;
          }
        #endif
        SERIAL_ERROR_MSG("SV04 NEXT: original RAM mesh restored; EEPROM untouched");
      }
      void accept() { armed = false; }
      ~SV04NextMeshRollback() { revert(); }
    } sv04_mesh_guard(sv04_transactional_run);
    uint8_t sv04_measured_points = 0;
  #endif
'''
    output[g]=replace_one(output[g], '  reset_stepper_timeout();\n',
                          '  reset_stepper_timeout();\n'+guard,g)

    output[g]=replace_one(output[g],
        '''            z_values[abl.meshCount.x][abl.meshCount.y] = z;
            TERN_(EXTENSIBLE_UI, ExtUI::onMeshUpdate(abl.meshCount, z));''',
        '''            z_values[abl.meshCount.x][abl.meshCount.y] = z;
            #if ENABLED(AUTO_BED_LEVELING_BILINEAR) && DISABLED(PROBE_MANUALLY)
              if (sv04_transactional_run) ++sv04_measured_points;
            #endif
            TERN_(EXTENSIBLE_UI, ExtUI::onMeshUpdate(abl.meshCount, z));''',g)

    tail='''  #if ENABLED(RTS_AVAILABLE)
    RTS_AutoBedLevelPage();
  #endif
  report_current_position();

  TERN_(FULL_REPORT_TO_HOST_FEATURE, set_and_report_grblstate(M_IDLE));

  G29_RETURN(isnan(abl.measured_z));'''
    updated='''  #if ENABLED(AUTO_BED_LEVELING_BILINEAR) && DISABLED(PROBE_MANUALLY)
    if (sv04_transactional_run) {
      // 4x4 and complete, finite measurements are essential: G29 can return
      // after partially mutating its in-memory grid when probing fails.
      bool sv04_good = isfinite(abl.measured_z) && !faux && !abl.dryrun
        && GRID_MAX_POINTS_X == 4 && GRID_MAX_POINTS_Y == 4
        && sv04_measured_points == 16 && planner.leveling_active
        && isfinite(probe.offset.z)
        && ABS(probe.offset.z - sv04_mesh_guard.old_probe_offset) < 0.00001f;
      if (sv04_good) {
        for (uint8_t x=0; x<GRID_MAX_POINTS_X; ++x)
          for (uint8_t y=0; y<GRID_MAX_POINTS_Y; ++y)
            if (!isfinite(z_values[x][y])) sv04_good = false;
      }
      if (sv04_good) {
        sv04_mesh_guard.accept();
        SERIAL_ECHOLNPGM("SV04 NEXT: G29 U 16/16 OK, RAM mesh only");
      }
      else {
        sv04_mesh_guard.revert();
        abl.measured_z = NAN;
      }
    }
  #endif

  #if ENABLED(RTS_AVAILABLE)
    RTS_AutoBedLevelPage();
  #endif
  report_current_position();

  TERN_(FULL_REPORT_TO_HOST_FEATURE, set_and_report_grblstate(M_IDLE));

  G29_RETURN(isnan(abl.measured_z));'''
    output[g]=replace_one(output[g],tail,updated,g)
    # Invariants: the transaction is not invoked by the RTS key handler and cannot save.
    changed='\n'.join((output[k] for k in OEM_BLOBS))
    if 'settings.save()' in changed or 'queue.enqueue' in guard+updated or 'M500' in guard+updated:
        raise PatchRefused('Unexpected persistent/motion command in transactional guard')
    return output

def git_blob_sha(data:bytes):
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()

def apply(root:Path,evidence:Path|None=None):
    originals={}
    for path,expected in OEM_BLOBS.items():
        raw=(root/path).read_bytes()
        actual=git_blob_sha(raw)
        if actual!=expected:
            raise PatchRefused(f'Original mismatch: {path}: {actual} != {expected}')
        originals[path]=raw.decode('utf-8')
    modified=render(originals)  # Fail before writing anything, including evidence.
    info={'result':'EXPERIMENTAL_NO_FLASH','m500_automated':False,'dwin_hmi_button_added':False,
          'flash_approved':False,'source_patch':{}}
    for path,content in modified.items():
        info['source_patch'][path]={'git_sha_before':OEM_BLOBS[path],
                                    'sha256_after':hashlib.sha256(content.encode('utf-8')).hexdigest()}
        (root/path).write_text(content,encoding='utf-8')
    if evidence:
        evidence.parent.mkdir(parents=True,exist_ok=True)
        evidence.write_text(json.dumps(info,indent=2)+'\n',encoding='utf-8')
    return info

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--root',type=Path,default=Path('.'))
    ap.add_argument('--evidence',type=Path)
    args=ap.parse_args()
    print(json.dumps(apply(args.root,args.evidence),indent=2))

if __name__=='__main__': main()
