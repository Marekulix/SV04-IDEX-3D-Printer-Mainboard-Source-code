#!/usr/bin/env python3
"""Stand 16: v16 + UNABHAENGIGE elektrische Bestaetigung des T1-Parkzustands (X_MAX-Pegel) als zusaetzliche Verweigerungsbedingung des G29-U-Guards.

Warum: Der Guard prueft T1 bisher nur ueber Firmware-Buchfuehrung (inactive_extruder_x == X2_MAX_POS, axis_is_trusted). inactive_extruder_x ist laut OEM schon VOR der ersten
Referenzfahrt 362; beides beweist nicht, dass T1 physisch geparkt ist (Auftrag P1: 'kein Vertrauen nur auf axis_is_trusted'). Jetzt muss zusaetzlich der X_MAX-Schalter
elektrisch ausgeloest lesen: (a) vor dem Start, (b) vor JEDEM der 16 Punkte, (c) beim Abschluss. Sonst Verweigerung bzw. Rollback. Reine VERSCHAERFUNG; nichts wird gelockert.

Eigenschaften (alle vor dem Schreiben geprueft, sonst PatchRefused und NICHTS wird veraendert):
 * v16.render bleibt die einzige Quelle der bisherigen Transformationen und ist byte-identisch zum in CI 18 gebauten Stand 15; diese Schicht fuegt in G29.cpp genau 4 Blocks
   (1 Include, 3 Pruefungen) an eindeutigen Ankern des BEREITS gepatchten Textes ein. Keine OEM-Zeile wird entfernt oder umgeschrieben.
 * Neuer Header SV04NextT1ParkSense.hpp: nur READ(), fail closed, kein WRITE/SET_OUTPUT/Heizen/Bewegen/EEPROM.
 * 'block' bleibt 13 (Katalognachweis); zusaetzlich 'layer': 17 und 't1_electrical_park_check': true im Bericht.
NICHT FLASHEN. Dieser Code ist NICHT in CI gebaut, bevor Workflow 19 gelaufen ist.
"""
from __future__ import annotations
import argparse, json, re
from pathlib import Path
import apply_native_guard_v16 as v16

v15 = v16.v15; v14 = v15.v14
PatchRefused = v16.PatchRefused
HEADERS = list(v16.HEADERS) + ['SV04NextT1ParkSense.hpp']
G29 = 'Marlin/src/gcode/bedlevel/abl/G29.cpp'
H_SENSE = 'Marlin/src/feature/sv04_next/SV04NextT1ParkSense.hpp'
SENSE_FORBIDDEN = ('WRITE(', 'OUT_WRITE', 'SET_OUTPUT', 'SET_INPUT_PULLUP', 'pinMode', 'digitalWrite', 'settings.', 'M500', 'enqueue', 'setTargetBed', 'thermalManager', 'planner.', 'process_subcommands', 'millis(')
A_INCLUDE = '  #include "../../../feature/sv04_next/SV04NextG29UReceipt.hpp"\n'
A_START = '      SERIAL_ERROR_MSG("SV04 NEXT G29U REFUSED: IDEX/homing preflight");\n        G29_RETURN(true);\n      }\n'
A_POINT = '          // Ordinary G29 still calls the OEM probe path exactly once.\n'
A_FINAL = '      if (sv04_good && !sv04next::g29u_receipt.finish_ram_only())\n'
A_REVERT = '        refresh_bed_level();\n        set_bed_leveling_enabled(old_active);\n'
A_REVERT0 = '        armed = false;\n        set_bed_leveling_enabled(false);\n'
N_START = ('      if (!sv04next::t1_parked_electrically()) {\n'
           '        // Unabhaengig von der Firmware-Buchfuehrung: der X_MAX-Schalter von T1 muss ELEKTRISCH ausgeloest lesen (fail closed).\n'
           '        sv04next::g29u_receipt.refuse(sv04next::G29UReceipt::Failure::UnsafeIDEX);\n'
           '        SERIAL_ERROR_MSG("SV04 NEXT G29U REFUSED: T1 park not confirmed by X_MAX endstop");\n'
           '        G29_RETURN(true);\n'
           '      }\n')
N_POINT = ('          #if ENABLED(AUTO_BED_LEVELING_BILINEAR) && DISABLED(PROBE_MANUALLY)\n'
           '            // Vor JEDEM Punkt: T1 muss weiterhin elektrisch am X_MAX-Schalter stehen (sonst Abbruch und Rollback).\n'
           '            if (sv04_transactional_run && !sv04next::t1_parked_electrically()) {\n'
           '              SERIAL_ERROR_MSG("SV04 NEXT G29U ABORT: T1 park not confirmed by X_MAX endstop");\n'
           '              abl.measured_z = NAN;\n'
           '              break;\n'
           '            }\n'
           '          #endif\n')
N_FINAL = '      if (sv04_good && !sv04next::t1_parked_electrically()) sv04_good = false;   // auch beim Abschluss elektrisch bestaetigen\n'
N_REVERT0 = ('        // Stand 18: schon VOR der ersten Umschaltung den Cache von bilinear_z_offset() aus dem AKTUELLEN (ggf. neuen) Mesh neu laden; sonst rechnet apply_leveling mit den Eckwerten des G29-Starts.\n'
             '        { xy_pos_t sv04_p1 = bilinear_start, sv04_p2 = bilinear_start; sv04_p2.x += bilinear_grid_spacing.x * (GRID_MAX_POINTS_X - 1); sv04_p2.y += bilinear_grid_spacing.y * (GRID_MAX_POINTS_Y - 1); (void)bilinear_z_offset(sv04_p1); (void)bilinear_z_offset(sv04_p2); }\n')
N_REVERT = ('        // Stand 18: bilinear_z_offset() cached die Eckwerte NUR bei Zellwechsel (abl.cpp 268-345), refresh_bed_level() invalidiert ihn nicht: zwei Aufrufe in verschiedenen Zellen laden ihn aus dem WIEDERHERGESTELLTEN Mesh neu, bevor das Leveling wieder aktiv wird.\n'
            '        { xy_pos_t sv04_p1 = bilinear_start, sv04_p2 = bilinear_start; sv04_p2.x += bilinear_grid_spacing.x * (GRID_MAX_POINTS_X - 1); sv04_p2.y += bilinear_grid_spacing.y * (GRID_MAX_POINTS_Y - 1); (void)bilinear_z_offset(sv04_p1); (void)bilinear_z_offset(sv04_p2); }\n')


def _check_sense(t: str) -> None:
    if not t.startswith('// SV04 NEXT 16: UNABHAENGIGE ELEKTRISCHE Bestaetigung'): raise PatchRefused('sense header provenance mismatch')
    code = '\n'.join(re.sub(r'//.*$', '', l) for l in t.splitlines())
    for bad in SENSE_FORBIDDEN:
        if bad in code: raise PatchRefused(f'sense header contains forbidden token {bad!r}')
    reads = re.findall(r'\bREAD\(([^)]*)\)', code)
    if reads != ['X_MAX_PIN']: raise PatchRefused(f'sense header reads {reads}; only READ(X_MAX_PIN) allowed')
    if 'inline bool t1_parked_electrically() { return false; }' not in code: raise PatchRefused('sense header must fail closed when the pin is unavailable')
    if '#if ENABLED(DUAL_X_CARRIAGE) && PIN_EXISTS(X_MAX)' not in code: raise PatchRefused('sense header: availability condition missing')
    if 'current_position.x <= X_MAX_POS' not in code or code.count('current_position') != 1: raise PatchRefused('sense header: T0 position discriminator (current_position.x <= X_MAX_POS, NaN refuses) missing')


def _once(text: str, anchor: str, what: str) -> None:
    if text.count(anchor) != 1: raise PatchRefused(f'G29 anchor for {what} found {text.count(anchor)}x (expected 1); nothing was modified')


def render(original: dict[str, str], *headers: str) -> dict[str, str]:
    if len(headers) != 17: raise PatchRefused('17 headers required (16 of v16 + T1ParkSense)')
    sense = headers[-1]; _check_sense(sense)
    out = v16.render(original, *headers[:-1])
    g = out[G29]
    for a, w in ((A_INCLUDE, 'include'), (A_START, 'start check'), (A_POINT, 'per-point check'), (A_FINAL, 'final check'), (A_REVERT, 'rollback cache invalidation'), (A_REVERT0, 'rollback first toggle')): _once(g, a, w)
    g = g.replace(A_INCLUDE, A_INCLUDE + '  #include "../../../feature/sv04_next/SV04NextT1ParkSense.hpp"\n')
    g = g.replace(A_START, A_START + N_START)
    g = g.replace(A_POINT, N_POINT + '\n' + A_POINT)
    g = g.replace(A_FINAL, N_FINAL + A_FINAL)
    g = g.replace(A_REVERT, '        refresh_bed_level();\n' + N_REVERT + '        set_bed_leveling_enabled(old_active);\n')
    g = g.replace(A_REVERT0, '        armed = false;\n' + N_REVERT0 + '        set_bed_leveling_enabled(false);\n')
    if g.count('(void)bilinear_z_offset(sv04_p1)') != 2: raise PatchRefused('rollback cache invalidation must appear exactly twice (before the first toggle and after the restore)')
    if g.count('t1_parked_electrically()') != 3: raise PatchRefused('expected exactly 3 uses of t1_parked_electrically() in G29.cpp')
    # nur Einfuegungen gegenueber der v16-Ausgabe (nichts entfernt, nichts umgeschrieben)
    old_lines = out[G29].split('\n'); it = iter(g.split('\n'))
    for l in old_lines:
        for m in it:
            if m == l: break
        else: raise PatchRefused('layer 17 changed an existing line of the v16 output; refused')
    out[G29] = g; out[H_SENSE] = sense
    return out


def apply(root: Path, headers: list[Path], evidence: Path | None = None, dry_run: bool = False, diff_out: Path | None = None) -> dict:
    return v15.apply(root, headers, evidence, dry_run, diff_out, render_fn=render, block=13,
                     extra_report={'auto60_engine_compiled_by_default': False, 'auto60_start_trigger_present': False, 'auto60_eeprom_wired': False,
                                   'auto60_macro': v16.MACRO, 'layer': 17, 't1_electrical_park_check': True})


if __name__ == '__main__':
    p = argparse.ArgumentParser(description='SV04 NEXT Overlay (Stand 16, atomar). NICHT FLASHEN.')
    p.add_argument('--root', type=Path, default=Path('.')); p.add_argument('--evidence', type=Path); p.add_argument('--dry-run', action='store_true'); p.add_argument('--diff-out', type=Path)
    here = Path(__file__).resolve().parent.parent / 'include'   # Header relativ zum SKRIPTORT, nie relativ zum Arbeitsverzeichnis
    for name in HEADERS: p.add_argument('--' + name[:-4].lower(), type=Path, default=here / name)
    a = p.parse_args()
    missing = [str(getattr(a, n[:-4].lower())) for n in HEADERS if not getattr(a, n[:-4].lower()).is_file()]
    if missing: raise SystemExit('PatchRefused: overlay header(s) not found: ' + ', '.join(missing[:3]))
    print(json.dumps(apply(a.root, [getattr(a, n[:-4].lower()) for n in HEADERS], a.evidence, a.dry_run, a.diff_out), indent=2))
