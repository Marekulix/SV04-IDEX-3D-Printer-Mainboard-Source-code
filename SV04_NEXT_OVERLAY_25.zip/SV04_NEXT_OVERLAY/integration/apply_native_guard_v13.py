#!/usr/bin/env python3
"""SV04 block 8: passive G28 begin/return witness + G28/G29 order observation.

This patch does not queue G-code, move motors, heat, create a button, or save.
Cannot be flashed: firmware build AND physical hardware safety still unproven.
"""
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path
import apply_native_guard_v12 as previous
import apply_native_guard_v5 as base

G28 = 'Marlin/src/gcode/calibrate/G28.cpp'
RTS = previous.RTS
OEM_BLOBS = dict(previous.OEM_BLOBS)
OEM_BLOBS[G28] = '5700ac25228ef7405797a80b840bab1dacddfcc7'
PatchRefused = previous.PatchRefused
replace_one = previous.replace_one
HEADER_G28 = 'Marlin/src/feature/sv04_next/SV04NextG28PassiveReceipt.hpp'
HEADER_ORDER = 'Marlin/src/feature/sv04_next/SV04NextG28G29OrderWitness.hpp'


def render(original:dict[str,str], thermal:str, visit:str, receipt:str,
           native:str,sensor:str,timeline:str,status:str,map_packet:str,
           g28_receipt:str,order:str)->dict[str,str]:
    if G28 not in original: raise PatchRefused('G28 OEM source missing')
    required_g28 = ('// SV04 NEXT 8: passive native G28 scope receipt.',
                    'bool allows_motion()const{return false;}',
                    'bool allows_heating()const{return false;}',
                    'bool allows_eeprom()const{return false;}',
                    'bool physical_t1_proven()const{return false;}')
    required_order = ('// SV04 NEXT 8: observation-only G28 -> G29 U order checker.',
                      'bool allows_motion()const{return false;}',
                      'bool allows_heating()const{return false;}',
                      'bool allows_eeprom()const{return false;}',
                      'bool safe_for_actuation=false,save_allowed=false;')
    if any(x not in g28_receipt for x in required_g28) or any(x not in order for x in required_order):
        raise PatchRefused('safety contract missing')
    for untrusted in ('queue.enqueue', 'settings.save', 'M500', 'setTargetBed(', 'process_subcommands_now', 'do_blocking_move_to'):
        if untrusted in g28_receipt+order: raise PatchRefused('new passive header contains actuator')
    out = previous.render({k:v for k,v in original.items() if k != G28},
                          thermal,visit,receipt,native,sensor,timeline,status,map_packet)
    g28=original[G28]
    g28=replace_one(g28,
        '#include "../../module/endstops.h"',
        '#include "../../module/endstops.h"\n'
        '#if ENABLED(DUAL_X_CARRIAGE) && ENABLED(AUTO_BED_LEVELING_BILINEAR) && DISABLED(PROBE_MANUALLY)\n'
        '  #include "../../feature/sv04_next/SV04NextG28PassiveReceipt.hpp"\n'
        '#endif',G28)
    g28=replace_one(g28,
        '#include "../../core/debug_out.h"',
        '#include "../../core/debug_out.h"\n'
        '#if ENABLED(DUAL_X_CARRIAGE) && ENABLED(AUTO_BED_LEVELING_BILINEAR) && DISABLED(PROBE_MANUALLY)\n'
        '  namespace sv04next { G28PassiveReceipt g28_passive_receipt; }\n'
        '#endif',G28)
    g28=replace_one(g28,
        'void GcodeSuite::G28() {',
        'void GcodeSuite::G28() {\n'
        '  #if ENABLED(DUAL_X_CARRIAGE) && ENABLED(AUTO_BED_LEVELING_BILINEAR) && DISABLED(PROBE_MANUALLY)\n'
        '    // Scope only observes; an early G28 return is NOT a completed homing.\n'
        '    sv04next::G28PassiveReceipt::Scope sv04_g28_scope(sv04next::g28_passive_receipt, (uint32_t)millis());\n'
        '  #endif',G28)
    g28=replace_one(g28,
        '  TERN_(FULL_REPORT_TO_HOST_FEATURE, set_and_report_grblstate(M_IDLE));',
        '  TERN_(FULL_REPORT_TO_HOST_FEATURE, set_and_report_grblstate(M_IDLE));\n'
        '  #if ENABLED(DUAL_X_CARRIAGE) && ENABLED(AUTO_BED_LEVELING_BILINEAR) && DISABLED(PROBE_MANUALLY)\n'
        '    // End of native G28 path, only a firmware trust snapshot.\n'
        '    // This does not prove switch triggering or physical T1 parking.\n'
        '    sv04_g28_scope.finish((uint32_t)millis(),\n'
        '      axis_is_trusted(X_AXIS), axis_is_trusted(Y_AXIS), axis_is_trusted(Z_AXIS),\n'
        '      active_extruder == 0);\n'
        '  #endif',G28)
    out[G28]=g28
    rt=out[RTS]
    rt=replace_one(rt,
      '#include "../../../feature/sv04_next/SV04NextMeshMapPacket.hpp"',
      '#include "../../../feature/sv04_next/SV04NextMeshMapPacket.hpp"\n'
      '  #include "../../../feature/sv04_next/SV04NextG28PassiveReceipt.hpp"\n'
      '  #include "../../../feature/sv04_next/SV04NextG28G29OrderWitness.hpp"',RTS)
    rt=replace_one(rt,
      'namespace sv04next { MeshMapPacket mesh_map_packet; }',
      'namespace sv04next { MeshMapPacket mesh_map_packet; }\n'
      '  namespace sv04next { G28G29OrderWitness g28_g29_order_witness; }',RTS)
    anchor='''    sv04next::mesh_map_packet.capture(sv04next::g29u_receipt,
      sv04next::native_event_timeline.view(), sv04next::native_status_packet);'''
    rt=replace_one(rt,anchor,
      anchor+'\n    // Read-only order correlation; NEVER a native command scheduler.\n'
      '    sv04next::g28_g29_order_witness.observe((uint32_t)millis(),\n'
      '      sv04next::g28_passive_receipt.view(), sv04next::g29u_receipt);',RTS)
    out[RTS]=rt
    out[HEADER_G28]=g28_receipt
    out[HEADER_ORDER]=order
    import apply_native_guard_v2 as _v2
    _v2.no_new_tokens(original[RTS], rt, ('settings.save()', 'queue.enqueue_now("M500")'), 'RTS automation forbidden')
    for unchanged in ('Marlin/Configuration.h','Marlin/src/module/probe.cpp'):
        if out[unchanged]!=original[unchanged]:raise PatchRefused('OEM configuration changed')
    if g28.count('sv04_g28_scope.finish(')!=1 or g28.count('::Scope sv04_g28_scope(')!=1:
        raise PatchRefused('duplicate native homing witness')
    return out


def apply(root:Path,headers:list[Path],evidence:Path|None=None):
    original={}
    for name,sha in OEM_BLOBS.items():
        raw=(root/name).read_bytes()
        if base.git_blob_sha(raw)!=sha:raise PatchRefused('OEM git blob SHA mismatch: '+name)
        original[name]=raw.decode('utf-8')
    out=render(original,*[x.read_text(encoding='utf-8') for x in headers])
    report={'block':8,'native_stm32_verified':False,'github_required_now':False,
            'physical_t1_verified':False,'auto_g28_enabled':False,'auto_g29_enabled':False,
            'auto_heat_enabled':False,'auto_eeprom_enabled':False,'touch_button':False,
            'flash_approved':False,'changed':{}}
    for path,source in out.items():
        if path not in original or source!=original[path]:
            report['changed'][path]=hashlib.sha256(source.encode()).hexdigest()
            target=root/path;target.parent.mkdir(parents=True,exist_ok=True)
            target.write_text(source,encoding='utf-8')
    if evidence:
        evidence.parent.mkdir(parents=True,exist_ok=True)
        evidence.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path('.'))
    names=['SV04NextNativeThermalGate.hpp','SV04NextVisitProof.hpp','SV04NextG29UReceipt.hpp',
           'SV04NextNativeReadiness.hpp','SV04NextT1EndstopObserver.hpp',
           'SV04NextNativeEventTimeline.hpp','SV04NextNativeStatusPacket.hpp',
           'SV04NextMeshMapPacket.hpp','SV04NextG28PassiveReceipt.hpp',
           'SV04NextG28G29OrderWitness.hpp']
    for file in names:p.add_argument('--'+file[:-4].lower(),type=Path,default=Path('include')/file)
    p.add_argument('--evidence',type=Path)
    args=p.parse_args()
    print(json.dumps(apply(args.root,[getattr(args,f[:-4].lower()) for f in names],args.evidence),indent=2))
