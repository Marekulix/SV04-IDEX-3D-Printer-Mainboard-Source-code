#!/usr/bin/env python3
"""Stand 13: v15 + Auto60Engine + Marlin-Bruecke (SV04_NEXT_AUTO60_ENGINE). v15.render bleibt die einzige Quelle der bisherigen OEM-Transformationen.

Neu gegenueber v15 (nur zusaetzlich; nichts Bestehendes wird veraendert):
 * zwei neue Header: SV04NextAuto60Engine.hpp (reine Zustandsmaschine, keine Marlin-Aufrufe) und SV04NextAuto60Glue.hpp (Bruecke, GESAMT unter #if defined(SV04_NEXT_AUTO60_ENGINE)).
 * LCD_RTS.cpp: Include der Bruecke, die Instanz der Maschine und EIN Aufruf von auto60_glue_tick(), beides ausschliesslich unter demselben Makro.
 * Das Makro wird NIRGENDS gesetzt. Selbst wenn es gesetzt wird, startet nichts ohne auto60_request_start(); kein OEM-/Overlay-Code ruft das auf.
Sicherheitsvertrag, den dieses Skript vor dem Schreiben prueft (sonst PatchRefused, nichts veraendert):
 * Maschine: kein settings./M500/enqueue/setTargetBed/thermalManager/queue. im Text; allow_motion() ist false.
 * Bruecke: nur SV04_NEXT_ENQUEUE("G28") und ("G29 U"), nur SV04_NEXT_SET_BED_TARGET(60) und (0); kein M500/M501/M502/M503/M420/M140/M104/M109/G92/G0/G1/M112/M410/settings.;
   eeprom_commit_supported wird auf false gesetzt; gesamter Inhalt unter dem Makro.
 * Ausgabe: auto60_request_start() kommt in keiner OEM-Datei vor; auto60_glue_tick() steht in LCD_RTS.cpp nur direkt unter dem Makro; das Makro wird nirgends definiert.
Weiterhin: exakte Git-Blob-SHA1 der fuenf OEM-Dateien, Configuration.h und probe.cpp bleiben byte-identisch, kein Flash. NICHT FLASHEN; nicht gegen echtes OEM gebaut.
"""
from __future__ import annotations
import argparse, json, re
from pathlib import Path
import apply_native_guard_v15 as v15

v14 = v15.v14
PatchRefused = v15.PatchRefused
HEADERS = list(v15.HEADERS) + ['SV04NextAuto60Engine.hpp', 'SV04NextAuto60Glue.hpp']
H_ENGINE = 'Marlin/src/feature/sv04_next/SV04NextAuto60Engine.hpp'
H_GLUE = 'Marlin/src/feature/sv04_next/SV04NextAuto60Glue.hpp'
RTS = v14.RTS
MACRO = 'SV04_NEXT_AUTO60_ENGINE'
ENGINE_FORBIDDEN = ('settings.', 'M500', 'enqueue', 'setTargetBed', 'thermalManager', 'queue.', 'process_subcommands', 'planner.', 'millis(')
GLUE_FORBIDDEN = ('M500', 'M501', 'M502', 'M503', 'M420', 'M140', 'M104', 'M109', 'M190', 'G92', '"G0', '"G1 ', 'M112', 'M410', 'settings.', 'process_subcommands', 'enqueue_now')
A_INCLUDE = '  #include "../../../feature/sv04_next/SV04NextNativeIdexEvidence.hpp"\n'
A_INSTANCE = '  namespace sv04next { NativeIdexEvidence native_idex_evidence; }\n'
A_TICK = '      sv04next::g28_g29_order_witness.view());\n'


def _once(text: str, anchor: str, what: str) -> None:
    if text.count(anchor) != 1: raise PatchRefused(f'LCD_RTS anchor for {what} found {text.count(anchor)}x (expected 1)')


def _check_engine(t: str) -> None:
    if not t.startswith('// SV04 NEXT 13: EINE auslieferbare Zustandsmaschine'): raise PatchRefused('engine header provenance mismatch')
    for need in ('class Auto60Engine final', 'bool allow_motion() const { return false; }', 'enum class Action : uint8_t { None, SetBed60, SetBedOff, Home, Measure, Commit };'):
        if need not in t: raise PatchRefused('engine header missing safety contract: ' + need)
    for bad in ENGINE_FORBIDDEN:
        if bad in t: raise PatchRefused(f'engine header contains forbidden token {bad!r}')


def _check_glue(t: str) -> None:
    if not t.lstrip().startswith('// SV04 NEXT 13: Marlin-Bruecke'): raise PatchRefused('glue header provenance mismatch')
    if not t.rstrip().endswith(f'#endif // {MACRO}'): raise PatchRefused('glue header must be entirely under #if defined(' + MACRO + ')')
    m = re.search(r'^#if defined\(' + MACRO + r'\)\s*$', t, re.M)
    if not m: raise PatchRefused('glue header: no #if defined(' + MACRO + ') line')
    body = t[m.end():]
    if '#pragma once' in body or '#pragma once' not in t[:m.start()]: raise PatchRefused('glue header: #pragma once must precede the macro guard')
    code = '\n'.join(re.sub(r'//.*$', '', l) for l in t.splitlines())   # auch angehaengte Kommentare entfernen
    for bad in GLUE_FORBIDDEN:
        if bad in code: raise PatchRefused(f'glue header contains forbidden token {bad!r}')
    calls = re.findall(r'SV04_NEXT_ENQUEUE\("([^"]*)"\)', code)
    if sorted(set(calls)) != ['G28', 'G29 U']: raise PatchRefused(f'glue header enqueues {sorted(set(calls))}; only G28 and G29 U allowed')
    sets = [m for l in code.splitlines() if not l.lstrip().startswith('#define') for m in re.findall(r'SV04_NEXT_SET_BED_TARGET\(([^)]*)\)', l)]
    if sorted(set(sets)) != ['0', '60']: raise PatchRefused(f'glue header sets bed target {sorted(set(sets))}; only 60 and 0 allowed')
    if 'o.eeprom_commit_supported = false;' not in code or 'eeprom_commit_supported = true' in code: raise PatchRefused('glue header must keep eeprom_commit_supported=false')
    if 'case Auto60Engine::Action::Commit: auto60_engine.notify_action_failed(); break;' not in code: raise PatchRefused('glue header: Commit action must abort (EEPROM not wired)')
    if 'if (auto60_in_tick()) return;' not in code: raise PatchRefused('glue header: re-entrancy guard missing')


def render(original: dict[str, str], *headers: str) -> dict[str, str]:
    if len(headers) != 16: raise PatchRefused('16 headers required (14 of v15 + Auto60Engine + Auto60Glue)')
    engine, glue = headers[-2], headers[-1]
    _check_engine(engine); _check_glue(glue)
    out = v15.render(original, *headers[:-2])
    rts = out[RTS]
    for a, w in ((A_INCLUDE, 'include'), (A_INSTANCE, 'instance'), (A_TICK, 'tick')): _once(rts, a, w)
    rts = rts.replace(A_INCLUDE, A_INCLUDE + '  #include "../../../feature/sv04_next/SV04NextAuto60Glue.hpp"   // leer, solange ' + MACRO + ' nicht definiert ist\n')
    rts = rts.replace(A_INSTANCE, A_INSTANCE + f'  #if defined({MACRO})\n    namespace sv04next {{ Auto60Engine auto60_engine; }}\n  #endif\n')
    rts = rts.replace(A_TICK, A_TICK + f'    #if defined({MACRO})\n      // Opt-in per Makro. Startet NICHTS (kein request_start); bedient nur eine bereits laufende Maschine.\n      sv04next::auto60_glue_tick();\n    #endif\n')
    out[RTS] = rts; out[H_ENGINE] = engine; out[H_GLUE] = glue
    oem = (v15.v14.G28, v15.v14.RTS, 'Marlin/src/gcode/bedlevel/abl/G29.cpp', 'Marlin/src/module/probe.cpp', 'Marlin/Configuration.h')
    for n in oem:
        t = out[n]
        if 'auto60_request_start' in t: raise PatchRefused('auto60_request_start() referenced in OEM file ' + n)
        if re.search(r'^\s*#\s*define\s+' + MACRO, t, re.M): raise PatchRefused('macro ' + MACRO + ' must not be defined by the overlay (' + n + ')')
    lines = out[RTS].splitlines()
    for i, l in enumerate(lines):
        if 'auto60_glue_tick()' in l and not (i >= 2 and lines[i - 2].strip() == f'#if defined({MACRO})'): raise PatchRefused('auto60_glue_tick() not directly under #if defined(' + MACRO + ')')
    return out


def apply(root: Path, headers: list[Path], evidence: Path | None = None, dry_run: bool = False, diff_out: Path | None = None) -> dict:
    return v15.apply(root, headers, evidence, dry_run, diff_out, render_fn=render, block=13,
                     extra_report={'auto60_engine_compiled_by_default': False, 'auto60_start_trigger_present': False, 'auto60_eeprom_wired': False, 'auto60_macro': MACRO})


if __name__ == '__main__':
    p = argparse.ArgumentParser(description='SV04 NEXT Overlay (Stand 13, atomar). NICHT FLASHEN.')
    p.add_argument('--root', type=Path, default=Path('.')); p.add_argument('--evidence', type=Path); p.add_argument('--dry-run', action='store_true'); p.add_argument('--diff-out', type=Path)
    here = Path(__file__).resolve().parent.parent / 'include'   # Header relativ zum SKRIPTORT, nie relativ zum Arbeitsverzeichnis (CI ruft aus der Repository-Wurzel auf)
    for name in HEADERS: p.add_argument('--' + name[:-4].lower(), type=Path, default=here / name)
    a = p.parse_args()
    missing = [str(getattr(a, n[:-4].lower())) for n in HEADERS if not getattr(a, n[:-4].lower()).is_file()]
    if missing: raise SystemExit('PatchRefused: overlay header(s) not found: ' + ', '.join(missing[:3]))
    print(json.dumps(apply(a.root, [getattr(a, n[:-4].lower()) for n in HEADERS], a.evidence, a.dry_run, a.diff_out), indent=2))
