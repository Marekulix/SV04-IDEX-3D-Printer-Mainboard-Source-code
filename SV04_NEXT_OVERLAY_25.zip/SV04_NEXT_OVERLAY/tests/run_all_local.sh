#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if ! command -v clang++ >/dev/null; then echo "NOTE: clang++ nicht installiert: alle Clang-ASan/UBSan-Läufe unten werden NICHT ausgeführt (NOT_RUN)"; fi
python3 tests/test_overlay_v2.py
python3 tests/test_overlay_v3.py
python3 tests/test_overlay_v4.py
python3 tests/test_rts_rollback_map.py
for opt in 0 2; do
  for name in test_auto60_safety test_journal test_orchestrator test_faultmatrix test_rts_telemetry test_g29_transaction_model test_20_phase_contract test_sequenced_controller; do
    g++ -std=c++11 -O"${opt}" -Wall -Wextra -Werror -pedantic "tests/${name}.cpp" -o "/tmp/sv04-next-${name}-${opt}"
    "/tmp/sv04-next-${name}-${opt}"
  done
done
g++ -std=c++11 -O1 -g -fsanitize=undefined -fno-sanitize-recover=all -Wall -Wextra -Werror -pedantic tests/test_g29_transaction_model.cpp -o /tmp/sv04-next-g29-ubsan
/tmp/sv04-next-g29-ubsan
g++ -std=c++11 -O1 -g -fsanitize=undefined -fno-sanitize-recover=all -Wall -Wextra -Werror -pedantic tests/test_20_phase_contract.cpp -o /tmp/sv04-next-20phase-ubsan
/tmp/sv04-next-20phase-ubsan
g++ -std=c++11 -O1 -g -fsanitize=undefined -fno-sanitize-recover=all -Wall -Wextra -Werror -pedantic tests/test_sequenced_controller.cpp -o /tmp/sv04-next-sequenced-ubsan
/tmp/sv04-next-sequenced-ubsan
echo '(Zwischenstand Block 1: weitere Blöcke folgen; das Gesamtergebnis steht in der LETZTEN Zeile)'
python3 tests/test_overlay_v5.py
for opt in 0 2; do
  g++ -std=c++11 -O"${opt}" -Wall -Wextra -Werror -pedantic tests/test_native_thermal_gate.cpp -o "/tmp/sv04-next-native-gate-${opt}"
  "/tmp/sv04-next-native-gate-${opt}"
done
g++ -std=c++11 -O1 -g -fsanitize=undefined -fno-sanitize-recover=all -Wall -Wextra -Werror -pedantic tests/test_native_thermal_gate.cpp -o /tmp/sv04-next-native-gate-ubsan
/tmp/sv04-next-native-gate-ubsan
echo 'SV04 NEXT NATIVE V5 EXTRA REGRESSIONS PASS; STM32 build pending'
python3 tests/test_overlay_v6.py
for opt in 0 2; do
  for name in test_native_thermal_runtime test_visit_proof; do
    g++ -std=c++11 -O"${opt}" -Wall -Wextra -Werror -pedantic "tests/${name}.cpp" -o "/tmp/sv04-next-${name}-${opt}"
    "/tmp/sv04-next-${name}-${opt}"
  done
done
for name in test_native_thermal_runtime test_visit_proof; do
  g++ -std=c++11 -O1 -g -fsanitize=undefined -fno-sanitize-recover=all -Wall -Wextra -Werror -pedantic "tests/${name}.cpp" -o "/tmp/sv04-next-${name}-ubsan"
  "/tmp/sv04-next-${name}-ubsan"
done
echo 'SV04 NEXT v6 new native patch source checks and host-model tests PASS; STM32 build pending.'
python3 tests/test_overlay_v7.py
for opt in 0 2; do
  g++ -std=c++11 -O"${opt}" -Wall -Wextra -Werror -pedantic tests/test_g29u_receipt.cpp -o "/tmp/sv04-next-g29u-receipt-${opt}"
  "/tmp/sv04-next-g29u-receipt-${opt}"
done
g++ -std=c++11 -O1 -g -fsanitize=undefined -fno-sanitize-recover=all -Wall -Wextra -Werror -pedantic tests/test_g29u_receipt.cpp -o /tmp/sv04-next-g29u-receipt-ubsan
/tmp/sv04-next-g29u-receipt-ubsan
echo 'SV04 NEXT v7 native receipt model + overlay checks PASS; STM32 build pending.'
for opt in 0 2; do
  g++ -std=c++11 -O"${opt}" -Wall -Wextra -Werror -pedantic tests/test_g29u_display_frame.cpp -o "/tmp/sv04-next-g29u-display-${opt}"
  "/tmp/sv04-next-g29u-display-${opt}"
done
g++ -std=c++11 -O1 -g -fsanitize=undefined -fno-sanitize-recover=all -Wall -Wextra -Werror -pedantic tests/test_g29u_display_frame.cpp -o /tmp/sv04-next-g29u-display-ubsan
/tmp/sv04-next-g29u-display-ubsan
echo 'SV04 NEXT v7 receipt display extraction tests PASS; physical HMI not present.'
python3 tests/test_overlay_v8.py
for opt in 0 2; do
  g++ -std=c++11 -O"${opt}" -Wall -Wextra -Werror -pedantic tests/test_native_readiness.cpp -o "/tmp/sv04-next-native-readiness-${opt}"
  "/tmp/sv04-next-native-readiness-${opt}"
done
g++ -std=c++11 -O1 -g -fsanitize=undefined -fno-sanitize-recover=all -Wall -Wextra -Werror -pedantic tests/test_native_readiness.cpp -o /tmp/sv04-next-native-readiness-ubsan
/tmp/sv04-next-native-readiness-ubsan
echo 'v8 native-read-only bridge tests PASS. NOT FLASHABLE.'
python3 tests/test_overlay_v9.py
for opt in 0 2; do
  g++ -std=c++11 -O"${opt}" -Wall -Wextra -Werror -pedantic tests/test_t1_endstop_observer.cpp -o "/tmp/sv04-next-t1sensor-${opt}"
  "/tmp/sv04-next-t1sensor-${opt}"
done
g++ -std=c++11 -O1 -g -fsanitize=undefined -fno-sanitize-recover=all -Wall -Wextra -Werror -pedantic tests/test_t1_endstop_observer.cpp -o /tmp/sv04-next-t1sensor-ubsan
/tmp/sv04-next-t1sensor-ubsan
echo 'v9 X_MAX sensor observation contract PASS; physical T1 parking remains UNPROVEN.'

# Larger block 3: explicitly owned native G29 receipt and command tickets.
for opt in 0 2; do
  for name in test_command_handshake test_receipt_binder; do
    g++ -std=c++11 -O"${opt}" -Wall -Wextra -Werror -pedantic "tests/${name}.cpp" -o "/tmp/sv04-next-${name}-${opt}"
    "/tmp/sv04-next-${name}-${opt}"
  done
done
for name in test_command_handshake test_receipt_binder; do
  g++ -std=c++11 -O1 -g -fsanitize=undefined -fno-sanitize-recover=all -Wall -Wextra -Werror -pedantic "tests/${name}.cpp" -o "/tmp/sv04-next-${name}-ubsan"
  "/tmp/sv04-next-${name}-ubsan"
done
echo 'BLOCK 3: handshake & native receipt model PASS; NO commands or EEPROM; NO NEW GITHUB UPLOAD.'

for opt in 0 2; do
  g++ -std=c++11 -O"${opt}" -Wall -Wextra -Werror -pedantic tests/test_auto60_view_model.cpp -o "/tmp/sv04-next-view-${opt}"
  "/tmp/sv04-next-view-${opt}"
done
g++ -std=c++11 -O1 -g -fsanitize=undefined -fno-sanitize-recover=all -Wall -Wextra -Werror -pedantic tests/test_auto60_view_model.cpp -o /tmp/sv04-next-view-ubsan
/tmp/sv04-next-view-ubsan

for opt in 0 2; do
  g++ -std=c++11 -O"${opt}" -Wall -Wextra -Werror -pedantic tests/test_auto60_e2e_simulation.cpp -o "/tmp/sv04-next-e2e-${opt}"
  "/tmp/sv04-next-e2e-${opt}"
done
g++ -std=c++11 -O1 -g -fsanitize=undefined -fno-sanitize-recover=all -Wall -Wextra -Werror -pedantic tests/test_auto60_e2e_simulation.cpp -o /tmp/sv04-next-e2e-ubsan
/tmp/sv04-next-e2e-ubsan

# Block 4: larger local development without ANY Github requirement.
# All compiled host tests are intentionally separate from Marlin's STM32 build.
for opt in 0 2; do
  for name in operation_ledger thermal_witness homing_witness mesh_integrity dwin_status_contract auto60_full_contract; do
    g++ -std=c++11 -O"${opt}" -Wall -Wextra -Werror -pedantic "tests/test_${name}.cpp" -o "/tmp/sv04-next-${name}-${opt}"
    "/tmp/sv04-next-${name}-${opt}"
  done
done
for name in operation_ledger thermal_witness homing_witness mesh_integrity dwin_status_contract auto60_full_contract; do
  g++ -std=c++11 -O1 -g -fsanitize=undefined -fno-sanitize-recover=all -Wall -Wextra -Werror -pedantic "tests/test_${name}.cpp" -o "/tmp/sv04-next-${name}-ubsan"
  "/tmp/sv04-next-${name}-ubsan"
done
echo 'BLOCK 4 HOST SAFETY & FULL-CONTRACT SIMULATION PASSED; NO GITHUB, NO FLASH.'

# Block 5: offline abort containment and human-supervised recovery (never actuator).
for opt in 0 2; do
  for name in abort_quarantine fault_trace abort_supervisor; do
    g++ -std=c++11 -O"${opt}" -Wall -Wextra -Werror -pedantic "tests/test_${name}.cpp" -o "/tmp/sv04-next-${name}-${opt}"
    "/tmp/sv04-next-${name}-${opt}"
  done
done
for name in abort_quarantine fault_trace abort_supervisor; do
  g++ -std=c++11 -O1 -g -fsanitize=undefined -fno-sanitize-recover=all -Wall -Wextra -Werror -pedantic "tests/test_${name}.cpp" -o "/tmp/sv04-next-${name}-ubsan"
  "/tmp/sv04-next-${name}-ubsan"
done
echo 'BLOCK 5 OFFLINE ABORT/RECOVERY HOST PASS. NO GCODE, NO MOTOR, NO EEPROM, NO GITHUB.'
python3 tests/test_block5_contract.py

# Block 6: passive native G29 receipt + uptime + X_MAX electrical provenance.
python3 tests/test_overlay_v10.py
for opt in 0 2; do
  g++ -std=c++11 -O"${opt}" -Wall -Wextra -Werror -pedantic tests/test_native_event_timeline.cpp -o "/tmp/sv04-next-timeline-${opt}"
  "/tmp/sv04-next-timeline-${opt}"
done
g++ -std=c++11 -O1 -g -fsanitize=undefined -fno-sanitize-recover=all -Wall -Wextra -Werror -pedantic tests/test_native_event_timeline.cpp -o /tmp/sv04-next-timeline-ubsan
/tmp/sv04-next-timeline-ubsan
if command -v clang++ >/dev/null; then
  clang++ -std=c++11 -O2 -g -fsanitize=address,undefined -fno-sanitize-recover=all -Wall -Wextra -Werror -pedantic tests/test_native_event_timeline.cpp -o /tmp/sv04-next-timeline-clang
  /tmp/sv04-next-timeline-clang
fi
echo 'BLOCK 6 NATIVE EVENT COLLECTOR HOST TESTS PASS; NO STM32 BUILD, NO GITHUB, NO FLASH.'

# Block 7: native status snapshot and 16-value probe map, strictly RAM only.
python3 tests/test_overlay_v11.py
python3 tests/test_overlay_v12.py
for opt in 0 2; do
  for name in test_native_status_packet test_mesh_map_packet test_native_diagnostics_replay; do
    g++ -std=c++11 -O"${opt}" -Wall -Wextra -Werror -pedantic \
      "tests/${name}.cpp" -o "/tmp/sv04-next-${name}-${opt}"
    "/tmp/sv04-next-${name}-${opt}"
  done
done
for name in test_native_status_packet test_mesh_map_packet test_native_diagnostics_replay; do
  g++ -std=c++11 -O1 -g -fsanitize=undefined -fno-sanitize-recover=all \
    -Wall -Wextra -Werror -pedantic "tests/${name}.cpp" \
    -o "/tmp/sv04-next-${name}-ubsan"
  "/tmp/sv04-next-${name}-ubsan"
done
if command -v clang++ >/dev/null; then
  for name in test_native_status_packet test_mesh_map_packet test_native_diagnostics_replay; do
    clang++ -std=c++11 -O1 -g -fsanitize=address,undefined \
      -fno-sanitize-recover=all -Wall -Wextra -Werror -pedantic \
      "tests/${name}.cpp" -o "/tmp/sv04-next-${name}-clang"
    "/tmp/sv04-next-${name}-clang"
  done
fi
echo 'BLOCK 7 NATIVE DIAGNOSTICS & MESH READ-ONLY PASS; NO GITHUB, NO STM32 COMPILE, NO FLASH.'

# Block 8: native G28 function-entry/exit receipt + passive G28/G29 U correlation.
# No new Marlin compile or movement. The native overlay is validated with fixtures.
python3 tests/test_overlay_v13.py
for opt in 0 2; do
  for name in g28_receipt g28_g29_order; do
    g++ -std=c++11 -O"${opt}" -Wall -Wextra -Werror -pedantic \
      "tests/test_${name}.cpp" -o "/tmp/sv04next8-${name}-${opt}"
    "/tmp/sv04next8-${name}-${opt}"
  done
done
for name in g28_receipt g28_g29_order; do
  g++ -std=c++11 -O1 -g -fsanitize=undefined -fno-sanitize-recover=all \
    -Wall -Wextra -Werror -pedantic "tests/test_${name}.cpp" \
    -o "/tmp/sv04next8-${name}-ubsan"
  "/tmp/sv04next8-${name}-ubsan"
done
if command -v clang++ >/dev/null; then
  for name in g28_receipt g28_g29_order; do
    clang++ -std=c++11 -O1 -g -fsanitize=address,undefined -fno-sanitize-recover=all \
      -Wall -Wextra -Werror -pedantic "tests/test_${name}.cpp" \
      -o "/tmp/sv04next8-${name}-clang"
    "/tmp/sv04next8-${name}-clang"
  done
fi
echo 'BLOCK 8 PASS: G28 passive exit + G29 U ordered event only. NO ACTUATION, NO FLASH.'

# Block 9: extra T1 temporal audit and G28/G29 freshness regression.
for opt in 0 2; do
  g++ -std=c++11 -O"${opt}" -Wall -Wextra -Werror -pedantic tests/test_t1_correlation_audit.cpp -o "/tmp/sv04next9-t1-${opt}"
  "/tmp/sv04next9-t1-${opt}"
done
g++ -std=c++11 -O1 -g -fsanitize=undefined -fno-sanitize-recover=all -Wall -Wextra -Werror -pedantic tests/test_t1_correlation_audit.cpp -o /tmp/sv04next9-t1-ubsan
/tmp/sv04next9-t1-ubsan
if command -v clang++ >/dev/null; then
  clang++ -std=c++11 -O1 -g -fsanitize=address,undefined -fno-sanitize-recover=all -Wall -Wextra -Werror -pedantic tests/test_t1_correlation_audit.cpp -o /tmp/sv04next9-t1-clang
  /tmp/sv04next9-t1-clang
fi
echo 'BLOCK 9 PASS: no automatic parking, no EEPROM, no physical T1 proof.'

# Block 10: read-only native G28 X2/X1 execution evidence, not parking proof.
python3 tests/test_overlay_v14.py
for opt in 0 2; do
  for name in native_idex_homing_trace native_idex_evidence; do
    g++ -std=c++11 -O"${opt}" -Wall -Wextra -Werror -pedantic "tests/test_${name}.cpp" \
       -o "/tmp/sv04-next10-${name}-${opt}"
    "/tmp/sv04-next10-${name}-${opt}"
  done
done
for name in native_idex_homing_trace native_idex_evidence; do
  g++ -std=c++11 -O1 -g -fsanitize=undefined -fno-sanitize-recover=all \
    -Wall -Wextra -Werror -pedantic "tests/test_${name}.cpp" \
    -o "/tmp/sv04-next10-${name}-ubsan"
  "/tmp/sv04-next10-${name}-ubsan"
done
if command -v clang++ >/dev/null; then
  for name in native_idex_homing_trace native_idex_evidence; do
    clang++ -std=c++11 -O1 -g -fsanitize=address,undefined -fno-sanitize-recover=all \
      -Wall -Wextra -Werror -pedantic "tests/test_${name}.cpp" \
      -o "/tmp/sv04-next10-${name}-clang"
    "/tmp/sv04-next10-${name}-clang"
  done
fi
echo 'BLOCK 10 PASS: native G28 X2/X1 homing path trace + read-only evidence; NOT STM32-BUILT.'

# Block 11 (Prüfer-Stand): Negativtests gegen überlebende Mutanten, Plausibilität/Drift, bitbasierter Finite-Check, gehärteter Patch-Einstieg.
python3 tests/test_overlay_v15.py
for opt in 0 2; do
  g++ -std=c++11 -O"${opt}" -Wall -Wextra -Werror -pedantic tests/test_audit11_negative.cpp -o "/tmp/sv04-next11-neg-${opt}"
  "/tmp/sv04-next11-neg-${opt}"
done
g++ -std=c++11 -O1 -g -fsanitize=undefined -fno-sanitize-recover=all -Wall -Wextra -Werror -pedantic tests/test_audit11_negative.cpp -o /tmp/sv04-next11-neg-ubsan
/tmp/sv04-next11-neg-ubsan
g++ -std=c++11 -O1 -g -fsanitize=address,undefined -fno-sanitize-recover=all -Wall -Wextra -Werror -pedantic tests/test_audit11_negative.cpp -o /tmp/sv04-next11-neg-asan
/tmp/sv04-next11-neg-asan
for fl in "-O0" "-O2 -ffast-math" "-O2 -ffinite-math-only -fno-math-errno"; do
  g++ -std=c++11 $fl -Wall -Wextra -Werror -pedantic tests/test_fastmath_native_guard.cpp -o /tmp/sv04-next11-fm
  /tmp/sv04-next11-fm
done
if command -v clang++ >/dev/null; then
  clang++ -std=c++11 -O1 -g -fsanitize=address,undefined -fno-sanitize-recover=all -Wall -Wextra -Werror -pedantic tests/test_audit11_negative.cpp -o /tmp/sv04-next11-neg-clang
  /tmp/sv04-next11-neg-clang
else
  echo "NOT_RUN: clang++ nicht installiert (Clang-Läufe aller Blöcke übersprungen)"
fi
# Block 12: Host-Harness für den vom Overlay ERZEUGTEN G29.cpp-Code (Marlin-Attrappe, Fake-Sensoren, Fehlereinspeisung) und Workflow-Skripte auf synthetischen Repositories.
python3 harness/run_harness.py
if python3 -c "import yaml" 2>/dev/null; then python3 ci/test_workflows.py; else echo "NOT_RUN: PyYAML fehlt: Workflow-Tests in ci/ übersprungen"; fi
# Block 13: auslieferbare Zustandsmaschine Auto60Engine (Simulation gegen simulierte Maschine, echte Belege), Overlay v16. Der E2E-Harness (Maschine + Bruecke + erzeugter G28/G29-Code) laeuft in Block 12.
for opt in 0 2; do
  g++ -std=c++11 -O"${opt}" -Wall -Wextra -Werror -pedantic tests/test_auto60_engine.cpp -o "/tmp/sv04-next-auto60-engine-${opt}"
  "/tmp/sv04-next-auto60-engine-${opt}" | tail -1
done
g++ -std=c++11 -O1 -g -fsanitize=address,undefined -fno-sanitize-recover=all -Wall -Wextra -Werror -pedantic tests/test_auto60_engine.cpp -o /tmp/sv04-next-auto60-engine-asan
/tmp/sv04-next-auto60-engine-asan | tail -1
python3 tests/test_overlay_v16.py
# Block 14: Overlay gegen verschiedene G28-Layouts (beide gemeldeten Fehlerursachen reproduziert), Diagnosewerkzeug, Symbol-Probe, Herkunft der Anker. Alles SYNTHETISCH, kein echtes OEM.
python3 tests/test_overlay_v14_forms.py
python3 tests/test_overlay_diagnose.py
python3 ci/test_symbol_probe.py
python3 tools/anchor_provenance.py | tail -3
# Block 15: Overlay gegen die ECHTEN OEM-Dateien (tests/oem_real/, SHA1 geprueft): strukturelle G28-Topologie, OEM-Erhaltung, Platzierung, CLI aus jedem Arbeitsverzeichnis, Atomaritaet.
python3 tests/test_overlay_real_oem.py
python3 tests/test_shim_compile.py
python3 tools/shim_compile_check.py
# Der ECHTE, gepatchte G29.cpp wird gegen ein Fake-Geraet AUSGEFUEHRT (echte Zickzack-Schleife, OEM-Reset des Meshs, Nachlauf); Welt = Nachbildung, kein Marlin-Build.
python3 harness/run_real_g29.py | tail -1
# Block 16 (Stand 16): elektrische T1-Parkbestaetigung (Schicht v17) auf den ECHTEN OEM-Dateien, Binary-Erreichbarkeitswerkzeug, DWIN/RTS-Karte und D1-Analyse am ECHTEN Quelltext.
python3 tests/test_overlay_v17.py
python3 tests/test_reach_analyze.py
python3 tests/test_dwin_map.py
python3 tests/test_eeprom_audit.py
# Block 17 (Stand 17): T1-Positionsunterscheidung (Real-G29 152 Pruefungen laeuft in Block 15), echte Semantik von set_bed_leveling_enabled/reset_bed_level, VP-Konfliktmatrix,
# A/B-Slot-Entwurf mit Absturzinjektion (Modell, nicht verdrahtet), git-Quellpatch, CI-Auswerter, Workflow-Audit, Endstop-Belegmatrix.
python3 tests/test_dwin_conflicts.py
g++ -std=c++11 -O2 -Wall -Wextra -Werror -pedantic tests/test_mesh_slots.cpp -o /tmp/sv04-next-mesh-slots && /tmp/sv04-next-mesh-slots | tail -1
python3 tests/test_patch_apply.py
python3 tests/test_evaluate_ci.py
python3 tests/test_ci_audit_and_endstops.py
python3 tests/test_android_zip.py
# Block 18 (Stand 18): DWIN-Frameinventar/Statusmodul/Layout/statischer Sicherheits-Scan, Reproduzierbarkeitsstrategie
python3 tests/test_stage18_modules.py
python3 tests/test_repro_compare.py
# Block 19 (Stand 19): Zufallstest der Zustandsmaschine, Ring-Speichermodell, H-Protokoll/DWIN-Spezifikation/SOURCE_DATE_EPOCH
python3 tests/test_fuzz_auto60.py
g++ -std=c++11 -O2 -Wall -Wextra -Werror -pedantic tests/test_mesh_ring.cpp -o /tmp/sv04-next-mesh-ring && /tmp/sv04-next-mesh-ring | tail -1
python3 tests/test_h_protocol_and_spec.py
# --- Stand 20: Hardware-Evidenz (Original-Drucker, 02.11.2026), thermischer Stagnationswaechter, reales 4x4-Mesh ---
python3 tools/hardware_evidence.py --check
python3 tests/test_hw_ground_truth.py
python3 tools/make_ground_truth_doc.py --check
python3 tests/test_mesh_real_crosscheck.py
for opt in 0 2; do
  for name in test_thermal_witness test_thermal_real_trace; do
    g++ -std=c++11 -O"${opt}" -Wall -Wextra -Werror -pedantic "tests/${name}.cpp" -o "/tmp/sv04-next-${name}-${opt}"
    "/tmp/sv04-next-${name}-${opt}" | tail -1
  done
done
python3 tools/mutate_thermal_s20.py | tail -1
echo 'GESAMT: ALLE LOKALEN HOST-TESTS BESTANDEN (Blöcke 1-20 / Stand 20). NOT_RUN: nativer STM32-Build, Hardwaretests, echte GitHub-Läufe. Kein Beweis für Marlin-Kompatibilität oder Sicherheit am Gerät.'
