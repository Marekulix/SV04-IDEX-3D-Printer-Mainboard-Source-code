"""Beweist, dass tools/make_android_zip.py die ZIP-Form der erfolgreich hochgeladenen SV04_NEXT_OVERLAY_20.zip BYTE-GENAU reproduziert (aus dem entpackten Inhalt)."""
import hashlib, sys, tempfile, zipfile
from pathlib import Path
root = Path(__file__).resolve().parents[1]; sys.path[:0] = [str(root / 'tools')]
import make_android_zip as M
n = [0]
def ck(c, m=''): assert c, m; n[0] += 1
orig = root / 'ci-evidence/original-zips-20/SV04_NEXT_OVERLAY_20.zip'; t = Path(tempfile.mkdtemp()); zipfile.ZipFile(orig).extractall(t / 'x'); out = t / 'neu.zip'
cnt = M.make(t / 'x/SV04_NEXT_OVERLAY', out, 'SV04_NEXT_OVERLAY', orig); ck(cnt == 588, cnt)
out2 = t / 'sortiert.zip'; M.make(t / 'x/SV04_NEXT_OVERLAY', out2, 'SV04_NEXT_OVERLAY'); a2, b2 = zipfile.ZipFile(orig), zipfile.ZipFile(out2)
ck(sorted(a2.namelist()) == sorted(b2.namelist()) and all(a2.read(n) == b2.read(n) for n in a2.namelist()) and all((i.date_time, i.external_attr, i.compress_type, i.create_system) == ((2026, 11, 1, 12, 0, 0), 0o644 << 16, 8, 3) for i in b2.infolist()), 'Standard (sortiert): gleicher Inhalt und gleiche Metadaten, nur andere Reihenfolge')
try: M.make(t / 'x/SV04_NEXT_OVERLAY', t / 'q.zip', 'X', Path(t / 'sortiert.zip')); ck(True)
except SystemExit: ck(False, 'gleiche Dateien muessen akzeptiert werden')
h = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest(); ck(h(out) == h(orig) == '1fa6814d481fa13c57c9572114a9e0d2008c7e8e0361947ee47296f9fc379c4c', 'Neuverpackung ist nicht byte-identisch zur hochgeladenen ZIP')
z = zipfile.ZipFile(out); il = z.infolist(); ck(all(i.date_time == M.DATE and i.external_attr == 0o644 << 16 and i.create_system == 3 and i.compress_type == 8 and not i.filename.endswith('/') for i in il), 'Metadaten')
ck(z.testzip() is None, 'CRC'); ck(b2.namelist() == sorted(b2.namelist()), 'Standardreihenfolge ist sortiert und deterministisch')
print(f'PASS Android-ZIP-Form: {n[0]} Pruefungen (Neuverpackung des entpackten Overlays ist BYTE-IDENTISCH zur erfolgreich hochgeladenen SV04_NEXT_OVERLAY_20.zip, sha256 1fa6814d..., mit Reihenfolge der Referenz); Ursache der frueheren Upload-Fehler bleibt unbewiesen')
