"""Test der DWIN/RTS-Karte am ECHTEN LCD_RTS.h/.cpp: Fakten, Konsistenz, 'nichts erfunden' und Erkennung von Inkonsistenzen. Stufe: Textanalyse (Simulation), KEINE Displayprobe."""
import json, re, sys
from pathlib import Path
root = Path(__file__).resolve().parents[1]; sys.path[:0] = [str(root / 'tools')]
import dwin_map as D
n = [0]
def ck(c, m=''): assert c, m; n[0] += 1
H = (root / 'tests/oem_real_headers/Marlin/src/lcd/e3v2/creality/LCD_RTS.h').read_text(encoding='utf-8'); C = (root / 'tests/oem_real/Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp').read_text(encoding='utf-8')
m = D.parse(H, C); K = {k['key']: k for k in m['keys']}
ck(m['problems'] == [] and len(m['keys']) == 35 and len(m['vps']) == 86, (m['problems'], len(m['keys']), len(m['vps'])))
ck(m['vps']['BED_SET_TEMP_VP']['addr'] == 0x103A and m['vps']['BED_CURRENT_TEMP_VP']['addr'] == 0x103C and m['vps']['AUTO_BED_LEVEL_ICON_VP']['addr'] == 0x108D and m['vps']['AUTO_BED_LEVEL_1POINT_VP']['addr'] == 0x1100, 'bekannte VP-Adressen')
ck(K['BedLevelFunKey']['addr'] == 0x1044 and K['BedLevelFunKey']['index'] == 14 and K['BedLevelFunKey']['handler']['data_values'] == list(range(1, 12)), 'BedLevelFunKey')
ck('G28' in ' '.join(K['BedLevelFunKey']['handler']['enqueues'] + K['SettingScreenKey']['handler']['enqueues']), 'G28 im Bettmenue')
ck('G29 U' not in json.dumps(m), 'das Overlay-G29-U darf in keiner OEM-Taste vorkommen')
ck(K['StoreMemoryKey']['handler']['mentions_eeprom_save'] and K['SaveEEPROM']['handler']['mentions_eeprom_save'], 'EEPROM-Tasten des OEM erkannt')
ck([o['key'] for o in m['overlaps_with_point_values']] == ['ChangePageKey'] and m['overlaps_with_point_values'][0]['collides_with_point_value'] == 8, 'Ueberlappung')
ck(sorted(k['key'] for k in m['keys'] if not k['handler']) == ['SelectLanguageKey', 'ZOffsetKey', 'ZhotendOffsetKey'], 'Tasten ohne case')
# nichts erfunden: jede Adresse der Karte steht woertlich im Quelltext
hex_in_h = {int(x, 16) for x in re.findall(r'0[xX]([0-9A-Fa-f]{3,4})\b', H)}
ck(all(v['addr'] in hex_in_h for v in list(m['vps'].values()) + list(m['vps_commented_out'].values())) and all(k['addr'] in hex_in_h for k in m['keys']), 'Adresse ohne Quelltextbeleg')
ck(all(1 <= v['line'] <= H.count('\n') + 1 for v in m['vps'].values()) and all(k['handler'] is None or 1 <= k['handler']['lines'][0] <= k['handler']['lines'][1] <= C.count('\n') + 1 for k in m['keys']), 'Zeilenbelege')
# Inkonsistenzen werden erkannt
bad = D.parse(H.replace('  0x1002,\n', '', 1), C); ck(any('verschieden lang' in p for p in bad['problems']), 'Laengenabweichung muss auffallen')
bad = D.parse(H.replace('  0x1004,\n', '  0x1002,\n', 1), C); ck(any('doppelte' in p for p in bad['problems']), 'doppelte Adresse muss auffallen')
md = D.render_md(m); ck('BLOCKIERT' in md and 'Schaltflaeche "Bettvermessung 60 C"' in md and 'Display-Projekt' in md and '0x110E' in md, 'Markdown')
# die ausgelieferte Datei entspricht der Neuerzeugung
dj = json.loads((root / 'docs/DWIN_VP_MAP.json').read_text(encoding='utf-8')); ck(dj == json.loads(json.dumps(m)) and (root / 'docs/DWIN_VP_MAP.md').read_text(encoding='utf-8') == md, 'docs/DWIN_VP_MAP.* nicht aktuell')
print(f'PASS DWIN/RTS-Karte am ECHTEN LCD_RTS: {n[0]} Pruefungen (86 VPs, 35 Tasten, Handler, Ueberlappung, nichts erfunden, Inkonsistenzerkennung); Textanalyse, KEINE Displayprobe')
