"""Test der VP-Konfliktmatrix am ECHTEN LCD_RTS (inkl. Overlay-Nutzung) und ihrer Negativfaelle. Stufe: Textanalyse, KEINE Displayprobe."""
import json, sys
from pathlib import Path
root = Path(__file__).resolve().parents[1]; sys.path[:0] = [str(root / 'tools'), str(root / 'integration')]
import dwin_conflicts as C, apply_native_guard_v17 as v17
n = [0]
def ck(c, m=''): assert c, m; n[0] += 1
H = (root / 'tests/oem_real_headers/Marlin/src/lcd/e3v2/creality/LCD_RTS.h').read_text(encoding='utf-8'); CP = (root / 'tests/oem_real/Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp').read_text(encoding='utf-8')
real = root / 'tests/oem_real'; v14 = v17.v15.v14; orig = {k: (real / k).read_text(encoding='utf-8') for k in v14.OEM_BLOBS}
out = v17.render(dict(orig), *[(root / 'include' / h).read_text(encoding='utf-8') for h in v17.HEADERS]); patched = {k: (orig[k], out[k]) for k in orig if k.endswith(('LCD_RTS.cpp', 'G29.cpp', 'G28.cpp'))}
r = C.analyze(H, CP, patched); f = r['families']
ck(len(f) == 1 and f[0]['prefix'] == 'AUTO_BED_LEVEL' and f[0]['count'] == 16 and f[0]['first'] == 0x1100 and f[0]['last'] == 0x111E and f[0]['stride'] == [2] and f[0]['regular'], 'Messpunkt-Familie')
ck([(k['key'], k['point'], k['exact_slot']) for k in r['keys_inside_value_families']] == [('ChangePageKey', 8, True)], 'einzige Taste im Wertebereich: ChangePageKey = Punkt 8')
ck(r['alias'] == {} and r['map_problems'] == [], 'keine Alias-Adressen, Karte konsistent')
o = r['overlay_use']; ck(o['only_existing_vps'] and o['vps_used_by_inserted_code'] == ['AUTO_BED_LEVEL_1POINT_VP', 'AUTO_BED_LEVEL_ICON_VP'] and o['unknown_or_literal'] == [], 'Overlay benutzt nur vorhandene OEM-VPs')
# Negativfaelle: erfundene VP und eigenes Adressliteral im eingefuegten Code muessen auffallen
bad = dict(patched); k = next(x for x in bad if x.endswith('LCD_RTS.cpp')); bad[k] = (bad[k][0], bad[k][1].replace('AUTO_BED_LEVEL_ICON_VP', 'AUTO_BED_LEVEL_FAKE_START_VP', 1)); ob = C.analyze(H, CP, bad)['overlay_use']; ck(not ob['only_existing_vps'] and ob['unknown_or_literal'][0][2] == 'AUTO_BED_LEVEL_FAKE_START_VP', 'erfundene VP muss auffallen')
bad2 = dict(patched); bad2[k] = (bad2[k][0], bad2[k][1].replace('AUTO_BED_LEVEL_ICON_VP', '0x1200', 1)); ob2 = C.analyze(H, CP, bad2)['overlay_use']; ck(not ob2['only_existing_vps'] and ob2['unknown_or_literal'][0][2] == '0x1200', 'Adressliteral muss auffallen')
# Pruefung vorgeschlagener Adressen: Konflikte werden benannt, das Werkzeug schlaegt nichts vor
ck('KONFLIKT' in C.check(r, '0x110E')['verdict'] and 'Familie AUTO_BED_LEVEL' in ' '.join(C.check(r, '0x110E')['conflicts_in_known_map']) and 'Tastenadresse ChangePageKey' in ' '.join(C.check(r, '0x110E')['conflicts_in_known_map']), '0x110E')
ck('KONFLIKT' in C.check(r, '0x1100')['verdict'] and 'KONFLIKT' in C.check(r, '0x111F')['verdict'], 'Familienrand und Folgewort')
ck('NICHT belegt' in C.check(r, '0x3FFF')['verdict'] and 'KONFLIKT' not in C.check(r, '0x3FFF')['verdict'], 'unbekannte Adresse: nie "frei" behaupten')
ck('vorschlag' not in json.dumps(C.check(r, '0x3FFF')).lower().replace('vorgeschlagen', ''), 'kein Vorschlag')
md = C.render_md(r); ck('ChangePageKey' in md and 'nur vorhandene OEM-VPs' in md and 'NICHT vor' in md, 'Markdown')
pub = {k: v for k, v in r.items() if not k.startswith('_')}; ck(json.loads((root / 'docs/DWIN_VP_KONFLIKTMATRIX.json').read_text(encoding='utf-8')) == json.loads(json.dumps(pub)) and (root / 'docs/DWIN_VP_KONFLIKTMATRIX.md').read_text(encoding='utf-8') == md, 'docs nicht aktuell')
print(f'PASS DWIN-Konfliktmatrix am ECHTEN LCD_RTS: {n[0]} Pruefungen (1 Familie, ChangePageKey = Messpunkt 8, Overlay nutzt nur vorhandene VPs, Negativfaelle erfundene VP/Adressliteral, Adresspruefung ohne Vorschlag); Textanalyse, KEINE Displayprobe')
