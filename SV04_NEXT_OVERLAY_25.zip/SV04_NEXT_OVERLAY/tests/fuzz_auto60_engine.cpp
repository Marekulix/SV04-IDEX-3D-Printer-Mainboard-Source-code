// Zufallstest (Fuzz) der Zustandsmaschine Auto60Engine. SIMULATION, kein Geraet. Modus 0 = kooperative Maschine mit Stoerungen, Modus 1 = vollstaendig zufaellige Beobachtungen.
// Alle Invarianten sind aus dem Quelltext der Maschine abgeleitet und muessen fuer JEDE Eingabefolge gelten.
#include "../include/SV04NextAuto60Engine.hpp"
#include <cstdio>
#include <cstdlib>
#include <cmath>
#ifndef G28_PHASES
#define G28_PHASES 6          // Anzahl der Werte von G28PassiveReceipt::Phase; tests/test_fuzz_auto60.py prueft, dass dieser Standard der echten Enum-Groesse entspricht
#endif
#ifndef G29_FAILURES
#define G29_FAILURES 12       // Anzahl der Werte von G29UReceipt::Failure (gleiche Pruefung)
#endif
using namespace sv04next;
using E = Auto60Engine; using St = E::State; using Ac = E::Action; using Rs = E::Reason;
static uint64_t S;
static uint32_t rnd() { S ^= S << 13; S ^= S >> 7; S ^= S << 17; return (uint32_t)(S >> 11); }
static bool chance(int permille) { return (int)(rnd() % 1000) < permille; }
static int g_noise = 1;                                           // Modus 2: 25-fache Stoerrate
static bool rare(int per10000) { return (int)(rnd() % 10000) < per10000 * g_noise; }   // Stoerungen mit Wahrscheinlichkeit pro 10000
static bool term(St s) { return s == St::Done || s == St::DoneRamOnly || s == St::AbortLocked; }
static bool active(St s) { return s != St::Idle && !term(s); }
static int viol = 0; static uint32_t g_step = 0; static int g_mode = 0;
#define V(cond, msg) do { if (!(cond)) { if (viol < 12) std::printf("VERLETZUNG modus %d schritt %u: %s\n", g_mode, g_step, msg); ++viol; } } while (0)
struct Log { int set60 = 0, off = 0, home = 0, meas = 0, commit = 0; float z0 = 0; uint32_t t_heat = 0; bool seen60 = false; };
static G28PassiveReceipt::Phase g28ph() { return (G28PassiveReceipt::Phase)(rnd() % G28_PHASES); }
static G29UReceipt::Phase g29ph() { return (G29UReceipt::Phase)(rnd() % 5); }
static G29UReceipt::Failure g29f() { return (G29UReceipt::Failure)(rnd() % G29_FAILURES); }
static float fl(float lo, float hi) { return lo + (hi - lo) * (float)(rnd() % 10001) / 10000.0f; }
static float wild() { switch (rnd() % 8) { case 0: return NAN; case 1: return INFINITY; case 2: return -INFINITY; case 3: return 60.0f; case 4: return 65.0f; case 5: return 59.99f; default: return fl(-20.0f, 120.0f); } }
static void randomize(E::Obs &o, bool wildmode) {
  o.stopped = wildmode ? chance(500) : rare(8); o.printing = wildmode ? chance(500) : rare(8); o.paused = wildmode ? chance(500) : rare(5); o.motion_queued = wildmode ? chance(500) : rare(30); o.queue_busy = wildmode ? chance(500) : rare(30);
  o.tool0 = wildmode ? chance(500) : !rare(10); o.dual_auto_park = wildmode ? chance(500) : !rare(10); o.xyz_trusted = wildmode ? chance(500) : !rare(20); o.leveling_active = wildmode ? chance(500) : !rare(20); o.thermal_ready = chance(wildmode ? 500 : 600); o.thermal_safe = wildmode ? chance(500) : !rare(15);
  o.t1_parked_electrically = wildmode ? chance(500) : !rare(15); o.user_abort = wildmode ? chance(100) : rare(4); o.user_ack = chance(wildmode ? 300 : 120); o.eeprom_commit_supported = chance(wildmode ? 500 : 500);
  o.g28_phase = g28ph(); o.g29_phase = g29ph(); o.g29_failure = g29f(); o.g29_completed = (uint8_t)(wildmode ? rnd() % 256 : rnd() % 17); o.g28_trusted = chance(900); o.g28_tool0 = chance(900); o.eeprom = (E::Eeprom)(rnd() % 4);
  if (wildmode) { o.bed_c = wild(); o.bed_target_c = wild(); o.probe_offset_z = chance(300) ? wild() : -1.10f; o.g28_seq = rnd() % 6; o.g29_seq = rnd() % 6; o.g28_ended_ms = rnd(); }
}
int main(int argc, char **argv) {
  uint64_t seed = argc > 1 ? strtoull(argv[1], nullptr, 10) : 1; int mode_arg = argc > 2 ? atoi(argv[2]) : 0; g_mode = mode_arg == 1 ? 1 : 0; g_noise = mode_arg == 2 ? 25 : 1; uint32_t steps = argc > 3 ? (uint32_t)strtoul(argv[3], nullptr, 10) : 200000u; S = seed * 0x9E3779B97F4A7C15ull + 88172645463325252ull;
  E::Config cfg; cfg.auto_commit = false; E eng(cfg); E::Obs o; o.now_ms = 1000; Log lg; bool pending_off = false; long st_cov[16] = {0}, rs_cov[64] = {0}; long runs = 0, done = 0, doneram = 0, aborts = 0, idle_after = 0;
  // Stoerungen: G29 bleibt auf Running haengen, EEPROM antwortet nie, die Bruecke meldet ActionFailed
  float tgt_cmd = 0; int delay = 0; Ac last = Ac::None; bool stuck_g29 = false, commit_hang = false, notified = false, lev_off = false, no_ack = false, t1_off = false, commit_ok = true; float off_shift = 0.0f; float bed = 25.0f; uint32_t g28s = 0, g29s = 0; E::Obs env; env.stopped = false; env.printing = false; env.paused = false; env.motion_queued = false; env.queue_busy = false; env.tool0 = true; env.dual_auto_park = true; env.xyz_trusted = true; env.leveling_active = true; env.thermal_safe = true; env.t1_parked_electrically = true; env.eeprom_commit_supported = true; env.probe_offset_z = -1.10f; env.bed_c = bed; env.bed_target_c = 0;
  for (g_step = 0; g_step < steps; ++g_step) {
    St before = eng.view().state;
    if (before == St::Idle && chance(40)) {
      if (eng.request_start()) { ++runs; lg = Log(); pending_off = false; stuck_g29 = commit_hang = notified = lev_off = false; t1_off = false; off_shift = 0.0f; no_ack = chance(250); commit_ok = chance(600); }
    }
    if (chance(8)) {                                             // Doppelstart zu jeder Zeit: darf einen laufenden Ablauf nie veraendern; beginnt er in Idle einen NEUEN Lauf, wird das Protokoll zurueckgesetzt
      St s0 = eng.view().state; uint8_t p0 = eng.view().progress; bool st = eng.request_start();
      if (st) { ++runs; lg = Log(); pending_off = false; stuck_g29 = commit_hang = notified = lev_off = false; t1_off = false; off_shift = 0.0f; no_ack = chance(250); commit_ok = chance(600); }
      if (!st && s0 != St::Idle) { V(eng.view().state == s0 && eng.view().progress == p0, "Doppelstart hat einen laufenden Ablauf veraendert"); }
    }
    o = env; o.now_ms += (rare(3) ? 600000u : 50u + rnd() % 2000u); env.now_ms = o.now_ms;
    if (g_mode == 0) {                                          // kooperative Umgebung: reagiert auf die zuletzt gelieferte Aktion, mit zufaelligen Stoerungen
      if (last == Ac::SetBed60) { tgt_cmd = rare(80) ? 0.0f : 60.0f; delay = (int)(rnd() % 4); }   /* gelegentlich ignoriert die Heizung den Befehl */ if (last == Ac::SetBedOff) tgt_cmd = 0.0f;
      if (last == Ac::Home) { g28s += 1; env.g28_seq = g28s; env.g28_phase = chance(900) ? G28PassiveReceipt::Phase::EndObservedTrusted : g28ph(); env.g28_trusted = !rare(300); env.g28_tool0 = !rare(200); env.g28_ended_ms = rare(40) ? o.now_ms - (130000u + rnd() % 300000u) : o.now_ms; }
      if (last == Ac::Home && rare(60)) { off_shift = fl(0.01f, 0.3f); }
      if (last == Ac::Home && rare(60)) { t1_off = true; }
      if (last == Ac::Measure) { g29s += 1; env.g29_seq = g29s; env.g29_phase = chance(920) ? G29UReceipt::Phase::RamOnlySuccess : g29ph(); env.g29_completed = env.g29_phase == G29UReceipt::Phase::RamOnlySuccess ? 16 : (uint8_t)(rnd() % 17); env.g29_failure = g29f(); if (rare(60)) { lev_off = true; }
        if (rare(60)) { stuck_g29 = true; env.g29_phase = G29UReceipt::Phase::Running; env.g29_completed = (uint8_t)(rnd() % 16); } }
      if (stuck_g29) { env.now_ms += 120000u; o.now_ms = env.now_ms; env.g29_phase = G29UReceipt::Phase::Running; }
      if (last == Ac::Commit) { commit_hang = rare(1500); env.eeprom = commit_hang ? E::Eeprom::Unknown : (chance(900) ? E::Eeprom::ReadbackMatch : (E::Eeprom)(1 + rnd() % 3)); }
      if (commit_hang) { env.eeprom = E::Eeprom::Unknown; env.now_ms += 10000u; o.now_ms = env.now_ms; }
      env.bed_target_c = tgt_cmd; if (delay > 0) --delay; if (tgt_cmd > 0 && delay == 0) { if (bed < tgt_cmd - 1.0f) bed += 5.0f; else bed = tgt_cmd + fl(-0.4f, 0.4f); } else if (tgt_cmd == 0.0f) bed -= 2.0f; if (bed < 22.0f) bed = 22.0f; env.bed_c = rare(5) ? bed + 8.0f : bed; env.thermal_ready = tgt_cmd == 60.0f && bed > 58.5f && bed < 61.5f && delay == 0; env.thermal_safe = !rare(10);
      o = env; o.now_ms = env.now_ms; randomize(o, false); o.bed_c = env.bed_c; o.bed_target_c = rare(8) ? wild() : env.bed_target_c; o.thermal_ready = env.thermal_ready && !rare(30); o.g28_seq = env.g28_seq; o.g29_seq = env.g29_seq; o.eeprom = env.eeprom;
      if (!rare(300)) { o.stopped = false; o.printing = false; o.paused = false; o.motion_queued = false; o.queue_busy = false; } o.probe_offset_z = rare(5) ? -1.10f + fl(-0.5f, 0.5f) : -1.10f; if (!rare(200)) { o.tool0 = true; o.dual_auto_park = true; o.xyz_trusted = true; o.t1_parked_electrically = true; o.leveling_active = true; o.thermal_safe = true; }
      if (!rare(100)) { o.g28_phase = env.g28_phase; o.g28_trusted = env.g28_trusted; o.g28_tool0 = env.g28_tool0; o.g28_ended_ms = env.g28_ended_ms; o.g29_phase = env.g29_phase; o.g29_completed = env.g29_completed; o.g29_failure = env.g29_failure; }
      if (!rare(300)) { o.user_abort = false; }
      if (lev_off) { o.leveling_active = false; }
      if (t1_off) { o.t1_parked_electrically = false; }
      o.eeprom_commit_supported = commit_ok;   // feste Eigenschaft des Laufs (nicht pro Tick gewuerfelt)
      o.probe_offset_z += off_shift;
      if (no_ack && !term(eng.view().state)) { o.user_ack = false; }   // nur bis zum Ende des Laufs: im Endzustand braucht die Maschine die Quittung fuer die Rueckkehr nach Idle
      if (rare(40)) { o.g29_completed = (uint8_t)(rnd() % 256); }   // adversarial: Beobachtung ueber 16 Punkte
    } else { randomize(o, true); env.now_ms = o.now_ms; }
    St pre = eng.view().state; const bool was_notified = notified; notified = false; bool pre_pending = pending_off; const bool heater_was_on = lg.set60 > lg.off; Ac a = eng.tick(o); E::View v = eng.view(); last = a;
    if (a != Ac::None && rare(8)) { eng.notify_action_failed(); notified = true; }
    ++st_cov[(int)v.state]; if (v.reason != Rs::None) ++rs_cov[(int)v.reason];
    // --- Invarianten ---
    if (a == Ac::SetBed60 || a == Ac::Home || a == Ac::Measure || a == Ac::Commit) {
      V(!o.stopped && !o.printing && !o.paused, "Aktion bei Stopp/Druck/Pause");
      V(std::isfinite(o.bed_c) && o.bed_c < cfg.overshoot_c, "Aktion bei nicht endlicher oder zu heisser Betttemperatur");
      V(std::isfinite(o.bed_target_c) && std::isfinite(o.probe_offset_z), "Aktion bei nicht endlicher Beobachtung");
    }
    if (a == Ac::SetBed60) { V(lg.set60 == 0, "SetBed60 zweimal im Lauf"); V(pre == St::Precheck, "SetBed60 ausserhalb von Precheck"); V(o.tool0 && o.dual_auto_park, "SetBed60 ohne Werkzeug 0/Auto-Park"); V(!o.motion_queued && !o.queue_busy, "SetBed60 bei laufender Bewegung"); ++lg.set60; lg.z0 = o.probe_offset_z; lg.t_heat = o.now_ms; lg.seen60 = false; }
    if (a == Ac::Home) { V(lg.home == 0 && lg.set60 == 1, "Home doppelt oder ohne Heizbefehl"); V(o.bed_target_c == 60.0f && o.thermal_safe, "Home ohne Soll 60/thermisch sicher"); ++lg.home; }
    if (a == Ac::Measure) { V(lg.meas == 0 && lg.home == 1, "Messen doppelt oder ohne Home"); V(o.t1_parked_electrically, "MESSEN ohne elektrische T1-Bestaetigung"); V(o.xyz_trusted && o.tool0 && o.dual_auto_park, "Messen ohne Vertrauen/Werkzeug 0/Auto-Park"); V(o.thermal_ready && o.thermal_safe && o.bed_target_c == 60.0f, "Messen ohne stabile 60 C"); V(std::fabs(o.probe_offset_z - lg.z0) <= 0.00001f, "Messen bei geaendertem Z-Offset"); ++lg.meas; }
    if (a == Ac::Commit) { V(lg.commit == 0 && lg.meas == 1, "Commit doppelt oder ohne Messung"); V(o.eeprom_commit_supported, "Commit ohne Unterstuetzung"); V(cfg.auto_commit || o.user_ack, "COMMIT OHNE QUITTUNG"); ++lg.commit; }
    if (a == Ac::SetBedOff) { V(lg.off == 0 && lg.set60 == 1, "SetBedOff doppelt oder ohne vorheriges Heizen"); ++lg.off; }
    if (term(pre)) V(a == Ac::None || a == Ac::SetBedOff, "andere Aktion als Heizer-aus im Endzustand");
    if (pre_pending && term(pre)) { V(a == Ac::SetBedOff, "Heizer nicht sofort im naechsten Tick ausgeschaltet"); }
    pending_off = term(v.state) && lg.set60 > lg.off;
    if (active(pre) && v.state == St::AbortLocked && heater_was_on) { V(a == Ac::SetBedOff, "Abbruch schaltet den Heizer nicht SOFORT aus"); }
    if (active(pre) && o.user_abort && !was_notified) { V(v.state == St::AbortLocked && v.reason == Rs::UserAbort, "Abbruch durch den Benutzer wirkt nicht sofort"); }   // ein gemeldeter Befehlsfehler hat Vorrang (Zeile 51 der Maschine)
    if (active(pre) && o.stopped) V(v.state == St::AbortLocked, "Stopp wirkt nicht sofort");
    if (active(pre) && (!std::isfinite(o.bed_c) || !std::isfinite(o.bed_target_c) || !std::isfinite(o.probe_offset_z))) V(v.state == St::AbortLocked, "nicht endliche Beobachtung fuehrt nicht zum Abbruch");
    if (active(pre) && std::isfinite(o.bed_c) && o.bed_c >= cfg.overshoot_c) V(v.state == St::AbortLocked, "Ueberhitzung fuehrt nicht zum Abbruch");
    if ((pre == St::TempStable || pre == St::HomeG28 || pre == St::VerifyHome || pre == St::MeasureG29) && (!o.thermal_safe || o.bed_target_c != 60.0f)) { V(v.state == St::AbortLocked, "Verlust von Soll 60/thermischer Sicherheit waehrend Home/Messen bricht nicht sofort ab"); }
    if ((pre == St::TempStable || pre == St::HomeG28 || pre == St::VerifyHome || pre == St::MeasureG29 || pre == St::VerifyLeveling) && (o.printing || o.paused)) { V(v.state == St::AbortLocked, "Druck/Pause waehrend der Messkette bricht nicht sofort ab"); }
    if (was_notified && active(pre)) { V(v.state == St::AbortLocked && v.reason == Rs::ActionFailed, "gemeldeter Befehlsfehler fuehrt nicht zum Abbruch ActionFailed"); }
    if (pre == St::Heat60 && !lg.seen60 && o.bed_target_c != 60.0f && (uint32_t)(o.now_ms - lg.t_heat) > cfg.target_apply_ms) { V(v.state == St::AbortLocked, "Soll 60 wird nach der Frist nie gesehen, aber die Maschine bricht nicht ab"); }
    if (pre == St::Heat60 && o.bed_target_c == 60.0f) { lg.seen60 = true; }
    V(v.progress <= 16, "Fortschritt ueber 16");
    if (v.state == St::Idle && pre != St::Idle) { ++idle_after; V(lg.off == lg.set60, "Idle erreicht, obwohl der Heizer nicht ausgeschaltet wurde"); }
    if (v.state == St::Done) { ++done; }
    if (v.state == St::DoneRamOnly) { ++doneram; }
    if (v.state == St::AbortLocked && pre != St::AbortLocked) { ++aborts; }
    if (term(pre) && !term(v.state) && v.state != St::Idle) V(false, "Endzustand verlassen ohne Idle");
  }
  std::printf("FUZZ seed %llu modus %d: %u Schritte, %ld Laeufe, Done %ld, DoneRamOnly %ld, Abbrueche %ld, Idle danach %ld, Verletzungen %d\n", (unsigned long long)seed, mode_arg, steps, runs, done, doneram, aborts, idle_after, viol);
  std::printf("ZUSTAENDE"); for (int i = 0; i < 15; ++i) std::printf(" %ld", st_cov[i]); std::printf("\nGRUENDE"); for (int i = 0; i < 40; ++i) std::printf(" %ld", rs_cov[i]); std::printf("\n");
  return viol ? 1 : 0;
}
