"""Test der D1-Analyse am ECHTEN settings.cpp (aus dem CI-18-Diagnoseartefakt): Tatsachen mit Zeilen, Folgerung kippt ohne Tatsachen, ausgelieferte Dokumente aktuell. Textanalyse, KEIN EEPROM-Zugriff."""
import json, sys
from pathlib import Path
root = Path(__file__).resolve().parents[1]; sys.path[:0] = [str(root / 'tools')]
import eeprom_audit as E
n = [0]
def ck(c, m=''): assert c, m; n[0] += 1
S = (root / 'ci-evidence/18-diagnose/diagnose/oem-headers/Marlin/src/module/settings.cpp').read_text(encoding='utf-8'); C = (root / 'tests/oem_real/Marlin/Configuration.h').read_text(encoding='utf-8')
r = E.audit(S, C); f = r['facts']; c = r['conclusion']
ck(all(v['found'] for v in f.values()), [k for k, v in f.items() if not v['found']])
ck(f['version_placeholder_ERR']['line'] < f['header_written_first_unless_flash']['line'] < f['final_header_only_without_error']['line'] < f['final_header_written_last']['line'] < f['finish_after_header']['line'], 'Reihenfolge in save()')
ck(f['final_header_written_last']['line'] > f['mesh_written_in_save']['line'], 'der echte Header folgt dem Mesh')
ck(c['failed_or_interrupted_save_invalidates_stored_image'] and not c['old_mesh_survives_failed_save'] and 'NICHT erfuellbar' in c['catalog_clause_never_overwrite_old_mesh_on_error'], 'Folgerung')
ck(c['readback_possible'] and 'NICHT das Mesh' in c['readback_strength'], 'Readback-Staerke')
ck(f['auto_init_disabled']['found'] and f['failed_load_resets_everything']['found'], 'AUTO_INIT/reset')
# Folgerung kippt, wenn die Tatsachen fehlen (sie ist nicht hartkodiert)
r2 = E.audit(S.replace('char ver[4] = "ERR";', 'char ver[4] = "OKK";'), C); ck(not r2['conclusion']['failed_or_interrupted_save_invalidates_stored_image'] and r2['conclusion']['old_mesh_survives_failed_save'] and r2['conclusion']['catalog_clause_never_overwrite_old_mesh_on_error'] == 'unbelegt', 'ohne ERR-Header darf keine Folgerung stehen')
r3 = E.audit(S.replace('if (!eeprom_error) {\n      const uint16_t eeprom_size', 'if (true) {\n      const uint16_t eeprom_size'), C); ck(not r3['facts']['final_header_only_without_error']['found'], 'Fehlerbedingung muss gefunden werden')
r4 = E.audit(S, C.replace('//#define EEPROM_AUTO_INIT', '#define EEPROM_AUTO_INIT')); ck(not r4['facts']['auto_init_disabled']['found'], 'AUTO_INIT eingeschaltet muss auffallen')
ck(json.loads((root / 'docs/D1_EEPROM_FAKTEN.json').read_text(encoding='utf-8')) == json.loads(json.dumps(r)) and (root / 'docs/D1_EEPROM_ANALYSE.md').read_text(encoding='utf-8') == E.render_md(r), 'docs/D1_* nicht aktuell')
print(f'PASS D1-EEPROM-Analyse am ECHTEN settings.cpp: {n[0]} Pruefungen (13 belegte Tatsachen mit Zeilen, Folgerung kippt ohne Tatsachen); Textanalyse, KEIN EEPROM-Zugriff')
