"""Test des CI-Auswerters: ECHTE CI-18-Archive (Stand 15 gruen, aber NICHT als Stand 16 wertbar) und gezielt zerstoerte Kopien (SKIPPED, Exit 1, falscher Block, fehlende Hashes, Reichweite verletzt, Reproduzierbarkeit)."""
import json, shutil, subprocess, sys, tempfile
from pathlib import Path
root = Path(__file__).resolve().parents[1]; sys.path[:0] = [str(root / 'tools')]
import evaluate_ci_artifacts as E
n = [0]
def ck(c, m=''): assert c, m; n[0] += 1
REG = {'overlays': {'stand15': {'sha256': '5bc56e75940892ab74ed90ef70a7c36bcdd91fc4c2e2d6d268ddb3bddfc29b05'}, 'stand16': {'sha256': '21096d27431f6ea2fc49fb7f9856111de2756174e1f94d6a95ef5088f23bbf38'}, 'stand17': {'sha256': 'a' * 64}, 'stand17_repack20': {'sha256': '1fa6814d481fa13c57c9572114a9e0d2008c7e8e0361947ee47296f9fc379c4c', 'stand': 'stand17'}}}
ev = root / 'ci-evidence'
o = E.evaluate(ev, '18', REG, '15'); ck(o['all_builds_green'] and [x['stand_built'] for x in o['variants'] if x['variant'].startswith('overlay')] == ['stand15', 'stand15'], 'echte CI 18: alle vier Builds gruen und Stand 15')
ck(o['diagnose']['ok'] and o['diagnose']['oem_all_match'] and o['diagnose']['strict_dry_run_ok'] and o['diagnose']['git_head'], 'echte Diagnose von CI 18: OEM 5/5, strenger Trockenlauf ok, Commit vorhanden')
ck(o['overall'].startswith('NICHT GRUEN') and not o['host_tests']['ok'] and not o['commit_consistent'], 'ohne Host-Test-Artefakt und ohne Commit-SHA darf es nicht "gruen" heissen')
o16 = E.evaluate(ev, '18', REG, '16'); ck(not o16['all_builds_green'] and all('Stand gebaut == erwarteter Stand' in [k for k, v in x['checks'].items() if not v] for x in o16['variants'] if x['variant'].startswith('overlay')), 'CI 18 darf NICHT als Stand 16 gelten')
ck(any('NICHT als Stand 16 werten' in ' '.join(x['notes']) for x in o16['variants']), 'Hinweis auf den tatsaechlich gebauten Stand')
ck(E.evaluate(ev, '18', {'overlays': {}}, '15')['variants'][2]['stand_built'] is None, 'unbekannter Hash: Stand unbekannt (nie raten)')
# ECHTE Workflow-20-Artefakte (Stand 17, inhaltsgleich neu gepackte ZIP als Alias): baseline/probe/overlay gruen, Auto60 durch Infrastrukturfehler UNBEWIESEN
o20 = E.evaluate(ev, '20', REG, '17'); vs = {x['variant']: x for x in o20['variants']}
ck([vs[v]['verdict'] for v in ('baseline', 'probe', 'overlay')] == ['BAU GRUEN'] * 3 and all(vs[v]['stand_built'] == 'stand17' for v in ('overlay', 'overlay-auto60')), 'echte CI 20: drei Builds gruen, gebauter Stand 17 (Alias)')
ck(vs['overlay-auto60']['verdict'] == 'UNBEWIESEN (Infrastrukturfehler)' and vs['overlay-auto60'].get('infra_error') and not vs['overlay-auto60']['build_ok'], 'echte CI 20: Auto60 ist Infrastrukturfehler, NICHT gruen und kein Codefehler')
ck(o20['overall'].startswith('NICHT GRUEN') and not o20['all_builds_green'], 'echte CI 20: Gesamt nicht gruen, solange Auto60 fehlt')
ck(o20['host_tests']['ok'] and o20['commit_consistent'] and o20['diagnose']['ok'] and o20['commits'] == ['840143cd691ecb2d204d8e3a9376571be0467831'], 'echte CI 20: Host-Tests, Commit, Diagnose')
ck(o20['reach_summary'] == {'baseline': 'OK', 'probe': 'OK', 'overlay': 'OK', 'overlay-auto60': 'NICHT GELAUFEN (keine ELF/Binutils)'}, o20['reach_summary'])
ck(vs['baseline']['repro'] == {'result': 'VERSCHIEDEN', 'diff_bytes': '2'}, 'echte CI 20: Baseline nicht hashgleich, genau 2 Byte Unterschied')
ck(E.evaluate(ev, '20', {'overlays': {'stand17': {'sha256': 'a' * 64}}}, '17')['variants'][2]['stand_built'] is None, 'ohne Alias im Register: gebauter Stand unbekannt')
# synthetische Stand-17-Artefakte: vollstaendig gruen, dann gezielte Zerstoerung
def synth(tmp, stand_sha='a' * 64, layer=17, host='0'):
    for v in E.VARIANTS:
        d = tmp / f'19-build-{v}'; d.mkdir(parents=True)
        (d / 'variant.txt').write_text(v); (d / 'build.exit').write_text('0'); (d / 'build.log').write_text('...\n[SUCCESS] Took 100 s\n'); (d / 'firmware.sha256').write_text('b' * 64 + '  .pio/build/x/firmware.bin\n'); (d / 'firmware.size').write_text('-rwxr-xr-x 1 runner runner 162272 Oct 31 .pio/build/x/firmware.bin\n')
        (d / 'oem-blobs.ok').write_text('1'); (d / 'overlay-zip.sha256').write_text(stand_sha); (d / 'commit.txt').write_text('c' * 40 + '\nGITHUB_SHA=' + 'c' * 40 + '\n')
        if v.startswith('overlay'): (d / 'overlay-apply.exit').write_text('0'); (d / 'overlay-dry-run.exit').write_text('0'); (d / 'overlay-apply.json').write_text(json.dumps({'block': 13, 'layer': layer, 'auto60_engine_compiled_by_default': False}))
        (d / 'reach.json').write_text(json.dumps({'all_expectations_met': True, 'results': []})); (d / 'reach.exit').write_text('0')
        if v == 'baseline': (d / 'repro.txt').write_text('first=x\nsecond=x\nIDENTISCH\n')
    h = tmp / '19-host-tests'; h.mkdir(); (h / 'host-tests.exit').write_text(host); (tmp / '19-diagnose').mkdir(); (tmp / '19-diagnose/commit.txt').write_text('c' * 40 + '\nGITHUB_SHA=' + 'c' * 40 + '\n')
def synth_diag(tmp, ok=True):
    (tmp / '19-diagnose/diagnose').mkdir(parents=True, exist_ok=True); json.dump({'env': {'git_head': 'c' * 40}, 'overlay_integrity': {'ok': True}, 'oem': {'a': {'match': ok, 'crlf': 0, 'utf8': True, 'markers_present': []}}, 'anchor_failures': {'count': 0 if ok else 2, 'items': []}, 'strict_dry_run': {'ok': ok}}, open(tmp / '19-diagnose/diagnose/diagnose.json', 'w'))
t = Path(tempfile.mkdtemp()); synth(t); synth_diag(t); g = E.evaluate(t, '19', REG, '17'); ck(g['overall'].startswith('GRUEN') and g['reach_summary']['overlay'] == 'OK' and g['variants'][0]['repro']['result'] == 'IDENTISCH', 'vollstaendig gruener Stand-17-Lauf')
def broken(mod, expect_flag, what):
    tt = Path(tempfile.mkdtemp()); synth(tt); synth_diag(tt); mod(tt); r = E.evaluate(tt, '19', REG, '17'); ck(not r['overall'].startswith('GRUEN') and expect_flag(r), what); shutil.rmtree(tt, ignore_errors=True)
broken(lambda d: (d / '19-build-overlay/build.exit').write_text('SKIPPED'), lambda r: r['variants'][2]['verdict'] == 'SKIPPED', 'SKIPPED ist nie gruen')
broken(lambda d: (d / '19-build-overlay-auto60/build.exit').write_text('1'), lambda r: r['variants'][3]['verdict'] == 'NICHT GRUEN', 'build.exit 1')
broken(lambda d: (d / '19-build-overlay/overlay-apply.json').write_text(json.dumps({'block': 12, 'layer': 17, 'auto60_engine_compiled_by_default': False})), lambda r: not r['variants'][2]['checks']['apply.json block == 13'], 'falscher Block')
broken(lambda d: (d / '19-build-overlay/overlay-apply.json').write_text(json.dumps({'block': 13, 'layer': None, 'auto60_engine_compiled_by_default': False})), lambda r: not r['variants'][2]['checks']['apply.json layer == 17 (Stand >= 16)'], 'Stand-15-Overlay (ohne layer 17) bei erwartetem Stand 17')
broken(lambda d: (d / '19-build-overlay/overlay-zip.sha256').write_text('5bc56e75940892ab74ed90ef70a7c36bcdd91fc4c2e2d6d268ddb3bddfc29b05'), lambda r: r['variants'][2]['stand_built'] == 'stand15', 'alter ZIP gebaut (z. B. Android-Umbenennung/Altdatei)')
broken(lambda d: (d / '19-build-baseline/firmware.sha256').unlink(), lambda r: not r['variants'][0]['build_ok'], 'fehlender Firmware-Hash')
broken(lambda d: (d / '19-build-overlay/firmware.size').write_text('leer'), lambda r: not r['variants'][2]['checks']['firmware.size > 0'], 'keine Groesse')
broken(lambda d: (d / '19-host-tests/host-tests.exit').write_text('1'), lambda r: not r['host_tests']['ok'], 'Host-Tests rot')
broken(lambda d: (d / '19-build-overlay/commit.txt').write_text('d' * 40 + '\n'), lambda r: not r['commit_consistent'], 'unterschiedliche Commit-SHA')
# Erreichbarkeit wird SEPARAT gemeldet: Build gruen, aber Erwartung verletzt -> nicht stillschweigend ok
tt = Path(tempfile.mkdtemp()); synth(tt); (tt / '19-build-overlay/reach.json').write_text(json.dumps({'all_expectations_met': False, 'results': [{'name': 'kein Startpfad', 'passed': False}]})); r = E.evaluate(tt, '19', REG, '17')
ck(r['reach_summary']['overlay'] == 'VERLETZT' and r['variants'][2]['reach']['violated'] == ['kein Startpfad'] and r['all_builds_green'], 'Reach-Verletzung wird separat und namentlich gemeldet'); shutil.rmtree(tt, ignore_errors=True)
tt = Path(tempfile.mkdtemp()); synth(tt); (tt / '19-build-overlay/reach.json').unlink(); (tt / '19-build-overlay/reach.skipped').write_text('x'); r = E.evaluate(tt, '19', REG, '17'); ck(r['reach_summary']['overlay'].startswith('NICHT GELAUFEN'), 'uebersprungene Analyse ist NICHT ok'); shutil.rmtree(tt, ignore_errors=True)
tt = Path(tempfile.mkdtemp()); synth(tt); (tt / '19-build-baseline/repro.txt').write_text('first=x\nsecond=y\nVERSCHIEDEN\n'); (tt / '19-build-baseline/repro-diff-bytes.txt').write_text('17'); r = E.evaluate(tt, '19', REG, '17'); ck(r['variants'][0]['repro'] == {'result': 'VERSCHIEDEN', 'diff_bytes': '17'}, 'Reproduzierbarkeit verschieden wird als solche gemeldet'); shutil.rmtree(tt, ignore_errors=True)
broken(lambda d: synth_diag(d, ok=False), lambda r: not r['diagnose']['ok'], 'Diagnose meldet OEM-Abweichung/Trockenlauf-Fehler: der immer gruene Diagnose-Job darf das nicht verdecken')
shutil.rmtree(t, ignore_errors=True)
# CLI: Exit 1 bei nicht gruen
c = subprocess.run([sys.executable, str(root / 'tools/evaluate_ci_artifacts.py'), '--dir', str(ev), '--prefix', '18', '--registry', str(Path(tempfile.mkdtemp()) / 'x.json')], capture_output=True, text=True); ck(c.returncode != 0, 'fehlendes Register muss scheitern')
print(f'PASS CI-Auswerter: {n[0]} Pruefungen (echte CI 18: Stand 15 gruen und NICHT als Stand 16 wertbar; SKIPPED, Exit 1, falscher Block, alter ZIP, fehlende Hashes, Host-Tests, Commit-Abweichung, Reach verletzt/uebersprungen, Reproduzierbarkeit)')
