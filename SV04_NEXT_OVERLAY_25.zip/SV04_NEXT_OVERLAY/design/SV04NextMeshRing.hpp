// SV04 NEXT: ENTWURF (Stand 19), NICHT im Firmware-Build, NICHT im Patcher, NICHT verdrahtet. Kein M500, kein settings.save(), kein Marlin-Aufruf.
// Verallgemeinerung des A/B-Entwurfs auf einen RING mit NS >= 2 Slots (Wear-Leveling): Ziel des naechsten Speicherns ist der NACHFOLGER des neuesten gueltigen Slots; Nutzdaten zuerst, Kopf ZULETZT.
// Nur fuer BYTEWEISE beschreibbare Medien (I2C-24C16 laut pins_CREALITY_V4.h, belegt in docs/T1_ENDSTOP_BELEGMATRIX.md). Unbelegt: sizeof(SettingsData)/freier Bereich, Ladepfad, M500-Zusammenspiel, Haltbarkeit des Bauteils, echter Stromausfall.
#pragma once
#include "SV04NextMeshSlots.hpp"
namespace sv04next {
namespace slots {
template <class Dev, int NS> struct RingStore {
  static_assert(NS >= 2, "mindestens zwei Slots");
  Dev &dev; uint32_t base;
  RingStore(Dev &d, uint32_t b) : dev(d), base(b) {}
  uint32_t slot_addr(int s) const { return base + (uint32_t)s * kSlot; }
  bool valid(int s, uint32_t &seq) const {
    uint8_t buf[kSlot]; for (uint16_t i = 0; i < kSlot; ++i) buf[i] = dev.read(slot_addr(s) + i);
    Header h; memcpy(&h, buf, sizeof h);
    if (h.magic != kMagic || h.version != kVersion || h.gx != kGridX || h.gy != kGridY || h.len != kPayload || h.seq != (uint32_t)~h.seq_inv) return false;
    uint8_t tmp[kSlot]; memcpy(tmp, buf, kSlot); memset(tmp + offsetof(Header, crc), 0, 4);
    if (crc32(tmp, kSlot) != h.crc) return false;
    seq = h.seq; return true;
  }
  static bool newer(uint32_t a, uint32_t b) { return (int32_t)(a - b) > 0; }
  int newest(uint32_t &seq) const { int best = -1; uint32_t bs = 0; for (int s = 0; s < NS; ++s) { uint32_t q = 0; if (valid(s, q) && (best < 0 || newer(q, bs))) { best = s; bs = q; } } seq = bs; return best; }
  bool load(Mesh &m) const { uint32_t seq; const int s = newest(seq); if (s < 0) return false; for (uint16_t i = 0; i < kPayload; ++i) ((uint8_t *)&m)[i] = dev.read(slot_addr(s) + kHeader + i); return true; }
  bool save(const Mesh &m) {
    uint32_t seq = 0; const int cur = newest(seq); const int target = cur < 0 ? 0 : (cur + 1) % NS; const uint32_t nseq = cur < 0 ? 1u : seq + 1u;
    uint8_t buf[kSlot]; Header h; memset(&h, 0, sizeof h); h.magic = kMagic; h.version = kVersion; h.gx = kGridX; h.gy = kGridY; h.len = kPayload; h.seq = nseq; h.seq_inv = ~nseq; h.crc = 0;
    memcpy(buf, &h, sizeof h); memcpy(buf + kHeader, &m, kPayload); h.crc = crc32(buf, kSlot); memcpy(buf, &h, sizeof h);
    const uint32_t a = slot_addr(target);
    for (uint16_t i = kHeader; i < kSlot; ++i) if (!dev.write(a + i, buf[i])) return false;
    for (uint16_t i = 0; i < kHeader; ++i) if (!dev.write(a + i, buf[i])) return false;
    return true;
  }
};
}  // namespace slots
}  // namespace sv04next
