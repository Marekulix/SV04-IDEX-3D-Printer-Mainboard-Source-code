# D1: A/B-Slot-Persistenz, ENTWURF (Stand 17)  |  NICHT verdrahtet, NICHT im Firmware-Build, NICHT freigegeben

Datei: `design/SV04NextMeshSlots.hpp`, Test: `tests/test_mesh_slots.cpp` (13 Pruefungen), Mutationen: `tools/mutate_slots.py` (7 von 10 erkannt, 3 redundant).

## Was belegt ist (Modell, byteweise beschreibbarer Speicher)
- Zwei Slots, Kopf (Magic, Version, Rastergroesse, Laenge, Folgenummer samt Gegenwert, CRC32) und Nutzdaten (16 Messwerte, Raster-Start, Raster-Abstand). Schreiben in den **anderen** Slot, **Kopf zuletzt**.
- **Absturz an jedem der 212 Schreibpunkte** (Byte nicht geschrieben und halb geschriebenes Muellbyte): immer genau das alte ODER das neue Mesh, das neue nur nach vollstaendigem Schreiben. Jeder Einzelbitfehler in beiden Slots: nie ein verfaelschtes Mesh. Andere Version/Rastergroesse mit korrektem CRC wird abgelehnt. Folgenummer mit Ueberlauf.
- Tragend (Mutant wird erkannt): CRC, A/B-Wechsel, Ueberlauf-Vergleich, Version, Rastergroesse, Ladereihenfolge, **Schreibreihenfolge** (mit Kopf zuerst kann das neue Mesh sichtbar werden, obwohl `save()` Misserfolg meldet). Redundant (CRC deckt sie ab): Magic, Gegenwert der Folgenummer, Laenge.

## Was NICHT belegt ist (darum bleibt D1 OFFEN)
1. **EEPROM-Backend: jetzt am Quelltext bestimmt (Workflow 20), freier Bereich weiterhin unbekannt.** `Configuration.h` waehlt `BOARD_CREALITY_V4`; `EEPROM_SETTINGS` ist an und keine Backend-Option gewaehlt, daher greift `NO_EEPROM_SELECTED` und `pins_CREALITY_V4.h` waehlt **I2C-EEPROM 24C16, 2 KB (`IIC_BL24CXX_EEPROM`, SDA PC2, SCL PC3)**. `eeprom_bl24cxx.cpp` schreibt **byteweise** (`writeOneByte`) mit 2 ms Pause je Byte: das Modell (byteweise, kein Erase) passt zur Hardware; ein vollstaendiges `M500` dauert Sekunden. **Offen:** `sizeof(SettingsData)` (wie viel hinter dem Marlin-Block frei bleibt) ist aus dem Quelltext nicht ablesbar und muesste im Build ermittelt werden; ein eigener Bereich von 208 Byte (2 Slots) haette nur Platz, wenn der Marlin-Block hoechstens etwa 1,7 KB belegt (Annahme, nicht geprueft). Belegmatrix: `docs/T1_ENDSTOP_BELEGMATRIX.md`.
2. **Ladepfad beim Start fehlt**: nach `settings.load()` muesste ein eigener Code das Mesh laden, `bilinear_grid_*` setzen, `refresh_bed_level()` und `set_bed_leveling_enabled()` aufrufen. Das waere ein neuer Eingriff in OEM-Startcode.
3. **Zusammenspiel mit `M500`/`M501`/`M502`:** Marlins eigener Block bleibt davon unberuehrt, kann aber weiterhin bei unterbrochenem `M500` ALLE Einstellungen verlieren (siehe `docs/D1_EEPROM_ANALYSE.md`). Der Entwurf schuetzt nur das Mesh, nicht die uebrigen Einstellungen.
4. **Schreibdauer und Stromausfall am Geraet:** nicht gemessen. Das Modell kennt keine Seitenpuffer, keinen Erase, keine Mehrfachfehler.
5. Die Katalogklausel D1 verlangt einen **nativen** EEPROM-Commit mit Readback; der Entwurf ersetzt sie nicht.

## Voraussetzungen, bevor irgendetwas verdrahtet wird
Backend und Bereich aus der Pinbelegung belegen; HIL-Test mit echtem Stromausfall (ohne Heizen/Bewegen); Ladepfad als eigener, geprueft eingefuegter Patch; ausdrueckliche Freigabe. Bis dahin: **kein `M500` aus der Firmware**, Persistenz bleibt die bewusste Handlung des Nutzers.

## Stand 18: Kritische Pruefung und Blocker (ergaenzt)
- **Platz:** `EEPROM_OFFSET` = 100 (`settings.cpp` 40, belegt), Slot = 104 Byte (`tools/eeprom_layout.py`). Bei `sizeof(SettingsData)` bis etwa 1,7 KB passen 2 Slots, bis etwa 1,2 KB sogar 7 (Ring). **Unbekannt:** `sizeof(SettingsData)`; nur der Build kann es liefern. Bis dahin ist "passt" eine Annahme.
- **Wear-Leveling:** A/B verteilt Schreibzugriffe auf 2 Slots; ein Ring mit N Slots auf N. Die Haltbarkeit des 24C16 steht NICHT im Repository (Datenblatt noetig); keine Zahl angegeben.
- **Versionierung/CRC/Commit/Recovery:** CRC32, Version, Rastergroesse, Folgenummer mit Gegenwert, Kopf zuletzt: im Modell belegt (13 Pruefungen, 212 Schreibpunkte). Recovery = juengster gueltiger Slot, sonst "kein Mesh".
- **Nicht verdrahtet und nicht verdrahtbar, solange:** (a) `sizeof(SettingsData)` unbekannt, (b) kein Ladepfad nach `settings.load()`, (c) Marlins `save()` ist nicht atomar (Header `"ERR"` zuerst) und verwirft bei Unterbrechung ALLE Einstellungen, ein Slot-Schutz des Meshs aendert das nicht, (d) Schreibdauer ~2 ms/Byte (~0,2 s je Slot) und Stromausfall am Geraet nicht gemessen.
- **RAM-Transaktion (Mesh im RAM, Rollback in `G29.cpp`) und EEPROM-Transaktion sind getrennt:** Ersteres ist gebaut und getestet; Letzteres existiert nur als Modell. **Es gibt keinen EEPROM-Schreibpfad im Overlay** (statischer Scan, `tests/test_stage18_modules.py`).

## Stand 19: Ring mit N Slots (Modell)
`design/SV04NextMeshRing.hpp` verallgemeinert A/B auf N >= 2 Slots (Ziel = Nachfolger des neuesten gueltigen Slots; Nutzdaten zuerst, Kopf zuletzt). `tests/test_mesh_ring.cpp`: Absturz an **jedem** Schreibpunkt (beide Varianten) fuer N = 2, 3, 4, 7; 4000 Mehrfach-Absturz-Zufallsfolgen je N; jedes einzelne Bit jedes Slots gekippt (nie ein nicht committetes Mesh); Verschleiss gleichmaessig (Differenz <= 1 Speichern); Folgenummer-Ueberlauf; fremde Version/Rastergroesse mit gueltiger CRC abgelehnt. Mutanten (`tools/mutate_ring.py`): 8 von 9 erkannt (der Gegenwert der Folgenummer ist redundant zur CRC). **Weiter nur Modell:** nicht verdrahtet; Blocker unveraendert (`sizeof(SettingsData)`, Ladepfad, nicht-atomarer `save()`, Stromausfall am Geraet, Haltbarkeit des 24C16).
