// SV04 NEXT: ENTWURF (Stand 17), NICHT im Firmware-Build, NICHT im Patcher, NICHT verdrahtet. Kein M500, kein settings.save(), kein Marlin-Aufruf.
// Zweck: Belegen, ob "altes Mesh bei JEDEM Fehler erhalten" fuer ein A/B-Slot-Verfahren auf einem BYTEWEISE beschreibbaren Speicher (z. B. I2C-EEPROM) ueberhaupt erreichbar ist.
// Verfahren: zwei Slots A/B in einem EIGENEN Bereich (getrennt vom Marlin-Block). Ein Slot ist nur gueltig, wenn Magic, Version, Rastergroesse, Laenge, Folgenummer (mit Gegenwert) UND CRC32 ueber Kopf+Nutzdaten stimmen.
// Speichern: in den Slot mit der KLEINEREN (oder ungueltigen) Folgenummer schreiben: erst die Nutzdaten, ZULETZT der Kopf (mit CRC). Jeder Abbruch davor laesst den anderen Slot unberuehrt gueltig.
// Laden: der gueltige Slot mit der groesseren Folgenummer (mod 2^32 Vergleich). Beide ungueltig -> "kein gespeichertes Mesh" (Marlins eigener Block bleibt davon unberuehrt).
// GRENZEN: gilt nur fuer byteweise beschreibbare Medien (Schreiben = idempotent, ein unterbrochenes Byte ist hoechstens Muell, kein Seiten-Erase). Flash-Emulation braucht ein anderes Verfahren.
// Unbelegt: freier EEPROM-Bereich (Backend/Groesse unbekannt), Ladepfad beim Start (nach settings.load()), Zusammenspiel mit M500/M501/M502, Schreibdauer, echter Stromausfall (HIL).
#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>
namespace sv04next {
namespace slots {
constexpr uint32_t kMagic = 0x534C4F54u;          // "SLOT"
constexpr uint8_t kVersion = 1, kGridX = 4, kGridY = 4;
constexpr uint16_t kPayload = (uint16_t)(sizeof(float) * (kGridX * kGridY + 4));    // 16 Messwerte + start.x/y + spacing.x/y
struct Header { uint32_t magic; uint8_t version, gx, gy, pad; uint16_t len; uint16_t pad2; uint32_t seq, seq_inv, crc; };   // crc: ueber Kopf (ohne crc) + Nutzdaten
constexpr uint16_t kHeader = 24, kSlot = kHeader + kPayload;
static_assert(sizeof(Header) == kHeader, "Kopfgroesse");
inline uint32_t crc32(const uint8_t *p, uint32_t n, uint32_t c = 0xFFFFFFFFu) { for (uint32_t i = 0; i < n; ++i) { c ^= p[i]; for (int k = 0; k < 8; ++k) c = (c >> 1) ^ (0xEDB88320u & (0u - (c & 1u))); } return ~c; }
struct Mesh { float z[kGridX * kGridY]; float start_x, start_y, sp_x, sp_y; };
// Speichergeraet (Vorlage): bool write(addr, value) liefert false bei Abbruch (Stromausfall); uint8_t read(addr).
template <class Dev> struct Store {
  Dev &dev; uint32_t base;
  Store(Dev &d, uint32_t b) : dev(d), base(b) {}
  static uint32_t slot_addr(uint32_t base_, int s) { return base_ + (uint32_t)s * kSlot; }
  bool valid(int s, uint32_t &seq) const {
    uint8_t buf[kSlot]; for (uint16_t i = 0; i < kSlot; ++i) buf[i] = dev.read(slot_addr(base, s) + i);
    Header h; memcpy(&h, buf, sizeof h);
    if (h.magic != kMagic || h.version != kVersion || h.gx != kGridX || h.gy != kGridY || h.len != kPayload || h.seq != (uint32_t)~h.seq_inv) return false;
    uint8_t tmp[kSlot]; memcpy(tmp, buf, kSlot); memset(tmp + offsetof(Header, crc), 0, 4);
    if (crc32(tmp, kSlot) != h.crc) return false;
    seq = h.seq;
    return true;
  }
  static bool newer(uint32_t a, uint32_t b) { return (int32_t)(a - b) > 0; }   // Folgenummer mit Ueberlauf
  // liefert Slotnummer des neuesten gueltigen Slots oder -1
  int newest(uint32_t &seq) const { uint32_t sa = 0, sb = 0; const bool a = valid(0, sa), b = valid(1, sb); if (a && b) { if (newer(sa, sb)) { seq = sa; return 0; } seq = sb; return 1; } if (a) { seq = sa; return 0; } if (b) { seq = sb; return 1; } return -1; }
  bool load(Mesh &m) const { uint32_t seq; const int s = newest(seq); if (s < 0) return false; for (uint16_t i = 0; i < kPayload; ++i) ((uint8_t *)&m)[i] = dev.read(slot_addr(base, s) + kHeader + i); return true; }
  // true = vollstaendig geschrieben; false = abgebrochen (der andere Slot bleibt unberuehrt gueltig)
  bool save(const Mesh &m) {
    uint32_t seq = 0; const int cur = newest(seq); const int target = cur < 0 ? 0 : 1 - cur; const uint32_t nseq = cur < 0 ? 1u : seq + 1u;
    uint8_t buf[kSlot]; Header h; memset(&h, 0, sizeof h); h.magic = kMagic; h.version = kVersion; h.gx = kGridX; h.gy = kGridY; h.len = kPayload; h.seq = nseq; h.seq_inv = ~nseq; h.crc = 0;
    memcpy(buf, &h, sizeof h); memcpy(buf + kHeader, &m, kPayload); h.crc = crc32(buf, kSlot); memcpy(buf, &h, sizeof h);
    const uint32_t a = slot_addr(base, target);
    for (uint16_t i = kHeader; i < kSlot; ++i) if (!dev.write(a + i, buf[i])) return false;      // zuerst die Nutzdaten
    for (uint16_t i = 0; i < kHeader; ++i) if (!dev.write(a + i, buf[i])) return false;           // ZULETZT der Kopf
    return true;
  }
};
}  // namespace slots
}  // namespace sv04next
