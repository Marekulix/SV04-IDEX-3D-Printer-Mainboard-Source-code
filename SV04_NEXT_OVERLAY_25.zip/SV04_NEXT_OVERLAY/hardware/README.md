# hardware/: Vorlagen fuer Hardware-Protokolle  |  NICHTS DAVON IST DURCHGEFUEHRT

`templates/H0.json` bis `H3.json` sind **leere Vorlagen** (alle Pflichtfelder leer). Ausgefuellte Protokolle gehoeren nach `protocols/` (derzeit leer). Pruefung: `python3 tools/h_protocol_check.py protocols/<Datei>.json --register RELEASE_REGISTER.json --stand stand18`.
Das Werkzeug berechnet das Ergebnis aus den Messwerten; eine leere Vorlage besteht nie. H0 bis H3 loesen **keine Bewegung und keine Heizung** aus. Der Katalog kennt fuer H noch kein Format und vergibt deshalb heute keine H-Punkte (siehe `docs/KATALOGVORSCHLAG.md`).
