# SV04 NEXT 31 – DWIN Adressschutz (keine Flashfreigabe)

**Neu im tatsächlich eingebundenen Firmwarecode:** `DwinVpSafety::writable(vp, Addrbuf)` vergleicht den aus dem G29-U-Receipt abgeleiteten Schreib-VP mit **allen originalen Touch-Eingangsadressen** der Sovol-Firmware. Beim Treffer wird der passive `RTS_SndData`-Schreibvorgang **nicht ausgeführt**.

## Kritischer Konflikt

Die originale HMI-/Firmware-Adresskarte verwendet `0x110E` gleichzeitig für die **Seitenwechsel-Taste `ChangePageKey`** und **Messwertfeld 8** (`0x1100 + 7×2`). Stand 30 schrieb hier ungeprüft. Stand 31 **unterdrückt diesen einen neu eingefügten Schreibvorgang**. Die interne G29-U-Quittung enthält weiterhin alle 16 Messwerte; das originale DWIN-Mesh erhält über die **neue Brücke nur 15/16 Punkte**. Die Anzeige darf daher NICHT als vollständiges, verifiziertes 16-Punkte-Mesh vermarktet werden. Dieses Vorgehen schützt die neue Brücke, behebt jedoch NICHT die bereits vorhandene Adressüberlappung im OEM-`G29`.

**Warum kein Ausweich-VP?** Eine unbenutzte MCU-Adresse ist nicht automatisch im T5UID/DGUS-Displayprojekt eingerichtet. Ohne HMI-Ressourcen ist kein sicherer alternativer Touch-/Display-VP nachgewiesen. Kein neuer Startknopf, keine Farbkacheln, kein Auto60-Start, kein Bewegen, kein Heizen, kein EEPROM-Schreiben.

**Nachweise:** C++-Policytests für die 16er Familie, negative Fälle bei nachträglich belegten Touch-Adressen, nativer Patch-Einbau, Patch-Integrität, ARM-CI über Workflow 31 (ausstehend).
