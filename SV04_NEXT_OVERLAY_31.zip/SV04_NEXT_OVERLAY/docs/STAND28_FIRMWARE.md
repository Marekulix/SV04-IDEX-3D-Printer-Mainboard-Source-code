# SV04 NEXT Stand 28: NATIVER Firmwarecode (kein Flash)

* Basis: Stand 27, dessen GitHub-WF27 alle vier Builds und komplette Host-Suite erfolgreich abgeschlossen hat (Angabe aus nutzerseitigen CI-Artefakten).
* **Aenderung im ARM-Firmwarepfad** `include/SV04NextT1ParkSense.hpp`: `G29 U` (die transaktionale, zusaetzlich gesicherte Bettvermessung) verweigert bei `active_extruder != 0` und `!axis_is_trusted(X_AXIS)`, zusaetzlich zum X_MAX-PE15-Signal und X<=302. Die native Guard-Funktion wird im kompilierten G29.cpp vor Start, pro Punkt und beim Abschluss aufgerufen.
* `integration/apply_native_guard_v17.py` verweigert jetzt auch Manipulationen, die eine der neuen beiden Bedingungen entfernen. Mehrere positive/negative Hardwaremodelle im bestehenden `test_overlay_v17.py`, plus neues Vertragstestskript.
* **Keine Aenderung** an Original `G29`, G28, der OEM-DWIN-Steuerung, Bewegungen, Heizung, EEPROM, Werkzeugwechsel oder an der Auto60-Startlogik. Es gibt noch keine frei gegebene DWIN-Schaltflaeche und keinen Auto60-Startpfad.
* **Wichtig:** `axis_is_trusted` ist nur Firmware-Buchfuehrung. Nach `M18` mit manuellem Verschieben ist das kein physikalischer Positionsnachweis. Diese Aenderung reduziert bestimmte Softwarefehler, aber beweist KEINE Kollisionsfreiheit.
* **Sicherheit:** Kein Hardwaretest mit SV04 NEXT, keine Freigabe zum Flashen. GitHub-WF28 muss Firmware und Host-Tests erst ausfuehren.
* **Prozessregel:** ZIP/YAML in jedem neuen Lauf eindeutig gleich nummerieren, niemals zurueckspringen oder altes ZIP in altem Workflow wiederverwenden. Der folgende Test nach 28 muss 29 oder eine nachweislich freie hoehere Nummer verwenden.
