# SV04 NEXT Stand 30: echte native DWIN-Ausgabe (nur G29 U, nicht flashen)

## Neu programmierter Firmwarecode

- `include/SV04NextG29UDwinMirror.hpp`: `sv04next::G29UDwinMirror`, eine kleine zustandsbehaftete Klasse, die nur bereits beobachtete Daten aus dem nativen `G29UReceipt` in DWIN-Schreibaufträge übersetzt. Sie startet weder Messung noch Heizung, fährt keine Achse und speichert kein EEPROM.
- `integration/apply_native_guard_v18.py`: Die neue Patch-Stufe 18, ohne Änderung an Stage 17, ergänzt den OEM-Code `Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp` um einen globalen DWIN-Mirror und die **tatsächliche** Übertragung über `rtscheck.RTS_SndData` in `RTSUpdate()`.
- `patches/0001-sv04next-overlay.patch`: Mit `tools/make_patch.py` aus den ECHTEN OEM-Dateien neu erzeugt, `git apply`/Revert getestet.
- Es wird **nur** auf die bereits belegten Sovol-Adressen `AUTO_BED_LEVEL_ICON_VP` (0/1) und `AUTO_BED_LEVEL_1POINT_VP + 2*slot` (16 Werte) geschrieben. Keine erfundenen VPs, keine Änderung des Bildschirms, kein neuer Touch-Handler.
- Zuordnung der 16 Punkte folgt der bestehenden Sovol-Schlangenlinie: Zeile 0 X3,2,1,0; Zeile 1 X0,1,2,3; usw. Der Messwert ist 1/1000 mm wie bei OEM.
- Maximal ein DWIN-Schreibauftrag je 120 ms, nur wenn `G29 U` eine neue Quittung/Sequenz liefert. Normales `G29`, Idle und frühe Verweigerung bleiben unberührt. Abbruch beendet die laufende Anzeige mit `Icon=0`; eine bei Ankunft bereits beendete Messung zeigt keinen falschen Busy-Zustand.
- Ein RAM-vollständiger Abschluss darf die Anzeige aktualisieren, **ist keine EEPROM-Speicherung**. Fehlgeschlagene G29-U-Proben nutzt weiterhin den bestehenden Mesh-Rollback, die Anzeige erfindet keine Erfolgsmeldung.

## Bewusst weiterhin nicht fertig

- **Keine Auto60-Starttaste**: Ohne gesicherte HMI-/DWIN-Ressourcen kein neuer Touchbereich. `SV04_NEXT_AUTO60_ENGINE` bleibt standardmäßig AUS.
- **Kein neuer farbiger 4×4-Bildschirm** und keine sicheren freien VPs für Rot/Grün. Originale Ressourcen nicht vorhanden. Status-/Fehlernummer auf dem Display nur eingeschränkt, ohne neue VP-Familie.
- Kein EEPROM-Commit, keine Bewegungs-/Heizfreigabe, **kein Freigabenachweis für den realen Drucker**.
- Die OEM-Adresskarte hat eine bereits bestehende Überlappung `ChangePageKey` mit dem Feld für Messpunkt 8. Der Overlay-Code verwendet nur die OEM-Familie, die HMI-Ressourcen müssen vor einem separaten Menüprojekt inspiziert werden.

## Tests/Nachweise

- `tests/test_native_dwin_mirror.cpp`: reale Reihenfolge, Drosselung, Doppelmeldungen, verspäteter Erfolg, Abbruch, späterer Neustart, Millis-Überlauf, keine Heiz-/Motion-/EEPROM-Autorisierung.
- `tests/test_native_dwin_bridge.py`: verifiziert Einbau in den nativen `RTSUpdate()`-Pfad und ausschließliche OEM-VPs.
- `tests/test_patch_apply.py`: neue Firmware-Ausgabe aus dem Patcher bitgleich zum ausgelieferten Git-Patch, apply und revert auf den echten OEM-Dateien.
- `tests/test_dwin_conflicts.py`: nur vorhandene VPs, Konfliktliste bleibt nachvollziehbar.
- Gesamte Host-Tests und vier ARM-Buildvarianten **müssen** in Workflow 30 unabhängig durchlaufen; kein Flash-Test.
