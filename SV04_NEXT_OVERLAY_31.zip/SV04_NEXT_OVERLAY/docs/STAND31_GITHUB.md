# SV04 NEXT 31 – Android / GitHub (NICHT FLASHEN)

1. `SV04_NEXT_OVERLAY_31.zip` in das GitHub-Repository-Hauptverzeichnis (neben `Marlin`) hochladen, **nicht entpacken**.
2. `31.yml` im GitHub-Ordner `.github/workflows/` hochladen.
3. Actions > **31 - SV04 NEXT** > Run workflow; alle Standardwerte belassen, `upload_binary=no`.
4. Die sechs Archive `31-diagnose`, `31-host-tests`, `31-build-baseline`, `31-build-probe`, `31-build-overlay`, `31-build-overlay-auto60` zur Prüfung hochladen.

**Wichtig:** Durch die native DWIN-VP-Kollisionsprüfung wird die neue G29-U-Display-Brücke nur noch 15 der 16 Messwerte übertragen. Punkt 8 bleibt im RAM vorhanden, sein DWIN-VP ist gleichzeitig ein OEM-Seitenwechsel-Touchkey. Erst nach Beschaffung des originalen HMI-Projekts ist eine gefahrlose vollständige 16-Punkte-Anzeige möglich. Bestehende normale OEM-G29-Anzeigeschreibwege bleiben unangetastet. Keine Flashfreigabe.
