#pragma once
#include "SV04NextG29UReceipt.hpp"

namespace sv04next {
// SV04 NEXT 30: REAL passive bridge from the native G29 U receipt to the
// EXISTING Sovol 4x4 DWIN variable fields. No new HMI addresses or touch keys.
// One bounded write proposal per RTSUpdate (>=120ms between proposals).
// Never queues G-code, starts heating/motion or writes EEPROM. The caller
// decides whether to send a proposal using the OEM RTS_SndData implementation.
class G29UDwinMirror final {
public:
  enum class Kind : uint8_t { Icon, Point };
  struct Write { Kind kind = Kind::Icon; uint8_t slot = 0; int16_t value = 0; };
  static constexpr uint32_t MinWriteIntervalMs = 120u;

  bool poll(uint32_t now, const G29UReceipt &receipt, Write &out) {
    if (!receipt.sequence() || receipt.phase() == G29UReceipt::Phase::Never)
      return false;                         // ordinary G29: untouched
    if (receipt.sequence() != sequence_) {  // new G29 U, including after errors
      sequence_ = receipt.sequence(); sent_mask_ = 0;
      begun_ = ended_ = have_last_ = false;
    }
    if (have_last_ && (uint32_t)(now - last_ms_) < MinWriteIntervalMs)
      return false;
    if (ended_) return false;

    const G29UReceipt::Phase phase = receipt.phase();
    if (phase == G29UReceipt::Phase::Refused || phase == G29UReceipt::Phase::Failed) {
      ended_ = true;
      if (!begun_) return false;           // early refusal: leave OEM UI alone
      return output(now, out, Kind::Icon, 0, 0);
    }
    if (!begun_) {
      begun_ = true;
      // A completed receipt observed late must NOT pretend the probe
      // is still moving. Only a genuinely running G29 U shows busy=1.
      if (phase == G29UReceipt::Phase::Running)
        return output(now, out, Kind::Icon, 0, 1); // OEM busy icon: 0/1 only
    }
    const bool complete = phase == G29UReceipt::Phase::RamOnlySuccess &&
                          receipt.completed() == G29UReceipt::Count &&
                          receipt.point_mask() == 0xFFFFu;
    if (phase == G29UReceipt::Phase::RamOnlySuccess && !complete) {
      ended_ = true;                       // corrupt receipt: never show success
      return output(now, out, Kind::Icon, 0, 0);
    }
    // DWIN slots use the OEM serpentine measurement order, NOT raw (y*4+x).
    // Never write invalid points. A successful terminal receipt is re-sent
    // fully, which synchronizes the 16 legacy DWIN registers with the RAM mesh.
    for (uint8_t slot = 0; slot < G29UReceipt::Count; ++slot) {
      const uint8_t y = slot / 4;
      const uint8_t col = slot % 4;
      const uint8_t x = (y & 1u) ? col : (uint8_t)(3u - col);
      const uint8_t index = (uint8_t)(4u*y + x);
      const uint16_t bit = (uint16_t)(1u << index);
      if ((sent_mask_ & bit) || !(receipt.point_mask() & bit) ||
          receipt.pixel(index) != G29UReceipt::Pixel::Recorded) continue;
      const float z = receipt.value(index);
      if (!float_is_finite(z) || fabsf(z) > G29UReceipt::MaxAbsZmm) continue;
      sent_mask_ |= bit;
      const int16_t milli = (int16_t)(z * 1000.0f); // native OEM unit
      return output(now, out, Kind::Point, slot, milli);
    }
    if (complete) {
      ended_ = true;
      return output(now, out, Kind::Icon, 0, 0);  // finished; RAM ONLY!
    }
    return false; // waiting for next valid point
  }
  bool permits_heating() const { return false; }
  bool permits_motion() const { return false; }
  bool permits_eeprom() const { return false; }
private:
  bool output(uint32_t now, Write &out, Kind kind, uint8_t slot, int16_t val) {
    out.kind = kind; out.slot = slot; out.value = val;
    last_ms_ = now; have_last_ = true;
    return true;
  }
  uint32_t sequence_ = 0, last_ms_ = 0;
  uint16_t sent_mask_ = 0;
  bool begun_ = false, ended_ = false, have_last_ = false;
};

} // namespace sv04next
