// SV04 NEXT 31: passive DWIN write admission using the OEM touchscreen input map.
// NO new VP, page, G-code, motor/heater command or EEPROM write.
// The OEM ChangePageKey shares 0x110E with the 8th 4x4 mesh value.
// A 16-bit output at any known touch-input VP is NOT sent until the
// real HMI/T5UID resource establishes a safe alternative mapping.
#pragma once
#include <stdint.h>
namespace sv04next {
class DwinVpSafety final {
public:
  template<typename Word, unsigned N>
  static bool writable(uint16_t vp, const Word (&touch_vps)[N]) {
    if (!vp || !N) return false;                 // fail closed
    for (unsigned i=0; i<N; ++i) {
      if ((uint32_t)touch_vps[i] == (uint32_t)vp) return false;
    }
    return true;
  }
};
} // namespace sv04next
