#!/usr/bin/env python3
"""SV04 NEXT 31: fail-closed native DWIN VP collision gate over stage18.

Stage18 is preserved unchanged. Touch key addresses come from the real OEM
Addrbuf[] (not from invented VP values). Legacy OEM G29 is not modified.
"""
from __future__ import annotations
import argparse, json
from pathlib import Path
import apply_native_guard_v18 as v18

v15 = v18.v15
v14 = v15.v14
PatchRefused = v18.PatchRefused
HEADERS = list(v18.HEADERS) + ['SV04NextDwinVpSafety.hpp']
RTS = v14.RTS


def _once(body: str, anchor: str, what: str):
    if body.count(anchor) != 1:
        raise PatchRefused(f'stage19 {what} anchor count != 1 (found {body.count(anchor)})')


def render(original: dict[str,str], *headers: str) -> dict[str,str]:
    if len(headers) != len(HEADERS):
        raise PatchRefused(f'stage19 needs {len(HEADERS)} native headers')
    policy = headers[-1]
    if ('class DwinVpSafety final' not in policy or
        'static bool writable(' not in policy or
        'touch_vps[i]' not in policy or
        'if (!vp || !N) return false;' not in policy):
        raise PatchRefused('stage19 fail-closed DWIN policy header contract missing')
    out = v18.render(original, *headers[:-1])
    out['Marlin/src/feature/sv04_next/SV04NextDwinVpSafety.hpp'] = policy
    rts = out[RTS]
    inc = '  #include "../../../feature/sv04_next/SV04NextG29UDwinMirror.hpp"\n'
    _once(rts, inc, 'include')
    rts = rts.replace(inc, inc + '  #include "../../../feature/sv04_next/SV04NextDwinVpSafety.hpp"\n')
    write = '      rtscheck.RTS_SndData((int)sv04_dwin_write.value, sv04_vp);\n'
    _once(rts, write, 'native DWIN write')
    rts = rts.replace(write,
        '      // Stand 31: skip every VP listed as an OEM TOUCH INPUT.\n'
        '      // This suppresses point 8 (0x110E == ChangePageKey) in the NEW bridge.\n'
        '      // The receipt still contains all 16 points; no fake display success.\n'
        '      if (sv04next::DwinVpSafety::writable(sv04_vp, Addrbuf))\n'
        + write)
    out[RTS] = rts
    return out


def apply(root: Path, headers: list[Path], evidence: Path | None = None,
          dry_run: bool=False, diff_out: Path | None=None) -> dict:
    return v15.apply(root, headers, evidence, dry_run, diff_out,
                     render_fn=render, block=13,
                     extra_report={'layer':19, 'native_dwin_vp_collision_gate': True,
                                   'dwin_point8_mirrored':False,
                                   'dwin_touch_start_present':False,
                                   'auto60_eeprom_wired':False,
                                   'auto60_engine_compiled_by_default':False})

if __name__ == '__main__':
    p=argparse.ArgumentParser(description='SV04 NEXT 31 DWIN VP gate, NOT FLASHABLE')
    p.add_argument('--root',type=Path,default=Path('.'))
    p.add_argument('--evidence',type=Path)
    p.add_argument('--dry-run',action='store_true')
    p.add_argument('--diff-out',type=Path)
    here=Path(__file__).resolve().parent.parent/'include'
    for name in HEADERS:
        p.add_argument('--'+name[:-4].lower(),type=Path,default=here/name)
    a=p.parse_args()
    files=[getattr(a,n[:-4].lower()) for n in HEADERS]
    missing=[str(f) for f in files if not f.is_file()]
    if missing: raise SystemExit('PatchRefused: missing header(s): '+', '.join(missing[:3]))
    print(json.dumps(apply(a.root,files,a.evidence,a.dry_run,a.diff_out),indent=2))
