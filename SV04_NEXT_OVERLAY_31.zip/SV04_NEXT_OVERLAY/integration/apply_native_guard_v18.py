#!/usr/bin/env python3
"""SV04 NEXT stand 30: native passive G29U->legacy DWIN VP bridge.

Extends stage17 without changing stage17 or any OEM touch-button handling.
Refuses patching if either RTS anchor differs from verified Sovol source.
No heating/motion/EEPROM/start actions and no new HMI addresses.
"""
from __future__ import annotations
import argparse, json
from pathlib import Path
import apply_native_guard_v17 as v17

v15 = v17.v15
v14 = v15.v14
PatchRefused = v17.PatchRefused
HEADERS = list(v17.HEADERS) + ["SV04NextG29UDwinMirror.hpp"]


def _once(haystack: str, needle: str, purpose: str) -> None:
    if haystack.count(needle) != 1:
        raise PatchRefused(f'stage18 {purpose} anchor count != 1; refused')


def render(original: dict[str, str], *headers: str) -> dict[str, str]:
    if len(headers) != 18: raise PatchRefused('stage18 requires exactly 18 native headers')
    out = v17.render(original, *headers[:-1])
    new_header = headers[-1]
    if 'class G29UDwinMirror' not in new_header or 'float_is_finite(z)' not in new_header:
        raise PatchRefused('stage18 native DWIN mirror header contract missing')
    out['Marlin/src/feature/sv04_next/SV04NextG29UDwinMirror.hpp'] = new_header
    rts = out[v14.RTS]
    inc_anchor = '  #include "../../../feature/sv04_next/SV04NextNativeStatusPacket.hpp"\n'
    _once(rts, inc_anchor, 'native DWIN header include')
    rts = rts.replace(inc_anchor, inc_anchor +
      '  #include "../../../feature/sv04_next/SV04NextG29UDwinMirror.hpp"\n')
    global_anchor = '  namespace sv04next { NativeIdexEvidence native_idex_evidence; }\n'
    tick_anchor = ('    sv04next::mesh_map_packet.capture(sv04next::g29u_receipt,\n'
                   '      sv04next::native_event_timeline.view(), sv04next::native_status_packet);\n')
    _once(rts, global_anchor, 'DWIN singleton')
    _once(rts, tick_anchor, 'DWIN update')
    rts = rts.replace(global_anchor, global_anchor +
      '  namespace sv04next { G29UDwinMirror g29u_dwin_mirror; }\n')
    rts = rts.replace(tick_anchor, tick_anchor +
      '    // Stand 30: G29 U only, at most one known legacy DWIN VP per 120ms.\n'
      '    // No new page, touch handler, heating, G-code or EEPROM calls.\n'
      '    sv04next::G29UDwinMirror::Write sv04_dwin_write;\n'
      '    if (sv04next::g29u_dwin_mirror.poll((uint32_t)millis(), sv04next::g29u_receipt, sv04_dwin_write)) {\n'
      '      const uint16_t sv04_vp = sv04_dwin_write.kind == sv04next::G29UDwinMirror::Kind::Icon\n'
      '        ? AUTO_BED_LEVEL_ICON_VP\n'
      '        : (uint16_t)(AUTO_BED_LEVEL_1POINT_VP + (uint16_t)sv04_dwin_write.slot * 2u);\n'
      '      rtscheck.RTS_SndData((int)sv04_dwin_write.value, sv04_vp);\n'
      '    }\n')
    out[v14.RTS] = rts
    return out


def apply(root: Path, headers: list[Path], evidence: Path | None = None,
          dry_run: bool = False, diff_out: Path | None = None) -> dict:
    return v15.apply(root, headers, evidence, dry_run, diff_out,
                     render_fn=render, block=13,
                     extra_report={'layer': 18, 'native_dwin_g29u_vp_bridge': True,
                                   'dwin_touch_start_present': False, 'auto60_eeprom_wired': False,
                                   'auto60_engine_compiled_by_default': False})


if __name__ == '__main__':
    p = argparse.ArgumentParser(description='SV04 NEXT DWIN native stage18, NOT FLASHABLE')
    p.add_argument('--root', type=Path, default=Path('.'))
    p.add_argument('--evidence', type=Path)
    p.add_argument('--dry-run', action='store_true')
    p.add_argument('--diff-out', type=Path)
    here = Path(__file__).resolve().parent.parent / 'include'
    for name in HEADERS:
        p.add_argument('--'+name[:-4].lower(), type=Path, default=here/name)
    a = p.parse_args()
    missing = [str(getattr(a,n[:-4].lower())) for n in HEADERS if not getattr(a,n[:-4].lower()).is_file()]
    if missing: raise SystemExit('PatchRefused: missing header(s): '+', '.join(missing[:3]))
    print(json.dumps(apply(a.root,[getattr(a,n[:-4].lower()) for n in HEADERS],
                           a.evidence,a.dry_run,a.diff_out),indent=2))
