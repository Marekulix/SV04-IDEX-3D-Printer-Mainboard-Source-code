# SV04 NEXT 306: gemeinsame Entwicklung (NO FLASH)

**Nicht flashen. Keine Hardwarefreigabe.** Der letzte nachgewiesene erfolgreiche STM32-Gesamtbuild ist **291**. 299 und 300–306 sind lokale Entwicklungsschritte. Claude C2 ist ein eigener Quellstand, KEINE eigene Firmware-Versionsnummer.

## Neu in 306

Die G29/DWIN-Abbrucherweiterung aus 299, EEPROM-Kette 292–294 + 300–305 und Claudes C2-Werkzeugwechsel-/Heizsperren werden geordnet und ohne pauschales Ueberschreiben zusammengefuehrt.

### Zusaetzliche EEPROM-Korrektur 306

Bei einem Stromausfall direkt nach `settings.save()` kann der neue EEPROM-Hauptblock bereits eine korrekte CRC enthalten, obwohl Auto60 dessen Messwerte noch NICHT unabhaengig geprueft und die Transaktion noch NICHT abgeschlossen hat. Frueher bedeutete ein gueltiger Hauptblock bei offenem Undo-Journal stets `BA_CLEAR`; damit wurde unbestaetigter Inhalt uebernommen. 306 fuehrt einen **bytegenauen Vergleich des Hauptblocks mit der unveraenderten Journal-Kopie** aus. Solange ein gueltiges Journal aktiv ist, wird bei Abweichung der vorherige Block zurueckgespielt. Bei Lesefehler bleibt das Journal erhalten (`BR_UNAVAILABLE`, Auto60 gesperrt). Nach ausdruecklichem `commit_transaction(..., verified=true)` wird das Journal geloescht; der neue Block bleibt erhalten. Bei Stromausfall vor diesem Abschluss wird ein unbestaetigtes neues Mesh konservativ verworfen. Dies ist beabsichtigt.

## Lokale Nachweise (12.11.2026)

- 306: 50/50 C++11 EEPROM-Tests, inklusive 5 neue Tests zu CRC-gueltigem unbestaetigtem Hauptblock, identischem Hauptblock, Lesefehler beim Vergleich, Stromausfall waehrend Rollback, bestaetigtem Commit.
- 306: gemeinsame Patchreihe 299 + 292–294 + 300–306 + Claude C2 auf der dokumentierten 287-Quellreferenz erfolgreich angewendet, wiederholbar ohne Veraenderungen. **Kein vollstaendiger OEM-Baum lokal vorhanden.**
- Claude C2: 6/6 unittest-Gruppen gegen die enthaltenen originalen OEM-Dateien bestanden, darunter 96 `T.cpp`-Kombinationen.
- 294: Auto60-Koordinator lokal: 150/150 PASS; GitHub-Workflow prueft SUMMARY getrennt, da der alte Wrapper nicht immer einen Fehlstatus weitergibt.
- Beide STM32-Profile von 306: **noch nicht gebaut**. Der GitHub-Workflow versucht diese Builds nur und archiviert alle Logs, auch bei Fehlern.

## Integration

Im GitHub-Workflow: gepinntes Sovol OEM-Commit `1867fcba75354a5c65e0631d6972dd19f1bd6cbe` klonen, die bestehenden 287-, 288-, 290-Patches anwenden und dann

`python3 work306/integrate_306.py oem`

Die Datei `integrate_306.py` installiert exakt: G29 299, EEPROM 292/293/294, EEPROM 300/301/304/306, Adapter 302/303/305 und Claude C2 Heater/T.cpp. Die Reihenfolge der Nummern ist absichtlich von der funktionalen Abhaengigkeit abgeleitet. Die Skripte verweigern unbekannte Anker; kein pauschales Ueberschreiben. Sie pruefen anschliessend die relevanten Merkmale und geben SHA256 der gepatchten Quelldateien aus.

Im Repo die zwei unveraendert benannten Dateien ablegen: `A 306.zip` im Root; `B 306.yml` unter `.github/workflows/`. Der Workflow `306` benoetigt die auf GitHub bereits vorhandenen `SV04_NEXT_287.zip`, `SV04_NEXT_289.zip`, `SV04_NEXT_291.zip`, `SV04_NEXT_294.zip`, `SV04_NEXT_295.zip` im Root. Der Workflow fuehrt **keine Flashaktion** aus.

## Bekannte Grenzen

- Lokale Integration ist eine Quellreferenzprobe; nur GitHub kann die tatsaechliche Kombination mit dem gesamten OEM-Baum und ARM-Toolchain nachweisen.
- Die C2-Sperre deckt normale T-G-Code-Wechsel ab. Interne Werkzeugwechsel sind nicht vollstaendig abgesichert. BLTouch-ohne-Trigger und mechanische IDEX-Abstaende sind weiterhin offen.
- Die EEPROM-Vergleiche sind Host-I2C-Modellsimulation, nicht reales EEPROM oder Stromausfall am Geraet.
- Erst nach einem fehlerfreien Build beider Profile und eigener Hardware-Sicherheitspruefung kann ein Test am Drucker ueberhaupt erwogen werden.
