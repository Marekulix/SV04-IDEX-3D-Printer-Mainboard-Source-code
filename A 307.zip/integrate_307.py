#!/usr/bin/env python3
"""307: correct the 306 OEM integration gap, then run the unchanged 306 patch chain."""
import sys
from ensure_287_headers_307 import ensure
from integrate_306 import main as compose_306
if __name__=='__main__':
    if len(sys.argv)!=2:sys.exit('usage: integrate_307.py OEM_ROOT')
    ensure(sys.argv[1])
    compose_306(sys.argv[1])
    print('SV04_NEXT_307_COMPOSITION=PASS')
