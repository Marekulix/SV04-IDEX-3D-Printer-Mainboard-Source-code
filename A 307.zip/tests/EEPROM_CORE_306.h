#pragma once
/**
 * SV04 NEXT 283 - EEPROM-Kern: UNABHAENGIGE Rohlesung, Integritaetspruefung und Stromausfall-Absicherung (Undo-Journal).
 *
 * Portables C++11 ohne Marlin-Abhaengigkeit, ohne Heap, ohne STL, ohne Ausnahmen. Der Adapter (sv04_claude_auto60_marlin.inc) legt eine Store-Huelle um persistentStore.
 *
 * HINTERGRUND (belegt am OEM-Code dieses Builds):
 *  - settings.cpp:655/1461-1464: save() schreibt zuerst die Kennung "ERR" in den Kopf und die echte Version samt CRC ERST AM ENDE. Ein Stromausfall dazwischen laesst den GESAMTEN
 *    Einstellungsblock ungueltig zurueck (nicht nur das Mesh); EEPROM_AUTO_INIT ist aus, der Drucker liefe danach mit den Firmware-Standardwerten.
 *  - settings.h:129: EEPROM_WRITE() VERWIRFT den Rueckgabewert von write_data(). Ein fehlgeschlagener Schreibzugriff wird von save() nur INDIREKT bemerkt (der Treiber zaehlt die Position nicht weiter,
 *    dadurch schlaegt size_error() an, settings.cpp:1457-1469) und GAR NICHT, wenn er beim Schreiben des Kopfes (Version + CRC, settings.cpp:1461-1464) auftritt.
 *    => Der Rueckgabewert von save() ist KEIN Erfolgsnachweis. Die Pruefung muss unabhaengig vom RAM aus dem Speicher selbst erfolgen (Test EE20: 5 Positionen, an denen save() Erfolg meldet und die Daten falsch sind).
 *  - HAL/STM32 eeprom_bl24cxx.cpp: schreibt nur GEAENDERTE Bytes (je ~5 ms) und prueft jedes geschriebene Byte nach; 24C16, 2 KB (pins_CREALITY_V4.h:48-52).
 *
 * LAYOUT-ANNAHMEN (alle zur Laufzeit geprueft; eine verletzte Annahme fuehrt zu "nicht verifiziert", NIE zu einem Erfolg):
 *  - Block = [EEPROM_OFFSET .. +datasize()); Kopf = version[4] + crc16; crc16 = CRC-16/XMODEM (Marlin crc16()) ueber die Bytes nach dem Kopf bis zum Blockende.
 *  - Das Mesh steht als zusammenhaengende Folge: grid_max_x, grid_max_y (je 1 Byte), bilinear_grid_spacing (2 float), bilinear_start (2 float), z_values (16 float) = 82 Bytes (settings.cpp:815-821).
 *    Es wird NICHT ueber einen festen Offset, sondern ueber die exakte Bytefolge des gemessenen Meshes im Block gefunden (muss GENAU EINMAL vorkommen).
 */
#include <stdint.h>
#include <string.h>
#include <math.h>

namespace sv04c {
namespace ee {

static const uint8_t kMeshN = 4;                                   // GRID_MAX_POINTS_X == GRID_MAX_POINTS_Y (Adapter: static_assert gegen sv04c::kN)
static const uint16_t kPts = kMeshN * kMeshN;                      // 16 Messpunkte
static const uint16_t kWireGeom = 2 + 4 * 4;                       // gx, gy, spacing(2 float), start(2 float) = 18 Bytes
static const uint16_t kWire = kWireGeom + kPts * 4;                // + 16 float = 82 Bytes
static const uint16_t kHdr = 6;                                    // version[4] + crc16
static const uint16_t kChunk = 32;
static const uint16_t kShadowHdr = 16;
static const uint16_t kGuard = 8;                                  // Abstand zwischen Marlin-Block und Journal
static const uint8_t kShadowValid = 0xA5;                          // "Transaktion laeuft": nur dieses Byte macht das Journal gueltig

// ---------------------------------------------------------------------------------------------------- Speicherhuelle
struct Store {
  void *ctx;
  uint16_t capacity;                                               // persistentStore.capacity()
  bool (*read)(void *, uint16_t pos, uint8_t *buf, uint16_t n);    // true = ok
  bool (*write)(void *, uint16_t pos, const uint8_t *buf, uint16_t n);   // true = ok (HAL: nur geaenderte Bytes, mit Nachlesen)
  void (*crc16)(uint16_t *crc, const void *data, uint16_t n);      // Marlin: crc16() (CRC-16/XMODEM, fortlaufend)
};
struct Block {                                                     // Marlin-Einstellungsblock: [start, start+len)
  uint16_t start, len;
  const char *ver;                                                 // erwartete Version (4 Bytes inkl. NUL, z. B. "V85"); nullptr = jede Form V<ziffer><ziffer> (nur Host-Tests)
  Block() : start(0), len(0), ver(nullptr) {}
};

inline bool rd(const Store &s, uint16_t pos, uint8_t *b, uint16_t n) { return n == 0 || (static_cast<uint32_t>(pos) + n <= s.capacity && s.read(s.ctx, pos, b, n)); }
inline bool wr(const Store &s, uint16_t pos, const uint8_t *b, uint16_t n) { return n == 0 || (static_cast<uint32_t>(pos) + n <= s.capacity && s.write(s.ctx, pos, b, n)); }
inline bool block_fits(const Store &s, const Block &b) { return b.len > kHdr && static_cast<uint32_t>(b.start) + b.len <= s.capacity; }

// CRC ueber [pos, pos+n) im Speicher (fortlaufend, in Chunks); false = Lesefehler
inline bool crc_range(const Store &s, uint16_t pos, uint16_t n, uint16_t &crc) {
  uint8_t buf[kChunk];
  while (n) {
    const uint16_t c = n < kChunk ? n : kChunk;
    if (!rd(s, pos, buf, c)) return false;
    s.crc16(&crc, buf, c);
    pos = static_cast<uint16_t>(pos + c); n = static_cast<uint16_t>(n - c);
  }
  return true;
}

// ---------------------------------------------------------------------------------------------------- Mesh-Abbild (82 Bytes in Marlins Schreibreihenfolge)
inline void pack_wire(const float z[kMeshN][kMeshN], const float spacing[2], const float start[2], uint8_t out[kWire]) {
  out[0] = kMeshN; out[1] = kMeshN;
  memcpy(out + 2, spacing, 8); memcpy(out + 10, start, 8); memcpy(out + kWireGeom, z, kPts * 4);
}

// Muster im Bereich [pos, pos+len) zaehlen (nicht ueberlappend gezaehlt wird NICHT: jede Fundstelle zaehlt); streamend, Fenster = Chunk + (Muster-1)
inline bool count_pattern(const Store &s, uint16_t pos, uint16_t len, const uint8_t *pat, uint16_t plen, uint16_t &count, uint16_t &first) {
  count = 0; first = 0;
  if (plen == 0 || plen > kWire || len < plen) return true;
  uint8_t win[kWire + kChunk];
  uint16_t have = 0;                                               // gueltige Bytes im Fenster
  uint16_t winpos = pos;                                           // Adresse von win[0]
  uint16_t remaining = len;
  uint16_t next = pos;
  while (remaining || have >= plen) {
    if (remaining) {
      const uint16_t c = remaining < kChunk ? remaining : kChunk;
      if (!rd(s, next, win + have, c)) return false;
      have = static_cast<uint16_t>(have + c); next = static_cast<uint16_t>(next + c); remaining = static_cast<uint16_t>(remaining - c);
    }
    uint16_t i = 0;
    for (; static_cast<uint16_t>(i + plen) <= have; ++i)
      if (memcmp(win + i, pat, plen) == 0) { if (count == 0) first = static_cast<uint16_t>(winpos + i); if (count < 0xFFFF) ++count; }
    // die letzten (plen-1) Bytes behalten; den Rest verwerfen
    const uint16_t keep = static_cast<uint16_t>(plen - 1) < have ? static_cast<uint16_t>(plen - 1) : have;
    const uint16_t drop = static_cast<uint16_t>(have - keep);
    if (drop) { memmove(win, win + drop, keep); winpos = static_cast<uint16_t>(winpos + drop); have = keep; }
    if (!remaining) break;
  }
  return true;
}

// ---------------------------------------------------------------------------------------------------- Zustand des Hauptblocks (unabhaengig von Marlin)
enum PrimaryState : uint8_t { PR_UNREADABLE = 0, PR_BLANK, PR_INTERRUPTED, PR_FOREIGN, PR_CRC_BAD, PR_VALID };
struct PrimaryInfo { PrimaryState st; uint16_t crc_stored, crc_calc; uint8_t ver[4]; };
inline bool ver_is_versioned(const uint8_t v[4]) { return v[0] == 'V' && v[1] >= '0' && v[1] <= '9' && v[2] >= '0' && v[2] <= '9' && v[3] == 0; }
inline PrimaryInfo primary_info(const Store &s, const Block &b) {
  PrimaryInfo r; memset(&r, 0, sizeof r); r.st = PR_UNREADABLE;
  if (!block_fits(s, b)) return r;
  uint8_t h[kHdr];
  if (!rd(s, b.start, h, kHdr)) return r;
  memcpy(r.ver, h, 4); r.crc_stored = static_cast<uint16_t>(h[4] | (h[5] << 8));
  if (memcmp(h, "ERR", 4) == 0) { r.st = PR_INTERRUPTED; return r; }                  // Kennung, die save() zuerst schreibt (settings.cpp:655)
  const bool ff = h[0] == 0xFF && h[1] == 0xFF && h[2] == 0xFF && h[3] == 0xFF, z0 = h[0] == 0 && h[1] == 0 && h[2] == 0 && h[3] == 0;
  // SV04 NEXT EEPROM BLANK GUARD: A blank header does not prove a blank
  // settings block. Inspect every byte before allowing the first Auto60 save.
  // A partial previous write, including a failed header write, is not blank.
  if (ff || z0) {
    const uint8_t fill = ff ? 0xFF : 0x00;
    uint8_t chunk[kChunk];
    for (uint32_t off = 0; off < b.len; ) {
      const uint16_t n = static_cast<uint16_t>((b.len - off) < kChunk ? (b.len - off) : kChunk);
      if (!rd(s, static_cast<uint16_t>(static_cast<uint32_t>(b.start) + off), chunk, n)) return r;
      for (uint16_t j = 0; j < n; ++j)
        if (chunk[j] != fill) { r.st = PR_FOREIGN; return r; }
      off += n;
    }
    r.st = PR_BLANK;
    return r;
  }
  if (!ver_is_versioned(h)) { r.st = PR_FOREIGN; return r; }
  if (b.ver && memcmp(h, b.ver, 4) != 0) { r.st = PR_FOREIGN; return r; }          // gueltig aussehende, aber ANDERE Version (z. B. V84 einer aelteren Firmware): Marlin laedt sie nicht; wird NIE automatisch ueberschrieben
  uint16_t c = 0;
  if (!crc_range(s, static_cast<uint16_t>(b.start + kHdr), static_cast<uint16_t>(b.len - kHdr), c)) { r.st = PR_UNREADABLE; return r; }
  r.crc_calc = c;
  r.st = c == r.crc_stored ? PR_VALID : PR_CRC_BAD;
  return r;
}

// ---------------------------------------------------------------------------------------------------- Unabhaengige Verifikation des gespeicherten Meshes
struct VerifyReport {
  bool readable, header_ok, crc_ok;                                // Kopf versioniert / CRC der Rohbytes stimmt (eigene Berechnung)
  bool found, unique;                                              // Mesh-Block gefunden / genau einmal
  bool geometry_equal, z_equal, values_ok;                         // Raster+Start gleich / alle 16 Werte gleich / alle gespeicherten Zahlen endlich und im Rahmen
  bool zoff_found;                                                 // gemessenes probe.offset (12 Bytes) steht im Block
  uint16_t at, matches, bad_mask;                                  // Fundstelle (absolut) / Anzahl Fundstellen / Bit i = Punkt i weicht ab
  uint16_t crc_stored, crc_calc;
  PrimaryState primary;
};
inline bool verify_ok(const VerifyReport &r) { return r.readable && r.header_ok && r.crc_ok && r.found && r.unique && r.geometry_equal && r.z_equal && r.values_ok; }

// abs_limit: Betragsgrenze fuer gespeicherte z-Werte (mm)
inline bool verify_mesh(const Store &s, const Block &b, const uint8_t wire[kWire], const uint8_t *probe_offset12, const float abs_limit, VerifyReport &r) {
  memset(&r, 0, sizeof r);
  const PrimaryInfo pi = primary_info(s, b);
  r.primary = pi.st; r.crc_stored = pi.crc_stored; r.crc_calc = pi.crc_calc;
  r.readable = pi.st != PR_UNREADABLE;
  r.header_ok = pi.st == PR_VALID || pi.st == PR_CRC_BAD;
  r.crc_ok = pi.st == PR_VALID;
  if (!r.readable) return false;
  const uint16_t rs = static_cast<uint16_t>(b.start + kHdr), rl = static_cast<uint16_t>(b.len - kHdr);
  uint16_t cnt = 0, first = 0;
  if (!count_pattern(s, rs, rl, wire, kWire, cnt, first)) { r.readable = false; return false; }
  r.matches = cnt;
  if (cnt >= 1) {
    r.found = true; r.unique = cnt == 1; r.at = first; r.geometry_equal = r.z_equal = true;
  } else {                                                         // Teilsuche: Raster+Start gefunden? dann die 16 Werte einzeln klassifizieren
    uint16_t g = 0, gf = 0;
    if (!count_pattern(s, rs, rl, wire, kWireGeom, g, gf)) { r.readable = false; return false; }
    r.matches = g;
    if (g >= 1) { r.found = true; r.unique = g == 1; r.at = gf; r.geometry_equal = true; }
  }
  if (r.found) {                                                   // gespeicherte Werte lesen (aus dem Speicher, nicht aus dem RAM)
    uint8_t buf[kWire];
    if (!rd(s, r.at, buf, kWire)) { r.readable = false; return false; }
    float v[kPts]; memcpy(v, buf + kWireGeom, sizeof v);
    float sp[2], st[2]; memcpy(sp, buf + 2, 8); memcpy(st, buf + 10, 8);
    bool vals = isfinite(sp[0]) && isfinite(sp[1]) && sp[0] > 0 && sp[1] > 0 && isfinite(st[0]) && isfinite(st[1]);
    for (uint16_t i = 0; i < kPts; ++i) {
      if (!isfinite(v[i]) || fabsf(v[i]) > abs_limit) vals = false;
      if (memcmp(buf + kWireGeom + i * 4, wire + kWireGeom + i * 4, 4) != 0) r.bad_mask = static_cast<uint16_t>(r.bad_mask | (1u << i));
    }
    r.values_ok = vals; r.z_equal = r.bad_mask == 0 && cnt >= 1;
  }
  if (probe_offset12) { uint16_t c = 0, f = 0; if (!count_pattern(s, rs, rl, probe_offset12, 12, c, f)) { r.readable = false; return false; } r.zoff_found = c >= 1; }
  return verify_ok(r);
}

// Differenzen zweier gleich langer Bereiche (z. B. Hauptblock gegen Sicherungskopie) nach Art einordnen: Kopf / Mesh / uebrige Einstellungen
struct DiffSummary { uint16_t total, header, mesh, other; uint16_t first_other[4]; };
inline bool diff_regions(const Store &s, uint16_t a, uint16_t b, uint16_t len, uint16_t mesh_off_rel, bool has_mesh, DiffSummary &d) {
  memset(&d, 0, sizeof d);
  uint8_t x[kChunk], y[kChunk];
  for (uint16_t off = 0; off < len;) {
    const uint16_t c = static_cast<uint16_t>(len - off) < kChunk ? static_cast<uint16_t>(len - off) : kChunk;
    if (!rd(s, static_cast<uint16_t>(a + off), x, c) || !rd(s, static_cast<uint16_t>(b + off), y, c)) return false;
    for (uint16_t i = 0; i < c; ++i) {
      if (x[i] == y[i]) continue;
      const uint16_t o = static_cast<uint16_t>(off + i);
      ++d.total;
      if (o < kHdr) ++d.header;
      else if (has_mesh && o >= mesh_off_rel && o < mesh_off_rel + kWire) ++d.mesh;
      else { if (d.other < 4) d.first_other[d.other] = o; ++d.other; }
    }
    off = static_cast<uint16_t>(off + c);
  }
  return true;
}

// ---------------------------------------------------------------------------------------------------- Journal (Undo-Log) gegen Stromausfall waehrend settings.save()
// Layout am ENDE des EEPROMs: [Kopf 16][Kopie des letzten GUELTIGEN Blocks]. Der Kopf wird zuletzt auf "gueltig" gesetzt und als ERSTES zurueckgenommen.
struct ShadowPlan { bool ok; uint16_t hdr, data; };
inline ShadowPlan shadow_plan(const Store &s, const Block &b) {
  ShadowPlan p; p.ok = false; p.hdr = p.data = 0;
  if (!block_fits(s, b)) return p;
  const uint32_t total = static_cast<uint32_t>(kShadowHdr) + b.len;
  if (total > s.capacity) return p;
  const uint32_t hdr = s.capacity - total;
  if (hdr < static_cast<uint32_t>(b.start) + b.len + kGuard) return p;      // kein Platz: Journal NICHT moeglich (kein Ueberschreiben anderer Daten)
  p.ok = true; p.hdr = static_cast<uint16_t>(hdr); p.data = static_cast<uint16_t>(hdr + kShadowHdr);
  return p;
}
struct ShadowInfo { bool present, inflight, data_ok; uint16_t start, len, crc, seq; };
inline void shadow_hdr_crc(const Store &s, const uint8_t h[kShadowHdr], uint16_t &crc) {          // ueber Bytes 0..4 und 6..13 (ohne Statusbyte 5 und ohne die CRC selbst)
  crc = 0; s.crc16(&crc, h, 5); s.crc16(&crc, h + 6, 8);
}
inline bool shadow_info(const Store &s, const ShadowPlan &p, const Block &b, bool check_data, ShadowInfo &i) {
  memset(&i, 0, sizeof i);
  if (!p.ok) return true;
  uint8_t h[kShadowHdr];
  if (!rd(s, p.hdr, h, kShadowHdr)) return false;
  uint16_t hc; shadow_hdr_crc(s, h, hc);
  if (memcmp(h, "S4SH", 4) != 0 || h[4] != 1 || hc != static_cast<uint16_t>(h[14] | (h[15] << 8))) return true;           // kein gueltiger Kopf
  i.present = true; i.inflight = h[5] == kShadowValid;
  i.start = static_cast<uint16_t>(h[6] | (h[7] << 8)); i.len = static_cast<uint16_t>(h[8] | (h[9] << 8)); i.crc = static_cast<uint16_t>(h[10] | (h[11] << 8)); i.seq = static_cast<uint16_t>(h[12] | (h[13] << 8));
  if (check_data && i.inflight && i.start == b.start && i.len == b.len) { uint16_t c = 0; if (!crc_range(s, p.data, i.len, c)) return false; i.data_ok = c == i.crc; }
  return true;
}
inline bool shadow_set_state(const Store &s, const ShadowPlan &p, uint8_t state) {
  uint8_t v = state, chk = 0;
  return wr(s, static_cast<uint16_t>(p.hdr + 5), &v, 1) && rd(s, static_cast<uint16_t>(p.hdr + 5), &chk, 1) && chk == state;
}
// Kopiert [src, src+n) nach [dst, dst+n) in Chunks; crc (optional) ueber die Quellbytes
inline bool copy_range(const Store &s, uint16_t src, uint16_t dst, uint16_t n, uint16_t *crc) {
  uint8_t buf[kChunk];
  for (uint16_t off = 0; off < n;) {
    const uint16_t c = static_cast<uint16_t>(n - off) < kChunk ? static_cast<uint16_t>(n - off) : kChunk;
    if (!rd(s, static_cast<uint16_t>(src + off), buf, c)) return false;
    if (crc) s.crc16(crc, buf, c);
    if (!wr(s, static_cast<uint16_t>(dst + off), buf, c)) return false;
    off = static_cast<uint16_t>(off + c);
  }
  return true;
}
enum ShadowCreate : uint8_t { SC_OK = 0, SC_NO_SPACE, SC_PRIMARY_INVALID, SC_IO, SC_VERIFY };
inline ShadowCreate shadow_create(const Store &s, const ShadowPlan &p, const Block &b, uint16_t seq) {
  if (!p.ok) return SC_NO_SPACE;
  if (primary_info(s, b).st != PR_VALID) return SC_PRIMARY_INVALID;          // nur einen GUELTIGEN Block sichern
  if (!shadow_set_state(s, p, 0)) return SC_IO;                              // 1. altes Journal ungueltig
  uint16_t crc = 0;
  if (!copy_range(s, b.start, p.data, b.len, &crc)) return SC_IO;             // 2. Kopie schreiben
  uint8_t h[kShadowHdr]; memset(h, 0, sizeof h);
  memcpy(h, "S4SH", 4); h[4] = 1; h[5] = 0;
  h[6] = static_cast<uint8_t>(b.start); h[7] = static_cast<uint8_t>(b.start >> 8); h[8] = static_cast<uint8_t>(b.len); h[9] = static_cast<uint8_t>(b.len >> 8);
  h[10] = static_cast<uint8_t>(crc); h[11] = static_cast<uint8_t>(crc >> 8); h[12] = static_cast<uint8_t>(seq); h[13] = static_cast<uint8_t>(seq >> 8);
  uint16_t hc; shadow_hdr_crc(s, h, hc); h[14] = static_cast<uint8_t>(hc); h[15] = static_cast<uint8_t>(hc >> 8);
  if (!wr(s, p.hdr, h, kShadowHdr)) return SC_IO;                              // 3. Kopf (noch ungueltig)
  uint16_t c2 = 0;
  if (!crc_range(s, p.data, b.len, c2) || c2 != crc) return SC_VERIFY;       // 4. Kopie nachlesen
  if (!shadow_set_state(s, p, kShadowValid)) return SC_IO;                    // 5. ERST JETZT gueltig
  return SC_OK;
}
inline bool shadow_invalidate(const Store &s, const ShadowPlan &p) { return !p.ok || shadow_set_state(s, p, 0); }

enum Restore : uint8_t { RS_OK = 0, RS_NO_SHADOW, RS_IO, RS_VERIFY };
// Spielt die Kopie zurueck: ZUERST Daten (Bytes nach dem Kopf), ERST ZULETZT der Kopf; der Hauptblock bleibt bis dahin "ERR"/ungueltig (kein irrefuehrend gueltig aussehender Zwischenstand)
inline Restore shadow_restore(const Store &s, const ShadowPlan &p, const Block &b) {
  ShadowInfo i; if (!shadow_info(s, p, b, true, i)) return RS_IO;
  if (!i.present || !i.inflight || !i.data_ok) return RS_NO_SHADOW;
  if (!copy_range(s, static_cast<uint16_t>(p.data + kHdr), static_cast<uint16_t>(b.start + kHdr), static_cast<uint16_t>(b.len - kHdr), nullptr)) return RS_IO;
  if (!copy_range(s, p.data, b.start, kHdr, nullptr)) return RS_IO;
  uint16_t c = 0;
  if (!crc_range(s, b.start, b.len, c)) return RS_IO;
  if (c != i.crc || primary_info(s, b).st != PR_VALID) return RS_VERIFY;
  return RS_OK;
}

enum Commit : uint8_t { CM_OK = 0, CM_ROLLED_BACK, CM_ROLLBACK_FAILED, CM_CLEAR_FAILED };
// Abschluss der Transaktion. verified=true: Journal verwerfen. verified=false: ist der Hauptblock nicht bitgleich zur Kopie -> zurueckspielen.
inline Commit commit_transaction(const Store &s, const ShadowPlan &p, const Block &b, bool verified) {
  if (!p.ok) return CM_OK;
  if (verified) return shadow_invalidate(s, p) ? CM_OK : CM_CLEAR_FAILED;
  // SV04 NEXT 304: This call is made only for a transaction expected to
  // have a live undo journal. Missing, unreadable or corrupt journal data
  // must NEVER be treated as a successful rollback/commit.
  ShadowInfo i;
  if (!shadow_info(s, p, b, true, i) || !i.present || !i.inflight ||
      i.start != b.start || i.len != b.len || !i.data_ok)
    return CM_ROLLBACK_FAILED;
  uint16_t c = 0;
  const bool same = primary_info(s, b).st == PR_VALID && crc_range(s, b.start, b.len, c) && c == i.crc;
  if (same) return shadow_invalidate(s, p) ? CM_OK : CM_CLEAR_FAILED;                                  // Hauptblock ist unveraendert
  if (shadow_restore(s, p, b) != RS_OK) return CM_ROLLBACK_FAILED;                                      // Journal bleibt GUELTIG -> naechster Start versucht es erneut
  return shadow_invalidate(s, p) ? CM_ROLLED_BACK : CM_CLEAR_FAILED;
}

// ---------------------------------------------------------------------------------------------------- Startwiederherstellung
enum BootAction : uint8_t { BA_NONE = 0, BA_CLEAR, BA_RESTORE };
// Reine Entscheidung (erschoepfend getestet). Das Journal gilt nur dann, wenn es gueltig UND seine Kopie unversehrt ist.
inline BootAction boot_decision(PrimaryState primary, bool journal_usable) {
  if (!journal_usable) return BA_NONE;
  switch (primary) {
    case PR_VALID: return BA_CLEAR;                                // Speichern war abgeschlossen (oder nie begonnen): Journal nur verwerfen
    case PR_INTERRUPTED: case PR_CRC_BAD: case PR_BLANK: return BA_RESTORE;   // unterbrochenes Schreiben
    case PR_FOREIGN: return BA_RESTORE;                            // mit gueltigem Journal im SELBEN EEPROM ist ein halb umgeschriebener Kopf ("E85", "V8R"...) ein abgerissener Schreibvorgang (Test EE40)
    default: return BA_NONE;                                       // UNREADABLE: nichts anfassen
  }
}
enum BootResult : uint8_t { BR_NOTHING = 0, BR_CLEARED, BR_RESTORED, BR_RESTORE_FAILED, BR_NO_SPACE, BR_UNAVAILABLE };
inline BootResult recover_at_boot(const Store &s, const Block &b, PrimaryState *primary_out) {
  const ShadowPlan p = shadow_plan(s, b);
  const PrimaryInfo pi = primary_info(s, b);
  if (primary_out) *primary_out = pi.st;
  if (!p.ok) return BR_NO_SPACE;
  ShadowInfo i;
  if (!shadow_info(s, p, b, true, i)) return BR_UNAVAILABLE;
  const bool usable = i.present && i.inflight && i.data_ok;
  // SV04 NEXT 301: A damaged journal must never be reported as cleared
  // when its state byte could not be invalidated. If the main block is
  // damaged too, preserve the journal for diagnosis rather than erasing it.
  if (i.present && i.inflight && !usable) {
    if (pi.st != PR_VALID) return BR_RESTORE_FAILED;
    return shadow_invalidate(s, p) ? BR_CLEARED : BR_UNAVAILABLE;
  }
  // SV04 NEXT 306: valid alone is not proof that a pending write was verified.
  // A cut after settings.save() writes a correct CRC but before Auto60 verifies
  // that the newly measured mesh matches leaves a valid *uncommitted* block.
  // Conservatively restore the previous settings when a live journal exists
  // and its byte-for-byte copy differs from the primary, even if its CRC is valid.
  // A power cut just before closing the journal can lose the newly measured
  // mesh, but must not silently commit unverified settings.
  BootAction decision = boot_decision(pi.st, usable);
  if (decision == BA_CLEAR && usable) {
    bool equal = true;
    uint8_t original[kChunk], current[kChunk];
    for (uint16_t off = 0; off < b.len;) {
      const uint16_t n = static_cast<uint16_t>(b.len - off) < kChunk ? static_cast<uint16_t>(b.len - off) : kChunk;
      if (!rd(s, static_cast<uint16_t>(p.data + off), original, n) ||
          !rd(s, static_cast<uint16_t>(b.start + off), current, n))
        return BR_UNAVAILABLE;  // unreadable: retain journal and block Auto60
      if (memcmp(original, current, n) != 0) { equal = false; break; }
      off = static_cast<uint16_t>(off + n);
    }
    if (!equal) decision = BA_RESTORE;
  }
  switch (decision) {
    case BA_CLEAR: return shadow_invalidate(s, p) ? BR_CLEARED : BR_UNAVAILABLE;
    case BA_RESTORE:
      if (shadow_restore(s, p, b) != RS_OK) return BR_RESTORE_FAILED;
      // The data was restored, but incomplete journal cleanup is NOT a
      // completed recovery. Keep the transaction blocked and diagnosable.
      return shadow_invalidate(s, p) ? BR_RESTORED : BR_UNAVAILABLE;
    default: return BR_NOTHING;
  }
}

}  // namespace ee
}  // namespace sv04c
