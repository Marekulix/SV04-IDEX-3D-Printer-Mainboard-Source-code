#!/usr/bin/env python3
"""Independent source composition regression against 287 pinned integration fixtures.
This is NOT a full firmware compilation, nor a hardware qualification.
"""
from pathlib import Path
import tempfile,shutil,subprocess,sys,hashlib
P=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='sv04_306_compose_') as td:
    o=Path(td)/'oem'
    shutil.copytree(P/'fixtures'/'baseline_287',o)
    def run():
        r=subprocess.run([sys.executable,str(P/'integrate_306.py'),str(o)],capture_output=True,text=True)
        if r.returncode:
            print('COMPOSE_FAILED',r.returncode,r.stdout[-10000:],r.stderr[-10000:],sep='\n')
            sys.exit(r.returncode)
        assert 'SV04_NEXT_306_COMPOSITION=PASS' in r.stdout
    def hashes():
        return {f.relative_to(o).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in o.rglob('*') if f.is_file()}
    run(); first=hashes()
    run(); second=hashes()
    assert first==second,'ERROR: second application changed source'
    assert len(first)==8, f'expected baseline 6 plus 2 C2 headers; got {len(first)}: {list(first)}'
    code=(o/'Marlin/src/feature/sv04_claude_auto60/sv04_claude_eeprom_core.h').read_text()
    assert 'if (!equal) decision = BA_RESTORE;' in code
    assert 'return BR_UNAVAILABLE;  // unreadable: retain journal and block Auto60' in code
    adapter=(o/'Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc').read_text()
    assert adapter.index('SV04 NEXT 302: verify') < adapter.index('SV04 NEXT 303: resend mesh')
    assert 'if (c > 0 && IsStopped()) return;' in adapter
    assert 'SV04 NEXT 305: refusal reason before return' in adapter
    tc=(o/'Marlin/src/gcode/control/T.cpp').read_text()
    assert 'if (!sv04c_t_allowed(tool_index)) return;' in tc
    print('COMPOSITION_306_PASS files=',len(first),'rerun=idempotent')
