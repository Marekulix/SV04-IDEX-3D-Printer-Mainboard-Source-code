#!/usr/bin/env python3
"""307 regression: simulate the actual 306 break (missing EEPROM core header).
Positive install, repeatability, and rejection of alien sources.
Not an OEM STM32 compilation.
"""
from pathlib import Path
import tempfile,shutil,subprocess,sys,hashlib
P=Path(__file__).resolve().parents[1]
H=Path('Marlin/src/feature/sv04_claude_auto60')
FIXTURE=P/'fixtures/baseline_287'
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def run(p,expect=True):
    r=subprocess.run([sys.executable,str(P/'integrate_307.py'),str(p)],capture_output=True,text=True)
    if expect:
        assert r.returncode==0, 'Unexpected failure: '+r.stdout+'\n'+r.stderr
        assert 'SV04_NEXT_307_COMPOSITION=PASS' in r.stdout,r.stdout
    else:
        assert r.returncode!=0,'An unexpected existing header was accepted'
    return r
with tempfile.TemporaryDirectory(prefix='sv04_307_') as td:
    base=Path(td)
    # All three: same baseline, only EEPROM header missing (the actual 306 failure).
    p=base/'missing_eeprom';shutil.copytree(FIXTURE,p)
    (p/H/'sv04_claude_eeprom_core.h').unlink()
    r=run(p)
    assert 'HEADER_307 SUPPLIED sv04_claude_eeprom_core.h' in r.stdout
    assert 'SV04_NEXT_306_COMPOSITION=PASS' in r.stdout
    first={str(f.relative_to(p)):sha(f) for f in p.rglob('*') if f.is_file()}
    run(p)
    assert first=={str(f.relative_to(p)):sha(f) for f in p.rglob('*') if f.is_file()},'rerun changed files'
    print('PASS 307_01 actual 306 missing core header now repaired and composition passed')
    print('PASS 307_02 second application is idempotent')
    # Simulate all standalone new headers absent after earlier assembler.
    p=base/'missing_three';shutil.copytree(FIXTURE,p)
    for n in ['sv04_claude_eeprom_core.h','sv04_claude_auto60_core.h','sv04_claude_g29_session.h']:
        (p/H/n).unlink()
    r=run(p);assert r.stdout.count('HEADER_307 SUPPLIED')==3,r.stdout
    print('PASS 307_03 all 3 missing standalone headers supplied from pinned 287 originals')
    # Refuse alien existing data (never overwrite somebody else's firmware).
    p=base/'alien';shutil.copytree(FIXTURE,p)
    target=p/H/'sv04_claude_eeprom_core.h';target.write_text('#pragma once\n// wrong repository source!\n')
    before=sha(target);r=run(p,expect=False)
    assert sha(target)==before
    assert 'UNKNOWN_EXISTING_HEADER_NOT_OVERWRITTEN' in r.stderr,r.stderr
    print('PASS 307_04 foreign header rejected and not overwritten')
    # Revalidate checked source identity and manifest of all 287 headers.
    import importlib.util
    spec=importlib.util.spec_from_file_location('ensure',P/'ensure_287_headers_307.py')
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    for name,pin in mod.PINNED.items():assert sha(FIXTURE/H/name)==pin
    print('PASS 307_05 pinned header hashes match archived 287 sources')
print('SUMMARY tests=5 pass=5 fail=0')
