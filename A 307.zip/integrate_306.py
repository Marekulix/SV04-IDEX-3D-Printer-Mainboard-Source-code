#!/usr/bin/env python3
"""SV04 NEXT 306 — apply G29/EEPROM/C2 composition to a pinned OEM tree already
integrated with SV04_NEXT_287.zip and 288/290 planner guards. No flash.
Fail immediately if any guard refuses a source state.
"""
from pathlib import Path
import sys, subprocess, hashlib
ROOT=Path(__file__).resolve().parent

def run(script, arg):
    print('APPLY',script,'TARGET',arg,flush=True)
    subprocess.run([sys.executable,str(ROOT/script),str(arg)],check=True)

def main(dest):
    dest=Path(dest).resolve()
    marlin=dest/'Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc'
    ee=dest/'Marlin/src/feature/sv04_claude_auto60/sv04_claude_eeprom_core.h'
    g29=dest/'Marlin/src/gcode/bedlevel/abl/G29.cpp'
    tool=dest/'Marlin/src/gcode/control/T.cpp'
    for f in [marlin,ee,g29,tool]:
        if not f.is_file():raise RuntimeError('MISSING actual integrated file: '+str(f))
    run('patches/apply_g29_merge_299.py',dest)
    for s in ('apply_eeprom_policy_292.py','apply_eeprom_commit_guard_293.py'):
        run('patches/'+s,dest)
    run('patches/apply_eeprom_coordinator_294.py',dest)
    for s in ('apply_eeprom_blank_guard_300.py','apply_eeprom_boot_recovery_301.py','apply_eeprom_commit_failclosed_304.py','apply_eeprom_unverified_valid_306.py'):
        run('patches/'+s,ee)
    for s in ('apply_eeprom_post_boot_302.py','apply_eeprom_display_guard_303.py'):
        run('patches/'+s,marlin)
    run('patches/apply_refusal_305.py',dest)
    run('claude/03_PATCHES/apply_stop_heater_guard_c2.py',dest)
    run('claude/03_PATCHES/apply_toolchange_guard_c2.py',dest)
    expectations={
      marlin:['SV04 NEXT 299 G29 cancellation:','SV04 NEXT 292: testable conservative policy','SV04 NEXT 293: journal closure must be confirmed', 'SV04 NEXT 302: verify the actual primary block','SV04 NEXT 303: resend mesh only after verified EEPROM recovery.', 'SV04 NEXT 305: refusal reason before return','SV04 NEXT C2: stop()'],
      ee:['SV04 NEXT EEPROM BLANK GUARD','SV04 NEXT 301','SV04 NEXT 304','SV04 NEXT 306: valid alone is not proof'],
      g29:['SV04 NEXT 299: recheck immediately before G28 XY end-script'],
      tool:['SV04 NEXT C2','sv04c_t_allowed(tool_index)'],
    }
    for f,markers in expectations.items():
        content=f.read_text(encoding='utf-8')
        for m in markers:
            assert m in content, f'MISSING_MARKER {m} in {f}'
        print('VERIFY',f.relative_to(dest),'sha256',hashlib.sha256(f.read_bytes()).hexdigest())
    assert (dest/'Marlin/src/gcode/control/sv04_claude_toolchange_guard.h').is_file()
    assert (dest/'Marlin/src/feature/sv04_claude_auto60/sv04_claude_toolchange_policy.h').is_file()
    print('SV04_NEXT_306_COMPOSITION=PASS')
if __name__=='__main__':
    if len(sys.argv)!=2:sys.exit('usage: python integrate_306.py <fully_integrated_OEM_ROOT>')
    main(sys.argv[1])
