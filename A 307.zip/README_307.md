# SV04 NEXT 307 – reale GitHub-306-Integrationsluecke geschlossen

**NICHT FLASHEN. Hardwaretest ausstehend. Letzter nachweislich erfolgreicher STM32-Build: 291.**

## Konkreter Fehler von 306
Der GitHub-Lauf 306 bestand alle Hosttests, stoppte aber vor PlatformIO mit `MISSING actual integrated file: .../sv04_claude_eeprom_core.h`. Das 286-Integrationsskript hatte diese neue Claude-Headerdatei nicht im OEM-Baum angelegt. Die Quelle liegt signiert in der archivierten 287-Entwicklung und war bereits als `fixtures/baseline_287/...` in 306 enthalten.

## Korrektur 307
Vor der unveraenderten 306-Patchkette kontrolliert `ensure_287_headers_307.py` drei eigenstaendige Originaldateien aus Stand 287:
- `sv04_claude_auto60_core.h`
- `sv04_claude_eeprom_core.h`
- `sv04_claude_g29_session.h`

Fehlt eine Datei, wird sie aus der eingebetteten, SHA-256-gepinnten 287-Referenz neu angelegt. Bestehende Dateien werden **niemals ueberschrieben**. Nur bytegenau bekannte Originale bzw. der bekannte voll gepatchte 306-EEPROM-Core sind zugelassen; jede unbekannte vorhandene Variante wird abgelehnt. Das Skript ist bei wiederholter Ausfuehrung idempotent.

`integrate_307.py` ruft zuerst diese Quellepruefung/Nachlieferung auf und danach `integrate_306.py` mit der gesamten unveraenderten G29-/EEPROM-/Claude-C2-Patchfolge. Alle Funktionen aus Version 306 bleiben erhalten. Auch die ZIP-Pruefsummenpruefung umfasst die neuen Dateien.

## Tests
- 5/5 neue 307-Regressionen: exakt die fehlende Datei aus Run 306, alle drei fehlenden Dateien, Idempotenz, Fremdquellschutz, feste Original-SHA.
- 50/50 EEPROM-C++-Tests erneut bestanden.
- Bestehende 306-Koordinator-/C2-/G29-/Planner-Pruefungen im GitHub-Workflow weiterhin strikt aktiv.
- **Die gesamte Firmware ist lokal nicht als ARM-STM32-Build kompiliert.** Das GitHub-Workflow-Ergebnis bleibt offen.

## GitHub-Upload
`A 307.zip` ins Repo-Hauptverzeichnis, `B 307.yml` nach `.github/workflows/`, Dateinamen unveraendert. GitHub Actions `307` manuell starten. Keine Flashaktion.

## Sicherheitsgrenzen
T0/T1 mechanische Kollision, BLTouch ohne Trigger und interne Werkzeugwechselpfade sind noch nicht vollstaendig am Geraet verifiziert.
