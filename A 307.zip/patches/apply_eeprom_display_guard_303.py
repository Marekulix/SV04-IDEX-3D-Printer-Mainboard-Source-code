#!/usr/bin/env python3
"""SV04 NEXT 303: update DWIN mesh only after post-restore EEPROM validation."""
from pathlib import Path
import sys
from importlib.util import spec_from_file_location,module_from_spec

MARK='// SV04 NEXT 303: resend mesh only after verified EEPROM recovery.'
OLD='''    #if SV04_CLAUDE_G29_RESEND
      if (loaded) sv04c_send_oem_mesh();       // die OEM-Bootschleife hat VOR der Wiederherstellung die Standardwerte gesendet: ohne erneutes Senden zeigte das Display ein LEERES Mesh, obwohl das alte gueltig ist
    #endif'''
NEW='''    // SV04 NEXT 303: defer display update until the recovered EEPROM primary
    // has independently passed the post-boot validation below.'''
ANCHOR='''  // SV04 NEXT 302: verify the actual primary block after journal recovery/cleanup.'''
INSERT='''  // SV04 NEXT 303: resend mesh only after verified EEPROM recovery.
  // Never present a restored mesh as successful if the raw EEPROM recheck
  // failed or Marlin could not reload its settings.
  #if SV04_CLAUDE_G29_RESEND
    if (r == sv04c::ee::BR_RESTORED && !sv04c_ee_boot_blocked)
      sv04c_send_oem_mesh();
  #endif
'''

def patch(source):
    if source.count(MARK)==1:
        if OLD in source: raise ValueError('303 partially installed: early resend remains')
        return source
    if MARK in source:raise ValueError('303 duplicated')
    if source.count(OLD)!=1:raise ValueError('original resend anchor missing or ambiguous')
    if source.count(ANCHOR)!=1:raise ValueError('302 verification anchor missing or ambiguous')
    start=source.find('static void sv04c_ee_boot() {')
    end=source.find('\nstatic bool sv04c_ee_start_ok()',start)
    if start<0 or end<0 or not start<source.index(OLD)<source.index(ANCHOR)<end:
        raise ValueError('unexpected boot-handler ordering')
    snippet=source[start:end].replace(OLD,NEW,1)
    # Place immediately after post-validation block but before function closing brace.
    close=snippet.rfind('\n}')
    if close<0:raise ValueError('boot closing brace missing')
    snippet=snippet[:close]+'\n'+INSERT.rstrip()+snippet[close:]
    return source[:start]+snippet+source[end:]

if __name__=='__main__':
    if len(sys.argv)!=2: raise SystemExit('Usage: apply_eeprom_display_guard_303.py <sv04_claude_auto60_marlin.inc>')
    p=Path(sys.argv[1]); before=p.read_text();after=patch(before)
    if after!=before:p.write_text(after)
    print('SV04 NEXT 303:', 'already installed' if before==after else 'patched')
