#!/usr/bin/env python3
"""294: Reject Auto60 success if persistent journal finalization fails.
Requires the exact 285/287 coordinator source before applying the patch.
No other files are altered. The 292/293 adapter fixes are separate and additive.
"""
from pathlib import Path
import sys
TARGET=Path('Marlin/src/feature/sv04_claude_auto60/sv04_claude_auto60_core.h')
OLD='if (good) { finish_eeprom(true); go(ST_SUCCESS, R_VERIFIED); restore_heater(); disp(D_RESULT); return; }'
NEW='if (good) {\n      // SV04 NEXT 294: successful readback alone cannot prove journal finalization.\n      // A failed final EEPROM write must never produce ST_SUCCESS / R_VERIFIED.\n      // If saving was skipped because bytes were already identical, there is\n      // deliberately no journal to close.\n      if (save_prepared_ && !finish_eeprom(true)) {\n        fail(R_EEPROM_RECOVERY_REQUIRED);\n        return;\n      }\n      go(ST_SUCCESS, R_VERIFIED); restore_heater(); disp(D_RESULT); return;\n    }'
MARK='SV04 NEXT 294: successful readback alone cannot prove journal finalization.'
def apply(s):
    if MARK in s:
        if s.count(MARK)!=1: raise ValueError('duplicate marker')
        return s,False
    if s.count(OLD)!=1: raise ValueError('294 requires exactly one known coordinator site')
    return s.replace(OLD,NEW,1),True
if __name__=='__main__':
    if len(sys.argv)!=2: sys.exit('Usage: apply_eeprom_coordinator_294.py /path/to/oem')
    path=Path(sys.argv[1])/TARGET
    source=path.read_text(encoding='utf-8'); result,changed=apply(source)
    if changed: path.write_text(result,encoding='utf-8')
    print('EEPROM_COORDINATOR_294='+('PATCHED' if changed else 'ALREADY_PATCHED'))
