#!/usr/bin/env python3
"""Apply SV04 301 recovery-result fixes to the exact EEPROM core from 300."""
from pathlib import Path
import sys

OLD_BAD = '  if (i.present && i.inflight && !usable) { shadow_invalidate(s, p); return pi.st == PR_VALID ? BR_CLEARED : BR_RESTORE_FAILED; }    // Journal beschaedigt: nicht verwenden'
NEW_BAD = '''  // SV04 NEXT 301: A damaged journal must never be reported as cleared
  // when its state byte could not be invalidated. If the main block is
  // damaged too, preserve the journal for diagnosis rather than erasing it.
  if (i.present && i.inflight && !usable) {
    if (pi.st != PR_VALID) return BR_RESTORE_FAILED;
    return shadow_invalidate(s, p) ? BR_CLEARED : BR_UNAVAILABLE;
  }'''
OLD_RESTORE = '    case BA_RESTORE: if (shadow_restore(s, p, b) != RS_OK) return BR_RESTORE_FAILED; shadow_invalidate(s, p); return BR_RESTORED;'
NEW_RESTORE = '''    case BA_RESTORE:
      if (shadow_restore(s, p, b) != RS_OK) return BR_RESTORE_FAILED;
      // The data was restored, but incomplete journal cleanup is NOT a
      // completed recovery. Keep the transaction blocked and diagnosable.
      return shadow_invalidate(s, p) ? BR_RESTORED : BR_UNAVAILABLE;'''

def patch(s):
    if NEW_BAD in s and NEW_RESTORE in s:
        return s
    if NEW_BAD in s or NEW_RESTORE in s:
        raise ValueError('Partial 301 patch detected')
    if s.count(OLD_BAD) != 1 or s.count(OLD_RESTORE) != 1:
        raise ValueError('301 recovery anchors missing or ambiguous')
    return s.replace(OLD_BAD, NEW_BAD).replace(OLD_RESTORE, NEW_RESTORE)

if __name__ == '__main__':
    if len(sys.argv) != 2: raise SystemExit('usage: python3 apply_eeprom_boot_recovery_301.py path/to/sv04_claude_eeprom_core.h')
    p=Path(sys.argv[1]);s=p.read_text();new=patch(s)
    if new != s:p.write_text(new)
    print('SV04 NEXT 301: recovery safeguards installed')
