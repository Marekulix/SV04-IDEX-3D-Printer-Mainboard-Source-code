#!/usr/bin/env python3
"""SV04 NEXT 292: Auto60 EEPROM policy: default journal required and boot fail-closed.
Input: a tree already integrated from 285/287/291 with the same Auto60 inc.
Never replaces files wholesale. Blocks unknown content, idempotent.
"""
from pathlib import Path
import sys
import re
TARGET = Path('Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc')
POLICY = '// SV04 NEXT 292: testable conservative policy for a known primary block.\n// The first write into a blank EEPROM has no valid previous block to restore.\nstatic bool sv04c_ee_policy_allows(const bool blank, const bool valid, const bool journal_room, const bool journal_required) {\n  return blank || (valid && (journal_room || !journal_required));\n}\n'

def replace_once(text, before, after):
    if text.count(before) != 1:
        raise ValueError('Anchor is missing or ambiguous: ' + before[:90])
    return text.replace(before, after, 1)

def apply(s):
    if '// SV04 NEXT 292: testable conservative policy' in s:
        return s, False
    # SV04 NEXT 298: Match the declaration, not exact whitespace/comment formatting.
    # Do not silently modify unknown, multiple, or already-changed definitions.
    pattern = re.compile(r'(?m)^(?P<indent>[ \t]*)#define[ \t]+SV04_CLAUDE_EEPROM_REQUIRE_JOURNAL[ \t]+(?P<value>[^ \t\r\n]+)[^\r\n]*$')
    matches = list(pattern.finditer(s))
    if len(matches) != 1 or matches[0].group('value') != '0':
        raise ValueError('Expected exactly one journal setting with value 0; found ' + repr([m.group(0) for m in matches]))
    m = matches[0]
    s = (s[:m.start()] + m.group('indent')
         + '#define SV04_CLAUDE_EEPROM_REQUIRE_JOURNAL 1   // SV04 NEXT 292/298: occupied EEPROM requires an undo journal'
         + s[m.end():])
    s=replace_once(s,
      'static uint16_t sv04c_ee_unprotected_saves = 0;       // erfolgreiche Speicherungen OHNE Undo-Journal seit dem Start (in M1060 S3)',
      'static uint16_t sv04c_ee_unprotected_saves = 0;       // erfolgreiche Speicherungen OHNE Undo-Journal seit dem Start (in M1060 S3)\nstatic bool sv04c_ee_boot_blocked = false;  // SV04 NEXT 292: failed journal recovery / failed post-recovery reload')
    s=replace_once(s,
      'static void sv04c_ee_msg(const char *what) { SERIAL_ECHO_START(); SERIAL_ECHOPGM("Auto60 EEPROM: "); SERIAL_ECHO(what); SERIAL_EOL(); }',
      POLICY+'\nstatic void sv04c_ee_msg(const char *what) { SERIAL_ECHO_START(); SERIAL_ECHOPGM("Auto60 EEPROM: "); SERIAL_ECHO(what); SERIAL_EOL(); }')
    s=replace_once(s,
      'const bool loaded = settings.load();\n    sv04c_ee_msg(loaded ?',
      'const bool loaded = settings.load();\n    if (!loaded) sv04c_ee_boot_blocked = true;\n    sv04c_ee_msg(loaded ?')
    s=replace_once(s,
      'else if (r == sv04c::ee::BR_RESTORE_FAILED) sv04c_ee_msg("FEHLER: unterbrochenes Speichern konnte NICHT zurueckgespielt werden");',
      'else if (r == sv04c::ee::BR_RESTORE_FAILED) { sv04c_ee_boot_blocked = true; sv04c_ee_msg("FEHLER: unterbrochenes Speichern konnte NICHT zurueckgespielt werden"); }\n  else if (r == sv04c::ee::BR_UNAVAILABLE) { sv04c_ee_boot_blocked = true; sv04c_ee_msg("FEHLER: Journal-Status beim Start nicht lesbar"); }')
    s=replace_once(s,
      'sv04c_ee_boot();\n  Sv04cEeAccess acc; if (!acc.ok) return false;\n  const sv04c::ee::Store s = sv04c_ee_store(); const sv04c::ee::Block b = sv04c_ee_block();',
      'sv04c_ee_boot();\n  if (sv04c_ee_boot_blocked) return false; // 292: no new Auto60 write after failed recovery or reload\n  Sv04cEeAccess acc; if (!acc.ok) return false;\n  const sv04c::ee::Store s = sv04c_ee_store(); const sv04c::ee::Block b = sv04c_ee_block();')
    s=replace_once(s,
      'if (pi.st == sv04c::ee::PR_BLANK) { sv04c_ee_announce(3); return true; }\n  if (pi.st != sv04c::ee::PR_VALID) return false;\n  const bool room = sv04c::ee::shadow_plan(s, b).ok;',
      'const bool blank = pi.st == sv04c::ee::PR_BLANK;\n  const bool valid = pi.st == sv04c::ee::PR_VALID;\n  if (!blank && !valid) return false;\n  if (blank) { sv04c_ee_announce(3); return true; }\n  const bool room = sv04c::ee::shadow_plan(s, b).ok;\n  if (!sv04c_ee_policy_allows(blank, valid, room, SV04_CLAUDE_EEPROM_REQUIRE_JOURNAL)) return false;')
    s=replace_once(s,
      'static bool sv04c_ee_prepare(void *, uint32_t) {\n  Sv04cEeAccess acc; if (!acc.ok) return false;',
      'static bool sv04c_ee_prepare(void *, uint32_t) {\n  if (sv04c_ee_boot_blocked) return false; // 292: prevent write after recovery failure\n  Sv04cEeAccess acc; if (!acc.ok) return false;')
    s=replace_once(s,
      'if (!p.ok) { if (SV04_CLAUDE_EEPROM_REQUIRE_JOURNAL) return false; sv04c_ee_journal = 2; sv04c_ee_announce(2); return true; }',
      'if (!sv04c_ee_policy_allows(false, true, p.ok, SV04_CLAUDE_EEPROM_REQUIRE_JOURNAL)) return false;\n  if (!p.ok) { sv04c_ee_journal = 2; sv04c_ee_announce(2); return true; }')
    return s, True

if __name__=='__main__':
    if len(sys.argv)!=2:
        sys.exit('usage: python3 apply_eeprom_policy_292.py /path/to/integrated/OEM')
    dest=Path(sys.argv[1])/TARGET
    data=dest.read_text(encoding='utf-8')
    modified, done=apply(data)
    if done: dest.write_text(modified, encoding='utf-8')
    print('SV04 EEPROM 292:', 'PATCHED' if done else 'ALREADY_PATCHED', dest)
