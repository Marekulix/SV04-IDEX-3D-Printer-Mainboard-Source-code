#!/usr/bin/env python3
"""Apply SV04 NEXT 304 fail-closed journal commit fix, safely and idempotently."""
import pathlib
import sys

OLD = '  ShadowInfo i; if (!shadow_info(s, p, b, true, i) || !i.present || !i.inflight) return CM_OK;       // nichts in Arbeit\n'
NEW = '''  // SV04 NEXT 304: This call is made only for a transaction expected to
  // have a live undo journal. Missing, unreadable or corrupt journal data
  // must NEVER be treated as a successful rollback/commit.
  ShadowInfo i;
  if (!shadow_info(s, p, b, true, i) || !i.present || !i.inflight ||
      i.start != b.start || i.len != b.len || !i.data_ok)
    return CM_ROLLBACK_FAILED;
'''

def apply(txt):
    if txt.count(NEW) == 1 and OLD not in txt:
        return txt, 'already applied'
    if txt.count(OLD) != 1 or NEW in txt:
        raise ValueError('Unknown, conflicting or ambiguous EEPROM core; refusing modification')
    if 'inline Commit commit_transaction(' not in txt or 'enum Commit : uint8_t' not in txt:
        raise ValueError('Commit function context missing')
    return txt.replace(OLD, NEW), 'patched'

def main():
    if len(sys.argv) != 2:
        raise SystemExit('Usage: python3 apply_eeprom_commit_failclosed_304.py <sv04_claude_eeprom_core.h>')
    path = pathlib.Path(sys.argv[1]); original = path.read_text(encoding='utf-8')
    amended, result = apply(original)
    if amended != original:
        path.write_text(amended, encoding='utf-8')
    print(result)

if __name__ == '__main__': main()
