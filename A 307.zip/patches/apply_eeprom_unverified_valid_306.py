#!/usr/bin/env python3
"""SV04 NEXT 306: preserve pre-transaction EEPROM when a fully CRC-valid but
unverified new settings block survives a power cut before journal closure.
Fail closed on unexpected sources; patch 304 must already be applied.
"""
import sys
from pathlib import Path
MARK='// SV04 NEXT 306: valid alone is not proof that a pending write was verified.'
ORIGINAL='''  switch (boot_decision(pi.st, usable)) {
    case BA_CLEAR: return shadow_invalidate(s, p) ? BR_CLEARED : BR_UNAVAILABLE;'''
NEW='''  // SV04 NEXT 306: valid alone is not proof that a pending write was verified.
  // A cut after settings.save() writes a correct CRC but before Auto60 verifies
  // that the newly measured mesh matches leaves a valid *uncommitted* block.
  // Conservatively restore the previous settings when a live journal exists
  // and its byte-for-byte copy differs from the primary, even if its CRC is valid.
  // A power cut just before closing the journal can lose the newly measured
  // mesh, but must not silently commit unverified settings.
  BootAction decision = boot_decision(pi.st, usable);
  if (decision == BA_CLEAR && usable) {
    bool equal = true;
    uint8_t original[kChunk], current[kChunk];
    for (uint16_t off = 0; off < b.len;) {
      const uint16_t n = static_cast<uint16_t>(b.len - off) < kChunk ? static_cast<uint16_t>(b.len - off) : kChunk;
      if (!rd(s, static_cast<uint16_t>(p.data + off), original, n) ||
          !rd(s, static_cast<uint16_t>(b.start + off), current, n))
        return BR_UNAVAILABLE;  // unreadable: retain journal and block Auto60
      if (memcmp(original, current, n) != 0) { equal = false; break; }
      off = static_cast<uint16_t>(off + n);
    }
    if (!equal) decision = BA_RESTORE;
  }
  switch (decision) {
    case BA_CLEAR: return shadow_invalidate(s, p) ? BR_CLEARED : BR_UNAVAILABLE;'''

def patch(s):
    if MARK in s:
        if s.count(MARK)!=1 or s.count(NEW)!=1:raise ValueError('306 partial/ambiguous installation')
        return s,False
    if s.count(ORIGINAL)!=1:raise ValueError(f'306 unexpected boot handler: anchors {s.count(ORIGINAL)}')
    if 'SV04 NEXT 304' not in s or 'SV04 NEXT 301' not in s:raise ValueError('306 requires EEPROM 301/304')
    return s.replace(ORIGINAL,NEW),True
if __name__=='__main__':
    if len(sys.argv)!=2:sys.exit('usage: apply_eeprom_unverified_valid_306.py <path_to_eeprom_core.h>')
    f=Path(sys.argv[1]); s=f.read_text(encoding='utf-8'); output,changed=patch(s)
    if changed:f.write_text(output,encoding='utf-8')
    print('EEPROM_306=', 'PATCHED' if changed else 'ALREADY',f)
