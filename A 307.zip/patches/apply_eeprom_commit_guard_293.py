#!/usr/bin/env python3
"""SV04 NEXT 293: fail-closed treatment of incomplete EEPROM journal close.
Must be applied AFTER apply_eeprom_policy_292.py on integrated 291 source.
"""
from pathlib import Path
import sys
TARGET=Path('Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc')
MARK='// SV04 NEXT 293: journal closure must be confirmed before success'

def replace_once(s, before, after):
    if s.count(before)!=1:
        raise ValueError('293 requires exactly one trusted anchor: '+before[:90])
    return s.replace(before,after,1)

def apply(s):
    if MARK in s: return s,False
    if 'SV04 NEXT 292: testable conservative policy' not in s:
        raise ValueError('293 requires verified 292 precursor')
    before='''  sv04c_ee_journal = 0;
  Sv04cEeAccess acc; if (!acc.ok) { sv04c_ee_last_commit = 6; return false; }                                  // Journal bleibt gueltig: der naechste Start versucht es erneut'''
    after='''  // SV04 NEXT 293: journal closure must be confirmed before success.
  // Keep journal=1 until finalization is successful; a failed close must
  // prevent another Auto60 write in this boot session.
  Sv04cEeAccess acc;
  if (!acc.ok) { sv04c_ee_last_commit = 6; sv04c_ee_boot_blocked = true; return false; }'''
    s=replace_once(s,before,after)
    before='''  if (r == sv04c::ee::CM_ROLLBACK_FAILED) { sv04c_ee_msg("FEHLER: alter Block konnte NICHT zurueckgespielt werden (Journal bleibt, naechster Start versucht es)"); return false; }
  if (!verified) {                                                                                             // "konsistent" wird NACHGEWIESEN: der Hauptblock muss jetzt gueltig sein (ein toter Bus liefert Muell ohne Fehlermeldung; dann sieht ein fehlendes Journal wie "nichts zu tun" aus)
    if (sv04c::ee::primary_info(s, b).st != sv04c::ee::PR_VALID) { sv04c_ee_last_commit = 7; return false; }
  }
  return true;'''
    after='''  if (r == sv04c::ee::CM_ROLLBACK_FAILED) {
    sv04c_ee_boot_blocked = true;
    sv04c_ee_msg("FEHLER: alter Block konnte NICHT zurueckgespielt werden (Journal bleibt, naechster Start versucht es)");
    return false;
  }
  if (r == sv04c::ee::CM_CLEAR_FAILED) {
    sv04c_ee_boot_blocked = true;
    sv04c_ee_msg("FEHLER: Undo-Journal konnte nicht sicher beendet werden; Auto60-Speicherung gesperrt");
    return false;
  }
  if (!verified) {                                                                                             // "konsistent" wird NACHGEWIESEN: der Hauptblock muss jetzt gueltig sein
    if (sv04c::ee::primary_info(s, b).st != sv04c::ee::PR_VALID) {
      sv04c_ee_last_commit = 7;
      sv04c_ee_boot_blocked = true;
      return false;
    }
  }
  sv04c_ee_journal = 0;  // only after complete journal close and (when needed) primary verification
  return true;'''
    s=replace_once(s,before,after)
    return s,True

if __name__=='__main__':
    if len(sys.argv)!=2: sys.exit('Usage: apply_eeprom_commit_guard_293.py /path/to/integrated/OEM')
    p=Path(sys.argv[1])/TARGET
    old=p.read_text(encoding='utf-8'); new,changed=apply(old)
    if changed: p.write_text(new,encoding='utf-8')
    print('EEPROM293:', 'PATCHED' if changed else 'ALREADY_PATCHED',p)
