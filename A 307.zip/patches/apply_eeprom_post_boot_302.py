#!/usr/bin/env python3
"""SV04 NEXT 302: verify primary EEPROM AFTER reported journal cleanup/recovery.
Only touches sv04_claude_auto60_marlin.inc. Fail closed on unknown sources.
"""
import pathlib, sys
MARK='// SV04 NEXT 302: verify the actual primary block after journal recovery/cleanup.'
ANCHOR='  else if (r == sv04c::ee::BR_CLEARED) sv04c_ee_msg("altes Journal verworfen");'
INSERT='''
  // SV04 NEXT 302: verify the actual primary block after journal recovery/cleanup.
  // A successful journal operation alone is not proof that the main settings block
  // is still readable and valid. In particular, don't allow Auto60 to save to a
  // damaged EEPROM after a driver falsely reports a completed write.
  if (r == sv04c::ee::BR_RESTORED || r == sv04c::ee::BR_CLEARED) {
    bool verified_primary = false;
    {
      Sv04cEeAccess verify_access;
      if (verify_access.ok)
        verified_primary = sv04c::ee::primary_info(sv04c_ee_store(), sv04c_ee_block()).st == sv04c::ee::PR_VALID;
    }
    if (!verified_primary) {
      sv04c_ee_boot_blocked = true;
      sv04c_ee_msg("FEHLER: EEPROM-Hauptblock nach Journalbereinigung nicht gueltig; Auto60-Speichern gesperrt");
    }
  }
'''
def patch(txt):
    if txt.count(MARK)==1:
        if txt.count(ANCHOR)!=1: raise ValueError('302 already installed, but baseline anchor changed')
        return txt
    if MARK in txt: raise ValueError('duplicate/ambiguous 302 marker')
    start=txt.find('static void sv04c_ee_boot() {')
    end=txt.find('\nstatic bool sv04c_ee_start_ok()',start)
    if start<0 or end<0:raise ValueError('boot/start functions absent')
    snippet=txt[start:end]
    if snippet.count(ANCHOR)!=1:raise ValueError('boot anchor missing or ambiguous')
    for required in ['sv04c_ee_boot_blocked','BR_RESTORED','BR_RESTORE_FAILED','BR_UNAVAILABLE','settings.load()']:
        if required not in snippet:raise ValueError('unsupported boot handler: missing '+required)
    return txt[:start]+snippet.replace(ANCHOR,ANCHOR+INSERT,1)+txt[end:]
def main():
    if len(sys.argv)!=2:raise SystemExit('usage: apply_eeprom_post_boot_302.py <sv04_claude_auto60_marlin.inc>')
    p=pathlib.Path(sys.argv[1]);original=p.read_text();updated=patch(original)
    if updated!=original:p.write_text(updated)
    print('SV04 NEXT 302:', 'already installed' if updated==original else 'patched',p)
if __name__=='__main__':main()
