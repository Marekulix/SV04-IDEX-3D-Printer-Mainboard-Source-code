from pathlib import Path
import sys

def patch(text):
    old='''  if (ff || z0) { r.st = PR_BLANK; return r; }'''
    new='''  // SV04 NEXT EEPROM BLANK GUARD: A blank header does not prove a blank
  // settings block. Inspect every byte before allowing the first Auto60 save.
  // A partial previous write, including a failed header write, is not blank.
  if (ff || z0) {
    const uint8_t fill = ff ? 0xFF : 0x00;
    uint8_t chunk[kChunk];
    for (uint32_t off = 0; off < b.len; ) {
      const uint16_t n = static_cast<uint16_t>((b.len - off) < kChunk ? (b.len - off) : kChunk);
      if (!rd(s, static_cast<uint16_t>(static_cast<uint32_t>(b.start) + off), chunk, n)) return r;
      for (uint16_t j = 0; j < n; ++j)
        if (chunk[j] != fill) { r.st = PR_FOREIGN; return r; }
      off += n;
    }
    r.st = PR_BLANK;
    return r;
  }'''
    if new in text:return text
    if text.count(old)!=1:raise ValueError('Expected exactly one blank header branch')
    return text.replace(old,new)
if __name__=='__main__':
    p=Path(sys.argv[1]);s=p.read_text();p.write_text(patch(s))
