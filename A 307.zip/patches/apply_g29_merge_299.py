#!/usr/bin/env python3
"""SV04 NEXT 299: preserve existing EEPROM patches while extending G29 abort.
Target: pinned OEM tree after 287 integration + G29 CANCEL V1, BEFORE EEPROM patches 292/293/294.
No wholesale replacements. Fail closed on unknown/multiple anchors.
"""
from pathlib import Path
import re, sys

ADAPTER=Path('Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc')
HOOKS=Path('Marlin/src/lcd/e3v2/creality/sv04_claude_hooks.h')
G29=Path('Marlin/src/gcode/bedlevel/abl/G29.cpp')
START='bool SV04Claude_Auto60_Busy() { return sv04c_coord.running(); }'
TOUCH='void SV04Claude_Auto60_TouchCancel() { if (sv04c_coord.running()) { sv04c_cancel_sid = sv04c_coord.session(); sv04c_cancel_req = true; } }'
EXTERN='extern void SV04Claude_Auto60_TouchCancel();'
POLL='''#ifndef SV04_CLAUDE_G29_POLL_DWIN
  #define SV04_CLAUDE_G29_POLL_DWIN 1
#endif
static bool sv04c_in_poll = false;
static void sv04c_poll_dwin() {
  if (sv04c_in_poll) return;
  sv04c_in_poll = true;
  while (rtscheck.RTS_RecData() > 0) rtscheck.RTS_HandleData();
  sv04c_in_poll = false;
}
static void sv04c_drain_dwin() { while (rtscheck.RTS_RecData() > 0) {} }
// SV04 NEXT 299 G29 cancellation: the current Auto60 session only.
bool SV04Claude_G29CancelRequested() {
  if (!sv04c_coord.running() || sv04c_coord.state() != sv04c::ST_PROBING) return false;
  #if SV04_CLAUDE_G29_POLL_DWIN
    sv04c_poll_dwin();
  #endif
  if (sv04c_cancel_req) {
    sv04c_cancel_req = false;
    if (sv04c_cancel_sid == sv04c_coord.session()) { sv04c_coord.cancel(); sv04c_hb_cancel_armed(); }
  }
  return sv04c_coord.cancel_requested();
}
'''
STUB='bool SV04Claude_G29CancelRequested() { return false; }'
OLD_END='''    // SV04 NEXT G29-CANCEL V1: do NOT move both IDEX carriages after Auto60 cancel.
    #if ENABLED(RTS_AVAILABLE) && ENABLED(AUTO_BED_LEVELING_BILINEAR)
      if (!sv04_g29_cancelled)
    #endif
        process_subcommands_now_P(PSTR(Z_PROBE_END_SCRIPT));'''
NEW_END='''    // SV04 NEXT G29-CANCEL V1: do NOT move both IDEX carriages after Auto60 cancel.
    // SV04 NEXT 299: recheck immediately before G28 XY end-script.
    #if ENABLED(RTS_AVAILABLE) && ENABLED(AUTO_BED_LEVELING_BILINEAR)
      if (!sv04_g29_cancelled && SV04Claude_G29CancelRequested()) sv04_g29_cancelled = true;
      if (!sv04_g29_cancelled)
    #endif
        process_subcommands_now_P(PSTR(Z_PROBE_END_SCRIPT));'''

def one(s,needle,replacement):
    if s.count(needle)!=1: raise ValueError(f'unsafe anchor: {needle[:100]!r}, hits {s.count(needle)}')
    return s.replace(needle,replacement,1)

def transform_adapter(s):
    if '// SV04 NEXT 299 G29 cancellation:' in s: return s
    # The 289 V1 installer can already have its own callback; replace only its function body.
    if s.count('bool SV04Claude_G29CancelRequested() {'):
        matches=list(re.finditer(r'\bbool\s+SV04Claude_G29CancelRequested\(\)\s*\{',s))
        for m in reversed(matches):
            depth=1; i=m.end()
            while i<len(s) and depth:
                if s[i]=='{':depth+=1
                elif s[i]=='}':depth-=1
                i+=1
            if depth:raise ValueError('unterminated existing G29 callback')
            s=s[:m.start()]+s[i:]
    # Keep other 289 logic untouched.
    s=one(s,START,START+'\n'+POLL)
    old='if (s == 1) { sv04c_cancel_req = false; const sv04c::Reason r = sv04c_coord.start();'
    s=one(s,old,'if (s == 1) { sv04c_cancel_req = false; sv04c_drain_dwin(); const sv04c::Reason r = sv04c_coord.start();')
    # Include inactive stubs, only inside the two known #else branches.
    for comment in ['#else  // Auto60 nicht kompiliert:', '#else  // !AUTO_BED_LEVELING_BILINEAR:']:
        pos=s.find(comment)
        if pos<0: raise ValueError('missing disabled branch '+comment)
        sub=s[pos:]; needle='void SV04Claude_Auto60_TouchCancel() {}'
        if needle not in sub:raise ValueError('missing stub in '+comment)
        idx=s.index(needle,pos)+len(needle)
        # Only one stub per branch; if the next line already defines callback, leave it.
        if STUB not in s[idx:idx+150]:s=s[:idx]+'\n'+STUB+s[idx:]
    return s

def transform_hooks(s):
    if 'SV04 NEXT 299 G29 hook' in s:return s
    if 'extern bool SV04Claude_G29CancelRequested();' in s:return s
    rows=s.splitlines(keepends=True)
    idx=[i for i,line in enumerate(rows) if line.startswith(EXTERN)]
    if len(idx)!=1:raise ValueError('missing or ambiguous touch hook')
    rows.insert(idx[0]+1,'extern bool SV04Claude_G29CancelRequested(); // SV04 NEXT 299 G29 hook\n')
    return ''.join(rows)

def transform_g29(s):
    if 'SV04 NEXT 299: recheck immediately' in s:return s
    return one(s,OLD_END,NEW_END)

def main(root):
    root=Path(root); paths=[ADAPTER,HOOKS,G29]; functions=[transform_adapter,transform_hooks,transform_g29]
    original=[(root/p).read_text(encoding='utf-8') for p in paths]
    changed=[f(s) for f,s in zip(functions,original)]
    # Atomic-ish: all transformations computed before any writes.
    for p,s in zip(paths,changed):(root/p).write_text(s,encoding='utf-8')
    for p,s,t in zip(paths,original,changed):print(p,'CHANGED' if s!=t else 'UNCHANGED')
if __name__=='__main__':
    if len(sys.argv)!=2:sys.exit('usage: apply_g29_merge_299.py OEM_ROOT')
    main(sys.argv[1])
