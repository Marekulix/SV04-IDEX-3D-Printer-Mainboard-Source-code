#!/usr/bin/env python3
"""Apply SV04 NEXT 305 to the actual integrated Marlin source; reject unexpected states."""
import sys
from pathlib import Path
FILE = Path('Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc')
OLD = '  if (!sv04c_ee_policy_allows(blank, valid, room, SV04_CLAUDE_EEPROM_REQUIRE_JOURNAL)) return false;\n  #if SV04_CLAUDE_EEPROM_REQUIRE_JOURNAL\n    if (!room) { SERIAL_ECHO_START(); SERIAL_ECHOLNPGM("Auto60 EEPROM: Start verweigert, kein Platz fuer das Undo-Journal und SV04_CLAUDE_EEPROM_REQUIRE_JOURNAL=1"); return false; }\n  #endif\n'
NEW = '  if (!sv04c_ee_policy_allows(blank, valid, room, SV04_CLAUDE_EEPROM_REQUIRE_JOURNAL)) { // SV04 NEXT 305: refusal reason before return\n    if (valid && !room && SV04_CLAUDE_EEPROM_REQUIRE_JOURNAL) {\n      SERIAL_ECHO_START(); SERIAL_ECHOLNPGM("Auto60 EEPROM: Start verweigert, kein Platz fuer das Undo-Journal und SV04_CLAUDE_EEPROM_REQUIRE_JOURNAL=1");\n    }\n    return false;\n  }\n'
def transform(s):
    if s.count(NEW)==1 and OLD not in s: return s, False
    if s.count(OLD)!=1 or NEW in s: raise ValueError('source conflict: expected a unique unmodified 292 policy guard')
    return s.replace(OLD,NEW),True
if __name__ == '__main__':
    if len(sys.argv)!=2: sys.exit('usage: apply_refusal_305.py <marlin_repo_root>')
    path=Path(sys.argv[1])/FILE
    original=path.read_text(encoding='utf-8')
    changed, applied=transform(original)
    if applied: path.write_text(changed,encoding='utf-8')
    print('SV04_NEXT_305_REFUSAL=' + ('APPLIED' if applied else 'ALREADY_APPLIED'))
