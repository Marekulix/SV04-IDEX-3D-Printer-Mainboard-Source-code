// ABGELEITET aus meiner frueheren Lieferung SV04_NEXT_194_196_CLAUDE_ENTWICKLUNG.zip (overlay/SV04NextG29Session194.hpp, sha256 8d532af84da9d2d78f340f6341fc730c8edab52aad1b879a5c2006220774c48a); Namensraum umbenannt, Funktionen unveraendert.
// Das ist KEINE neue Arbeit dieses Auftrags, sondern wiederverwendeter, bereits getesteter Code (RAM-Rollback der G29-Sitzung). Er wird hier unter neuen Tests (04_TESTS/sim) gegen die ECHTE G29.cpp erneut geprueft.
#pragma once
// SV04 NEXT 194 - G29-Sitzungslogik. REINES C++ ohne Marlin-Abhaengigkeit (kein Heap, kein EEPROM, keine Ausgabe, einthreadig).
// Eine Sitzung = ein G29-Lauf ab dem Homing-Waechter. Der Zustand, den ein Lauf veraendern kann, wird beim Start gesichert (MeshState) und nur dann
// zurueckgerollt, wenn der Lauf die MESSPHASE erreicht hat (sonst waere z. B. ein bewusstes "G29 J" nicht mehr moeglich).
#include <stdint.h>
#include <string.h>
#include <math.h>

namespace sv04g29 {
static const unsigned kGrid = 4;
static const float kMaxAbsMm = 30.0f;

// Alles, was ein G29-Lauf in diesem Build (Bilinear, BLTouch) im RAM veraendern kann: Mesh, Rasterlage, Rasterfaktor. (belegt: G29.cpp 441-453, 672, 752)
struct MeshState {
  float z[kGrid][kGrid];
  float spacing[2], start[2], factor[2];
};
inline bool same(const MeshState &a, const MeshState &b) { return memcmp(&a, &b, sizeof(MeshState)) == 0; }   // bitweise: NaN-sicher

enum Outcome { OUT_NONE = 0, OUT_ACCEPTED = 1, OUT_REJ_NO_SESSION = 2, OUT_REJ_STALE_ID = 3, OUT_REJ_FAILED = 4, OUT_REJ_DRYRUN = 5, OUT_REJ_FAUX = 6,
               OUT_REJ_INVALID_MESH = 7, OUT_ABORTED_EARLY = 8, OUT_ABORTED_PROBING = 9 };
enum Decision { DEC_KEEP = 0, DEC_ROLLBACK = 1 };
struct Event { uint32_t seq, id; uint8_t outcome, probing; };

// Ein vollstaendiges, plausibles Ergebnis: alle 16 Werte endlich und in +-30 mm, Raster endlich und > 0, Start und Faktor endlich.
inline bool plausible(const MeshState &s) {
  for (unsigned x = 0; x < kGrid; x++) for (unsigned y = 0; y < kGrid; y++) if (!isfinite(s.z[x][y]) || s.z[x][y] < -kMaxAbsMm || s.z[x][y] > kMaxAbsMm) return false;
  for (unsigned i = 0; i < 2; i++) if (!isfinite(s.spacing[i]) || s.spacing[i] <= 0 || !isfinite(s.start[i]) || !isfinite(s.factor[i]) || s.factor[i] <= 0) return false;
  return true;
}

class Session {
  static const unsigned kRing = 8;
  MeshState backup_, accepted_;
  Event ring_[kRing];
  uint32_t next_id_, active_id_, accepted_id_, seq_, begun_, accepted_n_, rejected_n_, aborted_n_, rollbacks_, resends_;
  bool probing_, has_accepted_;
  uint8_t last_;
  void log(uint32_t id, Outcome o, bool probing) { Event &e = ring_[seq_ % kRing]; e.seq = ++seq_; e.id = id; e.outcome = (uint8_t)o; e.probing = probing ? 1 : 0; last_ = (uint8_t)o; }
  void drop_accepted() { has_accepted_ = false; accepted_id_ = 0; }
  uint32_t alloc() { uint32_t v = next_id_++; if (next_id_ == 0) next_id_ = 1; return v; }
 public:
  Session() : backup_(), accepted_(), ring_(), next_id_(1), active_id_(0), accepted_id_(0), seq_(0), begun_(0), accepted_n_(0), rejected_n_(0), aborted_n_(0), rollbacks_(0), resends_(0), probing_(false), has_accepted_(false), last_(OUT_NONE) {}

  uint32_t begin(const MeshState &before) {
    if (active_id_ != 0) { ++aborted_n_; log(active_id_, probing_ ? OUT_ABORTED_PROBING : OUT_ABORTED_EARLY, probing_); }   // Vorgaenger ohne Abschluss
    drop_accepted();
    backup_ = before;
    probing_ = false;
    active_id_ = alloc();
    ++begun_;
    return active_id_;
  }
  void probing(uint32_t id) { if (id != 0 && id == active_id_) probing_ = true; }

  Decision complete(uint32_t id, bool successful, bool dryrun, bool faux, const MeshState &now, Outcome &out) {
    if (active_id_ == 0) { drop_accepted(); ++rejected_n_; log(id, OUT_REJ_NO_SESSION, false); out = OUT_REJ_NO_SESSION; return DEC_KEEP; }
    if (id != active_id_) { drop_accepted(); ++rejected_n_; log(id, OUT_REJ_STALE_ID, false); out = OUT_REJ_STALE_ID; return DEC_KEEP; }   // aktive Sitzung bleibt offen
    const uint32_t sid = active_id_;
    const bool reached = probing_;
    active_id_ = 0; probing_ = false; drop_accepted();
    Outcome o = OUT_ACCEPTED;
    if (!successful) o = OUT_REJ_FAILED;
    else if (dryrun) o = OUT_REJ_DRYRUN;
    else if (faux) o = OUT_REJ_FAUX;
    else if (!plausible(now)) o = OUT_REJ_INVALID_MESH;
    log(sid, o, reached);
    out = o;
    if (o == OUT_ACCEPTED) { accepted_ = now; has_accepted_ = true; accepted_id_ = sid; ++accepted_n_; return DEC_KEEP; }
    ++rejected_n_;
    return reached ? DEC_ROLLBACK : DEC_KEEP;
  }
  // Aufruf aus dem Destruktor des Waechters, wenn KEIN Abschluss gemeldet wurde (jeder vorzeitige G29-Ausstieg).
  Decision abort(uint32_t id, Outcome &out) {
    if (id == 0 || id != active_id_) { out = OUT_NONE; return DEC_KEEP; }
    const bool reached = probing_;
    active_id_ = 0; probing_ = false; drop_accepted();
    ++aborted_n_;
    out = reached ? OUT_ABORTED_PROBING : OUT_ABORTED_EARLY;
    log(id, out, reached);
    return reached ? DEC_ROLLBACK : DEC_KEEP;
  }
  const MeshState &backup() const { return backup_; }
  void note_rollback() { ++rollbacks_; }
  void note_resend() { ++resends_; }
  bool snapshot(MeshState &out) const { if (!has_accepted_ || active_id_ != 0 || !plausible(accepted_)) return false; out = accepted_; return true; }
  bool session_open() const { return active_id_ != 0; }
  bool probing_reached() const { return active_id_ != 0 && probing_; }
  uint32_t active_id() const { return active_id_; }
  uint32_t accepted_id() const { return accepted_id_; }
  uint32_t begun() const { return begun_; }
  uint32_t accepted() const { return accepted_n_; }
  uint32_t rejected() const { return rejected_n_; }
  uint32_t aborted() const { return aborted_n_; }
  uint32_t rollbacks() const { return rollbacks_; }
  uint32_t resends() const { return resends_; }
  uint8_t last_outcome() const { return last_; }
  bool event(unsigned back, Event &e) const { if (back >= kRing || back >= seq_) return false; e = ring_[(seq_ - 1 - back) % kRing]; return true; }
};
}  // namespace sv04g29
