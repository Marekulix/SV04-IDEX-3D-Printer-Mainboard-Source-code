#pragma once
/**
 * SV04 NEXT C2 (Claude): Marlin-Anbindung der Richtlinie sv04_claude_toolchange_policy.h. Wird NUR von T.cpp eingebunden.
 * SV04_CLAUDE_TOOLCHANGE_GUARD (Standard 1): 0 = das OEM-Verhalten unveraendert (nur fuer Vergleich/Notfall).
 */
#include "../../feature/sv04_claude_auto60/sv04_claude_toolchange_policy.h"
#include "../../lcd/e3v2/creality/sv04_claude_hooks.h"

#ifndef SV04_CLAUDE_TOOLCHANGE_GUARD
  #define SV04_CLAUDE_TOOLCHANGE_GUARD 1
#endif

inline bool sv04c_t_allowed(const int8_t tool) {
  #if SV04_CLAUDE_TOOLCHANGE_GUARD && ENABLED(DUAL_X_CARRIAGE)
    const sv04c::TcIn in = { (int)tool, (int)active_extruder, (int)EXTRUDERS, axis_was_homed(X_AXIS), axis_is_trusted(X_AXIS), SV04Claude_Auto60_Busy() };
    const sv04c::TcVerdict v = sv04c::tc_decide(in);
    if (sv04c::tc_refused(v)) {
      SERIAL_ECHO_START();
      SERIAL_ECHOPGM("SV04: T", (int)tool, " abgelehnt: ");
      SERIAL_ECHOLN(sv04c::tc_why(v));
      return false;
    }
  #else
    UNUSED(tool);
  #endif
  return true;
}
