#pragma once
/**
 * SV04 NEXT C2 (Claude): reine Richtlinie "darf ein T0/T1 ueber GcodeSuite::T() einen ECHTEN Werkzeugwechsel ausloesen?" - ohne Marlin-Abhaengigkeit, deshalb exhaustiv testbar.
 * HINTERGRUND (echter OEM-Code, Commit 1867fcba, tool_change.cpp:868): dualx_tool_change() ruft set_axis_is_at_home(X_AXIS) auch dann auf, wenn no_move gesetzt ist (z. B. weil nicht alle Achsen referenziert sind).
 * set_axis_is_at_home() setzt set_axis_trusted(X) UND set_axis_homed(X) und ueberschreibt current_position.x mit der Heimposition des NEUEN Werkzeugs (motion.cpp). Ein T1 bei nicht vertrauenswuerdigem X
 * macht X also ohne jede Bewegung wieder "referenziert" - auch nachdem ein fehlgeschlagenes G28 X entzogen hat (fail-closed umgangen). Gleiches Werkzeug (tool == active) schaltet nichts und ist harmlos.
 * Interne Aufrufe (G28, G29, M600, ...) rufen tool_change() direkt auf und sind von dieser Richtlinie NICHT betroffen.
 */
namespace sv04c {

struct TcIn {
  int  tool;          // angefordertes Werkzeug
  int  active;        // aktuell aktives Werkzeug (active_extruder)
  int  extruders;     // EXTRUDERS
  bool x_homed;       // axis_was_homed(X_AXIS)
  bool x_trusted;     // axis_is_trusted(X_AXIS)
  bool auto60_busy;   // Auto60-Lauf aktiv
};

enum TcVerdict { TC_ALLOW = 0, TC_ALLOW_SAME_TOOL, TC_PASS_INVALID_TOOL, TC_REFUSE_AUTO60_BUSY, TC_REFUSE_X_NOT_TRUSTED };

inline TcVerdict tc_decide(const TcIn &in) {
  if (in.tool < 0 || in.tool >= in.extruders) return TC_PASS_INVALID_TOOL;   // die OEM-Fehlermeldung (invalid_extruder_error) bleibt unveraendert
  if (in.tool == in.active)                   return TC_ALLOW_SAME_TOOL;     // kein Wechsel
  if (in.auto60_busy)                         return TC_REFUSE_AUTO60_BUSY;  // ein Auto60-Lauf darf nicht durch ein fremdes T unterbrochen werden
  if (!(in.x_homed && in.x_trusted))          return TC_REFUSE_X_NOT_TRUSTED;
  return TC_ALLOW;
}

inline bool tc_refused(const TcVerdict v) { return v == TC_REFUSE_AUTO60_BUSY || v == TC_REFUSE_X_NOT_TRUSTED; }

inline const char *tc_why(const TcVerdict v) {
  switch (v) {
    case TC_REFUSE_AUTO60_BUSY:     return "Auto60 laeuft";
    case TC_REFUSE_X_NOT_TRUSTED:   return "X nicht referenziert oder nicht vertrauenswuerdig, erst G28";
    default:                        return "";
  }
}

} // namespace sv04c
