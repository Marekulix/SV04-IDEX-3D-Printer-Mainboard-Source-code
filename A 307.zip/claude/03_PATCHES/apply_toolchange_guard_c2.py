#!/usr/bin/env python3
"""SV04 NEXT C2 (Claude): Werkzeugwechsel-Schutz in T.cpp. Fail-closed:
 * prueft ZUERST den Git-Blob-SHA-1 der ORIGINAL-T.cpp gegen den gepinnten OEM-Wert (Commit 1867fcba..., cb... siehe PIN) bzw. - bereits gepatcht - den SHA-1 des Ergebnisses;
 * jeder Anker muss GENAU EINMAL vorkommen, sonst Abbruch ohne Aenderung; idempotent;
 * legt die beiden neuen Claude-Dateien (Richtlinie, Glue) neben die OEM-Dateien.
Aufruf: apply_toolchange_guard_c2.py <OEM_ROOT>   (OEM_ROOT enthaelt Marlin/src/...)"""
import hashlib
import sys
from pathlib import Path

PIN_T_CPP = '5bb139f951f19836407eac9c2672ac78a24531e2'          # git blob sha1 von Marlin/src/gcode/control/T.cpp @ 1867fcba75354a5c65e0631d6972dd19f1bd6cbe
MARK = 'SV04 NEXT C2'
A_INC = '#include "../../core/debug_out.h"\n'
B_INC = A_INC + '#include "sv04_claude_toolchange_guard.h"   // SV04 NEXT C2\n'
A_CALL = '  tool_change(tool_index\n'
B_CALL = ('  // SV04 NEXT C2: ein ECHTER Werkzeugwechsel nur bei vertrauenswuerdigem X und ausserhalb eines Auto60-Laufs (OEM dualx_tool_change() markiert X sonst auch ohne Bewegung als referenziert)\n'
          '  if (!sv04c_t_allowed(tool_index)) return;\n\n' + A_CALL)


def blob_sha1(b):
    return hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()


def transform(raw):
    """raw: Bytes der T.cpp. Rueckgabe (neue Bytes, geaendert?)."""
    s = raw.decode('utf-8')
    if MARK in s:
        if s.count('sv04c_t_allowed(tool_index)') != 1 or s.count('sv04_claude_toolchange_guard.h') != 1:
            raise ValueError('T.cpp ist halb gepatcht oder doppelt gepatcht')
        return raw, False
    if blob_sha1(raw) != PIN_T_CPP:
        raise ValueError('T.cpp weicht vom gepinnten OEM-Stand ab (git-sha1 %s statt %s): kein Patch' % (blob_sha1(raw), PIN_T_CPP))
    for a in (A_INC, A_CALL):
        if s.count(a) != 1:
            raise ValueError('Anker nicht genau einmal vorhanden: %r (%d)' % (a[:50], s.count(a)))
    return s.replace(A_INC, B_INC).replace(A_CALL, B_CALL).encode('utf-8'), True


def main(argv):
    if len(argv) != 2:
        print(__doc__); return 2
    root = Path(argv[1])
    t = root / 'Marlin/src/gcode/control/T.cpp'
    new, changed = transform(t.read_bytes())
    here = Path(__file__).resolve().parents[1] / '02_SOURCE' / 'Marlin' / 'src'
    for rel in ('feature/sv04_claude_auto60/sv04_claude_toolchange_policy.h', 'gcode/control/sv04_claude_toolchange_guard.h'):
        dst = root / 'Marlin' / 'src' / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes((here / rel).read_bytes())
    if changed:
        t.write_bytes(new)
    print('TOOLCHANGE_GUARD_C2=' + ('PATCHED' if changed else 'ALREADY_PATCHED'), t)
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
