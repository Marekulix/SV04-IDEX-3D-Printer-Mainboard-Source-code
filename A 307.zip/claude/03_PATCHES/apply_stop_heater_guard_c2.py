#!/usr/bin/env python3
"""SV04 NEXT C2 (Claude): Auto60 schaltet das Bett nach Marlins stop() NICHT mehr wieder ein.
BEFUND (echter OEM-Code, Commit 1867fcba): bltouch.cpp deploy_proc()/stow_proc() rufen bei Fehlschlag stop() (kein kill). stop() (MarlinCore.cpp:932) schaltet ALLE Heizungen ab und setzt marlin_state = MF_STOPPED.
Auto60 stellt in jedem Endzustand die frueher gesetzte Bett-Solltemperatur wieder her (restore_heater -> sv04c_bed_set -> setTargetBed): nach einem BLTouch-Alarm heizte das Bett also wieder auf (Simulation: bed_target 60 -> stop() -> bed_target 70).
Aenderung: nur sv04c_bed_set(): ein Sollwert > 0 wird im Zustand IsStopped() nicht gesetzt; Abschalten (0) bleibt immer moeglich. Ein einziger Anker, genau einmal, idempotent, bricht sonst ab.
Aufruf: apply_stop_heater_guard_c2.py <OEM_ROOT>   (Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc, nach 292-305 anzuwenden)"""
import sys
from pathlib import Path

TARGET = Path('Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc')
MARK = 'SV04 NEXT C2: stop()'
OLD = "static void sv04c_bed_set(void *, float c) { thermalManager.setTargetBed((int16_t)(c + (c >= 0 ? 0.5f : -0.5f))); }\n"
NEW = ("static void sv04c_bed_set(void *, float c) {\n"
       "  if (c > 0 && IsStopped()) return;      // SV04 NEXT C2: stop() (z. B. BLTouch-Alarm, MarlinCore.cpp:932) hat ALLE Heizungen abgeschaltet: nicht wieder einschalten (Abschalten bleibt moeglich)\n"
       "  thermalManager.setTargetBed((int16_t)(c + (c >= 0 ? 0.5f : -0.5f)));\n"
       "}\n")


def transform(s):
    if MARK in s:
        if s.count(NEW) != 1:
            raise ValueError('halb gepatcht')
        return s, False
    if s.count(OLD) != 1:
        raise ValueError('CONFLICT: Anker %d mal vorhanden (erwartet 1)' % s.count(OLD))
    return s.replace(OLD, NEW), True


def main(argv):
    if len(argv) != 2:
        print(__doc__); return 2
    p = Path(argv[1]) / TARGET
    t, ch = transform(p.read_text(encoding='utf-8'))
    if ch:
        p.write_text(t, encoding='utf-8')
    print('STOP_HEATER_GUARD_C2=' + ('PATCHED' if ch else 'ALREADY_PATCHED'), p)
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
