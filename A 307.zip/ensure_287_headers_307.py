#!/usr/bin/env python3
"""307: supply *missing* 287 new Auto60 headers from byte-pinned 287 sources.
Never replace an existing firmware source; fail on alien hashes. This fixes the
missing EEPROM header in actual GitHub run 306 before applying the 306 patches.
"""
from pathlib import Path
import hashlib,sys,os
HERE=Path(__file__).resolve().parent
REL=Path('Marlin/src/feature/sv04_claude_auto60')
PINNED={
    'sv04_claude_auto60_core.h': '8792087b437ec8d0d1e70d32ce87106db08f387f5bd04fb2dbb49300ad9b65fd',
    'sv04_claude_eeprom_core.h': 'ea7705dd688ae0e7073d46afe3fd8532e8f30ba1eaaa1abe95005f06965b9b57',
    'sv04_claude_g29_session.h': 'd616c3e94826ffaac50e5e43fa842a53f17a091ff24537433edc8ce1c8afa250',
}
COMPOSED_EEPROM='379848c3a0e3cd2f2a67e4f560b0a02592b6d95bd414818d8d4fc8ad0f04a2a3'
COMPOSED_AUTO60='faf2d034a067ccecea5e0d413028e9598935fe577486748a6a5493bc16c6a097'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ensure(root):
    root=Path(root).resolve()
    changes=[]
    for name,pin in PINNED.items():
        original=HERE/'fixtures/baseline_287'/REL/name
        if not original.is_file() or sha(original)!=pin:
            raise RuntimeError('PINNED_287_SOURCE_INVALID: '+name)
        dest=root/REL/name
        if dest.is_file():
            got=sha(dest)
            permitted=[pin]
            if name=='sv04_claude_eeprom_core.h':permitted.append(COMPOSED_EEPROM)
            if name=='sv04_claude_auto60_core.h':permitted.append(COMPOSED_AUTO60)
            if got not in permitted:raise RuntimeError('UNKNOWN_EXISTING_HEADER_NOT_OVERWRITTEN '+name+' sha256='+got)
            changes.append(('ALREADY',name,got))
            continue
        if dest.exists():raise RuntimeError('TARGET_NOT_REGULAR_FILE '+str(dest))
        dest.parent.mkdir(parents=True,exist_ok=True)
        # Exclusive creation, not overwrite. No partly-created file on exception.
        try:
            with dest.open('xb') as out:out.write(original.read_bytes())
        except BaseException:
            if dest.is_file():dest.unlink()
            raise
        if sha(dest)!=pin:raise RuntimeError('INSTALLED_HEADER_SHA_MISMATCH: '+name)
        changes.append(('SUPPLIED',name,pin))
    for action,name,h in changes:print('HEADER_307',action,name,h,flush=True)
    print('SV04_NEXT_307_HEADERS=PASS')
if __name__=='__main__':
    if len(sys.argv)!=2:sys.exit('usage: ensure_287_headers_307.py OEM_ROOT')
    ensure(sys.argv[1])
