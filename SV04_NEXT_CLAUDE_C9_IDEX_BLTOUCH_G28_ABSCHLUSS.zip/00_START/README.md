# SV04 NEXT – Claude C9 – Start hier
**Kein Build ausgeführt (kein GitHub-Zugriff), nichts geflasht, keine Hardwarefreigabe. Eine OEM-Datei geändert: `M999.cpp` (+15).**
* `00_START/ERGEBNISBERICHT.md`, `VERGLEICH_C8_C9.md`
* `01_QUELLEN/geaendert/` – die geänderte Quelldatei; `02_PATCHES/` – Patchskripte, Generator, Auswertung, Diffs
* `03_TESTS/` – alle Tests; **`run_tests.py` im Wurzelverzeichnis ist der Einstieg**
* `04_ROHLOGS/` – `50` M999-Echtcode, `51` Auswertung an echten Daten, `52` Workflow-Tests, `53` Include-Kette, `54` Eingaben, `55` Ringpuffer, `56` Reason-Tabelle, `57` Artefaktprüfung
* `05_INTEGRATION/` – Integrationsempfehlung, Schnittstellenbeschreibung, Ausführungsschritte; `06_RISIKEN/`
Separat: `claude_c9_stm32_no_flash.yml`. Prüfen: `python3 run_tests.py` (python3, g++, patch, git, PyYAML; ca. 4 Minuten).
