# SV04 NEXT – Claude C9: IDEX, BLTouch, G28 – Wiederaufnahme nach Fehlern

Stand 13.11.2026 · Basis: Version 318 (unverändert), GitHub-Lauf 43484048208 (4 von 4 PASS) · **C9 ist ein Claude-Arbeitstitel; ChatGPT integriert in einen eigenen Stand.**

> **Kurzfassung:** C9 ändert **eine** OEM-Datei (`M999.cpp`, +15 Zeilen) und schließt damit die eine Lücke gegenüber Ihrem Punkt 3, die ich am echten Code belegen konnte: **Nach einem BLTouch-Stopp mitten in der G29 und `M999` galten X/Y/Z weiter als referenziert, Auto60 startete sofort wieder und meldete Erfolg.** Das ist an der echten `M999.cpp` ausgeführt belegt (Host-Test, mit Negativkontrolle). **Kein STM32-Build ausgeführt** (kein GitHub-Zugriff von hier); der C9-Workflow ist vorbereitet, **die Kompilierbarkeit der Änderung ist erst nach einem Lauf belegt.** Nichts geflasht, keine Hardwarefreigabe. Alle mechanisch unbelegbaren Bedingungen bleiben gesperrt.

## 1. Eingangsprüfung
| Benötigt | Status |
|---|---|
| Version 318, Quellen, echte Build-Logs | da; Quellhashes des Laufs = meine Soll-Hashes (Log `57`) |
| 315-Paket (Adapter 314/315, Tests) | da; Manifest 12/12; ChatGPTs Tests **unverändert** mit Negativkontrollen: 314 fällt durch (65 Prüfungen, 30 Fehler / DWIN 1 Fehler), 315 besteht (Log `54`) |
| Workflow-08-**Datei** | **fehlt** (nur der Name genannt); Eingabenamen aus den Artefakten: `SV04_NEXT_318_GITHUB_UPLOAD_06.zip`, `SV04_NEXT_CLAUDE_C8_BUILD_EVIDENZ_NO_FLASH.zip` |
| GitHub-Zugriff | **nein** (Log `38` aus C8, erneut geprüft) |
| Maße T0/T1, BLTouch-Verhalten, reale Z-Strecke | **fehlen**, nur am Gerät messbar |

## 2. Ihre Entscheidungen
* **Keine pauschale `M605`-Sperre:** umgesetzt (nichts gebaut). Belege: `PowerContinuePrintKey` in `LCD_RTS.cpp` und der OEM-Menüablauf senden `M605 S2/S3` **vor** dem Referenzieren; eine Sperre würde die Wiederaufnahme nach Stromausfall brechen. Die bestehenden IDEX-Betriebsarten bleiben unberührt.
* **Auto60 prüft den IDEX-Modus bereits** (`PRE_IDEX_MODE`, Reason 8); keine zweite Implementierung.

## 3. Wiederaufnahme nach Fehlern (Ihr Punkt 3) – Umsetzung und Beleg
| Anforderung | Umsetzung | Test-IDs (Rohlog, bestanden) |
|---|---|---|
| Kritischer Fehler wird nicht automatisch zurückgesetzt: Stopp-Neustart (M999) erzeugt keine Freigabe | siehe Zeile | C901, C902, C904, C907, C910 |
| Referenzierung muss erneut bestätigt werden (X/Y/Z nach Stopp + M999 nicht referenziert) | siehe Zeile | C901, C904, C910, C911 |
| Werkzeugwechsel T1 nach Stopp + Neustart abgelehnt (echte M999.cpp → echte T.cpp) | siehe Zeile | C911, T04 |
| Auto60 startet erst nach erneuter vollständiger Prüfung (Z bekannt, Marlin läuft, T0, IDEX-Modus) | siehe Zeile | C910, C511, C512, C514, C602 |
| Keine automatische Fortsetzung einer abgebrochenen G29-Messung, kein Endskript nach Stopp | siehe Zeile | ST03, ST05, C521 |
| Manuelle G29 im Stopp-Zustand verweigert, bestehende OEM-Funktion ohne Stopp erhalten | siehe Zeile | C521, C522 |
| Keine EEPROM-Speicherung nach fehlgeschlagener Messung (M500 nur nach validiertem Mesh) | siehe Zeile | E20, E03, E04 |

**Die Lücke und die Änderung.** `stop()` (nach BLTouch-Fehlern) lässt die Referenzierung unverändert, `M999` setzt nur `marlin_state = MF_RUNNING`. Neu: `M999` aus dem **Stopp-Zustand** setzt X/Y/Z auf „nicht referenziert und nicht vertrauenswürdig“ (`set_all_unhomed()`) und meldet `SV04 C9: restart after STOPPED state, axes are now UNHOMED: …`. `M999` ohne Stopp-Zustand bleibt unverändert; Schalter `SV04_CLAUDE_M999_REHOME_REQUIRED` (Standard 1; 0 = OEM). Folge ohne weiteren Code: Auto60 lehnt mit `PRE_Z_UNKNOWN` (65) ab, `T1` wird vom C2-Wächter abgelehnt, und erst eine neue Referenzierung (von Hand `G28`) hebt das auf; danach läuft die gesamte Prüfung von Auto60 neu.

**Belege an echtem Code (Host-Tests):**
* Die **echte** `M999.cpp` (OEM und gepatcht) wird mit minimalen Attrappen kompiliert: alle 256 Kombinationen aus Zustand, Referenzierung und `S`-Parameter (`C904`); der OEM-Neustart (Alarm zurücksetzen, Resend) bleibt identisch (`C905`).
* **Negativkontrolle `C907`:** Die unveränderte OEM-`M999.cpp` lässt nach Stopp und Neustart alle Achsen referenziert.
* **Verkettung zweier echter OEM-Dateien `C911`:** Die Achszustände der `M999.cpp` entscheiden in der echten `T.cpp` über `T1`. Mit der OEM-Datei wird `T1` an `tool_change()` gereicht, mit C9 abgelehnt.
* **Sieben Mutanten** des Patches werden über den vollen Zustandsraum erkannt (`C909`).
* **Auto60-Simulation `C910` (Modell der gepatchten `M999`-Semantik):** OEM-Modell: Neustart nach `stop()` mitten in der G29 → Auto60 läuft erneut durch und meldet `SUCCESS`. C9-Modell: `PRE_Z_UNKNOWN`. Nach erneuter Referenzierung startet Auto60 wieder.

**Bewusst nicht geändert: die Befehlswarteschlange.** `ring_buffer.clear()` innerhalb von `M999` würde den `uint8_t`-Längenzähler nach `advance_pos(index_r, -1)` unterlaufen lassen (Log `55`). „Keine automatische Wiederaufnahme unterbrochener Bewegungen“ gilt daher so: Nach dem Stopp lehnt Marlin `G0`–`G5` ab (`queue.cpp:509`), die G29 wird im Stopp-Zustand verweigert (C5) und beendet sich bei Stopp mitten in der Messung ohne Endskript (C4); **bereits eingereihte Befehle nach `M999 S1` (Fortsetzen ohne Puffer-Flush) bleiben ein Restrisiko**, siehe Abschnitt 7.

## 4. Die drei Prioritäten – ehrlicher Stand
| Priorität | Stand |
|---|---|
| **1 IDEX + BLTouch** | T1 nur bei referenziertem, vertrauenswürdigem X (C2); Werkzeugwechsel erzeugt kein X-Vertrauen (C3); **neu:** Stopp-Neustart hebt X-Vertrauen auf. **Keine neue Kollisionsprüfung:** reale Maße fehlen. M605-Betriebsarten unverändert. |
| **2 G28** | Referenzfahrt bei bekanntem Z auf z+Toleranz begrenzt (C3), bei unbekanntem Z auf 410 mm (C5, Konfigurationsannahme); Sensorfehler → `HOME_FAILED`, Z/X unreferenziert (P1); **neu:** Wiederanlauf nach Stopp verlangt erneutes G28. **Offen:** ausbleibende Auslösung bei unbekanntem Z wird erst am Streckenende erkannt; echte `homeaxis()` nicht ausgeführt. |
| **3 Auto60-Schnittstelle** | G28-/Z-/Stopp-/Werkzeug-/IDEX-Prüfung besteht (Kern); G29-Abbruchschutz erhalten (Tests grün). **Neu:** der Neustart allein reicht nicht. |

## 5. Geänderte Dateien
* **OEM:** `Marlin/src/gcode/control/M999.cpp` (+15 Zeilen); Patch `apply_m999_reset_c9.py` (OEM-Hash gepinnt, idempotent, fremde Datei → Abbruch); Diff `02_PATCHES/diffs/M999_OEM_nach_C9.diff`; vollständige Datei `01_QUELLEN/geaendert/…/M999.cpp`.
* **Werkzeuge/Tests:** `evaluate_builds_c9.py` (Korrektur des C7-Fehlers: der Workflow schreibt `BUILD_TREE=oem/oem318`; jetzt gegen die **echten** Daten des Laufs getestet, `E901`–`E906`), `make_workflow_c9.py`, Tests `C901`–`C911`, `W901`–`W906`.
* **Compiler-Risiko (nicht ausgeführt):** `M999.cpp` braucht `motion.h` (`set_all_unhomed`, in beiden Konfigurationszweigen vorhanden), `IsStopped` (aus `MarlinCore.h`, bereits eingebunden) und `SERIAL_ECHO_MSG` (über `gcode.h` → `MarlinConfig.h` → `core/serial.h`, wie in `G28.cpp`, `M280.cpp`, `M282.cpp`; Log `53`).

## 6. Build
**Nicht ausgeführt.** Workflow `claude_c9_stm32_no_flash.yml` (aus dem im Lauf 43484048208 erfolgreichen Route-B-Workflow abgeleitet, Eingabenamen wie dort): Job `modified_318_c6` baut die **unveränderte 318** als Baseline, Job `c9_changes` baut die **neue Kopie `oem_c9`** (nur `M999.cpp` weicht ab, per `diff -rq` erzwungen), der Auswertungsjob ist rot, solange nicht alle vier Kombinationen belegt PASS sind. Der Kontrollbuild der 309 entfällt (bereits belegt). Schritte: `05_INTEGRATION/AUSFUEHRUNGSSCHRITTE_GITHUB.md`.

## 7. Fehler- und Restrisikoliste
* **Kompilierbarkeit der C9-Änderung unbelegt** bis zum GitHub-Lauf. Schlägt der Lauf fehl, repariere ich den **ersten** Compilerfehler auf einer neuen Kopie.
* **Verhaltensänderung:** `M999` aus dem Stopp-Zustand verlangt jetzt `G28`. Für Hosts, die mit `M999 S1` einen Druck nach einem Stopp **fortsetzen**, gilt dann: Achsen unreferenziert, Softwareendschalter greifen nicht; Schalter `SV04_CLAUDE_M999_REHOME_REQUIRED=0` stellt das OEM-Verhalten wieder her. Display-Nutzer haben keinen `M999`-Weg (Aus-/Einschalten referenziert ohnehin neu).
* **Eingereihte Befehle** nach `M999 S1` werden nicht verworfen (siehe oben).
* **Nicht freigegeben, weil nicht belegbar:** Z-Homing aus unbekannter Position (410 mm sind keine Kollisionsfreigabe), T0/T1-Kollisionsabstände (`TOOLCHANGE_ZRAISE 0`), BLTouch-Verhalten am Gerät, Kabelbruch/taub bleibender Sensor, EEPROM-Journal und Stromausfall am Gerät, DWIN-HMI.
* **Mutationstests der Altklassen nicht wiederholt:** Claude-Quellen und Standardverhalten des Simulationstreibers sind unverändert (nur die Option `m999_c9` kam hinzu); Berichte aus C8.
* **Workflow-08-Datei nicht gesehen:** Abweichungen meines Workflows zu Ihrer Datei sind möglich (Eingabenamen sind angeglichen).

## 8. Fortschritt vorher/nachher
| Nr | Funktion | Vorher | Nachher |
|---|---|---|---|
| 1 | IDEX + BLTouch | 88 % | 88 % |
| 2 | G28 Homing | 81 % | 81 % |
| 3 | G29 + Abbruch | 75 % | 75 % |
| 4 | M420 S1 | 97 % | 97 % |
| 5 | M500 EEPROM | 70 % | 70 % |
| 6 | EEPROM-Rücklesung | 60 % | 60 % |
| | Gesamt | 78,5 % | 78,5 % |

Ich ändere die Felder nicht eigenmächtig: Die C9-Änderung ist host-seitig belegt, aber **noch nicht kompiliert und nicht am Gerät geprüft**. Ob sie nach einem erfolgreichen Lauf einen Punkt rechtfertigt, entscheiden Sie bzw. ChatGPT.

## 9. Tests (Rohlogs in `04_ROHLOGS/`)
Kern 159/159 · EEPROM-Kern 33/33 · Host 67/67 · Simulation 251/251 · Mutationen (Altklassen, 0 Überlebende): G29-Abbruch 13 · Betrieb 9 · Adapter 13 · Backend 10 · Koordinator 19 · EEPROM-Adapter 11 · Bedlevel 6 · Kern 24 · EEPROM-Kern 17. **Neu in C9 zählen nur** `C901`–`C911`, `E901`–`E906`, `W901`–`W906`; alles andere sind alte, weiterhin bestandene Tests. Host-Simulation und echte Firmware-/Hardwaretests bleiben strikt getrennt: Es gibt keine Firmware- oder Hardwaretests.
