# Vergleich C8 → C9 (Hashvergleich gegen die ausgelieferte C8-ZIP)

**Firmware-/OEM-Quelldateien geändert: genau eine** (`Marlin/src/gcode/control/M999.cpp`, +15 Zeilen, SHA-256 OEM `f778002d1a491dc58ee4d8c550120f24db477ec185d3f7124acc457968659cb9` → C9 `cbaca8b8bca033002a39ceb0eff7a7a64799a2c99e7d1f83cb5ea6a203418654`). In `claude/02_SOURCE` (Adapter, Kern, hooks.h, Richtlinien): **0 Änderungen**; Version 318 bleibt unverändert, EEPROM-/DWIN-/M420-/G29-Dateien werden nicht angefasst.

**Geändert:**
* `claude/04_TESTS/sim/driver_integ.cpp`
* `claude/tools/run_all_tests_a60.py`

**Neu:**
* `claude/01_BASELINE/OEM_309/orig/gcode/control/M999.cpp`
* `claude/03_PATCHES/apply_m999_reset_c9.py`
* `claude/04_TESTS/real_data_run_43484048208/oem/integrated_backend/build.log`
* `claude/04_TESTS/real_data_run_43484048208/oem/integrated_backend/errors.txt`
* `claude/04_TESTS/real_data_run_43484048208/oem/integrated_backend/ram_flash.txt`
* `claude/04_TESTS/real_data_run_43484048208/oem/integrated_backend/result.txt`
* `claude/04_TESTS/real_data_run_43484048208/oem/integrated_backend/warnings.txt`
* `claude/04_TESTS/real_data_run_43484048208/oem/integrated_failclosed/build.log`
* `claude/04_TESTS/real_data_run_43484048208/oem/integrated_failclosed/errors.txt`
* `claude/04_TESTS/real_data_run_43484048208/oem/integrated_failclosed/ram_flash.txt`
* `claude/04_TESTS/real_data_run_43484048208/oem/integrated_failclosed/result.txt`
* `claude/04_TESTS/real_data_run_43484048208/oem/integrated_failclosed/warnings.txt`
* `claude/04_TESTS/real_data_run_43484048208/oem318/integrated_backend/build.log`
* `claude/04_TESTS/real_data_run_43484048208/oem318/integrated_backend/errors.txt`
* `claude/04_TESTS/real_data_run_43484048208/oem318/integrated_backend/ram_flash.txt`
* `claude/04_TESTS/real_data_run_43484048208/oem318/integrated_backend/result.txt`
* `claude/04_TESTS/real_data_run_43484048208/oem318/integrated_backend/warnings.txt`
* `claude/04_TESTS/real_data_run_43484048208/oem318/integrated_failclosed/build.log`
* `claude/04_TESTS/real_data_run_43484048208/oem318/integrated_failclosed/errors.txt`
* `claude/04_TESTS/real_data_run_43484048208/oem318/integrated_failclosed/ram_flash.txt`
* `claude/04_TESTS/real_data_run_43484048208/oem318/integrated_failclosed/result.txt`
* `claude/04_TESTS/real_data_run_43484048208/oem318/integrated_failclosed/warnings.txt`
* `claude/04_TESTS/sim/test_c9.py`
* `claude/04_TESTS/test_evaluate_c9.py`
* `claude/04_TESTS/test_workflow_c9.py`
* `claude/docs_c8/claude_c8_route_b_patch_no_flash.yml`
* `claude/tools/evaluate_builds_c9.py`
* `claude/tools/make_workflow_c9.py`
* `run_tests.py`

**Entfernt:**
* (keine)
