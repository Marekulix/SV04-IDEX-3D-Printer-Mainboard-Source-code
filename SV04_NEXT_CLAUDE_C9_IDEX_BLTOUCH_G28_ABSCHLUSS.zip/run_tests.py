#!/usr/bin/env python3
"""EIN Kommando fuer alle lokalen Tests (SV04 NEXT, Claude C3). Alle Pfade relativ zu dieser Datei; keine festen /mnt- oder Heimverzeichnisse; laeuft nach dem Entpacken in einem frischen Ordner.
Schritte: (1) SHA256_MANIFEST.txt pruefen (falls vorhanden), (2) Kern-/Host-/Simulationstests inkl. Patch-Harnesses gegen die echten OEM-Dateien, (3) Konfigurationsaudit.
Voraussetzungen: python3, g++ (C++11), patch, PyYAML. KEIN STM32-Build, KEINE Hardware.
Aufruf: python3 run_tests.py [--logs ORDNER] [--stages core,host,sim] [--no-manifest]   (Exitcode 0 = alles bestanden)"""
import argparse
import hashlib
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TESTS = ROOT / '03_TESTS' if (ROOT / '03_TESTS' / 'claude').is_dir() else ROOT


def verify_manifest():
    m = ROOT / 'SHA256_MANIFEST.txt'
    if not m.is_file():
        print('SHA256_MANIFEST.txt nicht vorhanden: Manifestpruefung uebersprungen'); return True
    bad = n = 0
    for line in m.read_text(encoding='utf-8').splitlines():
        if not line.strip():
            continue
        h, _, rel = line.partition('  ')
        p = ROOT / rel
        n += 1
        if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest() != h:
            bad += 1; print('ABWEICHEND:', rel)
    print(f'MANIFEST: geprueft={n} abweichend={bad}')
    return bad == 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--logs', default=str(ROOT / '04_ROHLOGS' / 'lauf_neu')); ap.add_argument('--stages', default='core,host,sim'); ap.add_argument('--no-manifest', action='store_true')
    a = ap.parse_args()
    ok = True if a.no_manifest else verify_manifest()
    r = subprocess.run([sys.executable, '-B', 'claude/tools/run_all_tests_a60.py', '--stages', a.stages, '--logs', a.logs], cwd=TESTS)
    ok = ok and r.returncode == 0
    r2 = subprocess.run([sys.executable, '-B', 'claude/tools/check_idex_bltouch_config_c1.py'], cwd=TESTS, capture_output=True, text=True)
    print(r2.stdout.strip().splitlines()[-1] if r2.stdout.strip() else r2.stderr.strip()[-200:])
    ok = ok and r2.returncode == 0
    print('GESAMT: ' + ('ALLE TESTS BESTANDEN' if ok else 'FEHLER'))
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
