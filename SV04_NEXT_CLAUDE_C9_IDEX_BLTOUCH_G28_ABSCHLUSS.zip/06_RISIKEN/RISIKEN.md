# Offene Risiken (C9)
* Kompilierbarkeit der C9-Änderung bis zum GitHub-Lauf unbelegt.
* Verhaltensänderung: `M999` aus dem Stopp-Zustand verlangt `G28` (Schalter `SV04_CLAUDE_M999_REHOME_REQUIRED`); eingereihte Befehle nach `M999 S1` bleiben (Ringpuffer-Grund im Bericht).
* Nicht freigegeben: Z-Homing aus unbekannter Position (410 mm), T0/T1-Kollisionsabstände, BLTouch-Verhalten, EEPROM/Stromausfall und DWIN am Gerät.
