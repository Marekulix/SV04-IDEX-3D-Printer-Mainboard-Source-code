#!/usr/bin/env python3
"""Gehaerteter Aufruf von ChatGPTs integrate_318.py (der Installer selbst bleibt UNVERAENDERT).
LUECKE im Original: integrate_318.py prueft nur tool_change.cpp, motion.cpp und G29.cpp und UEBERSCHREIBT danach Kern und Adapter, ohne den 309-Zustand dieser Dateien zu pruefen. Eine abweichende 309-Zusammensetzung
(z. B. ein anderer Adapter) wuerde stillschweigend ersetzt. Dieser Aufruf pinnt zusaetzlich die Eingangshashes ALLER acht sv04_claude_*-Dateien des Standes 309 und weist UNBEKANNTE Claude-Dateien im Baum ab (C7: verbindlicher Standardpfad) (aus ChatGPTs source_hashes_after_308 und combined_308.patch).
Aufruf: integrate_318_strict.py <INTEGRATE_318_ORDNER> <VOLLSTAENDIGE_309> <NEUE_318_KOPIE>   Exitcode 4 = Eingangspruefung gescheitert (nichts geschrieben); sonst Exitcode des Original-Installers."""
import hashlib
import subprocess
import sys
from pathlib import Path

PIN_309 = {   # ALLE sv04_claude_*-Dateien des Standes 309 (aus ChatGPTs source_hashes_after_308 und dem vollstaendigen 309-Baum)
    'Marlin/src/feature/sv04_claude_auto60/sv04_claude_auto60_core.h': 'faf2d034a067ccecea5e0d413028e9598935fe577486748a6a5493bc16c6a097',
    'Marlin/src/feature/sv04_claude_auto60/sv04_claude_eeprom_core.h': '379848c3a0e3cd2f2a67e4f560b0a02592b6d95bd414818d8d4fc8ad0f04a2a3',
    'Marlin/src/feature/sv04_claude_auto60/sv04_claude_g29_session.h': 'd616c3e94826ffaac50e5e43fa842a53f17a091ff24537433edc8ce1c8afa250',
    'Marlin/src/feature/sv04_claude_auto60/sv04_claude_toolchange_policy.h': 'a6ea813001b6a81547c17834811aba68bc6022a526e19145643be2bfe445b16d',
    'Marlin/src/gcode/control/sv04_claude_toolchange_guard.h': 'b417b83080615d869ffd3b5115a057b10d4ce50187cfc12de3e8649888cad06d',
    'Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc': '03543e739c3fe75d668f57202441597a3a5050b62ffaa25c2f8ca45573db4f1f',
    'Marlin/src/lcd/e3v2/creality/sv04_claude_hooks.h': '7ca925326ca62b286c529c2ef2f722cb0899b6319c1f47aece5fb2f9d0b484aa',
    'Marlin/src/lcd/e3v2/creality/sv04_claude_oem_mesh_loop.inc': 'f7cf74f644d473927e13478d2f851d24c9b77f29c7c7f9b628f48809186a3b0b',
}


def main(argv):
    if len(argv) != 4:
        print(__doc__); return 2
    inst, src, dst = Path(argv[1]) / 'integrate_318.py', Path(argv[2]), Path(argv[3])
    bad = []
    for rel, want in PIN_309.items():
        p = src / rel
        got = hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else 'FEHLT'
        if got != want:
            bad.append(f'{rel}: {got} statt {want}')
    known = set(PIN_309)
    for f in sorted((src / 'Marlin' / 'src').rglob('sv04_claude_*')):
        rel = f.relative_to(src).as_posix()
        if f.is_file() and rel not in known:
            bad.append(f'{rel}: UNBEKANNTE Claude-Datei im 309-Baum (nicht im gepinnten Satz)')
    if dst.exists():
        bad.append(f'{dst}: Ziel existiert bereits')
    if bad:
        print('BLOCKED (strict): der 309-Eingang entspricht nicht dem gepinnten Stand; NICHTS wurde geschrieben:'); [print('  ' + b) for b in bad]
        return 4
    print('STRICT_PRECHECK=OK (alle %d Claude-Dateien entsprechen dem 309-Stand, keine unbekannte Claude-Datei)' % len(PIN_309))
    return subprocess.run([sys.executable, str(inst), str(src), str(dst)]).returncode


if __name__ == '__main__':
    sys.exit(main(sys.argv))
