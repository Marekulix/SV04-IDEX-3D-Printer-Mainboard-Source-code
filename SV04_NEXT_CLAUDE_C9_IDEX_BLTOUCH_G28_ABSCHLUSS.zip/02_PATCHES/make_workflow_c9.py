#!/usr/bin/env python3
"""Erzeugt claude_c9_stm32_no_flash.yml TEXTUELL aus dem gelieferten claude_c8_route_b_patch_no_flash.yml (Route B, im GitHub-Lauf 43484048208 erfolgreich):
 * Eingabenamen wie im erfolgreichen Lauf (SV04_NEXT_318_GITHUB_UPLOAD_06.zip) und das C9-Paket (Hash fest eingetragen);
 * Job baseline_318 (= der bewaehrte Modifikations-Job, 318 UNVERAENDERT) und Job c9_changes: dieselbe Vorbereitung, dann eine NEUE Kopie oem_c9 mit dem C9-Patch (apply_m999_reset_c9.py); nur oem_c9 wird gebaut;
 * der Kontrollbuild der 309 entfaellt (bereits belegt, unveraendert); Auswertungsjob mit evaluate_builds_c9.py --trees oem318,oem_c9 (rot, solange nicht alle vier Kombinationen belegt PASS sind). NO FLASH.
Aufruf: make_workflow_c9.py <c8_route_b.yml> <sha256_318_zip> <sha256_c9_zip> <out.yml> [<318_zip_name>]"""
import re
import sys
from pathlib import Path

src, sha318, shac9, out = Path(sys.argv[1]).read_text(encoding='utf-8'), sys.argv[2], sys.argv[3], sys.argv[4]
name318 = sys.argv[5] if len(sys.argv) > 5 else 'SV04_NEXT_318_GITHUB_UPLOAD_06.zip'
if not re.fullmatch(r'[0-9a-f]{64}', shac9) or sha318 not in src or not re.fullmatch(r'[A-Za-z0-9_.-]+\.zip', name318):
    print('FEHLER: Argumente ungueltig (64-stelliger C9-Hash, 318-Hash muss im Quell-Workflow stehen, ZIP-Name)', file=sys.stderr); sys.exit(2)
t = src


def rep(a, b, n=1):
    global t
    if t.count(a) != n:
        print(f'FEHLER: Anker {a[:80]!r} {t.count(a)} mal gefunden (erwartet {n})', file=sys.stderr); sys.exit(2)
    t = t.replace(a, b)


m = re.search(r"echo '([0-9a-f]{64})  SV04_NEXT_CLAUDE_C8_BUILD_EVIDENZ_NO_FLASH\.zip'", t)
if not m:
    print('FEHLER: C8-Paketpin nicht gefunden', file=sys.stderr); sys.exit(2)
rep(m.group(1), shac9, 3)
for a, b in (('SV04_NEXT_318_GESAMTINTEGRATION_UND_C6_UEBERGABE_NO_FLASH.zip', name318), ('SV04_NEXT_CLAUDE_C8_BUILD_EVIDENZ_NO_FLASH', 'SV04_NEXT_CLAUDE_C9_IDEX_BLTOUCH_G28_ABSCHLUSS'), ('c8pkg', 'c9pkg'), ('c8_host_tests', 'c9_host_tests'), ('input_c8_sha', 'input_c9_sha'), ('zip_c8_integrity', 'zip_c9_integrity'),
             ('Verify C8 inputs', 'Verify C9 inputs'), ('Claude C8 package', 'Claude C9 package'), ('Run Claude C8 host regression', 'Run Claude C9 host regression'), ('Verify and unpack the C8 package', 'Verify and unpack the C9 package'),
             ('SV04_C8B_MODIFIED_318_STM32_LOGS_NO_FLASH', 'SV04_C9_BASELINE_318_STM32_LOGS_NO_FLASH'), ('SV04_C8B_CONTROL_309_ORIGINAL_STM32_LOGS_NO_FLASH', 'SV04_C9_CONTROL_UNUSED'), ('SV04_C8B_', 'SV04_C9_')):
    t = t.replace(a, b)
if any(x in t for x in ('C8_BUILD', 'c8pkg', 'SV04_C8', 'SV04_NEXT_287', 'point1', 'integrate_286')):
    print('FEHLER: Reste von C8/287 im Workflow', file=sys.stderr); sys.exit(2)
rep('name: "C8 route B - 309 reproduced from combined_308.patch (NO 287, different route than the original 309 build), STRICT installer, control 309 vs modified 318, STM32 NO FLASH, evaluated (number-free)"',
    'name: "C9 - IDEX/BLTouch/G28 restart safety on 318 (route B reproduction, STRICT installer), baseline 318 vs C9 copy, STM32 NO FLASH, evaluated (number-free)"')
pre_jobs, jobs_text = t.split('\njobs:\n', 1)
head = pre_jobs + '\njobs:\n'
jobs = re.split(r'(?m)^(?=  [a-z_0-9]+:\n)', jobs_text)[1:]
J = {re.match(r'  ([a-z_0-9]+):', j).group(1): j for j in jobs}
if list(J) != ['control_309_original', 'modified_318_c6', 'evaluate_builds']:
    print('FEHLER: unerwartete Jobs', list(J), file=sys.stderr); sys.exit(2)
base = J['modified_318_c6']
h, steps = re.split(r'(?m)^(?=      - name: )', base)[0], re.split(r'(?m)^(?=      - name: )', base)[1:]
sname = lambda s: re.match(r'      - name: (.*)', s).group(1)
names = [sname(s) for s in steps]
need = ('Run Claude C9 host regression', 'Apply 318 installer to a NEW copy through the STRICT wrapper (309 stays untouched, fail-closed)')
for n in need:
    if not any(x.startswith(n[:40]) for x in names):
        print('FEHLER: erwarteter Schritt fehlt:', n, file=sys.stderr); sys.exit(2)
apply9 = ('      - name: Apply C9 patch to a NEW copy of 318 (318 stays untouched, fail-closed)\n        shell: bash\n        run: |\n          set -euo pipefail\n          cp -a oem318 oem_c9\n'
          '          python3 c9pkg/02_PATCHES/apply_m999_reset_c9.py oem_c9 2>&1 | tee evidence/apply_m999_reset_c9.txt\n          grep -F "M999_C9=PATCHED" evidence/apply_m999_reset_c9.txt\n'
          '          diff -rq oem318 oem_c9 2>&1 | tee evidence/diff_318_vs_c9.txt || true\n          test "$(diff -rq oem318 oem_c9 | wc -l)" -eq 1\n          grep -F "M999.cpp" evidence/diff_318_vs_c9.txt\n'
          '          echo "f778002d1a491dc58ee4d8c550120f24db477ec185d3f7124acc457968659cb9  oem318/Marlin/src/gcode/control/M999.cpp" | sha256sum -c - | tee evidence/oem318_m999_unchanged.txt\n'
          '          sha256sum oem_c9/Marlin/src/gcode/control/M999.cpp | tee evidence/source_hash_c9_m999.txt\n')
c9_steps, base_steps = [], []
for s in steps:
    n = sname(s)
    if n.startswith('Run Claude C9 host regression'): base_steps.append(s); continue
    if n.startswith('Build STM32 profiles'):
        c = s.replace('pio run -d oem318 -e', 'pio run -d oem_c9 -e').replace('oem318/.pio/build/STM32F103RET6_creality', 'oem_c9/.pio/build/STM32F103RET6_creality').replace('evidence/modified_318/', 'evidence/c9/').replace('BUILD_TREE=oem318', 'BUILD_TREE=oem_c9').replace('ROUTE_B_MODIFIED_318_NEW_COPY_OF_PATCH_REPRODUCED_309', 'ROUTE_B_C9_ON_318_NEW_COPY')
        if 'oem318' in c or c == s:
            print('FEHLER: Build-Schritt konnte nicht auf oem_c9 umgestellt werden', file=sys.stderr); sys.exit(2)
        c9_steps.append(apply9); c9_steps.append(c); base_steps.append(s); continue
    if n.startswith('Archive every log'): c9_steps.append(s); base_steps.append(s); continue
    c9_steps.append(s); base_steps.append(s)
J_base = h + ''.join(base_steps)
J_c9 = h.replace('  modified_318_c6:', '  c9_changes:', 1).replace('name: "Modified build: NEW 318 copy by integrate_318.py (both profiles)"', 'name: "C9 build: NEW copy oem_c9 = 318 + C9 patch (both profiles)"') + ''.join(s for s in c9_steps if not sname(s).startswith('Run Claude C9 host regression'))
J_c9 = J_c9.replace('name: SV04_C9_BASELINE_318_STM32_LOGS_NO_FLASH', 'name: SV04_C9_CHANGED_STM32_LOGS_NO_FLASH')
ev = J['evaluate_builds']
ev = ev.replace('needs: [control_309_original, modified_318_c6]', 'needs: [modified_318_c6, c9_changes]')
if ev.count('evaluate_builds_c9') or ev.count('evaluate_c7_builds.py art --out') != 1:
    print('FEHLER: Auswertungsschritt nicht wie erwartet', file=sys.stderr); sys.exit(2)
ev = ev.replace('evaluate_c7_builds.py art --out', 'evaluate_builds_c9.py art --trees oem318,oem_c9 --out').replace('control_309 and modified_318', 'oem318 and oem_c9')
text = head + J_base.rstrip('\n') + '\n\n' + J_c9.rstrip('\n') + '\n\n' + ev
Path(out).write_text(text, encoding='utf-8', newline='\n'); print('geschrieben', out, len(text.splitlines()), 'Zeilen')
