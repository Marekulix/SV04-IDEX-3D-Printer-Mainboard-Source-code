#!/usr/bin/env python3
"""DWIN-Adresspruefung (statisch, aus dem QUELLTEXT; KEIN HMI-Projekt, KEINE Hardware): doppelt vergebene aktive VP-Adressen, Kollisionen mit dem Auto60-Zellbereich, Seitenkonstanten.
Aufruf: check_dwin_addresses_c6.py <OEM_ROOT>   (Marlin/src/lcd/e3v2/creality/...). Exitcode 1 bei Doppelbelegung oder Kollision."""
import re
import sys
from pathlib import Path

root = Path(sys.argv[1]) / 'Marlin/src/lcd/e3v2/creality'
h = (root / 'LCD_RTS.h').read_text(errors='replace'); adapter = (root / 'sv04_claude_auto60_marlin.inc').read_text(errors='replace'); hooks = (root / 'sv04_claude_hooks.h').read_text(errors='replace')
active = {}
for i, l in enumerate(h.split('\n'), 1):
    m = re.match(r'^\s*#define\s+([A-Za-z_0-9]+)\s+(0x[0-9A-Fa-f]{2,4})\b', l)
    if m and not l.lstrip().startswith('//'): active.setdefault(int(m.group(2), 16), []).append((m.group(1), i))
fails = []
dup = {a: v for a, v in active.items() if len({n for n, _ in v}) > 1}
print(f'aktive #define mit Adresswert in LCD_RTS.h: {sum(len(v) for v in active.values())} | verschiedene Adressen: {len(active)}')
print('Doppelbelegung (gleiche Adresse, verschiedene Namen):', {hex(a): [n for n, _ in v] for a, v in dup.items()} or 'keine')
cell0 = active_name = None
base = next((a for a, v in active.items() if any(n == 'AUTO_BED_LEVEL_1POINT_VP' for n, _ in v)), None)
print('AUTO_BED_LEVEL_1POINT_VP =', hex(base) if base is not None else 'NICHT AKTIV')
if base is not None:
    cells = list(range(base, base + 16 * 2 + 1))                       # 16 Zellen: base + index*2 (je ein 32-Bit-Wert = 2 Worte)
    print(f'Auto60-/OEM-Zellbereich: {hex(base)} .. {hex(base + 31)} (16 Zellen, Schritt 2, je 2 Worte)')
    clash = {a: [n for n, _ in v] for a, v in active.items() if base < a < base + 32 and a != base}
    print('aktive Adressen IM Zellbereich (ausser der ersten Zelle):', {hex(a): n for a, n in clash.items()} or 'keine')
    if clash: fails.append('Kollision im Zellbereich')
print('Adapter schreibt Zellen mit:', re.findall(r'RTS_SndData\([^;]*AUTO_BED_LEVEL_1POINT_VP[^;]*;', adapter)[:1], '| Zell-Indizes 0..15 (index*2):', 'index * 2' in adapter)
used = sorted(set(re.findall(r'\b[A-Z_0-9]*_VP\b', adapter)))
print('Display-Adressen, die der Adapter verwendet:', used, '->', {u: hex(next((a for a, v in active.items() if any(n == u for n, _ in v)), 0)) for u in used})
for name in ('SV04_CLAUDE_PAGE_PROBING', 'SV04_CLAUDE_PAGE_SUCCESS', 'SV04_CLAUDE_PAGE_FAIL'):
    m = re.search(r'#\s*define\s+' + name + r'\s+(\S+)', hooks + adapter + h); print(f'{name} =', m.group(1) if m else 'NICHT DEFINIERT'); 
    if not m: fails.append(name + ' fehlt')
print('Seitenwechsel-Adresse ExchangepageAddr =', hex(next((a for a, v in active.items() if any(n == 'ExchangepageAddr' for n, _ in v)), 0)))
print('DWIN_ADDRESS_CHECK=' + ('FAIL ' + str(fails) if fails or dup else 'OK'))
sys.exit(1 if fails or dup else 0)
