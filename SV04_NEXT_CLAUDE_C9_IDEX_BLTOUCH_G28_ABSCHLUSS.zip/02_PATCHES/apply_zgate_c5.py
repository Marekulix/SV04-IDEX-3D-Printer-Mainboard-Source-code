#!/usr/bin/env python3
"""SV04 NEXT C5 (Claude), Angriff 1+5: Auto60 startet NICHT aus unbekanntem Z (Kaltstart).
BEGRUENDUNG: Bei unbekannter Z-Position ist keine Z-Strecke begruendbar (C3/C5: Obergrenze nur aus der Konfiguration, bis 410 mm). Die Automatik wuerde diese Fahrt ohne Bediener ausloesen. Deshalb: Start nur, wenn Z
referenziert UND vertrauenswuerdig ist; sonst Ablehnung mit R_PRE_Z_UNKNOWN. Der Bediener referenziert einmal von Hand (G28, Hand am Not-Aus); dann gilt fuer Auto60s eigenes G28 die begrenzte Strecke (C3).
AENDERUNG (angehaengt, alle bisherigen Reason-Zahlenwerte bleiben): core.h: R_PRE_Z_UNKNOWN nach R_MARLIN_STOPPED, Precond.z_unknown (ohne Initialisierer), Start-Pruefung. Adapter: read_precond fuellt z_unknown.
SCHALTER: SV04_CLAUDE_AUTO60_REQUIRE_Z_KNOWN (Standard 1). 0 = bisheriges Verhalten (Auto60 referenziert selbst aus dem Kaltstart) - nur nach ausdruecklicher Entscheidung.
Fail-closed: beide Dateien muessen dem Stand nach C4 entsprechen (sha256); jeder Anker genau einmal; geschrieben wird nur, wenn BEIDE passen; idempotent.
Aufruf: apply_zgate_c5.py <OEM_ROOT>"""
import hashlib
import sys
from pathlib import Path

CORE = Path('Marlin/src/feature/sv04_claude_auto60/sv04_claude_auto60_core.h')
INC = Path('Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc')
PIN = {'core': '04b3d83f18fb237b6ad7d888fe01dd6334903116ea710f61f299f955c5a232c0', 'inc': 'b75dd01a8fc93ebc4d4313b584662faa25bdaf40315e9b35f8cdb84e140c6859'}      # Stand nach C4
MARK = 'SV04 NEXT C5'
CORE_EDITS = [
    ('R_MARLIN_STOPPED /* SV04 NEXT C4: am ENDE, damit alle bisherigen Zahlenwerte bleiben */, R_COUNT };', 'R_MARLIN_STOPPED /* SV04 NEXT C4: am ENDE, damit alle bisherigen Zahlenwerte bleiben */, R_PRE_Z_UNKNOWN /* SV04 NEXT C5: ebenfalls am Ende */, R_COUNT };'),
    ('"CANCEL_AFTER_STEP", "MARLIN_STOPPED"}', '"CANCEL_AFTER_STEP", "MARLIN_STOPPED", "PRE_Z_UNKNOWN"}'),
    ('Precond bleibt trivial (boot_reset() nutzt memset) */;', 'Precond bleibt trivial (boot_reset() nutzt memset) */, z_unknown /* SV04 NEXT C5: Z nicht referenziert/vertrauenswuerdig (Kaltstart); ohne Initialisierer */;'),
    ('    if (q.heater_fault) return R_PRE_HEATER_FAULT;\n', '    if (q.z_unknown) return R_PRE_Z_UNKNOWN;                 // SV04 NEXT C5: kein Auto60-Start aus unbekanntem Z (erst von Hand referenzieren)\n    if (q.heater_fault) return R_PRE_HEATER_FAULT;\n'),
]
INC_EDITS = [
    ('  p.marlin_stopped = IsStopped();', '  #ifndef SV04_CLAUDE_AUTO60_REQUIRE_Z_KNOWN\n    #define SV04_CLAUDE_AUTO60_REQUIRE_Z_KNOWN 1                       // SV04 NEXT C5: Standard: Auto60 startet nur bei bekanntem Z\n  #endif\n  #if SV04_CLAUDE_AUTO60_REQUIRE_Z_KNOWN\n    p.z_unknown = !(axis_was_homed(Z_AXIS) && axis_is_trusted(Z_AXIS));        // SV04 NEXT C5\n  #else\n    p.z_unknown = false;\n  #endif\n  p.marlin_stopped = IsStopped();'),
]


def apply(raw, pin, edits, name):
    s = raw.decode('utf-8')
    if MARK in s:
        for _, new in edits:
            if s.count(new) != 1:
                raise ValueError(name + ': halb oder doppelt gepatcht')
        return raw, False
    h = hashlib.sha256(raw).hexdigest()
    if h != pin:
        raise ValueError('%s entspricht NICHT dem Stand nach C4 (sha256 %s statt %s): kein Patch' % (name, h, pin))
    for old, _ in edits:
        if s.count(old) != 1:
            raise ValueError('%s: Anker %d mal vorhanden (erwartet 1): %r' % (name, s.count(old), old[:60]))
    for old, new in edits:
        s = s.replace(old, new)
    return s.encode('utf-8'), True


def transform(core_raw, inc_raw):
    c, cc = apply(core_raw, PIN['core'], CORE_EDITS, 'core.h')
    i, ci = apply(inc_raw, PIN['inc'], INC_EDITS, 'marlin.inc')
    if cc != ci:
        raise ValueError('core.h und marlin.inc sind nicht im selben Zustand (nur eine Datei gepatcht)')
    return c, i, cc


def main(argv):
    if len(argv) != 2:
        print(__doc__); return 2
    root = Path(argv[1])
    c, i, ch = transform((root / CORE).read_bytes(), (root / INC).read_bytes())
    if ch:
        (root / CORE).write_bytes(c); (root / INC).write_bytes(i)
    print('ZGATE_C5=' + ('PATCHED' if ch else 'ALREADY_PATCHED'), 'core sha256', hashlib.sha256((root / CORE).read_bytes()).hexdigest(), 'inc sha256', hashlib.sha256((root / INC).read_bytes()).hexdigest())
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
