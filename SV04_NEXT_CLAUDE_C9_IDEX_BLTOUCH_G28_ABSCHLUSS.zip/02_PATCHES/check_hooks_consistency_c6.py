#!/usr/bin/env python3
"""Statische Konsistenz der Claude-Haken im zusammengesetzten OEM-Baum: jeder von OEM-Dateien genutzte SV04Claude_*-Bezeichner ist in hooks.h deklariert und (als Funktion im Adapter oder als struct in hooks.h) definiert.
Kein Ersatz fuer einen Build; findet aber Naht-Fehler zwischen Installer, Adapter und hooks.h. Aufruf: check_hooks_consistency_c6.py <OEM_ROOT>. Exitcode 1 bei Luecken."""
import re
import sys
from pathlib import Path

R = Path(sys.argv[1]) / 'Marlin/src'
used = {}
for f in R.rglob('*'):
    if f.is_file() and f.suffix in ('.cpp', '.h', '.inc') and 'SV04Claude_' in (t := f.read_text(errors='replace')):
        for m in re.finditer(r'\bSV04Claude_[A-Za-z0-9_]+', t): used.setdefault(m.group(0), set()).add(f.name)
hooks = (R / 'lcd/e3v2/creality/sv04_claude_hooks.h').read_text(); inc = (R / 'lcd/e3v2/creality/sv04_claude_auto60_marlin.inc').read_text()
decl = set(re.findall(r'\bSV04Claude_[A-Za-z0-9_]+', hooks))
fn = set(re.findall(r'^(?:[A-Za-z_:<>0-9 \*&]+?)\s+(SV04Claude_[A-Za-z0-9_]+)\s*\(', inc, flags=re.M)); structs = set(re.findall(r'struct\s+(SV04Claude_[A-Za-z0-9_]+)', hooks))
users = {k: v for k, v in used.items() if v - {'sv04_claude_hooks.h', 'sv04_claude_auto60_marlin.inc'}}
miss_decl = sorted(k for k in users if k not in decl); miss_def = sorted(k for k in users if k not in fn and k not in structs); orphan = sorted(k for k in fn if k not in decl)
print('Bezeichner SV04Claude_*, die OEM-Dateien nutzen:', len(users), '|', ', '.join(sorted(users)))
print('  nicht in hooks.h deklariert:', miss_decl or 'keine'); print('  weder im Adapter (Funktion) noch in hooks.h (struct) definiert:', miss_def or 'keine'); print('  im Adapter definiert, in hooks.h nicht deklariert:', orphan or 'keine')
macros = {}
for f in R.rglob('*'):
    if f.is_file() and f.suffix in ('.cpp', '.h', '.inc'):
        t = f.read_text(errors='replace'); own = set(re.findall(r'#\s*define\s+(SV04_CLAUDE_[A-Z0-9_]+)', t))
        for m in set(re.findall(r'\bSV04_CLAUDE_[A-Z0-9_]+', t)) - own: macros.setdefault(m, set()).add(f.name)
alld = set()
for f in R.rglob('*'):
    if f.is_file() and f.suffix in ('.cpp', '.h', '.inc'): alld |= set(re.findall(r'#\s*define\s+(SV04_CLAUDE_[A-Z0-9_]+)', f.read_text(errors='replace')))
undefined = sorted(m for m in macros if m not in alld and not m.startswith('SV04_CLAUDE_PAGE'))
print('Makros SV04_CLAUDE_* ohne irgendeine #define (vermutlich per -D oder #ifndef-Vorgabe):', undefined or 'keine')
ok = not (miss_decl or miss_def or orphan)
print('HOOKS_CONSISTENCY=' + ('OK' if ok else 'FAIL')); sys.exit(0 if ok else 1)
