#!/usr/bin/env python3
"""SV04 NEXT C4 (Claude): Startfreigabe und Laufzeit-Abbruch bei Marlin-Stopp (z. B. BLTouch deploy/stow -> stop(), MarlinCore.cpp:932).
BEFUNDE (ausgefuehrt in der Simulation, Stand 309):
 (1) Nach einem Stopp startete Auto60 erneut (START_OK) und scheiterte spaeter mit dem irrefuehrenden Grund HEAT_TARGET_CHANGED.
 (2) Wird Marlin mitten in der G29 gestoppt, endet Auto60 zwar (nur zufaellig ueber die Heizungspruefung), die laufende OEM-G29 misst aber ALLE restlichen Punkte weiter und faehrt das Endskript G28 XY.
AENDERUNG (minimal, angehaengt, alle bisherigen Reason-Zahlenwerte bleiben):
 core.h:    neuer Reason R_MARLIN_STOPPED am ENDE des Enums; Precond.marlin_stopped (ohne Initialisierer, Precond bleibt trivial); Start verweigert (start()) und der Lauf bricht in JEDEM aktiven Zustand am Anfang von tick() ab.
 Adapter:   read_precond fuellt marlin_stopped = IsStopped(); der G29-Abbruchtest bricht die G29 ab, wenn die Auto60-Sitzung DIESER G29 schon beendet ist (Bindung sv04c_bound/sv04c_bound_g29; eine
            manuelle G29 hat nie eine Bindung und bleibt unberuehrt).
Fail-closed: beide Dateien muessen dem Stand der Baseline 309 entsprechen (sha256), jeder Anker genau einmal; geschrieben wird nur, wenn BEIDE passen; idempotent.
Aufruf: apply_start_release_c4.py <OEM_ROOT>"""
import hashlib
import sys
from pathlib import Path

CORE = Path('Marlin/src/feature/sv04_claude_auto60/sv04_claude_auto60_core.h')
INC = Path('Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc')
PIN = {'core': 'faf2d034a067ccecea5e0d413028e9598935fe577486748a6a5493bc16c6a097', 'inc': '03543e739c3fe75d668f57202441597a3a5050b62ffaa25c2f8ca45573db4f1f'}   # Baseline 309
MARK = 'SV04 NEXT C4'
CORE_EDITS = [
    ('  R_USER_CANCEL, R_CANCEL_AFTER_STEP, R_COUNT };', '  R_USER_CANCEL, R_CANCEL_AFTER_STEP, R_MARLIN_STOPPED /* SV04 NEXT C4: am ENDE, damit alle bisherigen Zahlenwerte bleiben */, R_COUNT };'),
    ('"USER_CANCEL", "CANCEL_AFTER_STEP"}', '"USER_CANCEL", "CANCEL_AFTER_STEP", "MARLIN_STOPPED"}'),
    ('dwin_busy, home_backend_available, eeprom_available;\n  uint8_t active_extruder;\n};', 'dwin_busy, home_backend_available, eeprom_available, marlin_stopped /* SV04 NEXT C4: IsStopped(), z. B. nach BLTouch-stop(); KEIN Initialisierer: Precond bleibt trivial (boot_reset() nutzt memset) */;\n  uint8_t active_extruder;\n};'),
    ('    if (q.heater_fault) return R_PRE_HEATER_FAULT;\n', '    if (q.marlin_stopped) return R_MARLIN_STOPPED;           // SV04 NEXT C4: kein Start im gestoppten Zustand\n    if (q.heater_fault) return R_PRE_HEATER_FAULT;\n'),
    ('  void tick() {\n    if (!active()) return;\n', '  void tick() {\n    if (!active()) return;\n    { Precond sq; p_.read_precond(p_.ctx, sq); if (sq.marlin_stopped) { fail(R_MARLIN_STOPPED); return; } }      // SV04 NEXT C4: Marlin gestoppt (z. B. BLTouch-stop()) -> in JEDEM aktiven Zustand sofort FAILED mit dem richtigen Grund, vor der Heizungspruefung\n'),
]
INC_EDITS = [
    ('  p.heater_fault = false;', '  p.marlin_stopped = IsStopped();                                      // SV04 NEXT C4: nach stop() (BLTouch-Alarm) keine Freigabe\n  p.heater_fault = false;'),
    ('bool SV04Claude_G29CancelRequested() {\n  if (!sv04c_coord.running() || sv04c_coord.state() != sv04c::ST_PROBING) return false;',
     'bool SV04Claude_G29CancelRequested() {\n  if (sv04c_bound != 0 && sv04c_bound_g29 != 0 && !sv04c_coord.running()) return true;    // SV04 NEXT C4: die Auto60-Sitzung DIESER G29 ist beendet (FAILED/CANCELLED), die G29 laeuft noch: beim naechsten Messpunkt abbrechen, kein Endskript\n  if (!sv04c_coord.running() || sv04c_coord.state() != sv04c::ST_PROBING) return false;'),
]


SIGS = {'core.h': ['R_MARLIN_STOPPED /* SV04 NEXT C4', '"CANCEL_AFTER_STEP", "MARLIN_STOPPED"', 'marlin_stopped /* SV04 NEXT C4', '    if (q.marlin_stopped) return R_MARLIN_STOPPED;', 'if (sq.marlin_stopped) { fail(R_MARLIN_STOPPED); return; }'],
        'marlin.inc': ['  p.marlin_stopped = IsStopped();', '  if (sv04c_bound != 0 && sv04c_bound_g29 != 0 && !sv04c_coord.running()) return true;']}


def apply(raw, pin, edits, name):
    s = raw.decode('utf-8')
    if MARK in s:
        # Bereits gepatcht. Ein SPAETERER Patch (C5: apply_zgate_c5.py) erweitert Enum, Namenstabelle und Precond; deshalb Signaturen statt exaktem Text.
        sigs = SIGS[name]
        if any(s.count(g) != 1 for g in sigs):
            raise ValueError(name + ': halb oder doppelt gepatcht')
        return raw, False
    h = hashlib.sha256(raw).hexdigest()
    if h != pin:
        raise ValueError('%s entspricht NICHT der Baseline 309 (sha256 %s statt %s): kein Patch' % (name, h, pin))
    for old, _ in edits:
        if s.count(old) != 1:
            raise ValueError('%s: Anker %d mal vorhanden (erwartet 1): %r' % (name, s.count(old), old[:60]))
    for old, new in edits:
        s = s.replace(old, new)
    return s.encode('utf-8'), True


def transform(core_raw, inc_raw):
    c, cc = apply(core_raw, PIN['core'], CORE_EDITS, 'core.h')
    i, ci = apply(inc_raw, PIN['inc'], INC_EDITS, 'marlin.inc')
    if cc != ci:
        raise ValueError('core.h und marlin.inc sind nicht im selben Zustand (nur eine Datei gepatcht)')
    return c, i, cc


def main(argv):
    if len(argv) != 2:
        print(__doc__); return 2
    root = Path(argv[1])
    c, i, ch = transform((root / CORE).read_bytes(), (root / INC).read_bytes())
    if ch:
        (root / CORE).write_bytes(c); (root / INC).write_bytes(i)
    print('START_RELEASE_C4=' + ('PATCHED' if ch else 'ALREADY_PATCHED'), 'core sha256', hashlib.sha256((root / CORE).read_bytes()).hexdigest(), 'inc sha256', hashlib.sha256((root / INC).read_bytes()).hexdigest())
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
