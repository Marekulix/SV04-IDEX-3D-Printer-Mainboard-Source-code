#!/usr/bin/env python3
"""Prueft die Eingaben eines Workflows GEGEN die vorhandenen Dateien: Dateiname, SHA-256 (aus den `echo '<hash>  <datei>' | sha256sum -c`-Zeilen des Workflows), ZIP-Integritaet und -- fuer jedes entpackte Archiv -- ob die vom Workflow
REFERENZIERTEN Mitglieder (`unzip -q <zip> -d <dir>` + `<dir>/<pfad>`) wirklich im Archiv stehen. Es wird NICHTS umbenannt und keine Pruefsumme umgangen; eine fehlende Datei bleibt MISSING.
Aufruf: verify_inputs_c8.py <WORKFLOW.yml> <ORDNER_MIT_DEN_ZIPS> [--out LOG]   Exitcode 0 = alle Eingaben vorhanden und strukturell passend; 3 = mindestens eine MISSING/BAD."""
import hashlib
import re
import sys
import zipfile
from pathlib import Path

wf = Path(sys.argv[1]).read_text(encoding='utf-8'); folder = Path(sys.argv[2])
outp = Path(sys.argv[sys.argv.index('--out') + 1]) if '--out' in sys.argv else None
pins = {}
for h, n in re.findall(r"echo '([0-9a-f]{64})  ([^'\n]+?\.zip)'\s*\|\s*sha256sum -c", wf): pins[n] = h
unz = dict((n, d) for n, d in re.findall(r"unzip -q (?:'([^']+)'|(\S+\.zip)) -d (\S+)", wf) and [((a or b), c) for a, b, c in re.findall(r"unzip -q (?:'([^']+)'|(\S+\.zip)) -d (\S+)", wf)])
refs = {}
for d in set(unz.values()):
    for m in re.finditer(r'(?<![A-Za-z0-9_])' + re.escape(d) + r'/([A-Za-z0-9_./-]+\.(?:py|cpp|h|txt|zip|inc|json|md))', wf): refs.setdefault(d, set()).add(m.group(1))
L = ['PRUEFUNG DER WORKFLOW-EINGABEN (verify_inputs_c8.py)', f'Workflow: {Path(sys.argv[1]).name} | Ordner: {folder}', '', f'{"Datei":<66}{"Status":<10}Details']
bad = 0
for name, h in pins.items():
    p = folder / name
    if not p.is_file(): L.append(f'{name:<66}{"MISSING":<10}erwartet SHA-256 {h}'); bad += 1; continue
    got = hashlib.sha256(p.read_bytes()).hexdigest()
    if got != h: L.append(f'{name:<66}{"BAD_HASH":<10}gefunden {got} statt {h}'); bad += 1; continue
    try: names = set(zipfile.ZipFile(p).namelist()); zok = zipfile.ZipFile(p).testzip() is None
    except Exception as e: L.append(f'{name:<66}{"BAD_ZIP":<10}{type(e).__name__}'); bad += 1; continue
    d = unz.get(name); need = sorted(refs.get(d, [])) if d else []
    miss = [r for r in need if not any(x == r or x.endswith('/' + r) for x in names)]
    if not zok or miss: L.append(f'{name:<66}{"BAD_STRUCT":<10}fehlende Mitglieder: {miss}'); bad += 1
    else: L.append(f'{name:<66}{"OK":<10}Hash stimmt, ZIP ok, {len(names)} Mitglieder, referenzierte Mitglieder vorhanden: {need or "(keine direkten)"}')
extra = sorted(p.name for p in folder.glob('*.zip') if p.name not in pins)
L += ['', f'Nicht vom Workflow gepinnte ZIPs im Ordner (werden NICHT als Ersatz benutzt): {extra or "keine"}', f'ERGEBNIS={"ALLE_EINGABEN_OK" if not bad else f"{bad}_EINGABE(N)_NICHT_ERFUELLT"}']
text = '\n'.join(L) + '\n'; print(text)
if outp: outp.write_text(text, encoding='utf-8')
sys.exit(0 if not bad else 3)
