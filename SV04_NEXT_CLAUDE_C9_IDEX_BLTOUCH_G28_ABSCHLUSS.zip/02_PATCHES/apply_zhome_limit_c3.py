#!/usr/bin/env python3
"""SV04 NEXT C3 (Claude), AP1: begrenzt die schnelle Z-Homing-Fahrt in motion.cpp homeaxis() auf (erwartete Strecke + Toleranz), wenn Z vorher referenziert und vertrauenswuerdig war.
Eingabe MUSS der motion.cpp der Baseline 309 entsprechen (OEM + P1-Patch; sha256 im Skript). Fail-closed: andere Quelle -> Abbruch ohne Aenderung; jeder Anker genau einmal; idempotent.
Aufruf: apply_zhome_limit_c3.py <OEM_ROOT>   (schreibt zusaetzlich sv04_claude_zhome_policy.h neben die Claude-Dateien)"""
import hashlib
import sys
from pathlib import Path

PIN_MOTION_309_SHA256 = '54ff1c0c034f76b1c795e747cbc0fad525c259c6ce6ffd0e8c7fd4c90062ec96'   # motion.cpp der Baseline 309 (aus OEM-Original + combined_308.patch rekonstruiert, siehe test_c3)
TARGET = Path('Marlin/src/module/motion.cpp')
MARK = 'SV04 NEXT C3 (AP1)'
A_INC = '#include "../core/debug_out.h"\n'
B_INC = A_INC + '#include "../feature/sv04_claude_auto60/sv04_claude_zhome_policy.h"   // SV04 NEXT C3 (AP1)\n'
A_MOVE = '    const float move_length = 1.5f * max_length(TERN(DELTA, Z_AXIS, axis)) * axis_home_dir;\n'
B_MOVE = ('    float move_length = 1.5f * max_length(TERN(DELTA, Z_AXIS, axis)) * axis_home_dir;\n'
          '    #if SV04_CLAUDE_ZHOME_LIMIT && ENABLED(DUAL_X_CARRIAGE) && ENABLED(BLTOUCH) && HOMING_Z_WITH_PROBE\n'
          '      // SV04 NEXT C3 (AP1): ist Z bekannt, nur (erwartete Strecke + Toleranz) fahren statt 1,5 x max_length (bis 600 mm bei ausbleibendem Trigger); Z unbekannt: OEM-Strecke unveraendert\n'
          '      if (axis == Z_AXIS) move_length = sv04c_zhome_limit(move_length, axis_was_homed(Z_AXIS) && axis_is_trusted(Z_AXIS), current_position.z, probe.offset.z);\n'
          '    #endif\n')


def transform(raw):
    s = raw.decode('utf-8')
    if MARK in s:
        # Bereits gepatcht. Ein SPAETERER Patch (C5: apply_zhome_cold_c5.py) darf den Aufruf innerhalb des Blocks erweitern; deshalb pruefen wir Signaturen statt den exakten Text.
        sig = (s.count(B_INC) == 1 and s.count('    float move_length = 1.5f * max_length(TERN(DELTA, Z_AXIS, axis)) * axis_home_dir;\n') == 1 and s.count('if (axis == Z_AXIS) move_length = sv04c_zhome_limit(move_length, axis_was_homed(Z_AXIS) && axis_is_trusted(Z_AXIS), current_position.z, probe.offset.z') == 1)
        if not sig:
            raise ValueError('motion.cpp ist halb oder doppelt gepatcht')
        return raw, False
    h = hashlib.sha256(raw).hexdigest()
    if h != PIN_MOTION_309_SHA256:
        raise ValueError('motion.cpp entspricht NICHT dem Stand der Baseline 309 (sha256 %s statt %s): kein Patch' % (h, PIN_MOTION_309_SHA256))
    for a in (A_INC, A_MOVE):
        if s.count(a) != 1:
            raise ValueError('Anker %d mal vorhanden (erwartet 1): %r' % (s.count(a), a[:60]))
    return s.replace(A_INC, B_INC).replace(A_MOVE, B_MOVE).encode('utf-8'), True


def main(argv):
    if len(argv) != 2:
        print(__doc__); return 2
    root = Path(argv[1]); p = root / TARGET
    new, ch = transform(p.read_bytes())
    here = Path(__file__).resolve().parents[1] / '02_SOURCE' / 'Marlin' / 'src' / 'feature' / 'sv04_claude_auto60' / 'sv04_claude_zhome_policy.h'
    dst = root / 'Marlin' / 'src' / 'feature' / 'sv04_claude_auto60' / 'sv04_claude_zhome_policy.h'
    dst.parent.mkdir(parents=True, exist_ok=True); dst.write_bytes(here.read_bytes())
    if ch:
        p.write_bytes(new)
    print('ZHOME_LIMIT_C3=' + ('PATCHED' if ch else 'ALREADY_PATCHED'), p, 'sha256', hashlib.sha256(p.read_bytes()).hexdigest())
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
