#!/usr/bin/env python3
"""SV04 NEXT C3 (Claude), AP2: ein Werkzeugwechsel darf X-VERTRAUEN NIE ERZEUGEN.
BEFUND (echter OEM-Code, Commit 1867fcba): dualx_tool_change() ruft set_axis_is_at_home(X_AXIS) bei JEDEM Wechsel auf, auch wenn no_move gesetzt ist (nicht alle Achsen referenziert). set_axis_is_at_home()
setzt set_axis_trusted(X) UND set_axis_homed(X) (motion.cpp) und ueberschreibt current_position.x. Ein T0/T1 - auch ein INTERNER Aufruf (M605 S2 -> tool_change(0), M600/M701, G29, G26, ExtUI) - machte X also ohne
Referenzfahrt wieder "referenziert und vertrauenswuerdig". C2 schuetzt nur den regulaeren T-G-Code (T.cpp); diese Aenderung schliesst ALLE Pfade an der Quelle.
AENDERUNG: vor dem Wechsel merken, ob X wirklich referenziert UND vertrauenswuerdig war; nach set_axis_is_at_home(X) die Flags wieder entziehen, wenn sie vorher nicht gesetzt waren. War X vertrauenswuerdig, bleibt das
Verhalten BYTEGLEICH zum OEM (geprueft: Harness mit der extrahierten echten Funktion). Fail-closed: Pin = Git-Blob-SHA-1 der OEM-tool_change.cpp; jeder Anker genau einmal; idempotent.
Aufruf: apply_dxc_no_trust_c3.py <OEM_ROOT>"""
import hashlib
import sys
from pathlib import Path

PIN_TOOL_CHANGE = 'cb551647d7d33c8e5935e2828b0937bf0a7dcd12'      # git blob sha1 Marlin/src/module/tool_change.cpp @ 1867fcba75354a5c65e0631d6972dd19f1bd6cbe (unveraendert in Baseline 309)
TARGET = Path('Marlin/src/module/tool_change.cpp')
MARK = 'SV04 NEXT C3: a tool change must never CREATE X trust'
OLD = """    // Activate the new extruder ahead of calling set_axis_is_at_home!
    active_extruder = new_tool;

    // This function resets the max/min values - the current position may be overwritten below.
    set_axis_is_at_home(X_AXIS);
"""
NEW = """    // SV04 NEXT C3: remember whether X was REALLY homed and trusted before this tool change
    const bool sv04c_x_was_ok = axis_was_homed(X_AXIS) && axis_is_trusted(X_AXIS);

    // Activate the new extruder ahead of calling set_axis_is_at_home!
    active_extruder = new_tool;

    // This function resets the max/min values - the current position may be overwritten below.
    set_axis_is_at_home(X_AXIS);

    // SV04 NEXT C3: a tool change must never CREATE X trust. set_axis_is_at_home() marks X homed AND trusted (motion.cpp), even when no_move is set because the axes are not homed.
    // Without a real homing move the new position is only an assumption: take the flags back (G28 and all other real homing set them again legitimately).
    if (!sv04c_x_was_ok) { set_axis_unhomed(X_AXIS); set_axis_untrusted(X_AXIS); }
"""


def blob_sha1(b):
    return hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()


def transform(raw):
    s = raw.decode('utf-8')
    if MARK in s:
        if s.count(NEW) != 1:
            raise ValueError('tool_change.cpp ist halb oder doppelt gepatcht')
        return raw, False
    if blob_sha1(raw) != PIN_TOOL_CHANGE:
        raise ValueError('tool_change.cpp weicht vom gepinnten OEM-Stand ab (git-sha1 %s statt %s): kein Patch' % (blob_sha1(raw), PIN_TOOL_CHANGE))
    if s.count(OLD) != 1:
        raise ValueError('Anker %d mal vorhanden (erwartet 1)' % s.count(OLD))
    return s.replace(OLD, NEW).encode('utf-8'), True


def main(argv):
    if len(argv) != 2:
        print(__doc__); return 2
    p = Path(argv[1]) / TARGET
    new, ch = transform(p.read_bytes())
    if ch:
        p.write_bytes(new)
    print('DXC_NO_TRUST_C3=' + ('PATCHED' if ch else 'ALREADY_PATCHED'), p, 'sha256', hashlib.sha256(p.read_bytes()).hexdigest())
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
