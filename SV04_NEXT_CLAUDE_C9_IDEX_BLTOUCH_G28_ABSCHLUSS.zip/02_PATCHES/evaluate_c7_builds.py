#!/usr/bin/env python3
"""Wertet die Ergebnisse der GitHub-Buildjobs aus. Meldet NIE pauschal Erfolg: bestanden ist nur, was BUILD_EXIT=0 UND den PlatformIO-[SUCCESS]-Marker UND RAM-/Flash-Zeilen im build.log belegt.
Erwartet vier Kombinationen: {control_309, modified_318} x {integrated_backend, integrated_failclosed} (je evidence/<baum>/<profil>/result.txt + build.log).
Aufruf: evaluate_c7_builds.py <ARTEFAKT_WURZEL> [--out EVALUATION.md]
Exitcode: 0 = alle vier PASS; 3 = mindestens eine Kombination FAIL/INCOMPLETE/MISSING; 2 = ueberhaupt keine Ergebnisdatei gefunden (BLOCKED)."""
import re
import sys
from pathlib import Path

TREES = ('control_309', 'modified_318')
PROFILES = ('integrated_backend', 'integrated_failclosed')
ERR = re.compile(r'(fatal error:|\berror:|undefined reference|ld returned|collect2: error|\*\*\* \[.*\] Error)')
USED = re.compile(r'(RAM|Flash):\s*\[[^\]]*\]\s*([0-9.]+)%\s*\(used\s*(\d+)\s*bytes from\s*(\d+)\s*bytes\)')


def parse_result(p):
    kv = {}
    for l in p.read_text(errors='replace').splitlines():
        if '=' in l:
            k, _, v = l.partition('='); kv[k.strip()] = v.strip()
    return kv


def judge(res_file):
    kv = parse_result(res_file); log = res_file.parent / 'build.log'
    out = {'tree': kv.get('BUILD_TREE', '?'), 'profile': kv.get('PROFILE', '?'), 'exit': kv.get('BUILD_EXIT'), 'errors': [], 'warnings': 0, 'ram': None, 'flash': None, 'status': None, 'why': ''}
    if out['exit'] is None or not re.fullmatch(r'-?\d+', out['exit'] or ''):
        out.update(status='INCOMPLETE', why='result.txt ohne gueltiges BUILD_EXIT'); return out
    text = log.read_text(errors='replace') if log.is_file() else None
    if text is not None:
        for l in text.splitlines():
            if ERR.search(l) and 'SUCCESS' not in l and 'FAILED' not in l.split(':')[0:1]: out['errors'].append(l.strip()[:240])
        out['warnings'] = sum(1 for l in text.splitlines() if 'warning:' in l)
        for m in USED.finditer(text): out['ram' if m.group(1) == 'RAM' else 'flash'] = (int(m.group(3)), int(m.group(4)), float(m.group(2)))
    if int(out['exit']) != 0:
        out.update(status='FAIL', why=f'BUILD_EXIT={out["exit"]}'); return out
    if text is None: out.update(status='INCOMPLETE', why='BUILD_EXIT=0, aber kein build.log'); return out
    if '[SUCCESS]' not in text: out.update(status='INCOMPLETE', why='BUILD_EXIT=0 ohne PlatformIO-[SUCCESS]-Marker'); return out
    if out['ram'] is None or out['flash'] is None: out.update(status='INCOMPLETE', why='BUILD_EXIT=0 und SUCCESS, aber keine RAM-/Flash-Zeilen'); return out
    out.update(status='PASS'); return out


def main(argv):
    if len(argv) < 2:
        print(__doc__); return 2
    root = Path(argv[1]); outp = Path(argv[argv.index('--out') + 1]) if '--out' in argv else None
    files = sorted(root.rglob('result.txt')) if root.is_dir() else []
    if not files:
        msg = f'GESAMTERGEBNIS=BLOCKED_KEINE_ERGEBNISDATEIEN unter {root}: es wurde KEIN Build ausgewertet, es wird KEIN Erfolg gemeldet.'
        print(msg)
        if outp: outp.write_text('# Build-Auswertung\n\n' + msg + '\n', encoding='utf-8')
        return 2
    found = {}
    for f in files:
        j = judge(f); found[(j['tree'], j['profile'])] = j
    L = ['# Build-Auswertung (nur belegte Ergebnisse)', '', '| Baum | Profil | Status | Exit | RAM | Flash | Compilerfehler | Warnungen | Grund |', '|---|---|---|---|---|---|---|---|---|']
    npass = 0
    for t in TREES:
        for p in PROFILES:
            j = found.get((t, p))
            if j is None: L.append(f'| {t} | {p} | **MISSING** | - | - | - | - | - | keine Ergebnisdatei |'); continue
            fmt = lambda v: f'{v[0]}/{v[1]} B ({v[2]}%)' if v else '-'
            npass += j['status'] == 'PASS'
            L.append(f'| {t} | {p} | **{j["status"]}** | {j["exit"]} | {fmt(j["ram"])} | {fmt(j["flash"])} | {len(j["errors"])} | {j["warnings"]} | {j["why"]} |')
    extra = sorted(k for k in found if k not in {(t, p) for t in TREES for p in PROFILES})
    if extra: L += ['', 'Unerwartete Ergebnisse (nicht gezaehlt): ' + ', '.join(f'{a}/{b}' for a, b in extra)]
    for (t, p), j in sorted(found.items()):
        if j['status'] == 'FAIL' and j['errors']:
            L += ['', f'## Erste echte Compilerfehler: {t} / {p}', *['    ' + e for e in j['errors'][:10]]]
    L += ['', '## Vergleich Kontrolle 309 gegen modifizierte 318 (nur wenn BEIDE PASS)']
    for p in PROFILES:
        a, b = found.get(('control_309', p)), found.get(('modified_318', p))
        if a and b and a['status'] == b['status'] == 'PASS': L.append(f'* {p}: RAM {b["ram"][0] - a["ram"][0]:+d} B, Flash {b["flash"][0] - a["flash"][0]:+d} B (318 gegenueber 309)')
        else: L.append(f'* {p}: kein Vergleich moeglich')
    verdict = 'GESAMTERGEBNIS=BUILD_OK_ALLE_4_KOMBINATIONEN' if npass == 4 and not extra or npass == 4 else f'GESAMTERGEBNIS=NICHT_BESTANDEN ({npass} von 4 Kombinationen belegt PASS)'
    L += ['', verdict, 'FLASH_ALLOWED=NO', 'HARDWARE_TESTED=NO']
    text = '\n'.join(L) + '\n'; print(text)
    if outp: outp.parent.mkdir(parents=True, exist_ok=True); outp.write_text(text, encoding='utf-8')
    return 0 if npass == 4 else 3


if __name__ == '__main__':
    sys.exit(main(sys.argv))
