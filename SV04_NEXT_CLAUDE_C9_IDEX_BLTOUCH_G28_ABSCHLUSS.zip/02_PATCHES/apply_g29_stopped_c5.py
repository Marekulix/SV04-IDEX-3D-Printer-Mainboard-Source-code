#!/usr/bin/env python3
"""SV04 NEXT C5 (Claude), Angriff 3: eine MANUELL gestartete G29 wird im Marlin-Stopp-Zustand verweigert.
BEFUND (echter OEM-Code): queue.cpp:509 sperrt im Stopp-Zustand nur G0-G5; G28 und G29 laufen weiter. Nach einem BLTouch-stop() (bltouch.cpp, MarlinCore.cpp:932: alle Heizungen aus) wuerde eine G29 also messen, obwohl der Zustand
"Neustart noetig" ist. G28 bleibt BEWUSST unberuehrt: es ist der heutige Wiederherstellungsweg fuer Display-Nutzer (im Display-Code gibt es keinen M999-Weg).
AENDERUNG: G29.cpp: #include MarlinCore.h und eine Pruefung am Funktionsanfang (vor jedem Haken/Zustand): IsStopped() -> Fehlermeldung, G29_RETURN(false), nichts wird veraendert. Schalter SV04_CLAUDE_G29_REFUSE_WHEN_STOPPED (Standard 1).
Fail-closed: G29.cpp muss dem Stand der Baseline 309 entsprechen (sha256), Anker genau einmal, idempotent.
Aufruf: apply_g29_stopped_c5.py <OEM_ROOT>"""
import hashlib
import sys
from pathlib import Path

PIN_G29_309 = 'c1b44b74784eaaa45da8c13d1765a2094a3823c45912fc7200e3873924c1de24'
TARGET = Path('Marlin/src/gcode/bedlevel/abl/G29.cpp')
MARK = 'SV04 NEXT C5'
A_INC = '#include "../../../core/debug_out.h"\n'
B_INC = A_INC + '#include "../../../MarlinCore.h"   // SV04 NEXT C5: IsStopped()\n'
A_FN = 'G29_TYPE GcodeSuite::G29() {\n  DEBUG_SECTION(log_G29, "G29", DEBUGGING(LEVELING));\n'
B_FN = A_FN + ('  // SV04 NEXT C5: im Marlin-Stopp-Zustand (z. B. nach BLTouch-stop()) KEINE Messung; Neustart (M999 / Aus- und Einschalten) ist noetig. G28 bleibt als Wiederherstellungsweg erlaubt.\n'
               '  #ifndef SV04_CLAUDE_G29_REFUSE_WHEN_STOPPED\n    #define SV04_CLAUDE_G29_REFUSE_WHEN_STOPPED 1\n  #endif\n'
               '  #if SV04_CLAUDE_G29_REFUSE_WHEN_STOPPED\n    if (IsStopped()) { SERIAL_ERROR_MSG("SV04 C5: G29 refused, printer is in STOPPED state (BLTouch alarm?). Restart first (M999 or power cycle)"); G29_RETURN(false); }\n  #endif\n')


def transform(raw, check_pin=True):
    s = raw.decode('utf-8')
    if MARK in s:
        if s.count(B_FN) != 1 or s.count(B_INC) != 1:
            raise ValueError('G29.cpp ist halb oder doppelt gepatcht')
        return raw, False
    h = hashlib.sha256(raw).hexdigest()
    if check_pin and h != PIN_G29_309:
        raise ValueError('G29.cpp entspricht NICHT dem Stand der Baseline 309 (sha256 %s statt %s): kein Patch' % (h, PIN_G29_309))
    for a in (A_INC, A_FN):
        if s.count(a) != 1:
            raise ValueError('Anker %d mal vorhanden (erwartet 1): %r' % (s.count(a), a[:60]))
    return s.replace(A_INC, B_INC).replace(A_FN, B_FN).encode('utf-8'), True


def main(argv):
    if len(argv) != 2:
        print(__doc__); return 2
    p = Path(argv[1]) / TARGET
    new, ch = transform(p.read_bytes())
    if ch:
        p.write_bytes(new)
    print('G29_STOPPED_C5=' + ('PATCHED' if ch else 'ALREADY_PATCHED'), p, 'sha256', hashlib.sha256(p.read_bytes()).hexdigest())
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
