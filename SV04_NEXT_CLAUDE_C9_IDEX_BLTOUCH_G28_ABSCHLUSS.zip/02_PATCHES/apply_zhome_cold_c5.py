#!/usr/bin/env python3
"""SV04 NEXT C5 (Claude), Angriff 1: Z-Homing bei UNBEKANNTEM Z (Kaltstart) auf eine aus der KONFIGURATION abgeleitete Obergrenze begrenzen: max_length(Z) + Z_CLEARANCE_DEPLOY_PROBE (400 + 10 = 410 mm statt 1,5 x 400 = 600 mm).
Baut auf C3 (apply_zhome_limit_c3.py) auf und aendert nur den Aufruf in motion.cpp homeaxis(): zusaetzliches Argument max_length(Z_AXIS). Bleibt bei bekanntem Z unveraendert (C3-Verhalten).
HINWEIS: Das ist KEINE Sicherheit gegen einen ausbleibenden Trigger bei unbekannter Position, sondern eine Reduktion des Worst Case um 190 mm; die Annahme "Konfiguration = Mechanik" ist nicht gemessen.
Fail-closed: motion.cpp muss dem Stand nach C3 entsprechen (sha256), Anker genau einmal, idempotent.
Aufruf: apply_zhome_cold_c5.py <OEM_ROOT>"""
import hashlib
import sys
from pathlib import Path

PIN_MOTION_AFTER_C3 = 'f56c28ff15033cd028bc4de5755acf28462a8c52dcecdf870bce6060220725c4'
TARGET = Path('Marlin/src/module/motion.cpp')
MARK = 'SV04 NEXT C5 (cold start cap)'
OLD = 'current_position.z, probe.offset.z);\n'
NEW = 'current_position.z, probe.offset.z, max_length(Z_AXIS));   // SV04 NEXT C5 (cold start cap): bei unbekanntem Z Obergrenze max_length(Z) + Sondenfreiheit\n'


def transform(raw):
    s = raw.decode('utf-8')
    if MARK in s:
        if s.count(NEW) != 1:
            raise ValueError('motion.cpp ist halb oder doppelt gepatcht')
        return raw, False
    h = hashlib.sha256(raw).hexdigest()
    if h != PIN_MOTION_AFTER_C3:
        raise ValueError('motion.cpp entspricht NICHT dem Stand nach C3 (sha256 %s statt %s): erst apply_zhome_limit_c3.py, kein Patch' % (h, PIN_MOTION_AFTER_C3))
    if s.count(OLD) != 1:
        raise ValueError('Anker %d mal vorhanden (erwartet 1)' % s.count(OLD))
    return s.replace(OLD, NEW).encode('utf-8'), True


def main(argv):
    if len(argv) != 2:
        print(__doc__); return 2
    root = Path(argv[1]); p = root / TARGET
    new, ch = transform(p.read_bytes())
    here = Path(__file__).resolve().parents[1] / '02_SOURCE' / 'Marlin' / 'src' / 'feature' / 'sv04_claude_auto60' / 'sv04_claude_zhome_policy.h'
    dst = root / 'Marlin' / 'src' / 'feature' / 'sv04_claude_auto60' / 'sv04_claude_zhome_policy.h'
    dst.parent.mkdir(parents=True, exist_ok=True); dst.write_bytes(here.read_bytes())
    if ch:
        p.write_bytes(new)
    print('ZHOME_COLD_C5=' + ('PATCHED' if ch else 'ALREADY_PATCHED'), p, 'sha256', hashlib.sha256(p.read_bytes()).hexdigest())
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
