#!/usr/bin/env python3
"""SV04 NEXT C9 (Claude), Wiederaufnahme nach Fehlern: Ein Neustart nach dem Marlin-Stopp-Zustand (M999) erzeugt KEINE Sicherheitsfreigabe mehr.
BEFUND (echter OEM-Code): stop() (MarlinCore.cpp) aendert die Referenzierung nicht, M999 setzt nur marlin_state = MF_RUNNING. Nach einem BLTouch-stop() (z. B. mitten in der G29) und M999 gelten X, Y und Z weiter als referenziert und
vertrauenswuerdig; Auto60 (Z-Sperre C5), T1 (C2-Wachter) und die Softwareendschalter wuerden den Zustand fuer sicher halten.
AENDERUNG (M999.cpp, +14 Zeilen): Wird M999 aus dem STOPP-ZUSTAND aufgerufen, werden X/Y/Z auf "nicht referenziert und nicht vertrauenswuerdig" gesetzt (set_all_unhomed()) und eine Meldung ausgegeben. M999 ausserhalb des Stopp-Zustands bleibt
unveraendert. Die Befehlswarteschlange wird BEWUSST NICHT angefasst: ring_buffer.clear() innerhalb eines G-Code-Handlers wuerde den uint8_t-Laengenzaehler nach advance_pos(index_r, -1) unterlaufen lassen (queue.h:78/80, queue.cpp advance()).
Schalter: SV04_CLAUDE_M999_REHOME_REQUIRED (Standard 1; 0 = OEM-Verhalten). Fail-closed: M999.cpp muss dem OEM-Original entsprechen (sha256), Anker genau einmal, idempotent.
Aufruf: apply_m999_reset_c9.py <OEM_ROOT>"""
import hashlib
import sys
from pathlib import Path

PIN_OEM_M999 = 'f778002d1a491dc58ee4d8c550120f24db477ec185d3f7124acc457968659cb9'
TARGET = Path('Marlin/src/gcode/control/M999.cpp')
MARK = 'SV04 NEXT C9'
A_INC = '#include "../queue.h"           // for flush_and_request_resend\n'
B_INC = A_INC + '#include "../../module/motion.h" // SV04 NEXT C9: set_all_unhomed()\n'
A_FN = 'void GcodeSuite::M999() {\n  marlin_state = MF_RUNNING;\n  ui.reset_alert_level();\n'
B_FN = ('void GcodeSuite::M999() {\n'
        '  // SV04 NEXT C9: ein Neustart nach dem Stopp-Zustand (z. B. nach einem BLTouch-stop()) darf KEINE Sicherheitsfreigabe erzeugen: X/Y/Z muessen erneut referenziert (und damit bestaetigt) werden.\n'
        '  // Ausserhalb des Stopp-Zustands bleibt M999 unveraendert. Die Warteschlange wird nicht geleert (RingBuffer-Laengenzaehler, siehe apply_m999_reset_c9.py).\n'
        '  #ifndef SV04_CLAUDE_M999_REHOME_REQUIRED\n    #define SV04_CLAUDE_M999_REHOME_REQUIRED 1\n  #endif\n'
        '  #if SV04_CLAUDE_M999_REHOME_REQUIRED\n    const bool sv04c9_was_stopped = IsStopped();\n  #endif\n'
        '  marlin_state = MF_RUNNING;\n  ui.reset_alert_level();\n'
        '  #if SV04_CLAUDE_M999_REHOME_REQUIRED\n    if (sv04c9_was_stopped) {\n      set_all_unhomed();\n      SERIAL_ECHO_MSG("SV04 C9: restart after STOPPED state, axes are now UNHOMED: home (G28) and re-check before Auto60, G29 or a tool change");\n    }\n  #endif\n')


def transform(raw, check_pin=True):
    s = raw.decode('utf-8')
    if MARK in s:
        if s.count(B_FN) != 1 or s.count(B_INC) != 1:
            raise ValueError('M999.cpp ist halb oder doppelt gepatcht')
        return raw, False
    h = hashlib.sha256(raw).hexdigest()
    if check_pin and h != PIN_OEM_M999:
        raise ValueError('M999.cpp entspricht NICHT dem OEM-Original (sha256 %s statt %s): kein Patch' % (h, PIN_OEM_M999))
    for a in (A_INC, A_FN):
        if s.count(a) != 1:
            raise ValueError('Anker %d mal vorhanden (erwartet 1): %r' % (s.count(a), a[:60]))
    return s.replace(A_INC, B_INC).replace(A_FN, B_FN).encode('utf-8'), True


def main(argv):
    if len(argv) != 2:
        print(__doc__); return 2
    p = Path(argv[1]) / TARGET
    new, ch = transform(p.read_bytes())
    if ch:
        p.write_bytes(new)
    print('M999_C9=' + ('PATCHED' if ch else 'ALREADY_PATCHED'), p, 'sha256', hashlib.sha256(p.read_bytes()).hexdigest())
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
