# Integrationsempfehlung für ChatGPT (C9 auf 318)

**318 nicht überschreiben.** C9 ändert **eine** OEM-Datei und berührt keine Datei, die ChatGPT für EEPROM, DWIN, M420 oder Planner pflegt.

1. Auf der neuen Kopie `oem318` (aus `integrate_318_strict.py`): `python3 02_PATCHES/apply_m999_reset_c9.py oem_c9` auf einer **Kopie** von `oem318`. Das Skript pinnt den OEM-Hash der `M999.cpp` (`f778002d…`, in 309 und 318 unverändert), ist idempotent und bricht bei fremder Datei ohne Schreiben ab.
2. **Konflikte:** keine bekannt. Falls ChatGPT `M999.cpp` ändert, bricht das Skript mit dem tatsächlichen Hash ab; dann die 15 Zeilen (`02_PATCHES/diffs/M999_OEM_nach_C9.diff`) von Hand einarbeiten.
3. **Build:** `claude_c9_stm32_no_flash.yml` (Baseline 318 und `oem_c9`, beide Profile). Den Auswertungsjob unverändert benutzen (`evaluate_builds_c9.py`, liest `oem`/`oem318`/`oem_c9`).
4. **Entscheidung für ChatGPT:** Soll `SV04_CLAUDE_M999_REHOME_REQUIRED` Standard 1 bleiben (empfohlen)? Und soll die DWIN-Anzeige die Zeilen aus `STATUS_SCHNITTSTELLE_C9.md` abbilden?
5. **Reihenfolge der Regression:** 315-Tests (unverändert, mit Negativkontrollen) und meine Suite (`python3 run_tests.py`) nach dem Einarbeiten erneut ausführen.
6. **Nicht integrieren:** eine `M605`-Sperre (bricht die Wiederaufnahme nach Stromausfall).
