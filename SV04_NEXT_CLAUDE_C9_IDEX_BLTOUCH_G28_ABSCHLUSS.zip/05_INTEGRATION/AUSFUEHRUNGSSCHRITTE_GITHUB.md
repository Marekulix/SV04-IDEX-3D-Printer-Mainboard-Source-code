# Ausführungsschritte für den GitHub-Lauf (C9) – nicht von mir ausgeführt

Im Repository-Stamm liegen bereits (aus dem erfolgreichen Lauf): `SV04_NEXT_318_GITHUB_UPLOAD_06.zip`. Neu hinzukommen:
1. `SV04_NEXT_CLAUDE_C9_IDEX_BLTOUCH_G28_ABSCHLUSS.zip` (Hash im Workflow fest eingetragen; vorher `sha256sum` vergleichen).
2. Workflow `.github/workflows/claude_c9_stm32_no_flash.yml` (Inhalt der gleichnamigen Datei einfügen) → Commit.
3. *Actions* → Workflow wählen → *Run workflow*.
4. Artefakte laden und mir geben: `SV04_C9_BASELINE_318_STM32_LOGS_NO_FLASH`, `SV04_C9_CHANGED_STM32_LOGS_NO_FLASH`, `SV04_C9_EVALUATION`.
Der Auswertungsjob ist nur grün, wenn **alle vier** Kombinationen (318 und C9-Kopie, je beide Profile) belegt PASS sind. Bei einem Fehler genügen mir `errors.txt` und `build.log` des Profils.
