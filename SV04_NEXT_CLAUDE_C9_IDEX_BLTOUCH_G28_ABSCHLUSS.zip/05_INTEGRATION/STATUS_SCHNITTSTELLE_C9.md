# Schnittstelle und Fehlerstatus für ChatGPTs DWIN (nur Beschreibung, kein neuer Adaptercode)

Alle Meldungen stammen aus bestehenden, getesteten Stellen; C9 fügt genau **eine** Meldung hinzu. **Die Anzeige je Reason am Display ist ChatGPTs Aufgabe; das HMI-Projekt fehlt, eine Anzeige ist deshalb nirgends belegt.**

## Zustände und der Weg zurück
| Zustand | Auto60 | Meldung (seriell) | Weg zurück |
|---|---|---|---|
| BLTouch-Fehler → `stop()` | `MARLIN_STOPPED` (64) | `STOP called because of BLTouch error - restart with M999` (OEM) | Ursache beseitigen; Aus-/Einschalten oder `M999`; **danach `G28` von Hand** |
| Neustart aus dem Stopp-Zustand (C9) | `PRE_Z_UNKNOWN` (65) | `SV04 C9: restart after STOPPED state, axes are now UNHOMED: …` | `G28`; danach prüft Auto60 alles neu |
| Z nicht referenziert/vertrauenswürdig | `PRE_Z_UNKNOWN` (65) | `Auto60 refused: PRE_Z_UNKNOWN` | `G28` (Hand am Not-Aus) |
| Homing-Fehler im Lauf | `HOME_FAILED` (24) | Fehlerseite 28 | Ursache beheben, `G28`, erneut starten |
| falsches Werkzeug | `PRE_WRONG_EXTRUDER` (7) | `Auto60 refused: …` | `G28` mit T0 |
| IDEX-Modus nicht `FULL_CONTROL`/`AUTO_PARK` oder Duplikation läuft | `PRE_IDEX_MODE` (8) | `Auto60 refused: …` | Modus wechseln, `G28 X` |
| manuelle G29 im Stopp-Zustand | – | `SV04 C5: G29 refused, printer is in STOPPED state …` | Neustart, `G28` |
| T1 bei nicht vertrauenswürdigem X | – | `SV04: T1 abgelehnt` (C2) | `G28 X` |

Die vollständige Reason-Tabelle mit allen Zahlenwerten aus dem echten Kern: `04_ROHLOGS/56_reason_tabelle_vollstaendig.txt` (neue Werte stehen am Ende, alle früheren sind unverändert).

## Regeln, auf die sich die Anzeige verlassen kann
* Ein kritischer Fehler setzt sich nicht von selbst zurück: Der Weg führt immer über **Ursache beseitigen → Neustart → erneute Referenzierung → vollständige Auto60-Prüfung**.
* Ein Neustart allein erzeugt keine Freigabe (RAM-Zustand der Referenzierung; nach Stopp zusätzlich durch C9).
* Auto60 schreibt nie in das EEPROM, wenn die Messung nicht vollständig validiert wurde (EEPROM-Kette von ChatGPT unverändert).
