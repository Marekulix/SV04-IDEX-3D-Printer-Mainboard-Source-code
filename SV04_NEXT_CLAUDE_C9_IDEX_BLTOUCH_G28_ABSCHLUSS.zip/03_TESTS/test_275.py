import unittest
from apply_275 import patch
class TestP275(unittest.TestCase):
 def setUp(self):
  self.original='SV04_NEXT_P1_268 sv04_p1_z_completed\n      bool sv04_t1_homed_this_g28 = false;\n      sv04_p1_t1_x_completed = false;\n          if (sv04_z_homed) probe.move_z_after_homing();\n  TERN_(RTS_AVAILABLE, RTS_MoveAxisHoming());\n  TERN_(EXTENSIBLE_UI, ExtUI::onHomingComplete());'
 def test_failure_flag(self):self.assertIn('bool sv04_p1_z_failed = false;',patch(self.original))
 def test_failure_branch(self):self.assertIn('else sv04_p1_z_failed = true;',patch(self.original))
 def test_failure_does_not_report_success(self):
  s=patch(self.original);branch=s.split('if (sv04_p1_z_failed) {',1)[1].split('else {',1)[0]
  self.assertNotIn('RTS_MoveAxisHoming()',branch)
  self.assertNotIn('onHomingComplete()',branch)
 def test_success_still_reports(self):
  s=patch(self.original);self.assertIn('else {\n      TERN_(RTS_AVAILABLE, RTS_MoveAxisHoming());',s)
 def test_missing_anchor_fails(self):
  with self.assertRaises(ValueError):patch(self.original.replace('if (sv04_z_homed)','if (home_ok)'))
 def test_duplicate_anchor_fails(self):
  with self.assertRaises(ValueError):patch(self.original+'\n  TERN_(RTS_AVAILABLE, RTS_MoveAxisHoming());\n  TERN_(EXTENSIBLE_UI, ExtUI::onHomingComplete());')
 def test_reapply_fails(self):
  with self.assertRaises(ValueError):patch(patch(self.original))
 def test_status_is_diagnostic_only(self): self.assertNotIn('FLASH_ALLOWED=YES',patch(self.original))
if __name__=='__main__':unittest.main()
