# SV04 NEXT 276 – P1 IDEX + BLTouch: gebündelte Homing-Fehlerbehandlung

## Quellen / Baseline
- OEM: `Sovol3d/SV04-IDEX-3D-Printer-Mainboard-Source-code`, Commit `1867fcba75354a5c65e0631d6972dd19f1bd6cbe` (unverändert).
- Bisherige Patch-Kette: 268 → 272 → 274 → 275. 275 STM32 BUILD_EXIT=0; 42 lokale Tests bestanden.
- 276 erweitert nur Punkt 1 und ist bis zum separaten GitHub-Build nicht als fertige Integration zu bewerten.

## Konkrete Änderungen in 276
1. `motion.h`: T0-X-Abschlussflag zusätzlich zu T1-X und Z.
2. `motion.cpp`: T0-Abschlussflag nur beim Durchlaufen des Endes von `homeaxis(X_AXIS)` mit aktivem T0 setzen, zusätzlich zur bestehenden T1- und Z-Abschlusslogik. Alle Flags werden vor G28 zurückgesetzt.
3. `G28.cpp`: Z-Homing-Gate verlangt sowohl die aktuelle T1-X-Bestätigung als auch die abgeschlossene T0-X-Referenzfahrt.
4. Bei fehlgeschlagener T1-X-Referenzfahrt T0-X-Bewegung nicht beginnen; bei fehlgeschlagenem T0-X-Homing den Zustand nicht als geparkt melden.
5. Bei fehlgeschlagenem X- oder Z-Homing keine erneute IDEX-Duplikations-/Mirror-Referenzfahrt, kein SD-Sonderzweig, keine Wiederaktivierung von Leveling, keine Werkzeugrückstellung und keine normale DWIN-/ExtUI-Erfolgsmeldung.
6. OEM-Anker müssen exakt einmal vorkommen; sonst wird der Patchvorgang abgebrochen. Keine Änderung an EEPROM, M500, G29 oder an Claudes Arbeitspaketen.

## Testlage
- 57 Python-Tests lokal bestanden (42 vorherige + 15 neue Struktur-/Fehlerpfadprüfungen).
- Ein Test beweist **nicht** die physische Parkposition, die Reaktion der Endschalter, die tatsächliche BLTouch-Erkennung oder die sichere Bewegung beider Wagen.
- Punkt 1 bleibt bis zum bestätigten Gesamtbuild bei 55 % (Entwicklungsschätzung). Keine Flashfreigabe.

## Bekannte Restrisiken / Teststrategie
- `homeaxis()` gibt im OEM `void` zurück; die Abschlussflags sind nur Firmware-Evidenz, keine unabhängige Endschalterprüfung. Insbesondere können Verkabelungs-/Endschalterfehler ohne Hardware nicht nachgewiesen werden.
- `G28 Z` allein wird bewusst weiterhin verweigert, weil dieser Schutz eine neue X-Referenzierung innerhalb desselben G28-Aufrufs verlangt. Das ist ein bewusstes Kompatibilitätsrisiko und muss vor Freigabe auf dem Gerät beurteilt werden.
- Die vier IDEX-Modi FULL_CONTROL, AUTO_PARK, DUPLICATION und MIRRORED wurden nur anhand des OEM-Codes untersucht. Keine Bewegungsprüfung erfolgt.
- GitHub-Workflow führt Tests, OEM-Patchkette und STM32-Gesamtbuild aus. Er publiziert keine installierbare Firmware.

## Für die sichere Hardwarevalidierung nach fachlicher Prüfung
1. Funktion des T1-Endschalters separat verifizieren und tatsächliche T1-Parkposition mit geeigneten Mitteln bestätigen.
2. BLTouch-Eigen- und Alarmsignalprüfung bei stillstehenden Achsen; korrekte Abbruchmeldung prüfen.
3. Alle vier IDEX-Betriebsarten separat mit abgestimmten Bewegungsgrenzen testen; dabei Fehlerfälle ohne gefährliche Bewegungen erfassen.
4. Erfolgreiches und absichtlich fehlgeschlagenes Homing in der DWIN-/Host-Ausgabe vergleichen. Keine Erfolgsmeldung und keine Folgebewegung bei Fehler.
5. Keine Firmware installieren, solange die fachliche Freigabe und ein geeigneter Rücksetzweg fehlen.
