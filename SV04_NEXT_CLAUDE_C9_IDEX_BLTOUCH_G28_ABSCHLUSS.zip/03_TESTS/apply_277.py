#!/usr/bin/env python3
"""SV04 NEXT 277: Gesamt-Patch auf einem OEM-Baum, der bereits die Kette 268/272/274/275/276 (ChatGPT, unveraendert) enthaelt. NUR Build/Diagnose, KEIN Flash.

  --profile p1          Profil (a): 276 + P1-Korrekturen (apply_277_p1.py)  [Stufe 1]
  --profile integrated  Profil (b): Stufe 1 + Claude-Auto60 mit PRODUKTIONS-Backend (G29/LCD/gcode/G28-Waechter + neue Dateien)  [Stufe 1 + 2]

Stufe 2 benutzt claude/02_SOURCE und claude/03_PATCHES/apply_claude_parallel.py (kopierend, fail-closed: jeder Anker genau einmal, alles oder nichts). Die Eingabedateien G29.cpp/LCD_RTS.cpp/gcode.cpp
muessen PRISTINE OEM sein (ein zweites Anwenden wird abgelehnt). Kein Test-Double wird installiert.
Aufruf: apply_277.py --root oem --profile integrated [--report patch277_report.json]"""
import argparse
import hashlib
import json
import shutil
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
CLAUDE = HERE / 'claude'
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(CLAUDE / '03_PATCHES'))

REL = {'lcd': 'Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp', 'g29': 'Marlin/src/gcode/bedlevel/abl/G29.cpp', 'gcode': 'Marlin/src/gcode/gcode.cpp', 'g28': 'Marlin/src/gcode/calibrate/G28.cpp'}


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def apply(root, profile):
    import apply_277_p1 as p1
    root = Path(root)
    touched = {}
    before = {}
    watch = ['Marlin/src/module/motion.h', 'Marlin/src/module/motion.cpp', *REL.values()]
    for rel in watch:
        if (root / rel).is_file():
            before[rel] = sha(root / rel)
    p1.apply(root)
    if profile == 'integrated':
        import apply_claude_parallel as P
        out = Path(tempfile.mkdtemp(prefix='sv04_277_'))
        try:
            P.run(root / REL['lcd'], root / REL['g29'], root / REL['gcode'], out, CLAUDE / '02_SOURCE', g28=root / REL['g28'])
            for f in sorted(out.rglob('*')):
                if f.is_file():
                    dst = root / f.relative_to(out)
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(f, dst)
        finally:
            shutil.rmtree(out, ignore_errors=True)
    for rel in sorted(set(watch) | {str(p.relative_to(root)) for p in root.rglob('sv04_claude_*')}):
        f = root / rel
        if f.is_file():
            touched[rel] = {'sha256_before': before.get(rel), 'sha256_after': sha(f)}
    return touched


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--root', type=Path, required=True)
    ap.add_argument('--profile', choices=('p1', 'integrated'), required=True)
    ap.add_argument('--report', type=Path)
    a = ap.parse_args(argv)
    try:
        t = apply(a.root, a.profile)
    except Exception as e:                                     # fail-closed: nichts Teilweises
        print('PATCH 277 ABGELEHNT:', type(e).__name__, e, file=sys.stderr)
        return 3
    rep = {'tool': 'apply_277.py', 'profile': a.profile, 'flash_allowed': False, 'hardware_tested': False, 'files': t}
    if a.report:
        a.report.write_text(json.dumps(rep, indent=1))
    print('P277_%s_APPLIED files=%d; FLASH_ALLOWED=NO' % (a.profile.upper(), len(t)))
    return 0


if __name__ == '__main__':
    sys.exit(main())
