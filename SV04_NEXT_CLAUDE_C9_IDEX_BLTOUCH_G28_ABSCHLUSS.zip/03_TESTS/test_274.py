import unittest
from apply_274 import patch_motion_h,patch_motion_cpp,patch_g28

class P274(unittest.TestCase):
 def setUp(self):
  self.h='  extern float inactive_extruder_x,                 // Used in mode 0 & 1'
  self.cpp='  float inactive_extruder_x              = X2_MAX_POS,                    // Used in mode 0 & 1\n    if (DEBUGGING(LEVELING)) DEBUG_ECHOLNPGM("<<< homeaxis(", AS_CHAR(AXIS_CHAR(axis)), ")");\n\n  } // homeaxis()'
  self.g='SV04_NEXT_P1_268\nx_home_pos(1)\n      bool sv04_t1_homed_this_g28 = false;\n          sv04_t1_homed_this_g28 = axis_is_trusted(X_AXIS)\n            && (fabsf(inactive_extruder_x - x_home_pos(1)) <= 1.0f);\n      homeaxis(Z_AXIS);\n      return axis_is_trusted(Z_AXIS);'
 def test_declaration(self): self.assertIn('extern bool sv04_p1_t1_x_completed',patch_motion_h(self.h))
 def test_definitions(self): self.assertIn('bool sv04_p1_t1_x_completed = false',patch_motion_cpp(self.cpp))
 def test_x_tail(self):self.assertIn('active_extruder == 1',patch_motion_cpp(self.cpp))
 def test_z_tail(self):self.assertIn('sv04_p1_z_completed = axis_is_trusted(Z_AXIS)',patch_motion_cpp(self.cpp))
 def test_reset(self):self.assertIn('sv04_p1_z_completed = false;',patch_g28(self.g))
 def test_t1_gate(self):self.assertIn('sv04_t1_homed_this_g28 = sv04_p1_t1_x_completed',patch_g28(self.g))
 def test_z_gate(self):self.assertIn('return sv04_p1_z_completed && axis_is_trusted(Z_AXIS)',patch_g28(self.g))
 def test_duplicate_rejected(self):
  with self.assertRaises(ValueError):patch_motion_h(self.h+'\n'+self.h)
 def test_missing_anchor_rejected(self):
  with self.assertRaises(ValueError):patch_g28('SV04_NEXT_P1_268 x_home_pos(1)')
 def test_second_application_rejected(self):
  with self.assertRaises(ValueError):patch_g28(patch_g28(self.g))

if __name__=='__main__':unittest.main()
