#!/usr/bin/env python3
"""SV04 P1: guarded per-call homing completion evidence, applied after 268+272 patches.
Only a diagnostic integration candidate: does not establish physical parking.
"""
import argparse
from pathlib import Path

def single(src, old, new, label):
    count=src.count(old)
    if count!=1: raise ValueError(f'{label}: expected unique anchor, got {count}')
    return src.replace(old,new,1)

def patch_motion_h(src):
    anchor='''  extern float inactive_extruder_x,                 // Used in mode 0 & 1'''
    replacement='''  // SV04_NEXT_P1_274: ephemeral completion evidence from homeaxis() tail.
  // Not a physical position sensor and never persisted to EEPROM.
  #if ENABLED(BLTOUCH) && ENABLED(Z_SAFE_HOMING)
    extern bool sv04_p1_t1_x_completed, sv04_p1_z_completed;
  #endif
  extern float inactive_extruder_x,                 // Used in mode 0 & 1'''
    return single(src,anchor,replacement,'motion.h declarations')

def patch_motion_cpp(src):
    anchor='''  float inactive_extruder_x              = X2_MAX_POS,                    // Used in mode 0 & 1'''
    replacement='''  // SV04_NEXT_P1_274: reset per G28. Set true only after homeaxis() runs to end.
  #if ENABLED(BLTOUCH) && ENABLED(Z_SAFE_HOMING)
    bool sv04_p1_t1_x_completed = false, sv04_p1_z_completed = false;
  #endif
  float inactive_extruder_x              = X2_MAX_POS,                    // Used in mode 0 & 1'''
    src=single(src,anchor,replacement,'motion.cpp definitions')
    anchor='''    if (DEBUGGING(LEVELING)) DEBUG_ECHOLNPGM("<<< homeaxis(", AS_CHAR(AXIS_CHAR(axis)), ")");

  } // homeaxis()'''
    replacement='''    // SV04_NEXT_P1_274: only reaches here if BLTouch deploy/stow and
    // other early-return checks did not abort homeaxis().
    #if ENABLED(DUAL_X_CARRIAGE) && ENABLED(BLTOUCH) && ENABLED(Z_SAFE_HOMING)
      if (axis == X_AXIS && active_extruder == 1) sv04_p1_t1_x_completed = axis_is_trusted(X_AXIS);
      if (axis == Z_AXIS) sv04_p1_z_completed = axis_is_trusted(Z_AXIS);
    #endif
    if (DEBUGGING(LEVELING)) DEBUG_ECHOLNPGM("<<< homeaxis(", AS_CHAR(AXIS_CHAR(axis)), ")");

  } // homeaxis()'''
    return single(src,anchor,replacement,'homeaxis completion tail')

def patch_g28(src):
    if 'SV04_NEXT_P1_268' not in src or 'x_home_pos(1)' not in src: raise ValueError('Requires exact previous patch lineage')
    anchor='''      bool sv04_t1_homed_this_g28 = false;'''
    replacement='''      bool sv04_t1_homed_this_g28 = false;
      sv04_p1_t1_x_completed = false;
      sv04_p1_z_completed = false;'''
    src=single(src,anchor,replacement,'G28 reset')
    anchor='''          sv04_t1_homed_this_g28 = axis_is_trusted(X_AXIS)
            && (fabsf(inactive_extruder_x - x_home_pos(1)) <= 1.0f);'''
    replacement='''          sv04_t1_homed_this_g28 = sv04_p1_t1_x_completed
            && axis_is_trusted(X_AXIS)
            && (fabsf(inactive_extruder_x - x_home_pos(1)) <= 1.0f);'''
    src=single(src,anchor,replacement,'G28 T1 evidence')
    anchor='''      homeaxis(Z_AXIS);
      return axis_is_trusted(Z_AXIS);'''
    replacement='''      #if ENABLED(DUAL_X_CARRIAGE) && ENABLED(BLTOUCH)
        sv04_p1_z_completed = false;
      #endif
      homeaxis(Z_AXIS);
      #if ENABLED(DUAL_X_CARRIAGE) && ENABLED(BLTOUCH)
        return sv04_p1_z_completed && axis_is_trusted(Z_AXIS);
      #else
        return axis_is_trusted(Z_AXIS);
      #endif'''
    return single(src,anchor,replacement,'G28 BLTouch completion')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);a=ap.parse_args()
    specs=[('Marlin/src/module/motion.h',patch_motion_h),('Marlin/src/module/motion.cpp',patch_motion_cpp),('Marlin/src/gcode/calibrate/G28.cpp',patch_g28)]
    updated=[]
    for rel,fn in specs:
        p=a.root/rel
        if not p.is_file(): raise FileNotFoundError(p)
        updated.append((p,fn(p.read_text(encoding='utf-8'))))
    # Validate all before any changes; no double apply.
    for p,s in updated: p.write_text(s,encoding='utf-8',newline='')
    print('SV04_P1_274_APPLIED files=3 FLASH=NO')
if __name__=='__main__': main()
