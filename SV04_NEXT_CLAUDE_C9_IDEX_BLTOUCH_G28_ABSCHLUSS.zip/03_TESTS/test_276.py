import unittest
from apply_276 import patch_header,patch_motion,patch_g28

class P276Tests(unittest.TestCase):
    def setUp(self):
        self.h='extern bool sv04_p1_t1_x_completed, sv04_p1_z_completed;'
        self.m='''bool sv04_p1_t1_x_completed = false, sv04_p1_z_completed = false;
if (axis == X_AXIS && active_extruder == 1) sv04_p1_t1_x_completed = axis_is_trusted(X_AXIS);'''
        self.g='''SV04_NEXT_P1_275
      bool sv04_p1_z_failed = false;
      sv04_p1_t1_x_completed = false;
      sv04_p1_z_completed = false;
        && active_extruder == 0
        && !idex_is_duplicating()
          sv04_t1_homed_this_g28 = sv04_p1_t1_x_completed
            && axis_is_trusted(X_AXIS)
            && (fabsf(inactive_extruder_x - x_home_pos(1)) <= 1.0f);
        // Home the 1st (left) extruder
        active_extruder = 0;
        homeaxis(X_AXIS);

        // Consider the active extruder to be in its "parked" position
        idex_set_parked();
  #if ENABLED(DUAL_X_CARRIAGE)

    if (idex_is_duplicating()) {
    else if((save_dual_x_carriage_mode == 4) && card.isPrinting()){
  TERN_(CAN_SET_LEVELING_AFTER_G28, if (leveling_restore_state) set_bed_leveling_enabled());
    tool_change(old_tool_index, TERN(PARKING_EXTRUDER, !pe_final_change_must_unpark, DISABLED(DUAL_X_CARRIAGE)));   // Do move if one of these
    if (sv04_p1_z_failed) {
      SERIAL_ERROR_MSG("SV04 P1 275: G28 Z failed; homing NOT complete");'''
    def test_h_declaration(self): self.assertIn('sv04_p1_t0_x_completed',patch_header(self.h))
    def test_m_definition(self): self.assertIn('sv04_p1_t0_x_completed = false',patch_motion(self.m))
    def test_m_evidence(self): self.assertIn('active_extruder == 0) sv04_p1_t0_x_completed = axis_is_trusted(X_AXIS)',patch_motion(self.m))
    def test_per_g28_reset(self): self.assertIn('sv04_p1_t0_x_completed = false;',patch_g28(self.g))
    def test_z_requires_t0(self): self.assertIn('&& sv04_p1_t0_x_completed',patch_g28(self.g))
    def test_t1_failure_report(self): self.assertIn('if (!sv04_t1_homed_this_g28) sv04_p1_x_failed = true;',patch_g28(self.g))
    def test_t0_failure_report(self): self.assertIn('if (!sv04_p1_t0_x_completed) sv04_p1_x_failed = true;',patch_g28(self.g))
    def test_duplication_failure_block(self): self.assertIn('if (!sv04_p1_any_failed && idex_is_duplicating())',patch_g28(self.g))
    def test_special_mode_failure_block(self): self.assertIn('else if(!sv04_p1_any_failed',patch_g28(self.g))
    def test_leveling_failure_block(self):
        p=patch_g28(self.g)
        self.assertIn('if (!sv04_p1_any_failed)\n      TERN_',p)
    def test_tool_failure_block(self):
        p=patch_g28(self.g)
        self.assertIn('if (!sv04_p1_any_failed)\n    #endif\n        tool_change',p)
    def test_ui_failure_block(self): self.assertIn('if (sv04_p1_any_failed) {',patch_g28(self.g))
    def test_duplicate_guard(self):
        with self.assertRaises(ValueError):patch_g28(self.g+self.g)
    def test_idempotence_rejected(self):
        with self.assertRaises(ValueError):patch_g28(patch_g28(self.g))
    def test_no_untested_changes(self):
        p=patch_g28(self.g)
        self.assertNotIn('M500',p)
        self.assertNotIn('FLASH_ALLOWED=YES',p)

if __name__=='__main__':unittest.main()
