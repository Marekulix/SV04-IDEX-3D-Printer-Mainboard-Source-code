#!/usr/bin/env python3
"""SV04 NEXT 277 Stufe 1 (P1 IDEX + BLTouch): Haertung des Standes 276. Anwendung NACH 268/272/274/275/276 auf die gepinnten OEM-Dateien. Nur Diagnose/Build, KEIN Flash.

Behebt in 276 nachgewiesene Fehlerzustaende (Beleg: Analyse am echten Quelltext, siehe docs/ANALYSE_276_BEFUNDE.md):
 F1 nach gescheitertem Z-Homing blieb Z als homed+trusted markiert (homeaxis() ruft set_axis_is_at_home() VOR probe.stow()).
 F2 nach gescheitertem X-Homing blieb X als homed+trusted markiert; ausserdem lief Y-Homing weiter.
 F3 die T1-Positionspruefung |inactive_extruder_x - x_home_pos(1)| ist nach homeaxis() tautologisch; ergaenzt um eine Plausibilitaet gegen die Achsgrenzen (nur Software, KEIN physischer Beleg).
 F4 es gab keinen exportierten Ergebnisstatus je G28: jetzt sv04_p1_g28_result, auf JEDEM Austrittspfad festgeschrieben (Voraussetzung fuer das Auto60-Backend und die Auswertung des G29-Endskripts G28 XY).
 Option: SV04_P1_Z_ONLY_REHOMES_X (Standard 0 = unveraendert: G28 Z allein bleibt verweigert, wie in 276).
"""
import argparse
from pathlib import Path

MARK = 'SV04_NEXT_P1_277'


def once(s, old, new, desc):
    n = s.count(old)
    if n != 1:
        raise ValueError(f'{desc}: expected exactly one anchor, got {n}')
    return s.replace(old, new, 1)


def patch_header(s):
    if MARK in s:
        raise ValueError('motion.h already patched (277)')
    if 'sv04_p1_t0_x_completed' not in s:
        raise ValueError('motion.h: requires the 276 lineage')
    s = once(s, '#pragma once\n', f'''#pragma once

// {MARK}: default OFF = G28 Z alone stays refused exactly as in 276. 1 = G28 Z first re-homes X (T1, then T0) inside the SAME call, so the gate has fresh evidence.
#ifndef SV04_P1_Z_ONLY_REHOMES_X
  #define SV04_P1_Z_ONLY_REHOMES_X 0
#endif
''', 'motion.h pragma')
    return once(s, '    extern bool sv04_p1_t1_x_completed, sv04_p1_t0_x_completed, sv04_p1_z_completed;\n',
f'''    extern bool sv04_p1_t1_x_completed, sv04_p1_t0_x_completed, sv04_p1_z_completed;
    // {MARK}: per-G28 result, committed on EVERY G28 exit (see G28.cpp). SOFTWARE evidence only, never a physical position proof.
    struct sv04_p1_g28_result_t {{
      uint32_t seq;                              // incremented by EVERY G28, also skipped ones; written LAST
      bool completed;                            // G28 ran to its end (false: early return, no homing)
      bool ok;                                   // completed && no X/Z failure
      bool x_attempted, t1_ok, t0_ok;            // X homing attempted / T1 completed + plausible / T0 completed
      bool z_attempted, z_ok;                    // Z homing attempted / Z completed after BLTouch deploy+stow
    }};
    extern sv04_p1_g28_result_t sv04_p1_g28_result;
    bool sv04_p1_t1_home_plausible();
''', 'motion.h declarations')


def patch_motion(s):
    if MARK in s:
        raise ValueError('motion.cpp already patched (277)')
    s = once(s, '    bool sv04_p1_t1_x_completed = false, sv04_p1_t0_x_completed = false, sv04_p1_z_completed = false;\n',
f'''    bool sv04_p1_t1_x_completed = false, sv04_p1_t0_x_completed = false, sv04_p1_z_completed = false;
    // {MARK}
    sv04_p1_g28_result_t sv04_p1_g28_result = {{ 0, false, false, false, false, false, false, false }};
''', 'motion.cpp result definition')
    return once(s, '      return hotend_offset[1].x > 0 ? hotend_offset[1].x : X2_HOME_POS;\n  }\n',
f'''      return hotend_offset[1].x > 0 ? hotend_offset[1].x : X2_HOME_POS;
  }}

  // {MARK}: after homeaxis() the check "inactive_extruder_x == x_home_pos(1)" is TAUTOLOGICAL (set_axis_is_at_home() assigns exactly that value).
  // This is the only independent SOFTWARE-side check: the T1 reference (also after an M218 override) must lie inside the second carriage's configured
  // travel and to the right of the first carriage's home. NOT a physical position proof and NOT a collision proof.
  #if ENABLED(BLTOUCH) && ENABLED(Z_SAFE_HOMING)
    bool sv04_p1_t1_home_plausible() {{
      const float hx = x_home_pos(1);
      return !isnan(hx) && !isnan(inactive_extruder_x)
          && hx >= float(X2_MIN_POS) && hx <= float(X2_MAX_POS) && hx > x_home_pos(0)
          && inactive_extruder_x >= float(X2_MIN_POS) && inactive_extruder_x <= float(X2_MAX_POS);
    }}
  #endif
''', 'motion.cpp plausibility')


def patch_g28(s):
    if MARK in s:
        raise ValueError('G28.cpp already patched (277)')
    if 'SV04_NEXT_P1_276' not in s or 'sv04_p1_x_failed' not in s:
        raise ValueError('G28.cpp: requires the 276 lineage')
    s = once(s, '      sv04_p1_t0_x_completed = false;\n      sv04_p1_z_completed = false;\n    #endif\n',
f'''      sv04_p1_t0_x_completed = false;
      sv04_p1_z_completed = false;
      // {MARK}: per-G28 result, committed on EVERY exit path of this G28 (early return and normal end; kill() never returns).
      bool sv04_p1_x_attempted = false, sv04_p1_t1_ok = false, sv04_p1_t0_ok = false, sv04_p1_z_attempted = false, sv04_p1_z_ok = false, sv04_p1_g28_end = false;
      struct Sv04P1Commit {{
        const bool &end_, &xf_, &zf_, &xa_, &t1_, &t0_, &za_, &zo_;
        Sv04P1Commit(const bool &e, const bool &xf, const bool &zf, const bool &xa, const bool &t1, const bool &t0, const bool &za, const bool &zo)
          : end_(e), xf_(xf), zf_(zf), xa_(xa), t1_(t1), t0_(t0), za_(za), zo_(zo) {{}}
        ~Sv04P1Commit() {{
          sv04_p1_g28_result.completed = end_;
          sv04_p1_g28_result.ok = end_ && !xf_ && !zf_;
          sv04_p1_g28_result.x_attempted = xa_; sv04_p1_g28_result.t1_ok = t1_; sv04_p1_g28_result.t0_ok = t0_;
          sv04_p1_g28_result.z_attempted = za_; sv04_p1_g28_result.z_ok = zo_;
          ++sv04_p1_g28_result.seq;            // LAST: a reader that sees the new seq sees a complete record
        }}
      }} sv04_p1_commit(sv04_p1_g28_end, sv04_p1_x_failed, sv04_p1_z_failed, sv04_p1_x_attempted, sv04_p1_t1_ok, sv04_p1_t0_ok, sv04_p1_z_attempted, sv04_p1_z_ok);
    #endif
''', 'G28 result commit')
    s = once(s, '''          sv04_t1_homed_this_g28 = sv04_p1_t1_x_completed
            && axis_is_trusted(X_AXIS)
            && (fabsf(inactive_extruder_x - x_home_pos(1)) <= 1.0f);
          if (!sv04_t1_homed_this_g28) sv04_p1_x_failed = true;''',
f'''          sv04_p1_x_attempted = true;
          sv04_t1_homed_this_g28 = sv04_p1_t1_x_completed
            && axis_is_trusted(X_AXIS)
            && sv04_p1_t1_home_plausible()   // {MARK}: the next comparison alone is tautological
            && (fabsf(inactive_extruder_x - x_home_pos(1)) <= 1.0f);
          sv04_p1_t1_ok = sv04_t1_homed_this_g28;
          if (!sv04_t1_homed_this_g28) sv04_p1_x_failed = true;''', 'T1 evidence')
    s = once(s, '            if (!sv04_p1_t0_x_completed) sv04_p1_x_failed = true;\n',
             '            if (!sv04_p1_t0_x_completed) sv04_p1_x_failed = true;\n            sv04_p1_t0_ok = sv04_p1_t0_x_completed;\n', 'T0 evidence')
    s = once(s, '''    // Home Y (after X)
    if (DISABLED(HOME_Y_BEFORE_X) && doY)
      homeaxis(Y_AXIS);''',
f'''    // Home Y (after X). {MARK}: not after a failed X homing (no further axis motion on a failed/unknown X state).
    if (DISABLED(HOME_Y_BEFORE_X) && doY
      #if ENABLED(DUAL_X_CARRIAGE) && ENABLED(BLTOUCH) && ENABLED(Z_SAFE_HOMING)
        && !sv04_p1_x_failed
      #endif
    ) homeaxis(Y_AXIS);''', 'Y homing gate')
    s = once(s, '            const bool sv04_z_homed = home_z_safely(sv04_t1_homed_this_g28);\n',
             '            sv04_p1_z_attempted = true;\n            const bool sv04_z_homed = home_z_safely(sv04_t1_homed_this_g28);\n            sv04_p1_z_ok = sv04_z_homed;\n', 'Z result')
    s = once(s, '  TERN_(FULL_REPORT_TO_HOST_FEATURE, set_and_report_grblstate(M_IDLE));\n',
f'''  TERN_(FULL_REPORT_TO_HOST_FEATURE, set_and_report_grblstate(M_IDLE));
  #if ENABLED(DUAL_X_CARRIAGE) && ENABLED(BLTOUCH) && ENABLED(Z_SAFE_HOMING)
    sv04_p1_g28_end = true;                    // {MARK}: reached only if the whole G28 ran to its end
  #endif
''', 'G28 end marker')
    s = once(s, '''    if (sv04_p1_any_failed) {
      SERIAL_ERROR_MSG("SV04 P1 276: X or Z homing failed; completion refused");''',
f'''    if (sv04_p1_any_failed) {{
      // {MARK}: a failed X attempt must not leave X marked homed/trusted (T1 may have set the shared X flags before T0 failed).
      if (sv04_p1_x_failed) {{ set_axis_unhomed(X_AXIS); set_axis_untrusted(X_AXIS); }}
      SERIAL_ERROR_MSG("SV04 P1 276: X or Z homing failed; completion refused");''', 'X trust revocation')
    s = once(s, '''      homeaxis(Z_AXIS);
      #if ENABLED(DUAL_X_CARRIAGE) && ENABLED(BLTOUCH)
        return sv04_p1_z_completed && axis_is_trusted(Z_AXIS);
      #else''',
f'''      homeaxis(Z_AXIS);
      #if ENABLED(DUAL_X_CARRIAGE) && ENABLED(BLTOUCH)
        const bool sv04_z_done = sv04_p1_z_completed && axis_is_trusted(Z_AXIS);
        if (!sv04_z_done) {{
          // {MARK}: homeaxis() runs set_axis_is_at_home() BEFORE probe.stow(): an alarm/early return would leave Z marked homed and trusted.
          set_axis_unhomed(Z_AXIS);
          set_axis_untrusted(Z_AXIS);
          SERIAL_ERROR_MSG("SV04 P1 277: Z homing did not complete (BLTouch deploy/stow alarm?); Z marked unhomed");
        }}
        return sv04_z_done;
      #else''', 'Z trust revocation')
    s = once(s, '''        && axis_is_trusted(X_AXIS)
        && (fabsf(inactive_extruder_x - x_home_pos(1)) <= 1.0f);
      if (!sv04_t1_gate) {''',
f'''        && axis_is_trusted(X_AXIS)
        && sv04_p1_t1_home_plausible()   // {MARK}
        && (fabsf(inactive_extruder_x - x_home_pos(1)) <= 1.0f);
      if (!sv04_t1_gate) {{''', 'Z gate plausibility')
    # ---- F5: das Z-Gate verlangte !idex_is_duplicating() (modusbasiert), G28 schaltet die Duplizierung aber zu Beginn ab -> Z-Homing in DUPLICATION/MIRRORED immer verweigert
    s = once(s, '''        && sv04_p1_t0_x_completed
        && !idex_is_duplicating()''',
f'''        && sv04_p1_t0_x_completed
        && !extruder_duplication_enabled   // {MARK}: runtime flag (G28 clears it at its start); idex_is_duplicating() is MODE based and would refuse Z in DUPLICATION/MIRRORED''', 'Z gate duplication')
    # ---- F6: die zweite X-Referenzfahrt (Wiederherstellung der Duplizierung) war ungeprueft; sv04_p1_any_failed war dort bereits const ausgewertet
    s = once(s, '      const bool sv04_p1_any_failed = sv04_p1_x_failed || sv04_p1_z_failed;\n',
             '      bool sv04_p1_any_failed = sv04_p1_x_failed || sv04_p1_z_failed;   // ' + MARK + ': non-const, re-evaluated after the duplication pass\n', 'any_failed mutable')
    s = once(s, '''      // Always home the 2nd (right) extruder first
      active_extruder = 1;
      homeaxis(X_AXIS);

      // Remember this extruder's position for later tool change
      inactive_extruder_x = current_position.x;

      // Home the 1st (left) extruder
      active_extruder = 0;
      homeaxis(X_AXIS);

      // Consider the active extruder to be parked
      idex_set_parked();

      dual_x_carriage_mode = IDEX_saved_mode;
      set_duplication_enabled(IDEX_saved_duplication_state);''',
f'''      // Always home the 2nd (right) extruder first
      #if ENABLED(Z_SAFE_HOMING) && ENABLED(BLTOUCH)
        sv04_p1_t1_x_completed = sv04_p1_t0_x_completed = false;   // {MARK}: fresh evidence for this second X pass
      #endif
      active_extruder = 1;
      homeaxis(X_AXIS);

      // Remember this extruder's position for later tool change
      inactive_extruder_x = current_position.x;

      #if ENABLED(Z_SAFE_HOMING) && ENABLED(BLTOUCH)
        if (!(sv04_p1_t1_x_completed && axis_is_trusted(X_AXIS) && sv04_p1_t1_home_plausible())) sv04_p1_x_failed = true;
        if (!sv04_p1_x_failed) {{
      #endif
        // Home the 1st (left) extruder
        active_extruder = 0;
        homeaxis(X_AXIS);
        #if ENABLED(Z_SAFE_HOMING) && ENABLED(BLTOUCH)
          if (!sv04_p1_t0_x_completed) sv04_p1_x_failed = true;
        }}
        // {MARK}: parked, the saved mode and the saved duplication state are restored ONLY after BOTH carriages completed (a failed pass leaves duplication OFF = the safe state)
        if (!sv04_p1_x_failed) {{
          idex_set_parked();
          dual_x_carriage_mode = IDEX_saved_mode;
          set_duplication_enabled(IDEX_saved_duplication_state);
        }}
        #else
          // Consider the active extruder to be parked
          idex_set_parked();

          dual_x_carriage_mode = IDEX_saved_mode;
          set_duplication_enabled(IDEX_saved_duplication_state);
        #endif''', 'duplication pass hardening')
    s = once(s, '''    else if(!sv04_p1_any_failed && (save_dual_x_carriage_mode == 4) && card.isPrinting()){
      // Home the 1st (left) extruder
      active_extruder = 0;
      homeaxis(X_AXIS);
''',
f'''    else if(!sv04_p1_any_failed && (save_dual_x_carriage_mode == 4) && card.isPrinting()){{
      // Home the 1st (left) extruder
      active_extruder = 0;
      #if ENABLED(Z_SAFE_HOMING) && ENABLED(BLTOUCH)
        sv04_p1_t0_x_completed = false;   // {MARK}
      #endif
      homeaxis(X_AXIS);
      #if ENABLED(Z_SAFE_HOMING) && ENABLED(BLTOUCH)
        if (!sv04_p1_t0_x_completed) sv04_p1_x_failed = true;
      #endif
''', 'mode 4 pass')
    s = once(s, '  #endif // DUAL_X_CARRIAGE\n\n  endstops.not_homing();\n',
f'''  #if ENABLED(DUAL_X_CARRIAGE) && ENABLED(BLTOUCH) && ENABLED(Z_SAFE_HOMING)
    sv04_p1_any_failed = sv04_p1_x_failed || sv04_p1_z_failed;   // {MARK}: includes failures of the duplication/mode-4 X passes
  #endif
  #endif // DUAL_X_CARRIAGE

  endstops.not_homing();
''', 'any_failed refresh')
    s = once(s, 'needX = _UNSAFE(X), needY = _UNSAFE(Y), needZ = false, // UNUSED',
             f'needX = _UNSAFE(X) || (SV04_P1_Z_ONLY_REHOMES_X != 0 && homeZ), needY = _UNSAFE(Y), needZ = false, // UNUSED ({MARK}: option, default off)', 'G28 Z option')
    return s


SPECS = [('Marlin/src/module/motion.h', patch_header), ('Marlin/src/module/motion.cpp', patch_motion), ('Marlin/src/gcode/calibrate/G28.cpp', patch_g28)]


def apply(root):
    """Alle drei Dateien werden zuerst VOLLSTAENDIG validiert und gepatcht (im Speicher); erst dann wird geschrieben (alles oder nichts)."""
    root = Path(root)
    out = []
    for rel, fn in SPECS:
        p = root / rel
        if not p.is_file():
            raise FileNotFoundError(p)
        out.append((p, fn(p.read_text(encoding='utf-8'))))
    for p, s in out:
        p.write_text(s, encoding='utf-8', newline='')
    return [p for p, _ in out]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', type=Path, required=True)
    a = ap.parse_args()
    apply(a.root)
    print('P1_277_HARDENING_APPLIED files=3; FLASH_ALLOWED=NO')


if __name__ == '__main__':
    main()
