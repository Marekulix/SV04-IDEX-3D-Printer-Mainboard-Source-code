#!/usr/bin/env python3
"""SV04 NEXT 281: integrate Claude 277 P1/Auto60 and M420 V2/V4/V5/V6 on one OEM tree.
No flash, no hardware claims. Never overwrite the good 279 build.
"""
from pathlib import Path
import argparse,subprocess,sys,hashlib,json,traceback

HERE=Path(__file__).resolve().parent
CMDS=[
 ["apply_268.py", "{root}/Marlin/src/gcode/calibrate/G28.cpp", "--verify-oem", "--out", "{root}/Marlin/src/gcode/calibrate/G28.cpp.patched"],
]

def patch(root, logs):
 root=Path(root).resolve();logs=Path(logs).resolve();logs.mkdir(parents=True,exist_ok=True)
 def call(name,*argv):
  cmd=[sys.executable,str(HERE/name), *map(str,argv)]
  p=subprocess.run(cmd,capture_output=True,text=True)
  (logs/(name.replace('/','_')+'.log')).write_text('COMMAND '+str(cmd)+'\nEXIT='+str(p.returncode)+'\nSTDOUT\n'+p.stdout+'\nSTDERR\n'+p.stderr)
  print(name,'EXIT',p.returncode,flush=True)
  if p.returncode:raise RuntimeError(f'{name} EXIT {p.returncode}; see saved stderr')
 call('apply_268.py',root/'Marlin/src/gcode/calibrate/G28.cpp','--verify-oem','--out',root/'Marlin/src/gcode/calibrate/G28.cpp.patched')
 (root/'Marlin/src/gcode/calibrate/G28.cpp.patched').replace(root/'Marlin/src/gcode/calibrate/G28.cpp')
 call('apply_272.py',root/'Marlin/src/gcode/calibrate/G28.cpp','--out',root/'Marlin/src/gcode/calibrate/G28.cpp.patched')
 (root/'Marlin/src/gcode/calibrate/G28.cpp.patched').replace(root/'Marlin/src/gcode/calibrate/G28.cpp')
 call('apply_274.py','--root',root)
 call('apply_275.py',root/'Marlin/src/gcode/calibrate/G28.cpp')
 call('apply_276.py','--root',root)
 call('apply_277.py','--root',root,'--profile','integrated','--report',logs/'patch277_report.json')
 for f in ['m420/apply_m420_guard_v2.py','m420/apply_m420_v4.py','m420/apply_m420_v5.py','m420/apply_m420_v6.py']:
  call(f,root)
 paths=['Marlin/src/gcode/calibrate/G28.cpp','Marlin/src/gcode/bedlevel/abl/G29.cpp','Marlin/src/gcode/bedlevel/M420.cpp','Marlin/src/feature/bedlevel/bedlevel.cpp','Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp','Marlin/src/module/motion.cpp']
 (logs/'checksums.txt').write_text(''.join(hashlib.sha256((root/p).read_bytes()).hexdigest()+'  '+p+'\n' for p in paths))
 return True

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('root',type=Path);ap.add_argument('--logs',type=Path,required=True);a=ap.parse_args()
 try:patch(a.root,a.logs)
 except BaseException as ex:
  (a.logs/'fatal_error.txt').write_text(traceback.format_exc())
  print('INTEGRATION_FAILED',ex,file=sys.stderr);sys.exit(3)
 print('INTEGRATED_277_PLUS_M420_V6=YES; FLASH_ALLOWED=NO')
