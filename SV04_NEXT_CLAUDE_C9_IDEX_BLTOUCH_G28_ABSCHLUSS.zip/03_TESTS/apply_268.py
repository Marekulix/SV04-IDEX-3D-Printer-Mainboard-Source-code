#!/usr/bin/env python3
"""Pin-aware OEM G28 patch: per-invocation T1 homing evidence before BLTouch safe-Z.

No changes to EEPROM, machine configuration, or other G-codes.
Requires Sovol OEM G28.cpp blob 5700ac25228ef7405797a80b840bab1dacddfcc7.
"""
import argparse
import hashlib
from pathlib import Path

OEM_BLOB = '5700ac25228ef7405797a80b840bab1dacddfcc7'
MARK = 'SV04_NEXT_P1_268'

OLD_HELPER = '''  inline void home_z_safely() {
    DEBUG_SECTION(log_G28, "home_z_safely", DEBUGGING(LEVELING));

    // Disallow Z homing if X or Y homing is needed
    if (homing_needed_error(_BV(X_AXIS) | _BV(Y_AXIS))) return;'''
NEW_HELPER = '''  // SV04_NEXT_P1_268: Require T1 X homing evidence from this *same* G28.
  // Note: Firmware homing status does NOT constitute independent physical verification.
  inline bool home_z_safely(const bool sv04_t1_homed_this_g28) {
    DEBUG_SECTION(log_G28, "home_z_safely", DEBUGGING(LEVELING));

    // Disallow Z homing if X or Y homing is needed
    if (homing_needed_error(_BV(X_AXIS) | _BV(Y_AXIS))) return false;

    #if ENABLED(DUAL_X_CARRIAGE) && ENABLED(BLTOUCH)
      // Reject a Z-only G28: stale stored coordinates cannot authorize a move.
      // This gate executes BEFORE the OEM writes *_position_x1_axis below.
      const bool sv04_t1_gate = sv04_t1_homed_this_g28
        && active_extruder == 0
        && !idex_is_duplicating()
        && axis_is_trusted(X_AXIS)
        && (fabsf(inactive_extruder_x - X2_HOME_POS) <= 1.0f);
      if (!sv04_t1_gate) {
        SERIAL_ERROR_MSG("SV04 P1 268: T1 homing not confirmed in this G28; Z refused");
        return false;
      }
    #else
      UNUSED(sv04_t1_homed_this_g28);
    #endif'''
OLD_END = '''      do_blocking_move_to_xy(destination);
      homeaxis(Z_AXIS);
    }
    else {
      LCD_MESSAGEPGM(MSG_ZPROBE_OUT);
      SERIAL_ECHO_MSG(STR_ZPROBE_OUT_SER);
    }
  }'''
NEW_END = '''      do_blocking_move_to_xy(destination);
      homeaxis(Z_AXIS);
      return axis_is_trusted(Z_AXIS);
    }
    else {
      LCD_MESSAGEPGM(MSG_ZPROBE_OUT);
      SERIAL_ECHO_MSG(STR_ZPROBE_OUT_SER);
      return false;
    }
  }'''
OLD_TOP = '''  #if ENABLED(DUAL_X_CARRIAGE)
    bool IDEX_saved_duplication_state = extruder_duplication_enabled;
    DualXMode IDEX_saved_mode = dual_x_carriage_mode;
  #endif'''
NEW_TOP = '''  #if ENABLED(DUAL_X_CARRIAGE)
    bool IDEX_saved_duplication_state = extruder_duplication_enabled;
    DualXMode IDEX_saved_mode = dual_x_carriage_mode;
    // SV04_NEXT_P1_268: Fresh local evidence, not persistent EEPROM state.
    #if ENABLED(Z_SAFE_HOMING) && ENABLED(BLTOUCH)
      bool sv04_t1_homed_this_g28 = false;
    #endif
  #endif'''
OLD_HOME_X = '''        // Always home the 2nd (right) extruder first
        active_extruder = 1;
        homeaxis(X_AXIS);

        // Remember this extruder's position for later tool change
        inactive_extruder_x = current_position.x;

        // Home the 1st (left) extruder
        active_extruder = 0;
        homeaxis(X_AXIS);'''
NEW_HOME_X = '''        // Always home the 2nd (right) extruder first
        active_extruder = 1;
        homeaxis(X_AXIS);

        // Remember this extruder's position for later tool change
        inactive_extruder_x = current_position.x;

        // Record T1 result before T0 homing can change shared X trust state.
        #if ENABLED(Z_SAFE_HOMING) && ENABLED(BLTOUCH)
          sv04_t1_homed_this_g28 = axis_is_trusted(X_AXIS)
            && (fabsf(inactive_extruder_x - X2_HOME_POS) <= 1.0f);
        #endif

        // Home the 1st (left) extruder
        active_extruder = 0;
        homeaxis(X_AXIS);'''
OLD_CALL = '''        TERN(Z_SAFE_HOMING, home_z_safely(), homeaxis(Z_AXIS));
        probe.move_z_after_homing();'''
NEW_CALL = '''        #if ENABLED(Z_SAFE_HOMING)
          #if ENABLED(DUAL_X_CARRIAGE) && ENABLED(BLTOUCH)
            const bool sv04_z_homed = home_z_safely(sv04_t1_homed_this_g28);
          #else
            const bool sv04_z_homed = home_z_safely(false);
          #endif
          if (sv04_z_homed) probe.move_z_after_homing();
        #else
          homeaxis(Z_AXIS);
          probe.move_z_after_homing();
        #endif'''

REPLACEMENTS = [(OLD_HELPER, NEW_HELPER), (OLD_END, NEW_END),
                (OLD_TOP, NEW_TOP), (OLD_HOME_X, NEW_HOME_X), (OLD_CALL, NEW_CALL)]

def git_blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()

def patch(source):
    if MARK in source:
        raise ValueError('Already patched')
    for old, _ in REPLACEMENTS:
        hits = source.count(old)
        if hits != 1:
            raise ValueError('Expected exactly one OEM anchor, found %d: %s' % (hits, old[:65]))
    for old, new in REPLACEMENTS:
        source = source.replace(old, new, 1)
    return source

def main():
    p = argparse.ArgumentParser()
    p.add_argument('source', type=Path)
    p.add_argument('--out', required=True, type=Path)
    p.add_argument('--verify-oem', action='store_true')
    args = p.parse_args()
    if args.source.resolve() == args.out.resolve():
        p.error('Refusing in-place overwrite of OEM source')
    raw = args.source.read_bytes()
    if args.verify_oem and git_blob(raw) != OEM_BLOB:
        p.error('Wrong OEM file SHA: ' + git_blob(raw))
    output = patch(raw.decode('utf-8'))
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(output, encoding='utf-8', newline='')
    print('P1_268_APPLIED OEM_SHA=%s FLASH=NO' % git_blob(raw))

if __name__ == '__main__':
    main()
