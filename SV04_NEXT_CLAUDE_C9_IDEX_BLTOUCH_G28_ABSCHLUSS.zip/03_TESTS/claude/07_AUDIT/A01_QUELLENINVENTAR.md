# A01 Quelleninventar (maschinell erzeugt; jede Zeilennummer stammt aus der echten Datei)

Original-Commit laut Auftrag: `1867fcba75354a5c65e0631d6972dd19f1bd6cbe`. Die Dateien stammen aus Ihrem frueheren CI-Lauf (Repo-Stand `840143cd...`); die Bindung an den Commit ist ohne Netz NICHT beweisbar.
Git-Blobs, die der CI-Lauf erwartet hat und die uebereinstimmen: Configuration.h, G28.cpp, G29.cpp, LCD_RTS.cpp, probe.cpp. Alle anderen Dateien sind nur STRONG (kein erwarteter Blob).

| Bereich | Datei | Zeile | Treffer | Suchtext | Bedeutung |
|---|---|---|---|---|---|
| G29 | `gcode/bedlevel/abl/G29.cpp` | 269 | 1 | `tool_change(0)` | bei aktivem T1 wird auf T0 gewechselt (IDEX) |
| G29 | `gcode/bedlevel/abl/G29.cpp` | 253 | 1 | `if (homing_needed_error()) G29_RETURN(false);` | G29 verlangt vorheriges Homing (sonst sofortiger Rueckkehr) |
| G29 | `gcode/bedlevel/abl/G29.cpp` | 275 | 1 | `abl.reenable = planner.leveling_active;` | Nivellierungszustand vor dem Lauf |
| G29 | `gcode/bedlevel/abl/G29.cpp` | 672 | 1 | `z_values[abl.meshCount.x][abl.meshCount.y] = z;` | Messwert wird WAEHREND der Messung ins RAM-Mesh geschrieben (kein Rollback im OEM) |
| G29 | `gcode/bedlevel/abl/G29.cpp` | 679 | 1 | `rtscheck.RTS_SndData(z*1000` | OEM sendet jeden Messpunkt live an das DWIN (x1000) |
| G29 | `gcode/bedlevel/abl/G29.cpp` | 883 | 1 | `planner.leveling_active = !abl.dryrun // abl.reenable;` | BEFUND: G29 schaltet die Nivellierung am Ende SELBST ein (vor jeder Validierung) |
| G29 | `gcode/bedlevel/abl/G29.cpp` | 897 | 1 | `process_subcommands_now_P(PSTR(Z_PROBE_END_SCRIPT));` | BEFUND: Endskript wird ausgefuehrt (laut Configuration.h "G28 XY") |
| G29 | `gcode/bedlevel/abl/G29.cpp` | 903 | 1 | `RTS_AutoBedLevelPage();` | OEM-Seitenwechsel am G29-Ende (auch nach Fehlschlag, wenn waitway==3) |
| G29 | `gcode/bedlevel/abl/G29.cpp` | 909 | 1 | `G29_RETURN(isnan(abl.measured_z));` | Rueckgabe am Ende |
| Konfiguration | `Marlin/Configuration.h` | 146 | 1 | `#define MOTHERBOARD BOARD_CREALITY_V4` | BEFUND: Platine laut Konfiguration BOARD_CREALITY_V4 (Auftrag nennt V5.2.1) |
| Konfiguration | `Marlin/Configuration.h` | 1830 | 1 | `#define EEPROM_SETTINGS` | EEPROM-Einstellungen aktiv |
| Konfiguration | `Marlin/Configuration.h` | 1722 | 1 | `#define Z_PROBE_END_SCRIPT` | Endskript nach der Messung |
| Konfiguration | `Marlin/Configuration.h` | 1544 | 1 | `#define AUTO_BED_LEVELING_BILINEAR` | Bilinear-Mesh aktiv |
| Konfiguration | `Marlin/Configuration.h` | 1095 | 1 | `#define BLTOUCH` | BLTouch (nicht Teil dieses Auftrags: ChatGPT) |
| Konfiguration | `Marlin/Configuration_adv.h` | 752 | 1 | `#define DUAL_X_CARRIAGE` | IDEX (nicht Teil dieses Auftrags: ChatGPT) |
| EEPROM | `pins/stm32f1/pins_CREALITY_V4.h` | 48 | 1 | `#define IIC_BL24CXX_EEPROM` | BEFUND: aktiver Speicher = I2C-EEPROM 24C16 |
| EEPROM | `pins/stm32f1/pins_CREALITY_V4.h` | 52 | 2 | `#define MARLIN_EEPROM_SIZE             0x800` | EEPROM-Groesse 2 KB |
| EEPROM | `HAL/STM32F1/eeprom_bl24cxx.cpp` | 47 | 1 | `bool PersistentStore::access_finish() { return true; }` | kein gepuffertes Schreiben: jedes Byte wird sofort geschrieben |
| EEPROM | `HAL/STM32F1/eeprom_bl24cxx.cpp` | 54 | 1 | `if (v != eeprom_read_byte(p))` | nur geaenderte Bytes werden geschrieben |
| EEPROM | `HAL/STM32F1/eeprom_bl24cxx.cpp` | 57 | 1 | `if (eeprom_read_byte(p) != v) {` | Rueckpruefung je Byte im Schreibpfad (nicht unabhaengig vom Schreibpfad) |
| EEPROM | `module/settings.cpp` | 39 | 1 | `#define EEPROM_VERSION "V85"` | Versionskennung |
| EEPROM | `module/settings.cpp` | 40 | 1 | `#define EEPROM_OFFSET 100` | Offset des Abbilds |
| EEPROM | `module/settings.cpp` | 653 | 2 | `bool MarlinSettings::save() {` | save() (= was M500 aufruft; M500.cpp liegt nicht vor) |
| EEPROM | `module/settings.cpp` | 655 | 1 | `char ver[4] = "ERR";` | BEFUND: Platzhalter-Version "ERR" wird zuerst geschrieben |
| EEPROM | `module/settings.cpp` | 1463 | 1 | `EEPROM_WRITE(version);` | echte Version erst am ENDE (Commit-Marker) |
| EEPROM | `module/settings.cpp` | 1464 | 1 | `EEPROM_WRITE(final_crc);` | CRC erst am ENDE |
| EEPROM | `module/settings.cpp` | 2443 | 1 | `bool MarlinSettings::validate() {` | validate(): liest + prueft CRC/Version, uebernimmt nichts (validating=true) |
| EEPROM | `module/settings.cpp` | 2458 | 1 | `bool MarlinSettings::load() {` | load(): validate(), sonst reset() auf Standardwerte |
| EEPROM | `module/settings.h` | 39 | 1 | `static bool save();` | oeffentliche API |
| EEPROM | `module/settings.h` | 60 | 1 | `static bool validate();` | oeffentliche API |
| EEPROM | `module/settings.h` | 59 | 1 | `static bool load();` | oeffentliche API |
| EEPROM | `module/settings.h` | 36 | 1 | `static uint16_t datasize();` | oeffentliche API |
| Temperatur | `module/temperature.h` | 357 | 1 | `static bed_info_t temp_bed;` | Bett: temp_bed.celsius / .target |
| Zustand | `module/motion.h` | 416 | 1 | `inline bool axis_is_trusted(const AxisEnum axis)` | Achs-Vertrauen (read-only genutzt) |
| Zustand | `module/motion.h` | 564 | 1 | `extern bool extruder_duplication_enabled;` | IDEX-Duplizierung (read-only genutzt) |
| Zustand | `module/motion.h` | 572 | 2 | `enum DualXMode : char {` | IDEX-Modi (read-only genutzt) |
| Zustand | `module/planner.h` | 392 | 1 | `static bool leveling_active;` | Nivellierung aktiv |
| Zustand | `gcode/queue.h` | 158 | 1 | `static bool has_commands_queued()` | Queue-Zustand |
| Zustand | `gcode/queue.h` | 153 | 1 | `static void enqueue_now_P(PGM_P const cmd);` | Befehl einstellen (G29) |
| Dispatch | `gcode/gcode.cpp` | 818 | 1 | `case 420: M420(); break;` | M420 (M420.cpp liegt nicht vor) |
| Dispatch | `gcode/gcode.cpp` | 841 | 1 | `case 500: M500(); break;` | M500 (M500.cpp liegt nicht vor) |
| Dispatch | `gcode/gcode.cpp` | 842 | 1 | `case 501: M501(); break;` | M501 = Ladepfad |
| Dispatch | `gcode/gcode.cpp` | 848 | 1 | `case 504: M504(); break;` | M504 = Validierung |
| Dispatch | `gcode/gcode.cpp` | 581 | 1 | `case 190: M190(); break;` | M190 (M190_M109.cpp liegt nicht vor) |
| Dispatch | `gcode/gcode.cpp` | 1036 | 1 | `case 1004: M1004(); break;` | hoechste belegte M-Nummer vor 7219: M1060 ist frei (M1000/1001/1002/1004 belegt) |
| DWIN | `lcd/e3v2/creality/LCD_RTS.h` | 72 | 1 | `#define AUTO_BED_LEVEL_1POINT_VP           0x1100` | Basis der 16 Mesh-Zellen |
| DWIN | `lcd/e3v2/creality/LCD_RTS.h` | 66 | 1 | `#define AUTO_BED_LEVEL_ICON_VP             0x108D` | Fortschritts-Icon |
| DWIN | `lcd/e3v2/creality/LCD_RTS.h` | 247 | 1 | `ChangePageKey` | Empfangsschluessel (VP 0x110E, kollidiert mit Mesh-Zelle k=7) |
| DWIN | `lcd/e3v2/creality/LCD_RTS.cpp` | 2693 | 1 | `void RTSUpdate()` | Hauptschleifen-Tick (Aufrufstelle in MarlinCore.cpp: NICHT verifizierbar) |
| DWIN | `lcd/e3v2/creality/LCD_RTS.cpp` | 710 | 1 | `void RTSSHOW::RTS_HandleData()` | Touch-Auswertung (waitway-Sperre am Anfang) |
| DWIN | `lcd/e3v2/creality/LCD_RTS.cpp` | 2872 | 1 | `void RTS_AutoBedLevelPage()` | Seitenwechsel nach G29 |
| DWIN | `lcd/e3v2/creality/LCD_RTS.cpp` | 338 | 3 | `queue.enqueue_now_P(PSTR("M420 S1"));` | OEM-M420 S1 (Menue/Boot; unveraendert) |
| DWIN | `lcd/e3v2/creality/LCD_RTS.cpp` | 864 | 6 | `settings.save()` | OEM-Menue ruft settings.save() an mehreren Stellen (waehrend Auto60 per Touch-Sperre blockiert) |
| Mesh | `feature/bedlevel/abl/abl.cpp` | 268 | 1 | `float bilinear_z_offset(` | Interpolation (keine NaN-Behandlung) |
| Mesh | `feature/bedlevel/bedlevel.h` | 36 | 1 | `bool leveling_is_valid();` | Meshgueltigkeit |
| Mesh | `feature/bedlevel/bedlevel.h` | 37 | 1 | `void set_bed_leveling_enabled(` | Nivellierung ein/aus |

## NICHT vorhanden (daher nur eingeschraenkt inventarisierbar)

- **M420.cpp / M500-M504.cpp / M190_M109.cpp**: nicht in den Uploads: M420 S1, M500, M501, M504 sind nur ueber gcode.cpp-Dispatch und settings.h belegt; das Verhalten stammt aus der oeffentlichen settings-API, nicht aus ihrem Quelltext
- **MarlinCore.cpp**: nicht in den Uploads: Aufrufstelle von RTSUpdate() und die Reihenfolge von idle() nicht verifizierbar
- **temperature.cpp (Regelung/Thermal Protection)**: als Datei vorhanden, hier nur read-only; Heizungsfehler-Fahnen sind nicht oeffentlich abfragbar (kill() bei Fehler)
- **HAL/STM32F1/eeprom_if_iic.cpp, I2C-Treiber**: Hardware-nahe Bitebene nicht Teil der Uploads
- **ini/*.ini (Definition von env:STM32F103RET6_creality)**: nicht in den Uploads; nur default_envs in platformio.ini
- **HMI-Binaerdateien 14ShowFile.bin / 13TouchFile.bin**: nicht in den Uploads

## Gesperrt (ChatGPT Punkt 1; Claude liest nur)

- `Marlin/src/gcode/calibrate/G28.cpp`, `Marlin/src/module/motion.cpp`, `Marlin/src/module/motion.h`: werden von den 275-Patchskripten geaendert (apply_268/272/274/275). Dieses Paket aendert sie NICHT.
