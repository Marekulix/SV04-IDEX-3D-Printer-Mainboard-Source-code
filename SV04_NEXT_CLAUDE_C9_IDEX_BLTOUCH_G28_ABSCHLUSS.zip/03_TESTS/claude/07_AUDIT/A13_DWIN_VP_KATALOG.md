# A13 DWIN-VP-Katalog (maschinell aus LCD_RTS.h)

*_VP-Definitionen: 87

## Mesh-Zellen (Anzeige, OEM-Reihenfolge = Messreihenfolge)

| Punkt k | VP | Zelle (x,y) |
|---|---|---|
| 0 | 0x1100 | (3, 0) |
| 1 | 0x1102 | (2, 0) |
| 2 | 0x1104 | (1, 0) |
| 3 | 0x1106 | (0, 0) |
| 4 | 0x1108 | (0, 1) |
| 5 | 0x110a | (1, 1) |
| 6 | 0x110c | (2, 1) |
| 7 | 0x110e | (3, 1) |
| 8 | 0x1110 | (3, 2) |
| 9 | 0x1112 | (2, 2) |
| 10 | 0x1114 | (1, 2) |
| 11 | 0x1116 | (0, 2) |
| 12 | 0x1118 | (0, 3) |
| 13 | 0x111a | (1, 3) |
| 14 | 0x111c | (2, 3) |
| 15 | 0x111e | (3, 3) |

## Gleiche Adresse unter mehreren Namen (Kollisionen in LCD_RTS.h)

- keine

## Definitionen im Mesh-Bereich 0x1100-0x111F

- AUTO_BED_LEVEL_1POINT_VP = 0x1100 (Zeile 72)

## Empfangstabelle (Touch/Rueckmeldung) im Mesh-Bereich

- Index 34 ChangePageKey = 0x110e
