"""PIPELINE (Block 3): der Gesamt-Patch 277 ist reproduzierbar, fail-closed und hygienisch. Prueft apply_277.py (beide Profile) gegen die Test-Pipeline, jeden Anker von Stufe 1, die Diff-Dateien
(reiner Python-Anwender), die Diff-Hygiene (Aequivalent zu `git diff --check`) und dass kein Test-Double und keine Firmware im Paket ist."""
import hashlib
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
CLAUDE = HERE.parent
PKG = CLAUDE.parent
sys.path.insert(0, str(HERE / 'sim'))
sys.path.insert(0, str(PKG))
import chain_tree as T  # noqa: E402
import apply_277_p1 as P1  # noqa: E402

REL = {'G28': 'Marlin/src/gcode/calibrate/G28.cpp', 'mh': 'Marlin/src/module/motion.h', 'mc': 'Marlin/src/module/motion.cpp', 'G29': 'Marlin/src/gcode/bedlevel/abl/G29.cpp', 'LCD': 'Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp', 'gcode': 'Marlin/src/gcode/gcode.cpp'}
H = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()


def fresh_oem_tree():
    d = Path(tempfile.mkdtemp(prefix='pipe_'))
    t = T.tree276(d / 'oem')
    for rel in ('lcd/e3v2/creality/LCD_RTS.cpp', 'gcode/bedlevel/abl/G29.cpp', 'gcode/gcode.cpp'):
        (t / 'Marlin/src' / rel).parent.mkdir(parents=True, exist_ok=True)
        shutil.copy(T.OEM / rel, t / 'Marlin/src' / rel)
    return t


def orchestrate(root, profile):
    return subprocess.run([sys.executable, str(PKG / 'apply_277.py'), '--root', str(root), '--profile', profile], capture_output=True, text=True)


def apply_diff(orig_lines, diff):
    hunks, cur = [], None
    for line in diff.split('\n'):
        m = re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', line)
        if m:
            cur = {'old': int(m.group(1)), 'lines': []}
            hunks.append(cur)
        elif cur is not None and line[:1] in (' ', '+', '-') and not line.startswith(('+++', '---')):
            cur['lines'].append(line)
    out, pos = [], 0
    for h in hunks:
        start = h['old'] - 1
        out += orig_lines[pos:start]
        i = start
        for l in h['lines']:
            tag, text = l[0], l[1:] + '\n'
            if tag in (' ', '-'):
                assert orig_lines[i] == text, 'Kontext/Entfernung passt nicht bei Zeile %d' % (i + 1)
                i += 1
            if tag in (' ', '+'):
                out.append(text)
        pos = i
    return out + orig_lines[pos:]


class Orchestrator(unittest.TestCase):
    def test_O01_both_profiles_reproduce_the_pipeline_stages_hash_for_hash(self):
        S = T.shared()
        for prof, key in (('p1', 'p1'), ('integrated', 'integ')):
            root = fresh_oem_tree() if False else None
            t = fresh_oem_tree()
            r = orchestrate(t, prof)
            self.assertEqual(r.returncode, 0, r.stderr)
            for rel in (REL['G28'], REL['mh'], REL['mc']) + ((REL['G29'], REL['LCD'], REL['gcode']) if prof == 'integrated' else ()):
                ref = S['claude_out'] if rel in (REL['G29'], REL['LCD'], REL['gcode']) else S[key]      # 290: S['integ'] enthaelt zusaetzlich G29-CANCEL V1 + EXT; die Pipeline-Stufen enden am Overlay
                self.assertEqual(H(t / rel), H(ref / rel), f'{prof}: {rel}')
            claude_files = sorted(p.name for p in t.rglob('sv04_claude_*') if p.is_file())
            self.assertEqual(claude_files, [] if prof == 'p1' else sorted(['sv04_claude_auto60_core.h', 'sv04_claude_auto60_marlin.inc', 'sv04_claude_eeprom_core.h', 'sv04_claude_g29_session.h', 'sv04_claude_hooks.h', 'sv04_claude_oem_mesh_loop.inc']), prof)

    def test_O02_second_application_is_refused_and_writes_nothing(self):
        for prof in ('p1', 'integrated'):
            t = fresh_oem_tree()
            self.assertEqual(orchestrate(t, prof).returncode, 0)
            snap = {p: H(p) for p in t.rglob('*') if p.is_file()}
            r = orchestrate(t, prof)
            self.assertEqual(r.returncode, 3, prof)
            self.assertIn('ABGELEHNT', r.stderr)
            self.assertEqual(snap, {p: H(p) for p in t.rglob('*') if p.is_file()}, prof + ': nichts veraendert')

    def test_O03_wrong_lineage_is_refused_and_writes_nothing(self):
        d = Path(tempfile.mkdtemp(prefix='lineage_'))
        for rel in (REL['G28'], REL['mh'], REL['mc']):
            (d / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy(CLAUDE / '01_BASELINE/OEM_FILES' / rel, d / rel)          # pristine OEM, OHNE 268..276
        snap = {p: H(p) for p in d.rglob('*') if p.is_file()}
        r = orchestrate(d, 'p1')
        self.assertEqual(r.returncode, 3)
        self.assertEqual(snap, {p: H(p) for p in d.rglob('*') if p.is_file()})

    def test_O04_integrated_profile_without_pristine_inputs_is_refused_atomically(self):
        t = fresh_oem_tree()
        g29 = t / REL['G29']
        g29.write_bytes(g29.read_bytes() + b'\n// sv04next194 marker\n')            # Vorgaengerpatch-Marker
        snap = {p: H(p) for p in t.rglob('*') if p.is_file()}
        r = orchestrate(t, 'integrated')
        self.assertEqual(r.returncode, 3)
        # Stufe 1 laeuft vor Stufe 2: bei Ablehnung in Stufe 2 darf KEINE Claude-Datei entstehen
        self.assertEqual([p for p in t.rglob('sv04_claude_*') if p.is_file()], [])

    def test_O05_the_chatgpt_chain_scripts_are_shipped_unchanged(self):
        import json
        ref = json.loads((CLAUDE / '01_BASELINE' / 'CHATGPT_SKRIPTE_SHA256.json').read_text())['sha256']
        self.assertGreaterEqual(len(ref), 13)
        for f, h in ref.items():
            self.assertEqual(H(PKG / f), h, f + ': muss byte-identisch mit ChatGPTs Lieferung sein')


class Stage1Anchors(unittest.TestCase):
    def test_A01_every_stage1_anchor_is_enforced_missing_and_doubled_are_rejected(self):
        t276 = T.shared()['t276']
        recorded = []
        orig = P1.once

        def rec(s, old, new, desc):
            recorded.append((desc, old))
            return orig(s, old, new, desc)
        P1.once = rec
        try:
            for rel, fn in P1.SPECS:
                fn((t276 / rel).read_text(encoding='utf-8'))
        finally:
            P1.once = orig
        self.assertEqual(len(recorded), 19, 'Stufe 1 hat genau 19 eindeutige Anker (4 in motion.*, 15 in G28.cpp)')
        by = {}
        for rel, fn in P1.SPECS:
            by[rel] = fn
        n = 0
        for rel, fn in P1.SPECS:
            text = (t276 / rel).read_text(encoding='utf-8')
            before = len(recorded)
            for desc, old in recorded:
                if text.count(old) != 1:
                    continue
                for label, mod in (('fehlt', text.replace(old, '// entfernt\n')), ('doppelt', text.replace(old, old + old))):
                    with self.assertRaises(ValueError, msg=f'{rel} {desc} {label}'):
                        fn(mod)
                    n += 1
        self.assertEqual(n, 38, '19 Anker x (fehlt, doppelt)')

    def test_A02_stage1_changes_only_the_three_files_and_replaces_only_known_lines(self):
        S = T.shared()
        known = {'        && !idex_is_duplicating()', '        return sv04_p1_z_completed && axis_is_trusted(Z_AXIS);', '                 needX = _UNSAFE(X), needY = _UNSAFE(Y), needZ = false, // UNUSED', '    // Home Y (after X)',
                 '    if (DISABLED(HOME_Y_BEFORE_X) && doY)', '      homeaxis(Y_AXIS);', '      const bool sv04_p1_any_failed = sv04_p1_x_failed || sv04_p1_z_failed;', '      // Home the 1st (left) extruder', '      active_extruder = 0;',
                 '      homeaxis(X_AXIS);', '', '      // Consider the active extruder to be parked', '      idex_set_parked();', '      dual_x_carriage_mode = IDEX_saved_mode;', '      set_duplication_enabled(IDEX_saved_duplication_state);', '    }'}
        import difflib
        for rel in (REL['G28'], REL['mh'], REL['mc']):
            a = (S['t276'] / rel).read_text().splitlines(); b = (S['p1'] / rel).read_text().splitlines()
            removed = [l[2:] for l in difflib.ndiff(a, b) if l.startswith('- ')]
            self.assertTrue(set(removed) <= known, f'{rel}: unerwartet entfernt: {set(removed) - known}')
            if rel != REL['G28']:
                self.assertEqual(removed, [])
        other = {p.relative_to(S['p1']).as_posix() for p in S['p1'].rglob('*') if p.is_file()}
        self.assertEqual(other, {REL['G28'], REL['mh'], REL['mc']})


class Hygiene(unittest.TestCase):
    """Aequivalent zu `git diff --check` und Inhaltspruefungen fuer ALLE hinzugefuegten Zeilen (Stufe 1 + 2 gegen 276 bzw. OEM)."""
    def added(self):
        import difflib
        S = T.shared()
        oem = CLAUDE / '01_BASELINE/OEM_FILES'
        pairs = {REL['G28']: S['t276'] / REL['G28'], REL['mh']: S['t276'] / REL['mh'], REL['mc']: S['t276'] / REL['mc'], REL['G29']: oem / REL['G29'], REL['LCD']: oem / REL['LCD'], REL['gcode']: oem / REL['gcode']}
        for rel, base in pairs.items():
            a = base.read_bytes().decode().splitlines(True); b = (S['integ'] / rel).read_bytes().decode().splitlines(True)
            yield rel, [l for l in (x[2:] for x in difflib.ndiff(a, b) if x.startswith('+ '))]

    def test_H01_no_trailing_whitespace_tabs_or_carriage_returns_in_added_lines(self):
        for rel, lines in self.added():
            for l in lines:
                body = l.rstrip('\n')
                self.assertEqual(body, body.rstrip(' \t'), f'{rel}: Leerzeichen am Zeilenende: {body!r}')
                self.assertNotIn('\t', body, rel); self.assertNotIn('\r', l, rel)

    def test_H02_added_code_never_touches_eeprom_heaters_or_the_queue_in_g28_and_motion(self):
        for rel, lines in self.added():
            if rel in (REL['G28'], REL['mh'], REL['mc']):
                code = '\n'.join(re.sub(r'//.*', '', l) for l in lines)
                for bad in ('settings.', 'M500', 'EEPROM', 'enqueue', 'queue.', 'thermalManager', 'setTarget', 'M104', 'M109', 'M140', 'M190', 'planner.buffer', 'do_blocking_move', 'tool_change', 'homeaxis('):
                    if bad == 'homeaxis(':
                        continue            # Durchgaenge der Duplizierung rufen homeaxis() wie das OEM selbst auf (geprueft in test_g28_a60)
                    self.assertNotIn(bad, code, f'{rel}: {bad}')

    def test_H03_stage2_adds_only_the_guard_to_g28(self):
        import difflib
        S = T.shared()
        a = (S['p1'] / REL['G28']).read_text().splitlines(); b = (S['integ'] / REL['G28']).read_text().splitlines()
        ops = [l for l in difflib.ndiff(a, b) if l[:2] in ('+ ', '- ')]
        self.assertEqual([l for l in ops if l.startswith('- ')], [])
        add = '\n'.join(l[2:] for l in ops)
        self.assertIn('SV04Claude_G28Guard sv04claude_g28_guard;', add)
        self.assertIn('if (!sv04claude_g28_guard.allowed()) return;', add)
        self.assertEqual(len(ops), 9)

    def test_H04_files_keep_lf_line_endings_and_their_final_newline(self):
        S = T.shared()
        for rel in (REL['G28'], REL['mh'], REL['mc'], REL['G29'], REL['LCD'], REL['gcode']):
            b = (S['integ'] / rel).read_bytes()
            self.assertNotIn(b'\r', b, rel); self.assertTrue(b.endswith(b'\n'), rel)


class Diffs(unittest.TestCase):
    def test_D01_every_shipped_diff_reproduces_its_target_with_the_pure_python_applier(self):
        sys.path.insert(0, str(CLAUDE / 'tools'))
        import make_diffs_277 as M
        n = 0
        for name, base, tgt, rel in M.plan():
            diff = (PKG / 'diffs' / name).read_text(encoding='utf-8')
            got = ''.join(apply_diff(base.read_bytes().decode().splitlines(True), diff)).encode()
            self.assertEqual(hashlib.sha256(got).hexdigest(), H(tgt), name)
            n += 1
        self.assertEqual(n, 10)

    def test_D02_diff_to_oem_for_g28_and_motion_shows_the_total_change_of_the_whole_chain(self):
        for k in ('G28', 'motion_h', 'motion_cpp'):
            d = (PKG / 'diffs' / f'3_GESAMT_{k}_OEM_nach_277.patch').read_text()
            self.assertIn('SV04_NEXT_P1_268' if k == 'G28' else 'SV04_NEXT_P1_274', d)
            self.assertIn('SV04_NEXT_P1_277', d)


class Diffs283(unittest.TestCase):
    def test_D03_the_283_diffs_reproduce_the_shipped_firmware_files_from_the_282_originals(self):
        import json
        sys.path.insert(0, str(CLAUDE / 'tools'))
        import make_diffs_283 as M3
        ref = json.loads((CLAUDE / '01_BASELINE' / 'STAND_282' / 'STAND_282_SHA256.json').read_text())['dateien']
        for n, meta in ref.items():
            self.assertEqual(H(CLAUDE / '01_BASELINE' / 'STAND_282' / n), meta['sha256'], n + ': 282-Original unveraendert')
        n = 0
        for name, base, tgt, rel in M3.plan():
            diff = (PKG / 'diffs' / name).read_text(encoding='utf-8')
            lines = base.read_bytes().decode().splitlines(True) if base else []
            got = ''.join(apply_diff(lines, diff)).encode()
            self.assertEqual(hashlib.sha256(got).hexdigest(), H(tgt), name); n += 1
        self.assertEqual(n, 7)
        ref5 = json.loads((CLAUDE / '01_BASELINE' / 'STAND_285' / 'STAND_285_SHA256.json').read_text())['dateien']
        for n5, meta in ref5.items():
            self.assertEqual(H(CLAUDE / '01_BASELINE' / 'STAND_285' / n5), meta['sha256'], n5 + ': 285-Original unveraendert')

    def test_D04_283_changes_no_oem_file_and_no_chatgpt_script(self):
        import json
        ref = json.loads((CLAUDE / '01_BASELINE' / 'CHATGPT_SKRIPTE_SHA256.json').read_text())['sha256']
        for f, h in ref.items():
            self.assertEqual(H(PKG / f), h, f)
        for p in (PKG / 'diffs').glob('4_*.patch'):
            changed = '\n'.join(l for l in p.read_text().splitlines() if l[:1] in '+-' and not l.startswith(('+++', '---')))          # nur geaenderte Zeilen, keine Kontextzeilen
            for oem in ('Marlin/src/gcode/', 'Marlin/src/module/motion', 'G28.cpp', 'G29.cpp', 'gcode.cpp', 'LCD_RTS.cpp'):
                self.assertNotIn(oem, changed, p.name + ': 283 aendert keine OEM-/P1-Datei (' + oem + ')')


class PackageContent(unittest.TestCase):
    def test_C01_no_test_double_no_firmware_binary_and_the_double_switch_is_never_set_by_a_profile(self):
        files = [p for p in PKG.rglob('*') if p.is_file() and '__pycache__' not in str(p)]
        self.assertEqual([p.name for p in files if p.suffix in ('.bin', '.hex', '.elf', '.uf2')], [])
        self.assertEqual([p.name for p in files if 'TEST_ONLY' in p.name], [])
        wf = PKG.parent / '277.yml'
        yml = (PKG / 'docs' / '277.yml.kopie').read_text() if (PKG / 'docs' / '277.yml.kopie').exists() else (wf.read_text() if wf.exists() else '')
        if yml:
            self.assertNotIn('SV04_CLAUDE_HOME_BACKEND_EXTERNAL', yml)

    def test_C02_gpl_notices_are_preserved_in_the_oem_files(self):
        for rel in (REL['G28'], REL['mh'], REL['mc']):
            self.assertIn('GNU General Public License', (T.shared()['integ'] / rel).read_text())


if __name__ == '__main__':
    unittest.main(verbosity=2)
