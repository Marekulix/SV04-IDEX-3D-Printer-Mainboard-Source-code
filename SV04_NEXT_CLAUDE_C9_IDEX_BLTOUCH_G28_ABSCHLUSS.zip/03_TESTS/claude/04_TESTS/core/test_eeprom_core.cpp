// Host-Tests des ECHTEN EEPROM-Kerns (02_SOURCE/.../sv04_claude_eeprom_core.h). Ausgabe: PASS/FAIL <ID> <Name>.
// Das EEPROM ist ein BYTE-GENAUES MODELL des BL24CXX-Treibers (HAL/STM32 eeprom_bl24cxx.cpp: nur geaenderte Bytes, Nachlesen, bei Fehler Rueckkehr ohne Weiterschreiben) und von Marlins save() (settings.cpp:
// "ERR" zuerst, Daten, Kopf+CRC zuletzt; settings.h:129: EEPROM_WRITE verwirft den Rueckgabewert von write_data). KEIN STM32, KEINE Hardware.
#include "../../02_SOURCE/Marlin/src/feature/sv04_claude_auto60/sv04_claude_eeprom_core.h"
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <string>
using namespace sv04c::ee;

static int g_pass = 0, g_fail = 0;
static const char *g_id = "", *g_name = ""; static bool g_ok = true;
#define CHECK(c) do { if (!(c)) { g_ok = false; printf("  FEHLER %s:%d: %s\n", g_id, __LINE__, #c); } } while (0)
#define EQ(a, b) do { if (!((a) == (b))) { g_ok = false; printf("  FEHLER %s:%d: %s == %s (ist: %ld, erwartet: %ld)\n", g_id, __LINE__, #a, #b, (long)(a), (long)(b)); } } while (0)
#define TEST(ID, NAME) static void t_##ID(); struct R_##ID { R_##ID() { reg().push_back({#ID, NAME, t_##ID}); } } r_##ID; static void t_##ID()
struct Tc { const char *id, *name; void (*fn)(); };
static std::vector<Tc> &reg() { static std::vector<Tc> v; return v; }

// ---- Referenz-CRC (CRC-16/XMODEM, wie Marlins crc16(); Pruefvektor "123456789" = 0x31C3)
static void ref_crc16(uint16_t *crc, const void *data, uint16_t cnt) {
  const uint8_t *p = (const uint8_t *)data;
  while (cnt--) { *crc = (uint16_t)(*crc ^ (uint16_t)(((uint16_t)*p++) << 8)); for (uint8_t i = 0; i < 8; i++) *crc = (uint16_t)((*crc & 0x8000) ? ((uint16_t)(*crc << 1) ^ 0x1021) : (*crc << 1)); }
}

// ---- EEPROM-Modell mit Fehlerinjektion
struct Img {
  uint8_t b[2048]; uint32_t changed = 0, reads = 0; int64_t cut_at = -1; bool dead = false; int64_t fail_at = -1; bool unreadable = false;
  Img() { memset(b, 0xFF, sizeof b); }
};
// HAL-getreu (eeprom_bl24cxx.cpp write_data): nur geaenderte Bytes schreiben; bei Fehler Rueckkehr (true=Fehler) OHNE pos weiterzuzaehlen und OHNE CRC fuer die restlichen Bytes
static bool hal_write(Img &m, int &pos, const uint8_t *v, size_t size, uint16_t *crc) {
  while (size--) {
    bool do_write = !m.dead && *v != m.b[pos];                                                         // ein toter Prozess schreibt nichts mehr
    if (do_write) {
      if (m.cut_at >= 0 && (int64_t)m.changed >= m.cut_at) { m.dead = true; do_write = false; }      // Stromausfall VOR diesem Byte
      else if (m.fail_at >= 0 && (int64_t)m.changed == m.fail_at) { ++m.changed; return true; }       // Schreibfehler (Verifikation schlaegt fehl): Rueckkehr mit Fehler
    }
    if (do_write) { m.b[pos] = *v; ++m.changed; }
    ref_crc16(crc, v, 1); pos++; v++;
  }
  return false;
}
static bool img_read(void *c, uint16_t pos, uint8_t *buf, uint16_t n) { Img *m = (Img *)c; if (m->unreadable) return false; ++m->reads; memcpy(buf, m->b + pos, n); return true; }
static bool img_write(void *c, uint16_t pos, const uint8_t *buf, uint16_t n) { Img *m = (Img *)c; int p = pos; uint16_t d = 0; return !hal_write(*m, p, buf, n, &d); }
static Store store(Img &m) { Store s; s.ctx = &m; s.capacity = 2048; s.read = img_read; s.write = img_write; s.crc16 = ref_crc16; return s; }

// ---- Modell der Marlin-Einstellungen (800 Bytes: Kopf 6 + Fuellfelder 300 + Nivellierung 1+4 + probe_offset 12 + Mesh 82 + Fuellfelder 395)
static const uint16_t OFF = 100, LEN = 800;
struct Ram { uint8_t fa[300]; uint8_t lev; float fade; float probe[3]; float z[4][4]; float sp[2], st[2]; uint8_t fb[395]; };
static Ram make_ram(unsigned seed, float zoff = -1.25f) {
  Ram r; memset(&r, 0, sizeof r); srand(seed);
  for (auto &x : r.fa) x = (uint8_t)(rand() & 0xFF);
  for (auto &x : r.fb) x = (uint8_t)(rand() & 0xFF);
  r.lev = 1; r.fade = 0.0f; r.probe[0] = -28.5f; r.probe[1] = 6.25f; r.probe[2] = zoff;
  for (int x = 0; x < 4; x++) for (int y = 0; y < 4; y++) r.z[x][y] = ((rand() % 600) - 300) / 1000.0f;
  r.sp[0] = 70.0f; r.sp[1] = 70.0f; r.st[0] = 10.0f; r.st[1] = 12.0f;
  return r;
}
// Marlins save(): "ERR" zuerst, Kopf-CRC-Platz ueberspringen, Felder, Kopf+CRC zuletzt. Rueckgabewerte von write_data werden WIE IM OEM VERWORFEN (settings.h:129).
static bool marlin_save(Img &m, const Ram &r) {
  int pos = OFF; uint16_t crc = 0, dummy = 0;
  const uint8_t err[4] = {'E', 'R', 'R', 0};
  hal_write(m, pos, err, 4, &dummy); pos += 2; crc = 0;
  auto W = [&](const void *d, size_t n) { hal_write(m, pos, (const uint8_t *)d, n, &crc); };
  uint8_t gx = 4, gy = 4;
  W(r.fa, sizeof r.fa); W(&r.lev, 1); W(&r.fade, 4); W(r.probe, 12); W(&gx, 1); W(&gy, 1); W(r.sp, 8); W(r.st, 8); W(r.z, 64); W(r.fb, sizeof r.fb);
  const uint16_t size = (uint16_t)(pos - OFF), fin = crc;
  pos = OFF; const uint8_t ver[4] = {'V', '8', '5', 0};
  hal_write(m, pos, ver, 4, &dummy); hal_write(m, pos, (const uint8_t *)&fin, 2, &dummy);
  return size == LEN;                                                        // wie size_error(); NICHT das Ergebnis der Schreibzugriffe
}
static void wire_of(const Ram &r, uint8_t w[kWire]) { pack_wire(r.z, r.sp, r.st, w); }
// Auto60 aendert NUR das Mesh: neues Mesh auf den alten Einstellungen (alle anderen Felder bleiben gleich)
static Ram with_new_mesh(const Ram &base, unsigned seed) { Ram r = base; Ram t = make_ram(seed); memcpy(r.z, t.z, sizeof r.z); return r; }
static Block blk() { Block b; b.start = OFF; b.len = LEN; return b; }
static bool same_block(const Img &a, const Img &b) { return memcmp(a.b + OFF, b.b + OFF, LEN) == 0; }

// ================================================================== A: Grundbausteine
TEST(EE01, "CRC-16/XMODEM: Pruefvektor 123456789 = 0x31C3, fortlaufend in Stuecken identisch") { uint16_t c = 0; ref_crc16(&c, "123456789", 9); EQ(c, 0x31C3); uint16_t d = 0; ref_crc16(&d, "1234", 4); ref_crc16(&d, "56789", 5); EQ(d, 0x31C3); }
TEST(EE02, "Mesh-Abbild: 82 Bytes in Marlins Reihenfolge (gx, gy, spacing, start, z[x][y])") {
  Ram r = make_ram(1); uint8_t w[kWire]; wire_of(r, w); EQ(kWire, 82); EQ(w[0], 4); EQ(w[1], 4);
  CHECK(memcmp(w + 2, r.sp, 8) == 0); CHECK(memcmp(w + 10, r.st, 8) == 0); CHECK(memcmp(w + 18, &r.z[0][0], 4) == 0); CHECK(memcmp(w + 18 + 4, &r.z[0][1], 4) == 0); CHECK(memcmp(w + 18 + 16, &r.z[1][0], 4) == 0); }
TEST(EE03, "Mustersuche streamt korrekt: Treffer an JEDER Position (auch ueber Chunk-Grenzen) gegen naive Suche") {
  Img m; Store s = store(m); uint8_t pat[kWire]; for (unsigned i = 0; i < kWire; i++) pat[i] = (uint8_t)(0x40 + i);
  unsigned bad = 0, cases = 0;
  for (uint16_t at = 0; at + kWire <= 400; at += 1) {
    memset(m.b, 0x11, sizeof m.b); memcpy(m.b + 100 + at, pat, kWire);
    uint16_t cnt = 99, first = 0; CHECK(count_pattern(s, 100, 400, pat, kWire, cnt, first));
    if (cnt != 1 || first != 100 + at) ++bad;
    ++cases;
  }
  EQ(bad, 0u); EQ(cases, 319u);
  // Kurzmuster, auch mehrfach und ueberlappend
  memset(m.b, 0, sizeof m.b); uint8_t z4[4] = {0, 0, 0, 0}; uint16_t c = 0, f = 0; count_pattern(s, 100, 10, z4, 4, c, f); EQ(c, 7);          // 10 Nullbytes: 7 Startpositionen
}
TEST(EE04, "Mustersuche: fehlende Suche, zu kurzer Bereich, Lesefehler") { Img m; Store s = store(m); uint8_t p[8] = {1, 2, 3, 4, 5, 6, 7, 8}; uint16_t c = 7, f = 0; CHECK(count_pattern(s, 0, 100, p, 8, c, f)); EQ(c, 0); CHECK(count_pattern(s, 0, 4, p, 8, c, f)); EQ(c, 0); m.unreadable = true; CHECK(!count_pattern(s, 0, 100, p, 8, c, f)); }
TEST(EE05, "primary_info: gueltig, leer (FF und 00), ERR, fremd, CRC falsch, nicht lesbar, zu gross") {
  Img m; Store s = store(m); Block b = blk(); Ram r = make_ram(2);
  EQ(primary_info(s, b).st, PR_BLANK); memset(m.b, 0, sizeof m.b); EQ(primary_info(s, b).st, PR_BLANK); memset(m.b, 0xFF, sizeof m.b);
  marlin_save(m, r); PrimaryInfo i = primary_info(s, b); EQ(i.st, PR_VALID); EQ(i.crc_stored, i.crc_calc);
  Img e = m; e.b[OFF + 300] ^= 0x01; EQ(primary_info(store(e), b).st, PR_CRC_BAD);
  Img g = m; memcpy(g.b + OFF, "ERR", 4); EQ(primary_info(store(g), b).st, PR_INTERRUPTED);
  Img f = m; f.b[OFF] = 'X'; EQ(primary_info(store(f), b).st, PR_FOREIGN);
  Img v = m; v.b[OFF + 1] = 'a'; EQ(primary_info(store(v), b).st, PR_FOREIGN);
  Img u = m; u.unreadable = true; EQ(primary_info(store(u), b).st, PR_UNREADABLE);
  Block big = b; big.len = 2000; EQ(primary_info(s, big).st, PR_UNREADABLE);
  Block tiny = b; tiny.len = 4; EQ(primary_info(s, tiny).st, PR_UNREADABLE); }
TEST(EE06, "CRC des Blocks stimmt mit Marlins gespeicherter CRC ueberein (Modell save() schreibt CRC ueber die Bytes nach dem Kopf)") { Img m; Ram r = make_ram(3); marlin_save(m, r); PrimaryInfo i = primary_info(store(m), blk()); CHECK(i.st == PR_VALID); uint16_t c = 0; ref_crc16(&c, m.b + OFF + 6, LEN - 6); EQ(c, i.crc_stored); }

// ================================================================== B: Verifikation des gespeicherten Meshes
TEST(EE10, "verify_mesh: frisch gespeichertes Mesh wird gefunden, genau einmal, bitgleich, CRC ok, probe.offset gefunden") {
  Img m; Ram r = make_ram(10); marlin_save(m, r); uint8_t w[kWire]; wire_of(r, w); VerifyReport v;
  CHECK(verify_mesh(store(m), blk(), w, (const uint8_t *)r.probe, 10.0f, v)); CHECK(v.readable && v.header_ok && v.crc_ok && v.found && v.unique && v.geometry_equal && v.z_equal && v.values_ok && v.zoff_found);
  EQ(v.matches, 1); EQ(v.bad_mask, 0); EQ(v.at, OFF + 6 + 300 + 1 + 4 + 12); }
TEST(EE11, "verify_mesh: EIN falsches Bit in EINEM Messwert mit KORRIGIERTER CRC (Fehlschreiben mit gueltiger Pruefsumme) -> z_equal=false, genau dieser Punkt") {
  for (unsigned pt = 0; pt < 16; pt++) { Img m; Ram r = make_ram(11); marlin_save(m, r); uint8_t w[kWire]; wire_of(r, w);
    m.b[OFF + 6 + 300 + 1 + 4 + 12 + 18 + pt * 4 + 1] ^= 0x04;                                  // Mesh-Wert veraendern
    uint16_t c = 0; ref_crc16(&c, m.b + OFF + 6, LEN - 6); m.b[OFF + 4] = (uint8_t)c; m.b[OFF + 5] = (uint8_t)(c >> 8);        // CRC passend neu setzen: nur der Vergleich kann es erkennen
    VerifyReport v; CHECK(!verify_mesh(store(m), blk(), w, nullptr, 10.0f, v)); CHECK(v.crc_ok); CHECK(v.found); CHECK(v.geometry_equal); CHECK(!v.z_equal); EQ(v.bad_mask, (1u << pt)); } }
TEST(EE12, "verify_mesh: gekipptes Bit im Mesh OHNE CRC-Korrektur -> crc_ok=false (CRC erkennt es)") { Img m; Ram r = make_ram(12); marlin_save(m, r); uint8_t w[kWire]; wire_of(r, w); m.b[OFF + 6 + 300 + 17 + 30] ^= 0x80; VerifyReport v; CHECK(!verify_mesh(store(m), blk(), w, nullptr, 10.0f, v)); CHECK(!v.crc_ok); EQ(v.primary, PR_CRC_BAD); }
TEST(EE13, "verify_mesh: jedes einzelne Byte des gesamten Blocks (ausser Kopf) gekippt -> NIE ein Erfolg") {
  unsigned ok_after_flip = 0; Ram r = make_ram(13); uint8_t w[kWire]; wire_of(r, w);
  for (uint16_t i = 6; i < LEN; i++) { Img m; marlin_save(m, r); m.b[OFF + i] ^= 0x10; VerifyReport v; if (verify_mesh(store(m), blk(), w, nullptr, 10.0f, v)) ++ok_after_flip; }
  EQ(ok_after_flip, 0u); }
TEST(EE14, "verify_mesh: jedes einzelne Byte der 82 Mesh-Bytes gekippt MIT neu gesetzter CRC -> NIE ein Erfolg (nur der Vergleich greift)") {
  unsigned ok_after_flip = 0; Ram r = make_ram(14); uint8_t w[kWire]; wire_of(r, w); const uint16_t mo = 6 + 300 + 17;
  for (uint16_t i = 0; i < kWire; i++) { Img m; marlin_save(m, r); m.b[OFF + mo + i] ^= 0x01; uint16_t c = 0; ref_crc16(&c, m.b + OFF + 6, LEN - 6); m.b[OFF + 4] = (uint8_t)c; m.b[OFF + 5] = (uint8_t)(c >> 8); VerifyReport v; if (verify_mesh(store(m), blk(), w, nullptr, 10.0f, v)) ++ok_after_flip; }
  EQ(ok_after_flip, 0u); }
TEST(EE15, "verify_mesh: ungueltige Zahlen im gespeicherten Mesh (NaN, Inf, ausserhalb des Rahmens) -> values_ok=false") {
  const float bad[3] = {NAN, INFINITY, 55.0f};
  for (float x : bad) { Img m; Ram r = make_ram(15); r.z[1][2] = x; marlin_save(m, r); Ram ex = make_ram(15); uint8_t w[kWire]; wire_of(r, w); VerifyReport v; CHECK(!verify_mesh(store(m), blk(), w, nullptr, 10.0f, v)); CHECK(!v.values_ok); CHECK(v.crc_ok); CHECK(v.z_equal); (void)ex; } }
TEST(EE16, "verify_mesh: Raster/Start veraendert (Teilsuche) -> geometry nicht gleich, Mesh 'nicht gefunden'") {
  Img m; Ram r = make_ram(16); marlin_save(m, r); Ram wr = r; wr.sp[0] = 70.5f; uint8_t w[kWire]; wire_of(wr, w); VerifyReport v; CHECK(!verify_mesh(store(m), blk(), w, nullptr, 10.0f, v)); CHECK(!v.found); CHECK(!v.geometry_equal); }
TEST(EE17, "verify_mesh: Muster zweimal vorhanden -> unique=false -> kein Erfolg") {
  Img m; Ram r = make_ram(17); marlin_save(m, r); uint8_t w[kWire]; wire_of(r, w); memcpy(m.b + OFF + 6 + 20, w, kWire);        // zweite Kopie im Fuellbereich
  uint16_t c = 0; ref_crc16(&c, m.b + OFF + 6, LEN - 6); m.b[OFF + 4] = (uint8_t)c; m.b[OFF + 5] = (uint8_t)(c >> 8);
  VerifyReport v; CHECK(!verify_mesh(store(m), blk(), w, nullptr, 10.0f, v)); EQ(v.matches, 2); CHECK(!v.unique); }
TEST(EE18, "verify_mesh: leeres/unbeschriebenes EEPROM, ERR-Kennung, nicht lesbar -> kein Erfolg") {
  Ram r = make_ram(18); uint8_t w[kWire]; wire_of(r, w); VerifyReport v;
  Img e; CHECK(!verify_mesh(store(e), blk(), w, nullptr, 10.0f, v)); CHECK(!v.found); EQ(v.primary, PR_BLANK);
  Img m; marlin_save(m, r); memcpy(m.b + OFF, "ERR", 4); CHECK(!verify_mesh(store(m), blk(), w, nullptr, 10.0f, v)); EQ(v.primary, PR_INTERRUPTED);
  Img u; marlin_save(u, r); u.unreadable = true; CHECK(!verify_mesh(store(u), blk(), w, nullptr, 10.0f, v)); CHECK(!v.readable); }
TEST(EE19, "verify_mesh: probe.offset (Z-Offset) abweichend gespeichert -> zoff_found=false") { Img m; Ram r = make_ram(19, -1.25f); marlin_save(m, r); Ram o = make_ram(19, -1.30f); uint8_t w[kWire]; wire_of(r, w); VerifyReport v; verify_mesh(store(m), blk(), w, (const uint8_t *)o.probe, 10.0f, v); CHECK(!v.zoff_found); verify_mesh(store(m), blk(), w, (const uint8_t *)r.probe, 10.0f, v); CHECK(v.zoff_found); }
TEST(EE20, "BEFUND OEM: Schreibfehler werden von Marlin nur INDIREKT bemerkt (size_error) und beim Schreiben des KOPFES GAR NICHT; die unabhaengige Pruefung erkennt in JEDEM Fall") {
  Ram old = make_ram(20), nw = with_new_mesh(old, 21); uint8_t w[kWire]; wire_of(nw, w); unsigned save_says_ok = 0, verify_says_ok = 0, runs = 0, changed_total = 0, silent_and_wrong = 0;
  { Img m; marlin_save(m, old); uint32_t b0 = m.changed; marlin_save(m, nw); changed_total = m.changed - b0; }
  for (unsigned k = 0; k < changed_total; k++) { Img m; marlin_save(m, old); m.fail_at = m.changed + k; const bool sv = marlin_save(m, nw); VerifyReport v; const bool vv = verify_mesh(store(m), blk(), w, nullptr, 10.0f, v); ++runs; if (sv) ++save_says_ok; if (vv) ++verify_says_ok; if (sv && !vv) ++silent_and_wrong; }
  CHECK(changed_total > 60); EQ(verify_says_ok, 0u);          // KEIN Schreibfehler an irgendeiner Position wird von der unabhaengigen Pruefung uebersehen
  EQ(save_says_ok, 5u); EQ(silent_and_wrong, 5u);             // save() meldet nur dort Erfolg, wo der Kopf (3 Versionsbytes + 2 CRC-Bytes) betroffen ist: ohne unabhaengige Pruefung bliebe das UNBEMERKT
  printf("    [%u Schreibfehler-Positionen: save() meldete in %u Faellen (Kopf) trotzdem Erfolg; unabhaengige Pruefung erkannte %u von %u]\n", runs, save_says_ok, runs - verify_says_ok, runs); }

// ================================================================== C: Journal
TEST(EE30, "shadow_plan: passt ans Ende des 2-KB-EEPROMs ohne den Hauptblock zu beruehren; kein Platz -> ok=false") {
  Img m; Store s = store(m); ShadowPlan p = shadow_plan(s, blk()); CHECK(p.ok); EQ(p.hdr, 2048 - 16 - 800); EQ(p.data, p.hdr + 16); CHECK(p.hdr >= OFF + LEN + kGuard);
  Block big = blk(); big.len = 1000; CHECK(!shadow_plan(s, big).ok);                         // 1000+16 + 100+1000 > 2048
  Block mid = blk(); mid.len = 960; ShadowPlan q = shadow_plan(s, mid); CHECK(q.ok); CHECK(q.hdr >= OFF + 960 + kGuard);
  mid.len = 970; CHECK(!shadow_plan(s, mid).ok); }
TEST(EE31, "shadow_create: Kopie bitgleich, Journal gueltig; zweites create mit unveraendertem Block schreibt <= 6 Bytes (Verschleissschutz)") {
  Img m; Ram r = make_ram(31); marlin_save(m, r); Store s = store(m); ShadowPlan p = shadow_plan(s, blk());
  uint32_t c0 = m.changed; EQ(shadow_create(s, p, blk(), 1), SC_OK); const uint32_t first = m.changed - c0; CHECK(first > 700);
  ShadowInfo i; CHECK(shadow_info(s, p, blk(), true, i)); CHECK(i.present && i.inflight && i.data_ok); CHECK(memcmp(m.b + p.data, m.b + OFF, LEN) == 0);
  CHECK(shadow_invalidate(s, p)); CHECK(shadow_info(s, p, blk(), true, i)); CHECK(i.present && !i.inflight);
  c0 = m.changed; EQ(shadow_create(s, p, blk(), 2), SC_OK); CHECK(m.changed - c0 <= 6); }
TEST(EE32, "shadow_create: nur von einem GUELTIGEN Hauptblock (leer, ERR, CRC falsch -> SC_PRIMARY_INVALID), ohne Platz -> SC_NO_SPACE") {
  Img m; Store s = store(m); ShadowPlan p = shadow_plan(s, blk()); EQ(shadow_create(s, p, blk(), 1), SC_PRIMARY_INVALID);
  Ram r = make_ram(32); marlin_save(m, r); m.b[OFF + 100] ^= 1; EQ(shadow_create(s, p, blk(), 1), SC_PRIMARY_INVALID);
  Block big = blk(); big.len = 1000; ShadowPlan np = shadow_plan(s, big); EQ(shadow_create(s, np, big, 1), SC_NO_SPACE); }
TEST(EE33, "shadow_create: Lesefehler -> Fehler, kein gueltiges Journal; Schreibfehler an jeder Stelle -> NIE ein gueltiges Journal mit falscher Kopie") {
  Ram r = make_ram(33); Img base; marlin_save(base, r); uint32_t n; { Img t = base; Store s = store(t); ShadowPlan p = shadow_plan(s, blk()); uint32_t c0 = t.changed; shadow_create(s, p, blk(), 1); n = t.changed - c0; }
  unsigned bad = 0;
  for (uint32_t k = 0; k < n; k++) { Img t = base; t.fail_at = t.changed + k; Store s = store(t); ShadowPlan p = shadow_plan(s, blk()); shadow_create(s, p, blk(), 1); ShadowInfo i; shadow_info(s, p, blk(), true, i); if (i.inflight && !i.data_ok) ++bad; if (i.inflight && memcmp(t.b + p.data, t.b + OFF, LEN) != 0) ++bad; }
  EQ(bad, 0u); }
TEST(EE34, "Journal: manipulierter Kopf (Magic, Layout, Kopf-CRC) oder beschaedigte Kopie -> nicht verwendbar; Statusbyte beliebig != 0xA5 -> nicht in Arbeit") {
  Ram r = make_ram(34); Img base; marlin_save(base, r); { Store s = store(base); ShadowPlan p = shadow_plan(s, blk()); EQ(shadow_create(s, p, blk(), 1), SC_OK); }
  ShadowPlan p = shadow_plan(store(base), blk()); ShadowInfo i;
  for (unsigned off : {0u, 3u, 4u, 6u, 8u, 10u, 12u, 14u, 15u}) { Img t = base; t.b[p.hdr + off] ^= 0x20; shadow_info(store(t), p, blk(), true, i); CHECK(!(i.present && i.inflight && i.data_ok)); }
  { Img t = base; t.b[p.data + 123] ^= 1; shadow_info(store(t), p, blk(), true, i); CHECK(i.present && i.inflight); CHECK(!i.data_ok); EQ(shadow_restore(store(t), p, blk()), RS_NO_SHADOW); }
  for (unsigned st : {0u, 0xFFu, 0x5Au, 0xA4u}) { Img t = base; t.b[p.hdr + 5] = (uint8_t)st; shadow_info(store(t), p, blk(), true, i); CHECK(i.present); CHECK(!i.inflight); } }
TEST(EE35, "shadow_restore: stellt den Hauptblock bitgleich wieder her; der Hauptblock bleibt bis zum LETZTEN Schritt ungueltig (Kopf zuletzt)") {
  Ram old = make_ram(35), nw = with_new_mesh(old, 36); Img m; marlin_save(m, old); Store s = store(m); ShadowPlan p = shadow_plan(s, blk()); EQ(shadow_create(s, p, blk(), 1), SC_OK);
  Img snapshot = m; marlin_save(m, nw); CHECK(!same_block(m, snapshot)); EQ(shadow_restore(s, p, blk()), RS_OK); CHECK(same_block(m, snapshot)); EQ(primary_info(s, blk()).st, PR_VALID);
  // Abbruch in jeder Phase des Zurueckspielens: der Hauptblock ist danach NIE "gueltig aussehend aber falsch" (er ist ERR/CRC-ungueltig oder fertig)
  marlin_save(m, nw); memcpy(m.b + OFF, "ERR", 4); Img mid = m; uint32_t n; { Img t = mid; Store ts = store(t); uint32_t c0 = t.changed; shadow_restore(ts, p, blk()); n = t.changed - c0; }
  unsigned wrong_looking_valid = 0; for (uint32_t k = 0; k < n; k++) { Img t = mid; t.cut_at = t.changed + k; Store ts = store(t); shadow_restore(ts, p, blk()); t.dead = false; t.cut_at = -1; const PrimaryInfo pi = primary_info(ts, blk()); if (pi.st == PR_VALID && !same_block(t, snapshot)) ++wrong_looking_valid; }
  EQ(wrong_looking_valid, 0u); }
TEST(EE36, "boot_decision: vollstaendige Tabelle (6 Primaerzustaende x Journal nutzbar/nicht)") {
  EQ(boot_decision(PR_VALID, true), BA_CLEAR); EQ(boot_decision(PR_INTERRUPTED, true), BA_RESTORE); EQ(boot_decision(PR_CRC_BAD, true), BA_RESTORE); EQ(boot_decision(PR_BLANK, true), BA_RESTORE);
  EQ(boot_decision(PR_FOREIGN, true), BA_RESTORE); EQ(boot_decision(PR_UNREADABLE, true), BA_NONE);
  for (int p = 0; p <= PR_VALID; p++) EQ(boot_decision((PrimaryState)p, false), BA_NONE); }
TEST(EE37, "recover_at_boot: Grundfaelle (nichts zu tun / Journal verwerfen / zurueckspielen / Journal beschaedigt / kein Platz)") {
  Ram old = make_ram(37), nw = with_new_mesh(old, 38); Block b = blk();
  { Img m; marlin_save(m, old); EQ(recover_at_boot(store(m), b, nullptr), BR_NOTHING); }
  { Img m; marlin_save(m, old); Img want = m; Store s = store(m); ShadowPlan p = shadow_plan(s, b); shadow_create(s, p, b, 1); marlin_save(m, nw); PrimaryState ps; EQ(recover_at_boot(s, b, &ps), BR_RESTORED); EQ(ps, PR_VALID); CHECK(same_block(m, want)); ShadowInfo i; shadow_info(s, p, b, true, i); CHECK(!i.inflight); }      // C3: seit ChatGPTs 306 gilt ein CRC-gueltiger, aber UNVERIFIZIERTER Hauptblock bei offenem Journal nicht mehr als abgeschlossen: der alte, verifizierte Block wird zurueckgespielt
  { Img m; marlin_save(m, old); Img want = m; Store s = store(m); ShadowPlan p = shadow_plan(s, b); shadow_create(s, p, b, 1); memcpy(m.b + OFF, "ERR", 4); m.b[OFF + 200] ^= 0x55; PrimaryState ps; EQ(recover_at_boot(s, b, &ps), BR_RESTORED); EQ(ps, PR_INTERRUPTED); CHECK(same_block(m, want)); ShadowInfo i; shadow_info(s, p, b, true, i); CHECK(!i.inflight); }
  { Img m; marlin_save(m, old); Store s = store(m); ShadowPlan p = shadow_plan(s, b); shadow_create(s, p, b, 1); memcpy(m.b + OFF, "ERR", 4); m.b[p.data + 9] ^= 1; EQ(recover_at_boot(s, b, nullptr), BR_RESTORE_FAILED); EQ(primary_info(s, b).st, PR_INTERRUPTED); }
  { Img m; marlin_save(m, old); Block big = b; big.len = 1000; EQ(recover_at_boot(store(m), big, nullptr), BR_NO_SPACE); }
  { Img m; marlin_save(m, old); m.b[OFF] = 'Q'; Store s = store(m); ShadowPlan p = shadow_plan(s, b); (void)p; EQ(recover_at_boot(s, b, nullptr), BR_NOTHING); } }
TEST(EE38, "commit_transaction: verified=true verwirft das Journal; verified=false spielt zurueck, aber nur wenn der Hauptblock von der Kopie abweicht") {
  Ram old = make_ram(39), nw = with_new_mesh(old, 40); Block b = blk();
  { Img m; marlin_save(m, old); Img want = m; Store s = store(m); ShadowPlan p = shadow_plan(s, b); shadow_create(s, p, b, 1); marlin_save(m, nw); EQ(commit_transaction(s, p, b, true), CM_OK); ShadowInfo i; shadow_info(s, p, b, true, i); CHECK(!i.inflight); CHECK(!same_block(m, want)); }
  { Img m; marlin_save(m, old); Img want = m; Store s = store(m); ShadowPlan p = shadow_plan(s, b); shadow_create(s, p, b, 1); marlin_save(m, nw); EQ(commit_transaction(s, p, b, false), CM_ROLLED_BACK); CHECK(same_block(m, want)); ShadowInfo i; shadow_info(s, p, b, true, i); CHECK(!i.inflight); }
  { Img m; marlin_save(m, old); Store s = store(m); ShadowPlan p = shadow_plan(s, b); shadow_create(s, p, b, 1); const uint32_t c0 = m.changed; EQ(commit_transaction(s, p, b, false), CM_OK); CHECK(m.changed - c0 <= 1); }      // Hauptblock unveraendert: nur Journal verwerfen
  { Img m; marlin_save(m, old); Store s = store(m); ShadowPlan p = shadow_plan(s, b); shadow_create(s, p, b, 1); marlin_save(m, nw); m.b[p.data + 5] ^= 1; EQ(commit_transaction(s, p, b, false), CM_ROLLBACK_FAILED); }   // beschaedigte Kopie: Zurueckspielen NICHT moeglich -> ehrlich als gescheitert gemeldet
  { Img m; marlin_save(m, old); Store s = store(m); ShadowPlan none; none.ok = false; none.hdr = none.data = 0; EQ(commit_transaction(s, none, b, false), CM_OK); } }

// ================================================================== D: ERSCHOEPFENDE Stromausfall-Pruefung
struct Outcome { bool valid, is_old, is_new, shadow_inflight; };
static Outcome after_reboot(Img &m, const Img &old, const Img &nw) {
  m.dead = false; m.cut_at = -1; m.fail_at = -1; Store s = store(m); recover_at_boot(s, blk(), nullptr);
  Outcome o; o.valid = primary_info(s, blk()).st == PR_VALID; o.is_old = same_block(m, old); o.is_new = same_block(m, nw);
  ShadowPlan p = shadow_plan(s, blk()); ShadowInfo i; shadow_info(s, p, blk(), true, i); o.shadow_inflight = i.present && i.inflight; return o;
}
// Die vollstaendige Transaktion des Adapters: Journal anlegen -> save() -> unabhaengig pruefen -> Abschluss (Journal verwerfen oder zurueckspielen)
static bool transaction(Img &m, const Ram &nw, bool use_journal) {
  Store s = store(m); const Block b = blk(); ShadowPlan p = shadow_plan(s, b);
  if (use_journal) shadow_create(s, p, b, 1);
  marlin_save(m, nw);
  uint8_t w[kWire]; wire_of(nw, w); VerifyReport v; const bool ok = verify_mesh(s, b, w, (const uint8_t *)nw.probe, 10.0f, v);
  if (use_journal) commit_transaction(s, p, b, ok);
  return ok;
}
TEST(EE40, "STROMAUSFALL an JEDER Byteposition der gesamten Transaktion: nach dem Neustart ist der Einstellungsblock IMMER gueltig und GENAU der alte oder der neue Block (nie ein Gemisch), das Journal ist verworfen") {
  Ram old = make_ram(41), nw = with_new_mesh(old, 42); Img oldimg; marlin_save(oldimg, old); Img newimg; marlin_save(newimg, nw);
  uint32_t total; { Img m = oldimg; const uint32_t c0 = m.changed; CHECK(transaction(m, nw, true)); total = m.changed - c0; CHECK(same_block(m, newimg)); }
  CHECK(total > 800 && total < 1000); unsigned invalid = 0, mixed = 0, inflight = 0, got_old = 0, got_new = 0;
  for (uint32_t k = 0; k <= total; k++) { Img m = oldimg; m.cut_at = m.changed + k; transaction(m, nw, true); const Outcome o = after_reboot(m, oldimg, newimg); if (!o.valid) ++invalid; if (!o.is_old && !o.is_new) ++mixed; if (o.shadow_inflight) ++inflight; if (o.is_old) ++got_old; if (o.is_new) ++got_new; }
  EQ(invalid, 0u); EQ(mixed, 0u); EQ(inflight, 0u); CHECK(got_old > 0 && got_new > 0); printf("    [%u Abschaltpunkte: %u endeten mit dem ALTEN, %u mit dem NEUEN Block]\n", total + 1, got_old, got_new); }
TEST(EE41, "OHNE Journal (Zustand von 282): wie viele Abschaltpunkte hinterlassen den Einstellungsblock UNGUELTIG? (Beleg fuer das Risiko, nicht fuer den Code)") {
  Ram old = make_ram(43), nw = with_new_mesh(old, 44); Img oldimg; marlin_save(oldimg, old); Img newimg; marlin_save(newimg, nw);
  uint32_t total; { Img m = oldimg; const uint32_t c0 = m.changed; transaction(m, nw, false); total = m.changed - c0; }
  unsigned invalid = 0; for (uint32_t k = 0; k <= total; k++) { Img m = oldimg; m.cut_at = m.changed + k; transaction(m, nw, false); m.dead = false; if (primary_info(store(m), blk()).st != PR_VALID) ++invalid; }
  CHECK(total > 40); CHECK(invalid > 0); printf("    [OHNE Journal: %u von %u Abschaltpunkten hinterlassen den GESAMTEN Einstellungsblock ungueltig]\n", invalid, total + 1); }
TEST(EE42, "Stromausfall WAEHREND der Wiederherstellung beim Neustart (verschachtelt): auch dann nach dem naechsten Neustart gueltig und alt/neu") {
  Ram old = make_ram(45), nw = with_new_mesh(old, 46); Img oldimg; marlin_save(oldimg, old); Img newimg; marlin_save(newimg, nw);
  unsigned runs = 0, bad = 0;
  for (uint32_t k1 = 0; k1 < 890; k1 += 3) {                                   // Abschaltpunkt im Speichern (mittendrin)
    Img crashed = oldimg; crashed.cut_at = crashed.changed + k1; transaction(crashed, nw, true); crashed.dead = false; crashed.cut_at = -1;
    uint32_t n2; { Img t = crashed; Store ts = store(t); const uint32_t c0 = t.changed; recover_at_boot(ts, blk(), nullptr); n2 = t.changed - c0; }
    for (uint32_t k2 = 0; k2 <= n2; k2 += 1) {                                    // Abschaltpunkt in der Wiederherstellung
      Img m = crashed; m.cut_at = m.changed + k2; Store s = store(m); recover_at_boot(s, blk(), nullptr); m.dead = false; m.cut_at = -1;
      const Outcome o = after_reboot(m, oldimg, newimg); ++runs; if (!o.valid || (!o.is_old && !o.is_new) || o.shadow_inflight) ++bad; } }
  CHECK(runs > 500); EQ(bad, 0u); printf("    [%u verschachtelte Abschaltungen (Speichern + Wiederherstellung), 0 fehlerhafte Endzustaende]\n", runs); }
TEST(EE43, "Schreibfehler (HAL-Fehler, von Marlin unbemerkt) an JEDER Position der Transaktion: unabhaengige Pruefung erkennt ihn; der Abschluss stellt den ALTEN gueltigen Block wieder her oder der neue ist vollstaendig korrekt") {
  Ram old = make_ram(47), nw = with_new_mesh(old, 48); Img oldimg; marlin_save(oldimg, old); Img newimg; marlin_save(newimg, nw);
  uint32_t total; { Img m = oldimg; const uint32_t c0 = m.changed; transaction(m, nw, true); total = m.changed - c0; }
  unsigned false_ok = 0, invalid_final = 0, mixed = 0, detected = 0;
  for (uint32_t k = 0; k < total; k++) {
    Img m = oldimg; m.fail_at = m.changed + k; const bool ok = transaction(m, nw, true); m.fail_at = -1;
    const bool valid = primary_info(store(m), blk()).st == PR_VALID, isold = same_block(m, oldimg), isnew = same_block(m, newimg);
    if (ok && !isnew) ++false_ok;                                                  // Erfolg gemeldet, aber der gespeicherte Block ist NICHT der neue
    if (!ok) ++detected;
    if (!valid) ++invalid_final;
    if (!isold && !isnew) ++mixed; }
  EQ(false_ok, 0u); EQ(mixed, 0u); CHECK(detected > 0); EQ(invalid_final, 0u); printf("    [%u Schreibfehler-Positionen: %u erkannt, danach stets gueltiger alter oder neuer Block]\n", total, detected); }

TEST(EE44, "Versionspruefung: ein gueltig aussehender Kopf einer ANDEREN Version (V84) ist FREMD und wird nie als gueltig behandelt; mit erwarteter Version V85 gueltig; ohne Angabe (nullptr) jede V<zz>") {
  Img m; Ram r = make_ram(44); marlin_save(m, r); Block b = blk(); b.ver = "V85"; Store s = store(m);
  EQ(primary_info(s, b).st, PR_VALID); Block any = blk(); EQ(any.ver == nullptr, true); EQ(primary_info(s, any).st, PR_VALID);
  Img o = m; memcpy(o.b + OFF, "V84", 4); EQ(primary_info(store(o), b).st, PR_FOREIGN); EQ(primary_info(store(o), any).st, PR_VALID);     // ohne Angabe wuerde V84 durchgehen: deshalb gibt der Adapter IMMER die Version an
  uint8_t w[kWire]; wire_of(r, w); VerifyReport v; CHECK(!verify_mesh(store(o), b, w, nullptr, 10.0f, v)); EQ(v.primary, PR_FOREIGN);
  ShadowPlan p = shadow_plan(s, b); CHECK(p.ok); EQ(shadow_create(store(o), p, b, 1), SC_PRIMARY_INVALID); }
TEST(EE45, "Startwiederherstellung mit erwarteter Version: Journal gueltig + Hauptblock einer anderen Version/halb ueberschrieben -> zurueckgespielt (alter V85-Block)") {
  Img m; Ram r = make_ram(45); marlin_save(m, r); Block b = blk(); b.ver = "V85"; Store s = store(m); ShadowPlan p = shadow_plan(s, b); EQ(shadow_create(s, p, b, 1), SC_OK);
  Img keep = m; memcpy(m.b + OFF, "V84", 4); PrimaryState ps; EQ(recover_at_boot(store(m), b, &ps), BR_RESTORED); EQ(ps, PR_FOREIGN); CHECK(same_block(m, keep)); }
// Ein Speicher, der LUEGT: write() meldet Erfolg, speichert ein Byte aber NICHT (der echte BL24CXX-Treiber liest jedes Byte nach und meldet den Fehler; diese Pruefung sichert gegen einen Treiber/Chip ab, der das nicht tut)
struct Lossy { Img *m; int drop; };
static bool lossy_read(void *c, uint16_t pos, uint8_t *buf, uint16_t n) { Lossy *l = (Lossy *)c; memcpy(buf, l->m->b + pos, n); return true; }
static bool lossy_write(void *c, uint16_t pos, const uint8_t *buf, uint16_t n) { Lossy *l = (Lossy *)c; for (uint16_t i = 0; i < n; i++) { if ((int)(pos + i) == l->drop) continue; l->m->b[pos + i] = buf[i]; } return true; }
static Store lossy_store(Lossy &l) { Store s; s.ctx = &l; s.capacity = 2048; s.read = lossy_read; s.write = lossy_write; s.crc16 = ref_crc16; return s; }
TEST(EE46, "Luegender Speicher: das Zurueckspielen verliert ein Byte OHNE Fehlermeldung -> die NACHPRUEFUNG erkennt es: RS_VERIFY, CM_ROLLBACK_FAILED, Journal bleibt GUELTIG, Start meldet BR_RESTORE_FAILED (nie 'wiederhergestellt')") {
  Ram old = make_ram(46), nw = with_new_mesh(old, 47); Img m; marlin_save(m, old); Img oldimg = m; Block b = blk(); b.ver = "V85"; Store s = store(m); ShadowPlan p = shadow_plan(s, b); EQ(shadow_create(s, p, b, 1), SC_OK);
  marlin_save(m, nw);                                                                  // Hauptblock ist jetzt der NEUE (Verifikation gescheitert -> es muss zurueckgespielt werden)
  int diff = -1; for (int i = 6; i < LEN; i++) if (oldimg.b[OFF + i] != m.b[OFF + i]) { diff = OFF + i; break; } CHECK(diff > 0);
  Lossy l = { &m, diff }; Store ls = lossy_store(l);
  EQ(shadow_restore(ls, p, b), RS_VERIFY);                                             // die Kopie wurde zurueckgeschrieben, ein Byte fehlt -> Nachpruefung schlaegt an
  EQ(commit_transaction(ls, p, b, false), CM_ROLLBACK_FAILED);
  ShadowInfo i; CHECK(shadow_info(ls, p, b, true, i)); CHECK(i.present && i.inflight && i.data_ok);              // Journal bleibt: der naechste Start versucht es erneut
  PrimaryState ps; EQ(recover_at_boot(ls, b, &ps), BR_RESTORE_FAILED); }
int main() {
  for (const Tc &t : reg()) { g_id = t.id; g_name = t.name; g_ok = true; t.fn(); if (g_ok) { ++g_pass; printf("PASS %s %s\n", t.id, t.name); } else { ++g_fail; printf("FAIL %s %s\n", t.id, t.name); } }
  printf("SUMMARY tests=%d pass=%d fail=%d\n", g_pass + g_fail, g_pass, g_fail);
  return g_fail ? 1 : 0;
}
