// Exhaustive Pruefung der reinen Richtlinie gegen ein UNABHAENGIG formuliertes Orakel (Regeltabelle). Kein Marlin, keine Simulation.
#include <cstdio>
#include <cstring>
#include "../../02_SOURCE/Marlin/src/feature/sv04_claude_auto60/sv04_claude_toolchange_policy.h"
using namespace sv04c;
static int fails = 0, tests = 0;
#define CHECK(c, ...) do { ++tests; if (!(c)) { ++fails; std::printf("FAIL %s:%d ", __FILE__, __LINE__); std::printf(__VA_ARGS__); std::printf("\n"); } } while (0)
// Orakel: wer darf wechseln? (als Tabelle der Gruende, nicht als Nachbau von tc_decide)
static int oracle(int tool, int active, int ext, bool hm, bool tr, bool busy) {
  const bool valid = tool >= 0 && tool < ext;
  if (!valid) return TC_PASS_INVALID_TOOL;
  const bool same = tool == active;
  if (same) return TC_ALLOW_SAME_TOOL;
  const bool x_ok = hm && tr;
  if (busy) return TC_REFUSE_AUTO60_BUSY;
  return x_ok ? TC_ALLOW : TC_REFUSE_X_NOT_TRUSTED;
}
int main(int argc, char **argv) {
  if (argc > 1 && !std::strcmp(argv[1], "cli")) {              // Zeilen "tool active ext homed trusted busy" -> Verdict (fuer die Verknuepfung mit den G28-Ergebnissen)
    int t, a, e, h, r, b;
    while (std::scanf("%d %d %d %d %d %d", &t, &a, &e, &h, &r, &b) == 6) std::printf("%d\n", (int)tc_decide(TcIn{t, a, e, h != 0, r != 0, b != 0}));
    return 0;
  }
  int n = 0;
  for (int ext = 1; ext <= 3; ++ext) for (int tool = -2; tool <= 4; ++tool) for (int active = 0; active < ext; ++active)
    for (int hm = 0; hm < 2; ++hm) for (int tr = 0; tr < 2; ++tr) for (int busy = 0; busy < 2; ++busy) {
      const TcVerdict v = tc_decide(TcIn{tool, active, ext, hm != 0, tr != 0, busy != 0}); ++n;
      CHECK((int)v == oracle(tool, active, ext, hm, tr, busy), "ext=%d tool=%d active=%d homed=%d trusted=%d busy=%d -> %d", ext, tool, active, hm, tr, busy, (int)v);
    }
  CHECK(n == 336, "Anzahl Faelle %d (erwartet 336 = 56 + 112 + 168)", n);
  // benannte Eigenschaften (Sicherheitsaussagen)
  for (int hm = 0; hm < 2; ++hm) for (int tr = 0; tr < 2; ++tr) {
    const bool x_ok = hm && tr;
    CHECK(tc_refused(tc_decide(TcIn{1, 0, 2, hm != 0, tr != 0, false})) == !x_ok, "ein echter Wechsel T0->T1 ist genau bei vertrauenswuerdigem X erlaubt (hm=%d tr=%d)", hm, tr);
    CHECK(tc_refused(tc_decide(TcIn{0, 1, 2, hm != 0, tr != 0, false})) == !x_ok, "T1->T0 genauso");
    CHECK(!tc_refused(tc_decide(TcIn{0, 0, 2, hm != 0, tr != 0, true})), "gleiches Werkzeug wird nie abgelehnt (hm=%d tr=%d)", hm, tr);
  }
  CHECK(tc_refused(tc_decide(TcIn{1, 0, 2, true, true, true})), "waehrend Auto60 wird ein echter Wechsel auch bei gutem X abgelehnt");
  CHECK(!tc_refused(tc_decide(TcIn{5, 0, 2, false, false, true})), "ein ungueltiges Werkzeug geht an die OEM-Fehlermeldung (keine eigene Ablehnung)");
  CHECK(!tc_refused(tc_decide(TcIn{-1, 0, 2, false, false, true})), "auch ein negatives");
  CHECK(std::strlen(tc_why(TC_REFUSE_AUTO60_BUSY)) > 0 && std::strlen(tc_why(TC_REFUSE_X_NOT_TRUSTED)) > 0 && std::strlen(tc_why(TC_ALLOW)) == 0, "Begruendungstexte");
  std::printf("SUMMARY tests=%d pass=%d fail=%d (Faelle im Orakelvergleich: %d)\n", tests, tests - fails, fails, n);
  return fails ? 1 : 0;
}
