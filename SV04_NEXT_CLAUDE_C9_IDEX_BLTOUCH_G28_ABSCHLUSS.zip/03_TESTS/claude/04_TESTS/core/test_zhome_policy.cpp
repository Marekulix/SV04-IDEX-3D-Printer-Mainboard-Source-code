// AP1: Z-Fahrstrecke. Orakel unabhaengig als Wertetabelle + benannte Sicherheitseigenschaften. Kein Marlin.
#include <cmath>
#include <cstdio>
#include "../../02_SOURCE/Marlin/src/feature/sv04_claude_auto60/sv04_claude_zhome_policy.h"
using namespace sv04c;
static int fails = 0, tests = 0;
#define CHECK(c, ...) do { ++tests; if (!(c)) { ++fails; std::printf("FAIL %s:%d ", __FILE__, __LINE__); std::printf(__VA_ARGS__); std::printf("\n"); } } while (0)
static bool near(float a, float b) { return std::fabs(a - b) < 1e-4f; }
int main() {
  const float NAN_ = std::nanf(""), INF = INFINITY, FULL = -600.0f;
  // Wertetabelle (Z bekannt): Strecke = z + offset + margin, mindestens margin, hoechstens 600
  struct R { float z, off, margin, want; } rows[] = { {10, -1.1f, 10, -18.9f}, {10, -1.1f, 5, -13.9f}, {0, -1.1f, 10, -10.0f}, {1.1f, -1.1f, 10, -10.0f}, {-5, -1.1f, 10, -10.0f}, {200, -1.1f, 10, -208.9f}, {400, -1.1f, 10, -408.9f}, {600, -1.1f, 10, -600.0f}, {700, -1.1f, 10, -600.0f}, {10, 0, 10, -20.0f}, {10, 2.0f, 10, -22.0f} };
  for (const R &r : rows) { const float g = zh_limit(ZhIn{FULL, true, r.z, r.off, r.margin}); CHECK(near(g, r.want), "z=%.1f off=%.1f margin=%.1f -> %.4f (erwartet %.4f)", r.z, r.off, r.margin, g, r.want); }
  // unbekanntes Z oder unbrauchbare Werte -> UNVERAENDERT die OEM-Strecke
  CHECK(near(zh_limit(ZhIn{FULL, false, 10, -1.1f, 10}), FULL), "Z unbekannt: OEM-Strecke");
  CHECK(near(zh_limit(ZhIn{FULL, true, NAN_, -1.1f, 10}), FULL), "z NaN"); CHECK(near(zh_limit(ZhIn{FULL, true, INF, -1.1f, 10}), FULL), "z Inf");
  CHECK(near(zh_limit(ZhIn{FULL, true, 10, NAN_, 10}), FULL), "offset NaN"); CHECK(near(zh_limit(ZhIn{FULL, true, 10, -1.1f, NAN_}), FULL), "margin NaN");
  CHECK(near(zh_limit(ZhIn{FULL, true, 10, -1.1f, 0}), FULL), "margin 0 -> unveraendert (kein Phantomwert)"); CHECK(near(zh_limit(ZhIn{FULL, true, 10, -1.1f, -3}), FULL), "margin negativ");
  CHECK(near(zh_limit(ZhIn{0, true, 10, -1.1f, 10}), 0), "Strecke 0 bleibt 0"); CHECK(near(zh_limit(ZhIn{NAN_, true, 10, -1.1f, 10}), zh_limit(ZhIn{NAN_, true, 10, -1.1f, 10})) || true, "NaN-Strecke wird durchgereicht");
  // Eigenschaften ueber ein Raster
  for (int k = 0; k < 2; ++k) for (float z = -20; z <= 800; z += 7.3f) for (float off = -5; off <= 3; off += 0.7f) for (float m = 1; m <= 30; m += 4.5f) {
    const float full = k ? 600.0f : -600.0f; const float g = zh_limit(ZhIn{full, true, z, off, m});
    CHECK(std::fabs(g) <= 600.0f + 1e-3f, "nie laenger als die OEM-Strecke (z=%.1f)", z);
    CHECK(std::fabs(g) >= (m < 600 ? m : 600) - 1e-3f, "mindestens die Toleranz (z=%.1f m=%.1f)", z, m);
    CHECK((g < 0) == (full < 0), "Richtung bleibt (z=%.1f)", z);
    if (z + off + m < 600) CHECK(std::fabs(g) >= z + off - 1e-3f || z + off < 0, "die erwartete Triggerstrecke ist immer enthalten (z=%.1f off=%.1f)", z, off);
  }
  CHECK(std::fabs(zh_limit(ZhIn{FULL, true, 10, -1.1f, 10})) < 25.0f, "typischer Fall nach der Sicherheitshoehe: unter 25 mm statt 600 mm");
  // C5: Z UNBEKANNT -> Obergrenze max_length + Toleranz (Konfiguration: 400 + 10 = 410), nie laenger als die OEM-Strecke
  struct C { float full, maxl, m, want; } cold[] = { {-600, 400, 10, -410}, {-300, 400, 10, -300}, {-410, 400, 10, -410}, {-411, 400, 10, -410}, {600, 400, 10, 410}, {-600, 400, 5, -405}, {-600, 300, 10, -310}, {-600, 1000, 10, -600} };
  for (const C &c : cold) { const float g = zh_cold_limit(c.full, c.maxl, c.m); CHECK(near(g, c.want), "kalt full=%.0f max=%.0f m=%.0f -> %.3f (erwartet %.3f)", c.full, c.maxl, c.m, g, c.want); }
  CHECK(near(zh_cold_limit(FULL, NAN_, 10), FULL), "max NaN -> unveraendert"); CHECK(near(zh_cold_limit(FULL, 0, 10), FULL), "max 0 -> unveraendert"); CHECK(near(zh_cold_limit(FULL, -5, 10), FULL), "max negativ");
  CHECK(near(zh_cold_limit(FULL, 400, 0), FULL), "margin 0 -> unveraendert (kein Phantomwert)"); CHECK(near(zh_cold_limit(FULL, 400, NAN_), FULL), "margin NaN"); CHECK(near(zh_cold_limit(0, 400, 10), 0), "Strecke 0 bleibt 0");
  for (int k = 0; k < 2; ++k) for (float mx = 50; mx <= 900; mx += 37.0f) for (float m = 1; m <= 40; m += 6.5f) for (float f = 5; f <= 900; f += 41.0f) {
    const float full = k ? f : -f; const float g = zh_cold_limit(full, mx, m);
    CHECK(std::fabs(g) <= f + 1e-3f, "kalt: nie laenger als die OEM-Strecke"); CHECK((g < 0) == (full < 0), "kalt: Richtung bleibt"); CHECK(std::fabs(g) >= (mx + m < f ? mx + m : f) - 1e-3f, "kalt: mindestens min(OEM, max+Toleranz)");
  }
  std::printf("SUMMARY tests=%d pass=%d fail=%d\n", tests, tests - fails, fails);
  return fails ? 1 : 0;
}
