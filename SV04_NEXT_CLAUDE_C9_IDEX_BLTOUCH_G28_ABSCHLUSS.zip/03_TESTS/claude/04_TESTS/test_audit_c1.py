"""Tests des Konfigurationsaudits IDEX/BLTouch/G28 (echter Prozess, echter Exitcode). Negativfaelle: jede Abweichung der OEM-Konfiguration muss den Exitcode != 0 erzeugen."""
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

CLAUDE = Path(__file__).resolve().parents[1]
TOOL = CLAUDE / 'tools' / 'check_idex_bltouch_config_c1.py'
OEM = CLAUDE / '01_BASELINE' / 'OEM_FILES' / 'Marlin'


def run(root=None):
    r = subprocess.run([sys.executable, '-B', str(TOOL)] + ([str(root)] if root else []), capture_output=True, text=True)
    return r.returncode, r.stdout + r.stderr


def variant(edit):
    d = Path(tempfile.mkdtemp()); shutil.copytree(OEM, d / 'Marlin'); (d / 'Marlin' / 'x').mkdir(exist_ok=True)
    for f, a, b in edit:
        p = d / 'Marlin' / f; t = p.read_text(encoding='utf-8'); lines = t.split('\n')
        whole = [i for i, l in enumerate(lines) if l == a]                                       # bevorzugt GANZE Zeile (ein #define kann Praefix eines anderen sein)
        if len(whole) == 1:
            lines[whole[0]] = b; p.write_text('\n'.join(lines), encoding='utf-8')
        else:
            assert t.count(a) == 1, (f, a); p.write_text(t.replace(a, b), encoding='utf-8')
    return d / 'Marlin'


class Audit(unittest.TestCase):
    def test_A01_the_real_oem_configuration_passes_and_the_derived_values_are_computed(self):
        rc, out = run()
        self.assertEqual(rc, 0, out[-600:]); self.assertIn('IDEX_BLTOUCH_CONFIG_AUDIT=OK fails=0 warns=3', out)
        self.assertIn('| 60 mm |', out.replace('60 mm', '| 60 mm |')); self.assertRegex(out, r'600 mm, 150 s')
        self.assertEqual(len(re.findall(r'^WARN:', out, flags=re.M)), 3); self.assertIn('motion.cpp:1810', out)

    def test_A02_a_changed_pinned_value_fails_with_a_nonzero_exit_code_and_names_the_value(self):
        for edit, name in (([('Configuration_adv.h', '#define X2_MAX_POS   362', '#define X2_MAX_POS   300')], 'X2_MAX_POS'), ([('Configuration.h', '#define Z_MAX_POS 400', '#define Z_MAX_POS 300')], 'Z_MAX_POS'),
                           ([('Configuration_adv.h', '#define X1_MAX_POS X_BED_SIZE ', '#define X1_MAX_POS 340 ')], 'X1_MAX_POS'), ([('Configuration.h', '#define Z_PROBE_END_SCRIPT "G28 XY"', '#define Z_PROBE_END_SCRIPT "G28"')], 'Z_PROBE_END_SCRIPT')):
            rc, out = run(variant(edit)); self.assertEqual(rc, 1, name); self.assertRegex(out, r'FAIL: .*' + name)

    def test_A03_a_missing_presence_define_fails_it_is_not_waved_through(self):
        for a, f, name in (('#define BLTOUCH', 'Configuration.h', 'BLTOUCH'), ('#define USE_PROBE_FOR_Z_HOMING', 'Configuration.h', 'USE_PROBE_FOR_Z_HOMING'), ('#define Z_SAFE_HOMING', 'Configuration.h', 'Z_SAFE_HOMING'), ('#define DUAL_X_CARRIAGE', 'Configuration_adv.h', 'DUAL_X_CARRIAGE')):
            txt = (OEM / f).read_text(encoding='utf-8')
            line = next(l for l in txt.split('\n') if l.lstrip().startswith(a) and l.lstrip()[len(a):len(a) + 1] in ('', ' ', '\t', '/'))
            rc, out = run(variant([(f, line, '//' + line)])); self.assertEqual(rc, 1, name); self.assertRegex(out, r'FAIL: .*' + name + r' = NICHT DEFINIERT')

    def test_A04_a_missing_file_gives_exit_code_2(self):
        d = Path(tempfile.mkdtemp()); (d / 'Marlin').mkdir()
        rc, out = run(d / 'Marlin'); self.assertEqual(rc, 2); self.assertIn('FEHLENDE DATEI', out)

    def test_A05_warnings_never_change_the_exit_code_and_the_zraise_note_names_its_condition(self):
        rc, out = run(variant([('Configuration_adv.h', '#define TOOLCHANGE_ZRAISE                 0 // (mm)', '#define TOOLCHANGE_ZRAISE                 5 // (mm)')]))
        self.assertEqual(rc, 0, out[-400:]); self.assertEqual(len(re.findall(r'^WARN:', out, flags=re.M)), 2, 'bei 5 mm entfaellt genau der Hinweis auf 0 mm')
        self.assertIn('HAS_MULTI_EXTRUDER', run()[1])


if __name__ == '__main__':
    unittest.main(verbosity=2)
