"""Auswertung der Buildergebnisse (synthetische Artefaktbaeume, echter Prozess, echter Exitcode): positive UND negative Faelle. Es werden KEINE echten Buildergebnisse erfunden: die Daten sind ausdruecklich synthetisch."""
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

TOOL = Path(__file__).resolve().parents[1] / 'tools' / 'evaluate_c7_builds.py'
OKLOG = 'Processing STM32F103RET6_creality\nCompiling .pio/build/x.o\nRAM:   [=         ]  {rp}% (used {ru} bytes from 20480 bytes)\nFlash: [====      ]  {fp}% (used {fu} bytes from 524288 bytes)\n========================= [SUCCESS] Took 100.00 seconds =========================\n'


def make(root, tree, profile, exit_code, log=None, result_extra=None):
    d = Path(root) / ('art_' + tree) / 'evidence' / tree / profile; d.mkdir(parents=True, exist_ok=True)
    kv = {'BUILD_TREE': tree, 'PROFILE': profile, 'BUILD_EXIT': exit_code, 'FLASH_ALLOWED': 'NO', 'HARDWARE_TESTED': 'NO'}
    (d / 'result.txt').write_text('\n'.join(f'{k}={v}' for k, v in kv.items() if v is not None) + '\n')
    if log is not None: (d / 'build.log').write_text(log)
    elif (d / 'build.log').exists(): (d / 'build.log').unlink()                    # "kein Log" bedeutet: es existiert wirklich keines


def run(root, *a):
    r = subprocess.run([sys.executable, '-B', str(TOOL), str(root)] + list(a), capture_output=True, text=True); return r.returncode, r.stdout


def allpass(root, bump=0):
    for t in ('control_309', 'modified_318'):
        for p in ('integrated_backend', 'integrated_failclosed'):
            n = 11028 + (bump if t == 'modified_318' else 0); make(root, t, p, 0, OKLOG.format(rp='53.8', ru=n, fp='44.1', fu=231148 + (bump if t == 'modified_318' else 0)))


class Evaluate(unittest.TestCase):
    def test_E701_all_four_combinations_pass_exit_0_and_the_deltas_are_computed(self):
        d = tempfile.mkdtemp(); allpass(d, bump=96); rc, out = run(d); self.assertEqual(rc, 0, out)
        self.assertIn('GESAMTERGEBNIS=BUILD_OK_ALLE_4_KOMBINATIONEN', out); self.assertEqual(out.count('**PASS**'), 4); self.assertIn('RAM +96 B, Flash +96 B', out); self.assertIn('FLASH_ALLOWED=NO', out)

    def test_E702_a_failed_profile_shows_the_first_real_compiler_errors_with_file_and_line_and_is_never_a_success(self):
        d = tempfile.mkdtemp(); allpass(d)
        make(d, 'modified_318', 'integrated_failclosed', 1, 'Compiling x\nMarlin/src/module/motion.cpp:1829:45: error: \'max_length\' was not declared in this scope\nMarlin/src/gcode/bedlevel/abl/G29.cpp:70:3: fatal error: MarlinCore.h: No such file or directory\nfoo.cpp:1:1: warning: unused\n*** [.pio/build/x.o] Error 1\n========================= [FAILED] Took 3.1 seconds =========================\n')
        rc, out = run(d); self.assertEqual(rc, 3); self.assertIn('NICHT_BESTANDEN (3 von 4', out); self.assertIn('**FAIL**', out); self.assertIn("motion.cpp:1829:45: error: 'max_length' was not declared", out); self.assertIn('G29.cpp:70:3: fatal error', out); self.assertNotIn('BUILD_OK', out)

    def test_E703_exit_0_without_the_success_marker_or_without_ram_flash_is_incomplete_not_a_pass(self):
        for log, why in (('Compiling\n', 'ohne PlatformIO-[SUCCESS]-Marker'), ('[SUCCESS]\n', 'keine RAM-/Flash-Zeilen')):
            d = tempfile.mkdtemp(); allpass(d); make(d, 'control_309', 'integrated_backend', 0, log); rc, out = run(d); self.assertEqual(rc, 3); self.assertIn('**INCOMPLETE**', out); self.assertIn(why, out); self.assertNotIn('BUILD_OK', out)
        d = tempfile.mkdtemp(); allpass(d); make(d, 'control_309', 'integrated_backend', 0, None); rc, out = run(d); self.assertEqual(rc, 3); self.assertIn('kein build.log', out)

    def test_E704_missing_combinations_are_reported_missing_and_an_empty_tree_is_blocked_with_exit_2(self):
        d = tempfile.mkdtemp()
        for p in ('integrated_backend', 'integrated_failclosed'): make(d, 'control_309', p, 0, OKLOG.format(rp='53.8', ru=11028, fp='44.1', fu=231148))
        rc, out = run(d); self.assertEqual(rc, 3); self.assertEqual(out.count('**MISSING**'), 2); self.assertIn('2 von 4', out)
        e = tempfile.mkdtemp(); rc, out = run(e); self.assertEqual(rc, 2); self.assertIn('BLOCKED_KEINE_ERGEBNISDATEIEN', out); self.assertNotIn('BUILD_OK', out)
        rc, out = run(Path(e) / 'gibt_es_nicht'); self.assertEqual(rc, 2)

    def test_E705_a_malformed_result_file_is_incomplete_and_does_not_crash(self):
        d = tempfile.mkdtemp(); allpass(d); make(d, 'modified_318', 'integrated_backend', None, OKLOG.format(rp='1', ru=1, fp='1', fu=1)); rc, out = run(d); self.assertEqual(rc, 3); self.assertIn('ohne gueltiges BUILD_EXIT', out)
        make(d, 'modified_318', 'integrated_backend', 'abc', OKLOG.format(rp='1', ru=1, fp='1', fu=1)); rc, out = run(d); self.assertEqual(rc, 3)

    def test_E706_warnings_are_counted_but_never_turn_a_pass_into_a_fail_and_an_unexpected_result_is_not_counted(self):
        d = tempfile.mkdtemp(); allpass(d); make(d, 'control_309', 'integrated_backend', 0, 'x.cpp:1: warning: a\ny.cpp:2: warning: b\n' + OKLOG.format(rp='1', ru=1, fp='1', fu=1)); make(d, 'sonstiger_baum', 'integrated_backend', 0, OKLOG.format(rp='1', ru=1, fp='1', fu=1))
        rc, out = run(d); self.assertEqual(rc, 0, out); self.assertIn('| 0 | 2 |', out); self.assertIn('Unerwartete Ergebnisse', out)

    def test_E707_the_out_file_is_written_and_contains_the_same_verdict(self):
        d = tempfile.mkdtemp(); allpass(d); o = Path(d) / 'sub' / 'EVALUATION.md'; rc, out = run(d, '--out', str(o)); self.assertEqual(rc, 0); self.assertIn('GESAMTERGEBNIS=BUILD_OK_ALLE_4_KOMBINATIONEN', o.read_text())


if __name__ == '__main__':
    unittest.main(verbosity=2)
