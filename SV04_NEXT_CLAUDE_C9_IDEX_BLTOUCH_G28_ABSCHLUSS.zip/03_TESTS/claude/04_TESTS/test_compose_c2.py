"""Reproduzierbarkeit (Auftrag 1/6): die vier Claude-Quelldateien des gemeinsamen Stands entstehen BYTEGLEICH aus Claudes unveraenderten 285-Dateien + ChatGPTs Patches
(Merge 299, EEPROM 292/293/294, dann Kern 300-301-304 und Adapter 302-303-305) + Claudes zwei C2-Patches (Heizungssperre nach stop(), Werkzeugwechsel-Schutz in T.cpp). Claude aendert KEINE Datei von ChatGPT. Host-Test, KEIN STM32-Build."""
import contextlib
import hashlib
import io
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

CLAUDE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(CLAUDE / '04_TESTS' / 'sim')); sys.path.insert(0, str(CLAUDE / '03_PATCHES' / 'chatgpt_299'))
import chain_tree as T  # noqa: E402
import apply_eeprom_commit_guard_293 as C293  # noqa: E402
import apply_eeprom_coordinator_294 as K294  # noqa: E402
import apply_eeprom_policy_292 as P292  # noqa: E402
import apply_g29_merge_299 as M299  # noqa: E402

D305 = CLAUDE / '03_PATCHES' / 'chatgpt_305'
REL = {'inc': 'Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc', 'hooks': 'Marlin/src/lcd/e3v2/creality/sv04_claude_hooks.h', 'core': 'Marlin/src/feature/sv04_claude_auto60/sv04_claude_auto60_core.h',
       'eecore': 'Marlin/src/feature/sv04_claude_auto60/sv04_claude_eeprom_core.h', 'session': 'Marlin/src/feature/sv04_claude_auto60/sv04_claude_g29_session.h', 'g29': 'Marlin/src/gcode/bedlevel/abl/G29.cpp'}
SRC = CLAUDE / '02_SOURCE'


def run(script, target):
    r = subprocess.run([sys.executable, '-B', str(script), str(target)], capture_output=True, text=True)
    return r.returncode, (r.stdout + r.stderr).strip()


def stage(root):
    """Zustand nach den Patches 292-294 + Merge 299 (ChatGPT) auf Claudes 285-Dateien, ohne die Kette 300-305."""
    b5 = CLAUDE / '01_BASELINE' / 'STAND_285'
    for n, k in (('sv04_claude_auto60_marlin.inc', 'inc'), ('sv04_claude_hooks.h', 'hooks'), ('sv04_claude_auto60_core.h', 'core')):
        (root / REL[k]).parent.mkdir(parents=True, exist_ok=True); shutil.copy(b5 / n, root / REL[k])
    d = T.integ(str(root / 'mk'), g29_cancel=False)
    (root / REL['g29']).parent.mkdir(parents=True, exist_ok=True); shutil.copy(d['integ'] / REL['g29'], root / REL['g29'])
    r = subprocess.run(['patch', '-p1', '--no-backup-if-mismatch', '-d', str(root), '-i', str(CLAUDE / '03_PATCHES' / 'g29_cancel_v1_289.patch')], capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr
    shutil.copy(SRC / 'Marlin/src/feature/sv04_claude_auto60/sv04_claude_g29_session.h', root / REL['session'])
    with contextlib.redirect_stdout(io.StringIO()):
        M299.main(root)
    a = root / REL['inc']; s, _ = P292.apply(a.read_text()); s, _ = C293.apply(s); a.write_text(s)
    c = root / REL['core']; k, _ = K294.apply(c.read_text()); c.write_text(k)


def chain(root, ec_src):
    """Kette 300-305. Der EEPROM-Kern von 283 ist Ausgangspunkt; er wird aus dem Paket-Original (STAND_283-Kern ist nicht gefuehrt) durch die Patches umgeformt, deshalb wird er als Rohdatei uebergeben."""
    (root / REL['eecore']).write_text(ec_src, encoding='utf-8')
    rcs = [run(D305 / 'apply_eeprom_blank_guard_300.py', root / REL['eecore'])[0], run(D305 / 'apply_eeprom_boot_recovery_301.py', root / REL['eecore'])[0], run(D305 / 'apply_eeprom_commit_failclosed_304.py', root / REL['eecore'])[0], run(D305 / 'apply_eeprom_unverified_valid_306.py', root / REL['eecore'])[0],
           run(D305 / 'apply_eeprom_post_boot_302.py', root / REL['inc'])[0], run(D305 / 'apply_eeprom_display_guard_303.py', root / REL['inc'])[0], run(D305 / 'apply_refusal_305.py', root)[0],
           run(CLAUDE / '03_PATCHES' / 'apply_stop_heater_guard_c2.py', root)[0], run(CLAUDE / '03_PATCHES' / 'apply_start_release_c4.py', root)[0], run(CLAUDE / '03_PATCHES' / 'apply_zgate_c5.py', root)[0]]
    return rcs


class ComposeC2(unittest.TestCase):
    def test_R01_chatgpt_scripts_are_unchanged_copies_with_recorded_hashes(self):
        for d, f in ((CLAUDE / '03_PATCHES' / 'chatgpt_299', 'SHA256SUMS_VON_A_299.txt'), (D305, 'SHA256SUMS_VON_300_BIS_306.txt')):
            for line in (d / f).read_text().splitlines():
                h, name = line.split()
                self.assertEqual(hashlib.sha256((d / name).read_bytes()).hexdigest(), h, name)

    def test_R02_the_four_claude_sources_are_reproduced_byte_for_byte_from_285_plus_the_whole_chain(self):
        eec283 = (CLAUDE / '01_BASELINE' / 'STAND_283_EEPROM_KERN' / 'sv04_claude_eeprom_core.h').read_text(encoding='utf-8')
        with tempfile.TemporaryDirectory() as t:
            root = Path(t); stage(root)
            self.assertEqual(chain(root, eec283), [0] * 10, 'alle Patches 300-306, der C2-, C4- und C5-Patch lassen sich anwenden')
            for key in ('core', 'eecore'):
                self.assertEqual((root / REL[key]).read_bytes(), (SRC / REL[key]).read_bytes(), key + ': 02_SOURCE == Rekonstruktion aus meiner Kette')
            # C6: Adapter und hooks.h sind seit 318 ChatGPTs Dateien (317-Adapter, 309-hooks.h) und entstehen NICHT aus meiner Kette: sie werden gegen die gepinnten 318-Dateien geprueft
            B318 = CLAUDE / '01_BASELINE' / 'STAND_318'; pins = dict(reversed(l.split()) for l in (B318 / 'SHA256SUMS.txt').read_text().splitlines())
            for key, name in (('inc', 'sv04_claude_auto60_marlin.inc'), ('hooks', 'sv04_claude_hooks.h'), ('core', 'sv04_claude_auto60_core.h'), ('eecore', 'sv04_claude_eeprom_core.h')):
                self.assertEqual(hashlib.sha256((SRC / REL[key]).read_bytes()).hexdigest(), pins[name], key + ': 02_SOURCE == gepinnte 318-Datei'); self.assertEqual((SRC / REL[key]).read_bytes(), (B318 / name).read_bytes())

    def test_R03_every_chatgpt_patch_refuses_a_second_application_or_leaves_the_source_unchanged(self):
        with tempfile.TemporaryDirectory() as t:
            root = Path(t)
            for k in ('inc', 'hooks', 'core', 'eecore'):
                (root / REL[k]).parent.mkdir(parents=True, exist_ok=True); shutil.copy(SRC / REL[k], root / REL[k])
            before = {k: (root / REL[k]).read_bytes() for k in ('inc', 'hooks', 'core', 'eecore')}
            run(D305 / 'apply_eeprom_blank_guard_300.py', root / REL['eecore']); run(D305 / 'apply_eeprom_boot_recovery_301.py', root / REL['eecore']); run(D305 / 'apply_eeprom_commit_failclosed_304.py', root / REL['eecore']); run(D305 / 'apply_eeprom_unverified_valid_306.py', root / REL['eecore'])
            run(D305 / 'apply_eeprom_post_boot_302.py', root / REL['inc']); run(D305 / 'apply_eeprom_display_guard_303.py', root / REL['inc']); run(D305 / 'apply_refusal_305.py', root)
            for k in before:
                self.assertEqual((root / REL[k]).read_bytes(), before[k], k + ': eine zweite Anwendung veraendert nichts')

    def test_R04_the_refusal_names_its_reason_exactly_once_and_the_post_boot_display_resend_is_kept(self):
        s = (SRC / REL['inc']).read_text()
        self.assertEqual(s.count('Start verweigert, kein Platz fuer das Undo-Journal'), 1)
        self.assertIsNotNone(re.search(r'if \(r == sv04c::ee::BR_RESTORED && !sv04c_ee_boot_blocked\)\s+sv04c_send_oem_mesh\(\);', s))


if __name__ == '__main__':
    unittest.main(verbosity=2)
