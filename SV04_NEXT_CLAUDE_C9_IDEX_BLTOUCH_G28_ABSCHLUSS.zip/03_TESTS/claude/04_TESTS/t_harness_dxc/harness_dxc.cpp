// Aufruf: ./h <mode> <new_tool> <active> <no_move> <x_ok> <running> <cur_x> <delayed>
#include <cstdlib>
#include "stub_dxc.h"
DualXMode dual_x_carriage_mode = DXC_AUTO_PARK_MODE; uint8_t active_extruder = 0; bool active_extruder_parked = false; float inactive_extruder_x = 0; uint32_t delayed_move_time = 0;
Pos current_position = {0, 0, 0}, destination = {0, 0, 0}; uint8_t axis_homed = 0, axis_trusted = 0; std::string g_log; bool g_running = true; SPlanner planner; SStepper stepper;
#include "dxc_function.inc"          // die ECHTE Funktion, woertlich aus tool_change.cpp extrahiert
int main(int, char **a) {
  dual_x_carriage_mode = (DualXMode)std::atoi(a[1]); const uint8_t nt = (uint8_t)std::atoi(a[2]); active_extruder = (uint8_t)std::atoi(a[3]); bool nm = std::atoi(a[4]) != 0; const int xok = std::atoi(a[5]); g_running = std::atoi(a[6]) != 0;
  current_position.x = (float)std::atof(a[7]); destination.x = 111; delayed_move_time = (uint32_t)std::atoi(a[8]); planner.settings.max_feedrate_mm_s[0] = 200;
  axis_homed = (xok == 1 || xok == 2) ? 1 : 0; axis_trusted = (xok == 1 || xok == 3) ? 1 : 0;      // x_ok: 0 nichts, 1 beides, 2 nur referenziert, 3 nur vertrauenswuerdig
  dualx_tool_change(nt, nm);
  std::printf("active=%d x_homed=%d x_trusted=%d cur_x=%.1f no_move=%d parked=%d log=%s\n", (int)active_extruder, (int)axis_was_homed(X_AXIS), (int)axis_is_trusted(X_AXIS), current_position.x, (int)nm, (int)active_extruder_parked, g_log.c_str());
  return 0;
}
