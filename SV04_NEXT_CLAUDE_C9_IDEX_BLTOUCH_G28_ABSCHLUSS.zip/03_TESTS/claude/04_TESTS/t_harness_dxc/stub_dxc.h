#pragma once
// Attrappen fuer die ECHTE, aus tool_change.cpp extrahierte Funktion dualx_tool_change(). Die Semantik von set_axis_is_at_home() ist die des echten motion.cpp (trusted+homed setzen, X-Position setzen).
#include <cstdint>
#include <cstdio>
#include <string>
enum DualXMode { DXC_FULL_CONTROL_MODE = 0, DXC_AUTO_PARK_MODE = 1, DXC_DUPLICATION_MODE = 2, DXC_MIRRORED_MODE = 3 };
enum AxisEnum { X_AXIS = 0, Y_AXIS = 1, Z_AXIS = 2 };
struct Pos { float x, y, z; };
extern DualXMode dual_x_carriage_mode; extern uint8_t active_extruder; extern bool active_extruder_parked; extern float inactive_extruder_x; extern uint32_t delayed_move_time;
extern Pos current_position, destination; extern uint8_t axis_homed, axis_trusted; extern std::string g_log; extern bool g_running;
inline bool IsRunning() { return g_running; }
inline float x_home_pos(int e) { return e ? 362.0f : -62.0f; }
inline void line_to_current_position(float) { g_log += "park_move;"; }
struct SPlanner { struct { float max_feedrate_mm_s[3]; } settings; void synchronize() {} };
extern SPlanner planner;
inline void set_axis_is_at_home(AxisEnum a) { axis_trusted |= (1 << a); axis_homed |= (1 << a); if (a == X_AXIS) current_position.x = x_home_pos(active_extruder); g_log += "set_axis_is_at_home(X);"; }
inline bool axis_was_homed(AxisEnum a) { return (axis_homed >> a) & 1; }
inline bool axis_is_trusted(AxisEnum a) { return (axis_trusted >> a) & 1; }
inline void set_axis_unhomed(AxisEnum a) { axis_homed &= ~(1 << a); }
inline void set_axis_untrusted(AxisEnum a) { axis_trusted &= ~(1 << a); }
inline void idex_set_parked(bool = true) { g_log += "idex_set_parked;"; active_extruder_parked = true; }
struct SStepper { void set_directions() { g_log += "dirs;"; } };
extern SStepper stepper;
#define DEBUG_ECHOPGM(...) do {} while (0)
#define DEBUG_ECHOLNPGM(...) do {} while (0)
#define DEBUG_POS(...) do {} while (0)
