"""Buildauswertung C9 gegen die ECHTEN Ergebnisdaten des erfolgreichen GitHub-Laufs 43484048208 (Fehlerbehebung zu C7: BUILD_TREE heisst oem/oem318)."""
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

CL = Path(__file__).resolve().parents[1]; REAL = CL / '04_TESTS/real_data_run_43484048208'; NEW = CL / 'tools/evaluate_builds_c9.py'; OLD = CL / 'tools/evaluate_c7_builds.py'


def run(tool, root, *a):
    r = subprocess.run([sys.executable, '-B', str(tool), str(root)] + list(a), capture_output=True, text=True); return r.returncode, r.stdout


def copy_real():
    d = Path(tempfile.mkdtemp()) / 'r'; shutil.copytree(REAL, d); return d


class RealData(unittest.TestCase):
    def test_E901_the_real_run_is_four_of_four_pass_with_exactly_the_logged_numbers_and_deltas(self):
        rc, out = run(NEW, REAL); self.assertEqual(rc, 0, out); self.assertIn('GESAMTERGEBNIS=BUILD_OK_ALLE_4_KOMBINATIONEN', out); self.assertEqual(out.count('**PASS**'), 4)
        for needle in ('11100/65536 B (16.9%) | 176236/524288 B (33.6%)', '11080/65536 B (16.9%) | 174988/524288 B (33.4%)', '11112/65536 B (17.0%) | 177620/524288 B (33.9%)', '11092/65536 B (16.9%) | 176380/524288 B (33.6%)', 'RAM +12 B, Flash +1384 B', 'RAM +12 B, Flash +1392 B', 'FLASH_ALLOWED=NO'): self.assertIn(needle, out)

    def test_E902_the_old_tree_names_are_read_as_aliases_and_the_c7_tool_is_documented_as_wrong_on_these_data(self):
        rc, out = run(NEW, REAL, '--trees', 'control_309,modified_318'); self.assertEqual(rc, 0); self.assertIn('BUILD_OK_ALLE_4', out)
        rc, out = run(OLD, REAL); self.assertEqual(rc, 3); self.assertIn('NICHT_BESTANDEN (0 von 4', out); self.assertIn('Unerwartete Ergebnisse', out)        # der C7-Fehler: fail-closed, aber falsch negativ

    def test_E903_a_required_third_tree_that_has_no_results_is_missing_and_never_a_success(self):
        rc, out = run(NEW, REAL, '--trees', 'oem318,oem_c9'); self.assertEqual(rc, 3); self.assertEqual(out.count('**MISSING**'), 2); self.assertIn('2 von 4', out); self.assertNotIn('BUILD_OK', out)

    def test_E904_a_tampered_real_log_without_the_success_marker_is_incomplete_not_a_pass(self):
        d = copy_real(); f = d / 'oem318/integrated_backend/build.log'; f.write_text(f.read_text().replace('[SUCCESS]', '[ABGEBROCHEN]')); rc, out = run(NEW, d); self.assertEqual(rc, 3); self.assertIn('**INCOMPLETE**', out); self.assertIn('ohne PlatformIO-[SUCCESS]-Marker', out)

    def test_E905_a_failed_exit_code_with_real_compiler_lines_shows_the_first_errors_with_file_and_line(self):
        d = copy_real(); (d / 'oem318/integrated_failclosed/result.txt').write_text((d / 'oem318/integrated_failclosed/result.txt').read_text().replace('BUILD_EXIT=0', 'BUILD_EXIT=1'))
        f = d / 'oem318/integrated_failclosed/build.log'; f.write_text(f.read_text() + "Marlin/src/gcode/control/M999.cpp:41:7: error: 'set_all_unhomed' was not declared in this scope\n*** [.pio/build/x/M999.cpp.o] Error 1\n"); rc, out = run(NEW, d)
        self.assertEqual(rc, 3); self.assertIn('**FAIL**', out); self.assertIn("M999.cpp:41:7: error: 'set_all_unhomed' was not declared", out); self.assertIn('NICHT_BESTANDEN (3 von 4', out)

    def test_E906_empty_and_missing_roots_are_blocked_with_exit_2(self):
        self.assertEqual(run(NEW, tempfile.mkdtemp())[0], 2); self.assertEqual(run(NEW, Path(tempfile.mkdtemp()) / 'gibts_nicht')[0], 2); self.assertEqual(run(NEW, REAL, '--trees', '')[0], 2)


if __name__ == '__main__':
    unittest.main(verbosity=2)
