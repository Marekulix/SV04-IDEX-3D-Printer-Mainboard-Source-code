"""MUTATIONSTESTS (Empfindlichkeit): gezielte Fehler in den Kern und in den Marlin-Adapter einbauen; die Tests muessen sie finden.
Kern: Mutant wird gegen die 122+ C++-Kerntests geprueft (erkannt = Testlauf scheitert oder Build bricht).
Adapter: Mutant wird in die Patchkette (apply_claude_parallel.py) + Kettensimulation eingebaut; erkannt = Verhalten in einer festen Szenarioliste weicht vom unmutierten Stand ab.
Gleichwertige Mutanten sind getrennt und begruendet. Ergebnis: tests/LAST_MUTATION_REPORT_a60.txt"""
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / '03_PATCHES'))
sys.path.insert(0, str(HERE / 'sim'))
import apply_claude_parallel as P  # noqa: E402
import build_sim_a60 as B  # noqa: E402
import chain_tree as T  # noqa: E402

CORE = Path('02_SOURCE/Marlin/src/feature/sv04_claude_auto60/sv04_claude_auto60_core.h')
INC = Path('02_SOURCE/Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc')
OEM = ROOT / '01_BASELINE' / 'OEM_FILES' / 'Marlin' / 'src'

CORE_MUTANTS = [
    ('C01 Fenstergrenze exklusiv statt inklusiv', "fabsf(b.temp_c - c_.bed_target_c) <= c_.band_c", "fabsf(b.temp_c - c_.bed_target_c) < c_.band_c"),
    ('C02 Stabilitaetszeit wird beim Verlassen des Fensters nicht zurueckgesetzt', "if (!in_band(b)) stable_since_ = 0;", "if (false) stable_since_ = 0;"),
    ('C03 Start trotz laufendem Druck erlaubt', "    if (q.printing) return R_PRE_PRINTING;\n    if (q.paused) return R_PRE_PAUSED;\n    if (q.moving)", "    if (q.paused) return R_PRE_PAUSED;\n    if (q.moving)"),
    ('C04 Z-Offset-Pruefung vor dem Speichern entfernt', "    if (fabsf(p_.zoffset(p_.ctx) - zoff0_) > c_.zoffset_tol) { fail(R_ZOFFSET_CHANGED); return; }\n    bool act", "    bool act"),
    ('C05 Mesh-Unveraendertheit vor dem Speichern entfernt', "    if (!mesh_same(ram, validated_)) { fail(R_MESH_CHANGED); return; }\n    if (fabsf(p_.zoffset", "    if (fabsf(p_.zoffset"),
    ('C06 Pruefung "Nivellierung aktiv" nach M420 entfernt', "    if (!act || !val) { fail(R_M420_NOT_ACTIVE); return; }\n    MeshImage ram; p_.mesh_read(p_.ctx, ram);\n    if (!mesh_same(ram, validated_)) { fail(R_MESH_CHANGED); return; }\n    m420_enabled_", "    MeshImage ram; p_.mesh_read(p_.ctx, ram);\n    if (!mesh_same(ram, validated_)) { fail(R_MESH_CHANGED); return; }\n    m420_enabled_"),
    ('C07 SUCCESS ohne Mesh-Gleichheit der Ruecklesung', "ev.readback_ok && ev.mesh_equal && ev.zoff_equal", "ev.readback_ok && ev.zoff_equal"),
    ('C08 SUCCESS ohne Z-Offset-Gleichheit der Ruecklesung', "ev.mesh_equal && ev.zoff_equal && ev.version_ok", "ev.mesh_equal && ev.version_ok"),
    ('C09 "Ruecklesung nicht verfuegbar" gilt nicht als Fehler', "    if (ev.validate_ok && !avail) { fail(R_VERIFY_UNAVAILABLE); return; }", "    if (ev.validate_ok && !avail) { go(ST_SUCCESS, R_VERIFIED); return; }"),
    ('C10 IDEX-Gate-Nachweis wird nicht verlangt', "(c_.require_idex_gate && !ev.idex_gate_confirmed)", "false"),
    ('C11 Trockenlauf gilt als Erfolg', "if (!r.success || r.dryrun || r.faux) { fail(R_PROBE_FAILED); return; }", "if (!r.success || r.faux) { fail(R_PROBE_FAILED); return; }"),
    ('C12 Messreihenfolge wird nicht geprueft', "else if (point_no(ix, iy) != n_) e = ME_ORDER;", "else if (false) e = ME_ORDER;"),
    ('C13 Veraltete RAM-Werte werden nicht erkannt', "      if (memcmp(&ram.z[p.ix][p.iy], &p.stored_z, sizeof(float)) != 0) return R_MESH_STALE;", "      if (false) return R_MESH_STALE;"),
    ('C14 cancel() bricht die Wiederherstellung nach dem ersten save() ab', "      case ST_SAVE_PENDING: if (!save_issued_) cancelled(R_USER_CANCEL); break;   // nach save(): nicht abbrechbar", "      case ST_SAVE_PENDING: cancelled(R_USER_CANCEL); break;"),
    ('C15 Rollback des ungepruefen Meshes entfaellt', "    if (p_.rollback_mesh && mesh_touched_ && (!m420_enabled_ || after) && !save_issued_", "    if (false && p_.rollback_mesh && mesh_touched_ && (!m420_enabled_ || after) && !save_issued_"),
    ('C16 Wiederholung des save() auch bei reinem Nivellierungsproblem', "if (why != R_VERIFY_LEVELING && save_attempts_ <= c_.max_save_retries) {", "if (save_attempts_ <= c_.max_save_retries) {"),
    ('C17 Bett-Soll wird bei Endzustaenden nicht wiederhergestellt', "  void restore_heater() { if (c_.restore_heater_on_exit && p_.bed_set_target)", "  void restore_heater() { if (false && p_.bed_set_target)"),
    ('C18 G29-Beginn-Frist entfernt', "if (st_ == ST_PROBING && !g29_begun_ && t - enter_ms_ > c_.g29_begin_grace_ms && p_.cmd_idle(p_.ctx))", "if (false)"),
    ('C19 Messpunkte ohne G29-Beginn werden uebernommen', "if (st_ != ST_PROBING || sid != sid_ || !g29_begun_) { ++stale_events_; return; }", "if (st_ != ST_PROBING || sid != sid_) { ++stale_events_; return; }"),
    ('C20 Betragsgrenze exklusiv statt inklusiv (abs_limit)', "fabsf(p.raw_z) > c.abs_limit_mm || fabsf(p.stored_z) > c.abs_limit_mm", "fabsf(p.raw_z) >= c.abs_limit_mm || fabsf(p.stored_z) >= c.abs_limit_mm"),
    ('C21 Spannweitengrenze exklusiv statt inklusiv', "if (mx - mn > c.spread_limit_mm) return R_MESH_OUTLIER;", "if (mx - mn >= c.spread_limit_mm) return R_MESH_OUTLIER;"),
    ('C22 Fremde Sitzung bei Homing-Ergebnis wird akzeptiert', "if (st_ != ST_HOMING_PENDING || sid != sid_) { ++stale_events_; return; }", "if (st_ != ST_HOMING_PENDING) { ++stale_events_; return; }"),
    ('C23 Zweiter Start waehrend des Laufs erlaubt', "    if (active()) return R_PRE_ALREADY_RUNNING;\n", ""),
    ('C24 Sitzungs-Reset beim Neustart laesst alte Ereignisse zu', "    mesh_.begin(0); mesh_.invalidate(); memset(&validated_, 0, sizeof validated_);", "    memset(&validated_, 0, sizeof validated_);"),
]
CORE_EQUIVALENT = [
    ('E-C14 Pruefung cancel_pending_ in do_save() entfernt', "if (cancel_pending_ && !save_issued_) { cancelled(R_USER_CANCEL); return; }", "if (false) { cancelled(R_USER_CANCEL); return; }",
     'Unerreichbar: cancel() setzt cancel_pending_ nur in HOMING_PENDING/PROBING/ENABLING; do_enable() verbraucht es, bevor SAVE_PENDING betreten wird. Der wirksame Schutz sitzt in cancel() (Mutant C14).'),
]

ADAPTER_MUTANTS = [
    ('A01 Nivellierung wird nach der G29 NICHT wieder ausgeschaltet (OEM-Aktivierung unvalidiert)', "ST_VALIDATING) set_bed_leveling_enabled(false);   // G29.cpp:883", "ST_VALIDATING) { }   // G29.cpp:883"),
    ('A02 Haken ohne Sperrabschnitt (Tick mitten im Haken)', "void SV04Claude_G29Complete(const uint32_t id, const bool successful, const bool dryrun, const bool faux) {\n  Sv04cSection sv04c_section;\n", "void SV04Claude_G29Complete(const uint32_t id, const bool successful, const bool dryrun, const bool faux) {\n"),
    ('A03 Rollback stellt den Nivellierungszustand nicht her', "  if (planner.leveling_active != sv04c_lev_at_begin) set_bed_leveling_enabled(sv04c_lev_at_begin);   // Zustand wie VOR dem Lauf\n", ""),
    ('A04 Rollback bei ungueltigem Auto60-Lauf entfaellt vollstaendig (vor UND nach der Meldung)', None, lambda t: _both(t, "if (!predicted_ok) sv04c_g29_apply(sv04g29::DEC_ROLLBACK);", "if (false) sv04c_g29_apply(sv04g29::DEC_ROLLBACK);", "else sv04c_g29_apply(sv04g29::DEC_ROLLBACK);", "else { }")),
    ('A04b Rollback erst NACH der Ergebnismeldung (Fehlerseite mit veralteten Zahlen)', "      if (!predicted_ok) sv04c_g29_apply(sv04g29::DEC_ROLLBACK); ", "      if (false) sv04c_g29_apply(sv04g29::DEC_ROLLBACK); "),
    ('A05 DWIN-Touch wird waehrend des Laufs nicht gesperrt', "bool SV04Claude_Auto60_Busy() { return sv04c_coord.running(); }", "bool SV04Claude_Auto60_Busy() { return false; }"),
    ('A07 DWIN-Konflikt wird nicht als Startsperre gemeldet', "  p.dwin_busy = (waitway != 0);", "  p.dwin_busy = false;"),
    ('A08 Z-Vertrauen wird nicht aus dem Marlin-Zustand gelesen', "ev.z_trusted = axis_is_trusted(Z_AXIS);", "ev.z_trusted = true;"),
    ('A09 Laufender Druck wird nicht erkannt', "  p.printing = card.isPrinting() || PrintFlag != 0 || PoweroffContinue;", "  p.printing = false;"),
    ('A10 Vorbedingung "Backend vorhanden" entfaellt (Variante OHNE Backend)', "  p.home_backend_available = (SV04_CLAUDE_HOME_BACKEND_AVAILABLE != 0);", "  p.home_backend_available = true;", 'nobackend'),
    ('A11 Fremde G29 waehrend Auto60 wird nicht gemeldet', "    else if (sv04c_coord.running()) sv04c_coord.on_g29_begin(0);", "    else if (false) sv04c_coord.on_g29_begin(0);"),
    ('A12 Fehler: statt der Fehlerseite wird die Erfolgsseite angezeigt (317)', "        rtscheck.RTS_SndData(ExchangePageBase + SV04_CLAUDE_PAGE_FAIL, ExchangepageAddr);\n      }\n      sv04c_page_changed = false;", "        rtscheck.RTS_SndData(ExchangePageBase + SV04_CLAUDE_PAGE_SUCCESS, ExchangepageAddr);\n      }\n      sv04c_page_changed = false;"),
    ('A13 C6: die Erfolgsseite erscheint auch bei offenem Undo-Journal oder gesperrtem EEPROM (317)', "      if (e.state == sv04c::ST_SUCCESS && !sv04c_ee_boot_blocked && sv04c_ee_journal != 1) {", "      if (e.state == sv04c::ST_SUCCESS) {"),
]
ADAPTER_EQUIVALENT = [
    ('E1 zweite Sperre: ablehnende Huelle des Backends liefert true (Variante OHNE Backend)', "bool SV04Claude_HomeBackendRequest(const uint32_t) { return false; }                      // fail-closed: Auto60 startet nie (PRE_HOME_BACKEND_MISSING)", "bool SV04Claude_HomeBackendRequest(const uint32_t) { return true; }                       // fail-closed: Auto60 startet nie (PRE_HOME_BACKEND_MISSING)", 'nobackend',
     'Verteidigung in der Tiefe: die Vorbedingung home_backend_available=false lehnt den Start schon vorher ab, home_request() wird nie erreicht; die zweite Sperre ist nur bei Entfernen BEIDER wirksam (A10).'),
]
SIGNATURE_NOBACKEND = [('limit_s=400',), ('manual_g29=1', 'nostart=1', 'nan_at=9')]
SIGNATURE = [('old',), ('nan_at=9',), ('val_at=5', 'val=12'), ('val_at=5', 'val=45'), ('kick_after_probe=6', 'kick=40'), ('cancel_at=PROBING',), ('save=3',), ('m420_noop=1',), ('printing=1',), ('waitway=1',), ('home=noz',),
             ('manual_g29=1', 'nostart=1', 'nan_at=9'), ('foreign_g29_at_s=50', 'home_ms=60000', 'limit_s=200'), ('lev0=0', 'val_at=5', 'val=12'), ('save=1',)]
KEYS = ('RESULT', 'LOG', 'EE', 'RAM', 'HMI', 'HMIPAGE', 'HMIMULTI', 'CMDS', 'MESH', 'BUSY', 'SERIAL', 'WIREHEX')


def _both(t, a1, b1, a2, b2):
    assert t.count(a1) == 1 and t.count(a2) == 1, (t.count(a1), t.count(a2))
    return t.replace(a1, b1).replace(a2, b2)


def sig(exe, scen=None):
    out = []
    for a in (scen or SIGNATURE):
        args = [x for x in a if x != 'old']
        r = B.scenario(exe, *args)
        out.append(tuple(r.get(k, '') for k in KEYS))
    return out


def integ_with_source(source_root):
    """Integrierter Stand (276 + Stufe 1 + Overlay) mit einem ANDEREN 02_SOURCE (fuer Mutanten); die Stufen 276 und 1 werden wiederverwendet."""
    base = T.shared()
    d = Path(tempfile.mkdtemp(prefix='a60_mutint_'))
    co = T.claude_out(base['p1'], d / 'claude_out', source_root)
    full = d / 'integ'
    shutil.copytree(base['p1'], full)
    for f in co.rglob('*'):
        if f.is_file():
            t = full / f.relative_to(co)
            t.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy(f, t)
    return full


def mutated_exe(name, old, new, base_defines, work):          # base_defines bestimmt die Variante (mit/ohne Backend)
    src = Path(tempfile.mkdtemp(prefix='a60_mutsrc_'))
    shutil.copytree(ROOT / '02_SOURCE', src / '02_SOURCE')
    f = src / INC
    t = f.read_text(encoding='utf-8')
    if old is None:
        f.write_text(new(t), encoding='utf-8')            # transformierender Mutant (mehrere Stellen)
    else:
        assert t.count(old) == 1, (name, t.count(old))
        f.write_text(t.replace(old, new), encoding='utf-8')
    return B.build(integ_with_source(src / '02_SOURCE'), 'm' + str(abs(hash(name)) % 10**7), base_defines, work)


class CoreMutants(unittest.TestCase):
    def test_every_core_mutant_is_detected_by_the_cpp_tests(self):
        report, missed = [], []
        for name, old, new in CORE_MUTANTS:
            tmp = Path(tempfile.mkdtemp(prefix='a60_core_mut_'))
            shutil.copytree(ROOT / '02_SOURCE', tmp / '02_SOURCE')
            shutil.copytree(HERE / 'core', tmp / '04_TESTS' / 'core')
            h = tmp / CORE
            t = h.read_text(encoding='utf-8')
            self.assertEqual(t.count(old), 1, name)
            h.write_text(t.replace(old, new), encoding='utf-8')
            exe = tmp / 't'
            cc = subprocess.run(['g++', '-std=c++11', '-O1', '-w', str(tmp / '04_TESTS/core/test_auto60_core.cpp'), '-o', str(exe)], capture_output=True, text=True)
            if cc.returncode:
                how = 'Build bricht'
            else:
                r = subprocess.run([str(exe)], capture_output=True, text=True)
                how = ('Tests scheitern: ' + ','.join(l.split()[1] for l in r.stdout.splitlines() if l.startswith('FAIL'))[:60]) if r.returncode else None
            report.append(f'{name:<82} erkannt: {how}')
            if not how:
                missed.append(name)
        for name, old, new, why in CORE_EQUIVALENT:
            tmp = Path(tempfile.mkdtemp(prefix='a60_core_eq_'))
            shutil.copytree(ROOT / '02_SOURCE', tmp / '02_SOURCE')
            shutil.copytree(HERE / 'core', tmp / '04_TESTS' / 'core')
            h = tmp / CORE
            tx = h.read_text(encoding='utf-8')
            self.assertEqual(tx.count(old), 1, name)
            h.write_text(tx.replace(old, new), encoding='utf-8')
            exe = tmp / 't'
            subprocess.run(['g++', '-std=c++11', '-O1', '-w', str(tmp / '04_TESTS/core/test_auto60_core.cpp'), '-o', str(exe)], check=True)
            ok = subprocess.run([str(exe)], capture_output=True, text=True).returncode == 0
            report.append(f'{name:<82} gleichwertig (geprueft: alle Tests bestehen): {ok} | {why}')
            if not ok:
                missed.append(name + ' (als gleichwertig behauptet, aber Tests scheitern)')
        (HERE / 'LAST_MUTATION_REPORT_a60_core.txt').write_text('\n'.join(report) + '\n', encoding='utf-8')
        self.assertEqual(missed, [], 'UEBERLEBENDE Mutanten:\n' + '\n'.join(report))


class AdapterMutants(unittest.TestCase):
    VARIANTS = {'backend': ['SV04_CLAUDE_HOME_BACKEND_EXTERNAL=1', 'SIM_A60'], 'nobackend': ['SIM_A60', 'SV04_CLAUDE_HOME_BACKEND_AVAILABLE=0']}

    def golden(self, variant, work):
        return sig(B.build(T.shared()['integ'], 'golden_' + variant, self.VARIANTS[variant], work), SIGNATURE if variant == 'backend' else SIGNATURE_NOBACKEND)

    def test_every_adapter_mutant_changes_observable_chain_behaviour(self):
        work = Path(tempfile.mkdtemp(prefix='a60_mutwork_'))
        golden = {v: self.golden(v, work) for v in self.VARIANTS}
        report, missed = [], []
        for m in ADAPTER_MUTANTS:
            name, old, new = m[:3]
            variant = m[3] if len(m) > 3 else 'backend'
            try:
                exe = mutated_exe(name, old, new, self.VARIANTS[variant], work)
                how = 'Verhalten' if sig(exe, SIGNATURE if variant == 'backend' else SIGNATURE_NOBACKEND) != golden[variant] else None
            except RuntimeError:
                how = 'Build bricht'
            report.append(f'{name:<92} erkannt: {how}')
            if not how:
                missed.append(name)
        for name, old, new, variant, why in ADAPTER_EQUIVALENT:
            exe = mutated_exe(name, old, new, self.VARIANTS[variant], work)
            same = sig(exe, SIGNATURE_NOBACKEND) == golden[variant]
            report.append(f'{name:<92} gleichwertig (geprueft): {same} | {why}')
            if not same:
                missed.append(name + ' (als gleichwertig behauptet, aber Verhalten weicht ab)')
        (HERE / 'LAST_MUTATION_REPORT_a60_adapter.txt').write_text('\n'.join(report) + '\n', encoding='utf-8')
        self.assertEqual(missed, [], 'UEBERLEBENDE/UNSTIMMIGE Mutanten:\n' + '\n'.join(report))



# ---------------------------------------------------------------------------------- Mutanten des PRODUKTIONS-Backends (Integrationssignatur, echter G28/G29)
BACKEND_MUTANTS = [
    ('P01 Rueckmeldung nicht mehr "genau einmal" (Sperre sv04c_hb_reported entfernt)', "    if (sv04c_hb_reported) return;\n    sv04c_hb_reported = true;", "    sv04c_hb_reported = true;"),
    ('P02 Abbruch eines nur eingestellten G28 wird nicht verworfen', "static void sv04c_hb_cancel_armed() {\n    if (sv04c_hb_state == 1) {", "static void sv04c_hb_cancel_armed() {\n    if (false) {"),
    ('P03 das G28 einer verworfenen Anforderung wird nicht mehr verweigert', "    if (sv04c_hb_stale && full) { sv04c_hb_stale = false; return false; }", "    if (sv04c_hb_stale && full) { sv04c_hb_stale = false; return true; }"),
    ('P04 ein fremdes G28 waehrend der Anforderung macht sie nicht ungueltig', "      sv04c_hb_finish(false, false); sv04c_hb_state = 0; sv04c_hb_stale = true; sv04c_hb_stale_ms = (uint32_t)millis();   // ein ANDERES G28 kam zuvor", "      // (mutiert)   // ein ANDERES G28 kam zuvor"),
    ('P05 Druck zwischen Anforderung und Ausfuehrung wird nicht erkannt', "        if (sv04c_hb_printer_busy()) { sv04c_hb_finish(false, false); sv04c_hb_state = 0; return false; }", "        if (false) { sv04c_hb_finish(false, false); sv04c_hb_state = 0; return false; }"),
    ('P06 G28-Erfolg ignoriert das P1-Ergebnis "ok" (Z-/X-Fehler gelten als Homing-Erfolg)', "const bool done = allowed && r.seq != sv04c_hb_seq0 && r.completed && r.ok;", "const bool done = allowed && r.seq != sv04c_hb_seq0 && r.completed;"),
    ('P07 G29-Endskript und Zustand danach werden nicht ausgewertet', "r.endscript_ok = end_ok && axis_is_trusted(X_AXIS) && axis_is_trusted(Y_AXIS) && axis_is_trusted(Z_AXIS) && active_extruder == 0;", "r.endscript_ok = true;"),
    ('P08 Touch-Abbruch wird nie angewendet', "    if (sv04c_coord.running() && sv04c_cancel_sid == sv04c_coord.session()) { sv04c_coord.cancel(); sv04c_hb_cancel_armed(); }", "    if (false) { sv04c_coord.cancel(); sv04c_hb_cancel_armed(); }"),
    ('P09 haengende Queue wird nicht erkannt (Zeitgrenze der Anforderung entfernt)', "if (sv04c_hb_state == 1 && now - sv04c_hb_ms > SV04_CLAUDE_HOME_BEGIN_TIMEOUT_MS)", "if (false && sv04c_hb_state == 1 && now - sv04c_hb_ms > SV04_CLAUDE_HOME_BEGIN_TIMEOUT_MS)"),
    ('P10 Verwurf durch den Koordinator erreicht das Backend nicht', "  if (sid != sv04c_hb_sid) return;\n  if (sv04c_hb_state == 1) {", "  if (true) return;\n  if (sv04c_hb_state == 1) {"),
]
INTEG_SIGNATURE = [('homed=none',), ('homed=none', 'x_early_t1=1'), ('homed=none', 'x_early_t0=1'), ('homed=none', 'stow_fail=1'), ('homed=none', 'x_t1_on_call=2'), ('homed=none', 'queue_stall=1', 'queue_release_s=80', 'tail_s=100', 'limit_s=300'),
                   ('homed=none', 'queue_stall=1', 'queue_release_s=60', 'cancel_at=HOMING_PENDING', 'tail_s=60', 'limit_s=200'), ('homed=none', 'queue_stall=1', 'queue_release_s=100', 'foreign_g28_exec_s=40', 'tail_s=120', 'limit_s=400'),
                   ('homed=none', 'queue_stall=1', 'queue_release_s=45', 'printing_at_s=40', 'tail_s=20', 'limit_s=200'), ('homed=none', 'print_after_homeaxis=2'), ('homed=none', 'kick_after_homeaxis=2', 'kick=40'), ('homed=none', 'touch_after_homeaxis=2'),
                   ('homed=none', 'touch_after_probe=6'), ('homed=none', 'cancel_after_homeaxis=2'), ('homed=none', 'nan_at=9')]
INTEG_KEYS = ('RESULT', 'LOG', 'EE', 'RAM', 'P1RESULT', 'AXES', 'HOMEAXIS', 'STALE', 'CMDS', 'HMI', 'HMIPAGE', 'SERIAL')


def isig(exe):
    return [tuple(B.scenario(exe, *a).get(k, '') for k in INTEG_KEYS) for a in INTEG_SIGNATURE]


class BackendMutants(unittest.TestCase):
    def test_every_production_backend_mutant_changes_observable_behaviour_with_the_real_g28_and_g29(self):
        work = Path(tempfile.mkdtemp(prefix='a60_bmut_'))
        golden = isig(B.build_integ(T.shared()['integ'], 'bgolden', ['SIM_P1_277'], work))
        report, missed = [], []
        for name, old, new in BACKEND_MUTANTS:
            src = Path(tempfile.mkdtemp(prefix='a60_bsrc_'))
            shutil.copytree(ROOT / '02_SOURCE', src / '02_SOURCE')
            f = src / INC
            t = f.read_text(encoding='utf-8')
            self.assertEqual(t.count(old), 1, name)
            f.write_text(t.replace(old, new), encoding='utf-8')
            try:
                exe = B.build_integ(integ_with_source(src / '02_SOURCE'), 'b' + str(abs(hash(name)) % 10**7), ['SIM_P1_277'], work)
                how = 'Verhalten' if isig(exe) != golden else None
            except RuntimeError:
                how = 'Build bricht'
            report.append(f'{name:<95} erkannt: {how}')
            if not how:
                missed.append(name)
        (HERE / 'LAST_MUTATION_REPORT_a60_backend.txt').write_text('\n'.join(report) + '\n', encoding='utf-8')
        self.assertEqual(missed, [], 'UEBERLEBENDE Mutanten:\n' + '\n'.join(report))


# ============================================================================================================ 283: Mutanten der EEPROM-Teile
EECORE = Path('02_SOURCE/Marlin/src/feature/sv04_claude_auto60/sv04_claude_eeprom_core.h')
EE_CORE_MUTANTS = [
    ('EC01 primary_info ignoriert die CRC', "r.st = c == r.crc_stored ? PR_VALID : PR_CRC_BAD;", "r.st = PR_VALID;"),
    ('EC02 verify_mesh meldet crc_ok immer true', "r.crc_ok = pi.st == PR_VALID;", "r.crc_ok = true;"),
    ('EC03 verify_mesh vergleicht die 16 Werte nicht', "r.values_ok = vals; r.z_equal = r.bad_mask == 0 && cnt >= 1;", "r.values_ok = vals; r.z_equal = true;"),
    ('EC04 verify_mesh akzeptiert ein mehrfach vorhandenes Muster', "r.found = true; r.unique = cnt == 1;", "r.found = true; r.unique = true;"),
    ('EC05 gespeicherte Werte: Betragsgrenze entfernt', "if (!isfinite(v[i]) || fabsf(v[i]) > abs_limit) vals = false;", "if (!isfinite(v[i])) vals = false;"),
    ('EC06 gespeicherte Werte: NaN/Inf nicht mehr erkannt', "if (!isfinite(v[i]) || fabsf(v[i]) > abs_limit) vals = false;", "if (fabsf(v[i]) > abs_limit) vals = false;"),
    ('EC07 Versionspruefung entfernt (V84 gilt als gueltig)', "if (b.ver && memcmp(h, b.ver, 4) != 0) { r.st = PR_FOREIGN; return r; }", "if (false) { r.st = PR_FOREIGN; return r; }"),
    ('EC08 ERR-Kennung des unterbrochenen Schreibens nicht erkannt', "if (memcmp(h, \"ERR\", 4) == 0) { r.st = PR_INTERRUPTED; return r; }", "if (false) { r.st = PR_INTERRUPTED; return r; }"),
    ('EC09 Journal wird nie als gueltig markiert', "if (!shadow_set_state(s, p, kShadowValid)) return SC_IO;                    // 5. ERST JETZT gueltig", "// (mutiert) kein gueltig-Markieren"),
    ('EC10 Wiederherstellung wird nicht nachgeprueft', "if (c != i.crc || primary_info(s, b).st != PR_VALID) return RS_VERIFY;", "if (false) return RS_VERIFY;"),
    ('EC11 Abschluss: Hauptblock gilt immer als unveraendert (kein Zurueckspielen)', "const bool same = primary_info(s, b).st == PR_VALID && crc_range(s, b.start, b.len, c) && c == i.crc;", "const bool same = true;"),
    ('EC12 Abschluss nach Erfolg verwirft das Journal nicht', "if (verified) return shadow_invalidate(s, p) ? CM_OK : CM_CLEAR_FAILED;", "if (verified) return CM_OK;"),
    ('EC13 Start: gueltiger Hauptblock mit gueltigem Journal wird zurueckgespielt statt verworfen', "case PR_VALID: return BA_CLEAR;", "case PR_VALID: return BA_RESTORE;"),
    ('EC14 Start: unterbrochener Block mit gueltigem Journal wird NICHT zurueckgespielt', "case PR_INTERRUPTED: case PR_CRC_BAD: case PR_BLANK: return BA_RESTORE;", "case PR_INTERRUPTED: case PR_CRC_BAD: case PR_BLANK: return BA_NONE;"),
    ('EC15 Platzpruefung des Journals entfernt (es darf den Hauptblock ueberlappen)', "if (hdr < static_cast<uint32_t>(b.start) + b.len + kGuard) return p;", "if (false) return p;"),
    ('EC17 beschaedigte Journal-Daten gelten als gesund', "i.data_ok = c == i.crc; }", "i.data_ok = true; }"),
    ('EC18 Journal-Kopf-CRC wird nicht geprueft', "|| hc != static_cast<uint16_t>(h[14] | (h[15] << 8))) return true;           // kein gueltiger Kopf", ") return true;           // kein gueltiger Kopf"),
]
EE_CORE_EQUIVALENT = [
    ('EC16 Blockgrenze gegen die Kapazitaet nicht geprueft', "return b.len > kHdr && static_cast<uint32_t>(b.start) + b.len <= s.capacity; }", "return b.len > kHdr; }",
     'redundante Absicherung: rd()/wr() pruefen JEDEN Zugriff gegen die Kapazitaet selbst; ein zu grosser Block endet auch ohne diese Zeile als PR_UNREADABLE bzw. SC_NO_SPACE'),
]
COORD283 = [
    ('CK19 C5: der Start wird bei unbekanntem Z freigegeben', "    if (q.z_unknown) return R_PRE_Z_UNKNOWN;", "    if (false) return R_PRE_Z_UNKNOWN;"),
    ('CK17 C4: der Lauf bemerkt einen Marlin-Stopp nicht', "if (sq.marlin_stopped) { fail(R_MARLIN_STOPPED); return; }", "if (false) { fail(R_MARLIN_STOPPED); return; }"),
    ('CK18 C4: der Start wird im gestoppten Marlin-Zustand freigegeben', "    if (q.marlin_stopped) return R_MARLIN_STOPPED;", "    if (false) return R_MARLIN_STOPPED;"),
    ('CK01 Erfolg verlangt keine unabhaengige Rohlesung', "&& ev.independent && ev.crc_ok", "&& ev.crc_ok"),
    ('CK02 Erfolg verlangt keine eigene CRC', "&& ev.independent && ev.crc_ok && ev.mesh_found", "&& ev.independent && ev.mesh_found"),
    ('CK03 Erfolg verlangt keinen unveraenderten RAM-Zustand der Rohlesung', "&& ev.geometry_ok && ev.ram_unchanged;", "&& ev.geometry_ok;"),
    ('CK04 kein Undo-Journal vor dem Speichern', "if (p_.eeprom_prepare && !save_prepared_) {", "if (false && p_.eeprom_prepare && !save_prepared_) {"),
    ('CK05 gescheitertes Anlegen des Journals wird ignoriert', "if (!p_.eeprom_prepare(p_.ctx, sid_)) { fail(R_EEPROM_PREPARE_FAILED); return; }", "(void)p_.eeprom_prepare(p_.ctx, sid_);"),
    ('CK06 Erfolg schliesst die Journal-Transaktion nicht ab', "if (save_prepared_ && !finish_eeprom(true)) {", "if (false) {"),
    ('CK16 294: ein gescheiterter Journal-Abschluss wird ignoriert und endet trotzdem als Erfolg', "        fail(R_EEPROM_RECOVERY_REQUIRED);\n        return;\n      }\n      go(ST_SUCCESS", "      }\n      go(ST_SUCCESS"),
    ('CK07 Ergebnis des Zurueckspielens wird ignoriert (immer \"konsistent\")', "const bool consistent = finish_eeprom(false);", "const bool consistent = (finish_eeprom(false), true);"),
    ('CK08 Ueberspringen wird auch bei der Wiederholung versucht (Endlosschleife)', "if (p_.eeprom_unchanged && save_attempts_ == 0 && p_.eeprom_unchanged(", "if (p_.eeprom_unchanged && p_.eeprom_unchanged("),
    ('CK09 uebersprungener Versuch zaehlt nicht als Versuch', "save_skipped_ = true; save_issued_ = true; ++save_attempts_; evidence_.save_ok = true;", "save_skipped_ = true; save_issued_ = true; evidence_.save_ok = true;"),
    ('CK10 uebersprungenes Speichern gilt als gescheitert', "save_skipped_ = true; save_issued_ = true; ++save_attempts_; evidence_.save_ok = true;", "save_skipped_ = true; save_issued_ = true; ++save_attempts_; evidence_.save_ok = false;"),
    ('CK12 Rohlesung nicht verfuegbar: die Journal-Transaktion wird nicht abgeschlossen (der unverifizierte Block bliebe im EEPROM)', "if (ev.validate_ok && !avail) { fail(R_VERIFY_UNAVAILABLE); return; }", "if (ev.validate_ok && !avail) { abort_home(); maybe_rollback(); mesh_.invalidate(); go(ST_FAILED, R_VERIFY_UNAVAILABLE); restore_heater(); disp(D_RESULT); return; }"),
    ('CK13 Option rollback_after_activation wirkt nicht (Bereich bleibt ST_ENABLING)', "st_ <= (after ? ST_SAVE_PENDING : ST_ENABLING)", "st_ <= ST_ENABLING"),
    ('CK14 Option: Rollback auch NACH save() (die Sperre !save_issued_ fehlt)', "(!m420_enabled_ || after) && !save_issued_ && st_", "(!m420_enabled_ || after) && st_"),
    ('CK15 Option ignoriert die Aktivierung nicht (!m420_enabled_ gilt immer)', "(!m420_enabled_ || after) &&", "(!m420_enabled_) &&"),
    ('CK11 ohne Nachweis der Konsistenz trotzdem nicht \"Wiederherstellung noetig\"', "fail((why == R_VERIFY_INVALID || why == R_SAVE_ERROR) && !consistent ? R_EEPROM_RECOVERY_REQUIRED : why);", "fail(why);"),
]
EE_ADAPTER = [
    ('AE12 292: die Richtlinie erlaubt immer (auch einen ungueltigen Block)', "  return blank || (valid && (journal_room || !journal_required));", "  return true;"),
    ('AE13 292: die Richtlinie ignoriert die Pflicht zum Journal (fehlender Platz wird erlaubt)', "  return blank || (valid && (journal_room || !journal_required));", "  return blank || valid;"),
    ('AE02 Start verweigert auch ein noch leeres EEPROM', "  if (blank) { sv04c_ee_announce(3); return true; }", "  if (blank) { sv04c_ee_announce(3); return false; }"),
    ('AE03 die erwartete EEPROM-Version wird nicht uebergeben', "b.len = (uint16_t)settings.datasize(); b.ver = SV04_CLAUDE_EEPROM_VERSION; return b; }", "b.len = (uint16_t)settings.datasize(); return b; }"),
    ('AE04 gescheitertes Anlegen des Journals wird ignoriert (317)', "  if (created != sv04c::ee::SC_OK) {", "  if (false) {"),
    ('AE06 nach der Startwiederherstellung wird NICHT neu geladen (RAM bleibt Standardwerte)', "    const bool loaded = settings.load();", "    const bool loaded = true;"),
    ('AE07 Ueberspringen genuegt schon, wenn nur das Raster gefunden wurde', "return sv04c::ee::verify_ok(r) && r.zoff_found;\n}\n", "return r.found;\n}\n"),
    ('AE08 mitgespeicherte weitere Bytes werden nicht gemeldet', "if (d.other) { SERIAL_ECHO_START();", "if (false) { SERIAL_ECHO_START();"),
    ('AE09 leerer Block wird nicht als \"nichts zu schuetzen\" vermerkt', "if (pi.st == sv04c::ee::PR_BLANK) { sv04c_ee_journal = 3; sv04c_ee_announce(3); return true; }", "if (pi.st == sv04c::ee::PR_BLANK) { sv04c_ee_announce(3); return true; }"),
    ('AE10 Rohlesung prueft das probe.offset nicht', "ev.mesh_equal = r.found && r.unique && r.geometry_equal && r.z_equal; ev.zoff_equal = r.zoff_found;", "ev.mesh_equal = r.found && r.unique && r.geometry_equal && r.z_equal; ev.zoff_equal = true;"),
    ('AE11 Rohlesung meldet die CRC nicht', "ev.independent = true; ev.crc_ok = r.crc_ok;", "ev.independent = true; ev.crc_ok = true;"),
]
EE_ADAPTER_EQUIVALENT = [
    ('AE05 Konsistenz nach dem Zurueckspielen wird nicht nachgewiesen [beobachtungsgleich seit 304]', '  if (!verified && sv04c::ee::primary_info(s, b).st != sv04c::ee::PR_VALID) {\n    sv04c_ee_last_commit = 7;', '  if (false) {\n    sv04c_ee_last_commit = 7;', 'seit ChatGPTs Patch 304 liefert der Kern bei nicht lesbarem Journal schon FRUEHER CM_ROLLBACK_FAILED (last_commit=3 statt 7); die Adapterpruefung ist nur noch zweite Verteidigungslinie. Vergleich Stand 299 (Szenario noreadback=1 unterscheidet) gegen Stand 305 (kein Szenario unterscheidet); KEIN Szenario trifft nur die Adapterpruefung'),
    ('AE01 Start erlaubt auch einen ungueltigen Block (die Pruefung in start_ok entfaellt)', "  if (!blank && !valid) return false;\n  if (blank) { sv04c_ee_announce(3); return true; }", "  if (blank) { sv04c_ee_announce(3); return true; }", 'seit 292 verweigert sv04c_ee_policy_allows() einen weder leeren noch gueltigen Block ohnehin (blank || (valid && ...)); die Pruefung in start_ok ist redundant'),
    ('AG01 RAM-Unveraendertheit der Rohlesung immer true', "ev.ram_unchanged = sv04c::mesh_same(m0, m1) && memcmp(&po0, &probe.offset, sizeof po0) == 0 && lev0 == planner.leveling_active;", "ev.ram_unchanged = true;",
     'durch Konstruktion nicht beobachtbar: die Rohlesung schreibt nie ins RAM; die Pruefung ist eine Sicherung gegen kuenftige Aenderungen'),
    ('AG02 Schreibbloecke von 64 statt 8 Bytes', "const uint16_t k = (n - done) < 8 ? (uint16_t)(n - done) : (uint16_t)8;", "const uint16_t k = (n - done) < 64 ? (uint16_t)(n - done) : (uint16_t)64;",
     'betrifft nur die ZEIT zwischen safe_delay()-Aufrufen (Heizungs-/Watchdog-Bedienung): im Host-Modell nicht beobachtbar'),
    ('AG03 safe_delay(1) zwischen den Schreibbloecken entfernt', "    done = (uint16_t)(done + k);\n    safe_delay(1);", "    done = (uint16_t)(done + k);",
     'dito: nur Zeitverhalten (Heizung/Watchdog), im Host-Modell nicht beobachtbar'),
]

EE_SCEN = None


def ee_scenarios():
    global EE_SCEN
    if EE_SCEN is None:
        sys.path.insert(0, str(HERE / 'sim'))
        import test_ee_a60 as E
        old, new, total = E.refs()
        crc = E.mutated('m_crc.img', lambda b: b.__setitem__(E.OFF + 300, b[E.OFF + 300] ^ 1))
        v84 = E.mutated('m_v84.img', lambda b: b.__setitem__(slice(E.OFF, E.OFF + 4), b'V84\0'))
        blank = E.mutated('m_blank.img', lambda b: b.__setitem__(slice(0, 2048), b'\xff' * 2048))
        E.run('homed=none', 'ee_cut_at=850', 'ee_out=' + E.img('m_cut850.img'))
        E.run('homed=none', 'ee_cut_at=%d' % (total - 1), 'ee_out=' + E.img('m_cutlast.img'))
        EE_SCEN = [('homed=none',), ('homed=none', 'save=1'), ('homed=none', 'save=2'), ('homed=none', 'save=3'), ('homed=none', 'save=5'), ('homed=none', 'save=6'), ('homed=none', 'noreadback=1'), ('homed=none', 'other_dirty=1'),
                   ('homed=none', 'ee_in=' + E.img('new.img')), ('homed=none', 'ee_in=' + E.img('new.img'), 'other_dirty=1'), ('boot_only=1', 'ee_in=' + E.img('m_cut850.img')), ('boot_only=1', 'ee_in=' + E.img('m_cutlast.img')),
                   ('homed=none', 'ee_in=' + crc), ('homed=none', 'ee_in=' + v84), ('homed=none', 'ee_in=' + blank), ('homed=none', 'ee_fail_at=300'), ('homed=none', 'ee_unreadable=1'), ('homed=none', 'ee_fail_at=850')]
    return EE_SCEN


EE_KEYS = ('RESULT', 'EE', 'EERAW', 'EEMAINEQ', 'EEBYTES_CHANGED_VS_START', 'SERIAL', 'HMIPAGE', 'MESH', 'EEMESH', 'RAM')


def eesig(exe):
    out = []
    for a in ee_scenarios():
        r = B.scenario(exe, *a)
        out.append(tuple(r.get(k, '') for k in EE_KEYS))
    return out


NOROOM_DEFS = ['SIM_P1_277', 'SIM_EE_OFFSET=1000', 'SV04_CLAUDE_EEPROM_OFFSET=1000']      # 299: ohne Platz fuer das Journal entscheidet die Richtlinie von 292 (Journal Pflicht)


def eesig2(tree, tag, work):
    """Signatur der normalen Szenarien PLUS der Szenarien ohne Platz fuer das Journal (Standard 292: Journal Pflicht -> Start verweigert)."""
    out = eesig(B.build_integ(tree, tag, ['SIM_P1_277'], work))
    nr = B.build_integ(tree, tag + 'n', NOROOM_DEFS, work)
    for a in (('homed=none',), ('homed=none', 's3_end=1'), ('homed=none', 'save=1')):
        r = B.scenario(nr, *a); out.append(tuple(r.get(k, '') for k in EE_KEYS))
    return out


class EepromCoreMutants(unittest.TestCase):
    def test_every_eeprom_core_mutant_is_detected_by_the_cpp_tests(self):
        report, missed = [], []
        for name, old, new in EE_CORE_MUTANTS:
            tmp = Path(tempfile.mkdtemp(prefix='ee_core_mut_'))
            shutil.copytree(ROOT / '02_SOURCE', tmp / '02_SOURCE'); shutil.copytree(HERE / 'core', tmp / '04_TESTS' / 'core')
            h = tmp / EECORE; t = h.read_text(encoding='utf-8')
            self.assertEqual(t.count(old), 1, name); h.write_text(t.replace(old, new), encoding='utf-8')
            exe = tmp / 't'
            cc = subprocess.run(['g++', '-std=c++11', '-O1', '-w', str(tmp / '04_TESTS/core/test_eeprom_core.cpp'), '-o', str(exe)], capture_output=True, text=True)
            if cc.returncode:
                how = 'Build bricht'
            else:
                r = subprocess.run([str(exe)], capture_output=True, text=True)
                how = ('Tests scheitern: ' + ','.join(l.split()[1] for l in r.stdout.splitlines() if l.startswith('FAIL'))[:60]) if r.returncode else None
            report.append(f'{name:<88} erkannt: {how}')
            if not how:
                missed.append(name)
        for name, old, new, why in EE_CORE_EQUIVALENT:
            tmp = Path(tempfile.mkdtemp(prefix='ee_core_eq_'))
            shutil.copytree(ROOT / '02_SOURCE', tmp / '02_SOURCE'); shutil.copytree(HERE / 'core', tmp / '04_TESTS' / 'core')
            h = tmp / EECORE; t = h.read_text(encoding='utf-8')
            self.assertEqual(t.count(old), 1, name); h.write_text(t.replace(old, new), encoding='utf-8')
            exe = tmp / 't'; subprocess.run(['g++', '-std=c++11', '-O1', '-w', str(tmp / '04_TESTS/core/test_eeprom_core.cpp'), '-o', str(exe)], check=True)
            ok = subprocess.run([str(exe)], capture_output=True, text=True).returncode == 0
            report.append(f'{name:<88} gleichwertig (geprueft: alle Tests bestehen): {ok} | {why}')
            if not ok:
                missed.append(name + ' (als gleichwertig behauptet, aber Tests scheitern)')
        (HERE / 'LAST_MUTATION_REPORT_a60_eeprom_core.txt').write_text('\n'.join(report) + '\n', encoding='utf-8')
        self.assertEqual(missed, [], 'UEBERLEBENDE Mutanten:\n' + '\n'.join(report))


class Coordinator283Mutants(unittest.TestCase):
    def test_every_new_coordinator_mutant_is_detected_by_the_cpp_tests(self):
        report, missed = [], []
        for name, old, new in COORD283:
            tmp = Path(tempfile.mkdtemp(prefix='ck_mut_'))
            shutil.copytree(ROOT / '02_SOURCE', tmp / '02_SOURCE'); shutil.copytree(HERE / 'core', tmp / '04_TESTS' / 'core')
            h = tmp / CORE; t = h.read_text(encoding='utf-8')
            self.assertEqual(t.count(old), 1, name); h.write_text(t.replace(old, new), encoding='utf-8')
            exe = tmp / 't'
            cc = subprocess.run(['g++', '-std=c++11', '-O1', '-w', str(tmp / '04_TESTS/core/test_auto60_core.cpp'), '-o', str(exe)], capture_output=True, text=True)
            if cc.returncode:
                how = 'Build bricht'
            else:
                try:
                    r = subprocess.run([str(exe)], capture_output=True, text=True, timeout=60)
                    how = ('Tests scheitern: ' + ','.join(l.split()[1] for l in r.stdout.splitlines() if l.startswith('FAIL'))[:60]) if r.returncode else None
                except subprocess.TimeoutExpired:
                    how = 'Endlosschleife (Timeout)'
            report.append(f'{name:<88} erkannt: {how}')
            if not how:
                missed.append(name)
        (HERE / 'LAST_MUTATION_REPORT_a60_coordinator283.txt').write_text('\n'.join(report) + '\n', encoding='utf-8')
        self.assertEqual(missed, [], 'UEBERLEBENDE Mutanten:\n' + '\n'.join(report))


class EepromAdapterMutants(unittest.TestCase):
    def test_every_eeprom_adapter_mutant_changes_observable_behaviour_end_to_end(self):
        work = Path(tempfile.mkdtemp(prefix='ee_amut_'))
        golden = eesig2(T.shared()['integ'], 'eegolden', work)
        report, missed = [], []
        sl = os.environ.get('EE_MUT_SLICE')                                 # nur fuer Stapelaufrufe von Hand: 'a:b' (Mutanten) bzw. 'eq' (gleichwertige); ohne Angabe: ALLE
        lo, hi = (0, len(EE_ADAPTER)) if not sl else (0, 0) if sl == 'eq' else tuple(int(v) for v in sl.split(':'))
        for name, old, new in EE_ADAPTER[lo:hi]:
            src = Path(tempfile.mkdtemp(prefix='ee_asrc_')); shutil.copytree(ROOT / '02_SOURCE', src / '02_SOURCE')
            f = src / INC; t = f.read_text(encoding='utf-8')
            self.assertEqual(t.count(old), 1, name); f.write_text(t.replace(old, new), encoding='utf-8')
            try:
                how = 'Verhalten' if eesig2(integ_with_source(src / '02_SOURCE'), 'e' + str(abs(hash(name)) % 10**7), work) != golden else None
            except RuntimeError:
                how = 'Build bricht'
            report.append(f'{name:<88} erkannt: {how}')
            if not how:
                missed.append(name)
        for name, old, new, why in (EE_ADAPTER_EQUIVALENT if (not sl or sl == 'eq') else []):
            src = Path(tempfile.mkdtemp(prefix='ee_asrc_')); shutil.copytree(ROOT / '02_SOURCE', src / '02_SOURCE')
            f = src / INC; t = f.read_text(encoding='utf-8')
            self.assertEqual(t.count(old), 1, name); f.write_text(t.replace(old, new), encoding='utf-8')
            same = eesig2(integ_with_source(src / '02_SOURCE'), 'g' + str(abs(hash(name)) % 10**7), work) == golden
            report.append(f'{name:<88} gleichwertig (geprueft: Verhalten unveraendert): {same} | {why}')
            if not same:
                missed.append(name + ' (als gleichwertig behauptet, aber das Verhalten aendert sich)')
        (HERE / ('LAST_MUTATION_REPORT_a60_eeprom_adapter%s.txt' % ('' if not sl else '_' + sl.replace(':', '-')))).write_text('\n'.join(report) + '\n', encoding='utf-8')
        self.assertEqual(missed, [], 'UEBERLEBENDE Mutanten:\n' + '\n'.join(report))


# ============================================================================================================ Gesamtintegration: Rollback-Reihenfolge gegen die ECHTEN V2/V4-Funktionen
BL_MUTANTS = [
    ('BM01 altes Mesh wird ohne vorheriges Ausschalten hergestellt (V4: aktiv + ungueltig = kill)', "  if (planner.leveling_active && !sv04c_mesh_image_valid(b)) set_bed_leveling_enabled(false);\n  sv04c_mesh_restore(b);", "  sv04c_mesh_restore(b);"),
    ('BM02 Zustand von VOR dem Lauf wird nicht wiederhergestellt', "  sv04c_mesh_restore(b);\n  if (planner.leveling_active != sv04c_lev_at_begin) set_bed_leveling_enabled(sv04c_lev_at_begin);   // Zustand wie VOR dem Lauf\n}", "  sv04c_mesh_restore(b);\n}"),
    ('BM03 der G29-Rollback-Haken benutzt wieder das nackte Wiederherstellen', "      sv04c_mesh_rollback_safe(b);\n      sv04c_g29s.note_rollback();", "      sv04c_mesh_restore(b);\n      sv04c_g29s.note_rollback();"),
    ('BM04 Pruefung des alten Meshs ist umgekehrt (aus nur bei GUELTIGEM alten Mesh)', "if (planner.leveling_active && !sv04c_mesh_image_valid(b)) set_bed_leveling_enabled(false);", "if (planner.leveling_active && sv04c_mesh_image_valid(b)) set_bed_leveling_enabled(false);"),
    ('BM05 ein NaN im alten Mesh gilt als gueltig', "for (int x = 0; x < GRID_MAX_POINTS_X; x++) for (int y = 0; y < GRID_MAX_POINTS_Y; y++) if (!isfinite(m.z[x][y])) return false;\n  return true;", "return true;"),
    ('BM06 Rasterabstand 0 im alten Mesh gilt als gueltig', "|| m.spacing[0] <= 0 || m.spacing[1] <= 0) return false;", ") return false;"),
]
BL_EQUIVALENT = [
    ('BG01 das Auto60-Rollback des Koordinators benutzt das nackte Wiederherstellen', "  sv04c_mesh_rollback_safe(b);                                                                       // Zustand wie VOR dem Lauf (Reihenfolge: siehe dort)", "  sv04c_mesh_restore(b); if (planner.leveling_active != sv04c_lev_at_begin) set_bed_leveling_enabled(sv04c_lev_at_begin);",
     'im Zustand VALIDATING/ENABLING ist die Nivellierung schon AUS (Aufruf set_bed_leveling_enabled(false) nach on_g29_finished); die Reihenfolge spielt dort keine Rolle'),
]
BL_SCEN = None


def bl_scenarios():
    global BL_SCEN
    if BL_SCEN is None:
        sys.path.insert(0, str(HERE / 'sim'))
        import test_bedlevel_a60 as BLT
        b = BLT.blank()
        BL_SCEN = [('homed=none',), ('homed=none', 'ee_in=' + b, 'touch_after_probe=6'), ('homed=none', 'ee_in=' + b, 'val_at=5', 'val=45'), ('homed=none', 'ee_in=' + b), ('homed=none', 'lev0=0', 'val_at=5', 'val=45'),
                   ('homed=none', 'lev0=1', 'val_at=5', 'val=45'), ('homed=none', 'lev0=1', 'touch_after_probe=6'), ('homed=none', 'ee_in=' + b, 'nan_at=9'), ('homed=none', 'lev0=1', 'val_at=5', 'val=12'), ('homed=none', 'lev0=0', 'val_at=5', 'val=12'),
                   ('homed=none', 'lev0=0', 'old_nan=1', 'touch_after_probe=6'), ('homed=none', 'lev0=0', 'old_zero_spacing=1', 'touch_after_probe=6'),
                   ('homed=all', 'manual_g29=1', 'lev0=1', 'val_at=5', 'val=45'), ('homed=all', 'manual_g29=1', 'lev0=0', 'val_at=5', 'val=45'), ('homed=all', 'manual_g29=1', 'ee_in=' + b, 'val_at=5', 'val=45')]
    return BL_SCEN


BL_KEYS = ('RESULT', 'RAM', 'HMIPAGE', 'EEBYTES_CHANGED_VS_START', 'EEMAINEQ', 'EERAW')


def blsig(exe):
    out = []
    for a in bl_scenarios():
        try:
            r = B.scenario(exe, *a)
            out.append(tuple(r.get(k, '') for k in BL_KEYS))
        except AssertionError:
            out.append(('EXIT!=0',))
    return out


class BedlevelMutants(unittest.TestCase):
    def test_every_rollback_order_mutant_is_detected_with_the_real_v2_v4_functions(self):
        work = Path(tempfile.mkdtemp(prefix='bl_mut_'))
        D = ['SIM_P1_277', 'SIM_REAL_BEDLEVEL=v2v4']
        golden = blsig(B.build_integ(T.shared()['integ'], 'blgolden', D, work))
        report, missed = [], []
        for name, old, new in BL_MUTANTS:
            src = Path(tempfile.mkdtemp(prefix='bl_src_')); shutil.copytree(ROOT / '02_SOURCE', src / '02_SOURCE')
            f = src / INC; t = f.read_text(encoding='utf-8')
            self.assertEqual(t.count(old), 1, name); f.write_text(t.replace(old, new), encoding='utf-8')
            try:
                how = 'Verhalten' if blsig(B.build_integ(integ_with_source(src / '02_SOURCE'), 'b' + str(abs(hash(name)) % 10**7), D, work)) != golden else None
            except RuntimeError:
                how = 'Build bricht'
            report.append(f'{name:<100} erkannt: {how}')
            if not how:
                missed.append(name)
        for name, old, new, why in BL_EQUIVALENT:
            src = Path(tempfile.mkdtemp(prefix='bl_src_')); shutil.copytree(ROOT / '02_SOURCE', src / '02_SOURCE')
            f = src / INC; t = f.read_text(encoding='utf-8')
            self.assertEqual(t.count(old), 1, name); f.write_text(t.replace(old, new), encoding='utf-8')
            same = blsig(B.build_integ(integ_with_source(src / '02_SOURCE'), 'g' + str(abs(hash(name)) % 10**7), D, work)) == golden
            report.append(f'{name:<100} gleichwertig (geprueft: Verhalten unveraendert): {same} | {why}')
            if not same:
                missed.append(name + ' (als gleichwertig behauptet, aber das Verhalten aendert sich)')
        (HERE / 'LAST_MUTATION_REPORT_a60_bedlevel.txt').write_text('\n'.join(report) + '\n', encoding='utf-8')
        self.assertEqual(missed, [], 'UEBERLEBENDE Mutanten:\n' + '\n'.join(report))


# ============================================================================================================ 285: Anzeige, Abbruch, Schutzstatus, Rollback-Option
OPS_MUTANTS = [      # (Name, [(alt, neu), ...])  -- mehrere Ersetzungen = ein Mutant
    ('OM13 C5: der Adapter meldet "Z unbekannt" nicht an den Koordinator', [("    p.z_unknown = !(axis_was_homed(Z_AXIS) && axis_is_trusted(Z_AXIS));        // SV04 NEXT C5", "    p.z_unknown = false;        // SV04 NEXT C5")]),
    ('OM12 C4: der Adapter meldet den Marlin-Stopp nicht an den Koordinator', [("  p.marlin_stopped = IsStopped();", "  p.marlin_stopped = false;")]),
    ('OM10 C2: nach stop() (BLTouch-Fehler) wird die Bett-Solltemperatur wieder eingeschaltet', [("  if (c > 0 && IsStopped()) return;", "  if (false) return;")]),
    ('OM11 C2: der Stopp-Zustand wird mit dem Laufzustand verwechselt (Sollwert wird bei normalem Lauf unterdrueckt)', [("  if (c > 0 && IsStopped()) return;", "  if (c > 0 && IsRunning()) return;")]),
    ('OM01 nach der Start-Wiederherstellung wird das Mesh NICHT erneut an das Display gesendet', [("    if (r == sv04c::ee::BR_RESTORED && !sv04c_ee_boot_blocked)\n      sv04c_send_oem_mesh();", "    if (false)\n      sv04c_send_oem_mesh();")]),
    ('OM02 der Schutzstatus wird beim START nicht gemeldet', [("  sv04c_ee_announce(room ? 1 : 2);\n  return true;", "  return true;")]),
    ('OM03 die Speicherfreigabe meldet "ohne Journal" nicht', [("sv04c_ee_journal = 2; sv04c_ee_announce(2); return true; }", "sv04c_ee_journal = 2; return true; }")]),
    ('OM04 gespeichert OHNE Journal wird nicht gezaehlt', [("if (verified && sv04c_ee_journal == 2) ++sv04c_ee_unprotected_saves;", "")]),
    ('OM05 der Touch-Abbruch ist wieder UNGEBUNDEN (Stand 284: Touch im Leerlauf und alter Touch wirken auf den naechsten Lauf)', [
        ("void SV04Claude_Auto60_TouchCancel() { if (sv04c_coord.running()) { sv04c_cancel_sid = sv04c_coord.session(); sv04c_cancel_req = true; } }", "void SV04Claude_Auto60_TouchCancel() { sv04c_cancel_sid = sv04c_coord.session(); sv04c_cancel_req = true; }"),
        ("    if (s == 1) { sv04c_cancel_req = false; sv04c_drain_dwin(); const sv04c::Reason r", "    if (s == 1) { sv04c_drain_dwin(); const sv04c::Reason r"),
        ("    if (sv04c_coord.running() && sv04c_cancel_sid == sv04c_coord.session()) { sv04c_coord.cancel(); sv04c_hb_cancel_armed(); }", "    { sv04c_coord.cancel(); sv04c_hb_cancel_armed(); }")]),
]
OPS_EQUIVALENT = [   # nur EINE von drei Abbruch-Schichten entfernt: die beiden anderen schuetzen weiter (Mehrfachabsicherung)
    ('OG01 Touch-Abbruch wird auch im Leerlauf vorgemerkt (die Schichten Start-Loeschen und Tick-Pruefung schuetzen)', [("void SV04Claude_Auto60_TouchCancel() { if (sv04c_coord.running()) { sv04c_cancel_sid = sv04c_coord.session(); sv04c_cancel_req = true; } }", "void SV04Claude_Auto60_TouchCancel() { sv04c_cancel_sid = sv04c_coord.session(); sv04c_cancel_req = true; }")],
     'durch die beiden anderen Schichten abgesichert (Vorgemerkter Touch wird beim Start verworfen und im Tick auf laufende Sitzung geprueft)'),
    ('OG02 der Start loescht einen vorgemerkten Touch nicht (Schichten Nur-im-Lauf und Tick-Pruefung schuetzen)', [("    if (s == 1) { sv04c_cancel_req = false; sv04c_drain_dwin(); const sv04c::Reason r", "    if (s == 1) { sv04c_drain_dwin(); const sv04c::Reason r")],
     'durch die beiden anderen Schichten abgesichert'),
    ('OG03 der Tick prueft Sitzung und Lauf nicht (Schichten Nur-im-Lauf und Start-Loeschen schuetzen)', [("    if (sv04c_coord.running() && sv04c_cancel_sid == sv04c_coord.session()) { sv04c_coord.cancel(); sv04c_hb_cancel_armed(); }", "    { sv04c_coord.cancel(); sv04c_hb_cancel_armed(); }")],
     'durch die beiden anderen Schichten abgesichert'),
]
OPS_SCEN = None


def ops_scenarios():
    global OPS_SCEN
    if OPS_SCEN is None:
        sys.path.insert(0, str(HERE / 'sim'))
        import test_ee_a60 as EE
        old, new, total = EE.refs()
        EE.run('homed=none', 'ee_cut_at=830', 'ee_out=' + EE.img('om_cut830.img'))
        OPS_SCEN = [('default', ('boot_only=1', 'ee_in=' + EE.img('om_cut830.img'))), ('default', ('homed=none',)), ('noroom', ('homed=none', 's3_end=1')), ('default', ('homed=none', 'touch_idle=1')),
                    ('default', ('homed=none', 'rerun=1', 'touch_late=1', 'limit_s=900')), ('default', ('homed=none', 'touch_after_homeaxis=2', 'touch_burst=5')), ('default', ('homed=none', 'touch_after_homeaxis=2', 'rerun=1', 'limit_s=900')),
                    ('default', ('homed=none', 'target0=70', 'bed0=70', 'bltouch_alarm=1')), ('default', ('homed=none', 'target0=70', 'bed0=70', 'stow_fail=1')), ('default', ('homed=none', 'target0=70', 'bed0=70')),
                    ('default', ('homed=none', 'bltouch_alarm=1', 'rerun=1', 'limit_s=1200', 'target0=70', 'bed0=70')),
                    ('zgate', ('homed=none',)), ('zgate', ('homed=all',)), ('zgate', ('homed=XY',))]
    return OPS_SCEN


OPS_KEYS = ('RESULT', 'RESULT1', 'HMI', 'MESH', 'SERIAL', 'EEBYTES_CHANGED_VS_START', 'STALE', 'EERAW')


def opssig(builds):
    out = []
    for which, a in ops_scenarios():
        try:
            r = B.scenario(builds[which], *a)
            bed = tuple(c.strip() for c in r.get('CMDS', '').split(';') if 'bed_target' in c or 'stop()' in c)           # C2: Heiz-/Stopp-Spur (nach stop() darf kein Heizbefehl folgen)
            out.append(tuple(r.get(k, '') for k in OPS_KEYS) + (bed,))
        except AssertionError:
            out.append(('EXIT!=0',))
    return out


class OpsMutants(unittest.TestCase):
    def _builds(self, tree, tag, work):
        return {'zgate': B.build_integ(tree, tag + 'z', ['SIM_P1_277', 'SV04_CLAUDE_AUTO60_REQUIRE_Z_KNOWN=1'], work), 'default': B.build_integ(tree, tag + 'd', ['SIM_P1_277'], work), 'noroom': B.build_integ(tree, tag + 'n', ['SIM_P1_277', 'SIM_EE_OFFSET=1000', 'SV04_CLAUDE_EEPROM_OFFSET=1000', 'SV04_CLAUDE_EEPROM_REQUIRE_JOURNAL=0'], work)}      # 299: ungeschuetzter Modus nur noch ausdruecklich (292: Standard = Journal Pflicht)

    def _mutate(self, repl):
        src = Path(tempfile.mkdtemp(prefix='ops_src_')); shutil.copytree(ROOT / '02_SOURCE', src / '02_SOURCE')
        f = src / INC; t = f.read_text(encoding='utf-8')
        for old, new in repl:
            self.assertEqual(t.count(old), 1, old[:70]); t = t.replace(old, new)
        f.write_text(t, encoding='utf-8')
        return src / '02_SOURCE'

    def test_every_ops_mutant_changes_observable_behaviour(self):
        sl = os.environ.get('OPS_MUT_SLICE')
        lo, hi = (0, len(OPS_MUTANTS)) if not sl else (0, 0) if sl == 'eq' else tuple(int(v) for v in sl.split(':'))
        work = Path(tempfile.mkdtemp(prefix='ops_mut_'))
        golden = opssig(self._builds(T.shared()['integ'], 'opsg', work))
        report, missed = [], []
        for name, repl in OPS_MUTANTS[lo:hi]:
            try:
                how = 'Verhalten' if opssig(self._builds(integ_with_source(self._mutate(repl)), 'o' + str(abs(hash(name)) % 10**6), work)) != golden else None
            except RuntimeError:
                how = 'Build bricht'
            report.append(f'{name:<130} erkannt: {how}')
            if not how:
                missed.append(name)
        for name, repl, why in (OPS_EQUIVALENT if (not sl or sl == 'eq') else []):
            same = opssig(self._builds(integ_with_source(self._mutate(repl)), 'g' + str(abs(hash(name)) % 10**6), work)) == golden
            report.append(f'{name:<130} gleichwertig (geprueft: Verhalten unveraendert): {same} | {why}')
            if not same:
                missed.append(name + ' (als gleichwertig behauptet, aber das Verhalten aendert sich)')
        (HERE / ('LAST_MUTATION_REPORT_a60_ops%s.txt' % ('' if not sl else '_' + sl.replace(':', '-')))).write_text('\n'.join(report) + '\n', encoding='utf-8')
        self.assertEqual(missed, [], 'UEBERLEBENDE Mutanten:\n' + '\n'.join(report))


# ============================================================================================================ 290 Punkt 3: G29-Abbruch (V1-Hunks, Erweiterung, Abbruchtest im Adapter)
G29_MUTANTS = [      # (Name, [(alt, neu)])  -- in der ECHTEN G29.cpp des Builds 289 (+ Erweiterung)
    ('GM13 C5: die manuelle G29 laeuft im Marlin-Stopp-Zustand', [('    if (IsStopped()) { SERIAL_ERROR_MSG("SV04 C5: G29 refused', '    if (false) { SERIAL_ERROR_MSG("SV04 C5: G29 refused')]),
    ('GM01 V1: Pruefung VOR jeder Messung entfaellt', [("            if (SV04Claude_G29CancelRequested()) {\n              sv04_g29_cancelled = true;\n              set_bed_leveling_enabled(abl.reenable);", "            if (false) {\n              sv04_g29_cancelled = true;\n              set_bed_leveling_enabled(abl.reenable);")]),
    ('GM02 V1: Pruefung NACH jeder Messung entfaellt', [("            if (SV04Claude_G29CancelRequested()) { sv04_g29_cancelled = true; abl.measured_z = NAN; }", "            if (false) { sv04_g29_cancelled = true; abl.measured_z = NAN; }")]),
    ('GM03 V1: die Messung, waehrend der abgebrochen wurde, wird NICHT verworfen', [("            if (SV04Claude_G29CancelRequested()) { sv04_g29_cancelled = true; abl.measured_z = NAN; }", "            if (SV04Claude_G29CancelRequested()) { sv04_g29_cancelled = true; }")]),
    ('GM04 V1: nach dem Abbruch vor der Messung geht die Schleife weiter (break fehlt)', [("              abl.measured_z = NAN;\n              break;\n            }\n          #endif\n\n          abl.probePos", "              abl.measured_z = NAN;\n            }\n          #endif\n\n          abl.probePos")]),
    ('GM05 V1: das Endskript G28 XY laeuft auch nach einem Abbruch (beide IDEX-Wagen)', [("      if (!sv04_g29_cancelled)\n    #endif\n        process_subcommands_now_P", "      if (true)\n    #endif\n        process_subcommands_now_P")]),
    ('GM06 290-Erweiterung: keine Pruefung vor dem Endskript', [("      if (!sv04_g29_cancelled && SV04Claude_G29CancelRequested()) sv04_g29_cancelled = true;\n", "")]),
]
ADAPTER_G29_MUTANTS = [
    ('AM06 C4: die Auto60-Sitzung dieser G29 ist beendet (Marlin-Stopp), die G29 misst trotzdem weiter und faehrt das Endskript', [("  if (sv04c_bound != 0 && sv04c_bound_g29 != 0 && !sv04c_coord.running()) return true;", "  if (false) return true;")]),
    ('AM01 der Abbruchtest meldet nie einen Abbruch', [("  return sv04c_coord.cancel_requested();", "  return false;")]),
    ('AM02 der Abbruchtest liest den DWIN-Puffer nicht selbst', [("  #if SV04_CLAUDE_G29_POLL_DWIN\n    sv04c_poll_dwin();\n  #endif\n  if (sv04c_cancel_req) {", "  if (sv04c_cancel_req) {")]),
    ('AM03 der Touch wird nicht an den Koordinator weitergegeben (und trotzdem verbraucht)', [("    if (sv04c_cancel_sid == sv04c_coord.session()) { sv04c_coord.cancel(); sv04c_hb_cancel_armed(); }\n  }\n  return sv04c_coord.cancel_requested();", "    if (sv04c_cancel_sid == sv04c_coord.session()) { sv04c_hb_cancel_armed(); }\n  }\n  return sv04c_coord.cancel_requested();")]),
    ('AM04 der Abbruchtest greift auch bei einer BENUTZER-G29 (kein Auto60-Lauf in PROBING)', [("  if (!sv04c_coord.running() || sv04c_coord.state() != sv04c::ST_PROBING) return false;\n  #if SV04_CLAUDE_G29_POLL_DWIN", "  #if SV04_CLAUDE_G29_POLL_DWIN")]),
    ('AM05 der Start verwirft alte DWIN-Rahmen nicht', [("sv04c_cancel_req = false; sv04c_drain_dwin(); const sv04c::Reason r", "sv04c_cancel_req = false; const sv04c::Reason r")]),
]
G29S_SCEN = None


def g29s_scenarios():
    global G29S_SCEN
    if G29S_SCEN is None:
        G29S_SCEN = [('homed=none',), ('homed=none', 'touch_after_probe=1', 'no_idle_rts=1'), ('homed=none', 'touch_after_probe=6', 'no_idle_rts=1'), ('homed=none', 'touch_after_probe=6'), ('homed=none', 'touch_after_probe=16', 'no_idle_rts=1'),
                     ('homed=none', 'touch_g29_start=1', 'no_idle_rts=1'), ('homed=none', 'touch_after_homeaxis=6', 'no_idle_rts=1'), ('homed=all', 'manual_g29=1', 'touch_after_probe=6', 'no_idle_rts=1'),
                     ('homed=none', 'rx_idle=3'), ('homed=none', 'touch_after_probe=6', 'no_idle_rts=1', 'rerun=1', 'limit_s=1200'),
                     ('homed=none', 'touch_in_probe=6', 'no_idle_rts=1'), ('homed=none', 'touch_in_probe=16', 'no_idle_rts=1'), ('homed=none', 'touch_in_probe=1', 'no_idle_rts=1'),
                     ('homed=none', 'stop_at_probe=5', 'target0=70', 'bed0=70'),
                     ('homed=all', 'manual_g29=1', 'stopped0=1')]
    return G29S_SCEN


G29S_KEYS = ('RESULT', 'RESULT1', 'COUNTS', 'HOMEAXIS', 'RX', 'EEBYTES_CHANGED_VS_START', 'HMI', 'HMIPAGE', 'CMDS', 'HMICELLWRITES')


def g29sig(exe):
    out = []
    for a in g29s_scenarios():
        try:
            r = B.scenario(exe, *a)
            out.append(tuple(r.get(k, '') for k in G29S_KEYS))
        except AssertionError:
            out.append(('EXIT!=0',))
    return out


class G29CancelMutants(unittest.TestCase):
    def test_every_g29_cancel_mutant_changes_observable_behaviour(self):
        sl = os.environ.get('G29_MUT_SLICE', '0:13'); lo, hi = (int(v) for v in sl.split(':'))
        work = Path(tempfile.mkdtemp(prefix='g29_mut_'))
        tree = T.shared()['integ']
        golden = g29sig(B.build_integ(tree, 'g29golden', ['SIM_P1_277'], work))
        g29text = (tree / 'Marlin/src/gcode/bedlevel/abl/G29.cpp').read_text(encoding='utf-8')
        report, missed = [], []
        allm = [('G', n_, r_) for n_, r_ in G29_MUTANTS] + [('A', n_, r_) for n_, r_ in ADAPTER_G29_MUTANTS]
        for idx, (kind, name, repl) in enumerate(allm):
            if not (lo <= idx < hi):
                continue
            try:
                if kind == 'G':
                    t = g29text
                    for old, new in repl:
                        self.assertEqual(t.count(old), 1, name + ': ' + old[:60]); t = t.replace(old, new)
                    f = work / ('g29_' + str(idx) + '.cpp'); f.write_text(t, encoding='utf-8')
                    sig = g29sig(B.build_integ(tree, 'g29m%d' % idx, ['SIM_P1_277'], work, g29_override=f))
                else:
                    src = Path(tempfile.mkdtemp(prefix='g29a_src_')); shutil.copytree(ROOT / '02_SOURCE', src / '02_SOURCE')
                    f = src / INC; t = f.read_text(encoding='utf-8')
                    for old, new in repl:
                        self.assertEqual(t.count(old), 1, name + ': ' + old[:60]); t = t.replace(old, new)
                    f.write_text(t, encoding='utf-8')
                    sig = g29sig(B.build_integ(integ_with_source(src / '02_SOURCE'), 'g29a%d' % idx, ['SIM_P1_277'], work))
                how = 'Verhalten' if sig != golden else None
            except RuntimeError:
                how = 'Build bricht'
            report.append(f'{name:<110} erkannt: {how}')
            if not how:
                missed.append(name)
        (HERE / ('LAST_MUTATION_REPORT_a60_g29cancel_%s.txt' % sl.replace(':', '-'))).write_text('\n'.join(report) + '\n', encoding='utf-8')
        self.assertEqual(missed, [], 'UEBERLEBENDE Mutanten:\n' + '\n'.join(report))

if __name__ == '__main__':
    unittest.main(verbosity=2)
