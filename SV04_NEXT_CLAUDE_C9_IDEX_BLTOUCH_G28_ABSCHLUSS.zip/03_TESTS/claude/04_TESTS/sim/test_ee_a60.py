"""283 EEPROM (Punkt 5 und 6), ENDE-ZU-ENDE in der Host-Simulation: ECHTER Adapter (sv04_claude_auto60_marlin.inc) + ECHTER EEPROM-Kern + echter G28/G29 + byte-genaues Modell des BL24CXX-Treibers und von Marlins
save()/validate()/load(). Stromausfaelle sind ZWEI-PHASEN-Laeufe: Phase 1 endet beim n-ten geaenderten Byte (Prozessende, Abbild wird geschrieben), Phase 2 ist der Neustart mit diesem Abbild. KEIN STM32, KEINE Hardware."""
import os
import re
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import build_sim_a60 as B  # noqa: E402
import chain_tree as T  # noqa: E402

OFF, LEN = 100, 800
_S = {}
TMP = Path(tempfile.mkdtemp(prefix='ee_'))
BASE = ['SIM_P1_277']


def exe(name='ee', defines=()):
    k = (name, tuple(defines))
    if k not in _S:
        _S.setdefault('work', Path(tempfile.mkdtemp(prefix='ee_w_')))
        _S[k] = B.build_integ(T.shared()['integ'], name, BASE + list(defines), _S['work'])
    return _S[k]


def run(*a, name='ee', defines=()):
    r = B.scenario(exe(name, defines), *a)
    r['t'] = [c.strip() for c in r.get('CMDS', '').split(';') if c.strip()]
    parts = r['RESULT'].split()
    r['state'] = parts[0].split('=')[1]
    r['reason'] = parts[1].split('=')[1] if len(parts) > 1 else ''
    r['raw'] = {k: int(v) for k, v in (kv.split('=') for kv in r.get('EERAW', '').split() if '=' in kv)}
    r['mesh'] = [float(v) for v in r.get('MESH', '').split()]
    r['eemesh'] = [float(v) for v in r.get('EEMESH', '').split()]
    return r


def img(name):
    return str(TMP / name)


def block(path):
    return Path(path).read_bytes()[OFF:OFF + LEN]


def refs():
    """Referenzabbilder: 'alt' (werkseitiger Zustand) und 'neu' (nach einem erfolgreichen Lauf) und die Gesamtzahl geaenderter Bytes eines Laufs."""
    if 'refs' not in _S:
        run('boot_only=1', 'ee_out=' + img('old.img'))
        r = run('homed=none', 'ee_out=' + img('new.img'))
        assert (r['state'], r['reason']) == ('SUCCESS', 'VERIFIED'), r['RESULT']
        _S['refs'] = (block(img('old.img')), block(img('new.img')), r['raw']['changed'])
        assert _S['refs'][0] != _S['refs'][1]
    return _S['refs']


def mutated(name, fn):
    old = bytearray(Path(img('old.img')).read_bytes())
    fn(old)
    p = img(name)
    Path(p).write_bytes(bytes(old))
    return p


def near(a, b, tol=1e-6):
    return len(a) == len(b) and all(abs(x - y) <= tol for x, y in zip(a, b))


class PowerLoss(unittest.TestCase):
    def points(self, total):
        # Journal-Anlage (0..~816), Beginn des Hauptschreibens, Mitte, Kopf/CRC, letztes Byte (Journal verwerfen)
        pts = {0, 1, 2, 3, 4, 5, 8, 16, 100, 400, 799, 800, 801, 810, 811, 812, 813, 814, 815, 816, 817, 818, 820, 830, 840, 850, 860, 870}
        pts |= {total - k for k in (1, 2, 3, 4, 5, 6, 8, 10, 20, 40)}
        return sorted(p for p in pts if 0 <= p < total)

    def test_E01_power_loss_at_every_sampled_point_of_a_complete_run_leaves_a_valid_block_old_or_new_never_a_mix(self):
        old, new, total = refs()
        outcomes = {'old': 0, 'new': 0}
        for n in self.points(total):
            p1 = run('homed=none', f'ee_cut_at={n}', 'ee_out=' + img(f'cut{n}.img'))
            self.assertEqual(p1['state'], 'POWERLOSS', f'cut@{n}')
            p2 = run('boot_only=1', 'ee_in=' + img(f'cut{n}.img'), 'ee_out=' + img(f'boot{n}.img'))
            b = block(img(f'boot{n}.img'))
            self.assertEqual(p2['raw']['primary'], 5, f'cut@{n}: nach dem Neustart ist der Block GUELTIG')
            self.assertEqual(p2['raw']['journal_inflight'], 0, f'cut@{n}: kein Journal bleibt in Arbeit')
            self.assertIn(p2['raw']['boot_res'], (0, 1, 2), f'cut@{n}: Wiederherstellung nie gescheitert')
            kind = 'new' if b == new else 'old' if b == old else None
            self.assertIsNotNone(kind, f'cut@{n}: Block ist WEDER exakt alt NOCH exakt neu (Gemisch)')
            self.assertEqual(kind, 'old', f'cut@{n}: seit ChatGPTs 306 (CRC-gueltig, aber unverifiziert) bleibt OHNE abgeschlossenes Journal immer der ALTE, verifizierte Block (auch wenn nur das Schliessen des Journals fehlt)')
            self.assertTrue(near(p2['mesh'], p2['eemesh']), f'cut@{n}: nach dem Neustart steht im RAM dasselbe Mesh wie im EEPROM')
            outcomes[kind] += 1
        self.assertGreater(outcomes['old'], 30); self.assertEqual(outcomes['new'], 0)

    def test_E02_a_second_power_loss_during_the_recovery_is_also_recovered(self):
        old, new, total = refs()
        base = None
        for n in (815, 840, 870):                                       # Abschaltung im Hauptschreiben; die Wiederherstellung wird ihrerseits unterbrochen
            p1 = run('homed=none', f'ee_cut_at={n}', 'ee_out=' + img(f'c1_{n}.img')); self.assertEqual(p1['state'], 'POWERLOSS')
            done = 0
            for k in (0, 1, 2, 5, 20, 40, 60):
                p2 = run('boot_only=1', 'ee_in=' + img(f'c1_{n}.img'), f'ee_cut_at={k}', 'ee_out=' + img(f'c2_{n}_{k}.img'))
                src = img(f'c2_{n}_{k}.img') if p2['state'] == 'POWERLOSS' else None
                if src is None:
                    continue                                          # die Wiederherstellung brauchte weniger geaenderte Bytes als k
                p3 = run('boot_only=1', 'ee_in=' + src, 'ee_out=' + img(f'c3_{n}_{k}.img'))
                self.assertEqual(p3['raw']['primary'], 5, f'{n}/{k}'); self.assertEqual(block(img(f'c3_{n}_{k}.img')), old, f'{n}/{k}: der ALTE Block ist wieder da')
                self.assertEqual(p3['raw']['journal_inflight'], 0); done += 1
            self.assertGreaterEqual(done, 1, f'cut@{n}: mindestens eine verschachtelte Abschaltung wurde wirklich getestet')

    def test_E03_clean_boot_after_a_complete_successful_run_has_nothing_to_recover(self):
        old, new, total = refs()
        p2 = run('boot_only=1', 'ee_in=' + img('new.img'))
        self.assertEqual((p2['raw']['primary'], p2['raw']['boot_res'], p2['raw']['journal_inflight']), (5, 0, 0))
        self.assertIn('OK', ' '.join(p2['SERIAL'].split('=>')[-1:]), 'M1060 S2: gespeichertes Mesh == RAM-Mesh nach dem Neustart (Wiederherstellung nachgewiesen)')


class WriteFailures(unittest.TestCase):
    def settled_after_reboot(self, path, old, new, tag):
        """Neustart mit dem Abbild: der Block ist danach GUELTIG und genau der alte oder genau der neue (nie gemischt)."""
        r = run('boot_only=1', 'ee_in=' + path, 'ee_out=' + path + '.rb')
        self.assertEqual(r['raw']['boot_primary'], 5, tag + ': nach dem Neustart gueltig'); self.assertIn(block(path + '.rb'), (old, new), tag + ': nach dem Neustart alt ODER neu, nie gemischt')

    def test_E04_a_write_error_at_any_sampled_position_is_never_a_false_success(self):
        old, new, total = refs()
        pts = sorted({0, 1, 5, 100, 500, 799, 800, 810, 815, 816, 820, 830, 840, 850, 860, 870} | {total - k for k in (1, 2, 3, 5, 10, 30)})
        n_success = n_fail = 0
        for n in (p for p in pts if p < total):
            r = run('homed=none', f'ee_fail_at={n}', 'ee_out=' + img(f'wf{n}.img'))
            b = block(img(f'wf{n}.img'))
            self.assertEqual(r['raw']['primary'], 5, f'fail@{n}: der Block ist am Ende GUELTIG')
            if r['state'] == 'SUCCESS':
                self.assertEqual(b[:0] + b, new, f'fail@{n}: SUCCESS nur, wenn der Block bitgleich der erwartete NEUE ist'); n_success += 1
                self.assertTrue(near(r['mesh'], r['eemesh']))
            else:
                if r['reason'] == 'EEPROM_RECOVERY_REQUIRED':                      # 299 (293/294): nur das BEENDEN des Journals scheiterte; der neue Block ist gueltig und verifiziert, der Lauf ist trotzdem FAILED
                    self.assertEqual(b, new, f'fail@{n}: Journal-Abschluss gescheitert -> gueltiger NEUER Block'); self.settled_after_reboot(img(f'wf{n}.img'), old, new, f'fail@{n}')
                else:
                    self.assertEqual(b, old, f'fail@{n}: Fehlschlag -> der ALTE Block ist wiederhergestellt (nicht beschaedigt)')
                n_fail += 1
                self.assertNotEqual(r['HMIPAGE'], '22', f'fail@{n}: kein "fertig"')
            self.assertEqual(r['RAM'].split()[0], 'zoff_unchanged=1')
        self.assertGreater(n_success + n_fail, 20)

    def test_E05_journal_cannot_be_created_io_error_in_the_journal_area_aborts_before_any_write_to_the_main_block(self):
        old, new, total = refs()
        r = run('homed=none', 'ee_fail_at=300', 'ee_out=' + img('jf.img'))
        self.assertEqual((r['state'], r['reason']), ('FAILED', 'EEPROM_PREPARE_FAILED'))
        self.assertEqual(block(img('jf.img')), old, 'der Hauptblock wurde nie angefasst')
        self.assertEqual(r['EEMAINEQ'], '1'); self.assertEqual(r['raw']['journal_inflight'], 0)

    def test_E06_silent_corruption_with_a_valid_checksum_is_caught_and_the_old_block_comes_back(self):
        old, new, total = refs()
        r = run('homed=none', 'save=3', 'ee_out=' + img('corr.img'))
        self.assertEqual(r['state'], 'FAILED'); self.assertEqual(r['reason'], 'VERIFY_MISMATCH'); self.assertEqual(block(img('corr.img')), old)
        self.assertNotEqual(r['HMIPAGE'], '22'); self.assertEqual(r['EEMAINEQ'], '1')

    def test_E07_save_aborts_after_the_err_marker_and_the_old_block_is_restored_bytewise(self):
        old, new, total = refs()
        for mode in (1, 2):
            r = run('homed=none', f'save={mode}', 'ee_out=' + img(f'sm{mode}.img'))
            self.assertEqual(r['state'], 'FAILED', mode); self.assertEqual(block(img(f'sm{mode}.img')), old, mode); self.assertEqual(r['raw']['primary'], 5)

    def test_E22_a_stored_zoffset_that_differs_is_caught_even_when_mesh_and_checksum_are_fine(self):
        old, new, total = refs()
        r = run('homed=none', 'save=5', 'ee_out=' + img('zoff.img'))
        self.assertEqual((r['state'], r['reason']), ('FAILED', 'VERIFY_MISMATCH')); self.assertEqual(block(img('zoff.img')), old, 'der ALTE Block (mit dem alten Z-Offset) ist zurueck')
        self.assertNotEqual(r['HMIPAGE'], '22'); self.assertEqual(r['RAM'].split()[0], 'zoff_unchanged=1')

    def test_E23_the_independent_checksum_catches_a_block_that_marlins_own_validate_wrongly_accepts(self):
        old, new, total = refs()
        r = run('homed=none', 'save=6', 'ee_out=' + img('crc_lie.img'))
        self.assertEqual((r['state'], r['reason']), ('FAILED', 'VERIFY_CRC'), 'Marlins validate() sagt "gueltig", die EIGENE CRC ueber die Rohbytes widerspricht -> kein Erfolg')
        self.assertEqual(block(img('crc_lie.img')), old); self.assertNotEqual(r['HMIPAGE'], '22')

    def test_E08_first_save_fails_once_second_succeeds_with_a_single_journal(self):
        old, new, total = refs()
        r = run('homed=none', 'save=4', 'ee_out=' + img('once.img'))
        self.assertEqual((r['state'], r['reason']), ('SUCCESS', 'VERIFIED')); self.assertEqual(block(img('once.img')), new)
        self.assertEqual(r['raw']['journal_inflight'], 0)


class DamagedData(unittest.TestCase):
    def refused(self, name, fn, why):
        refs()
        p = mutated(name, fn)
        r = run('homed=none', 'ee_in=' + p)
        self.assertEqual((r['state'], r['reason']), ('IDLE', 'NONE'), why)
        self.assertIn('Auto60 refused: PRE_EEPROM_UNAVAILABLE', r['SERIAL'], why)
        self.assertEqual(r['EEBYTES_CHANGED_VS_START'], '0', why + ': KEIN Byte geschrieben')
        self.assertEqual(r['HOMEAXIS'], 'count=0', why + ': nicht einmal referenziert')
        return r

    def test_E09_damaged_unfinished_or_foreign_data_is_never_overwritten_automatically(self):
        self.refused('d_crc.img', lambda b: b.__setitem__(OFF + 300, b[OFF + 300] ^ 1), 'CRC falsch')
        self.refused('d_err.img', lambda b: b.__setitem__(slice(OFF, OFF + 4), b'ERR\0'), 'unterbrochener Kopf ohne Journal')
        self.refused('d_foreign.img', lambda b: b.__setitem__(OFF, ord('X')), 'fremder Kopf')
        self.refused('d_old_version.img', lambda b: b.__setitem__(slice(OFF, OFF + 4), b'V84\0'), 'andere Version')

    def test_E10_a_never_written_eeprom_is_allowed_and_ends_valid(self):
        refs()
        p = mutated('blank.img', lambda b: b.__setitem__(slice(0, 2048), b'\xff' * 2048))
        r = run('homed=none', 'ee_in=' + p, 'ee_out=' + img('blank_after.img'))
        self.assertEqual((r['state'], r['reason']), ('SUCCESS', 'VERIFIED'))
        self.assertEqual(r['raw']['primary'], 5); self.assertIn('Schutz beim Speichern = nicht noetig (EEPROM noch leer)', r['SERIAL'], 'leerer Block: nichts zu schuetzen, kein Journal (die Meldung ist das Verhalten)'); self.assertIn(r['raw']['journal_state'], (0, 3), 'C6: der 317-Adapter setzt die interne Journal-Statusvariable nach dem Lauf auf 0 zurueck (318); mein 309/C5-Adapter hielt 3')

    def test_E11_a_dead_bus_that_returns_garbage_without_an_error_is_never_a_success(self):
        r = run('homed=none', 'ee_unreadable=1')
        self.assertNotEqual(r['state'], 'SUCCESS'); self.assertNotEqual(r['HMIPAGE'], '22')

    def test_E12_manual_raw_verification_m1060_s2_flags_a_damaged_block(self):
        refs()
        p = mutated('s2.img', lambda b: b.__setitem__(OFF + 300, b[OFF + 300] ^ 1))
        r = run('boot_only=1', 'ee_in=' + p)
        self.assertIn('ABWEICHUNG', r['SERIAL']); self.assertIn('primary=4', r['SERIAL'])
        g = run('boot_only=1', 'ee_in=' + img('old.img'))
        self.assertIn('=> OK', g['SERIAL'])
        self.assertIn('block=100+800', g['SERIAL']); self.assertIn('journal_platz=ja', g['SERIAL'])


class NoUnneededWrites(unittest.TestCase):
    def test_E13_a_mesh_that_is_already_stored_is_not_written_again_and_unsaved_other_settings_are_not_taken_along(self):
        old, new, total = refs()
        r = run('homed=none', 'ee_in=' + img('new.img'), 'other_dirty=1', 'ee_out=' + img('skip.img'))
        self.assertEqual((r['state'], r['reason']), ('SUCCESS', 'VERIFIED')); self.assertEqual(r['raw']['skipped'], 1)
        self.assertEqual(r['EEBYTES_CHANGED_VS_START'], '0', 'kein einziger Schreibzyklus'); self.assertEqual(block(img('skip.img')), new)
        self.assertEqual(r['raw']['journal_present'] if False else r['raw']['other'], 0)

    def test_E14_other_unsaved_settings_are_taken_along_by_a_real_save_and_that_is_reported(self):
        old, new, total = refs()
        r = run('homed=none', 'other_dirty=1')
        self.assertEqual((r['state'], r['reason']), ('SUCCESS', 'VERIFIED')); self.assertGreaterEqual(r['raw']['other'], 1)
        self.assertIn('weitere Bytes des Einstellungsblocks', r['SERIAL'])

    def test_E15_a_normal_run_writes_only_the_mesh_the_journal_and_the_header(self):
        old, new, total = refs()
        r = run('homed=none')
        self.assertEqual(r['raw']['other'], 0, 'ausser dem Mesh (und Kopf/CRC) aendert sich im Hauptblock nichts')
        main_changed = sum(1 for a, b in zip(old, new) if a != b)
        self.assertLess(main_changed, 90, 'Mesh 64 Bytes + Kopf/CRC: nicht der ganze Block'); self.assertEqual(r['RAM'].split()[0], 'zoff_unchanged=1')

    def test_E16_second_journal_creation_rewrites_only_what_changed(self):
        old, new, total = refs()
        r = run('homed=none', 'ee_in=' + img('new.img'), 'save=0', 'ee_out=' + img('second.img'), 'other_dirty=0')
        self.assertEqual(r['state'], 'SUCCESS')
        self.assertLess(r['raw']['changed'], 120, 'die Kopie im Journal ist schon da: nur Unterschiede werden geschrieben (Verschleiss)')


class EveryFailureBeforeTheSave(unittest.TestCase):
    CASES = [['x_early_t1=1'], ['x_early_t0=1'], ['stow_fail=1'], ['deploy_fail=1'], ['x_t1_on_call=2'], ['touch_after_homeaxis=2'], ['touch_after_probe=6'], ['kick_after_homeaxis=2', 'kick=40'],
             ['print_after_homeaxis=2'], ['hotend_x1=400'], ['nan_at=9'], ['val_at=5', 'val=12'], ['val_at=5', 'val=45'], ['touch_at=HEATING'], ['cancel_after_homeaxis=2']]

    def test_E17_no_eeprom_byte_is_written_and_no_journal_is_created_in_any_failure_or_cancel_before_the_save(self):
        refs(); n = 0
        for opt in self.CASES:
            r = run('homed=none', *opt)
            self.assertNotEqual(r['state'], 'SUCCESS', str(opt))
            self.assertEqual(r['EEBYTES_CHANGED_VS_START'], '0', str(opt) + ': KEIN EEPROM-Schreibzugriff'); self.assertEqual(r['EEMAINEQ'], '1', str(opt))
            self.assertEqual(r['raw']['journal_present'], 0, str(opt) + ': auch kein Journal angelegt'); self.assertEqual(r['raw']['primary'], 5, str(opt))
            self.assertEqual(r['RAM'].split()[0], 'zoff_unchanged=1', str(opt)); self.assertNotEqual(r['HMIPAGE'], '22', str(opt)); n += 1
        self.assertEqual(n, len(self.CASES))

    def test_E18_success_means_verified_raw_data_and_the_success_page_is_only_shown_then(self):
        old, new, total = refs()
        r = run('homed=none', 'ee_out=' + img('ok.img'))
        self.assertEqual((r['state'], r['HMIPAGE']), ('SUCCESS', '22')); self.assertEqual(block(img('ok.img')), new)
        self.assertEqual(r['raw']['last_commit'], 1, 'Transaktion abgeschlossen (verifiziert)'); self.assertEqual(r['raw']['journal_inflight'], 0)
        self.assertTrue(near(r['mesh'], r['eemesh'])); self.assertEqual(r['EEZOFF'], r['RAMZOFF'], 'Z-Offset im EEPROM == RAM == vor dem Lauf')
        self.assertEqual(r['COUNTS'].split()[2], 'settings_save=1')
        self.assertLess(r['t'].index('settings.save'), r['t'].index('eeprom_validate'))
        self.assertNotIn('settings.load', r['t'], 'KEIN settings.load(): es schaltet die Nivellierung aus (settings.cpp:1676)')
        self.assertEqual(r['RAM'].split()[1], 'leveling=1', 'die Nivellierung ist nach der Pruefung weiterhin AN')


class Profiles(unittest.TestCase):
    def test_E19_a_wrong_eeprom_offset_makes_auto60_fail_closed(self):
        refs()
        for off in (600, 1300):
            r = run('homed=none', name=f'off{off}', defines=[f'SV04_CLAUDE_EEPROM_OFFSET={off}'])
            self.assertEqual((r['state'], r['reason']), ('IDLE', 'NONE'), off); self.assertIn('PRE_EEPROM_UNAVAILABLE', r['SERIAL'], off); self.assertEqual(r['EEBYTES_CHANGED_VS_START'], '0', off)

    def test_E20_no_room_for_the_journal_saves_without_it_and_a_failure_is_then_reported_as_unrecoverable(self):
        d = ['SIM_EE_OFFSET=1000', 'SV04_CLAUDE_EEPROM_OFFSET=1000', 'SV04_CLAUDE_EEPROM_REQUIRE_JOURNAL=0']          # 299: Standard ist REQUIRE_JOURNAL=1 (292); der ungeschuetzte Modus ist nur noch eine ausdrueckliche Wahl
        ok = run('homed=none', name='noroom', defines=d)
        self.assertEqual((ok['state'], ok['reason']), ('SUCCESS', 'VERIFIED')); self.assertEqual(ok['raw']['journal_room'], 0); self.assertIn('Schutz beim Speichern = KEINER, WARNUNG: kein Platz fuer das Undo-Journal', ok['SERIAL'], 'ohne Journal (kein Platz), gemeldet (die Meldung ist das Verhalten)'); self.assertIn(ok['raw']['journal_state'], (0, 2), 'C6: 317 setzt die interne Statusvariable nach dem Lauf zurueck')
        bad = run('homed=none', 'save=1', name='noroom', defines=d)
        self.assertEqual((bad['state'], bad['reason']), ('FAILED', 'EEPROM_RECOVERY_REQUIRED'), 'ohne Journal ist ein gescheitertes Speichern NICHT stillschweigend "ok"')
        self.assertNotEqual(bad['HMIPAGE'], '22')

    def test_E21_requiring_the_journal_refuses_to_start_when_there_is_no_room(self):
        r = run('homed=none', name='noroom_req', defines=['SIM_EE_OFFSET=1000', 'SV04_CLAUDE_EEPROM_OFFSET=1000', 'SV04_CLAUDE_EEPROM_REQUIRE_JOURNAL=1'])
        self.assertEqual((r['state'], r['reason']), ('IDLE', 'NONE')); self.assertIn('PRE_EEPROM_UNAVAILABLE', r['SERIAL']); self.assertEqual(r['EEBYTES_CHANGED_VS_START'], '0')


if __name__ == '__main__':
    unittest.main(verbosity=2)
