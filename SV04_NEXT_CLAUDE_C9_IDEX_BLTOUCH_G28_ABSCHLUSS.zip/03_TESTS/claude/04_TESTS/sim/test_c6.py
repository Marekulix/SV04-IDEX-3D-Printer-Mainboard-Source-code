"""C6: 318-Installer (ChatGPT) und gehaerteter Aufruf. Eine MINIMALE 309-Fixture aus den im Paket liegenden Dateien (nur was der Installer anfasst); KEIN vollstaendiger OEM-Baum, KEIN STM32-Build, KEINE Hardware.
 C601  Original-Installer: positiv, Ziel existiert, fremde OEM-Datei -> BLOCKED; die 309-Quelle bleibt byte-gleich
 C602  LUECKE: der Original-Installer ueberschreibt einen ABWEICHENDEN Adapter/Kern stillschweigend; der gehaertete Aufruf blockiert (Exitcode 4) und schreibt nichts
 C603  Installer-Ergebnis == meine Patchkette (tool_change, motion, G29, Kern, Richtlinie byte-gleich); Adapter == die gepinnte 317-Datei
 C604  die 318-Dateien in 02_SOURCE sind die gepinnten 318-Dateien"""
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
CLAUDE = HERE.parents[1]
sys.path.insert(0, str(HERE)); sys.path.insert(0, str(CLAUDE / '03_PATCHES'))
import apply_dxc_no_trust_c3 as DX  # noqa: E402
import apply_g29_stopped_c5 as G5  # noqa: E402
import apply_start_release_c4 as S4  # noqa: E402
import apply_zgate_c5 as ZG  # noqa: E402
import apply_zhome_cold_c5 as ZC  # noqa: E402
import apply_zhome_limit_c3 as Z3  # noqa: E402
import test_c3 as T3  # noqa: E402

B = CLAUDE / '01_BASELINE'; INST = B / 'STAND_318/original_installer'; STRICT = CLAUDE / 'tools/integrate_318_strict.py'
sha = lambda b: hashlib.sha256(b).hexdigest()
REL = {'tc': 'Marlin/src/module/tool_change.cpp', 'mo': 'Marlin/src/module/motion.cpp', 'g29': 'Marlin/src/gcode/bedlevel/abl/G29.cpp', 'core': 'Marlin/src/feature/sv04_claude_auto60/sv04_claude_auto60_core.h',
       'inc': 'Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc', 'ee': 'Marlin/src/feature/sv04_claude_auto60/sv04_claude_eeprom_core.h', 'hooks': 'Marlin/src/lcd/e3v2/creality/sv04_claude_hooks.h',
       'g29s': 'Marlin/src/feature/sv04_claude_auto60/sv04_claude_g29_session.h', 'tcp': 'Marlin/src/feature/sv04_claude_auto60/sv04_claude_toolchange_policy.h', 'tcg': 'Marlin/src/gcode/control/sv04_claude_toolchange_guard.h', 'mesh': 'Marlin/src/lcd/e3v2/creality/sv04_claude_oem_mesh_loop.inc'}


def g29_309():
    d = Path(tempfile.mkdtemp()); (d / 'Marlin/src/gcode/bedlevel/abl').mkdir(parents=True); shutil.copy(B / 'OEM_309/orig/gcode/bedlevel/abl/G29.cpp', d / REL['g29'])
    txt = (B / 'OEM_309/combined_308.patch').read_text(encoding='utf-8'); s0 = txt.index('diff --git a/Marlin/src/gcode/bedlevel/abl/G29.cpp'); s1 = txt.index('diff --git ', s0 + 10); (d / 'one.patch').write_text(txt[s0:s1], encoding='utf-8')
    assert subprocess.run(['patch', '-p1', '--no-backup-if-mismatch', '-d', str(d), '-i', str(d / 'one.patch')], capture_output=True).returncode == 0
    return (d / REL['g29']).read_bytes()


def fixture():
    d = Path(tempfile.mkdtemp()) / 'f309'
    files = {'tc': (B / 'OEM_FILES/Marlin/src/module/tool_change.cpp').read_bytes(), 'mo': T3.reconstruct_309_motion(), 'g29': g29_309(), 'core': (B / 'STAND_309/sv04_claude_auto60_core.h').read_bytes(),
             'inc': (B / 'STAND_309/sv04_claude_auto60_marlin.inc').read_bytes(), 'ee': (CLAUDE / '02_SOURCE' / REL['ee']).read_bytes(), 'hooks': (B / 'STAND_318/sv04_claude_hooks.h').read_bytes(),
             'g29s': (CLAUDE / '02_SOURCE' / REL['g29s']).read_bytes(), 'tcp': (CLAUDE / '02_SOURCE' / REL['tcp']).read_bytes(), 'tcg': (CLAUDE / '02_SOURCE' / REL['tcg']).read_bytes(), 'mesh': (B / 'STAND_309/sv04_claude_oem_mesh_loop.inc').read_bytes()}
    for k, v in files.items(): (d / REL[k]).parent.mkdir(parents=True, exist_ok=True); (d / REL[k]).write_bytes(v)
    (d / 'Marlin/src/MarlinCore.cpp').write_text('// Fixture\n')
    return d


def run(script, *a): return subprocess.run([sys.executable, '-B', str(script)] + [str(x) for x in a], capture_output=True, text=True)
def snap(d): return {p.relative_to(d).as_posix(): sha(p.read_bytes()) for p in sorted(d.rglob('*')) if p.is_file()}


class Installer(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.f = fixture(); cls.before = snap(cls.f)

    def test_C601_the_original_installer_is_fail_closed_for_target_and_foreign_oem_files_and_never_touches_the_309_source(self):
        out = self.f.parent / 'o1'; r = run(INST / 'integrate_318.py', self.f, out); self.assertEqual(r.returncode, 0, r.stdout + r.stderr); self.assertIn('318 SOURCE OVERLAY APPLIED', r.stdout)
        self.assertEqual(run(INST / 'integrate_318.py', self.f, out).returncode, 2, 'vorhandenes Ziel'); self.assertEqual(snap(self.f), self.before, 'die 309-Quelle bleibt byte-gleich')
        fo = self.f.parent / 'foreign'; shutil.copytree(self.f, fo); (fo / REL['mo']).write_bytes((fo / REL['mo']).read_bytes() + b'\n'); r = run(INST / 'integrate_318.py', fo, self.f.parent / 'o_foreign'); self.assertEqual(r.returncode, 3); self.assertFalse((self.f.parent / 'o_foreign').exists())

    def test_C602_gap_the_original_overwrites_a_deviating_adapter_silently_the_strict_call_blocks_and_writes_nothing(self):
        for key in ('inc', 'core', 'ee', 'hooks', 'g29s', 'tcp', 'tcg', 'mesh'):
            odd = self.f.parent / ('odd_' + key); shutil.copytree(self.f, odd); (odd / REL[key]).write_bytes((odd / REL[key]).read_bytes() + b'\n// abweichend\n'); b = snap(odd)
            o = run(INST / 'integrate_318.py', odd, self.f.parent / ('orig_out_' + key))
            if key in ('inc', 'core'): self.assertEqual(o.returncode, 0, 'LUECKE: der Original-Installer ueberschreibt die abweichende Datei ' + key + ' ohne Pruefung')           # die uebrigen Dateien beruehrt der Original-Installer nicht: nur der gehaertete Aufruf prueft sie
            s = run(STRICT, INST, odd, self.f.parent / ('strict_out_' + key)); self.assertEqual(s.returncode, 4, key + ': ' + s.stdout); self.assertFalse((self.f.parent / ('strict_out_' + key)).exists(), 'nichts geschrieben'); self.assertEqual(snap(odd), b)
        ok = run(STRICT, INST, self.f, self.f.parent / 'strict_ok'); self.assertEqual(ok.returncode, 0, ok.stdout); self.assertIn('STRICT_PRECHECK=OK (alle 8 Claude-Dateien', ok.stdout)

    def test_C605_unknown_missing_and_pre_existing_claude_state_is_rejected_without_any_side_effect(self):
        """C7 Standardpfad: eine UNBEKANNTE sv04_claude_*-Datei im Baum, eine FEHLENDE bekannte Datei und ein vorhandenes Ziel werden abgewiesen (Exitcode 4), es entsteht kein Ziel, die Quelle bleibt byte-gleich."""
        unk = self.f.parent / 'unk'; shutil.copytree(self.f, unk); (unk / 'Marlin/src/feature/sv04_claude_auto60/sv04_claude_neue_datei.h').write_text('// unbekannt\n'); b = snap(unk)
        r = run(STRICT, INST, unk, self.f.parent / 'unk_out'); self.assertEqual(r.returncode, 4); self.assertIn('UNBEKANNTE Claude-Datei', r.stdout); self.assertFalse((self.f.parent / 'unk_out').exists()); self.assertEqual(snap(unk), b)
        mis = self.f.parent / 'mis'; shutil.copytree(self.f, mis); (mis / REL['mesh']).unlink(); r = run(STRICT, INST, mis, self.f.parent / 'mis_out'); self.assertEqual(r.returncode, 4); self.assertIn('FEHLT', r.stdout); self.assertFalse((self.f.parent / 'mis_out').exists())
        pre = self.f.parent / 'pre_target'; pre.mkdir(); r = run(STRICT, INST, self.f, pre); self.assertEqual(r.returncode, 4); self.assertIn('Ziel existiert bereits', r.stdout); self.assertEqual(list(pre.iterdir()), [], 'das vorhandene Ziel wurde nicht angefasst')
        nof = self.f.parent / 'nofile'; r = run(STRICT, self.f.parent / 'kein_installer', self.f, nof); self.assertNotEqual(r.returncode, 0); self.assertFalse(nof.exists())

    def test_C603_the_installer_result_equals_my_patch_chain_for_five_files_and_the_adapter_is_the_pinned_317_file(self):
        out = self.f.parent / 'o3'; self.assertEqual(run(INST / 'integrate_318.py', self.f, out).returncode, 0)
        w = self.f.parent / 'chain'; shutil.copytree(self.f, w); (w / REL['inc']).write_bytes((B / 'STAND_309/sv04_claude_auto60_marlin.inc').read_bytes())
        for s in ('apply_dxc_no_trust_c3', 'apply_zhome_limit_c3', 'apply_zhome_cold_c5', 'apply_start_release_c4', 'apply_zgate_c5', 'apply_g29_stopped_c5'): self.assertEqual(run(CLAUDE / '03_PATCHES' / (s + '.py'), w).returncode, 0, s)
        for rel in (REL['tc'], REL['mo'], REL['g29'], REL['core'], 'Marlin/src/feature/sv04_claude_auto60/sv04_claude_zhome_policy.h'): self.assertEqual((out / rel).read_bytes(), (w / rel).read_bytes(), rel)
        self.assertEqual((out / REL['inc']).read_bytes(), (B / 'STAND_318/sv04_claude_auto60_marlin.inc').read_bytes()); self.assertNotEqual((out / REL['inc']).read_bytes(), (w / REL['inc']).read_bytes(), 'der 317-Adapter ist NICHT meine Kette')

    def test_C604_the_318_files_in_the_source_store_are_exactly_the_pinned_318_files_and_the_core_is_the_c5_core(self):
        pins = dict(reversed(l.split()) for l in (B / 'STAND_318/SHA256SUMS.txt').read_text().splitlines())
        for key, name in (('inc', 'sv04_claude_auto60_marlin.inc'), ('core', 'sv04_claude_auto60_core.h'), ('ee', 'sv04_claude_eeprom_core.h'), ('hooks', 'sv04_claude_hooks.h')): self.assertEqual(sha((CLAUDE / '02_SOURCE' / REL[key]).read_bytes()), pins[name], name)
        core309 = (B / 'STAND_309/sv04_claude_auto60_core.h').read_bytes(); inc309 = (B / 'STAND_309/sv04_claude_auto60_marlin.inc').read_bytes()
        c4, i4, _ = S4.transform(core309, inc309); c5, _i5, _ = ZG.transform(c4, i4)
        self.assertEqual(sha(c5), pins['sv04_claude_auto60_core.h'], 'Kern 318 == 309 + C4 + C5 (meine Kette)')
        self.assertNotEqual(sha(c4), pins['sv04_claude_auto60_core.h'], 'Gegenprobe: ohne C5 waere es ein anderer Kern, die Pruefung kann also fehlschlagen')


if __name__ == '__main__':
    unittest.main(verbosity=2)
