"""Betrieb (Auftrag 285): DWIN-Anzeige, Abbruch und EEPROM-Schutz gegen die ECHTE Produktionslogik (Adapter, Koordinator, EEPROM-Kern, echte G28/G29, byte-genaues EEPROM-Modell, HMI-Modell der 16 Zellen).
Host-Simulation; KEIN STM32, KEINE Hardware, KEIN HMI-Projekt (die Seiten-/Typangaben des HMI bleiben unbewiesen)."""
import re
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import test_ee_a60 as E  # noqa: E402

NOROOM = ['SIM_EE_OFFSET=1000', 'SV04_CLAUDE_EEPROM_OFFSET=1000']
NOROOM_UNPROTECTED = NOROOM + ['SV04_CLAUDE_EEPROM_REQUIRE_JOURNAL=0']      # 299 (292): Standard ist REQUIRE_JOURNAL=1; ohne Platz nur mit ausdruecklichem 0 ungeschuetzt


def cells_from_mesh(m):
    """RAM-Mesh (Ausgabe "MESH": y-Zeilen, x-Spalten) -> Anzeigereihenfolge k (OEM: Schlangenlinie, Werte mal 1000 abgeschnitten)."""
    z, i = {}, 0
    for y in range(4):
        for x in range(4):
            z[(x, y)] = m[i]; i += 1
    return [int(z[(x, y)] * 1000) for y in range(4) for x in (range(3, -1, -1) if y % 2 == 0 else range(0, 4))]


def hmi(r):
    return [int(v) for v in r['HMI'].split()]


def close(a, b, tol=1):
    return len(a) == len(b) and all(abs(x - y) <= tol for x, y in zip(a, b))


class Display(unittest.TestCase):
    def test_OP01_after_a_boot_recovery_the_display_shows_the_restored_mesh_not_empty_cells(self):
        """Fund: die OEM-Bootschleife sendet VOR der Wiederherstellung die Standardwerte; ohne erneutes Senden zeigte das Display nach einem Stromausfall im Speichern ein LEERES Mesh."""
        old, new, total = E.refs()
        n_restored = 0
        for n in (0, 800, 812, 815, 830, 850, 870, 880, total - 1):
            E.run('homed=none', f'ee_cut_at={n}', 'ee_out=' + E.img(f'op1_{n}.img'))
            r = E.run('boot_only=1', 'ee_in=' + E.img(f'op1_{n}.img'))
            self.assertTrue(close(hmi(r), cells_from_mesh(r['mesh'])), f'cut@{n} boot_res={r["raw"]["boot_res"]}: Display {hmi(r)[:6]} != RAM {cells_from_mesh(r["mesh"])[:6]}')
            n_restored += r['raw']['boot_res'] == 2
        self.assertGreaterEqual(n_restored, 4, 'mindestens vier Faelle haben wirklich zurueckgespielt')


    def test_OP02_hypothesis_refuted_a_rollback_to_an_invalid_old_mesh_leaves_no_stale_discarded_values_in_the_display(self):
        """Geprueft und WIDERLEGT: nach Fehler/Abbruch bei LEEREM altem Mesh (NaN) zeigt das Display den Startzustand, nicht die Werte des verworfenen Laufs."""
        E.refs(); b = E.mutated('op02_blank.img', lambda x: x.__setitem__(slice(0, 2048), b'\xff' * 2048))
        for opt in (['touch_after_probe=6'], ['val_at=5', 'val=45']):
            r = E.run('homed=none', 'ee_in=' + b, *opt)
            self.assertIn(r['state'], ('FAILED', 'CANCELLED'), str(opt)); self.assertEqual(r['HMI'], r['HMI0'], str(opt) + ': keine verworfenen Werte im Display')


class Cancel(unittest.TestCase):
    def test_OP10_many_touches_at_the_same_moment_are_one_cancel_and_write_nothing(self):
        r = E.run('homed=none', 'touch_after_homeaxis=2', 'touch_burst=7')
        self.assertEqual((r['state'], r['reason']), ('CANCELLED', 'CANCEL_AFTER_STEP')); self.assertEqual(r['EEBYTES_CHANGED_VS_START'], '0'); self.assertEqual(r['STALE'], '0'); self.assertNotEqual(r['HMIPAGE'], '22')

    def test_OP11_a_touch_while_no_run_is_active_never_cancels_the_next_run(self):
        r = E.run('homed=none', 'touch_idle=1')
        self.assertEqual((r['state'], r['reason']), ('SUCCESS', 'VERIFIED'))

    def test_OP12_a_late_touch_after_the_end_of_a_run_never_cancels_the_next_run_and_an_identical_second_save_is_skipped(self):
        for opt in ([], ['touch_late=1']):
            r = E.run('homed=none', 'rerun=1', 'limit_s=900', *opt)
            self.assertEqual(r['RESULT1'], 'state=SUCCESS reason=VERIFIED'); self.assertEqual((r['state'], r['reason']), ('SUCCESS', 'VERIFIED'), str(opt))
            self.assertEqual(r['raw']['skipped'], 1, str(opt) + ': bitgleiche Wiederholung wird nicht erneut gespeichert'); self.assertEqual(r['EEBYTES_CHANGED_VS_START'], '877', str(opt) + ': nur der erste Lauf hat geschrieben')

    def test_OP13_a_cancelled_run_can_be_restarted_immediately_and_succeeds(self):
        r = E.run('homed=none', 'touch_after_homeaxis=2', 'rerun=1', 'limit_s=900')
        self.assertEqual(r['RESULT1'], 'state=CANCELLED reason=CANCEL_AFTER_STEP'); self.assertEqual((r['state'], r['reason']), ('SUCCESS', 'VERIFIED'))

    def test_OP14_cancel_is_possible_in_every_state_before_the_save_and_never_afterwards(self):
        """Standard (wie 282-284): nach der AKTIVIERUNG bleibt das validierte, aber nie gespeicherte Mesh aktiv; Display und RAM sind immer KONSISTENT, das EEPROM bleibt unberuehrt."""
        old, new, total = E.refs()
        for st in ('HEATING', 'VALIDATING', 'ENABLING', 'SAVE_PENDING'):
            r = E.run('homed=none', f'touch_at={st}')
            self.assertEqual(r['state'], 'CANCELLED', st); self.assertEqual(r['EEBYTES_CHANGED_VS_START'], '0', st + ': KEIN EEPROM-Schreiben'); self.assertEqual(r['EEMAINEQ'], '1', st)
            self.assertNotEqual(r['HMIPAGE'], '22', st); self.assertTrue(close(hmi(r), cells_from_mesh(r['mesh'])), st + ': Display == RAM-Mesh')
            h0 = [int(v) for v in r['HMI0'].split()]
            if st in ('HEATING', 'VALIDATING'):
                self.assertTrue(close(hmi(r), h0), st + ': noch nicht aktiviert -> das ALTE Mesh')
            else:
                self.assertFalse(close(hmi(r), h0), st + ': aktiviertes Mesh bleibt (Standard); mit SV04_CLAUDE_ROLLBACK_AFTER_ENABLE=1 kommt das alte zurueck (OP14b)')
        r = E.run('homed=none', 'touch_at=VERIFYING')
        self.assertEqual((r['state'], r['reason']), ('SUCCESS', 'VERIFIED'), 'in VERIFYING ist schon gespeichert: ein Abbruch waere unehrlich; der Block wurde verifiziert')

    def test_OP14b_with_the_rollback_option_every_cancel_before_the_save_restores_the_old_mesh_display_and_leveling(self):
        old, new, total = E.refs()
        d = ['SV04_CLAUDE_ROLLBACK_AFTER_ENABLE=1']
        for st in ('VALIDATING', 'ENABLING', 'SAVE_PENDING'):
            for lev0 in (0, 1):
                r = E.run('homed=none', f'touch_at={st}', f'lev0={lev0}', name='rbopt', defines=d)
                self.assertEqual(r['state'], 'CANCELLED', st); self.assertEqual(r['EEBYTES_CHANGED_VS_START'], '0', st)
                h0 = [int(v) for v in r['HMI0'].split()]
                self.assertTrue(close(hmi(r), h0), f'{st} lev0={lev0}: Display zeigt das ALTE Mesh'); self.assertTrue(close(cells_from_mesh(r['mesh']), h0), f'{st} lev0={lev0}: RAM-Mesh alt')
                self.assertEqual(int(r['RAM'].split('leveling=')[1].split()[0]), lev0, f'{st}: Nivellierung wie VOR dem Lauf')
        r = E.run('homed=none', 'touch_at=VERIFYING', name='rbopt', defines=d)
        self.assertEqual((r['state'], r['reason']), ('SUCCESS', 'VERIFIED'), 'ab dem save() gibt es keinen Rollback und keinen Abbruch')

    def test_OP17_the_rollback_option_never_halts_the_printer_with_the_real_v2_v4_functions(self):
        """Die Option stellt nach der Aktivierung das alte Mesh her, waehrend die Nivellierung AN ist. Mit den ECHTEN V2/V4-Funktionen (aktiv + ungueltig = kill) darf das auch bei LEEREM altem Mesh nie ein Notstopp sein."""
        import test_bedlevel_a60 as BL
        d = ['SIM_REAL_BEDLEVEL=v2v4', 'SV04_CLAUDE_ROLLBACK_AFTER_ENABLE=1']; E.refs()
        for label, base in (('leer', ['ee_in=' + BL.blank(), 'lev0=0']), ('gueltig lev0=0', ['lev0=0']), ('gueltig lev0=1', ['lev0=1'])):
            for st in ('VALIDATING', 'ENABLING', 'SAVE_PENDING'):
                r = E.run('homed=none', f'touch_at={st}', *base, name='rb_real', defines=d)
                self.assertEqual(r['state'], 'CANCELLED', f'{label} {st}: KEIN Notstopp'); self.assertEqual(r['EEBYTES_CHANGED_VS_START'], '0', f'{label} {st}')
                self.assertTrue(close(hmi(r), [int(v) for v in r['HMI0'].split()]), f'{label} {st}: Display zeigt das alte Mesh')
                self.assertEqual(int(r['RAM'].split('leveling=')[1].split()[0]), 1 if 'lev0=1' in label else 0, f'{label} {st}: Nivellierung wie vorher')

    def test_OP15_touch_and_gcode_cancel_together_and_twice_are_one_cancel(self):
        r = E.run('homed=none', 'touch_after_homeaxis=2', 'cancel_after_homeaxis=2', 'touch_burst=3')
        self.assertEqual(r['state'], 'CANCELLED'); self.assertEqual(r['STALE'], '0'); self.assertEqual(r['EEBYTES_CHANGED_VS_START'], '0')

    def test_OP16_cancel_with_a_queued_g28_a_stale_g28_and_a_timeout_stays_consistent(self):
        r = E.run('homed=none', 'queue_stall=1', 'queue_release_s=80', 'touch_after_homeaxis=1', 'tail_s=100', 'limit_s=300')
        self.assertIn(r['state'], ('FAILED', 'CANCELLED')); self.assertEqual(r['HOMEAXIS'], 'count=0', 'das verspaetete G28 bewegt nichts'); self.assertEqual(r['EEBYTES_CHANGED_VS_START'], '0')


class Protection(unittest.TestCase):
    def test_OP20_the_journal_protection_is_announced_at_the_start_and_again_when_the_save_is_released(self):
        r = E.run('homed=none')
        n = len(re.findall(r'Schutz beim Speichern = Undo-Journal', r['SERIAL']))
        self.assertGreaterEqual(n, 2, 'Start UND Speicherfreigabe'); self.assertNotIn('KEINER', r['SERIAL'])

    def test_OP21_without_room_for_the_journal_the_unprotected_save_is_announced_loudly_counted_and_never_called_safe(self):
        r = E.run('homed=none', 's3_end=1', name='noroom_u', defines=NOROOM_UNPROTECTED)
        self.assertEqual((r['state'], r['reason']), ('SUCCESS', 'VERIFIED'))
        self.assertGreaterEqual(len(re.findall(r'KEINER, WARNUNG: kein Platz fuer das Undo-Journal', r['SERIAL'])), 2, 'beim Start UND bei der Speicherfreigabe')
        self.assertIn('ein Stromausfall waehrend des Speicherns kann den Einstellungsblock zerstoeren', r['SERIAL']); self.assertIn('journal_platz=NEIN', r['SERIAL']); self.assertIn('ohne_journal_gespeichert_seit_start=1', r['SERIAL'])
        self.assertNotIn('Schutz beim Speichern = Undo-Journal', r['SERIAL'])

    def test_OP22_requiring_the_journal_refuses_the_start_and_says_why(self):
        r = E.run('homed=none', name='noroom_req', defines=NOROOM + ['SV04_CLAUDE_EEPROM_REQUIRE_JOURNAL=1'])
        self.assertEqual((r['state'], r['reason']), ('IDLE', 'NONE')); self.assertIn('Start verweigert, kein Platz fuer das Undo-Journal', r['SERIAL']); self.assertEqual(r['EEBYTES_CHANGED_VS_START'], '0')

    def test_OP22b_since_299_the_journal_is_required_by_default_without_any_define(self):
        r = E.run('homed=none', name='noroom_default', defines=NOROOM)
        self.assertEqual((r['state'], r['reason']), ('IDLE', 'NONE')); self.assertIn('Start verweigert, kein Platz fuer das Undo-Journal', r['SERIAL']); self.assertEqual(r['EEBYTES_CHANGED_VS_START'], '0')

    def test_OP23_an_empty_eeprom_says_that_no_protection_is_needed(self):
        E.refs(); p = E.mutated('op23.img', lambda b: b.__setitem__(slice(0, 2048), b'\xff' * 2048))
        r = E.run('homed=none', 'ee_in=' + p)
        self.assertIn('nicht noetig (EEPROM noch leer)', r['SERIAL'])


class Recovery(unittest.TestCase):
    def test_OP30_a_dead_bus_at_boot_changes_nothing_and_the_recovery_is_not_lost(self):
        old, new, total = E.refs()
        E.run('homed=none', 'ee_cut_at=850', 'ee_out=' + E.img('op30.img'))
        r1 = E.run('boot_only=1', 'ee_in=' + E.img('op30.img'), 'ee_unreadable=1', 'ee_out=' + E.img('op30b.img'))
        self.assertEqual(r1['EEBYTES_CHANGED_VS_START'], '0', 'ein toter Bus (liefert Muell) darf NICHTS schreiben')
        self.assertEqual(Path(E.img('op30b.img')).read_bytes(), Path(E.img('op30.img')).read_bytes(), 'Abbild unveraendert')
        r2 = E.run('boot_only=1', 'ee_in=' + E.img('op30b.img'), 'ee_out=' + E.img('op30c.img'))
        self.assertEqual((r2['raw']['boot_res'], r2['raw']['primary']), (2, 5), 'beim naechsten Start mit Bus wird zurueckgespielt'); self.assertEqual(E.block(E.img('op30c.img')), old)
        self.assertTrue(close(hmi(r2), cells_from_mesh(r2['mesh'])))

    def test_OP31_a_missing_journal_after_an_interrupted_save_is_reported_and_nothing_is_written(self):
        E.run('homed=none', 'ee_cut_at=850', 'ee_out=' + E.img('op31.img'))
        p = E.mutated('op31b.img', lambda b: b.__setitem__(slice(0, 2048), Path(E.img('op31.img')).read_bytes()[:E.OFF + E.LEN] + b'\xff' * (2048 - E.OFF - E.LEN)))     # Journalbereich geloescht
        b = E.run('boot_only=1', 'ee_in=' + p)
        self.assertEqual(b['raw']['boot_res'], 0, 'ohne Journal kann nichts zurueckgespielt werden'); self.assertIn(b['raw']['boot_primary'], (2, 3), 'der Hauptblock ist unterbrochen/fremd')
        self.assertIn('ABWEICHUNG', b['SERIAL']); self.assertEqual(b['EEBYTES_CHANGED_VS_START'], '0')
        r = E.run('homed=none', 'ee_in=' + p)
        self.assertEqual((r['state'], r['reason']), ('IDLE', 'NONE')); self.assertIn('Auto60 refused: PRE_EEPROM_UNAVAILABLE', r['SERIAL']); self.assertEqual(r['EEBYTES_CHANGED_VS_START'], '0')

    def test_OP32_a_write_error_at_every_one_of_the_last_twelve_changes_incl_the_header_never_gives_a_false_success(self):
        old, new, total = E.refs()
        for k in range(total - 12, total):
            r = E.run('homed=none', f'ee_fail_at={k}', 'ee_out=' + E.img(f'op32_{k}.img')); b = E.block(E.img(f'op32_{k}.img'))
            self.assertEqual(r['raw']['primary'], 5, k)
            if r['state'] == 'SUCCESS':
                self.assertEqual(b, new, f'fail@{k}: SUCCESS nur mit bitgleichem NEUEM Block')
            elif r['reason'] == 'EEPROM_RECOVERY_REQUIRED':                          # 299 (293/294): nur das Beenden des Journals scheiterte
                self.assertEqual(b, new, f'fail@{k}: gueltiger NEUER Block'); self.assertNotEqual(r['HMIPAGE'], '22', k)
                rb = E.run('boot_only=1', 'ee_in=' + E.img(f'op32_{k}.img'), 'ee_out=' + E.img(f'op32_{k}.rb'))
                self.assertEqual(rb['raw']['boot_primary'], 5, k); self.assertIn(E.block(E.img(f'op32_{k}.rb')), (old, new), f'fail@{k}: nach dem Neustart alt ODER neu')
            else:
                self.assertEqual(b, old, f'fail@{k}: sonst der ALTE Block'); self.assertNotEqual(r['HMIPAGE'], '22', k)

    def test_OP33_invalid_foreign_old_and_partially_written_records_are_reported_by_m1060_and_never_overwritten(self):
        E.refs()
        cases = (('crc', lambda b: b.__setitem__(E.OFF + 300, b[E.OFF + 300] ^ 1), 'primary=4'), ('v84', lambda b: b.__setitem__(slice(E.OFF, E.OFF + 4), b'V84\0'), 'primary=3'), ('foreign', lambda b: b.__setitem__(E.OFF, ord('X')), 'primary=3'),
                 ('err', lambda b: b.__setitem__(slice(E.OFF, E.OFF + 4), b'ERR\0'), 'primary=2'), ('v8r', lambda b: b.__setitem__(slice(E.OFF, E.OFF + 4), b'V8R\0'), 'primary=3'))
        for name, fn, want in cases:
            p = E.mutated(f'op33_{name}.img', fn)
            b = E.run('boot_only=1', 'ee_in=' + p)
            self.assertIn(want, b['SERIAL'], name); self.assertIn('ABWEICHUNG', b['SERIAL'], name); self.assertEqual(b['EEBYTES_CHANGED_VS_START'], '0', name + ': M1060 S2/S3 schreiben nie')
            self.assertEqual(b['S2S3_UNCHANGED'], 'lev=1 pos=1 mesh=1 zoff=1 offset=1 no_motion=1', name)
            r = E.run('homed=none', 'ee_in=' + p)
            self.assertIn('Auto60 refused: PRE_EEPROM_UNAVAILABLE', r['SERIAL'], name); self.assertEqual(r['EEBYTES_CHANGED_VS_START'], '0', name)


class StopState(unittest.TestCase):
    """C2: bltouch.cpp stop() (MarlinCore.cpp:932) schaltet ALLE Heizungen ab und setzt den Zustand gestoppt. Auto60 darf das Bett danach nicht wieder einschalten (BEFUND: restore_heater tat es)."""
    PRE = ['homed=none', 'target0=70', 'bed0=70']

    @staticmethod
    def spur(r):
        tr = r.get('TRACE', r.get('t', '')); tr = tr if isinstance(tr, str) else ' ; '.join(tr)
        return [i.strip() for i in tr.replace('|', ';').split(';') if 'bed_target' in i or 'stop()' in i]

    def test_OP40_a_bltouch_alarm_stop_is_never_followed_by_heating_the_bed_again(self):
        r = E.run(*self.PRE, 'bltouch_alarm=1'); sp = self.spur(r)
        self.assertEqual((r['state'], r['reason']), ('FAILED', 'HOME_FAILED')); self.assertIn('stop(): heaters off, state STOPPED', sp)
        self.assertEqual([x for x in sp[sp.index('stop(): heaters off, state STOPPED') + 1:]], [], 'nach stop() kein einziger Heizbefehl mehr: ' + str(sp))

    def test_OP41_a_bltouch_stow_failure_stop_is_never_followed_by_heating_the_bed_again(self):
        r = E.run(*self.PRE, 'stow_fail=1'); sp = self.spur(r)
        self.assertEqual((r['state'], r['reason']), ('FAILED', 'HOME_FAILED')); self.assertEqual(sp[sp.index('stop(): heaters off, state STOPPED') + 1:], [], str(sp))

    def test_OP42_without_stop_the_previous_bed_target_is_still_restored_after_success_and_after_a_non_stop_failure(self):
        ok = self.spur(E.run(*self.PRE)); self.assertEqual(ok[-1], 'bed_target 70', str(ok))
        fail = E.run(*self.PRE, 'x_early_t1=1'); sp = self.spur(fail)
        self.assertEqual(fail['state'], 'FAILED'); self.assertNotIn('stop(): heaters off, state STOPPED', sp); self.assertEqual(sp[-1], 'bed_target 70', 'ein Fehler OHNE stop() stellt den Sollwert weiterhin wieder her: ' + str(sp))

    def test_OP43_a_bed_that_was_off_before_stays_off_and_the_guard_never_blocks_switching_off(self):
        r = E.run('homed=none', 'bltouch_alarm=1'); sp = self.spur(r)
        self.assertEqual(r['state'], 'FAILED'); self.assertEqual(sp[-1], 'stop(): heaters off, state STOPPED' if sp[-1].startswith('stop') else sp[-1]); self.assertNotIn('bed_target 70', sp)


if __name__ == '__main__':
    unittest.main(verbosity=2)
