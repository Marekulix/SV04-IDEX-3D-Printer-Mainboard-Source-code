"""C5: Z-Homing bei unbekanntem Z, Auto60-Sperre bei unbekanntem Z, manuelle G29 im Stopp-Zustand. Tests gegen die echten (rekonstruierten) OEM-/309-Dateien. Host-Simulation, KEIN STM32-Build, KEINE Hardware."""
import hashlib
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
CLAUDE = HERE.parents[1]
sys.path.insert(0, str(HERE)); sys.path.insert(0, str(CLAUDE / '03_PATCHES'))
import apply_g29_stopped_c5 as G5  # noqa: E402
import apply_start_release_c4 as S4  # noqa: E402
import apply_zgate_c5 as ZG  # noqa: E402
import apply_zhome_cold_c5 as ZC  # noqa: E402
import apply_zhome_limit_c3 as Z3  # noqa: E402
import test_c3 as T3  # noqa: E402
import test_ee_a60 as E  # noqa: E402

B = CLAUDE / '01_BASELINE'
GATE = ['SV04_CLAUDE_AUTO60_REQUIRE_Z_KNOWN=1']
sha = lambda b: hashlib.sha256(b).hexdigest()


def cmds(r): return [c.strip() for c in r.get('CMDS', '').split(';') if c.strip()]
def refused(r): return [x.strip() for x in r.get('SERIAL', '').split('[echo:') if 'refused' in x]


class ZCold(unittest.TestCase):
    def test_C501_the_cold_start_cap_is_derived_from_the_configuration_410_instead_of_600_mm(self):
        d = Path(tempfile.mkdtemp()); (d / 't.cpp').write_text('#define Z_CLEARANCE_DEPLOY_PROBE 10\n#include "%s"\n#include <cstdio>\nint main() { std::printf("%%.1f %%.1f %%.1f %%.1f\\n", sv04c_zhome_limit(-600.0f, false, 10.0f, -1.1f, 400.0f), sv04c_zhome_limit(-600.0f, true, 10.0f, -1.1f, 400.0f), sv04c_zhome_limit(-600.0f, false, 10.0f, -1.1f), sv04c_zhome_limit(-300.0f, false, 10.0f, -1.1f, 400.0f)); }\n' % T3.POL)
        self.assertEqual(subprocess.run(['g++', '-std=c++11', str(d / 't.cpp'), '-o', str(d / 't')], capture_output=True, text=True).returncode, 0)
        self.assertEqual(subprocess.run([str(d / 't')], capture_output=True, text=True).stdout.split(), ['-410.0', '-18.9', '-600.0', '-300.0'], 'unbekanntes Z: 410; bekanntes Z: 18,9 (C3); die alte 4-Argument-Form bleibt 600; eine kuerzere OEM-Strecke bleibt')

    def test_C502_the_chain_309_to_c3_to_c5_is_pinned_idempotent_and_refuses_foreign_files(self):
        m309 = T3.reconstruct_309_motion(); m3, c3 = Z3.transform(m309); self.assertTrue(c3); m5, c5 = ZC.transform(m3); self.assertTrue(c5)
        self.assertEqual(sha(m3), ZC.PIN_MOTION_AFTER_C3); self.assertEqual(ZC.transform(m5), (m5, False)); self.assertEqual(len(m5.splitlines()), len(m3.splitlines()), 'nur der Aufruf wird erweitert, keine neue Zeile')
        for bad in (m309, m3 + b'\n', m5.replace(b'max_length(Z_AXIS));   // SV04 NEXT C5', b'x);   // SV04 NEXT C5')):
            with self.assertRaises(ValueError): ZC.transform(bad)
        self.assertIn(b'probe.offset.z, max_length(Z_AXIS));', m5)

    def test_C503_the_oem_values_behind_the_cap_are_unchanged_z_range_400_and_clearance_10(self):
        cfg = (B / 'OEM_FILES/Marlin/Configuration.h').read_text()
        for needle in ('#define Z_MIN_POS 0', '#define Z_MAX_POS 400', '#define Z_CLEARANCE_DEPLOY_PROBE   10', '#define Z_HOME_DIR -1'): self.assertIn(needle, cfg, needle)
        self.assertIn('XYZ_DEFS(float, max_length,     MAX_LENGTH);', (B / 'OEM_309/orig/module/motion.h').read_text())


class ZGate(unittest.TestCase):
    def test_C511_a_cold_start_is_refused_with_pre_z_unknown_nothing_heats_nothing_homes(self):
        r = E.run('homed=none', name='zg', defines=GATE)
        self.assertEqual((r['state'], r['reason']), ('IDLE', 'NONE')); self.assertIn('Auto60 refused: PRE_Z_UNKNOWN', r['SERIAL'])
        self.assertEqual([c for c in cmds(r) if c.startswith(('bed_target', 'homeaxis', 'probe_at_point'))], [], 'keine Heizung, keine Referenzfahrt, keine Messung')

    def test_C512_with_z_known_auto60_runs_through_and_with_only_xy_known_it_is_refused(self):
        ok = E.run('homed=all', name='zg', defines=GATE); self.assertEqual((ok['state'], ok['reason']), ('SUCCESS', 'VERIFIED'))
        xy = E.run('homed=XY', name='zg', defines=GATE); self.assertEqual(xy['state'], 'IDLE'); self.assertIn('PRE_Z_UNKNOWN', xy['SERIAL'])

    def test_C513_after_a_bltouch_failure_z_is_unknown_again_and_the_restart_needs_a_manual_homing(self):
        r = E.run('homed=all', 'bltouch_alarm=1', 'rerun=1', 'limit_s=1200', 'm999=1', name='zg', defines=GATE)
        self.assertEqual(r['RESULT1'], 'state=FAILED reason=HOME_FAILED'); self.assertIn('Auto60 refused: PRE_Z_UNKNOWN', r['SERIAL'], 'nach M999 ist Marlin frei, aber Z ist (P1) nicht mehr referenziert: erst von Hand G28')

    def test_C514_a_stopped_marlin_wins_over_z_unknown_the_more_fundamental_reason_is_named(self):
        r = E.run('homed=none', 'stopped0=1', name='zg', defines=GATE); self.assertIn('Auto60 refused: MARLIN_STOPPED', r['SERIAL'])

    def test_C515_the_default_is_the_gate_ON_and_the_old_behaviour_stays_available_by_an_explicit_macro(self):
        inc = (CLAUDE / '02_SOURCE/Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc').read_text()
        self.assertIn('#define SV04_CLAUDE_AUTO60_REQUIRE_Z_KNOWN 1', inc); r = E.run('homed=none'); self.assertEqual((r['state'], r['reason']), ('SUCCESS', 'VERIFIED'), 'Standardsimulation (Gate AUS) behaelt die bisherige Aussage')

    def test_C516_the_gate_patch_applies_to_the_c4_state_reproduces_the_shipped_sources_and_refuses_foreign_ones(self):
        core = (B / 'STAND_C4/sv04_claude_auto60_core.h').read_bytes(); inc = (B / 'STAND_C4/sv04_claude_auto60_marlin.inc').read_bytes()
        self.assertEqual((sha(core), sha(inc)), (ZG.PIN['core'], ZG.PIN['inc']))
        c, i, ch = ZG.transform(core, inc); self.assertTrue(ch); self.assertEqual(ZG.transform(c, i), (c, i, False))
        S = CLAUDE / '02_SOURCE/Marlin/src'; self.assertEqual(c, (S / 'feature/sv04_claude_auto60/sv04_claude_auto60_core.h').read_bytes())
        a317 = (S / 'lcd/e3v2/creality/sv04_claude_auto60_marlin.inc').read_bytes()           # C6: ChatGPTs 317-Adapter; er muss die Z-Sperren-Zeilen dieses Patches enthalten, ist aber nicht byte-gleich
        self.assertIn(ZG.INC_EDITS[0][1].encode(), a317, 'der 317-Adapter enthaelt die C5-Z-Sperre unveraendert'); self.assertNotEqual(i, a317)
        with self.assertRaises(ValueError): ZG.transform(core + b'\n', inc)
        with self.assertRaises(ValueError): ZG.transform(c, inc)


class ManualG29(unittest.TestCase):
    def test_C521_a_manual_g29_is_refused_in_the_stopped_state_without_any_measurement_or_state_change(self):
        r = E.run('homed=all', 'manual_g29=1', 'stopped0=1')
        self.assertIn('G29 refused', r['SERIAL']); self.assertEqual(len([c for c in cmds(r) if c.startswith('probe_at_point')]), 0); self.assertEqual(r['EEBYTES_CHANGED_VS_START'], '0')

    def test_C522_without_the_stop_the_manual_g29_still_measures_all_16_points_like_the_oem(self):
        r = E.run('homed=all', 'manual_g29=1'); self.assertEqual(len([c for c in cmds(r) if c.startswith('probe_at_point')]), 16); self.assertNotIn('G29 refused', r['SERIAL'])

    def test_C523_g28_is_deliberately_not_blocked_it_stays_the_recovery_path_for_display_users(self):
        g28 = (B / 'OEM_309/orig/gcode/calibrate/G28.cpp').read_text(); self.assertNotIn('IsStopped', g28)
        self.assertEqual(G5.TARGET.name, 'G29.cpp', 'der Patch hat genau G29.cpp als Ziel, G28 wird nicht angefasst')
        disp = (B / 'OEM_FILES/Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp').read_text(); self.assertNotIn('M999', disp, 'im Display-Code gibt es keinen M999-Weg: Wiederherstellung nur ueber G28 oder Aus-/Einschalten')

    def test_C524_the_g29_patch_is_pinned_to_the_309_file_reconstructed_from_oem_plus_combined_308_idempotent_and_refuses_foreign_files(self):
        d = Path(tempfile.mkdtemp()); (d / 'Marlin/src/gcode/bedlevel/abl').mkdir(parents=True); shutil.copy(B / 'OEM_309/orig/gcode/bedlevel/abl/G29.cpp', d / 'Marlin/src/gcode/bedlevel/abl/G29.cpp')
        txt = (B / 'OEM_309/combined_308.patch').read_text(encoding='utf-8'); s0 = txt.index('diff --git a/Marlin/src/gcode/bedlevel/abl/G29.cpp'); s1 = txt.index('diff --git ', s0 + 10); (d / 'one.patch').write_text(txt[s0:s1], encoding='utf-8')
        self.assertEqual(subprocess.run(['patch', '-p1', '--no-backup-if-mismatch', '-d', str(d), '-i', str(d / 'one.patch')], capture_output=True, text=True).returncode, 0)
        g = (d / 'Marlin/src/gcode/bedlevel/abl/G29.cpp').read_bytes(); self.assertEqual(sha(g), G5.PIN_G29_309)
        n, ch = G5.transform(g); self.assertTrue(ch); self.assertEqual(G5.transform(n), (n, False)); self.assertEqual(len(n.splitlines()) - len(g.splitlines()), 8)
        for bad in (g + b'\n', (B / 'OEM_309/orig/gcode/bedlevel/abl/G29.cpp').read_bytes()):
            with self.assertRaises(ValueError): G5.transform(bad)
        self.assertLess(n.index(b'IsStopped()'), n.index(b'SV04Claude_G29CancelRequested'), 'die Pruefung steht VOR jedem Haken und jeder Zustandsaenderung')


class Chain(unittest.TestCase):
    def test_C531_the_whole_patch_chain_is_applied_twice_the_second_pass_changes_nothing_and_every_step_succeeds(self):
        """Auftrag: wiederholtes Anwenden muss wirkungslos sein. FUND dieser Runde: nach C5 scheiterte die 2. Anwendung von C3 und C4 (Idempotenzpruefung verlangte den exakten Text, C5 aendert ihn)."""
        w = Path(tempfile.mkdtemp()) / 'oem'
        for rel in ('Marlin/src/module', 'Marlin/src/feature/sv04_claude_auto60', 'Marlin/src/lcd/e3v2/creality', 'Marlin/src/gcode/bedlevel/abl'): (w / rel).mkdir(parents=True)
        shutil.copy(B / 'OEM_FILES/Marlin/src/module/tool_change.cpp', w / 'Marlin/src/module/tool_change.cpp'); (w / 'Marlin/src/module/motion.cpp').write_bytes(T3.reconstruct_309_motion())
        shutil.copy(B / 'STAND_309/sv04_claude_auto60_core.h', w / 'Marlin/src/feature/sv04_claude_auto60/sv04_claude_auto60_core.h'); shutil.copy(B / 'STAND_309/sv04_claude_auto60_marlin.inc', w / 'Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc')
        txt = (B / 'OEM_309/combined_308.patch').read_text(encoding='utf-8'); s0 = txt.index('diff --git a/Marlin/src/gcode/bedlevel/abl/G29.cpp'); s1 = txt.index('diff --git ', s0 + 10)
        shutil.copy(B / 'OEM_309/orig/gcode/bedlevel/abl/G29.cpp', w / 'Marlin/src/gcode/bedlevel/abl/G29.cpp'); (w / 'one.patch').write_text(txt[s0:s1], encoding='utf-8')
        self.assertEqual(subprocess.run(['patch', '-p1', '--no-backup-if-mismatch', '-d', str(w), '-i', str(w / 'one.patch')], capture_output=True, text=True).returncode, 0)
        order = ('apply_dxc_no_trust_c3.py', 'apply_zhome_limit_c3.py', 'apply_zhome_cold_c5.py', 'apply_start_release_c4.py', 'apply_zgate_c5.py', 'apply_g29_stopped_c5.py')
        files = [p for p in sorted(w.rglob('*')) if p.is_file() and p.name != 'one.patch']
        for k in (1, 2):
            for sname in order:
                r = subprocess.run([sys.executable, '-B', str(CLAUDE / '03_PATCHES' / sname), str(w)], capture_output=True, text=True); self.assertEqual(r.returncode, 0, f'Durchlauf {k}: {sname}: {r.stdout[-200:]}{r.stderr[-300:]}')
            if k == 1: after1 = {p.name: sha(p.read_bytes()) for p in files}
        self.assertEqual({p.name: sha(p.read_bytes()) for p in files}, after1, 'die zweite Anwendung der GANZEN Kette aendert keine Datei')
        self.assertIn(b'R_PRE_Z_UNKNOWN', (w / 'Marlin/src/feature/sv04_claude_auto60/sv04_claude_auto60_core.h').read_bytes())


if __name__ == '__main__':
    unittest.main(verbosity=2)
