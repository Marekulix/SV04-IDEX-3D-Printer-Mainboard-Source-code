"""Punkt 2 (G28 Homing) + Punkt 1 (IDEX/BLTouch): Invariantenpruefung ueber die GESAMTE Matrix gegen die ECHTE G28.cpp (OEM + P1-277-Patch).
Modus 0-3 x Startwerkzeug T0/T1 x Drucken x Achsenauswahl/Ausgangszustand x 7 Fehlerfaelle (T1/T0-Endschalter frueh, T1 scheitert im 2. Aufruf, BLTouch stow/deploy/alarm) x 1 oder 2 Aufrufe = 1792 Faelle.
Jede Verletzung ist ein Testfehler (Exitcode != 0). Negativkontrolle: derselbe Satz muss am alten 276er-G28 Verletzungen finden. Host-Simulation; KEIN STM32, KEINE Hardware."""
import collections
import itertools
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import test_g28_a60 as G  # noqa: E402

FAULTS = {'none': [], 'x_t1_early': ['x_early_t1=1'], 'x_t0_early': ['x_early_t0=1'], 't1_on_call2': ['x_t1_on_call=2'], 'stow_fail': ['stow_fail=1'], 'deploy_fail': ['deploy_fail=1'], 'alarm': ['bltouch_alarm=1']}
PAIRS = (('', 'none'), ('XYZ', 'none'), ('X', 'none'), ('Z', 'all'), ('', 'all'), ('XY', 'XY'), ('Y', 'none'), ('X', 'all'))


def sweep(which):
    viol = collections.defaultdict(list); n = 0; exits = 0
    for mode, tool, printing, (p, homed), (fname, fa), rep in itertools.product((0, 1, 2, 3), (0, 1), (0, 1), PAIRS, FAULTS.items(), (1, 2)):
        args = [f'p={p}', f'homed={homed}', f'mode={mode}', f'tool={tool}', f'printing={printing}', f'repeat={rep}'] + fa; tag = ' '.join(args); n += 1
        try:
            r = G.run(which, *args)
        except AssertionError:
            exits += 1; viol['X Prozessende (kill oder Exit != 0)'].append(tag); continue
        h = int(r['axes']['homed']); tr = int(r['axes']['trusted']); res = r['res']; t = r['t']
        if tr & ~h: viol['A trusted nicht Teilmenge von homed'].append(tag)
        # Erwartungen haengen am injizierten FEHLER, an der Spur und an den Achsenflags (nicht am Ergebnisobjekt von 277; der 276er-G28 hat keines)
        n_t1 = t.count('homeaxis X T1')                                           # Modus 0/1: ein T1-Durchgang je G28; Modus 2/3: zwei (zweiter Durchgang fuer die Duplikation)
        t1_fails_last = (fname == 'x_t1_early' and n_t1 >= 1) or (fname == 't1_on_call2' and n_t1 >= 2 and ((mode in (0, 1) and rep == 2) or (mode in (2, 3) and rep == 1)))
        last_t1 = max((i for i, c in enumerate(t) if c == 'homeaxis X T1'), default=-1); after = t[last_t1 + 1:] if last_t1 >= 0 else []
        if t1_fails_last:
            if h & 1: viol['B X als referenziert markiert trotz T1-Fehler im letzten Aufruf'].append(tag)
            if 'homeaxis X T0' in after: viol['B2 T0-X-Homing nach T1-Fehler im letzten Aufruf'].append(tag)
            if any(c.startswith(('homeaxis Y', 'homeaxis Z')) for c in after): viol['B3 Y/Z-Homing nach T1-Fehler im letzten Aufruf'].append(tag)
            if fname == 'x_t1_early' and homed == 'none' and rep == 1 and h & 0b101: viol['B4 T1 scheitert im ersten Durchgang, aber X oder Z als referenziert markiert (Y darf es sein: im Duplikationsmodus fuehrt auch G28 Y den T1-X-Durchgang aus)'].append(tag)
        if fname == 'x_t0_early' and p in ('', 'XYZ') and ('homeaxis Y T0' in t or 'homeaxis Z T0' in t) and h & 4: viol['E T0-Fehler, aber Y/Z gehomt und Z als referenziert markiert'].append(tag)
        if fname in ('stow_fail', 'deploy_fail', 'alarm') and 'homeaxis Z T0' in t and h & 4: viol['C BLTouch-Fehler, aber Z als referenziert markiert'].append(tag)
        if res:
            if res.get('ok') == '1' and p in ('', 'XYZ') and not (h == 7 and tr == 7): viol['D ok=1 aber nicht alles referenziert'].append(tag)
            if res.get('ok') == '1' and int(r['tool']['active']) != tool and mode in (0, 1) and p in ('', 'XYZ'): viol['H ok=1 aber Werkzeug nicht wiederhergestellt'].append(tag)
            if int(res.get('seq', 0)) != rep: viol['F Ergebnisfolge != Anzahl der Aufrufe'].append(tag)
    return n, viol


class Matrix(unittest.TestCase):
    def test_M01_the_real_g28_with_the_277_patch_violates_no_invariant_in_any_of_the_1792_combinations(self):
        n, viol = sweep('277')
        self.assertEqual(n, 1792)
        self.assertEqual({k: v[:2] for k, v in viol.items()}, {}, 'Verletzungen (Klasse: Beispiele)')

    def test_M02_negative_control_the_same_invariants_find_violations_in_the_old_276_g28(self):
        n, viol = sweep('276')
        self.assertEqual(n, 1792)
        self.assertTrue(any(k[0] in 'BC' for k in viol), 'die Pruefung ist wirksam: sie findet die bekannten 276-Fehler (Z/X-Vertrauen nach T0/T1/BLTouch-Fehlern)')
        self.assertGreater(sum(len(v) for v in viol.values()), 50)

    def test_M03_a_refused_g28_z_alone_moves_nothing_and_leaves_the_state_untouched_even_with_a_bltouch_fault(self):
        for fault in ([], ['stow_fail=1'], ['deploy_fail=1'], ['bltouch_alarm=1']):
            r = G.run('277', 'p=Z', 'homed=all', 'mode=0', 'tool=0', *fault)
            self.assertEqual([c for c in r['t'] if c.startswith(('homeaxis', 'do_blocking')) or (c.startswith('tool_change') and 'move=1' in c)], [], str(fault)); self.assertEqual(r['axes']['homed'], '7'); self.assertEqual(r['res'].get('ok'), '0')


if __name__ == '__main__':
    unittest.main(verbosity=2)
