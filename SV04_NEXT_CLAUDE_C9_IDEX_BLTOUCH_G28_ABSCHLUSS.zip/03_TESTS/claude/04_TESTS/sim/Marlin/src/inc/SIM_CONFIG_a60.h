#pragma once
// SIMULATIONSKONFIGURATION (Host). Jede Zeile ist an die ECHTE Marlin-Konfiguration des SV04 gebunden (Fundstelle in Kommentar).
// Quellen: Configuration.h (sha256 c9a5bffe..), Configuration_adv.h (CI-Diagnose 20-diagnose.zip, Repo-Stand 840143cd).
#define BLTOUCH                         // Configuration.h:1095
#define AUTO_BED_LEVELING_BILINEAR      // Configuration.h:1544
#define GRID_MAX_POINTS_X 4             // Configuration.h:1611
#define GRID_MAX_POINTS_Y GRID_MAX_POINTS_X   // :1612
#define RTS_AVAILABLE                   // Configuration.h:2787
#define DUAL_X_CARRIAGE                 // Configuration_adv.h:752 (DEFAULT_DUAL_X_CARRIAGE_MODE DXC_AUTO_PARK_MODE :766)
#define EXTRUDERS 2                     // Configuration.h:199  -> HAS_MULTI_HOTEND
#define Z_PROBE_END_SCRIPT "G28 XY"     // Configuration.h:1722
#define RESTORE_LEVELING_AFTER_G28      // Configuration.h:1553
#define EEPROM_SETTINGS                 // Configuration.h:1830
#define Z_CLEARANCE_DEPLOY_PROBE 10     // Configuration.h:1255
#define Z_CLEARANCE_BETWEEN_PROBES 5    // Configuration.h:1256
// NICHT aktiv (Configuration*.h auskommentiert): PROBE_MANUALLY (:1072), DEBUG_LEVELING_FEATURE (:1570), PREHEAT_BEFORE_LEVELING (:1559),
//   ABL_BILINEAR_SUBDIVISION (:1627), G29_RETRY_AND_RECOVER (Configuration_adv.h:1975), MULTIPLE_PROBING (:1238), EXTRA_PROBING (:1239)
// Abgeleitete Marlin-Bedingungen (Conditionals_post.h), fuer diese Konfiguration:
#define HAS_ABL_NOT_UBL 1
#define ABL_USES_GRID 1
#define ABL_PLANAR 0
#define HAS_BED_PROBE 1
#define HAS_LEVELING 1
#define HAS_MULTI_HOTEND 1
#define IS_CARTESIAN 1
#define GRID_MAX_POINTS (GRID_MAX_POINTS_X * GRID_MAX_POINTS_Y)
#define HAS_STATUS_MESSAGE 0
#define CAN_SET_LEVELING_AFTER_G28 1
// Achskonfiguration (Marlin Conditionals_*, abgeleitet): 3 lineare Achsen (X,Y,Z), 2 Extruder (Configuration.h:199)
#define LINEAR_AXES 3
#define HAS_EXTRUDERS 1
#define LOGICAL_AXES 4
#define DISTINCT_E 2
#define DISTINCT_AXES 5
#define E_STEPPERS 2
#define GANG_ITEM_E(N) N
#define CODE_ITEM_E(N) N
#define LIST_ITEM_E(N) , N
#define XY 2
#define G29_TYPE void                   // G29_RETRY_AND_RECOVER aus (Configuration_adv.h:1975) -> void; G29_RETURN(x) ist dann ein blosses 'return'
#define HAS_X_AXIS 1
#define HAS_Y_AXIS 1
#define HAS_Z_AXIS 1
#define HAS_MESH 1                      // ANY(AUTO_BED_LEVELING_BILINEAR, ...)
#define EXTRAPOLATE_BEYOND_GRID         // Configuration.h:1621
#define SEGMENT_LEVELED_MOVES           // Configuration.h:1589

// ---- Erweiterung fuer die ECHTE G28.cpp (Marlin 277) -----------------------------------------------------------------------------------------------
#define Z_SAFE_HOMING                   // Configuration.h:1745
#define Z_SAFE_HOMING_X_POINT 151       // Configuration.h:1748 (X_CENTER; Simulationswert, nur Zielkoordinate)
#define Z_SAFE_HOMING_Y_POINT 151       // Configuration.h:1749 (Y_CENTER)
#define USE_PROBE_FOR_Z_HOMING          // Configuration.h:1041 -> HOMING_Z_WITH_PROBE
#define HOMING_Z_WITH_PROBE 1
#define Z_HOMING_HEIGHT 10              // Configuration.h:1360
#define X_BED_SIZE 302                  // Configuration.h:1377
#define Y_BED_SIZE 302                  // :1378
#define X_MIN_POS -62                   // :1381
#define Y_MIN_POS 0                     // :1382
#define X_MAX_POS X_BED_SIZE            // :1384
#define Y_MAX_POS Y_BED_SIZE            // :1385
#define X_HOME_DIR -1                   // :1367
#define Y_HOME_DIR -1                   // :1368
#define Z_HOME_DIR -1                   // :1369
#define X2_MIN_POS 0                    // Configuration_adv.h:756
#define X2_MAX_POS 362                  // Configuration_adv.h:757
#define X2_HOME_DIR 1                   // Configuration_adv.h:758
#define X2_HOME_POS X2_MAX_POS          // Configuration_adv.h:759
#define X_HOME_POS X_MIN_POS            // abgeleitet (Marlin Conditionals: Home-Richtung -1)
#define HOTEND_OFFSET_X_T1 188.0f       // Configuration.h:358 { 0.0, 188.00 } -> x_home_pos(1) == 188
#define DEFAULT_DUAL_X_CARRIAGE_MODE DXC_AUTO_PARK_MODE   // Configuration_adv.h:766
#define HAS_HOME_OFFSET 1
#define HAS_ENDSTOPS 1
#define HAS_Z_AXIS 1
// NICHT aktiv: QUICK_HOME, HOME_Y_BEFORE_X, CODEPENDENT_XY_HOMING, IMPROVE_HOMING_RELIABILITY, SENSORLESS_HOMING, HOME_AFTER_DEACTIVATE, EXTENSIBLE_UI, DELTA, PARKING_EXTRUDER
#define HAS_DUPLICATION_MODE 1           // Conditionals_adv.h:535 (bei DUAL_X_CARRIAGE): G28 ruft set_duplication_enabled(false) am Anfang auf
