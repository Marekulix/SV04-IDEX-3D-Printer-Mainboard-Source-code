#pragma once
// ======================= Simulations-Stubs fuer die ECHTE G28.cpp (kein OEM-Code; Verhalten in g28_world.cpp) =======================
#include <stdint.h>
#include <stdarg.h>
#define LINEAR_AXIS_LIST(V...) LIST_N(LINEAR_AXES, V)
#define LINEAR_AXIS_GANG(V...) GANG_N(LINEAR_AXES, V)
#define LINEAR_AXIS_CODE(V...) CODE_N(LINEAR_AXES, V)
#define LOOP_LINEAR_AXES(VAR) for (int VAR = 0; VAR < LINEAR_AXES; VAR++)
typedef uint8_t linear_axis_bits_t;
void sim_serial_eol();
#include "p1_decls.h"          // WOERTLICH aus dem gepatchten motion.h extrahiert (Marker SV04_NEXT_P1_274/_277)
#define linear_bits 7
#define _BV(b) (1u << (b))
extern linear_axis_bits_t axis_homed, axis_trusted;
inline void set_axis_unhomed(const AxisEnum a)   { axis_homed = (linear_axis_bits_t)(axis_homed & ~(1u << a)); }
inline void set_axis_untrusted(const AxisEnum a) { axis_trusted = (linear_axis_bits_t)(axis_trusted & ~(1u << a)); }
inline void set_axis_homed(const AxisEnum a)     { axis_homed = (linear_axis_bits_t)(axis_homed | (1u << a)); }
inline void set_axis_trusted(const AxisEnum a)   { axis_trusted = (linear_axis_bits_t)(axis_trusted | (1u << a)); }
inline bool axis_was_homed(const AxisEnum a)     { return (axis_homed >> a) & 1; }
inline bool axis_is_trusted(const AxisEnum a)    { return (axis_trusted >> a) & 1; }
linear_axis_bits_t axes_should_home(linear_axis_bits_t axis_bits = linear_bits);   // real: motion.cpp:1318 (HOME_AFTER_DEACTIVATE aus -> axis_was_homed)
bool homing_needed_error(linear_axis_bits_t axis_bits = linear_bits);
void homeaxis(const AxisEnum axis);                                                // Stub: emuliert die fruehen returns und die Reihenfolge set_axis_is_at_home -> probe.stow -> Abschlussflags
void set_axis_is_at_home(const AxisEnum axis);
extern bool extruder_duplication_enabled;
extern float inactive_extruder_x, current_position_x0_axis, current_position_x1_axis;
extern float sim_hotend_offset_x1; extern bool active_extruder_parked;
extern char save_dual_x_carriage_mode;
float x_home_pos(const uint8_t extruder);
bool idex_is_duplicating();
void idex_set_parked(const bool park = true);
void set_duplication_enabled(const bool dupe, const int8_t tool_index = -1);
void tool_change(const uint8_t tmp_extruder, bool no_move = false);
extern xyze_pos_t destination;
extern xyz_pos_t home_offset;
void do_blocking_move_to_xy(const xy_pos_t &raw, const float &fr_mm_s = 0.0f);
bool position_is_reachable(const xy_pos_t &pos);
void sync_plan_position();
void reset_stepper_timeout();
void remember_feedrate_scaling_off();
void restore_feedrate_and_scaling();
#define SET_SOFT_ENDSTOP_LOOSE(V) do{ (void)(V); }while(0)
struct SimEndstops { void enable(const bool) {} void not_homing() {} void validate_homing_move() {} };
extern SimEndstops endstops;
struct SimBltouch { void init(); };
extern SimBltouch bltouch;
#define LCD_MESSAGEPGM(M) sim_lcd_message(#M)
void sim_lcd_message(const char *m);
void RTS_MoveAxisHoming();
#define MSG_ZPROBE_OUT ZPROBE_OUT
#define MSG_HOME_FIRST "Home %sfirst"
#define STR_ZPROBE_OUT_SER "Z probe out"
#define SERIAL_ERROR_MSG(...) (sim_serial("Error:", __VA_ARGS__), sim_serial_eol())
#define SERIAL_ECHO_MSG(...) (sim_serial("echo:", __VA_ARGS__), sim_serial_eol())
#define STR_Z_MOVE_COMP "Z_move_comp"
#define SERIAL_ECHOLNPGM_SIM(...) sim_serial(__VA_ARGS__)
#define DEBUGGING(x) false
#define DEBUG_SECTION(a, b, c) do{}while(0)
#define DEBUG_ECHOLNPGM(...) do{}while(0)
#define DEBUG_POS(a, b) do{}while(0)
#define log_machine_info() do{}while(0)
#define TOOL_X_HOME_DIR(e) ((e) ? X2_HOME_DIR : X_HOME_DIR)
#define MARLIN_DEV_MODE_OFF
#define UNUSED(x) (void)(x)
#define set_and_report_grblstate(x) do{}while(0)
#define HAS_CURRENT_HOME_SIM 0
