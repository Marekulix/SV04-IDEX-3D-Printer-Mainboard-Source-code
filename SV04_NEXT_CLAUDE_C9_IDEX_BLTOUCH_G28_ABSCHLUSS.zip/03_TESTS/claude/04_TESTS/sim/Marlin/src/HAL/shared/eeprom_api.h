// SIMULATIONS-Kopie der Deklarationen aus Marlin/src/HAL/shared/eeprom_api.h (identische Signaturen; die Definitionen liegen in chain_world.cpp und bilden HAL/STM32F1/eeprom_bl24cxx.cpp nach).
// Der Adapter bindet "../../../HAL/shared/eeprom_api.h" ein; im Host-Test liegt diese Datei an derselben relativen Stelle.
#pragma once
#include <stddef.h>
#include <stdint.h>

void crc16(uint16_t *crc, const void *data, uint16_t cnt);     // libs/crc16.h (CRC-16/XMODEM, fortlaufend)

class PersistentStore {
public:
  static size_t capacity();
  static bool access_start();
  static bool access_finish();
  // Return 'true' on write/read error (HAL-Konvention)
  static bool write_data(int &pos, const uint8_t *value, size_t size, uint16_t *crc);
  static bool read_data(int &pos, uint8_t *value, size_t size, uint16_t *crc, const bool writing = true);
  static inline bool write_data(const int pos, const uint8_t *value, const size_t size = sizeof(uint8_t)) { int p = pos; uint16_t crc = 0; return write_data(p, value, size, &crc); }
  static inline bool read_data(const int pos, uint8_t *value, const size_t size = 1) { int p = pos; uint16_t crc = 0; return read_data(p, value, size, &crc); }
};
extern PersistentStore persistentStore;
