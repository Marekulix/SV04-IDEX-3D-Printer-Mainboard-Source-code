#!/usr/bin/env python3
"""Extrahiert WOERTLICH Codebloecke aus den ECHTEN OEM-Dateien in Simulationsquellen. Jeder Block ist durch Anker (erste/letzte Zeile) und SHA-256 gesichert;
weicht die OEM-Datei ab, bricht das Skript ab (kein stilles Nachbauen). Aufruf: extract_real_a60.py --lcd LCD_RTS.cpp --abl abl.cpp --out gen/"""
import argparse
import hashlib
import json
import sys
from pathlib import Path


def block(lines, start, end, first, last):
    """1-basiert, inklusive. Prueft Anker."""
    seg = lines[start - 1:end]
    if first not in seg[0] or last not in seg[-1]:
        raise SystemExit(f'Anker passen nicht bei Zeilen {start}-{end}: {seg[0]!r} ... {seg[-1]!r}')
    return seg


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--lcd', required=True)
    ap.add_argument('--abl', required=True)
    ap.add_argument('--out', required=True)
    a = ap.parse_args(argv)
    lcd = Path(a.lcd).read_text(encoding='utf-8').split('\n')
    abl = Path(a.abl).read_text(encoding='utf-8').split('\n')
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    man = {'LCD_RTS.cpp_sha256': hashlib.sha256(Path(a.lcd).read_bytes()).hexdigest(), 'abl.cpp_sha256': hashlib.sha256(Path(a.abl).read_bytes()).hexdigest(), 'blocks': []}

    def rec(name, src, s, e, seg):
        txt = '\n'.join(seg) + '\n'
        man['blocks'].append({'name': name, 'source': src, 'lines': [s, e], 'sha256': hashlib.sha256(txt.encode()).hexdigest()})
        return txt

    ctor = rec('RTSSHOW_ctor', 'LCD_RTS.cpp', 103, 108, block(lcd, 103, 108, 'RTSSHOW::RTSSHOW()', '}'))
    snd = rec('RTS_SndData_overloads', 'LCD_RTS.cpp', 496, 656, block(lcd, 496, 656, 'void RTSSHOW::RTS_SndData(void)', '}'))
    page = rec('RTS_AutoBedLevelPage', 'LCD_RTS.cpp', 2872, 2879, block(lcd, 2872, 2879, 'void RTS_AutoBedLevelPage()', '}'))
    boot = rec('oem_boot_mesh_loop', 'LCD_RTS.cpp', 311, 337, block(lcd, 311, 337, 'bool zig = false;', '}'))
    (out / 'sim_rts_real_a60.cpp').write_text(
        '// GENERIERT von extract_real_a60.py - WOERTLICHER Auszug aus dem ECHTEN LCD_RTS.cpp (Zeilen siehe EXTRACTION_MANIFEST_a60.json). NICHT VON HAND AENDERN.\n'
        '#include "sim_lcd_env_a60.h"\n#include "Marlin/src/lcd/e3v2/creality/LCD_RTS.h"\n#include "Marlin/src/feature/bedlevel/abl/abl.h"\n#include <string.h>\n'
        'char waitway = 0;                       // LCD_RTS.cpp:54  char waitway = 0;\nRTSSHOW rtscheck;                      // LCD_RTS.cpp:78\n'
        + ctor + snd + page + '\n'
        '// Boot-Sendeschleife des OEM (Zeilen 311-336) als aufrufbare Funktion; RTS_SndData ruft hier die Instanz rtscheck auf (im Original steht der Aufruf in RTSSHOW::RTS_Init()).\n'
        '#define RTS_SndData rtscheck.RTS_SndData\n'
        'void sim_oem_boot_mesh_send() {\n' + boot + '}\n#undef RTS_SndData\n', encoding='utf-8')
    # abl.cpp: bilinear_z_offset samt ABL_BG_*-Makros
    s = next(i for i, l in enumerate(abl, 1) if l.startswith('#if ENABLED(ABL_BILINEAR_SUBDIVISION)') and 'ABL_BG_SPACING' in abl[i])
    f = next(i for i, l in enumerate(abl, 1) if l.startswith('float bilinear_z_offset'))
    d, e, started = 0, None, False
    for i in range(f, len(abl) + 1):
        for ch in abl[i - 1]:
            if ch == '{':
                d += 1; started = True
            elif ch == '}':
                d -= 1
        if started and d == 0:
            e = i
            break
    z = rec('bilinear_z_offset', 'abl.cpp', s, e, abl[s - 1:e])
    (out / 'sim_abl_real_a60.cpp').write_text(
        '// GENERIERT von extract_real_a60.py - WOERTLICHER Auszug aus dem ECHTEN abl.cpp (bilinear_z_offset). NICHT VON HAND AENDERN.\n'
        '#include "Marlin/src/inc/MarlinConfig.h"\n#include "Marlin/src/feature/bedlevel/abl/abl.h"\n' + z, encoding='utf-8')
    (out / 'EXTRACTION_MANIFEST_a60.json').write_text(json.dumps(man, indent=1))
    print(json.dumps([(b['name'], b['lines'], b['sha256'][:12]) for b in man['blocks']]))
    return 0


if __name__ == '__main__':
    sys.exit(main())
