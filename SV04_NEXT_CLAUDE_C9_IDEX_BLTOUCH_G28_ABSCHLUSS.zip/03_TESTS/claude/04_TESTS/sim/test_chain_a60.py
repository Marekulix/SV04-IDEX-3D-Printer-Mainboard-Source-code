"""KETTENTESTS (Host-Simulation): ECHTER Auto60-Adapter + ECHTER Koordinator + ECHTE gepatchte G29.cpp + ECHTE RTS_SndData (woertlich extrahiert) + Stubs/Modelle fuer
Thermik, Queue, G28-Backend und EEPROM (Modell nach der echten settings.cpp-Semantik). Jede Methode ist eine benannte Sequenz. Das ist SIMULATION: kein STM32, keine Hardware."""
import re
import struct
import subprocess
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(ROOT / '03_PATCHES'))
import build_sim_a60 as B  # noqa: E402
import chain_tree as T  # noqa: E402
import apply_claude_parallel as P  # noqa: E402

OEM = ROOT / '01_BASELINE' / 'OEM_FILES' / 'Marlin' / 'src'
SRC = ROOT / '02_SOURCE'
f32 = lambda x: struct.unpack('f', struct.pack('f', x))[0]
SCRIPT = [f32(f32(f32(0.012) * (k - 8)) + f32(f32(0.0031) * k)) for k in range(16)]
CELL = {}                                                      # Punktnummer -> (ix, iy)
for _k in range(16):
    _iy, _pos = divmod(_k, 4)
    CELL[_k] = ((_pos if _iy & 1 else 3 - _pos), _iy)
OLD = [f32(0.31 - 0.05 * x + 0.02 * y) for y in range(4) for x in range(4)]     # y-major wie die Ausgabe
BACKEND = ['SV04_CLAUDE_HOME_BACKEND_EXTERNAL=1', 'SIM_A60']          # Test-Double des G28/IDEX-Backends (NUR Host-Test; das Produktions-Backend wird in test_integ_a60.py geprueft)
_state = {}


def tree():
    """Der INTEGRIERTE Stand (276 + Stufe 1 + Claude-Overlay), erzeugt aus den echten Patchskripten (chain_tree.py)."""
    if 'tree' not in _state:
        import tempfile
        _state['tree'], _state['work'] = T.shared()['integ'], Path(tempfile.mkdtemp(prefix='a60_work_'))
    return _state['tree']


def claude_out():
    """Nur die vom Claude-Overlay geaenderten/neuen Dateien (fuer die Patch-Tests)."""
    return T.shared()['claude_out']


def exe(name, defines=BACKEND, g29=None):
    key = (name, tuple(defines), g29)
    if key not in _state:
        _state[key] = B.build(tree(), name, defines, _state.setdefault('work', None) or _state['work'], g29)
    return _state[key]


def run(name, *args, defines=BACKEND, g29=None):
    r = B.scenario(exe(name, defines, g29), *args)
    r['EEd'] = {k: int(v) for k, v in (kv.split('=') for kv in r['EE'].split() if '=' in kv and kv.split('=')[1].lstrip('-').isdigit())}
    r['HMIl'] = [int(v) for v in r['HMI'].split()]
    r['HMI0l'] = [int(v) for v in r['HMI0'].split()]
    r['MESHl'] = [float(v) for v in r['MESH'].split()]
    r['EEMESHl'] = [float(v) for v in r['EEMESH'].split()]
    r['state'] = r['RESULT'].split()[0].split('=')[1]
    r['reason'] = r['RESULT'].split()[1].split('=')[1]
    r['probe'] = int(re.search(r'probe=(\d+)', r['COUNTS']).group(1))
    return r


def expected_new_mesh():
    m = [0.0] * 16
    for k, (ix, iy) in CELL.items():
        m[iy * 4 + ix] = SCRIPT[k]
    return m


def near(a, b, tol=6e-5):
    return len(a) == len(b) and all(abs(x - y) <= tol for x, y in zip(a, b))


class Chain(unittest.TestCase):
    def untouched_eeprom(self, r, why=''):
        self.assertEqual(r['EEd']['saves'], 0, why)
        self.assertEqual(r['EEd']['bytes'], 0, why)
        self.assertEqual(r['EEd']['header_ok'], 1, why)
        self.assertEqual(r['EEd']['mesh_changed'], 0, why)
        self.assertEqual(r['EEd']['zoff_changed'], 0, why)
        self.assertEqual(r['EEd']['loads'], 0, why + ' (kein Ladepfad ohne Speichern)')

    def old_state_restored(self, r, why=''):
        self.assertTrue(near(r['MESHl'], OLD), why + ': RAM-Mesh == altes Mesh')
        self.assertEqual(r['HMIl'], r['HMI0l'], why + ': Display == Boot-Bild (altes Mesh)')

    # ------------------------------------------------------------------ Erfolgspfad
    def test_S01_happy_path_full_chain_success_after_independent_readback(self):
        r = run('chain')
        self.assertEqual((r['state'], r['reason'], r['RESULT'].split()[2]), ('SUCCESS', 'VERIFIED', 'sid=1'))
        self.assertEqual(r['LOG'].split(), ['IDLE>HEATING(START_OK)', 'HEATING>STABILIZING(BAND_REACHED)', 'STABILIZING>HOMING_PENDING(HEAT_STABLE)', 'HOMING_PENDING>PROBING(PROBE_STARTED)', 'PROBING>VALIDATING(PROBE_STARTED)',
                                         'VALIDATING>ENABLING(VALIDATED)', 'ENABLING>SAVE_PENDING(VALIDATED)', 'SAVE_PENDING>VERIFYING(NONE)', 'VERIFYING>SUCCESS(VERIFIED)'])
        self.assertEqual(r['probe'], 16)
        self.assertTrue(near(r['MESHl'], expected_new_mesh()), 'RAM-Mesh: 16 Werte in der tatsaechlichen Zellenreihenfolge')
        self.assertTrue(near(r['EEMESHl'], expected_new_mesh()), 'EEPROM-Abbild (Modell) == validiertes Mesh')
        self.assertEqual((r['EEd']['saves'], r['EEd']['header_ok'], r['EEd']['mesh_changed']), (1, 1, 1))
        self.assertEqual(r['EEd']['validates'], 1, '283: nur Marlins EIGENE validate(); die unabhaengige Pruefung ist eine Rohlesung')
        self.assertEqual(r['EEd']['loads'], 0, '283: KEIN settings.load() im Pruefpfad (es schaltet bei passendem Bilinear-Raster die Nivellierung AUS, settings.cpp:1676)')
        self.assertEqual(r['RAM'].split()[:2], ['zoff_unchanged=1', 'leveling=1'])
        self.assertEqual(r['EEZOFF'], r['RAMZOFF'])
        self.assertEqual(r['HMIl'], [int(f32(z * 1000)) for z in SCRIPT], 'Display: 16 Zellen == (int)(z*1000) in Messreihenfolge')
        self.assertEqual((r['HMIPAGE'], r['HMIBAD'], r['HMIMULTI']), ('22', '0', '2'), 'zwei Seitenrahmen: Messseite (38) und Ergebnisseite (22); Zellrahmen sind Ein-Wort-Rahmen')
        self.assertEqual(r['RAM'].split()[2], 'bed_target=0', 'Bett-Soll wiederhergestellt')
        self.assertEqual(r['BUSY'], 'seen=1 after=0', 'DWIN-Touch gesperrt waehrend des Laufs, danach frei')
        self.assertNotIn('G28', [c.strip() for c in r['CMDS'].split(';')], 'kein eigenes G28 durch Auto60 (nur die passive Schnittstelle)')

    def test_S01b_oem_g29_enables_leveling_itself_so_auto60_switches_it_off_until_validated(self):
        """BEFUND G29.cpp:883 (planner.leveling_active = !dryrun || reenable): die OEM-G29 schaltet die Nivellierung am Ende SELBST ein. Auto60 schaltet sie wieder aus und aktiviert erst nach der Validierung."""
        c = [x.strip() for x in run('chain')['CMDS'].split(';') if x.strip()]
        g29 = c.index('exec G29'); last_probe = max(i for i, x in enumerate(c) if x.startswith('probe_at_point'))
        end_script = c.index('gcode:G28 XY')
        self.assertGreater(end_script, last_probe, 'DAS OEM-ENDSKRIPT "G28 XY" LAEUFT INNERHALB DER G29 (Configuration.h:1722): ChatGPTs G28/IDEX-Zweig ist mitbetroffen (siehe INTEGRATION_CONFLICTS)')
        off_after = [i for i, x in enumerate(c) if x == 'set_bed_leveling_enabled(false)' and i > end_script][0]
        on_after = [i for i, x in enumerate(c) if x == 'set_bed_leveling_enabled(true)' and i > end_script][0]
        self.assertLess(off_after, on_after, 'erst AUS (unvalidiert), dann Aktivierung in ENABLING')
        self.assertLess(on_after, c.index('settings.save'), 'M500-Aequivalent erst nach der Aktivierung')
        self.assertLess(c.index('settings.save'), c.index('eeprom_validate'), 'Pruefung erst nach dem Speichern')
        self.assertNotIn('settings.load', c, '283: KEIN settings.load() im Ablauf (es schaltet die Nivellierung AUS, settings.cpp:1676)')

    def test_S01c_m420_that_does_nothing_is_detected_because_leveling_was_switched_off_before(self):
        r = run('chain', 'm420_noop=1')
        self.assertEqual((r['state'], r['reason']), ('FAILED', 'M420_NOT_ACTIVE'))
        self.untouched_eeprom(r); self.assertTrue(near(r['MESHl'], OLD), 'ungepruefte Werte verworfen'); self.assertEqual(r['HMIl'], r['HMI0l'])      # Hinweis: der Testschalter blockiert JEDES Einschalten, also auch die Wiederherstellung: der Nivellierungszustand wird hier nicht geprueft

    def test_S02_chain_never_changes_zoffset_even_with_nonstandard_value(self):
        r = run('chain', 'zoff=-0.73')
        self.assertEqual(r['state'], 'SUCCESS')
        self.assertEqual(r['RAM'].split()[0], 'zoff_unchanged=1')
        self.assertEqual(r['EEZOFF'], '-0.7300')
        self.assertEqual(r['EEd']['zoff_changed'], 0, 'EEPROM-Z-Offset == Z-Offset vor dem Lauf')

    # ------------------------------------------------------------------ Start- und Konfliktsperren (A03)
    def refused(self, args, reason, defines=BACKEND, name='chain'):
        r = run(name, *args, defines=defines)
        self.assertEqual((r['state'], r['reason']), ('IDLE', 'NONE'))
        self.assertIn('Auto60 refused: ' + reason, r['SERIAL'])
        self.untouched_eeprom(r)
        self.assertEqual(r['probe'], 0)
        self.assertNotIn('bed_target', r['CMDS'])
        self.assertEqual(r['BUSY'], 'seen=0 after=0')

    def test_S03_refused_while_printing(self): self.refused(['printing=1'], 'PRE_PRINTING')
    def test_S04_refused_while_paused(self): self.refused(['paused=1'], 'PRE_PAUSED')
    def test_S05_refused_with_wrong_extruder(self): self.refused(['ext1=1'], 'PRE_WRONG_EXTRUDER')
    def test_S06_refused_in_duplication_mode(self): self.refused(['dupl=1'], 'PRE_IDEX_MODE')
    def test_S07_refused_when_dwin_is_busy(self): self.refused(['waitway=1'], 'PRE_DWIN_BUSY')
    def test_S08_fail_closed_without_g28_idex_backend(self): self.refused([], 'PRE_HOME_BACKEND_MISSING', defines=['SIM_A60', 'SV04_CLAUDE_HOME_BACKEND_AVAILABLE=0'], name='nobackend')

    def test_S09_second_start_is_refused_and_run_continues(self):
        r = run('chain', 'double_start=5')
        self.assertIn('Auto60 refused: PRE_ALREADY_RUNNING', r['SERIAL'])
        self.assertEqual((r['state'], r['RESULT'].split()[2]), ('SUCCESS', 'sid=1'))

    def test_S10_boot_state_is_idle_and_touches_no_eeprom(self):
        r = run('chain', 'nostart=1', 'limit_s=5')
        self.assertEqual((r['state'], r['reason'], r['RESULT'].split()[2]), ('IDLE', 'NONE', 'sid=0'))
        self.untouched_eeprom(r, 'A19: kein EEPROM-Zugriff beim Start')
        self.assertEqual(r['LOG'], '')

    # ------------------------------------------------------------------ G28/IDEX-Schnittstelle (A05)
    def home_fail(self, mode, reason, **kw):
        r = run('chain', 'home=' + mode, *kw.get('extra', []))
        self.assertEqual((r['state'], r['reason']), ('FAILED', reason), mode)
        self.assertEqual(r['probe'], 0, 'kein G29 ohne bestaetigtes Homing')
        self.untouched_eeprom(r, mode)
        self.assertEqual(r['RAM'].split()[2], 'bed_target=0')
        return r

    def test_S11_home_failure(self): self.home_fail('fail', 'HOME_FAILED')
    def test_S12_home_without_idex_gate_evidence(self): self.home_fail('nogate', 'HOME_NO_EVIDENCE')
    def test_S13_home_leaves_t1_active(self): self.home_fail('wrongext', 'HOME_NO_EVIDENCE')
    def test_S14_home_leaves_z_untrusted(self): self.home_fail('noz', 'HOME_NO_EVIDENCE')
    def test_S15_home_changes_zoffset(self): self.home_fail('zoffs', 'HOME_ZOFFSET_CHANGED')
    def test_S16_home_request_rejected_by_backend(self): self.home_fail('reject', 'HOME_REJECTED')
    def test_S17_home_never_answers_times_out(self): self.home_fail('never', 'HOME_TIMEOUT', extra=['limit_s=500'])

    # ------------------------------------------------------------------ G29-Fehler (A06-A09)
    def probe_fail(self, args, reason, why, lev0=1):
        r = run('chain', *args, 'lev0=%d' % lev0)
        self.assertEqual((r['state'], r['reason']), ('FAILED', reason), why)
        self.untouched_eeprom(r, why)
        self.old_state_restored(r, why)
        self.assertNotIn('ENABLING', r['LOG'], why + ': Auto60 aktiviert nie ein unvalidiertes Mesh')
        self.assertEqual(r['COUNTS'].split()[2], 'settings_save=0', why)
        self.assertEqual(r['RAM'].split()[:2], ['zoff_unchanged=1', 'leveling=%d' % lev0], why + ': Nivellierung wie VOR dem Lauf, Z-Offset unveraendert')
        self.assertEqual(r['HMIPAGE'], '28', why + ': KEIN "fertig" (Seite 22), sondern die Fehlerseite (HMI-Annahme)')
        self.assertEqual(r['HMIMULTI'], '2', why)
        return r

    def test_S18_bltouch_failure_at_first_point(self): self.probe_fail(['nan_at=0'], 'PROBE_FAILED', 'k=0')
    def test_S19_bltouch_failure_in_the_middle(self): self.probe_fail(['nan_at=9'], 'PROBE_FAILED', 'k=9')
    def test_S20_bltouch_failure_at_last_point(self): self.probe_fail(['nan_at=15'], 'PROBE_FAILED', 'k=15')
    def test_S21_value_over_the_g29_limit_is_rejected_and_rolled_back(self): self.probe_fail(['val_at=5', 'val=45'], 'PROBE_FAILED', '45 mm')
    def test_S22_value_accepted_by_g29_but_over_the_auto60_limit_is_rolled_back(self):
        r = self.probe_fail(['val_at=5', 'val=12'], 'MESH_RANGE', '12 mm')
        self.assertEqual(r['probe'], 16)

    def test_S23_temperature_excursion_during_the_measurement(self):
        r = self.probe_fail(['kick_after_probe=6', 'kick=40'], 'TEMP_EXCURSION', 'Temperaturabfall')
        self.assertEqual(r['probe'], 6, 'C4: die fruehere GRENZE (die laufende OEM-G29 misst nach einem Auto60-Fehler alle 16 Punkte weiter) ist geschlossen: die G29 endet am naechsten Messpunkt, die Folgen bleiben gesperrt')

    def test_S24_fault_at_every_one_of_the_16_points(self):
        for k in range(16):
            self.probe_fail(['nan_at=%d' % k], 'PROBE_FAILED', 'k=%d' % k)

    # ------------------------------------------------------------------ Heizbett (A04)
    def test_S24b_failures_restore_leveling_off_state_too_when_it_was_off_before(self):
        for args, reason in ((['nan_at=0'], 'PROBE_FAILED'), (['nan_at=9'], 'PROBE_FAILED'), (['val_at=5', 'val=12'], 'MESH_RANGE'), (['val_at=5', 'val=45'], 'PROBE_FAILED'), (['kick_after_probe=6', 'kick=40'], 'TEMP_EXCURSION'), (['m420_noop=1'], 'M420_NOT_ACTIVE')):
            r = run('chain', *args, 'lev0=0')
            self.assertEqual((r['state'], r['reason']), ('FAILED', reason), str(args)); self.assertEqual(r['RAM'].split()[1], 'leveling=0', str(args) + ': war aus, bleibt aus')
            self.untouched_eeprom(r, str(args)); self.assertTrue(near(r['MESHl'], OLD), str(args))

    def test_S25_bed_sensor_fault(self):
        r = run('chain', 'heat=nan')
        self.assertEqual((r['state'], r['reason']), ('FAILED', 'HEAT_SENSOR_FAULT'))
        self.untouched_eeprom(r); self.assertEqual(r['probe'], 0); self.assertEqual(r['RAM'].split()[2], 'bed_target=0')

    def test_S26_bed_never_reaches_60_times_out(self):
        r = run('chain', 'heat=stuck', 'limit_s=1000')
        self.assertEqual((r['state'], r['reason']), ('FAILED', 'HEAT_TIMEOUT'))
        self.assertEqual(r['probe'], 0); self.untouched_eeprom(r)

    def test_S27_bed_target_changed_externally(self):
        r = run('chain', 'retarget_s=10')
        self.assertEqual((r['state'], r['reason']), ('FAILED', 'HEAT_TARGET_CHANGED'))
        self.assertEqual(r['probe'], 0)

    # ------------------------------------------------------------------ Fremde G29 / Abbruch (A08)
    def test_S28_foreign_g29_during_the_run(self):
        r = run('chain', 'home_ms=60000', 'foreign_g29_at_s=50', 'limit_s=200')
        self.assertEqual((r['state'], r['reason']), ('FAILED', 'FOREIGN_G29'))
        self.untouched_eeprom(r)

    def test_S29_cancel_while_heating(self):
        r = run('chain', 'cancel_at=HEATING')
        self.assertEqual((r['state'], r['reason']), ('CANCELLED', 'USER_CANCEL')); self.assertEqual(r['probe'], 0); self.untouched_eeprom(r); self.assertEqual(r['RAM'].split()[2], 'bed_target=0')

    def test_S30_cancel_while_stabilizing(self):
        r = run('chain', 'cancel_at=STABILIZING')
        self.assertEqual((r['state'], r['reason']), ('CANCELLED', 'USER_CANCEL')); self.assertEqual(r['probe'], 0); self.untouched_eeprom(r)

    def test_S31_cancel_while_homing_is_pending(self):
        r = run('chain', 'cancel_at=HOMING_PENDING')
        self.assertEqual((r['state'], r['reason']), ('CANCELLED', 'CANCEL_AFTER_STEP')); self.assertEqual(r['probe'], 0); self.untouched_eeprom(r)

    def test_S32_cancel_during_g29_invalidates_the_session_and_discards_the_new_mesh(self):
        r = run('chain', 'cancel_at=PROBING')
        self.assertEqual((r['state'], r['reason']), ('CANCELLED', 'CANCEL_AFTER_STEP'))
        self.untouched_eeprom(r); self.old_state_restored(r); self.assertEqual(r['HMIPAGE'], '28')
        self.assertEqual(r['probe'], 0, '290 (289 G29-CANCEL V1 + Abbruchtest): die G29 bricht VOR der ersten Messung ab; die frueher OFFENE Grenze "laufende G29 wird nicht gestoppt" ist fuer den Abbruch ZWISCHEN den Messungen behoben')
        self.assertEqual(r['COUNTS'].split()[1], 'm420=1', 'das einzige set_bed_leveling_enabled(true) ist das OEM-Wiederherstellen des Zustands VOR der G29 (abl.reenable, G29-CANCEL V1), KEIN Auto60-Aktivieren')

    # ------------------------------------------------------------------ EEPROM (A10-A12)
    def test_S33_save_always_fails_the_journal_restores_the_old_block_and_failure_is_reported(self):
        r = run('chain', 'save=1')
        self.assertEqual((r['state'], r['reason']), ('FAILED', 'VERIFY_INVALID'), '283: der alte Block wird zurueckgespielt, deshalb KEIN "Wiederherstellung noetig" (in 282 war das EEPROM verloren)')
        self.assertEqual((r['EEd']['saves'], r['EEd']['header_ok']), (2, 1), '283: nach dem Zurueckspielen ist der Kopf wieder gueltig')
        self.assertEqual(r['EEMAINEQ'], '1', 'der Einstellungsblock ist BYTEGLEICH zum Stand vor dem Lauf')
        self.assertEqual(r['RAM'].split()[:2], ['zoff_unchanged=1', 'leveling=1']); self.assertTrue(near(r['MESHl'], expected_new_mesh()), 'validiertes Mesh bleibt im RAM aktiv')
        self.assertEqual(r['HMIPAGE'], '28')

    def test_S34_write_aborts_after_err_header_the_journal_restores_the_old_block(self):
        r = run('chain', 'save=2')
        self.assertEqual((r['state'], r['reason']), ('FAILED', 'VERIFY_INVALID')); self.assertEqual(r['EEd']['header_ok'], 1); self.assertEqual(r['EEMAINEQ'], '1', '283: Journal stellt den alten Block bytegleich wieder her')

    def test_S35_silent_corruption_is_caught_by_the_readback_and_ram_keeps_the_validated_mesh(self):
        r = run('chain', 'save=3')
        self.assertEqual((r['state'], r['reason']), ('FAILED', 'VERIFY_MISMATCH'))
        self.assertTrue(near(r['MESHl'], expected_new_mesh()), 'RAM bleibt das validierte Mesh (der Adapter stellt nach dem Vergleich wieder her)')
        self.assertFalse(near(r['EEMESHl'], expected_new_mesh()), 'EEPROM-Abbild weicht ab')
        self.assertEqual(r['HMIPAGE'], '28')

    def test_S36_save_fails_once_then_recovers(self):
        r = run('chain', 'save=4')
        self.assertEqual((r['state'], r['reason']), ('SUCCESS', 'VERIFIED')); self.assertEqual((r['EEd']['saves'], r['EEd']['header_ok']), (2, 1))

    def test_S37_bus_failure_after_a_successful_validate_is_never_success_and_never_claims_consistency(self):
        r = run('chain', 'noreadback=1')      # 283: der Altschalter bedeutet jetzt: das EEPROM liefert nach validate() nur noch Muell (0xFF) OHNE Fehlermeldung, wie der echte Treiber bei einem Busfehler
        self.assertNotEqual(r['state'], 'SUCCESS'); self.assertEqual(r['reason'], 'EEPROM_RECOVERY_REQUIRED', 'der Hauptblock ist nicht nachweislich gueltig -> NICHT "konsistent" behaupten'); self.assertEqual(r['HMIPAGE'], '28')

    # ------------------------------------------------------------------ OEM-Erhalt und Regression (A18)
    def test_S38_manual_g29_success_is_identical_to_the_unmodified_oem_g29(self):
        a = run('chain', 'manual_g29=1', 'nostart=1')
        b = run('oem', 'manual_g29=1', 'nostart=1', g29=OEM / 'gcode/bedlevel/abl/G29.cpp')
        for k in ('MESH', 'HMI', 'HMIPAGE', 'HMIBAD', 'HMIMULTI', 'HMICELLWRITES', 'CMDS', 'COUNTS', 'RAM'):
            self.assertEqual(a[k], b[k], k)
        self.assertEqual(a['state'], 'IDLE'); self.untouched_eeprom(a)

    def test_S39_manual_g29_with_waitway_3_keeps_the_oem_page_switch(self):
        a = run('chain', 'manual_g29=1', 'nostart=1', 'waitway=3'); b = run('oem', 'manual_g29=1', 'nostart=1', 'waitway=3', g29=OEM / 'gcode/bedlevel/abl/G29.cpp')
        self.assertEqual((a['HMIPAGE'], a['HMIMULTI']), (b['HMIPAGE'], b['HMIMULTI'])); self.assertEqual(a['HMIPAGE'], '22')

    def test_S40_manual_g29_failure_oem_leaves_mixed_mesh_patched_restores_it(self):
        a = run('chain', 'manual_g29=1', 'nostart=1', 'nan_at=9'); b = run('oem', 'manual_g29=1', 'nostart=1', 'nan_at=9', g29=OEM / 'gcode/bedlevel/abl/G29.cpp')
        self.assertFalse(near(b['MESHl'], OLD), 'OEM: gemischtes Mesh bleibt zurueck'); self.assertTrue(near(a['MESHl'], OLD), 'Patch: alter Stand')
        self.assertEqual(a['HMIl'], a['HMI0l']); self.untouched_eeprom(a)

    def test_S41_manual_g29_never_touches_the_coordinator_or_the_eeprom(self):
        for extra in ([], ['nan_at=5'], ['val_at=3', 'val=45']):
            r = run('chain', 'manual_g29=1', 'nostart=1', *extra)
            self.assertEqual((r['state'], r['reason']), ('IDLE', 'NONE')); self.untouched_eeprom(r)

    # ------------------------------------------------------------------ Konfigurationsmatrix (A17/A18, Host)
    def test_S42_configuration_matrix_compiles_and_behaves(self):
        base = ['SV04_CLAUDE_HOME_BACKEND_AVAILABLE=1', 'SIM_A60']
        r = run('norollback', 'manual_g29=1', 'nostart=1', 'nan_at=9', defines=base + ['SV04_CLAUDE_G29_ROLLBACK=0'])
        self.assertFalse(near(r['MESHl'], OLD), 'ROLLBACK=0: OEM-Verhalten (gemischtes Mesh)')
        r = run('noresend', 'manual_g29=1', 'nostart=1', 'nan_at=9', defines=base + ['SV04_CLAUDE_G29_RESEND=0'])
        self.assertTrue(near(r['MESHl'], OLD)); self.assertNotEqual(r['HMIl'], r['HMI0l'], 'RESEND=0: Daten ja, Display nicht')
        r = run('nolive', 'manual_g29=1', 'nostart=1', defines=base + ['SV04_CLAUDE_G29_GUARD_LIVE=0'])
        self.assertEqual(r['HMIl'], [int(f32(z * 1000)) for z in SCRIPT])
        r = run('noauto', 'limit_s=5', defines=['SIM_A60', 'SV04_CLAUDE_AUTO60_ENABLE=0'])
        self.assertEqual(r['state'], 'IDLE'); self.assertIn('Auto60 not compiled', r['SERIAL']); self.untouched_eeprom(r)
        r = run('noauto', 'manual_g29=1', 'nostart=1', 'nan_at=9', defines=['SIM_A60', 'SV04_CLAUDE_AUTO60_ENABLE=0'])
        self.assertTrue(near(r['MESHl'], OLD), 'ohne Auto60 bleibt der RAM-Rollback der G29 nutzbar')

    def test_S43_all_chain_failures_keep_eeprom_untouched_before_save(self):
        n = 0
        for args in (['printing=1'], ['home=fail'], ['home=nogate'], ['nan_at=3'], ['val_at=2', 'val=12'], ['val_at=2', 'val=45'], ['heat=nan'], ['retarget_s=8'], ['cancel_at=HEATING'], ['cancel_at=PROBING'], ['kick_after_probe=3', 'kick=30']):
            r = run('chain', *args)
            self.untouched_eeprom(r, str(args)); self.assertEqual(r['COUNTS'].split()[2], 'settings_save=0'); n += 1
        self.assertEqual(n, 11)


class PatchFiles(unittest.TestCase):
    """Das Patchwerkzeug: nur Einfuegungen, gesperrte Dateien unberuehrt, reproduzierbar, fail-closed."""
    def setUp(self):
        self.oem = {'lcd': OEM / 'lcd/e3v2/creality/LCD_RTS.cpp', 'g29': OEM / 'gcode/bedlevel/abl/G29.cpp', 'gcode': OEM / 'gcode/gcode.cpp'}

    def test_P01_only_pure_insertions_and_oem_files_are_recoverable_byte_for_byte(self):
        import difflib
        tr = claude_out()
        for key, rel in (('lcd', P.LCD_REL), ('g29', P.G29_REL), ('gcode', P.GCODE_REL)):
            o = self.oem[key].read_bytes().decode().splitlines(True); n = (tr / rel).read_bytes().decode().splitlines(True)
            ops = [x for x in difflib.SequenceMatcher(None, o, n, autojunk=False).get_opcodes() if x[0] != 'equal']
            self.assertTrue(ops and all(x[0] == 'insert' for x in ops), key + ': nur Einfuegungen')
            kept = [l for i, l in enumerate(n) if not any(x[3] <= i < x[4] for x in ops)]
            self.assertEqual(kept, o, key + ': OEM-Datei byte-genau rekonstruierbar')

    def test_P02_locked_files_are_not_in_the_output(self):
        files = {f.relative_to(claude_out()).as_posix() for f in claude_out().rglob('*') if f.is_file()}
        for locked in ('Marlin/src/module/motion.cpp', 'Marlin/src/module/motion.h', 'Marlin/src/module/probe.cpp'):       # 277: G28.cpp erhaelt NUR den Waechter (Stufe 2); motion/probe bleiben im Overlay unberuehrt
            self.assertNotIn(locked, files)
        self.assertEqual(files, {p.as_posix() for p in (P.LCD_REL, P.G29_REL, P.GCODE_REL, P.G28_REL, *P.NEW_FILES, P.LOOP_REL)})

    def test_P03_second_application_and_old_patches_are_refused(self):
        tr = claude_out()
        for fn, rel in ((P.patch_g29, P.G29_REL), (P.patch_lcd, P.LCD_REL), (P.patch_gcode, P.GCODE_REL)):
            with self.assertRaises(P.PatchError):
                fn((tr / rel).read_bytes())
        with self.assertRaises(P.PatchError):
            P.patch_g29(self.oem['g29'].read_bytes() + b'\n// sv04next194 marker\n')

    def test_P04_in_place_and_existing_output_are_refused(self):
        import tempfile
        with self.assertRaises(P.PatchError):
            P.run(self.oem['lcd'], self.oem['g29'], self.oem['gcode'], self.oem['lcd'].parent, SRC)
        with self.assertRaises(P.PatchError):
            P.run(self.oem['lcd'], self.oem['g29'], self.oem['gcode'], claude_out(), SRC)
        d = Path(tempfile.mkdtemp())
        P.run(self.oem['lcd'], self.oem['g29'], self.oem['gcode'], d, SRC)
        P.run(self.oem['lcd'], self.oem['g29'], self.oem['gcode'], d, SRC, overwrite=True)

    def test_P05_every_anchor_is_enforced_missing_doubled_and_commented_are_rejected(self):
        g = self.oem['g29'].read_bytes()
        for name in ('G29_A2', 'G29_A3', 'G29_A4P', 'G29_A4', 'G29_A5'):
            a = getattr(P, name).encode()
            for label, mod in (('missing', g.replace(a, b'// removed\n')), ('doubled', g.replace(a, a + a)), ('commented', g.replace(a, b'/*\n' + a + b'*/\n'))):
                with self.assertRaises(P.PatchError, msg=name + ' ' + label):
                    P.patch_g29(mod)
        for fn, key, names in ((P.patch_lcd, 'lcd', ('LCD_FUNC', 'LCD_TICK', 'LCD_LOCK')), (P.patch_gcode, 'gcode', ('GC_A2',))):
            data = self.oem[key].read_bytes()
            for name in names:
                a = getattr(P, name).encode()
                with self.assertRaises(P.PatchError, msg=name):
                    fn(data.replace(a, b'// removed\n'))

    def test_P06_inserted_code_adds_no_motion_heating_or_g28_commands(self):
        tr = claude_out()
        for rel in (P.G29_REL, P.LCD_REL, P.GCODE_REL):
            o = self.oem[{P.G29_REL: 'g29', P.LCD_REL: 'lcd', P.GCODE_REL: 'gcode'}[rel]].read_text().splitlines(True)
            n = (tr / rel).read_text().splitlines(True)
            added = ''.join(re.sub(r'//.*', '', l) for l in n if l not in o)       # Kommentare ausnehmen: es zaehlt nur Code
            for bad in ('G28', 'do_blocking_move', 'prepare_internal', 'M104', 'M109', 'M140', 'M190', 'M500', 'settings.save', 'set_bed_leveling_enabled(true', 'deploy', 'tool_change', 'homeaxis'):
                self.assertNotIn(bad, added, rel.name + ': ' + bad)

    def test_P07_the_only_settings_save_and_leveling_enable_live_in_the_adapter_and_are_reachable_from_coordinator_states_only(self):
        inc = (SRC / 'Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc').read_text()
        code = '\n'.join(re.sub(r'//.*', '', l) for l in inc.splitlines())                         # nur Code, keine Kommentare
        self.assertEqual(code.count('settings.save()'), 1); self.assertEqual(code.count('set_bed_leveling_enabled(true)'), 1)
        self.assertEqual(code.count('settings.load()'), 1, '283: settings.load() nur noch einmal: das Neuladen NACH einer Startwiederherstellung; NIE in der Rueckablesung')
        i0 = code.index('static void sv04c_ee_boot()'); i1 = code.index('static bool sv04c_ee_start_ok() {')
        self.assertIn('settings.load()', code[i0:i1]); self.assertNotIn('settings.load()', code[code.index('static bool sv04c_readback('):code.index('static bool sv04c_ee_unchanged(')])
        core = (SRC / 'Marlin/src/feature/sv04_claude_auto60/sv04_claude_auto60_core.h').read_text()
        self.assertEqual(core.count('p_.save('), 1); self.assertEqual(core.count('p_.m420_s1('), 1)
        self.assertLess(core.index('void do_save()'), core.index('p_.save('))
        self.assertIn('if (!p_.m420_s1(p_.ctx, sid_))', core[core.index('void do_enable()'):core.index('void do_save()')])


if __name__ == '__main__':
    unittest.main(verbosity=2)
