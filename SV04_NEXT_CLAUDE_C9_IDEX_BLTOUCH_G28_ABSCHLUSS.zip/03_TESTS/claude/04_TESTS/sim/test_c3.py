"""C3 (AP1 + AP2 + AP3 + AP4): Tests gegen die ECHTEN OEM-Quellen (Commit 1867fcba) und den Stand der Baseline 309. Host-Tests, KEIN STM32-Build, KEINE Hardware.
 AP2  dualx_tool_change() (echte Funktion aus tool_change.cpp, extrahiert): ein Werkzeugwechsel erzeugt NIE X-Vertrauen; war X vertrauenswuerdig, ist alles bytegleich zum OEM; 6 Mutanten
 AP1  Z-Fahrstrecke: reine Richtlinie (71k Pruefungen), Glue, 8 Mutanten, Patch gegen die aus OEM-Original + combined_308.patch REKONSTRUIERTE 309-motion.cpp
 AP3  Verknuepfung mit den ECHTEN G28-Ergebnissen (1792 Faelle)"""
import hashlib
import itertools
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
CLAUDE = HERE.parents[1]
sys.path.insert(0, str(HERE)); sys.path.insert(0, str(CLAUDE / '03_PATCHES'))
import apply_dxc_no_trust_c3 as DX  # noqa: E402
import apply_zhome_limit_c3 as ZH  # noqa: E402
import test_g28_a60 as G  # noqa: E402
import test_g28_matrix_305 as M  # noqa: E402

OEM = CLAUDE / '01_BASELINE/OEM_FILES/Marlin/src'
O309 = CLAUDE / '01_BASELINE/OEM_309'
H = CLAUDE / '04_TESTS/t_harness_dxc'
POL = CLAUDE / '02_SOURCE/Marlin/src/feature/sv04_claude_auto60/sv04_claude_zhome_policy.h'
sha256 = lambda b: hashlib.sha256(b).hexdigest()


def extract(src):
    s = src.decode() if isinstance(src, bytes) else src
    i = s.index('  inline void dualx_tool_change(const uint8_t new_tool, bool &no_move) {'); j = s.index('{', i); d = 0
    for k in range(j, len(s)):
        d += (s[k] == '{') - (s[k] == '}')
        if d == 0: return s[i:k + 1]


def build_dxc(src, strict=True):
    d = Path(tempfile.mkdtemp()); shutil.copy(H / 'stub_dxc.h', d); shutil.copy(H / 'harness_dxc.cpp', d); (d / 'dxc_function.inc').write_text(extract(src))
    r = subprocess.run(['g++', '-std=c++11', '-O1', '-Wall', '-Wextra'] + (['-Werror'] if strict else ['-Wno-unused-variable', '-Wno-unused-but-set-variable']) + ['-I', str(d), str(d / 'harness_dxc.cpp'), '-o', str(d / 'h')], capture_output=True, text=True)
    if strict:
        assert r.returncode == 0, r.stderr
    return d / 'h' if r.returncode == 0 else None      # ein Mutant, der nicht einmal kompiliert, gilt als erkannt


def run_h(exe, *a):
    return subprocess.run([str(exe)] + [str(x) for x in a], capture_output=True, text=True).stdout.strip()


COMBOS = list(itertools.product((0, 1, 2, 3), (0, 1), (0, 1), (0, 1), (0, 1, 2, 3), (0, 1), (100, 362), (0, 1)))


def violations(exe_orig, exe_new):
    bad = []
    for c in COMBOS:
        o, p = run_h(exe_orig, *c), run_h(exe_new, *c)
        want = o if c[4] == 1 else o.replace('x_homed=1 x_trusted=1', 'x_homed=0 x_trusted=0')      # c[4] = x_ok: nur 1 (referenziert UND vertrauenswuerdig) bleibt wie im OEM
        if p != want: bad.append(c)
    return bad


def reconstruct_309_motion():
    d = Path(tempfile.mkdtemp()); (d / 'Marlin/src/module').mkdir(parents=True); shutil.copy(O309 / 'orig/module/motion.cpp', d / 'Marlin/src/module/motion.cpp')
    txt = (O309 / 'combined_308.patch').read_text(encoding='utf-8'); start = txt.index('diff --git a/Marlin/src/module/motion.cpp'); end = txt.index('diff --git ', start + 10)
    (d / 'one.patch').write_text(txt[start:end], encoding='utf-8')
    r = subprocess.run(['patch', '-p1', '--no-backup-if-mismatch', '-d', str(d), '-i', str(d / 'one.patch')], capture_output=True, text=True); assert r.returncode == 0, r.stdout
    return (d / 'Marlin/src/module/motion.cpp').read_bytes()


class Ap2(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = (OEM / 'module/tool_change.cpp').read_bytes(); cls.new = DX.transform(cls.raw)[0]
        cls.orig = build_dxc(cls.raw); cls.pat = build_dxc(cls.new)

    def test_C301_the_real_oem_function_creates_x_trust_without_any_homing_move(self):
        """B1 AUSGEFUEHRT (an der echten extrahierten Funktion): in jeder Kombination mit nicht vertrauenswuerdigem X markiert das OEM X als referenziert UND vertrauenswuerdig."""
        n = 0
        for c in COMBOS:
            if c[4] != 1:
                self.assertIn('x_homed=1 x_trusted=1', run_h(self.orig, *c), str(c)); n += 1
        self.assertEqual(n, 768, '3/4 der 1024 Kombinationen: X war NICHT (referenziert UND vertrauenswuerdig)')

    def test_C302_the_patched_function_never_creates_x_trust_and_is_byte_identical_when_x_was_trusted(self):
        self.assertEqual(violations(self.orig, self.pat), [])

    def test_C303_every_mutant_of_the_patch_is_caught(self):
        NEWTXT = DX.NEW
        mut = [('AM1 Entzug entfaellt', '    if (!sv04c_x_was_ok) { set_axis_unhomed(X_AXIS); set_axis_untrusted(X_AXIS); }\n', ''),
               ('AM2 Entzug immer (auch wenn X vertrauenswuerdig war)', 'if (!sv04c_x_was_ok) {', 'if (true) {'),
               ('AM3 nur "unvertrauenswuerdig" entzogen', '{ set_axis_unhomed(X_AXIS); set_axis_untrusted(X_AXIS); }', '{ set_axis_untrusted(X_AXIS); }'),
               ('AM4 nur "unreferenziert" entzogen', '{ set_axis_unhomed(X_AXIS); set_axis_untrusted(X_AXIS); }', '{ set_axis_unhomed(X_AXIS); }'),
               ('AM5 "war ok" = referenziert ODER vertrauenswuerdig', 'axis_was_homed(X_AXIS) && axis_is_trusted(X_AXIS)', 'axis_was_homed(X_AXIS) || axis_is_trusted(X_AXIS)'),
               ('AM6 "war ok" wird erst NACH set_axis_is_at_home ermittelt', None, None)]
        miss = []
        for name, a, b in mut:
            if a is None:
                nt = NEWTXT.replace('    const bool sv04c_x_was_ok = axis_was_homed(X_AXIS) && axis_is_trusted(X_AXIS);\n', '').replace('    set_axis_is_at_home(X_AXIS);\n', '    set_axis_is_at_home(X_AXIS);\n    const bool sv04c_x_was_ok = axis_was_homed(X_AXIS) && axis_is_trusted(X_AXIS);\n', 1)
            else:
                self.assertEqual(NEWTXT.count(a), 1, name); nt = NEWTXT.replace(a, b)
            src = self.raw.decode().replace(DX.OLD, nt); self.assertNotEqual(src, self.raw.decode())
            exe = build_dxc(src, strict=False)
            if exe is not None and not violations(self.orig, exe): miss.append(name)
        self.assertEqual(miss, [], 'ueberlebende Mutanten')

    def test_C304_the_patch_script_pins_the_real_file_is_idempotent_adds_exactly_7_lines_and_refuses_everything_else(self):
        self.assertEqual(DX.blob_sha1(self.raw), DX.PIN_TOOL_CHANGE); self.assertEqual(DX.transform(self.new), (self.new, False))
        self.assertEqual(len(self.new.splitlines()) - len(self.raw.splitlines()), 7)
        for bad in (self.raw + b'\n', self.raw.replace(b'active_extruder = new_tool;', b'active_extruder = new_tool ;'), b'int x;'):
            with self.assertRaises(ValueError): DX.transform(bad)
        with self.assertRaises(ValueError): DX.transform(self.new.replace(b'sv04c_x_was_ok = axis_was_homed', b'x = axis_was_homed'))
        self.assertEqual([l for l in self.new.decode().split('\n') if l not in self.raw.decode().split('\n')][0].strip()[:30], '// SV04 NEXT C3: remember whet')

    def test_C305_the_trust_flags_after_every_REAL_g28_outcome_survive_an_internal_tool_change_unchanged(self):
        """AP3: dem echten G28-Ergebnis (X-Bits) folgt ein interner Werkzeugwechsel: das Vertrauen wird nie erzeugt, nur bei bestehendem Vertrauen uebernommen."""
        n = 0
        for mode, tool, printing, (p, homed), (fname, fa), rep in itertools.product((0, 1, 2, 3), (0, 1), (0, 1), M.PAIRS, M.FAULTS.items(), (1, 2)):
            args = [f'p={p}', f'homed={homed}', f'mode={mode}', f'tool={tool}', f'printing={printing}', f'repeat={rep}'] + fa
            try: r = G.run('277', *args)
            except AssertionError: continue
            hm, tr, act = int(r['axes']['homed']) & 1, int(r['axes']['trusted']) & 1, int(r['tool']['active'])
            x_ok = 1 if (hm and tr) else (2 if hm else (3 if tr else 0))
            out = run_h(self.pat, 1 if mode in (1, 0) else 2, 1 - act, act, 1, x_ok, 1, 100, 0); n += 1
            self.assertEqual(('x_homed=1 x_trusted=1' in out), bool(hm and tr), f'{args}: {out}')
        self.assertGreater(n, 1700)


MUT_ZH = [
    ('ZM01 Z unbekannt wird trotzdem begrenzt', 'if (!in.z_known || ', 'if ('),
    ('ZM02 Toleranz fehlt', 'float bound = in.z + in.probe_offset_z + in.margin;', 'float bound = in.z + in.probe_offset_z;'),
    ('ZM03 Sondenversatz ignoriert', 'float bound = in.z + in.probe_offset_z + in.margin;', 'float bound = in.z + in.margin;'),
    ('ZM04 Mindeststrecke entfaellt', '  if (bound < in.margin) bound = in.margin;', ''),
    ('ZM05 Begrenzung kann laenger als die OEM-Strecke werden', 'const float lim = bound < full ? bound : full;', 'const float lim = bound;'),
    ('ZM06 Richtung geht verloren', 'return in.move_length < 0.0f ? -lim : lim;', 'return lim;'),
    ('ZM08 Toleranz 0 wird akzeptiert', ' || in.margin <= 0.0f', ''),
    ('ZM09 C5: Kaltstart-Grenze ohne Sondenfreiheit', 'const float cap = max_len + margin;', 'const float cap = max_len;'),
    ('ZM10 C5: Kaltstart-Grenze ohne den Verfahrweg', 'const float cap = max_len + margin;', 'const float cap = margin;'),
    ('ZM11 C5: Kaltstart-Strecke kann laenger als die OEM-Strecke werden', 'const float lim = cap < full ? cap : full;\n  return move_length < 0.0f ? -lim : lim;\n}\n\n} // namespace', 'const float lim = cap;\n  return move_length < 0.0f ? -lim : lim;\n}\n\n} // namespace'),
    ('ZM12 C5: Kaltstart-Richtung geht verloren', 'const float lim = cap < full ? cap : full;\n  return move_length < 0.0f ? -lim : lim;\n}\n\n} // namespace', 'const float lim = cap < full ? cap : full;\n  return lim;\n}\n\n} // namespace'),
    ('ZM13 C5: Toleranz 0 wird bei der Kaltstart-Grenze akzeptiert', '|| max_len <= 0.0f || margin <= 0.0f ||', '|| max_len <= 0.0f ||'),
]


# Gleichwertig unter IEEE-Semantik: bei NaN/Inf faellt `bound < full` ohnehin auf `full` zurueck. Die explizite Pruefung bleibt als Schutz, falls ein Compiler (-ffast-math) NaN-Vergleiche wegoptimiert.
EQ_ZH = [('ZE01 NaN-/Inf-Position wird nicht explizit erkannt', '!zh_finite(in.z) || ', '')]


class Ap1(unittest.TestCase):
    def build(self, text, strict=True):
        d = Path(tempfile.mkdtemp()); p = d / '02_SOURCE/Marlin/src/feature/sv04_claude_auto60'; p.mkdir(parents=True); (d / '04_TESTS/core').mkdir(parents=True)
        (p / 'sv04_claude_zhome_policy.h').write_text(text); shutil.copy(CLAUDE / '04_TESTS/core/test_zhome_policy.cpp', d / '04_TESTS/core/test_zhome_policy.cpp')
        r = subprocess.run(['g++', '-std=c++11', '-O1', '-Wall', '-Wextra'] + (['-Werror', '-pedantic'] if strict else ['-Wno-unused-variable', '-Wno-unused-but-set-variable']) + [str(d / '04_TESTS/core/test_zhome_policy.cpp'), '-o', str(d / 't')], capture_output=True, text=True)
        return r.returncode, d / 't'

    def test_C311_the_pure_z_policy_passes_its_table_and_property_tests(self):
        rc, exe = self.build(POL.read_text()); self.assertEqual(rc, 0)
        out = subprocess.run([str(exe)], capture_output=True, text=True); self.assertEqual(out.returncode, 0, out.stdout[-300:]); self.assertRegex(out.stdout, r'SUMMARY tests=\d+ pass=\d+ fail=0')

    def test_C312_every_policy_mutant_is_caught(self):
        t = POL.read_text(); miss = []
        for name, a, b in MUT_ZH:
            self.assertEqual(t.count(a), 1, name); rc, exe = self.build(t.replace(a, b), strict=False)
            self.assertEqual(rc, 0, name + ': ein Mutant muss KOMPILIEREN; ein Compilerfehler ist kein Verhaltensnachweis')
            if subprocess.run([str(exe)], capture_output=True, text=True).returncode == 0: miss.append(name)
        self.assertEqual(miss, [])

    def test_C312b_the_documented_equivalent_mutant_really_changes_no_observable_result(self):
        t = POL.read_text()
        for name, a, b in EQ_ZH:
            self.assertEqual(t.count(a), 1, name); rc, exe = self.build(t.replace(a, b)); self.assertEqual(rc, 0)
            self.assertEqual(subprocess.run([str(exe)], capture_output=True, text=True).returncode, 0, name + ': besteht alle Pruefungen (gleichwertig bei IEEE-Semantik)')

    def test_C313_the_marlin_glue_uses_the_marlin_clearance_constant_as_the_default_margin(self):
        d = Path(tempfile.mkdtemp()); (d / 't.cpp').write_text('#define Z_CLEARANCE_DEPLOY_PROBE 10\n#include "%s"\n#include <cstdio>\nint main() { std::printf("%%.2f %%.2f %%.2f\\n", sv04c_zhome_limit(-600.0f, true, 10.0f, -1.1f), sv04c_zhome_limit(-600.0f, false, 10.0f, -1.1f), sv04c_zhome_limit(-600.0f, true, 10.0f, -1.1f) * 0 + (float)SV04_CLAUDE_ZHOME_MARGIN_MM); }\n' % POL)
        self.assertEqual(subprocess.run(['g++', '-std=c++11', str(d / 't.cpp'), '-o', str(d / 't')], capture_output=True, text=True).returncode, 0)
        self.assertEqual(subprocess.run([str(d / 't')], capture_output=True, text=True).stdout.split(), ['-18.90', '-600.00', '10.00'])

    def test_C314_the_309_motion_cpp_is_reconstructed_exactly_and_the_patch_is_pinned_idempotent_and_refuses_foreign_sources(self):
        m = reconstruct_309_motion(); self.assertEqual(sha256(m), ZH.PIN_MOTION_309_SHA256, 'OEM-Original + combined_308.patch == motion.cpp der Baseline 309')
        new, ch = ZH.transform(m); self.assertTrue(ch); self.assertEqual(ZH.transform(new), (new, False)); self.assertEqual(len(new.splitlines()) - len(m.splitlines()), 5)
        for bad in (m + b'\n', (O309 / 'orig/module/motion.cpp').read_bytes(), m.replace(b'Home Fast', b'Home FAST')):
            with self.assertRaises(ValueError): ZH.transform(bad)
        with self.assertRaises(ValueError): ZH.transform(new.replace(b'sv04c_zhome_limit(move_length', b'x(move_length'))
        self.assertIn(b'if (axis == Z_AXIS) move_length = sv04c_zhome_limit(', new); self.assertIn(b'HOMING_Z_WITH_PROBE\n      // SV04 NEXT C3 (AP1)', new)

    def test_C315_the_oem_path_the_patch_shortens_is_still_what_it_is_in_the_real_file(self):
        m = (O309 / 'orig/module/motion.cpp').read_text(); self.assertIn('const float move_length = 1.5f * max_length(TERN(DELTA, Z_AXIS, axis)) * axis_home_dir;', m)
        self.assertIn('do_homing_move(axis, move_length, 0.0, !use_probe_bump);', m)


if __name__ == '__main__':
    unittest.main(verbosity=2)
