// KETTENSIMULATION: Welt fuer Auto60 (Stubs/Modelle, kein OEM-Code). Das EEPROM-MODELL folgt der ECHTEN settings.cpp-Semantik:
// save(): zuerst Platzhalter "ERR" (settings.cpp:653-668), Daten, am Ende Kopf "V85"+CRC (1452-1469); load(): validate() ... sonst reset() auf Standardwerte (settings.cpp load()).
#include "Marlin/src/inc/MarlinConfig.h"
#include "Marlin/src/feature/bedlevel/abl/abl.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "Marlin/src/HAL/shared/eeprom_api.h"
SimThermal thermalManager; SimCard card; int PrintFlag = 0; bool PoweroffContinue = false, pause_action_flag = false;
DualXMode dual_x_carriage_mode = DXC_AUTO_PARK_MODE; bool extruder_duplication_enabled = false;
bool printingIsPaused() { return W.paused; }
SimQueue2 queue2; SimSettings2 settings2;
void SimThermal::setTargetBed(const int16_t c) { temp_bed.target = c; W.log("bed_target " + std::to_string(c)); }

// ============================================================================================ 283: BYTE-GENAUES EEPROM-MODELL
// BL24CXX-Treiber (HAL/STM32F1/eeprom_bl24cxx.cpp) + Marlins save()/validate()/load() (settings.cpp). Kein STM32, keine Hardware. Das Modell bildet die Reihenfolge und die Rueckgabekonvention nach:
//  - write_data(): nur GEAENDERTE Bytes, Nachlesen; bei Fehler Rueckkehr 'true' OHNE pos weiterzuzaehlen; safe_delay() nur beim 128. geaenderten Byte EINES Aufrufs
//  - read_data(): do..while(--size) (size==0 waere ein Ueberlauf -> hier ein harter Abbruch); der echte Treiber meldet NIE einen Lesefehler
//  - save(): "ERR" zuerst, Felder in der ECHTEN Reihenfolge (settings.cpp:764-837: ..., probe.offset(12), Planar-Platzhalter(36), Bilinear gx gy spacing start z[16], ubl_active, slot, ...), Kopf+CRC zuletzt;
//    Rueckgabewerte von write_data werden WIE IM OEM verworfen (settings.h:129)
//  - load(): bei passendem Bilinear-Raster set_bed_leveling_enabled(false) und KEIN Wiederherstellen (settings.cpp:1676; das Flag wird fuer Bilinear nicht gespeichert, :833)
enum { SM_OK = 0, SM_RETURN_FALSE, SM_POWERLOSS_AFTER_ERR, SM_CORRUPT, SM_FAIL_ONCE, SM_CORRUPT_ZOFF, SM_CRC_BAD_VALIDATE_LIES };      // 5: gespeichertes probe.offset verfaelscht (CRC korrigiert); 6: Block mit FALSCHER CRC, den Marlins validate() faelschlich akzeptiert
struct Ee { bool header_ok = true; char ver[4] = {'V', '8', '5', 0}; float z[4][4]; float sp[2], st[2], fa[2]; float zoff = 0; bool lev = false; unsigned saves = 0, bytes = 0, loads = 0, validates = 0; };
static bool sim_validate_lies = false;
Ee g_ee; int sim_save_mode = SM_OK; int sim_save_calls = 0; bool sim_readback_unavailable = false;

#ifndef SIM_EE_OFFSET
  #define SIM_EE_OFFSET 100                           // Testschalter: Lage des Einstellungsblocks im Modell (Gegenstueck: SV04_CLAUDE_EEPROM_OFFSET im Adapter)
#endif
static const int kCap = 2048, kOff = SIM_EE_OFFSET, kLen = 800;
static const int kA = 300, kMblLen = 42, kB = 320;                 // Fuellfelder / MBL-Platzhalter (4 + 1 + 1 + 36)
static const int kAo = kOff + 6, kMblo = kAo + kA, kZpo = kMblo + kMblLen, kPlano = kZpo + 12, kMesho = kPlano + 36, kUblo = kMesho + 82, kBo = kUblo + 2;
static_assert(kBo + kB == kOff + kLen, "Blocklayout muss 800 Bytes ergeben");
struct EeChip { uint8_t b[kCap]; uint32_t changed, reads; int64_t cut_at, fail_at; bool unreadable; EeChip() { memset(b, 0xFF, sizeof b); changed = reads = 0; cut_at = fail_at = -1; unreadable = false; } };
static EeChip g_chip;
uint8_t sim_other_a[kA], sim_other_b[kB];          // "uebrige Einstellungen" im RAM (Marlin: alles ausser dem Mesh)
const char *sim_ee_out_path = nullptr;             // Abbild beim Stromausfall/Ende schreiben
extern uint32_t sim_ms;
extern void (*sim_idle_hook)();
void crc16(uint16_t *crc, const void *data, uint16_t cnt) {
  const uint8_t *p = (const uint8_t *)data;
  while (cnt--) { *crc = (uint16_t)(*crc ^ (uint16_t)(((uint16_t)*p++) << 8)); for (uint8_t i = 0; i < 8; i++) *crc = (uint16_t)((*crc & 0x8000) ? ((uint16_t)(*crc << 1) ^ 0x1021) : (*crc << 1)); }
}
void safe_delay(unsigned long ms) { sim_ms += (uint32_t)ms; if (sim_idle_hook) sim_idle_hook(); }     // konservativ: das echte safe_delay bedient nur die Heizung; ein idle() dazwischen waere die haertere Annahme
void sim_ee_save_image(const char *path) { FILE *f = fopen(path, "wb"); if (f) { fwrite(g_chip.b, 1, kCap, f); fclose(f); } }
bool sim_ee_load_image(const char *path) { FILE *f = fopen(path, "rb"); if (!f) return false; const size_t n = fread(g_chip.b, 1, kCap, f); fclose(f); return n == (size_t)kCap; }
void sim_ee_power_cut() { if (sim_ee_out_path) sim_ee_save_image(sim_ee_out_path); printf("RESULT state=POWERLOSS reason=cut changed=%u\n", g_chip.changed); fflush(stdout); exit(0); }      // Strom weg: nichts laeuft mehr
void sim_ee_set_faults(long long cut_at, long long fail_at) { g_chip.cut_at = cut_at >= 0 ? (long long)g_chip.changed + cut_at : -1; g_chip.fail_at = fail_at >= 0 ? (long long)g_chip.changed + fail_at : -1; }
uint32_t sim_ee_changed() { return g_chip.changed; }
void sim_ee_refresh();
uint8_t *sim_ee_bytes() { return g_chip.b; }
void sim_ee_set_unreadable(bool u) { g_chip.unreadable = u; }

PersistentStore persistentStore;
size_t PersistentStore::capacity() { return kCap; }
bool PersistentStore::access_start() { return true; }
bool PersistentStore::access_finish() { return true; }
bool PersistentStore::write_data(int &pos, const uint8_t *value, size_t size, uint16_t *crc) {
  uint16_t written = 0;
  while (size--) {
    const uint8_t v = *value;
    if (pos < 0 || pos >= kCap) { fprintf(stderr, "SIM: Schreibzugriff ausserhalb des EEPROMs (pos=%d)\n", pos); exit(99); }
    if (v != g_chip.b[pos]) {
      if (g_chip.cut_at >= 0 && (int64_t)g_chip.changed >= g_chip.cut_at) sim_ee_power_cut();                 // Stromausfall VOR diesem Byte
      if (g_chip.fail_at >= 0 && (int64_t)g_chip.changed == g_chip.fail_at) { ++g_chip.changed; g_chip.fail_at = -1; return true; }      // Schreibfehler: Nachlesen scheitert -> Rueckkehr mit Fehler OHNE pos
      g_chip.b[pos] = v; ++g_chip.changed;
      if (!(++written & 0x7F)) safe_delay(2);
    }
    crc16(crc, &v, 1); pos++; value++;
  }
  return false;
}
bool PersistentStore::read_data(int &pos, uint8_t *value, size_t size, uint16_t *crc, const bool writing) {
  if (size == 0) { fprintf(stderr, "SIM: read_data mit size==0 (do..while(--size) liefe ueber)\n"); exit(98); }       // die Falle des echten Treibers
  do {
    if (pos < 0 || pos >= kCap) { fprintf(stderr, "SIM: Lesezugriff ausserhalb des EEPROMs (pos=%d)\n", pos); exit(99); }
    const uint8_t c = g_chip.unreadable ? (uint8_t)0xFF : g_chip.b[pos];                                          // der echte Treiber kann einen Busfehler NICHT melden: er liefert Muell
    if (writing) *value = c;
    crc16(crc, &c, 1); pos++; value++; ++g_chip.reads;
  } while (--size);
  return false;
}

static bool chip_crc_ok() { uint16_t crc = 0; crc16(&crc, g_chip.b + kOff + 6, kLen - 6); uint16_t st; memcpy(&st, g_chip.b + kOff + 4, 2); return memcmp(g_chip.b + kOff, "V85", 4) == 0 && crc == st; }
static void ee_view() {                                              // g_ee ist nur noch eine ANSICHT des Byte-Abbilds (fuer die Treiberausgabe der Alt-Tests)
  g_ee.bytes = g_chip.changed; memcpy(g_ee.ver, g_chip.b + kOff, 4); g_ee.header_ok = chip_crc_ok();
  for (int x = 0; x < 4; x++) for (int y = 0; y < 4; y++) memcpy(&g_ee.z[x][y], g_chip.b + kMesho + 18 + (x * 4 + y) * 4, 4);
  memcpy(g_ee.sp, g_chip.b + kMesho + 2, 8); memcpy(g_ee.st, g_chip.b + kMesho + 10, 8); memcpy(&g_ee.zoff, g_chip.b + kZpo + 8, 4);
  g_ee.fa[0] = g_ee.sp[0] != 0 ? 1.0f / g_ee.sp[0] : 0; g_ee.fa[1] = g_ee.sp[1] != 0 ? 1.0f / g_ee.sp[1] : 0; g_ee.lev = false;
}
void sim_ee_refresh() { ee_view(); }                                  // Ansicht g_ee aus dem Abbild neu ableiten (der Adapter schreibt am save() vorbei: Journal-Rueckspielen)
static void other_defaults() { for (int i = 0; i < kA; i++) sim_other_a[i] = (uint8_t)(i * 7 + 3); for (int i = 0; i < kB; i++) sim_other_b[i] = (uint8_t)(i * 13 + 5); }
void sim_ee_init_from_ram() {                                         // werkseitig beschriebenes EEPROM: ein ungestoerter save() des aktuellen RAMs
  g_chip = EeChip(); other_defaults(); const int m = sim_save_mode; sim_save_mode = SM_OK; sim_save_calls = 0;
  const size_t n_cmds = W.cmds.size(), n_trace = W.trace.size();
  void (*const hook)() = sim_idle_hook; sim_idle_hook = nullptr;          // das Werks-Beschreiben ist KEIN laufender Betrieb: kein Auto60-Tick mittendrin
  settings2.save(); sim_idle_hook = hook; sim_save_mode = m; W.cmds.resize(n_cmds); W.trace.resize(n_trace); sim_save_calls = 0; g_chip.changed = 0; g_ee.saves = g_ee.loads = g_ee.validates = 0; W.eeprom_saves = 0; ee_view();
}
bool SimSettings2::save() {
  ++g_ee.saves; ++sim_save_calls; W.log("settings.save"); W.eeprom_saves++;
  int pos = kOff; uint16_t crc = 0, dummy = 0; bool abort_now = false;
  const uint32_t c0 = g_chip.changed; const uint32_t budget = (sim_save_mode == SM_POWERLOSS_AFTER_ERR || sim_save_mode == SM_RETURN_FALSE || (sim_save_mode == SM_FAIL_ONCE && sim_save_calls == 1)) ? 3u : 0xFFFFFFFFu;
  persistentStore.access_start();
  const uint8_t err[4] = {'E', 'R', 'R', 0};
  persistentStore.write_data(pos, err, 4, &dummy);                                                    // Platzhalter zuerst (settings.cpp:655/662)
  pos += 2; crc = 0;                                                                                  // CRC-Platz ueberspringen (:664)
  auto Wr = [&](const void *d, size_t n) { if (g_chip.changed - c0 >= budget) abort_now = true; if (abort_now) { pos += (int)n; return; } persistentStore.write_data(pos, (const uint8_t *)d, n, &crc); };
  const float zero = 0; const uint8_t three = 3, four = 4, off = 0, slot = 0xFF; const uint8_t zeros36[36] = {0};
  Wr(sim_other_a, kA);
  Wr(&zero, 4); Wr(&three, 1); Wr(&three, 1); Wr(zeros36, 36);                                         // MBL-Platzhalter: z_offset, mesh_num_x/y, 9 x dummyf (:764-771)
  const xyz_pos_t zpo = probe.offset; Wr(&zpo, 12);                                                    // :785
  Wr(zeros36, 36);                                                                                    // Planar-Platzhalter (:796)
  Wr(&four, 1); Wr(&four, 1); const xy_pos_t sp = bilinear_grid_spacing, st = bilinear_start; Wr(&sp, 8); Wr(&st, 8); Wr(z_values, 64);   // :815-821
  Wr(&off, 1); Wr(&slot, 1);                                                                          // ubl_active=false (:833: fuer Bilinear NICHT gespeichert), storage_slot=-1
  Wr(sim_other_b, kB);
  if (abort_now) { ee_view(); return false; }                                                         // Abbruch: Kopf bleibt "ERR"
  const uint16_t size = (uint16_t)(pos - kOff), fin = crc;
  if (sim_save_mode == SM_CORRUPT) { const float bad = z_values[2][1] + 0.5f; uint8_t tmp[4]; memcpy(tmp, &bad, 4); persistentStore.write_data(kMesho + 18 + (2 * 4 + 1) * 4, tmp, 4); uint16_t c2 = 0; crc16(&c2, g_chip.b + kOff + 6, kLen - 6); pos = kOff + 4; persistentStore.write_data(pos, (const uint8_t *)&c2, 2, &dummy); pos = kOff; const uint8_t v[4] = {'V', '8', '5', 0}; persistentStore.write_data(pos, v, 4, &dummy); ee_view(); return true; }
  if (sim_save_mode == SM_CORRUPT_ZOFF) { uint8_t zb = g_chip.b[kZpo + 8] ^ 0x04; persistentStore.write_data(kZpo + 8, &zb, 1); uint16_t c2 = 0; crc16(&c2, g_chip.b + kOff + 6, kLen - 6); pos = kOff + 4; persistentStore.write_data(pos, (const uint8_t *)&c2, 2, &dummy); pos = kOff; const uint8_t v[4] = {'V', '8', '5', 0}; persistentStore.write_data(pos, v, 4, &dummy); ee_view(); return true; }
  pos = kOff; const uint8_t ver[4] = {'V', '8', '5', 0};
  persistentStore.write_data(pos, ver, 4, &dummy); persistentStore.write_data(pos, (const uint8_t *)&fin, 2, &dummy);   // Kopf + CRC zuletzt (:1461-1464)
  if (sim_save_mode == SM_CRC_BAD_VALIDATE_LIES) { g_chip.b[kBo + 10] ^= 0x01; sim_validate_lies = true; ee_view(); return true; }      // ein Byte kippt NACH der CRC (Fehlschreiben); validate() meldet trotzdem 'gueltig'
  persistentStore.access_finish(); ee_view();
  return size == kLen;                                                                                // wie size_error(): NICHT das Ergebnis der Schreibzugriffe
}
static bool validate_raw() {
  persistentStore.access_start();
  int pos = kOff; uint8_t ver[4]; uint16_t stored = 0, dummy = 0, crc = 0;
  persistentStore.read_data(pos, ver, 4, &dummy, true); persistentStore.read_data(pos, (uint8_t *)&stored, 2, &dummy, true);
  if (memcmp(ver, "V85", 4) != 0) return false;
  uint8_t buf[kLen]; persistentStore.read_data(pos, buf, kLen - 6, &crc, false);
  persistentStore.access_finish();
  return crc == stored;
}
bool SimSettings2::validate() { ++g_ee.validates; W.log("eeprom_validate"); const bool ok = sim_validate_lies ? true : validate_raw(); if (ok && sim_readback_unavailable) g_chip.unreadable = true; return ok; }   // Altschalter: nach erfolgreichem validate() ist der Bus gestoert
bool SimSettings2::load() {
  ++g_ee.loads; W.log("settings.load");
  if (!validate()) { reset_bed_level(); probe.offset.z = 0; other_defaults(); return false; }           // echtes load(): reset() auf Standardwerte
  memcpy(sim_other_a, g_chip.b + kAo, kA); memcpy(sim_other_b, g_chip.b + kBo, kB);
  memcpy(&probe.offset, g_chip.b + kZpo, 12);
  set_bed_leveling_enabled(false);                                                                    // settings.cpp:1676: Raster passt -> Nivellierung AUS, KEIN Wiederherstellen
  memcpy(&bilinear_grid_spacing, g_chip.b + kMesho + 2, 8); memcpy(&bilinear_start, g_chip.b + kMesho + 10, 8); memcpy(z_values, g_chip.b + kMesho + 18, 64);
  bilinear_grid_factor = bilinear_grid_spacing.reciprocal();
  return true;
}
