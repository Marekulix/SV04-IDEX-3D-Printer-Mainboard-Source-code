"""Punkt 3 (G29 + zuverlaessiger Abbruch) auf dem gemeinsamen Stand 289: die ECHTE, im Build 289 verwendete G29.cpp ("G29-CANCEL V1", bitgleich per SHA-256 belegt) + 290-Erweiterung (Pruefung vor dem Endskript), der ECHTE G28,
der ECHTE Adapter/Koordinator/EEPROM-Kern, die ECHTEN V2/V4-bedlevel-Funktionen und der Planner-Guard 288. Host-Simulation; KEIN STM32, KEINE Hardware, KEIN HMI-Projekt, KEIN echter Touch."""
import hashlib
import re
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import chain_tree as T  # noqa: E402
import test_ee_a60 as E  # noqa: E402

# SHA-256 der OEM-Dateien des ERFOLGREICH GEBAUTEN Stands 289 (GitHub-Run, beide Profile BUILD_EXIT=0; Datei BELEG_GEGEN_OEM_ANWENDBAR der 287-Uebergabe)
BUILD_289 = {'Marlin/src/gcode/calibrate/G28.cpp': 'c2017fbd2b9426b38d1c2435d24b08c323d9c5cb0fff257cc773c8fe41a19b95', 'Marlin/src/gcode/gcode.cpp': '12958700de094c44386c381a423966663058f62dfa7e1204d5922bcb46944a8d',
             'Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp': '0d8ef04dac43935d917d77a7c0efd269361b924b26270ccee85fadba9171a94c', 'Marlin/src/module/motion.cpp': '54ff1c0c034f76b1c795e747cbc0fad525c259c6ce6ffd0e8c7fd4c90062ec96',
             'Marlin/src/module/motion.h': 'df5118d6b4b74c355ddda8d2b2d228f99029061905145e6603c6406eca53950e'}
REAL = ['SIM_REAL_BEDLEVEL=v2v4']
G29 = 'Marlin/src/gcode/bedlevel/abl/G29.cpp'


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def n(r, key, field):
    return int(re.search(field + r'=(-?\d+)', r[key]).group(1))


def hm(r):
    return [int(v) for v in r['HMI'].split()]


class Reconstruction(unittest.TestCase):
    def test_GC01_the_simulation_runs_the_very_g29_and_oem_files_of_the_successfully_built_289(self):
        tree = T.shared()['integ']
        for rel, want in BUILD_289.items():
            self.assertEqual(sha(tree / rel), want, rel + ': Simulation == Build 289 (bitgleich)')
        ext = __import__('apply_g29_cancel_ext_290')
        text = (tree / G29).read_text(encoding='utf-8')
        self.assertIn('G29-CANCEL V1', text); self.assertIn('G29-CANCEL EXT 290', text)
        g5 = __import__('apply_g29_stopped_c5')
        self.assertIn('SV04 NEXT C5', text); self.assertEqual(text.count(g5.B_FN), 1)
        base = text.replace(g5.B_FN, g5.A_FN).replace(g5.B_INC, g5.A_INC)                      # C5: die bekannte, getrennt gepruefte Stopp-Pruefung der manuellen G29 zuerst zuruecknehmen
        self.assertEqual(hashlib.sha256(base.replace(ext.NEW, ext.OLD).encode()).hexdigest(), T.G29_CANCEL_V1_SHA256, 'G29.cpp ohne die 290-Erweiterung und ohne die C5-Stopp-Pruefung == G29.cpp des Builds 289')

    def test_GC02_the_extension_installer_is_idempotent_and_refuses_a_changed_or_missing_anchor(self):
        ext = __import__('apply_g29_cancel_ext_290')
        v1 = (T.shared()['integ'] / G29).read_text(encoding='utf-8').replace(ext.NEW, ext.OLD)
        once, c1 = ext.transform(v1); twice, c2 = ext.transform(once)
        self.assertTrue(c1); self.assertFalse(c2); self.assertEqual(once, twice); self.assertEqual(once.count('G29-CANCEL EXT 290'), 1)
        for bad in (v1.replace('if (!sv04_g29_cancelled)', 'if (!sv04_g29_cancelled_x)'), v1.replace(ext.OLD, ext.OLD + '\n' + ext.OLD)):
            with self.assertRaises(ValueError):
                ext.transform(bad)

    def test_GC03_the_sim_dwin_receive_stub_is_the_overlay_block_of_the_oem_function(self):
        diff = (HERE.parents[2] / 'diffs' / '2_OVERLAY_LCD_RTS_OEM_nach_277.patch').read_text(encoding='utf-8')
        block = [l[1:].strip() for l in diff.splitlines() if l.startswith('+') and 'recdat' in l or l.startswith('+') and 'SV04Claude_Auto60_TouchCancel' in l or l.startswith('+') and 'SV04Claude_Auto60_Busy' in l]
        self.assertTrue(any('SV04Claude_Auto60_Busy()' in l for l in block) and any('SV04Claude_Auto60_TouchCancel();' in l for l in block) and any('memset(&recdat' in l for l in block))
        stub = (HERE / 'sim_world_a60.cpp').read_text(encoding='utf-8'); i = stub.index('void RTSSHOW::RTS_HandleData()')
        self.assertIn('if (SV04Claude_Auto60_Busy()) { SV04Claude_Auto60_TouchCancel(); return; }', stub[i:i + 300])


class Interfaces(unittest.TestCase):
    def test_GC04_every_claude_identifier_and_macro_the_289_oem_files_use_is_declared_in_the_overlay_hooks(self):
        """Schutz vor einem Build-Bruch an der Naht Overlay <-> ChatGPTs Installer: das Overlay ersetzt hooks.h und den Adapter NACH der Integration; jeder Bezeichner der OEM-Dateien muss dort stehen."""
        tree = T.shared()['integ']
        hooks = (HERE.parents[1] / '02_SOURCE/Marlin/src/lcd/e3v2/creality/sv04_claude_hooks.h').read_text(encoding='utf-8')
        used = set()
        for rel in list(BUILD_289) + [G29]:
            txt = (tree / rel).read_text(encoding='utf-8', errors='replace'); own = set(re.findall(r'#\s*define\s+(SV04_CLAUDE_[A-Z0-9_]+)', txt))          # C5: in der Datei SELBST definierte Makros brauchen keine Deklaration in hooks.h
            used |= set(re.findall(r'\bSV04Claude_[A-Za-z0-9_]+|\bSV04_CLAUDE_[A-Z0-9_]+', txt)) - own
        self.assertGreaterEqual(len(used), 9)
        for ident in sorted(used):
            self.assertRegex(hooks, r'\b' + ident + r'\b', ident + ' fehlt in sv04_claude_hooks.h')
        self.assertIn('SV04Claude_G29CancelRequested', used)


class NonRegression(unittest.TestCase):
    def test_GC05_no_production_code_of_the_overlay_sets_leveling_active_itself(self):
        """Punkt 14: nichts umgeht die Sicherheitsgates (V4/V9-Guard, Planner-Guard 288); der Zustand wird nur ueber set_bed_leveling_enabled() geaendert. (Quelltext-Pruefung als ERGAENZUNG; der Nachweis durch Ausfuehrung sind GC30 und die BL-Tests.)"""
        src = HERE.parents[1] / '02_SOURCE'
        for f in list(src.rglob('*.h')) + list(src.rglob('*.inc')):
            for i, line in enumerate(f.read_text(encoding='utf-8').splitlines(), 1):
                code = line.split('//')[0]
                self.assertIsNone(re.search(r'leveling_active\s*=[^=]', code), f'{f.name}:{i}: {line.strip()}')


class Measurement(unittest.TestCase):
    def test_GC10_success_path_measures_16_points_runs_the_end_script_and_reads_nothing_from_the_dwin(self):
        r = E.run('homed=none')
        self.assertEqual((r['state'], r['reason']), ('SUCCESS', 'VERIFIED')); self.assertEqual(n(r, 'COUNTS', 'probe'), 16); self.assertEqual(r['HOMEAXIS'], 'count=7', 'Referenzfahrt (4) + Endskript G28 XY (3)')
        self.assertEqual(r['RX'], 'polled=0 pending=0'); self.assertEqual(r['HMIPAGE'], '22')

    def test_GC11_a_cancel_during_ANY_probe_stops_the_measurement_right_there_without_end_script_or_eeprom(self):
        """Fuer jeden Messpunkt k=1..16, in BEIDEN Umgebungen: (a) idle() ruft RTSUpdate() auf; (b) idle() ruft es NIE auf, der Touch kommt als DWIN-RAHMEN und wird NUR vom Abbruchtest der G29-Schleife gelesen."""
        for k in range(1, 17):
            for label, opt in (('RTSUpdate in idle', []), ('OHNE RTSUpdate in idle', ['no_idle_rts=1'])):
                r = E.run('homed=none', f'touch_after_probe={k}', *opt)
                tag = f'k={k} {label}'
                self.assertEqual((r['state'], r['reason']), ('CANCELLED', 'CANCEL_AFTER_STEP'), tag)
                self.assertEqual(n(r, 'COUNTS', 'probe'), k, tag + ': GENAU k Messungen, keine weitere'); self.assertEqual(r['HOMEAXIS'], 'count=4', tag + ': KEIN Endskript, keine Nachbewegung beider IDEX-Wagen')
                self.assertEqual(r['EEBYTES_CHANGED_VS_START'], '0', tag); self.assertEqual(n(r, 'COUNTS', 'settings_save'), 0, tag + ': kein M500'); self.assertEqual(r['HMIPAGE'], '28', tag + ': Fehlerseite, nie die Erfolgsseite')
                self.assertEqual(r['HMI'], r['HMI0'], tag + ': das Display zeigt wieder das ALTE Mesh'); self.assertEqual(r['EEMAINEQ'], '1', tag); self.assertEqual(int(r['RAM'].split('leveling=')[1].split()[0]), 1, tag + ': Nivellierung wie vorher')
                if opt:
                    self.assertEqual(r['RX'], 'polled=1 pending=0', tag + ': der Rahmen wurde vom Abbruchtest selbst gelesen')

    def test_GC11b_a_cancel_DURING_the_measurement_k_does_not_commit_that_measurement_to_mesh_or_display(self):
        """Der Touch trifft INNERHALB von probe_at_point() ein (vor der Uebernahme des Werts). Die Pruefung NACH der Messung verwirft ihn: live wurden nur k-1 Zellen geschrieben (+ 16 Boot-Rahmen; + 16 Rahmen der Wiederherstellung, sobald mindestens eine Zelle ueberschrieben war)."""
        for k in range(1, 17):
            r = E.run('homed=none', f'touch_in_probe={k}', 'no_idle_rts=1')
            tag = f'k={k}'
            self.assertEqual((r['state'], r['reason']), ('CANCELLED', 'CANCEL_AFTER_STEP'), tag); self.assertEqual(n(r, 'COUNTS', 'probe'), k, tag); self.assertEqual(r['HOMEAXIS'], 'count=4', tag + ': kein Endskript')
            self.assertEqual(int(r['HMICELLWRITES']), 16 + (k - 1) + (16 if k >= 2 else 0), tag + ': die abgebrochene Messung wurde NICHT als Zelle angezeigt')
            self.assertEqual(r['EEBYTES_CHANGED_VS_START'], '0', tag); self.assertEqual(r['HMI'], r['HMI0'], tag); self.assertEqual(r['RX'], 'polled=1 pending=0', tag)

    def test_GC12_a_cancel_right_after_the_g29_begin_means_zero_probes(self):
        for opt in ([], ['no_idle_rts=1']):
            r = E.run('homed=none', 'touch_g29_start=1', *opt)
            self.assertEqual((r['state'], r['reason']), ('CANCELLED', 'CANCEL_AFTER_STEP'), str(opt)); self.assertEqual(n(r, 'COUNTS', 'probe'), 0); self.assertEqual(r['HOMEAXIS'], 'count=4'); self.assertEqual(r['EEBYTES_CHANGED_VS_START'], '0'); self.assertEqual(r['HMI'], r['HMI0'])

    def test_GC13_a_cancel_during_the_homing_never_starts_the_g29(self):
        for k in (3, 4):
            r = E.run('homed=none', f'touch_after_homeaxis={k}', 'no_idle_rts=1')
            self.assertEqual((r['state'], r['reason']), ('CANCELLED', 'CANCEL_AFTER_STEP'), k); self.assertEqual(n(r, 'COUNTS', 'probe'), 0, 'keine einzige Messung'); self.assertEqual(r['EEBYTES_CHANGED_VS_START'], '0')

    def test_GC14_a_cancel_during_the_end_script_cannot_stop_the_running_g28_but_never_ends_as_success(self):
        """GRENZE (ehrlich): ein laufendes G28 XY wird nicht unterbrochen. Danach: kein Erfolg, kein EEPROM, altes Mesh, keine Erfolgsseite."""
        for k in (5, 6, 7):
            r = E.run('homed=none', f'touch_after_homeaxis={k}', 'no_idle_rts=1')
            self.assertEqual(r['state'], 'CANCELLED', k); self.assertEqual(r['HOMEAXIS'], 'count=7', 'das begonnene Endskript laeuft zu Ende'); self.assertEqual(r['EEBYTES_CHANGED_VS_START'], '0'); self.assertEqual(n(r, 'COUNTS', 'settings_save'), 0)
            self.assertEqual(r['HMIPAGE'], '28'); self.assertEqual(r['HMI'], r['HMI0']); self.assertEqual(int(r['RAM'].split('leveling=')[1].split()[0]), 1)

    def test_GC15_a_user_g29_keeps_its_normal_semantics_a_touch_never_stops_it(self):
        r = E.run('homed=all', 'manual_g29=1', 'touch_after_probe=6', 'no_idle_rts=1')
        self.assertEqual(n(r, 'COUNTS', 'probe'), 16, 'alle 16 Messungen der Benutzer-G29'); self.assertEqual((r['state'], r['reason']), ('IDLE', 'NONE'))
        r2 = E.run('homed=all', 'manual_g29=1', 'touch_after_probe=1', 'no_idle_rts=1')
        self.assertEqual(n(r2, 'COUNTS', 'probe'), 16)
        cmds = [c.strip() for c in r['CMDS'].split(';') if c.strip()]
        last_probe = max(i for i, c in enumerate(cmds) if c.startswith('probe_at_point'))
        self.assertTrue(all(i > last_probe for i, c in enumerate(cmds) if c == 'RTS_HandleData(normal)'), 'der Abbruchtest liest den DWIN-Puffer einer BENUTZER-G29 NIE (keine OEM-Tastenbehandlung mitten in der G29)')


class JournalClosure(unittest.TestCase):
    """299: EEPROM 293/294 (ChatGPT, Punkt 6) x G29-Abbruch. Ein gescheitertes BEENDEN des Journals ist nie Erfolg und sperrt weitere Auto60-Schreibzugriffe in dieser Sitzung."""

    def test_GC40_a_failed_journal_close_is_never_success_blocks_further_auto60_writes_and_the_next_boot_finishes_it(self):
        old, new, total = E.refs(); last = total - 1
        r = E.run('homed=none', f'ee_fail_at={last}', 'rerun=1', 'limit_s=1200', 'ee_out=' + E.img('gc40.img'))
        self.assertEqual(r['RESULT1'], 'state=FAILED reason=EEPROM_RECOVERY_REQUIRED'); self.assertEqual((r['state'], r['reason']), ('FAILED', 'EEPROM_RECOVERY_REQUIRED'), 'der zweite Start in derselben Sitzung wird abgelehnt, der Zustand bleibt')
        self.assertIn('Auto60-Speicherung gesperrt', r['SERIAL']); self.assertIn('Auto60 refused: PRE_EEPROM_UNAVAILABLE', r['SERIAL']); self.assertEqual(r['HMIPAGE'], '28', 'nie die Erfolgsseite'); self.assertEqual(r['EEBYTES_CHANGED_VS_START'], '877', 'der zweite Lauf hat NICHTS geschrieben')
        self.assertEqual(E.block(E.img('gc40.img')), new, 'der neue Block ist gueltig und verifiziert')
        b = E.run('boot_only=1', 'ee_in=' + E.img('gc40.img'), 'ee_out=' + E.img('gc40b.img')); self.assertEqual(E.block(E.img('gc40b.img')), old, 'nach dem Neustart steht exakt der ALTE verifizierte Block im EEPROM'); self.assertEqual((b['raw']['boot_res'], b['raw']['boot_primary']), (2, 5), 'seit 306: der naechste Start spielt den ALTEN verifizierten Block zurueck (BR_RESTORED), der Block ist gueltig')
        r2 = E.run('homed=none', 'ee_in=' + E.img('gc40.img')); self.assertEqual((r2['state'], r2['reason']), ('SUCCESS', 'VERIFIED'), 'nach dem Neustart ist Auto60 wieder frei')

    def test_GC41_an_abort_attempt_while_the_save_is_being_verified_cannot_hide_a_failed_journal_close(self):
        old, new, total = E.refs()
        r = E.run('homed=none', f'ee_fail_at={total - 1}', 'touch_at=VERIFYING')
        self.assertEqual((r['state'], r['reason']), ('FAILED', 'EEPROM_RECOVERY_REQUIRED')); self.assertEqual(r['HMIPAGE'], '28'); self.assertEqual(n(r, 'COUNTS', 'settings_save'), 1)

    def test_GC32_the_finite_motion_guard_would_halt_a_nan_move_and_no_abort_path_produces_one(self):
        """Positivkontrolle: derselbe NaN-Zug endet mit dem Guard in KILLED, ohne ihn in SUCCESS. Alle Abbruchfaelle (GC30) laufen mit dem Guard OHNE Notstopp."""
        killed = E.run('homed=none', 'nan_move=3', name='bl_g29', defines=REAL); plain = E.run('homed=none', 'nan_move=3')
        self.assertEqual(killed['state'], 'KILLED'); self.assertEqual(plain['state'], 'SUCCESS')


class Sessions(unittest.TestCase):
    def test_GC20_stale_touches_before_the_start_never_cancel_the_new_run(self):
        for opt in (['rx_idle=1'], ['rx_idle=3'], ['touch_idle=1', 'rx_idle=3']):
            r = E.run('homed=none', *opt)
            self.assertEqual((r['state'], r['reason']), ('SUCCESS', 'VERIFIED'), str(opt))

    def test_GC21_many_frames_in_the_same_moment_are_one_cancel_and_leave_no_residue(self):
        r = E.run('homed=none', 'touch_after_probe=6', 'no_idle_rts=1', 'touch_probe_burst=5')
        self.assertEqual((r['state'], r['reason']), ('CANCELLED', 'CANCEL_AFTER_STEP')); self.assertEqual(n(r, 'COUNTS', 'probe'), 6); self.assertEqual(r['STALE'], '0'); self.assertEqual(r['RX'], 'polled=5 pending=0')

    def test_GC22_a_cancelled_run_can_be_restarted_at_once_and_the_new_run_is_not_cancelled(self):
        r = E.run('homed=none', 'touch_after_probe=6', 'no_idle_rts=1', 'rerun=1', 'limit_s=1200')
        self.assertEqual(r['RESULT1'], 'state=CANCELLED reason=CANCEL_AFTER_STEP'); self.assertEqual((r['state'], r['reason']), ('SUCCESS', 'VERIFIED'))

    def test_GC23_without_the_poll_the_touch_during_the_g29_is_only_seen_after_it_NEGATIVE_CONTROL(self):
        """Mit SV04_CLAUDE_G29_POLL_DWIN=0 und einem idle(), das RTSUpdate() nicht aufruft, erreicht der Touch die laufende G29 NICHT: sie misst alle 16 Punkte und faehrt das Endskript. Das ist der Grund fuer den Abfrage-Code."""
        r = E.run('homed=none', 'touch_after_probe=6', 'no_idle_rts=1', name='nopoll', defines=['SV04_CLAUDE_G29_POLL_DWIN=0'])
        self.assertEqual(n(r, 'COUNTS', 'probe'), 16); self.assertEqual(r['HOMEAXIS'], 'count=7'); self.assertEqual(r['state'], 'CANCELLED', 'trotzdem nie als Erfolg'); self.assertEqual(r['EEBYTES_CHANGED_VS_START'], '0')


class MeshTransactionWithGuards(unittest.TestCase):
    def test_GC30_every_cancel_with_the_real_v2_v4_functions_and_the_planner_guard_never_halts_the_printer(self):
        """Altes Mesh LEER (NaN) oder gueltig, Nivellierung vorher aus/an. Rueckweg: ZUERST ausschalten, DANN das alte Mesh herstellen (sv04c_mesh_rollback_safe). Notstopp-Bedingung (aktiv + ungueltig) steht in set_bed_leveling_enabled (V4) UND in jeder Bewegung (Planner-Guard 288)."""
        import test_bedlevel_a60 as BL
        blank = BL.blank(); cells = 0
        for label, base, lev0 in (('altes Mesh leer', ['ee_in=' + blank, 'lev0=0'], 0), ('gueltig, Nivellierung aus', ['lev0=0'], 0), ('gueltig, Nivellierung an', ['lev0=1'], 1)):
            for k in range(1, 17):
                r = E.run('homed=none', f'touch_after_probe={k}', 'no_idle_rts=1', *base, name='bl_g29', defines=REAL)
                tag = f'{label} k={k}'
                self.assertNotEqual(r['state'], 'KILLED', tag + ': KEIN Notstopp'); self.assertEqual(r['state'], 'CANCELLED', tag); self.assertEqual(r['EEBYTES_CHANGED_VS_START'], '0', tag)
                self.assertEqual(int(r['RAM'].split('leveling=')[1].split()[0]), lev0, tag + ': Nivellierung wie VOR dem Lauf'); self.assertEqual(r['HMI'], r['HMI0'], tag + ': Display == altes Mesh'); cells += 1
        self.assertEqual(cells, 48)

    def test_GC31_the_planner_guard_is_really_active_in_the_real_variant(self):
        """Kontrolle des Messaufbaus: derselbe Guard-Text wie in planner.cpp; ein gueltiges Mesh und alle Lauefe oben beweisen sonst nichts, wenn der Guard nie ausloesen koennte."""
        sim = (HERE / 'sim_world_a60.cpp').read_text(encoding='utf-8'); self.assertIn('if (planner.leveling_active && !leveling_is_valid())', sim); self.assertIn('SV04: invalid active mesh at planner enqueue', sim)
        patch_text = ''
        for p in (HERE.parents[2] / 'claude' / '07_AUDIT').glob('*.md'):
            patch_text += p.read_text(encoding='utf-8', errors='ignore')
        guard = (HERE.parents[2] / 'm420' / 'apply_m420_v4.py').read_text(encoding='utf-8')
        self.assertIn('Invalid active mesh', guard)


if __name__ == '__main__':
    unittest.main(verbosity=2)
