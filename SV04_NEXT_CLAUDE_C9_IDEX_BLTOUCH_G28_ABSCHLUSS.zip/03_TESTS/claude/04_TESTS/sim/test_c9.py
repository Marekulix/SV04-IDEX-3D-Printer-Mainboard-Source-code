"""C9: Wiederaufnahme nach Fehlern: M999 aus dem Stopp-Zustand erzeugt keine Sicherheitsfreigabe.
Die ECHTE OEM-M999.cpp wird (mit minimalen Attrappen fuer Marlin-Header) kompiliert und ausgefuehrt: Host-Test, KEIN STM32-Build, KEINE Hardware.
 C901..C906 echte M999.cpp (gepatcht), C907 Negativkontrolle OEM-Original, C908 Patchskript, C909 Mutanten, C910 Komposition mit der Auto60-Simulation"""
import hashlib
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
CLAUDE = HERE.parents[1]
sys.path.insert(0, str(HERE)); sys.path.insert(0, str(CLAUDE / '03_PATCHES'))
import apply_m999_reset_c9 as M9  # noqa: E402
import test_ee_a60 as E  # noqa: E402

OEM = (CLAUDE / '01_BASELINE/OEM_309/orig/gcode/control/M999.cpp').read_bytes()
STUBS = {
    'gcode/gcode.h': '#pragma once\n#include <cstdio>\n#include <string>\nextern std::string sim_log;\n#define SERIAL_ECHO_MSG(s) do { sim_log += s; sim_log += "|"; } while (0)\nstruct Parser { bool s = false; bool boolval(char) const { return s; } };\nextern Parser parser;\nstruct GcodeSuite { static void M999(); };\n',
    'lcd/marlinui.h': '#pragma once\nstruct UI { int alerts = 0; void reset_alert_level() { ++alerts; } };\nextern UI ui;\n',
    'MarlinCore.h': '#pragma once\nenum MarlinState { MF_INITIALIZING = 0, MF_STOPPED = 1, MF_KILLED = 2, MF_RUNNING = 3 };\nextern MarlinState marlin_state;\ninline bool IsStopped() { return marlin_state == MF_STOPPED; }\n',
    'gcode/queue.h': '#pragma once\nstruct Ring { int command_port() const { return 0; } };\nstruct Queue { int flushes = 0; Ring ring_buffer; void flush_and_request_resend(int) { ++flushes; } };\nextern Queue queue;\n',
    'module/motion.h': '#pragma once\nextern unsigned axis_homed, axis_trusted;\ninline void set_all_unhomed() { axis_homed = axis_trusted = 0; }\n',
}
MAIN = r'''#include <cstdlib>
#include <cstdio>
#include <string>
#include "gcode/gcode.h"
#include "lcd/marlinui.h"
#include "MarlinCore.h"
#include "gcode/queue.h"
#include "module/motion.h"
std::string sim_log; Parser parser; UI ui; MarlinState marlin_state = MF_RUNNING; Queue queue; unsigned axis_homed = 0, axis_trusted = 0;
int main(int argc, char** argv) {
  marlin_state = (MarlinState)std::atoi(argv[1]); axis_homed = std::atoi(argv[2]); axis_trusted = std::atoi(argv[3]); parser.s = std::atoi(argv[4]) != 0;
  GcodeSuite::M999();
  std::printf("state=%d homed=%u trusted=%u flushes=%d alerts=%d msg=%d\n", (int)marlin_state, axis_homed, axis_trusted, queue.flushes, ui.alerts, sim_log.find("UNHOMED") != std::string::npos);
}
'''


def build(src, defines=()):
    d = Path(tempfile.mkdtemp())
    for rel, txt in STUBS.items(): (d / rel).parent.mkdir(parents=True, exist_ok=True); (d / rel).write_text(txt)
    (d / 'gcode/control').mkdir(parents=True, exist_ok=True); (d / 'gcode/control/M999.cpp').write_bytes(src); (d / 'main.cpp').write_text(MAIN)
    r = subprocess.run(['g++', '-std=c++11', '-O1', '-Wall', '-Wextra', '-Wno-unused-variable', '-Wno-unused-but-set-variable'] + ['-D' + x for x in defines] + ['-I', str(d), str(d / 'main.cpp'), str(d / 'gcode/control/M999.cpp'), '-o', str(d / 'm')], capture_output=True, text=True)
    assert r.returncode == 0, r.stderr[-800:]
    return d / 'm'


def run(exe, state, homed, trusted, s=0):
    out = subprocess.run([str(exe), str(state), str(homed), str(trusted), str(s)], capture_output=True, text=True).stdout.split()
    return dict(x.split('=') for x in out)


PATCHED, _ = M9.transform(OEM)
STOPPED, RUNNING = 1, 3


class RealM999(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.p = build(PATCHED); cls.o = build(OEM)

    def test_C901_a_restart_from_the_stopped_state_unhomes_and_untrusts_all_axes_and_reports_it(self):
        r = run(self.p, STOPPED, 7, 7, 0); self.assertEqual((r['state'], r['homed'], r['trusted'], r['msg']), (str(RUNNING), '0', '0', '1')); self.assertEqual((r['flushes'], r['alerts']), ('1', '1'), 'der OEM-Neustart (Alarm zuruecksetzen, Resend anfordern) bleibt erhalten')

    def test_C902_m999_s1_after_a_stop_unhomes_too_and_still_does_not_flush_like_the_oem(self):
        r = run(self.p, STOPPED, 7, 7, 1); self.assertEqual((r['homed'], r['trusted'], r['flushes'], r['msg']), ('0', '0', '0', '1'), 'S1 = ohne Puffer-Flush bleibt; aber auch S1 erzeugt keine Freigabe')

    def test_C903_m999_outside_the_stopped_state_is_unchanged(self):
        for s in (0, 1):
            r = run(self.p, RUNNING, 7, 7, s); self.assertEqual((r['homed'], r['trusted'], r['msg'], r['flushes']), ('7', '7', '0', '0' if s else '1'))

    def test_C904_exhaustive_all_homed_and_trusted_combinations_with_and_without_s(self):
        for h in range(8):
            for t in range(8):
                for s in (0, 1):
                    a = run(self.p, STOPPED, h, t, s); b = run(self.p, RUNNING, h, t, s); self.assertEqual((a['homed'], a['trusted']), ('0', '0'), (h, t, s)); self.assertEqual((b['homed'], b['trusted']), (str(h), str(t)), (h, t, s))

    def test_C905_the_patch_does_not_touch_the_oem_restart_semantics_everything_else_is_identical_to_the_original(self):
        for st in (STOPPED, RUNNING):
            for s in (0, 1):
                a, o = run(self.p, st, 7, 7, s), run(self.o, st, 7, 7, s)
                for k in ('state', 'flushes', 'alerts'): self.assertEqual(a[k], o[k], (st, s, k))

    def test_C906_with_the_switch_off_the_behaviour_equals_the_oem(self):
        off = build(PATCHED, ['SV04_CLAUDE_M999_REHOME_REQUIRED=0']); r = run(off, STOPPED, 7, 7, 0); self.assertEqual((r['homed'], r['trusted'], r['msg']), ('7', '7', '0'))

    def test_C907_negative_control_the_unpatched_oem_keeps_all_axes_homed_and_trusted_after_a_stop_and_m999(self):
        r = run(self.o, STOPPED, 7, 7, 0); self.assertEqual((r['homed'], r['trusted']), ('7', '7'), 'LUECKE des OEM: nach stop() + M999 gelten X/Y/Z weiter als referenziert und vertrauenswuerdig')


class Patch(unittest.TestCase):
    def test_C908_the_patch_is_pinned_idempotent_refuses_foreign_files_and_adds_15_lines(self):
        self.assertEqual(hashlib.sha256(OEM).hexdigest(), M9.PIN_OEM_M999); n, ch = M9.transform(OEM); self.assertTrue(ch); self.assertEqual(M9.transform(n), (n, False)); self.assertEqual(len(n.splitlines()) - len(OEM.splitlines()), 15)
        for bad in (OEM + b'\n', n.replace(b'SV04_CLAUDE_M999_REHOME_REQUIRED 1', b'SV04_CLAUDE_M999_REHOME_REQUIRED 2')):
            with self.assertRaises(ValueError): M9.transform(bad)
        w = Path(tempfile.mkdtemp()); (w / 'Marlin/src/gcode/control').mkdir(parents=True); (w / M9.TARGET).write_bytes(OEM)
        r = subprocess.run([sys.executable, '-B', str(CLAUDE / '03_PATCHES/apply_m999_reset_c9.py'), str(w)], capture_output=True, text=True); self.assertEqual(r.returncode, 0); self.assertIn('M999_C9=PATCHED', r.stdout)
        r = subprocess.run([sys.executable, '-B', str(CLAUDE / '03_PATCHES/apply_m999_reset_c9.py'), str(w)], capture_output=True, text=True); self.assertIn('ALREADY_PATCHED', r.stdout)
        (w / M9.TARGET).write_bytes(OEM + b'\n'); b = (w / M9.TARGET).read_bytes(); r = subprocess.run([sys.executable, '-B', str(CLAUDE / '03_PATCHES/apply_m999_reset_c9.py'), str(w)], capture_output=True, text=True); self.assertNotEqual(r.returncode, 0); self.assertEqual((w / M9.TARGET).read_bytes(), b, 'nichts geschrieben')

    def test_C909_every_mutant_of_the_patch_is_detected_by_the_real_code_tests(self):
        muts = [('M1 Zuruecksetzen auch ausserhalb des Stopp-Zustands', 'if (sv04c9_was_stopped) {', 'if (true) {'),
                ('M2 nur homed, trusted bleibt', 'set_all_unhomed();', 'axis_homed = 0;'),
                ('M3 Stopp-Zustand wird erst NACH dem Zustandswechsel gelesen', '    const bool sv04c9_was_stopped = IsStopped();\n  #endif\n  marlin_state = MF_RUNNING;', '  #endif\n  marlin_state = MF_RUNNING;\n  const bool sv04c9_was_stopped = IsStopped();'),
                ('M4 S1 umgeht das Zuruecksetzen', '    if (sv04c9_was_stopped) {', '    if (sv04c9_was_stopped && !parser.boolval(\'S\')) {'),
                ('M5 keine Meldung', 'SERIAL_ECHO_MSG("SV04 C9: restart after STOPPED state, axes are now UNHOMED', 'SERIAL_ECHO_MSG("restart after STOPPED state, axes are now unhomed'),
                ('M6 Zuruecksetzen nur wenn homed != 0 (Sonderfall)', 'set_all_unhomed();', 'if (axis_homed) set_all_unhomed();'),
                ('M7 OEM-Neustart (Alarm) geht verloren', '  marlin_state = MF_RUNNING;\n  ui.reset_alert_level();\n  #if SV04', '  marlin_state = MF_RUNNING;\n  #if SV04')]
        txt = PATCHED.decode(); miss = []; ref = build(PATCHED)
        space = [(st, h, t, s) for st in (STOPPED, RUNNING) for h in range(8) for t in range(8) for s in (0, 1)]           # ALLE 256 Kombinationen
        reference = {k: run(ref, *k) for k in space}
        for name, a, b in muts:
            self.assertEqual(txt.count(a), 1, name); exe = build(txt.replace(a, b).encode())
            if all(run(exe, *k) == reference[k] for k in space): miss.append(name)
        self.assertTrue(reference[(STOPPED, 7, 7, 0)]['homed'] == '0', 'die Referenz selbst ist wirksam')
        self.assertEqual(miss, [], 'Mutanten, die kein Test bemerkt')


class Composition(unittest.TestCase):
    GATE = ['SV04_CLAUDE_AUTO60_REQUIRE_Z_KNOWN=1']

    def test_C910_after_a_bltouch_stop_in_the_g29_a_plain_restart_must_not_allow_auto60_but_a_manual_rehome_does(self):
        gap = E.run('homed=all', 'stop_at_probe=5', 'rerun=1', 'limit_s=1200', 'm999=2', name='c9g', defines=self.GATE)
        self.assertEqual(gap['RESULT1'], 'state=FAILED reason=MARLIN_STOPPED'); self.assertNotIn('PRE_Z_UNKNOWN', gap['SERIAL'], 'MODELL des OEM: nach stop()+M999 startet Auto60 sofort erneut (Z gilt weiter als bekannt)')
        fix = E.run('homed=all', 'stop_at_probe=5', 'rerun=1', 'limit_s=1200', 'm999=2', 'm999_c9=1', name='c9g', defines=self.GATE)
        self.assertEqual(fix['RESULT1'], 'state=FAILED reason=MARLIN_STOPPED'); self.assertIn('Auto60 refused: PRE_Z_UNKNOWN', fix['SERIAL'], 'MODELL des gepatchten M999 (Semantik von C901 an der echten M999.cpp belegt): Neustart allein genuegt nicht')
        again = E.run('homed=all', name='c9g', defines=self.GATE); self.assertEqual((again['state'], again['reason']), ('SUCCESS', 'VERIFIED'), 'nach erneuter Referenzierung (Z bekannt) startet Auto60 wieder, die Pruefung erfolgt vollstaendig neu')


class RealChain(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import test_toolchange_c2 as TC
        TC.PatchAndHarness.setUpClass(); cls.h = TC.PatchAndHarness('test_T03_the_patch_script_pins_the_real_t_cpp_is_idempotent_and_refuses_everything_else'); cls.m = RealM999; RealM999.setUpClass()

    def test_C911_real_m999_into_real_t_cpp_after_a_stop_and_restart_a_t1_is_refused_without_the_patch_it_would_reach_tool_change(self):
        """Verkettung zweier ECHTER OEM-Dateien: die Achszustaende, die M999.cpp nach einem Stopp liefert, entscheiden in der echten T.cpp ueber T1 (X referenziert = Bit 0)."""
        for variant, exe, expect_called in (('OEM-M999 (Luecke)', RealM999.o, '1'), ('C9-M999', RealM999.p, None)):
            r = run(exe, STOPPED, 7, 7, 0); hm, tr = int(r['homed']) & 1, int(r['trusted']) & 1
            out = self.h.run_h('patched', 1, 0, 0, hm, tr, 0)
            if expect_called: self.assertIn('CALLED=' + expect_called, out, variant + ': X gilt nach stop()+M999 weiter als vertrauenswuerdig, T1 wird an tool_change() gereicht')
            else: self.assertIn('abgelehnt', out, variant); self.assertIn('CALLED=0', out, 'T1 erreicht tool_change() nie')
        self.assertIn('CALLED=1', self.h.run_h('patched', 1, 0, 0, 1, 1, 0), 'Gegenprobe: bei referenziertem, vertrauenswuerdigem X bleibt T1 erlaubt (OEM-Funktion erhalten)')


if __name__ == '__main__':
    unittest.main(verbosity=2)
