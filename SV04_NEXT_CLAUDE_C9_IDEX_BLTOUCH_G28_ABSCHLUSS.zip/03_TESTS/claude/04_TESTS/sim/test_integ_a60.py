"""INTEGRATION (Block 2): PRODUKTIONS-Backend (kein Test-Double) + ECHTER G28 (276 + Stufe 1 + Waechter) + ECHTE G29 (mit dem OEM-Endskript "G28 XY" als echtem G28-Lauf) + echter Adapter/Koordinator
+ echte RTS_SndData. Host-Simulation: Thermik, Queue, EEPROM-Modell und homeaxis()-Modell sind Stubs (OEM-Reihenfolge); KEIN STM32, KEINE Hardware."""
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import build_sim_a60 as B  # noqa: E402
import chain_tree as T  # noqa: E402

_S = {}
OLD_HMI_SCALE = 1000


def exe(name='integ', defines=('SIM_P1_277',)):
    k = (name, tuple(defines))
    if k not in _S:
        _S.setdefault('work', Path(tempfile.mkdtemp(prefix='integ_w_')))
        _S[k] = B.build_integ(T.shared()['integ'], name, list(defines), _S['work'])
    return _S[k]


def run(*a, name='integ', defines=('SIM_P1_277',)):
    r = B.scenario(exe(name, defines), *a)
    r['t'] = [c.strip() for c in r.get('CMDS', '').split(';') if c.strip()]
    r['state'] = r['RESULT'].split()[0].split('=')[1]
    r['reason'] = r['RESULT'].split()[1].split('=')[1] if len(r['RESULT'].split()) > 1 else ''
    r['ee'] = {k: int(v) for k, v in (kv.split('=') for kv in r.get('EE', '').split() if '=' in kv and kv.split('=')[1].lstrip('-').isdigit())}
    r['ax'] = dict(kv.split('=') for kv in r.get('AXES', '').split() if '=' in kv)
    r['p1'] = dict(kv.split('=') for kv in r.get('P1RESULT', '').split() if '=' in kv)
    return r


def has(r, s): return s in r['t']
def count(r, s): return sum(1 for c in r['t'] if c == s)
def idx(r, s): return r['t'].index(s)


class Integration(unittest.TestCase):
    def eeprom_untouched(self, r, why=''):
        self.assertEqual((r['ee']['saves'], r['ee']['bytes'], r['ee']['header_ok'], r['ee']['mesh_changed'], r['ee']['zoff_changed']), (0, 0, 1, 0, 0), why + ': EEPROM unberuehrt')
        self.assertEqual(r['COUNTS'].split()[2], 'settings_save=0', why)

    # ---------------------------------------------------------------- Erfolgspfad und Bindung
    def test_I01_full_chain_with_production_backend_real_g28_real_g29_and_g28_xy_end_script(self):
        r = run('homed=none')
        self.assertEqual((r['state'], r['reason']), ('SUCCESS', 'VERIFIED'))
        self.assertEqual(r['STALE'], '0', 'keine doppelten/veralteten Rueckmeldungen')
        self.assertEqual(count(r, 'exec G28 X Y Z'), 1)
        self.assertLess(idx(r, 'exec G28 X Y Z'), idx(r, 'exec G29'))
        self.assertLess(idx(r, 'homeaxis Z T0'), idx(r, 'exec G29'), 'Z-Referenz VOR der Messung')
        self.assertEqual(count(r, 'gcode:G28 XY'), 1, 'das OEM-Endskript wurde ausgefuehrt')
        self.assertEqual(r['p1']['seq'], '2', 'zwei G28: die Anforderung und das G29-Endskript')
        self.assertEqual((r['ax']['homed'], r['ax']['trusted'], r['ax']['active_ext']), ('7', '7', '0'))
        self.assertEqual(r['ee']['saves'], 1)
        self.assertEqual(r['RAM'].split()[0], 'zoff_unchanged=1')
        self.assertEqual((r['HMIPAGE'], r['HMIBAD']), ('22', '0'))
        self.assertEqual(r['LOG'].split()[2], 'STABILIZING>HOMING_PENDING(HEAT_STABLE)')

    def test_I02_exactly_one_g28_request_and_the_request_is_the_full_form(self):
        r = run('homed=none')
        self.assertEqual([c for c in r['t'] if c.startswith('exec G28')], ['exec G28 X Y Z'])

    # ---------------------------------------------------------------- G28-Fehler mit echtem G28
    def home_failure(self, *opt, reason='HOME_FAILED'):
        r = run('homed=none', *opt)
        self.assertEqual((r['state'], r['reason']), ('FAILED', reason), str(opt))
        self.assertFalse(has(r, 'exec G29'), str(opt) + ': keine G29 ohne bestaetigtes Homing')
        self.eeprom_untouched(r, str(opt))
        self.assertEqual(r['STALE'], '0', str(opt))
        self.assertEqual(r['RAM'].split()[0], 'zoff_unchanged=1')
        self.assertEqual(r['RAM'].split()[2], 'bed_target=0', 'Bett-Soll wiederhergestellt')
        self.assertNotEqual(r['HMIPAGE'], '22', 'kein "fertig"')
        return r

    def test_I03_t1_failure_the_t0_carriage_never_moves(self):
        r = self.home_failure('x_early_t1=1')
        self.assertEqual(r['HOMEAXIS'], 'count=1')
        self.assertEqual(r['p1']['ok'], '0')

    def test_I04_t0_failure_stops_before_y_and_z(self):
        r = self.home_failure('x_early_t0=1')
        self.assertEqual(r['HOMEAXIS'], 'count=2')
        self.assertEqual(r['ax']['homed'], '0', 'X widerrufen, Y/Z nicht gefahren')

    def test_I05_bltouch_stow_alarm_does_not_leave_z_homed_and_never_starts_the_g29(self):
        r = self.home_failure('stow_fail=1')
        self.assertEqual(r['ax']['homed'], '3', 'Z widerrufen (Stufe 1)')

    def test_I06_bltouch_deploy_and_alarm_failures(self):
        self.home_failure('deploy_fail=1'); self.home_failure('bltouch_alarm=1')

    def test_I07_implausible_t1_reference_blocks_the_run(self):
        r = self.home_failure('hotend_x1=400')
        self.assertFalse(has(r, 'homeaxis Z T0'))

    def test_I08_endstop_miss_is_a_kill_nothing_runs_afterwards(self):
        for opt in ('kill_x_t1=1', 'kill_x_t0=1', 'kill_z=1'):
            r = run('homed=none', opt)
            self.assertEqual(r['state'], 'KILLED', opt)

    def test_I09_all_four_idex_modes(self):
        for mode in (0, 1):
            r = run('homed=none', 'mode=%d' % mode)
            self.assertEqual((r['state'], r['reason']), ('SUCCESS', 'VERIFIED'), 'Modus %d' % mode)
            self.assertEqual(r['ax']['mode'], str(mode))
        for mode in (2, 3):
            r = run('homed=none', 'mode=%d' % mode)
            self.assertEqual((r['state'], r['reason']), ('IDLE', 'NONE'), 'Modus %d' % mode)
            self.assertIn('Auto60 refused: PRE_IDEX_MODE', r['SERIAL'])
            self.assertEqual(r['HOMEAXIS'], 'count=0'); self.eeprom_untouched(r, 'Modus %d' % mode)

    # ---------------------------------------------------------------- G29-Endskript G28 XY
    def test_I10_g28_xy_end_script_failure_fails_the_run_rolls_the_mesh_back_and_never_saves(self):
        r = run('homed=none', 'x_t1_on_call=2')
        self.assertEqual((r['state'], r['reason']), ('FAILED', 'G29_ENDSCRIPT_FAILED'))
        self.eeprom_untouched(r)
        self.assertEqual(r['COUNTS'].split()[1], 'm420=%s' % r['COUNTS'].split()[1].split('=')[1])
        self.assertNotIn('ENABLING', r['LOG'])
        self.assertEqual(r['HMIl'] if 'HMIl' in r else r['HMI'], r['HMI0'], 'Display == altes Mesh')
        self.assertNotEqual(r['HMIPAGE'], '22')
        self.assertEqual(r['p1']['ok'], '0')

    def test_I11_end_script_runs_inside_the_g29_and_reports_one_result_per_g28(self):
        r = run('homed=none')
        self.assertEqual(r['p1']['seq'], '2')
        probes = [i for i, c in enumerate(r['t']) if c.startswith('probe_at_point')]
        self.assertGreater(idx(r, 'gcode:G28 XY'), probes[-1])

    # ---------------------------------------------------------------- Queue, Timeout, SID, Wiederholung
    def test_I12_short_queue_delay_is_tolerated(self):
        r = run('homed=none', 'queue_stall=1', 'queue_release_s=40', 'limit_s=300')
        self.assertEqual((r['state'], r['reason']), ('SUCCESS', 'VERIFIED'))

    def test_I13_queue_that_never_starts_the_g28_fails_once_and_the_late_g28_is_refused_without_motion(self):
        r = run('homed=none', 'queue_stall=1', 'queue_release_s=80', 'tail_s=100', 'limit_s=300')
        self.assertEqual((r['state'], r['reason']), ('FAILED', 'HOME_FAILED'))
        self.assertEqual(r['HOMEAXIS'], 'count=0', 'das verspaetete G28 der verworfenen Anforderung fuehrt KEINE Bewegung aus')
        self.assertEqual(r['p1']['seq'], '0', 'verweigert, bevor der P1-Waechter existiert')
        self.assertTrue(has(r, 'exec G28 X Y Z'), 'das G28 WURDE aus der Queue ausgefuehrt (spaet), aber verweigert')
        self.eeprom_untouched(r); self.assertEqual(r['STALE'], '0')

    def test_I14_cancel_while_the_g28_is_only_queued_discards_it_and_it_never_moves(self):
        r = run('homed=none', 'queue_stall=1', 'queue_release_s=60', 'cancel_at=HOMING_PENDING', 'tail_s=60', 'limit_s=200')
        self.assertEqual((r['state'], r['reason']), ('CANCELLED', 'CANCEL_AFTER_STEP'))
        self.assertEqual(r['HOMEAXIS'], 'count=0'); self.assertFalse(has(r, 'exec G29')); self.eeprom_untouched(r)
        self.assertTrue(has(r, 'exec G28 X Y Z'), 'das eingestellte G28 lief spaeter aus der Queue und wurde verweigert')

    def test_I15_foreign_g28_while_armed_invalidates_the_request(self):
        r = run('homed=none', 'queue_stall=1', 'queue_release_s=100', 'foreign_g28_exec_s=40', 'tail_s=120', 'limit_s=400')
        self.assertEqual((r['state'], r['reason']), ('FAILED', 'HOME_FAILED'))
        self.assertTrue(has(r, 'exec G28 X (Anwender)'))
        self.assertEqual(r['HOMEAXIS'], 'count=2', 'nur das G28 X des Anwenders (T1, T0) bewegt; die Anforderung wurde verworfen')
        self.assertFalse(has(r, 'exec G29')); self.eeprom_untouched(r)

    def test_I16_print_starts_before_the_queued_g28_runs_it_is_refused(self):
        r = run('homed=none', 'queue_stall=1', 'queue_release_s=45', 'printing_at_s=40', 'tail_s=20', 'limit_s=200')
        self.assertEqual((r['state'], r['reason']), ('FAILED', 'HOME_FAILED')); self.assertTrue(has(r, 'exec G28 X Y Z')); self.assertEqual(r['HOMEAXIS'], 'count=0', 'Druck vor der Ausfuehrung: G28 verweigert, keine Bewegung'); self.assertFalse(has(r, 'exec G29')); self.eeprom_untouched(r)

    def test_I17_print_starts_while_the_g28_runs_no_g29_follows(self):
        r = run('homed=none', 'print_after_homeaxis=2')
        self.assertEqual((r['state'], r['reason']), ('FAILED', 'PRE_PRINTING')); self.assertFalse(has(r, 'exec G29')); self.eeprom_untouched(r); self.assertEqual(r['STALE'], '0')

    def test_I18_temperature_excursion_while_homing_the_result_is_not_forwarded_again(self):
        r = run('homed=none', 'kick_after_homeaxis=2', 'kick=40')
        self.assertEqual((r['state'], r['reason']), ('FAILED', 'TEMP_EXCURSION'))
        self.assertFalse(has(r, 'exec G29')); self.assertEqual(r['STALE'], '0', 'das spaete G28-Ergebnis wird nicht mehr weitergegeben'); self.eeprom_untouched(r)

    def test_I27_backend_request_is_not_reentrant_and_rejects_session_zero_and_foreign_sessions(self):
        r = run('homed=none', 'queue_stall=1', 'queue_release_s=48', 'request_again_s=40', 'limit_s=200')
        self.assertEqual(r['REQAGAIN'], 'same=0 zero=0 wrong=0', 'waehrend eine Anforderung eingestellt ist: Zweitaufruf, SID 0 und fremde SID werden abgelehnt')
        self.assertEqual(r['STALE'], '0'); self.assertEqual(count(r, 'exec G28 X Y Z'), 1, 'es wurde GENAU EIN G28 eingestellt')

    # ---------------------------------------------------------------- Abbruch / Touch
    def test_I19_touch_during_heating_cancels(self):
        r = run('homed=none', 'touch_at=HEATING')
        self.assertEqual((r['state'], r['reason']), ('CANCELLED', 'USER_CANCEL')); self.assertEqual(r['HOMEAXIS'], 'count=0'); self.eeprom_untouched(r)

    def test_I20_touch_during_the_running_g28_cancels_after_it_and_no_g29_follows(self):
        r = run('homed=none', 'touch_after_homeaxis=2')
        self.assertEqual((r['state'], r['reason']), ('CANCELLED', 'CANCEL_AFTER_STEP')); self.assertFalse(has(r, 'exec G29')); self.eeprom_untouched(r); self.assertEqual(r['p1']['ok'], '1')

    def test_I21_gcode_cancel_during_the_running_g28_behaves_the_same(self):
        r = run('homed=none', 'cancel_after_homeaxis=2')
        self.assertEqual((r['state'], r['reason']), ('CANCELLED', 'CANCEL_AFTER_STEP')); self.assertFalse(has(r, 'exec G29')); self.eeprom_untouched(r)

    def test_I22_touch_during_the_g29_discards_the_new_mesh_and_shows_no_done_page(self):
        r = run('homed=none', 'touch_after_probe=6')
        self.assertEqual((r['state'], r['reason']), ('CANCELLED', 'CANCEL_AFTER_STEP')); self.eeprom_untouched(r)
        self.assertNotIn('ENABLING', r['LOG'])
        self.assertNotEqual(r['HMIPAGE'], '22'); self.assertEqual(r['HMI'], r['HMI0'], 'Display == altes Mesh')

    # ---------------------------------------------------------------- Fail-closed-Profil und manuelle Nutzung
    def test_I23_fail_closed_profile_refuses_auto60_and_manual_g28_still_works(self):
        d = ('SIM_P1_277', 'SV04_CLAUDE_HOME_BACKEND_AVAILABLE=0')
        r = run('homed=none', name='nobackend', defines=d)
        self.assertEqual((r['state'], r['reason']), ('IDLE', 'NONE')); self.assertIn('Auto60 refused: PRE_HOME_BACKEND_MISSING', r['SERIAL']); self.assertEqual(r['HOMEAXIS'], 'count=0')
        m = run('homed=none', 'manual_g28=1', name='nobackend', defines=d)
        self.assertEqual((m['state'], m['ax']['homed'], m['p1']['ok']), ('IDLE', '7', '1'))

    def test_I24_manual_g28_in_the_production_build_is_normal_and_does_not_touch_auto60_or_the_eeprom(self):
        r = run('homed=none', 'manual_g28=1')
        self.assertEqual((r['state'], r['ax']['homed'], r['p1']['ok'], r['p1']['seq']), ('IDLE', '7', '1', '1'))
        self.assertEqual(r['STALE'], '0'); self.eeprom_untouched(r); self.assertFalse(has(r, 'exec G29'))

    def test_I25_every_failure_and_cancel_keeps_eeprom_zoffset_and_display_consistent(self):
        n = 0
        for opt in (['x_early_t1=1'], ['x_early_t0=1'], ['stow_fail=1'], ['deploy_fail=1'], ['x_t1_on_call=2'], ['touch_after_homeaxis=2'], ['touch_after_probe=6'], ['kick_after_homeaxis=2', 'kick=40'], ['print_after_homeaxis=2'], ['hotend_x1=400'], ['nan_at=9'], ['val_at=5', 'val=12']):
            r = run('homed=none', *opt)
            self.assertNotEqual(r['state'], 'SUCCESS', str(opt)); self.eeprom_untouched(r, str(opt)); self.assertEqual(r['RAM'].split()[0], 'zoff_unchanged=1', str(opt)); self.assertNotEqual(r['HMIPAGE'], '22', str(opt)); n += 1
        self.assertEqual(n, 12)

    def test_I26_g29_failures_after_the_real_homing_roll_the_mesh_back(self):
        for opt in (['nan_at=9'], ['val_at=5', 'val=12'], ['val_at=5', 'val=45']):
            r = run('homed=none', *opt)
            self.assertEqual(r['state'], 'FAILED', str(opt)); self.eeprom_untouched(r, str(opt)); self.assertEqual(r['HMI'], r['HMI0'], str(opt) + ': Display == altes Mesh')


if __name__ == '__main__':
    unittest.main(verbosity=2)
