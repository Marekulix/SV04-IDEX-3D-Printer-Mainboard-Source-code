#!/usr/bin/env python3
"""Erzeugt aus dem ECHTEN OEM-bedlevel.cpp die Funktionen leveling_is_valid / set_bed_leveling_enabled / reset_bed_level, wie sie im zusammengefuehrten Stand laufen:
  --variant oem   : unveraendert (Kontrolle)
  --variant v2v4  : nach m420/apply_m420_guard_v2.py UND dem bedlevel-Teil von m420/apply_m420_v4.py (ChatGPTs eigene Skripte, ueber deren Konstanten und Ankerpruefung; nichts nachgeschrieben)
Die Funktionen werden WOERTLICH extrahiert (wie extract_p1_a60.py fuer die P1-Bloecke) und in die Simulation eingehaengt (SIM_REAL_BEDLEVEL). Aufruf: extract_bedlevel_a60.py --bedlevel OEM/bedlevel.cpp --m420-dir m420 --variant v2v4 --out bedlevel_real.inc"""
import argparse
import importlib.util
import shutil
import sys
import tempfile
from pathlib import Path

FUNCS = ('bool leveling_is_valid()', 'void set_bed_leveling_enabled(', 'void reset_bed_level()')


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def patched_text(bedlevel, m420_dir, variant):
    text = Path(bedlevel).read_text(encoding='utf-8')
    if variant == 'oem':
        return text
    m420_dir = Path(m420_dir)
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        p = root / 'Marlin/src/feature/bedlevel/bedlevel.cpp'
        p.parent.mkdir(parents=True)
        p.write_text(text, encoding='utf-8')
        load(m420_dir / 'apply_m420_guard_v2.py', 'guard_v2').apply(root)                      # V2: leveling_is_valid() (endliche Werte, Geometrie)
        v4 = load(m420_dir / 'apply_m420_v4.py', 'm420_v4')
        bs = p.read_text(encoding='utf-8')                                                    # V4, bedlevel-Haelfte (die M420-Haelfte braucht M420.cpp, das hier nicht vorliegt)
        bs = v4.replace_once(bs, v4.SETTER_ANCHOR, v4.SETTER_REPLACEMENT, 'bedlevel setter')
        bs = v4.replace_once(bs, v4.CORE_ANCHOR, v4.CORE_REPLACEMENT, 'bedlevel include')
        return bs


def extract(text, start):
    lines = text.split('\n')
    for i, l in enumerate(lines):
        if l.startswith(start):
            j = i
            while not lines[j].startswith('}'):
                j += 1
            return '\n'.join(lines[i:j + 1])
    raise SystemExit('Funktion nicht gefunden: ' + start)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--bedlevel', required=True)
    ap.add_argument('--m420-dir', required=True)
    ap.add_argument('--variant', choices=('oem', 'v2v4'), required=True)
    ap.add_argument('--out', required=True)
    a = ap.parse_args(argv)
    text = patched_text(a.bedlevel, a.m420_dir, a.variant)
    body = '\n\n'.join(extract(text, f) for f in FUNCS)
    Path(a.out).write_text('// GENERIERT aus dem echten OEM-bedlevel.cpp, Variante %s. NICHT von Hand aendern.\n%s\n' % (a.variant, body), encoding='utf-8')
    print('bedlevel_real (%s): %d Zeilen' % (a.variant, body.count('\n') + 1))
    return 0


if __name__ == '__main__':
    sys.exit(main())
