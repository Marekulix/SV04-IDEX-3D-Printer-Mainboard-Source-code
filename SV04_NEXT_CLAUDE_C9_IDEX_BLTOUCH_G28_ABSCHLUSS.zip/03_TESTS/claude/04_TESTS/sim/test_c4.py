"""C4: Startfreigabe fuer Auto60 und Abbruch bei Marlin-Stopp (BLTouch deploy/stow -> stop()). Host-Simulation, KEIN STM32-Build, KEINE Hardware.
 Auftragsfaelle (Abschnitt 4): 6 BLTouch ohne/mit fehlerhaftem Signal -> ST01/ST03; 8 Abbruch waehrend der Referenzfahrt -> ST05; 9 erneuter Start nach einem Fehler -> ST01/ST02/ST04; 10 Startfreigabe -> ST01/ST02/ST06."""
import re
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import test_ee_a60 as E  # noqa: E402

REAL = ['SIM_REAL_BEDLEVEL=v2v4']
PRE70 = ['target0=70', 'bed0=70']


def t(r): return [c.strip() for c in r.get('CMDS', '').split(';') if c.strip()]
def heat_after_stop(r):
    tr = t(r); i = next((k for k, c in enumerate(tr) if c.startswith('stop()')), None)
    return None if i is None else [c for c in tr[i + 1:] if c.startswith('bed_target')]


class StartRelease(unittest.TestCase):
    def test_ST01_after_a_bltouch_alarm_the_next_auto60_start_is_refused_with_the_right_reason_and_nothing_heats(self):
        r = E.run('homed=none', 'bltouch_alarm=1', 'rerun=1', 'limit_s=1200', *PRE70)
        self.assertEqual(r['RESULT1'], 'state=FAILED reason=HOME_FAILED')
        self.assertIn('Auto60 refused: MARLIN_STOPPED', r['SERIAL']); self.assertNotIn('HEAT_TARGET_CHANGED', r['RESULT'], 'kein irrefuehrender Folgefehler mehr')
        self.assertEqual((r['state'], r['reason']), ('FAILED', 'HOME_FAILED'), 'der zweite Start hat keine neue Sitzung begonnen'); self.assertEqual(heat_after_stop(r), [], 'nach stop() kein einziger Heizbefehl')

    def test_ST02_after_m999_and_a_repaired_sensor_auto60_starts_again_and_succeeds(self):
        r = E.run('homed=none', 'bltouch_alarm=1', 'rerun=1', 'limit_s=1200', 'm999=2')
        self.assertEqual(r['RESULT1'], 'state=FAILED reason=HOME_FAILED'); self.assertEqual((r['state'], r['reason']), ('SUCCESS', 'VERIFIED'), 'Wiederaufnahme: M999 + repariert + neuer Lauf')

    def test_ST03_a_stop_in_the_middle_of_the_g29_ends_auto60_with_the_right_reason_and_stops_the_measurement(self):
        base = E.run('homed=none', name='bl_g29', defines=REAL); n_base = len([c for c in t(base) if c.startswith('probe_at_point')]); h_base = len([c for c in t(base) if c.startswith('homeaxis')])
        r = E.run('homed=none', 'stop_at_probe=5', *PRE70, name='bl_g29', defines=REAL); tr = t(r)
        self.assertEqual((r['state'], r['reason']), ('FAILED', 'MARLIN_STOPPED')); self.assertEqual(n_base, 16)
        self.assertLessEqual(len([c for c in tr if c.startswith('probe_at_point')]), 6, 'hoechstens der laufende Messpunkt wird noch fertig (Abbruch an der naechsten sicheren Stelle)')
        self.assertLess(len([c for c in tr if c.startswith('homeaxis')]), h_base, 'das Endskript G28 XY wird NICHT mehr gefahren'); self.assertEqual(r['EEBYTES_CHANGED_VS_START'], '0', 'EEPROM unberuehrt'); self.assertEqual(heat_after_stop(r), [])

    def test_ST04_a_stop_never_lets_a_second_session_start_before_m999(self):
        r = E.run('homed=none', 'stop_at_probe=5', 'rerun=1', 'limit_s=1200', *PRE70, name='bl_g29', defines=REAL)
        self.assertEqual(r['RESULT1'], 'state=FAILED reason=MARLIN_STOPPED'); self.assertIn('Auto60 refused: MARLIN_STOPPED', r['SERIAL'])

    def test_ST05_a_touch_abort_during_the_homing_run_still_ends_cancelled_and_is_unaffected_by_the_stop_check(self):
        r = E.run('homed=none', 'touch_after_homeaxis=2', 'limit_s=900')
        self.assertEqual(r['state'], 'CANCELLED')

    def test_ST06_without_a_stop_the_start_release_changes_nothing_cold_start_succeeds(self):
        for args in (['homed=none'], ['homed=none', 'target0=70', 'bed0=70'], ['homed=none', 'rerun=1', 'limit_s=1200']):
            r = E.run(*args); self.assertEqual((r['state'], r['reason']), ('SUCCESS', 'VERIFIED'), str(args))

    def test_ST07_after_a_t1_homing_failure_the_restart_is_refused_because_t1_stays_active_until_g28_recovers_it(self):
        r = E.run('homed=none', 'x_early_t1=1', 'rerun=1', 'limit_s=1200')
        self.assertEqual(r['RESULT1'], 'state=FAILED reason=HOME_FAILED'); self.assertIn('Auto60 refused: PRE_WRONG_EXTRUDER', r['SERIAL'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
