"""Reproduzierbare Pipeline fuer ALLE Tests: fuehrt die ECHTEN Patchskripte (268, 272, 274, 275, 276 von ChatGPT, unveraendert; dann 277 Stufe 1 und Stufe 2) auf den OEM-Dateien aus.
Stand 276 = OEM + 268..276 | Stand p1 = 276 + apply_277_p1.py | Stand integ = p1 + Claude-Overlay (G29/LCD/gcode/G28-Waechter + neue Dateien)."""
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
CLAUDE = HERE.parents[1]                  # .../claude
PKG = CLAUDE.parent                       # Paketwurzel mit apply_268.py ... apply_277_p1.py
OEM = CLAUDE / '01_BASELINE' / 'OEM_FILES' / 'Marlin' / 'src'
G28 = Path('Marlin/src/gcode/calibrate/G28.cpp')
MOTION = (Path('Marlin/src/module/motion.h'), Path('Marlin/src/module/motion.cpp'))
_CACHE = {}


def _run(args, cwd=None):
    r = subprocess.run([sys.executable, *map(str, args)], cwd=str(cwd or PKG), capture_output=True, text=True)
    if r.returncode:
        raise RuntimeError(' '.join(map(str, args)) + '\n' + r.stdout + r.stderr)
    return r.stdout


def tree276(dest):
    dest = Path(dest)
    if dest.exists():
        shutil.rmtree(dest)
    for rel in (G28, *MOTION):
        (dest / rel).parent.mkdir(parents=True, exist_ok=True)
        shutil.copy(OEM.parent.parent / rel, dest / rel)
    g = dest / G28
    _run(['apply_268.py', g, '--verify-oem', '--out', str(g) + '.p']); Path(str(g) + '.p').replace(g)
    _run(['apply_272.py', g, '--out', str(g) + '.p']); Path(str(g) + '.p').replace(g)
    _run(['apply_274.py', '--root', dest])
    _run(['apply_275.py', g])
    _run(['apply_276.py', '--root', dest])
    return dest


def tree_p1(dest):
    dest = tree276(dest)
    _run(['apply_277_p1.py', '--root', dest])
    return dest


def claude_out(p1_tree, out, source_root=None):
    """Stufe 2: Overlay auf die ECHTEN OEM-Dateien (G29/LCD/gcode) und den gehaerteten G28 -> out (nur geaenderte + neue Dateien)."""
    sys.path.insert(0, str(CLAUDE / '03_PATCHES'))
    import apply_claude_parallel as P
    out = Path(out)
    if out.exists():
        shutil.rmtree(out)
    P.run(OEM / 'lcd/e3v2/creality/LCD_RTS.cpp', OEM / 'gcode/bedlevel/abl/G29.cpp', OEM / 'gcode/gcode.cpp', out, source_root or (CLAUDE / '02_SOURCE'), g28=Path(p1_tree) / G28)
    return out


G29_CANCEL_V1_SHA256 = '0ec947ae3242d3e2a563dc8caa38d7979f082e88d66fccf5265e392c9b43a9f9'   # G29.cpp des ERFOLGREICH GEBAUTEN Stands 289 (Build-Log g29_cancel.txt)


def apply_g29_cancel_v1(tree):
    """289 "G29-CANCEL V1" (ChatGPT): 4 Hunks in G29.cpp. Der Patch ist aus dem Beleg-G29.cpp des Builds erzeugt; das Ergebnis MUSS bitgleich zu dessen Hash sein (sonst weicht die Simulation vom Build ab)."""
    import hashlib
    import subprocess
    g29 = Path(tree) / 'Marlin/src/gcode/bedlevel/abl/G29.cpp'
    r = subprocess.run(['patch', '-p1', '--no-backup-if-mismatch', '-d', str(tree), '-i', str(CLAUDE / '03_PATCHES' / 'g29_cancel_v1_289.patch')], capture_output=True, text=True)
    if r.returncode:
        raise RuntimeError('G29-CANCEL V1 nicht anwendbar: ' + r.stdout + r.stderr)
    got = hashlib.sha256(g29.read_bytes()).hexdigest()
    if got != G29_CANCEL_V1_SHA256:
        raise RuntimeError('G29.cpp nach V1 weicht vom 289-Build ab: ' + got)
    sys.path.insert(0, str(CLAUDE / '03_PATCHES'))
    import apply_g29_cancel_ext_290 as X
    t, changed = X.transform(g29.read_text(encoding='utf-8'))              # 290: Erweiterung ueber V1 (Pruefung vor dem Endskript)
    g29.write_text(t, encoding='utf-8')


def apply_g29_stopped_c5(full):
    """C5: die echte G29-Pruefung IsStopped() in die G29 des Simulationsbaums (die 309-Pruefsumme gilt dort nicht: V1+EXT statt Merge 299)."""
    import sys as _s
    _s.path.insert(0, str(Path(__file__).resolve().parents[2] / '03_PATCHES'))
    import apply_g29_stopped_c5 as G5
    g = Path(full) / 'Marlin/src/gcode/bedlevel/abl/G29.cpp'
    new, _ = G5.transform(g.read_bytes(), check_pin=False)
    g.write_bytes(new)
    (Path(full) / 'Marlin/src/MarlinCore.h').write_text('#pragma once\n// Simulationsattrappe: im echten Firmwarebaum liegt Marlin/src/MarlinCore.h; hier nur die Deklaration, die die G29-Pruefung braucht\nbool IsStopped();\nbool IsRunning();\n')


def integ(dest, source_root=None, g29_cancel=True):
    p1 = tree_p1(Path(dest) / 'p1')
    co = claude_out(p1, Path(dest) / 'claude_out', source_root)
    full = Path(dest) / 'integ'
    if full.exists():
        shutil.rmtree(full)
    shutil.copytree(p1, full)
    for f in co.rglob('*'):
        if f.is_file():
            t = full / f.relative_to(co)
            t.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy(f, t)
    if g29_cancel:
        apply_g29_cancel_v1(full)
        apply_g29_stopped_c5(full)
    return {'p1': p1, 'claude_out': co, 'integ': full}


def shared():
    """Einmal je Prozess: {'t276': ..., 'p1': ..., 'claude_out': ..., 'integ': ...}"""
    if 'all' not in _CACHE:
        base = Path(tempfile.mkdtemp(prefix='chain_'))
        d = integ(base)
        d['t276'] = tree276(base / 't276')
        _CACHE['all'] = d
    return _CACHE['all']
