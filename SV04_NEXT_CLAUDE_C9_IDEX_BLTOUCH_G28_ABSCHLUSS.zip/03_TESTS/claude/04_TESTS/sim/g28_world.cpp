// WELT fuer die ECHTE G28.cpp (Stubs/Modelle, kein OEM-Code). Der Trust-Zustand ist wie im OEM bitweise; homeaxis() folgt der OEM-REIHENFOLGE (motion.cpp:1738-2075):
//   frueher Rueckkehr-Check -> probe.deploy() [Alarm = return] -> bltouch.deploy() [Alarm = return] -> Homing-Bewegungen (Endschalter nicht ausgeloest -> validate_homing_move() -> kill())
//   -> set_axis_is_at_home() [trusted + homed] -> probe.stow() [Alarm = return, NACH der Trust-Setzung] -> p1_tail.inc (WOERTLICH aus motion.cpp extrahiert).
#include "Marlin/src/inc/MarlinConfig.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
linear_axis_bits_t axis_homed = 0, axis_trusted = 0;
float inactive_extruder_x = X2_MAX_POS, current_position_x0_axis = X_MIN_POS, current_position_x1_axis = X2_MAX_POS, sim_hotend_offset_x1 = HOTEND_OFFSET_X_T1;
char save_dual_x_carriage_mode = 0;
bool active_extruder_parked = false;
xyze_pos_t destination;
xyz_pos_t home_offset;
SimEndstops endstops; SimBltouch bltouch;
extern void sim_dump_and_exit(const char *why);
extern uint32_t sim_ms; extern void (*sim_idle_hook)();      // vom Treiber: Zustand ausgeben und beenden (kill() kehrt nie zurueck)
#include "p1_defs.inc"                               // WOERTLICH aus dem gepatchten motion.cpp
float x_home_pos(const uint8_t extruder) { return extruder == 0 ? (float)X_HOME_POS : (sim_hotend_offset_x1 > 0 ? sim_hotend_offset_x1 : (float)X2_HOME_POS); }   // motion.cpp:1132-1141 (Formel)
#include "p1_plaus.inc"                              // WOERTLICH
bool idex_is_duplicating() { return dual_x_carriage_mode >= DXC_DUPLICATION_MODE; }
void idex_set_parked(const bool park) { active_extruder_parked = park; W.log(park ? "idex_set_parked(true)" : "idex_set_parked(false)"); }
void set_duplication_enabled(const bool dupe, const int8_t) { extruder_duplication_enabled = dupe; W.log(dupe ? "set_duplication_enabled(true)" : "set_duplication_enabled(false)"); }
void tool_change(const uint8_t t, bool no_move) { char b[48]; snprintf(b, sizeof b, "tool_change T%d move=%d", (int)t, no_move ? 0 : 1); W.log(b); if (!no_move) W.tool_changes++; active_extruder = t; }
void do_blocking_move_to_xy(const xy_pos_t &p, const float &) { sim_planner_guard(p.x, p.y); char b[64]; snprintf(b, sizeof b, "do_blocking_move_to_xy %.1f %.1f", (double)p.x, (double)p.y); W.log(b); }
bool position_is_reachable(const xy_pos_t &) { return true; }
void sim_lcd_message(const char *m) { W.log(std::string("lcd:") + m); }
void RTS_MoveAxisHoming() { W.log("RTS_MoveAxisHoming"); }
void SimBltouch::init() { W.log("bltouch.init"); }
linear_axis_bits_t axes_should_home(linear_axis_bits_t b) {               // motion.cpp:1318-1327 (HOME_AFTER_DEACTIVATE aus -> axis_was_homed)
  for (int a = 0; a < 3; a++) if (((b >> a) & 1) && axis_was_homed((AxisEnum)a)) b = (linear_axis_bits_t)(b & ~(1u << a));
  return b;
}
bool homing_needed_error(linear_axis_bits_t bits) {
  if ((bits = axes_should_home(bits))) { W.log("homing_needed_error"); sim_serial("Home first"); sim_serial_eol(); return true; }
  return false;
}
void set_axis_is_at_home(const AxisEnum axis) {                            // motion.cpp:2100-2125 (Wesentliches)
  set_axis_trusted(axis); set_axis_homed(axis);
  if (axis == X_AXIS && (active_extruder == 1 || dual_x_carriage_mode == DXC_DUPLICATION_MODE)) { current_position.x = x_home_pos(active_extruder); return; }
  current_position[axis] = axis == X_AXIS ? (float)X_HOME_POS : 0.0f;
}
void homeaxis(const AxisEnum axis) {
  sim_planner_guard();
  ++W.homeaxis_calls;
  sim_ms += W.homeaxis_ms; if (sim_idle_hook) sim_idle_hook();             // Homing dauert; waehrenddessen laeuft idle() (planner.synchronize) -> Auto60-Tick re-entrant
  char b[48]; snprintf(b, sizeof b, "homeaxis %c T%d", "XYZ"[(int)axis], (int)active_extruder); W.log(b);
  if (axis == X_AXIS && active_extruder == 1) ++W.x_t1_calls;
  if (axis == X_AXIS && active_extruder == 1 && (W.x_early_t1 || (W.x_t1_on_call && W.x_t1_calls == W.x_t1_on_call))) return;      // frueher return (Abschlussflag bleibt aus)
  if (axis == X_AXIS && active_extruder == 0 && W.x_early_t0) return;
  if (axis == Z_AXIS && probe.deploy()) return;                             // motion.cpp:1763: Alarm beim Ausfahren
  if (axis == Z_AXIS && W.bltouch_alarm) { W.log("bltouch.deploy ALARM"); sim_stop(); return; }   // motion.cpp:1780: "BLTouch was deployed above, but get the alarm state"
  const bool kill_here = (axis == X_AXIS && active_extruder == 1 && W.kill_x_t1) || (axis == X_AXIS && active_extruder == 0 && W.kill_x_t0) || (axis == Z_AXIS && W.kill_z) || (axis == Y_AXIS && W.kill_y);
  if (kill_here) { W.log("kill: homing failed"); sim_dump_and_exit("homing failed (validate_homing_move -> kill)"); }   // endstops.cpp:106-114 (Sovol-Variante): kill() kehrt NIE zurueck
  set_axis_is_at_home(axis);                                                // motion.cpp:2008/2028: VOR dem Sondenabbau
  if (axis == Z_AXIS && probe.stow()) return;                               // motion.cpp:2039: Alarm beim Einfahren, Trust bleibt gesetzt
  #include "p1_tail.inc"                                                    // WOERTLICH aus dem gepatchten motion.cpp
}
