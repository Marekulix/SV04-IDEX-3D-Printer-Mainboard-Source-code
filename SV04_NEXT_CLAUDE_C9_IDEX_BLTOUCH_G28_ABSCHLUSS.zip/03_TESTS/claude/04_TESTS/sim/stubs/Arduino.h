#pragma once
// SIM-Stub fuer <Arduino.h> (LCD_RTS.h bindet es ein). Nur was die echten Dateien brauchen.
#include <stdint.h>
#include <string.h>
#include <string>
class String {
  std::string s_;
 public:
  String() {}
  String(const char *c) : s_(c) {}
  unsigned length() const { return (unsigned)s_.size(); }
  const char *c_str() const { return s_.c_str(); }
};
inline void delay(unsigned long) {}
