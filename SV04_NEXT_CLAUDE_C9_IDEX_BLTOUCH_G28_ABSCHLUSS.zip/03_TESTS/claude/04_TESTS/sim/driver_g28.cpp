// G28-TREIBER: fuehrt die ECHTE gepatchte G28.cpp aus (GcodeSuite::G28) und gibt den vollstaendigen Zustand aus. Parameter: p=XYZ|O|... (G-Code-Buchstaben), Fehlerinjektion, Ausgangszustand.
#include "Marlin/src/inc/MarlinConfig.h"
#include "Marlin/src/feature/bedlevel/abl/abl.h"
#include <map>
#include <string>
#include <string.h>
static std::map<std::string, std::string> opt;
static std::string gs(const char *k, const char *d) { auto i = opt.find(k); return i == opt.end() ? d : i->second; }
static int gi(const char *k, int d) { auto i = opt.find(k); return i == opt.end() ? d : atoi(i->second.c_str()); }
static float gf(const char *k, float d) { auto i = opt.find(k); return i == opt.end() ? d : (float)atof(i->second.c_str()); }
static linear_axis_bits_t bits(const std::string &s) { linear_axis_bits_t b = 0; if (s == "all") return 7; for (char c : s) { if (c == 'X') b |= 1; if (c == 'Y') b |= 2; if (c == 'Z') b |= 4; } return b; }
static void dump(const char *tag) {
  printf("TAG %s\n", tag);
  #ifdef SIM_P1_277
  printf("RESULT seq=%u completed=%d ok=%d x_attempted=%d t1_ok=%d t0_ok=%d z_attempted=%d z_ok=%d\n", sv04_p1_g28_result.seq, sv04_p1_g28_result.completed, sv04_p1_g28_result.ok, sv04_p1_g28_result.x_attempted, sv04_p1_g28_result.t1_ok, sv04_p1_g28_result.t0_ok, sv04_p1_g28_result.z_attempted, sv04_p1_g28_result.z_ok);
  #else
  printf("RESULT none (Stand 276: kein exportierter G28-Ergebnisstatus)\n");
  #endif
  printf("AXES homed=%d trusted=%d\n", (int)axis_homed, (int)axis_trusted);
  printf("TOOL active=%d parked=%d dupl=%d mode=%d\n", (int)active_extruder, active_extruder_parked ? 1 : 0, extruder_duplication_enabled ? 1 : 0, (int)dual_x_carriage_mode);
  printf("LEV active=%d\n", planner.leveling_active ? 1 : 0);
  printf("COUNTS homeaxis=%d tool_changes=%d\n", W.homeaxis_calls, W.tool_changes);
  printf("TRACE"); for (auto &c : W.cmds) printf(" %s;", c.c_str()); printf("\nSERIAL"); for (auto &s : W.serial) printf(" [%s]", s.c_str()); printf("\n");
}
void sim_dump_and_exit(const char *why) { dump("KILLED"); printf("KILL %s\n", why); exit(0); }
int main(int argc, char **argv) {
  for (int i = 1; i < argc; i++) { std::string a = argv[i]; size_t e = a.find('='); if (e == std::string::npos) opt[a] = "1"; else opt[a.substr(0, e)] = a.substr(e + 1); }
  W.reset();
  axis_homed = bits(gs("homed", "all")); axis_trusted = bits(gs("trusted", gs("homed", "all").c_str()));
  active_extruder = (uint8_t)gi("tool", 0); dual_x_carriage_mode = (DualXMode)gi("mode", 1); extruder_duplication_enabled = gi("dupl", dual_x_carriage_mode >= 2 ? 1 : 0) != 0;
  sim_hotend_offset_x1 = gf("hotend_x1", 188.0f); inactive_extruder_x = gf("inactive_x", X2_MAX_POS); save_dual_x_carriage_mode = (char)gi("save_mode", 0); card.printing = gi("printing", 0) != 0;
  bilinear_grid_spacing.set(84, 84); bilinear_start.set(25, 25); bilinear_grid_factor = bilinear_grid_spacing.reciprocal(); planner.leveling_active = gi("lev0", 1) != 0;
  W.deploy_fail = gi("deploy_fail", 0); W.stow_fail = gi("stow_fail", 0); W.bltouch_alarm = gi("bltouch_alarm", 0); W.x_early_t1 = gi("x_early_t1", 0); W.x_early_t0 = gi("x_early_t0", 0);
  W.kill_x_t1 = gi("kill_x_t1", 0); W.kill_x_t0 = gi("kill_x_t0", 0); W.kill_z = gi("kill_z", 0); W.kill_y = gi("kill_y", 0);
  for (char c : gs("p", "")) W.params[c] = 1e30f;
  if (gi("x_t1_on_call", 0)) W.x_t1_on_call = gi("x_t1_on_call", 0);
  if (gi("stale_flags", 0)) { sv04_p1_t1_x_completed = sv04_p1_t0_x_completed = sv04_p1_z_completed = true; }   // veraltete Flags duerfen eine Z-Fahrt NICHT autorisieren
  const int n = gi("repeat", 1);
  for (int i = 0; i < n; i++) GcodeSuite::G28();
  dump("END");
  return 0;
}
