"""C2: Werkzeugwechsel-Schutz (T.cpp) und die Befunde aus dem ECHTEN OEM-Code (Commit 1867fcba). Host-Tests, KEIN STM32-Build, KEINE Hardware.
 T01-T02  reine Richtlinie: exhaustiv gegen ein unabhaengiges Orakel + 9 Mutanten
 T03      Patchskript gegen die ECHTE, per Git-Blob-SHA-1 gepinnte T.cpp (fail-closed)
 T04      ECHTE T.cpp (OEM bzw. gepatcht) im Harness: 96 Kombinationen, erlaubt == identisch zum OEM, abgelehnt erreicht tool_change nie
 T05      Verknuepfung mit den ECHTEN G28-Ergebnissen (1792 Faelle): bei nicht vertrauenswuerdigem X wird kein Wechsel erlaubt
 T06      Strukturfakten der echten Quellen, auf denen die Begruendung beruht (aendert sich der OEM-Code, muss die Begruendung neu geprueft werden)"""
import hashlib
import itertools
import json
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
CLAUDE = HERE.parents[1]
sys.path.insert(0, str(HERE)); sys.path.insert(0, str(CLAUDE / '03_PATCHES'))
import apply_toolchange_guard_c2 as A  # noqa: E402
import test_g28_a60 as G  # noqa: E402
import test_g28_matrix_305 as M  # noqa: E402

POLICY = CLAUDE / '02_SOURCE/Marlin/src/feature/sv04_claude_auto60/sv04_claude_toolchange_policy.h'
CORE_TEST = CLAUDE / '04_TESTS/core/test_toolchange_policy.cpp'
OEM = CLAUDE / '01_BASELINE/OEM_FILES/Marlin/src'
PINS = json.loads((CLAUDE / '01_BASELINE/OEM_SOURCE_GIT_BLOB_SHA1.json').read_text())
sha1 = lambda b: hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()


def build_core(policy_text=None, out='tcp'):
    d = Path(tempfile.mkdtemp())
    src = d / 'c'; (src / '02_SOURCE/Marlin/src/feature/sv04_claude_auto60').mkdir(parents=True); (src / '04_TESTS/core').mkdir(parents=True)
    (src / '02_SOURCE/Marlin/src/feature/sv04_claude_auto60/sv04_claude_toolchange_policy.h').write_text(policy_text if policy_text is not None else POLICY.read_text())
    shutil.copy(CORE_TEST, src / '04_TESTS/core/test_toolchange_policy.cpp')
    r = subprocess.run(['g++', '-std=c++11', '-O1', '-Wall', '-Wextra', '-Werror', '-pedantic', str(src / '04_TESTS/core/test_toolchange_policy.cpp'), '-o', str(d / out)], capture_output=True, text=True)
    return r.returncode, d / out, r.stderr


MUTANTS = [
    ('TM01 gleiches Werkzeug wird nicht mehr durchgelassen', '  if (in.tool == in.active)                   return TC_ALLOW_SAME_TOOL;     // kein Wechsel\n', ''),
    ('TM02 Auto60 laeuft: kein Schutz mehr', '  if (in.auto60_busy)                         return TC_REFUSE_AUTO60_BUSY;', '  if (false)                                  return TC_REFUSE_AUTO60_BUSY;'),
    ('TM03 X-Pruefung: homed ODER trusted genuegt', '!(in.x_homed && in.x_trusted)', '!(in.x_homed || in.x_trusted)'),
    ('TM04 X-Pruefung ignoriert "referenziert"', '!(in.x_homed && in.x_trusted)', '!in.x_trusted'),
    ('TM05 X-Pruefung ignoriert "vertrauenswuerdig"', '!(in.x_homed && in.x_trusted)', '!in.x_homed'),
    ('TM06 negatives Werkzeug wird nicht an die OEM-Fehlermeldung gereicht', 'if (in.tool < 0 || in.tool >= in.extruders)', 'if (in.tool >= in.extruders)'),
    ('TM07 Werkzeug == EXTRUDERS gilt als gueltig', 'in.tool >= in.extruders)', 'in.tool > in.extruders)'),
    ('TM08 tc_refused kennt Auto60 nicht', 'return v == TC_REFUSE_AUTO60_BUSY || v == TC_REFUSE_X_NOT_TRUSTED;', 'return v == TC_REFUSE_X_NOT_TRUSTED;'),
    ('TM09 keine Begruendung fuer die X-Ablehnung', 'return "X nicht referenziert oder nicht vertrauenswuerdig, erst G28";', 'return "";'),
]


class Policy(unittest.TestCase):
    def test_T01_the_pure_policy_matches_an_independent_oracle_in_all_336_cases(self):
        rc, exe, err = build_core(); self.assertEqual(rc, 0, err)
        out = subprocess.run([str(exe)], capture_output=True, text=True).stdout
        self.assertRegex(out, r'SUMMARY tests=\d+ pass=\d+ fail=0 \(Faelle im Orakelvergleich: 336\)')

    def test_T02_every_mutant_of_the_policy_is_caught(self):
        text = POLICY.read_text(); survivors = []
        for name, old, new in MUTANTS:
            self.assertEqual(text.count(old), 1, name + ': Anker')
            rc, exe, _ = build_core(text.replace(old, new))
            caught = rc != 0 or subprocess.run([str(exe)], capture_output=True, text=True).returncode != 0
            if not caught: survivors.append(name)
        self.assertEqual(survivors, [], 'ueberlebende Mutanten')


class PatchAndHarness(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = (OEM / 'gcode/control/T.cpp').read_bytes()
        cls.w = Path(tempfile.mkdtemp()); shutil.copytree(CLAUDE / '04_TESTS/t_harness', cls.w / 'h')
        cls.exe = {}
        for variant, defs in (('orig', []), ('patched', []), ('off', ['-DSV04_CLAUDE_TOOLCHANGE_GUARD=0'])):
            d = cls.w / 'h' / 'Marlin/src/gcode/control'
            d.mkdir(parents=True, exist_ok=True)                  # leere Verzeichnisse sind NICHT im ZIP
            out = cls.raw if variant == 'orig' else A.transform(cls.raw)[0]
            (d / 'T.cpp').write_bytes(out)
            for rel in ('feature/sv04_claude_auto60/sv04_claude_toolchange_policy.h', 'gcode/control/sv04_claude_toolchange_guard.h'):
                (cls.w / 'h/Marlin/src' / rel).parent.mkdir(parents=True, exist_ok=True); shutil.copy(CLAUDE / '02_SOURCE/Marlin/src' / rel, cls.w / 'h/Marlin/src' / rel)
            r = subprocess.run(['g++', '-std=c++11', '-O1', '-Wall', '-Wextra', '-Werror', '-I', str(cls.w / 'h'), '-I', str(d), str(cls.w / 'h/harness_T.cpp'), str(d / 'T.cpp'), '-o', str(cls.w / ('h_' + variant))] + defs, capture_output=True, text=True)
            assert r.returncode == 0, variant + ': ' + r.stderr
            cls.exe[variant] = cls.w / ('h_' + variant)

    def run_h(self, v, *a):
        return subprocess.run([str(self.exe[v])] + [str(x) for x in a], capture_output=True, text=True).stdout.strip().replace('\n', ' | ')

    def test_T03_the_patch_script_pins_the_real_t_cpp_is_idempotent_and_refuses_everything_else(self):
        self.assertEqual(sha1(self.raw), PINS['Marlin/src/gcode/control/T.cpp']); self.assertEqual(A.PIN_T_CPP, PINS['Marlin/src/gcode/control/T.cpp'])
        new, ch = A.transform(self.raw); self.assertTrue(ch); self.assertEqual(A.transform(new), (new, False))
        self.assertEqual(new.count(b'sv04c_t_allowed(tool_index)'), 1); self.assertEqual(len(new.splitlines()) - len(self.raw.splitlines()), 4, 'genau 4 neue Zeilen in der OEM-Datei')
        for bad in (self.raw + b'\n', self.raw.replace(b'reset_stepper_timeout();', b'reset_stepper_timeout() ;'), b'static int x;'):
            with self.assertRaises(ValueError): A.transform(bad)
        with self.assertRaises(ValueError): A.transform(new.replace(b'sv04_claude_toolchange_guard.h', b'x.h'))
        r = subprocess.run([sys.executable, '-B', str(CLAUDE / '03_PATCHES/apply_toolchange_guard_c2.py'), str(CLAUDE / 'x_nonexistent')], capture_output=True, text=True); self.assertNotEqual(r.returncode, 0)

    def test_T04_the_real_t_cpp_allowed_is_identical_to_oem_refused_never_reaches_tool_change(self):
        cli = build_core()[1]; cnt = {'identisch': 0, 'abgelehnt': 0}
        for tool, active, S, hm, tr, busy in itertools.product((0, 1, 2), (0, 1), (0, 1), (0, 1), (0, 1), (0, 1)):
            o, p, off = self.run_h('orig', tool, active, S, hm, tr, busy), self.run_h('patched', tool, active, S, hm, tr, busy), self.run_h('off', tool, active, S, hm, tr, busy)
            self.assertEqual(off, o, 'Guard AUS == OEM')
            v = int(subprocess.run([str(cli), 'cli'], input=f'{tool} {active} 2 {hm} {tr} {busy}\n', capture_output=True, text=True).stdout.strip())
            if v in (3, 4):
                self.assertIn('abgelehnt', p); self.assertIn('CALLED=0', p); self.assertIn('FONT=7', p, 'Font-Zustand unveraendert'); cnt['abgelehnt'] += 1
            else:
                self.assertEqual(p, o, f'tool={tool} active={active} S={S} hm={hm} tr={tr} busy={busy}'); cnt['identisch'] += 1
        self.assertEqual(cnt, {'identisch': 68, 'abgelehnt': 28})
        self.assertIn('CALLED=1', self.run_h('orig', 1, 0, 0, 1, 0, 0), 'OEM wuerde T1 bei nicht vertrauenswuerdigem X an tool_change() reichen')


class RealCode(unittest.TestCase):
    def test_T05_after_every_real_g28_outcome_the_policy_allows_a_switch_exactly_when_x_is_homed_and_trusted(self):
        cli = build_core()[1]; lines = []; meta = []
        for mode, tool, printing, (p, homed), (fname, fa), rep in itertools.product((0, 1, 2, 3), (0, 1), (0, 1), M.PAIRS, M.FAULTS.items(), (1, 2)):
            args = [f'p={p}', f'homed={homed}', f'mode={mode}', f'tool={tool}', f'printing={printing}', f'repeat={rep}'] + fa
            try: r = G.run('277', *args)
            except AssertionError: continue
            h, tr = int(r['axes']['homed']), int(r['axes']['trusted']); act = int(r['tool']['active'])
            lines.append(f'{1 - act} {act} 2 {h & 1} {(tr >> 0) & 1} 0'); meta.append((' '.join(args), h & 1, tr & 1))
        out = subprocess.run([str(cli), 'cli'], input='\n'.join(lines) + '\n', capture_output=True, text=True).stdout.split()
        self.assertEqual(len(out), len(lines)); self.assertGreater(len(out), 1700)
        bad = [(m[0], v) for m, v in zip(meta, out) if (int(v) in (3, 4)) != (not (m[1] and m[2]))]
        self.assertEqual(bad[:3], [], 'Richtlinie und G28-Ergebnis widersprechen sich')
        self.assertTrue(any(int(v) == 4 for v in out) and any(int(v) == 0 for v in out), 'beide Ausgaenge kommen vor (die Pruefung ist nicht trivial)')

    def test_T06_the_real_sources_still_contain_the_facts_the_rationale_rests_on(self):
        for rel, sha in PINS.items():
            self.assertEqual(sha1((CLAUDE / '01_BASELINE/OEM_FILES' / rel).read_bytes()), sha, rel)
        tc = (OEM / 'module/tool_change.cpp').read_text().split('\n'); mo = (OEM / 'module/motion.cpp').read_text(); bl = (OEM / 'feature/bltouch.cpp').read_text()
        i_dx = next(i for i, l in enumerate(tc) if 'inline void dualx_tool_change' in l)
        body = '\n'.join(tc[i_dx:i_dx + 50])
        self.assertRegex(body, r'active_extruder = new_tool;\s*\n[^\n]*\n\s*set_axis_is_at_home\(X_AXIS\);', 'set_axis_is_at_home(X_AXIS) steht UNBEDINGT (ohne no_move-Abfrage) in dualx_tool_change')
        self.assertIn('if (!no_move && homing_needed()) {\n      no_move = true;', '\n'.join(tc))
        self.assertIn('if (new_tool != 0 && idex_is_duplicating())', '\n'.join(tc))
        fn = re.search(r'void set_axis_is_at_home\(const AxisEnum axis\) \{.*?\n\}\n', mo, flags=re.S).group(0)
        self.assertIn('set_axis_trusted(axis);', fn); self.assertIn('set_axis_homed(axis);', fn)
        for proc in ('deploy_proc', 'stow_proc'):
            blk = re.search(r'bool BLTouch::%s\(\) \{.*?\n\}\n' % proc, bl, flags=re.S).group(0)
            self.assertIn('stop();', blk); self.assertNotIn('kill(', blk, proc + ': stop(), KEIN kill()'); self.assertIn('return true;', blk)


if __name__ == '__main__':
    unittest.main(verbosity=2)
