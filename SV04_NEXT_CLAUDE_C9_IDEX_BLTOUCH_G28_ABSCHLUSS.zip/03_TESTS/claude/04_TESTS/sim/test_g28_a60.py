"""G28/IDEX/BLTouch (Punkt 1): die ECHTE G28.cpp wird in der Host-Simulation ausgefuehrt, einmal im Stand 276 (ChatGPT) und einmal im Stand 277 (Stufe 1). Jeder Befund ist ein Test, der auf 276 den
Fehler zeigt und auf 277 besteht. Normalfaelle (Modus 0/1) muessen auf beiden Staenden IDENTISCH laufen. motion.h/.cpp-Bloecke stammen WOERTLICH aus den gepatchten Dateien; homeaxis() ist ein Modell mit der
OEM-Reihenfolge (deploy -> Homing -> set_axis_is_at_home -> stow -> Abschlussflags); Endschalter-Fehler = kill() (beendet den Prozess). SIMULATION: keine Hardware, kein Endschalter, kein BLTouch."""
import re
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import build_sim_a60 as B  # noqa: E402
import chain_tree as T  # noqa: E402

ROOT = HERE.parents[1]
OEM276 = T.shared()['t276']                  # OEM + ChatGPT 268..276 (echte Skripte)
OEM277 = T.shared()['p1']                    # 276 + apply_277_p1.py
_S = {}


def exe(name, root, defines=()):
    k = (name, str(root), tuple(defines))
    if k not in _S:
        _S.setdefault('work', Path(tempfile.mkdtemp(prefix='g28t_')))
        _S[k] = B.build_g28(root, name, list(defines), _S['work'])
    return _S[k]


def run(which, *a):
    e = {'276': lambda: exe('b276', OEM276), '277': lambda: exe('b277', OEM277, ['SIM_P1_277']), 'zopt': lambda: exe('bz', OEM277, ['SIM_P1_277', 'SV04_P1_Z_ONLY_REHOMES_X=1'])}[which]()
    r = B.scenario(e, *a)
    r['t'] = [c.strip() for c in r['TRACE'].split(';') if c.strip()]
    r['axes'] = dict(kv.split('=') for kv in r['AXES'].split())
    r['tool'] = dict(kv.split('=') for kv in r['TOOL'].split())
    r['res'] = dict(kv.split('=') for kv in r['RESULT'].split()) if r['RESULT'].startswith('seq') else {}
    return r


def has(r, s): return any(s == c for c in r['t'])
def idx(r, s): return next(i for i, c in enumerate(r['t']) if c == s)
def motion(r): return [c for c in r['t'] if c.startswith(('homeaxis', 'tool_change', 'do_blocking', 'do_z_clearance'))]


class Parity(unittest.TestCase):
    """Normale G28-Nutzung bleibt auf 277 BYTEGLEICH zu 276 (Spur, Zustand, Meldungen)."""
    CASES = [['p=', 'homed=none'], ['p=X', 'homed=none'], ['p=Y', 'homed=none'], ['p=XY', 'homed=none'], ['p=XYZ', 'homed=none'], ['p=O', 'homed=all'], ['p=O', 'homed=none'], ['p=', 'homed=all'],
             ['p=', 'homed=none', 'tool=1'], ['p=', 'homed=none', 'lev0=0'], ['p=', 'homed=none', 'save_mode=4', 'printing=1'], ['p=XY', 'homed=none', 'tool=1'], ['p=Z', 'homed=all'], ['p=Z', 'homed=XY'], ['p=Z', 'homed=none']]

    def test_G01_success_and_refusal_paths_in_modes_0_and_1_are_identical_between_276_and_277(self):
        for mode in (0, 1):
            for c in self.CASES:
                a, b = run('276', *c, 'mode=%d' % mode), run('277', *c, 'mode=%d' % mode)
                for k in ('TRACE', 'AXES', 'TOOL', 'LEV', 'COUNTS'):
                    self.assertEqual(a[k], b[k], f'{c} mode={mode}: {k}')
                self.assertEqual([s for s in a['SERIAL'].split('] ') if 'Error' in s], [s for s in b['SERIAL'].split('] ') if 'Error' in s], f'{c} mode={mode}: Meldungen')

    def test_G02_g28_z_alone_stays_refused_even_with_stale_flags_and_homed_axes(self):
        for w in ('276', '277'):
            for c in (['p=Z', 'homed=all'], ['p=Z', 'homed=all', 'stale_flags=1'], ['p=Z', 'homed=XY']):
                r = run(w, *c)
                self.assertFalse(has(r, 'homeaxis Z T0'), f'{w} {c}: kein Z-Homing ohne frische T1-Referenz im selben G28')
                self.assertIn('T1 homing not confirmed', r['SERIAL'])

    def test_G03_normal_full_g28_sequence_t1_then_t0_then_parked_then_y_then_z_then_restore(self):
        r = run('277', 'p=', 'homed=none')
        order = ['homeaxis X T1', 'homeaxis X T0', 'idex_set_parked(true)', 'homeaxis Y T0', 'homeaxis Z T0', 'probe.stow', 'probe.move_z_after_homing']
        pos = [idx(r, s) for s in order]
        self.assertEqual(pos, sorted(pos))
        self.assertEqual((r['axes']['homed'], r['axes']['trusted']), ('7', '7'))
        self.assertEqual(r['res'], {'seq': '1', 'completed': '1', 'ok': '1', 'x_attempted': '1', 't1_ok': '1', 't0_ok': '1', 'z_attempted': '1', 'z_ok': '1'})
        self.assertTrue(has(r, 'RTS_MoveAxisHoming'))
        self.assertEqual(r['LEV'], 'active=1')

    def test_G04_every_g28_increments_the_result_sequence_also_skipped_ones(self):
        r = run('277', 'p=', 'homed=none', 'repeat=3')
        self.assertEqual(r['res']['seq'], '3')
        s = run('277', 'p=O', 'homed=all')
        self.assertEqual((s['res']['seq'], s['res']['completed'], s['res']['ok']), ('1', '0', '0'), 'G28 O ohne Bewegung: nicht "completed" (konservativ)')
        self.assertEqual(motion(s), [])


class Failures(unittest.TestCase):
    def test_F01_z_stow_alarm_276_leaves_z_homed_and_trusted_277_revokes_it(self):
        a, b = run('276', 'p=', 'homed=none', 'stow_fail=1'), run('277', 'p=', 'homed=none', 'stow_fail=1')
        self.assertEqual((a['axes']['homed'], a['axes']['trusted']), ('7', '7'), 'BEFUND 276: Z bleibt nach dem Alarm homed+trusted (set_axis_is_at_home laeuft VOR probe.stow)')
        self.assertEqual((b['axes']['homed'], b['axes']['trusted']), ('3', '3'))
        self.assertEqual((b['res']['ok'], b['res']['z_ok'], b['res']['z_attempted']), ('0', '0', '1'))
        for r in (a, b):
            self.assertFalse(has(r, 'probe.move_z_after_homing'))
            self.assertFalse(has(r, 'RTS_MoveAxisHoming'), 'keine Erfolgsmeldung an das Display')
            self.assertEqual(r['LEV'], 'active=0', 'Leveling nicht wiederhergestellt')

    def test_F02_deploy_and_bltouch_alarm_never_mark_z_homed(self):
        for opt in ('deploy_fail=1', 'bltouch_alarm=1'):
            r = run('277', 'p=', 'homed=none', opt)
            self.assertEqual((r['axes']['homed'], r['axes']['trusted']), ('3', '3'), opt)
            self.assertEqual((r['res']['ok'], r['res']['z_ok']), ('0', '0'), opt)
            self.assertFalse(has(r, 'RTS_MoveAxisHoming'), opt)

    def test_F03_t0_failure_after_t1_success_276_keeps_x_trusted_277_revokes_x_and_stops_y(self):
        a, b = run('276', 'p=', 'homed=none', 'x_early_t0=1'), run('277', 'p=', 'homed=none', 'x_early_t0=1')
        self.assertEqual(a['axes']['homed'], '3', 'BEFUND 276: X bleibt homed+trusted trotz T0-Fehler, Y wird noch gefahren')
        self.assertTrue(has(a, 'homeaxis Y T0'))
        self.assertEqual((b['axes']['homed'], b['axes']['trusted']), ('0', '0'))
        self.assertFalse(has(b, 'homeaxis Y T0'), 'nach gescheitertem X keine weitere Achsbewegung')
        self.assertFalse(has(b, 'homeaxis Z T0'))
        self.assertFalse(has(b, 'idex_set_parked(true)'))
        self.assertEqual((b['res']['ok'], b['res']['t1_ok'], b['res']['t0_ok']), ('0', '1', '0'))

    def test_F04_t1_failure_never_starts_the_t0_move_and_never_reports_success(self):
        for w in ('276', '277'):
            r = run(w, 'p=', 'homed=none', 'x_early_t1=1')
            self.assertFalse(has(r, 'homeaxis X T0'), w)
            self.assertFalse(has(r, 'idex_set_parked(true)'), w)
            self.assertFalse(has(r, 'RTS_MoveAxisHoming'), w)
            self.assertFalse(any(c.startswith('tool_change') and c.endswith('move=1') for c in r['t']), w + ': keine Werkzeugrueckstellung mit Bewegung')
        r = run('277', 'p=', 'homed=none', 'x_early_t1=1')
        self.assertEqual((r['axes']['homed'], r['res']['t1_ok'], r['res']['ok']), ('0', '0', '0'))

    def test_F05_endstop_miss_is_a_kill_nothing_runs_afterwards(self):
        for opt in ('kill_x_t1=1', 'kill_x_t0=1', 'kill_z=1', 'kill_y=1'):
            for w in ('276', '277'):
                r = run(w, 'p=', 'homed=none', opt)
                self.assertEqual(r['TAG'], 'KILLED', f'{w} {opt}')
                self.assertEqual(r['t'][-1], 'kill: homing failed', f'{w} {opt}: danach keine Bewegung, keine Meldung')
                self.assertFalse(has(r, 'RTS_MoveAxisHoming'))

    def test_F06_t1_reference_plausibility_is_checked_not_only_compared_with_itself(self):
        a = run('276', 'p=', 'homed=none', 'hotend_x1=400')
        self.assertTrue(has(a, 'homeaxis Z T0'), 'BEFUND 276: der Vergleich x == x_home_pos(1) ist tautologisch, ein T1-Offset ausserhalb des Verfahrwegs faellt nicht auf')
        # echte Formel (motion.cpp:1132): Offset <= 0 faellt auf X2_HOME_POS (362) zurueck -> plausibel; nur Werte UEBER X2_MAX_POS (362) sind unplausibel
        for hx, ok in ((188, '1'), (0, '1'), (-5, '1'), (362, '1'), (0.5, '1'), (362.5, '0'), (400, '0'), (1000, '0')):
            r = run('277', 'p=', 'homed=none', 'hotend_x1=%s' % hx)
            self.assertEqual(r['res']['ok'], ok, 'hotend_x1=%s' % hx)
            if ok == '0':
                self.assertFalse(has(r, 'homeaxis X T0')); self.assertFalse(has(r, 'homeaxis Z T0'))

    def test_F07_duplication_and_mirrored_modes_homing_works_on_277_and_failed_on_276(self):
        for mode in (2, 3):
            a, b = run('276', 'p=', 'homed=none', 'mode=%d' % mode), run('277', 'p=', 'homed=none', 'mode=%d' % mode)
            self.assertFalse(has(a, 'homeaxis Z T0'), 'BEFUND 276: Z-Homing in Modus %d verweigert' % mode)
            self.assertEqual(a['tool']['dupl'], '0', 'BEFUND 276: die Duplizierung des Anwenders wird abgeschaltet und NICHT wiederhergestellt')
            self.assertEqual((b['res']['ok'], b['axes']['homed'], b['tool']['dupl'], b['tool']['mode']), ('1', '7', '1', str(mode)))
            self.assertEqual(b['t'].count('homeaxis X T1'), 2, 'zweiter X-Durchgang der Duplizierungs-Wiederherstellung')
            self.assertEqual(b['LEV'], 'active=1')

    def test_F08_second_x_pass_failure_leaves_duplication_off_and_reports_failure(self):
        a, b = run('276', 'p=', 'homed=none', 'mode=2', 'x_t1_on_call=2'), run('277', 'p=', 'homed=none', 'mode=2', 'x_t1_on_call=2')
        self.assertEqual(a['tool']['dupl'], '0', 'Stand 276: Z verweigert, daher kein zweiter Durchgang (F5 ueberdeckt F6)')
        self.assertEqual((b['res']['ok'], b['res']['t1_ok'], b['tool']['dupl'], b['axes']['homed']), ('0', '1', '0', '6'), 'Duplizierung bleibt AUS = sicherer Zustand; X ist widerrufen; Z blieb homed (war erfolgreich)')
        self.assertFalse(has(b, 'set_duplication_enabled(true)'))
        self.assertFalse(has(b, 'RTS_MoveAxisHoming'))
        self.assertEqual(b['LEV'], 'active=0')

    def test_F09_failed_run_never_restores_leveling_tool_or_ui_in_any_failure(self):
        for opt in ('x_early_t0=1', 'x_early_t1=1', 'stow_fail=1', 'deploy_fail=1', 'bltouch_alarm=1'):
            r = run('277', 'p=', 'homed=none', 'tool=1', opt)
            self.assertEqual(r['LEV'], 'active=0', opt)
            self.assertFalse(any(c == 'tool_change T1 move=1' for c in r['t']), opt + ': keine Rueckstellung des Werkzeugs mit Bewegung')
            self.assertFalse(has(r, 'RTS_MoveAxisHoming'), opt)
            self.assertEqual(r['res']['ok'], '0', opt)

    def test_F10_g28_z_option_rehomes_x_in_the_same_call_only_when_enabled(self):
        d = run('277', 'p=Z', 'homed=all')
        self.assertFalse(has(d, 'homeaxis Z T0')); self.assertFalse(has(d, 'homeaxis X T1'))
        o = run('zopt', 'p=Z', 'homed=all')
        self.assertTrue(has(o, 'homeaxis X T1') and has(o, 'homeaxis X T0') and has(o, 'homeaxis Z T0'))
        self.assertLess(idx(o, 'homeaxis X T0'), idx(o, 'homeaxis Z T0'))
        self.assertEqual((o['res']['ok'], o['res']['t1_ok'], o['res']['z_ok']), ('1', '1', '1'))
        self.assertFalse(has(o, 'homeaxis Y T0'), 'Y wurde nicht angefordert')

    def test_F11_all_four_idex_modes_complete_a_full_g28_and_restore_their_mode(self):
        for mode in (0, 1, 2, 3):
            r = run('277', 'p=', 'homed=none', 'mode=%d' % mode)
            self.assertEqual((r['res']['ok'], r['axes']['homed'], r['tool']['mode'], r['tool']['active']), ('1', '7', str(mode), '0'), 'Modus %d' % mode)
            self.assertEqual(r['tool']['dupl'], '1' if mode >= 2 else '0', 'Modus %d: Duplizierungszustand wie vorher' % mode)


if __name__ == '__main__':
    unittest.main(verbosity=2)
