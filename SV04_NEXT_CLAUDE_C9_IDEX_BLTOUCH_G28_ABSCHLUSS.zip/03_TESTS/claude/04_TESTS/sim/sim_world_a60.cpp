// SIM-WELT (Stub, nicht OEM). Bedlevel-Funktionen folgen dem gelesenen ORIGINAL (bedlevel.cpp / abl.cpp, Fundstellen in Kommentaren).
#include "Marlin/src/inc/MarlinConfig.h"
#include "Marlin/src/feature/bedlevel/abl/abl.h"
#include "sim_lcd_env_a60.h"
#if defined(__has_include)
  #if __has_include("Marlin/src/lcd/e3v2/creality/sv04_claude_hooks.h")
    #include "Marlin/src/lcd/e3v2/creality/LCD_RTS.h"
    #include "Marlin/src/lcd/e3v2/creality/sv04_claude_hooks.h"
    #define SIM_HAS_CLAUDE_HOOKS 1                  // nur Baeume MIT den Claude-Dateien (G28-Simulationen haben sie nicht)
  #endif
#endif

SimWorld W;
GcodeParser parser;
Planner planner;
Probe probe;
SimSerial LCD_SERIAL;
uint8_t active_extruder = 0;
bed_mesh_t z_values;
xy_pos_t bilinear_grid_spacing, bilinear_start;
xy_float_t bilinear_grid_factor;
xyze_pos_t current_position;
float xy_probe_feedrate_mm_s = 0;

uint32_t sim_ms = 0;
void SimWorld::reset() {
  homed = true; params.clear(); probe_script.clear(); deploy_fail = stow_fail = false; bounds_ok = true; sim_stopped = false;
  cmds.clear(); serial.clear(); serial_line.clear(); wire.clear(); trace.clear();
  probe_calls = eeprom_saves = heat_cmds = tool_changes = 0; rx_frames = rx_polled = 0;
  planner.leveling_active = false; active_extruder = 0;
  for (int x = 0; x < GRID_MAX_POINTS_X; x++) for (int y = 0; y < GRID_MAX_POINTS_Y; y++) z_values[x][y] = NAN;
  bilinear_grid_spacing.reset(); bilinear_start.reset(); bilinear_grid_factor.reset();
  extern char waitway; waitway = 0;
}
void sim_serial_eol() { W.serial.push_back(W.serial_line); W.serial_line.clear(); }
void (*sim_run_g28_hook)(const std::string &) = nullptr;   // vom Treiber gesetzt: fuehrt GcodeSuite::G28() mit den Parametern des Endskripts aus
void process_subcommands_now_P(PGM_P s) { W.log(std::string("gcode:") + s); const std::string g = s; if (g.find("M104") == 0 || g.find("M109") == 0 || g.find("M140") == 0 || g.find("M190") == 0) W.heat_cmds++;  if (g.find("G28") == 0 && sim_run_g28_hook) sim_run_g28_hook(g); }
void remember_feedrate_scaling_off() { W.log("remember_feedrate_scaling_off"); }
void restore_feedrate_and_scaling() { W.log("restore_feedrate_and_scaling"); }
void sync_plan_position() { W.log("sync_plan_position"); }
void report_current_position() { W.log("report_current_position"); }
void (*sim_idle_hook)() = nullptr;
void reset_stepper_timeout() {}
void idle_no_sleep() { if (sim_idle_hook) sim_idle_hook(); }       // wie Marlin: idle() -> RTSUpdate() -> Auto60-Tick
void sim_probe_time_hook() { sim_ms += W.probe_ms; W.in_probe = true; if (sim_idle_hook) sim_idle_hook(); W.in_probe = false; }
void do_z_clearance(const float z) { sim_planner_guard(0, 0, z); char b[48]; snprintf(b, sizeof b, "do_z_clearance %.1f", (double)z); W.log(b); }
void do_blocking_move_to_z(const float z) { sim_planner_guard(0, 0, z); char b[48]; snprintf(b, sizeof b, "do_blocking_move_to_z %.1f", (double)z); W.log(b); }
long random(long a, long b) { return a + (b - a) / 2; }
void extrapolate_unprobed_bed_level() { W.log("extrapolate_unprobed_bed_level"); }   // vollstaendiges 4x4-Raster: keine unprobten Zellen
void print_bilinear_leveling_grid() { W.log("print_bilinear_leveling_grid"); }
#ifdef SIM_REAL_BEDLEVEL
// 283/Gesamtintegration: die ECHTEN Funktionen aus dem OEM-bedlevel.cpp (mit M420 V2 und V4, woertlich extrahiert, extract_bedlevel_a60.py) statt der Attrappen. kill() beendet den Prozess wie am Geraet (Notstopp).
extern void sim_dump_and_exit(const char *why);
void kill(PGM_P const lcd_error, PGM_P const lcd_component, const bool steppers_off) { (void)lcd_component; (void)steppers_off; W.log(std::string("kill: ") + (lcd_error ? lcd_error : "")); sim_dump_and_exit(lcd_error ? lcd_error : "kill"); }
#ifndef GRID_LOOP
  #define GRID_LOOP(A,B) LOOP_L_N(A, GRID_MAX_POINTS_X) LOOP_L_N(B, GRID_MAX_POINTS_Y)
#endif
#include SIM_REAL_BEDLEVEL_INC
// Planner-Guard 288: identische Bedingung und Meldung wie der in planner.cpp eingefuegte Block (combined_289.patch); jede Bewegungsroutine der Simulation ruft ihn auf (im Original: Planner::buffer_line)
void sim_planner_guard(const float x, const float y, const float z) {
  if (planner.leveling_active && !leveling_is_valid()) { SERIAL_ERROR_MSG("SV04: invalid active mesh at planner enqueue"); kill(PSTR("Invalid active mesh"), nullptr, true); }           // Guard 288
  if (!isfinite(x) || !isfinite(y) || !isfinite(z)) { SERIAL_ERROR_MSG("SV04: non-finite Cartesian move"); kill(PSTR("Invalid motion coordinates"), nullptr, true); }                  // Finite-Guard 290/291 (planner.cpp, Planner::buffer_line)
}
#else
void sim_planner_guard(const float, const float, const float) {}
// bedlevel.cpp:49-53 (Original)
bool leveling_is_valid() { return !!bilinear_grid_spacing.x; }
// bedlevel.cpp:62-95 (Original, ohne planner.apply_leveling: nur Zustand + Protokoll)
void set_bed_leveling_enabled(const bool enable) {
  const bool can_change = (!enable || leveling_is_valid()) && !(enable && W.m420_noop);
  W.log(std::string("set_bed_leveling_enabled(") + (enable ? "true" : "false") + ")" + (can_change ? "" : " REFUSED(grid invalid)"));
  if (can_change && enable != planner.leveling_active) {
    planner.synchronize();
    const xy_pos_t reset { -9999.999f, -9999.999f };
    (void)bilinear_z_offset(reset);
    planner.leveling_active = enable;
    sync_plan_position();
  }
}
// bedlevel.cpp:123-145 (Original, Zweig AUTO_BED_LEVELING_BILINEAR): z_values -> NAN, Raster/Start -> 0
void reset_bed_level() {
  W.log("reset_bed_level");
  set_bed_leveling_enabled(false);
  bilinear_start.reset();
  bilinear_grid_spacing.reset();
  for (int x = 0; x < GRID_MAX_POINTS_X; x++) for (int y = 0; y < GRID_MAX_POINTS_Y; y++) z_values[x][y] = NAN;
}
#endif   // SIM_REAL_BEDLEVEL
// abl.cpp refresh_bed_level (Original, ohne Subdivision)
void refresh_bed_level() { W.log("refresh_bed_level"); bilinear_grid_factor = bilinear_grid_spacing.reciprocal(); }

#ifdef SIM_HAS_CLAUDE_HOOKS
// 290: Empfangsweg des DWIN (nur die LEITUNG ist Attrappe; was danach passiert, ist der echte Adapter-/Koordinatorcode).
// RTS_RecData(): wie das Original -1 bei leerem Puffer, sonst 1 je Rahmen. RTS_HandleData(): der vom Overlay am Anfang der OEM-Funktion eingefuegte Block (Test OP40 vergleicht den Text mit dem Patch).
int RTSSHOW::RTS_RecData() { if (W.rx_frames <= 0) return -1; --W.rx_frames; ++W.rx_polled; return 1; }
void RTSSHOW::RTS_HandleData() {
  if (SV04Claude_Auto60_Busy()) { SV04Claude_Auto60_TouchCancel(); return; }
  W.log("RTS_HandleData(normal)");
}
#endif

// C2: MarlinCore.cpp:932 stop(): alle Heizungen aus, Zustand gestoppt; kein kill()
bool sim_stopped = false;
void sim_stop() { sim_stopped = true; thermalManager.temp_bed.target = 0; W.log("stop(): heaters off, state STOPPED"); }
bool IsStopped() { return sim_stopped; }
bool IsRunning() { return !sim_stopped; }
