#!/usr/bin/env python3
"""Extrahiert die P1-Bloecke WOERTLICH aus dem gepatchten motion.h / motion.cpp (nichts wird neu geschrieben):
 p1_decls.h  = Standardwert-Makro SV04_P1_Z_ONLY_REHOMES_X + Deklarationen (Ergebnisstruktur, Plausibilitaet, Abschlussflags)
 p1_defs.inc = Definitionen der Abschlussflags und der Ergebnisstruktur
 p1_plaus.inc= Funktion sv04_p1_t1_home_plausible()
 p1_tail.inc = Abschluss-Schwanz von homeaxis() (setzt die Flags)
Aufruf: extract_p1_a60.py --motion-h motion.h --motion-cpp motion.cpp --out DIR"""
import argparse
import re
import sys
from pathlib import Path


def block(lines, marker, kinds=('#if', '#ifndef', '#ifdef'), optional=False):
    i = next((k for k, l in enumerate(lines) if marker in l), None)
    if i is None:
        if optional:
            return '// (Block ' + marker + ' im Stand 276 nicht vorhanden)\n'
        raise SystemExit('Marker nicht gefunden: ' + marker)
    j = next(k for k in range(i, len(lines)) if lines[k].strip().startswith(kinds))
    depth, k = 0, j
    while True:
        st = lines[k].strip()
        if st.startswith(('#if', '#ifdef', '#ifndef')):
            depth += 1
        elif st.startswith('#endif'):
            depth -= 1
            if depth == 0:
                return '\n'.join(lines[i:k + 1]) + '\n'
        k += 1


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--motion-h', required=True)
    ap.add_argument('--motion-cpp', required=True)
    ap.add_argument('--out', required=True)
    a = ap.parse_args(argv)
    h = Path(a.motion_h).read_text(encoding='utf-8').split('\n')
    c = Path(a.motion_cpp).read_text(encoding='utf-8').split('\n')
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    decls = block(h, 'SV04_NEXT_P1_277: default OFF', optional=True) + block(h, 'SV04_NEXT_P1_274: ephemeral completion evidence')
    (out / 'p1_decls.h').write_text('#pragma once\n' + decls, encoding='utf-8')
    (out / 'p1_defs.inc').write_text(block(c, 'SV04_NEXT_P1_274: reset per G28'), encoding='utf-8')
    (out / 'p1_plaus.inc').write_text(block(c, 'SV04_NEXT_P1_277: after homeaxis()', optional=True), encoding='utf-8')
    (out / 'p1_tail.inc').write_text(block(c, 'SV04_NEXT_P1_274: only reaches here'), encoding='utf-8')
    print('P1-Bloecke extrahiert nach', out)
    return 0


if __name__ == '__main__':
    sys.exit(main())
