#pragma once
// VIRTUELLES HMI (Simulation): wertet die Bytes aus, die LCD_SERIAL.write() erhalten hat (DGUS: 5A A5 len cmd addr data...). Keine Aussage ueber das echte DWIN-Verhalten
// jenseits der Annahme "0x82-Schreibzugriffe setzen Register"; Dezimalstellen/Vorzeichen der Anzeige sind HMI-seitig und hier NICHT simuliert.
#include <stdint.h>
#include <map>
#include <string>
#include <vector>
struct VirtualHmiA60 {
  std::map<uint32_t, uint16_t> reg;
  int frames = 0, multiword = 0, page = -1, bad = 0;
  std::vector<uint32_t> cell_writes;                 // Reihenfolge der Schreibzugriffe auf Mesh-Zellen (VP)
  void feed(const std::vector<uint8_t> &w) {
    size_t i = 0;
    while (i + 3 < w.size()) {
      if (w[i] != 0x5A || w[i + 1] != 0xA5) { bad++; i++; continue; }
      const unsigned len = w[i + 2];
      if (i + 3 + len > w.size()) { bad++; break; }
      const uint8_t cmd = w[i + 3];
      frames++;
      if (cmd == 0x82 && len >= 5) {
        const uint32_t addr = ((uint32_t)w[i + 4] << 8) | w[i + 5];
        const unsigned words = (len - 3) / 2;
        if (words > 1) multiword++;
        for (unsigned k = 0; k < words; k++) reg[addr + k] = (uint16_t)((w[i + 6 + 2 * k] << 8) | w[i + 7 + 2 * k]);
        if (addr >= 0x1100 && addr <= 0x111E && !(addr & 1)) cell_writes.push_back(addr);
        if (addr == 0x0084 && words == 2 && reg[0x0084] == 0x5A01) page = reg[0x0085];
      }
      i += 3 + len;
    }
  }
  int cell(unsigned k) const { auto it = reg.find(0x1100 + 2 * k); return it == reg.end() ? 0x7FFFFFFF : (int)(int16_t)it->second; }   // 0x7FFFFFFF = nie beschrieben
};
