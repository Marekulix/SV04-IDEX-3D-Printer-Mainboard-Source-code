"""Gesamtintegration 283 + M420: Auto60, G29, M500 und EEPROM-Rohlesung gegen die ECHTEN Funktionen leveling_is_valid / set_bed_leveling_enabled / reset_bed_level des OEM-bedlevel.cpp mit den PATCHES M420 V2 und V4
(woertlich extrahiert, extract_bedlevel_a60.py; Patchskripte = ChatGPTs eigene, ueber deren Konstanten). V4: aktive Nivellierung + ungueltiges Mesh -> kill() (Notstopp). Host-Simulation; KEIN STM32, KEINE Hardware.
Die Attrappe der bisherigen Tests laesst solche Zustaende still durchgehen; diese Suite nicht."""
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import test_ee_a60 as E  # noqa: E402

REAL = ['SIM_REAL_BEDLEVEL=v2v4']


def run(*a):
    r = E.run(*a, name='bl_v2v4', defines=REAL)
    r['lev'] = int(r['RAM'].split('leveling=')[1].split()[0]) if 'leveling=' in r.get('RAM', '') else None
    return r


def blank():
    E.refs()
    return E.mutated('bl_blank.img', lambda b: b.__setitem__(slice(0, 2048), b'\xff' * 2048))


class RealBedlevel(unittest.TestCase):
    PRE_G29 = [['x_early_t1=1'], ['x_early_t0=1'], ['stow_fail=1'], ['deploy_fail=1'], ['x_t1_on_call=2'], ['touch_after_homeaxis=2'], ['kick_after_homeaxis=2', 'kick=40'], ['print_after_homeaxis=2'], ['hotend_x1=400'], ['cancel_after_homeaxis=2'], ['touch_at=HEATING']]
    DURING_G29 = [['touch_after_probe=6'], ['nan_at=9'], ['val_at=5', 'val=12'], ['val_at=5', 'val=45']]

    def test_BL01_success_path_with_the_real_v2_v4_functions(self):
        r = run('homed=none', 'ee_out=' + E.img('bl_ok.img'))
        self.assertEqual((r['state'], r['reason'], r['lev']), ('SUCCESS', 'VERIFIED', 1)); self.assertEqual(r['HMIPAGE'], '22')
        self.assertEqual(r['raw']['journal_inflight'], 0); self.assertTrue(E.near(r['mesh'], r['eemesh']))

    def test_BL02_empty_eeprom_no_failure_or_cancel_ends_in_an_emergency_stop(self):
        """ALTES Mesh = NaN (leeres EEPROM). Die OEM-G29 schaltet die Nivellierung am Ende ein; ein Rollback, das erst das ungueltige Mesh herstellt, loest mit V4 kill() aus."""
        b = blank(); n = 0
        for opt in self.PRE_G29 + self.DURING_G29:
            r = run('homed=none', 'ee_in=' + b, *opt)
            self.assertNotEqual(r['state'], 'KILLED', str(opt) + ': KEIN Notstopp'); self.assertNotEqual(r['state'], 'SUCCESS', str(opt))
            self.assertEqual(r['EEBYTES_CHANGED_VS_START'], '0', str(opt)); self.assertEqual(r['lev'], 0, str(opt) + ': Nivellierung wie vorher AUS'); self.assertNotEqual(r['HMIPAGE'], '22', str(opt))
            self.assertEqual(r['RAM'].split()[0], 'zoff_unchanged=1', str(opt)); n += 1
        self.assertEqual(n, len(self.PRE_G29) + len(self.DURING_G29))

    def test_BL03_valid_old_mesh_no_emergency_stop_and_leveling_state_is_restored(self):
        for lev0 in (0, 1):
            for opt in self.DURING_G29:
                r = run('homed=none', f'lev0={lev0}', *opt)
                self.assertNotEqual(r['state'], 'KILLED', f'{opt} lev0={lev0}'); self.assertNotEqual(r['state'], 'SUCCESS', f'{opt} lev0={lev0}')
                if 'nan_at=9' not in opt:
                    self.assertEqual(r['lev'], lev0, f'{opt}: Nivellierung nach dem Fehlschlag wie VOR dem Lauf (lev0={lev0})')
                self.assertEqual(r['EEBYTES_CHANGED_VS_START'], '0', str(opt)); self.assertEqual(r['EEMAINEQ'], '1', str(opt))

    def test_BL04_power_loss_then_boot_recovery_with_the_real_functions_never_halts(self):
        old, new, total = E.refs()
        for n in (0, 400, 800, 812, 814, 815, 816, 830, 860, 880, total - 1):
            p1 = run('homed=none', f'ee_cut_at={n}', 'ee_out=' + E.img(f'bl_cut{n}.img')); self.assertEqual(p1['state'], 'POWERLOSS', n)
            p2 = run('boot_only=1', 'ee_in=' + E.img(f'bl_cut{n}.img'))
            self.assertNotEqual(p2['state'], 'KILLED', f'cut@{n}: kein Notstopp beim Neustart'); self.assertEqual(p2['raw']['primary'], 5, n); self.assertTrue(E.near(p2['mesh'], p2['eemesh']), f'cut@{n}: RAM == EEPROM')
            self.assertEqual(p2['lev'], 0, f'cut@{n}: nach dem Neustart ist die Nivellierung aus (Flag wird fuer Bilinear nicht gespeichert)'); self.assertEqual(p2['raw']['journal_inflight'], 0, n)

    def test_BL05_read_only_commands_change_neither_mesh_zoffset_leveling_nor_position_and_move_nothing(self):
        old, new, total = E.refs()
        for label, image, lev0 in (('gueltig, Nivellierung aus', E.img('new.img'), 0), ('gueltig, Nivellierung AN', E.img('new.img'), 1), ('leer', blank(), 0), ('beschaedigt', E.mutated('bl_dmg.img', lambda b: b.__setitem__(E.OFF + 300, b[E.OFF + 300] ^ 1)), 0)):
            r = run('boot_only=1', 'ee_in=' + image, f'lev0={lev0}')
            self.assertEqual(r['state'], 'IDLE', label); self.assertEqual(r['S2S3_UNCHANGED'], 'lev=1 pos=1 mesh=1 zoff=1 offset=1 no_motion=1', label + ': M1060 S2/S3 aendern nichts und bewegen nichts')

    def test_BL06_g29_end_script_failure_and_invalid_new_mesh_never_enable_leveling_or_save(self):
        for opt in (['x_t1_on_call=2'], ['nan_at=9']):
            r = run('homed=none', *opt)
            self.assertEqual(r['state'], 'FAILED', str(opt)); self.assertEqual(r['EEBYTES_CHANGED_VS_START'], '0', str(opt)); self.assertNotEqual(r['HMIPAGE'], '22', str(opt)); self.assertNotEqual(r['state'], 'KILLED', str(opt))
            self.assertEqual(r['COUNTS'].split()[2], 'settings_save=0', str(opt) + ': kein M500')

    def test_BL08_manual_g29_rollback_restores_the_old_mesh_and_the_leveling_state_and_never_halts(self):
        """Auch die MANUELLE G29 (ohne Auto60) fuehrt bei verworfenem Messwert den RAM-Rollback aus; mit V4 darf das nie ein Notstopp sein."""
        for lev0 in (0, 1):
            r = run('homed=all', 'manual_g29=1', f'lev0={lev0}', 'val_at=5', 'val=45')
            self.assertNotEqual(r['state'], 'KILLED', lev0); self.assertEqual(r['lev'], lev0, f'lev0={lev0}: Nivellierung wie VOR der G29')
            self.assertTrue(E.near(r['mesh'], [0.31, 0.26, 0.21, 0.16, 0.33, 0.28, 0.23, 0.18, 0.35, 0.30, 0.25, 0.20, 0.37, 0.32, 0.27, 0.22], 1e-4), 'das ALTE Mesh ist wieder da (nicht das verworfene neue)')
        r = run('homed=all', 'manual_g29=1', 'ee_in=' + blank(), 'val_at=5', 'val=45')
        self.assertNotEqual(r['state'], 'KILLED', 'leeres EEPROM: kein Notstopp'); self.assertEqual(r['lev'], 0)

    def test_BL09_an_old_mesh_that_is_invalid_for_only_one_reason_never_causes_an_emergency_stop(self):
        """Das leere EEPROM ist doppelt ungueltig (NaN UND Raster 0). Hier je NUR EIN Grund: ein NaN-Punkt bei gueltigem Raster, bzw. Raster 0 bei endlichen Werten."""
        for flag in ('old_nan=1', 'old_zero_spacing=1'):
            for opt in (['touch_after_probe=6'], ['val_at=5', 'val=45'], ['val_at=5', 'val=12']):
                r = run('homed=none', 'lev0=0', flag, *opt)
                self.assertNotEqual(r['state'], 'KILLED', f'{flag} {opt}'); self.assertNotEqual(r['state'], 'SUCCESS', f'{flag} {opt}'); self.assertEqual(r['lev'], 0, f'{flag} {opt}')
                self.assertEqual(r['EEBYTES_CHANGED_VS_START'], '0', f'{flag} {opt}')
            r = run('homed=none', 'lev0=0', flag)
            self.assertEqual((r['state'], r['lev']), ('SUCCESS', 1), flag + ': ein sauberer Lauf ueberschreibt das ungueltige alte Mesh und schaltet ein')

    def test_BL07_the_unpatched_oem_functions_are_not_what_we_test_but_the_patched_ones_are_really_in_the_build(self):
        import extract_bedlevel_a60 as X
        pkg = HERE.parents[2]
        oem = (pkg / 'claude' / '01_BASELINE' / 'OEM_FILES' / 'Marlin' / 'src' / 'feature' / 'bedlevel' / 'bedlevel.cpp')
        t = X.patched_text(oem, pkg / 'm420', 'v2v4')
        self.assertIn('Invalid active mesh', t); self.assertIn('__builtin_isfinite(z_values[x][y])', t)
        self.assertNotIn('Invalid active mesh', X.patched_text(oem, pkg / 'm420', 'oem'))


    def test_BL10_the_comparison_tool_proves_host_code_equals_integrated_build_code_and_detects_a_difference(self):
        import subprocess
        import tempfile
        pkg = HERE.parents[2]
        oem = pkg / 'claude' / '01_BASELINE' / 'OEM_FILES' / 'Marlin' / 'src' / 'feature' / 'bedlevel' / 'bedlevel.cpp'
        import extract_bedlevel_a60 as X
        good = Path(tempfile.mkdtemp()) / 'bedlevel.cpp'
        good.write_text(X.patched_text(oem, pkg / 'm420', 'v2v4'), encoding='utf-8')                      # so sieht der integrierte Baum nach V2 + V4 aus
        r = subprocess.run([sys.executable, str(pkg / 'claude' / 'tools' / 'compare_bedlevel_real.py'), '--integrated', str(good)], capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr); self.assertIn('BEDLEVEL_HOST_EQUALS_BUILD=YES', r.stdout)
        bad = Path(tempfile.mkdtemp()) / 'bedlevel.cpp'
        bad.write_text(good.read_text().replace('kill(PSTR("Invalid active mesh"), nullptr, true);', 'kill(PSTR("anders"), nullptr, true);'), encoding='utf-8')
        r2 = subprocess.run([sys.executable, str(pkg / 'claude' / 'tools' / 'compare_bedlevel_real.py'), '--integrated', str(bad)], capture_output=True, text=True)
        self.assertEqual(r2.returncode, 1); self.assertIn('BEDLEVEL_HOST_EQUALS_BUILD=NO', r2.stdout); self.assertIn('ABWEICHEND', r2.stdout)
        oemtxt = Path(tempfile.mkdtemp()) / 'bedlevel.cpp'; oemtxt.write_text(oem.read_text(), encoding='utf-8')                                 # unveraenderter OEM (ohne V2/V4) ist NICHT dasselbe
        r3 = subprocess.run([sys.executable, str(pkg / 'claude' / 'tools' / 'compare_bedlevel_real.py'), '--integrated', str(oemtxt)], capture_output=True, text=True)
        self.assertEqual(r3.returncode, 1)

if __name__ == '__main__':
    unittest.main(verbosity=2)
