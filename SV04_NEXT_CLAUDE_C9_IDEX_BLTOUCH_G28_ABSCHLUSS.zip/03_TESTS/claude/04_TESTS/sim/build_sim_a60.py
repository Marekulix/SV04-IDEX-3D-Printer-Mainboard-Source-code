"""Baut die Kettensimulation: ECHTE gepatchte G29.cpp + ECHTER Adapter (.inc) + ECHTER Koordinator + woertlich extrahierte OEM-Bloecke + Stubs. Gibt den Pfad der Ausfuehrung zurueck."""
import shutil
import subprocess
import tempfile
from pathlib import Path

SIM = Path(__file__).resolve().parent
CXX = ['g++', '-std=gnu++14', '-O1', '-w']


def run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode:
        raise RuntimeError(' '.join(str(c) for c in cmd[:3]) + ' ...\n' + r.stderr[-3000:])


_CACHE = {}


def build(patched_out, name, defines=(), workdir=None, g29_override=None):
    """patched_out = Ausgabeordner von apply_claude_parallel.py (enthaelt Marlin/src/...)."""
    work = Path(workdir or tempfile.mkdtemp(prefix='a60_'))
    work.mkdir(parents=True, exist_ok=True)
    tree = work / ('tree_' + name)
    if tree.exists():
        shutil.rmtree(tree)
    shutil.copytree(SIM / 'Marlin', tree / 'Marlin')
    po = Path(patched_out) / 'Marlin' / 'src'
    for f in po.rglob('*'):                                  # gepatchte G29.cpp + neue Dateien in den Baum legen (ohne LCD_RTS.cpp/gcode.cpp: sie werden nicht kompiliert)
        if f.is_file() and f.name not in ('LCD_RTS.cpp', 'gcode.cpp'):
            dst = tree / 'Marlin' / 'src' / f.relative_to(po)
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy(f, dst)
    inc = ['-I', str(tree), '-I', str(tree / 'Marlin' / 'src'), '-I', str(SIM), '-I', str(SIM / 'stubs'), '-I', str(tree / 'Marlin' / 'src' / 'lcd' / 'e3v2' / 'creality'), '-I', str(tree / 'Marlin' / 'src' / 'feature' / 'sv04_claude_auto60')]
    if g29_override:
        shutil.copy(g29_override, tree / 'Marlin' / 'src' / 'gcode' / 'bedlevel' / 'abl' / 'G29.cpp')
    d = [f'-D{x}' for x in defines]
    objs = []
    for src in (SIM / 'sim_world_a60.cpp', SIM / 'gen' / 'sim_rts_real_a60.cpp', SIM / 'gen' / 'sim_abl_real_a60.cpp', SIM / 'chain_world.cpp', tree / 'Marlin' / 'src' / 'gcode' / 'bedlevel' / 'abl' / 'G29.cpp', SIM / 'driver_chain.cpp'):
        o = work / f'{name}_{src.stem}.o'
        shared = src.parent in (SIM, SIM / 'gen')                      # unabhaengig von Varianten und Schaltern: einmal je Arbeitsordner uebersetzen
        if shared and (work, src.name) in _CACHE:
            objs.append(_CACHE[(work, src.name)])
            continue
        run(CXX + ['-c', *d, *inc, str(src), '-o', str(o)])
        if shared and src.name != 'driver_chain.cpp':
            _CACHE[(work, src.name)] = o
        objs.append(o)
    exe = work / name
    run(['g++', *[str(o) for o in objs], '-o', str(exe)])
    return exe


def scenario(exe, *args, timeout=120):
    r = subprocess.run([str(exe), *args], capture_output=True, text=True, timeout=timeout)
    assert r.returncode == 0, r.stderr
    out = {}
    for line in r.stdout.splitlines():
        k, _, v = line.partition(' ')
        out[k] = v
    return out


def build_g28(patched_out, name, defines=(), workdir=None):
    """Baut den G28-Treiber: ECHTE gepatchte G28.cpp + woertlich extrahierte P1-Bloecke (motion.h/.cpp) + Stubs. patched_out = Baum mit Marlin/src/{gcode/calibrate/G28.cpp, module/motion.h, module/motion.cpp}."""
    import subprocess as sp
    work = Path(workdir or tempfile.mkdtemp(prefix='g28_'))
    work.mkdir(parents=True, exist_ok=True)
    tree = work / ('tree_' + name)
    if tree.exists():
        shutil.rmtree(tree)
    shutil.copytree(SIM / 'Marlin', tree / 'Marlin')
    po = Path(patched_out) / 'Marlin' / 'src'
    for f in po.rglob('*'):
        if f.is_file() and f.name not in ('LCD_RTS.cpp', 'gcode.cpp', 'motion.cpp', 'motion.h'):
            dst = tree / 'Marlin' / 'src' / f.relative_to(po)
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy(f, dst)
    (tree / 'Marlin' / 'src' / 'gcode' / 'calibrate').mkdir(parents=True, exist_ok=True)
    shutil.copy(po / 'gcode' / 'calibrate' / 'G28.cpp', tree / 'Marlin' / 'src' / 'gcode' / 'calibrate' / 'G28.cpp')
    r = sp.run(['python3', str(SIM / 'extract_p1_a60.py'), '--motion-h', str(po / 'module' / 'motion.h'), '--motion-cpp', str(po / 'module' / 'motion.cpp'), '--out', str(tree / 'Marlin' / 'src' / 'inc')], capture_output=True, text=True)
    if r.returncode:
        raise RuntimeError(r.stderr)
    inc = ['-I', str(tree), '-I', str(tree / 'Marlin' / 'src'), '-I', str(tree / 'Marlin' / 'src' / 'inc'), '-I', str(SIM), '-I', str(SIM / 'stubs'), '-I', str(tree / 'Marlin' / 'src' / 'lcd' / 'e3v2' / 'creality'), '-I', str(tree / 'Marlin' / 'src' / 'feature' / 'sv04_claude_auto60')]
    d = [f'-D{x}' for x in defines]
    objs = []
    for src in (SIM / 'sim_world_a60.cpp', SIM / 'gen' / 'sim_rts_real_a60.cpp', SIM / 'gen' / 'sim_abl_real_a60.cpp', SIM / 'chain_world.cpp', SIM / 'g28_world.cpp', tree / 'Marlin' / 'src' / 'gcode' / 'calibrate' / 'G28.cpp', SIM / 'driver_g28.cpp'):
        o = work / f'{name}_{src.stem}.o'
        run(CXX + ['-c', *d, *inc, str(src), '-o', str(o)])
        objs.append(o)
    exe = work / name
    run(['g++', *[str(o) for o in objs], '-o', str(exe)])
    return exe


def make_integrated_tree(oem_p1_root, claude_out, dest):
    """Gemeinsamer Quellstand: Stufe 1 (G28/motion gehaertet) + Stufe 2 (Claude-Overlay) -> dest/Marlin/src/..."""
    dest = Path(dest)
    if dest.exists():
        shutil.rmtree(dest)
    shutil.copytree(Path(oem_p1_root), dest)
    for f in Path(claude_out).rglob('*'):
        if f.is_file():
            t = dest / f.relative_to(claude_out)
            t.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy(f, t)
    return dest


def build_integ(tree, name, defines=(), workdir=None, driver='driver_integ.cpp', g29_override=None):
    """Integrierte Kette: ECHTER G28 (Stufe 1+2) + ECHTE G29 + ECHTER Adapter mit PRODUKTIONS-Backend (kein Test-Double) + echte RTS_SndData + Stubs."""
    work = Path(workdir or tempfile.mkdtemp(prefix='integ_'))
    work.mkdir(parents=True, exist_ok=True)
    t = work / ('tree_' + name)
    if t.exists():
        shutil.rmtree(t)
    shutil.copytree(SIM / 'Marlin', t / 'Marlin')
    po = Path(tree) / 'Marlin' / 'src'
    for f in po.rglob('*'):
        if f.is_file() and f.name not in ('LCD_RTS.cpp', 'gcode.cpp', 'motion.cpp', 'motion.h'):
            dst = t / 'Marlin' / 'src' / f.relative_to(po)
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy(f, dst)
    r = subprocess.run(['python3', str(SIM / 'extract_p1_a60.py'), '--motion-h', str(po / 'module' / 'motion.h'), '--motion-cpp', str(po / 'module' / 'motion.cpp'), '--out', str(t / 'Marlin' / 'src' / 'inc')], capture_output=True, text=True)
    if r.returncode:
        raise RuntimeError(r.stderr)
    inc = ['-I', str(t), '-I', str(t / 'Marlin' / 'src'), '-I', str(t / 'Marlin' / 'src' / 'inc'), '-I', str(SIM), '-I', str(SIM / 'stubs'), '-I', str(t / 'Marlin' / 'src' / 'lcd' / 'e3v2' / 'creality'), '-I', str(t / 'Marlin' / 'src' / 'feature' / 'sv04_claude_auto60')]
    hal = SIM / 'Marlin' / 'src' / 'HAL'
    if hal.is_dir():                                   # 283: Simulationskopie von HAL/shared/eeprom_api.h an der Stelle, die der Adapter einbindet
        shutil.copytree(hal, t / 'Marlin' / 'src' / 'HAL', dirs_exist_ok=True)
    if g29_override:
        shutil.copy(g29_override, t / 'Marlin' / 'src' / 'gcode' / 'bedlevel' / 'abl' / 'G29.cpp')
    d = [f'-D{x}' for x in defines]
    if not any(str(x).startswith('SV04_CLAUDE_AUTO60_REQUIRE_Z_KNOWN') for x in defines):
        d.append('-DSV04_CLAUDE_AUTO60_REQUIRE_Z_KNOWN=0')          # C5: die Standardsimulation startet weiter aus dem Kaltstart (Gate AUS); Gate-Tests setzen =1 ausdruecklich
    if any(str(x).startswith('SIM_REAL_BEDLEVEL=') for x in defines):       # 283: echte bedlevel-Funktionen (oem|v2v4) aus dem echten OEM-bedlevel.cpp
        variant = [str(x) for x in defines if str(x).startswith('SIM_REAL_BEDLEVEL=')][0].split('=', 1)[1]
        d = [x for x in d if not x.startswith('-DSIM_REAL_BEDLEVEL=')] + ['-DSIM_REAL_BEDLEVEL=1']
        pkg = SIM.parents[2]
        incf = work / f'bedlevel_real_{variant}.inc'
        r = subprocess.run(['python3', str(SIM / 'extract_bedlevel_a60.py'), '--bedlevel', str(pkg / 'claude' / '01_BASELINE' / 'OEM_FILES' / 'Marlin' / 'src' / 'feature' / 'bedlevel' / 'bedlevel.cpp'), '--m420-dir', str(pkg / 'm420'), '--variant', variant, '--out', str(incf)], capture_output=True, text=True)
        if r.returncode:
            raise RuntimeError(r.stdout + r.stderr)
        d.append('-DSIM_REAL_BEDLEVEL_INC="%s"' % incf)
    objs = []
    srcs = (SIM / 'sim_world_a60.cpp', SIM / 'gen' / 'sim_rts_real_a60.cpp', SIM / 'gen' / 'sim_abl_real_a60.cpp', SIM / 'chain_world.cpp', SIM / 'g28_world.cpp',
            t / 'Marlin' / 'src' / 'gcode' / 'bedlevel' / 'abl' / 'G29.cpp', t / 'Marlin' / 'src' / 'gcode' / 'calibrate' / 'G28.cpp', SIM / driver)
    for src in srcs:
        o = work / f'{name}_{src.stem}.o'
        run(CXX + ['-c', *d, *inc, str(src), '-o', str(o)])
        objs.append(o)
    exe = work / name
    run(['g++', *[str(o) for o in objs], '-o', str(exe)])
    return exe


def build(patched_out, name, defines=(), workdir=None, g29_override=None):
    """Altes API (Kettentests mit externem Test-Double): jetzt ebenfalls ueber den INTEGRIERTEN Quellstand (echter G28 wird mitgebaut, das G29-Endskript bleibt dort ein Log-Eintrag)."""
    return build_integ(patched_out, name, defines, workdir, driver='driver_chain.cpp', g29_override=g29_override)
