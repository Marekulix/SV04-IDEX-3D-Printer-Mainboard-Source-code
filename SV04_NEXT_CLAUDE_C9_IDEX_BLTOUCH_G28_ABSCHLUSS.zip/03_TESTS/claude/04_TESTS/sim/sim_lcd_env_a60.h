#pragma once
// SIM: serielle Schnittstelle zum DWIN-Display (LCD_SERIAL). Jedes geschriebene Byte landet in W.wire und wird vom virtuellen HMI ausgewertet.
#include "Marlin/src/inc/MarlinConfig.h"
struct SimSerial { void write(uint8_t b) { W.wire.push_back(b); } int available() { return 0; } int read() { return 0; } };
extern SimSerial LCD_SERIAL;
