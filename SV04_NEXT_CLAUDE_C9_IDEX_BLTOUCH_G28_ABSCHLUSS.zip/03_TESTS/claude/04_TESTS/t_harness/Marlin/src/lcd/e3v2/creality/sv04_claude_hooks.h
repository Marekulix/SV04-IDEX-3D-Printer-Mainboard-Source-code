#pragma once
// Attrappe: im Harness ist SV04Claude_Auto60_Busy() in stub_marlin.h deklariert
