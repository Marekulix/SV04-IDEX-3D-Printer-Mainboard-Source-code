// Harness: kompiliert die ECHTE T.cpp (OEM bzw. gepatcht) gegen minimale Marlin-Attrappen und meldet, was GcodeSuite::T() tut.
// Aufruf: ./h <tool> <active> <S 0/1> <x_homed> <x_trusted> <auto60_busy>
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include "stub_marlin.h"
uint8_t active_extruder = 0, active_extruder_font = 7;
bool g_homed = false, g_trusted = false, g_busy = false, g_S = false;
int g_called = 0, g_tool = -1, g_nomove = -1;
bool axis_was_homed(int) { return g_homed; }
bool axis_is_trusted(int) { return g_trusted; }
bool SV04Claude_Auto60_Busy() { return g_busy; }
void reset_stepper_timeout() {}
void tool_change(const uint8_t t, bool no_move) { g_called++; g_tool = t; g_nomove = no_move; }
Parser parser;
int main(int, char **argv) {
  const int tool = std::atoi(argv[1]); active_extruder = (uint8_t)std::atoi(argv[2]); g_S = std::atoi(argv[3]) != 0; g_homed = std::atoi(argv[4]) != 0; g_trusted = std::atoi(argv[5]) != 0; g_busy = std::atoi(argv[6]) != 0;
  GcodeSuite::T((int8_t)tool);
  std::printf("CALLED=%d TOOL=%d NOMOVE=%d FONT=%d\n", g_called, g_tool, g_nomove, (int)active_extruder_font);
  return 0;
}
