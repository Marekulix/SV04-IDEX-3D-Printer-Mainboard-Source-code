#pragma once
// Minimale Marlin-Attrappen fuer die ECHTE T.cpp (Makros wie in Marlin core/macros.h, aber nur was T.cpp braucht)
#include <cstdint>
#include <cstdio>
#include "Marlin/src/core/macros.h"        // die ECHTE macros.h des OEM-Repositories (ENABLED, TERN, EITHER, UNUSED)
#define DEBUG_SECTION(...) do {} while (0)
#define DEBUGGING(x) (0)
#define DEBUG_ECHOLNPGM(...) do {} while (0)
#define SERIAL_ECHO_START() do {} while (0)
#define SERIAL_ECHOPGM(...) hs_echo(__VA_ARGS__)
#define SERIAL_ECHOLN(s) hs_echoln(s)
#define X_AXIS 0
#define EXTRUDERS 2
#define DUAL_X_CARRIAGE 1
#define HAS_MULTI_EXTRUDER 1
// Funktionen/Variablen der Attrappen-Welt
extern uint8_t active_extruder, active_extruder_font;
bool axis_was_homed(int);
bool axis_is_trusted(int);
bool SV04Claude_Auto60_Busy();
void reset_stepper_timeout();
void tool_change(const uint8_t, bool = false);
inline void hs_echo(const char *a, int t, const char *b) { std::printf("MSG %s%d%s", a, t, b); }
inline void hs_echoln(const char *s) { std::printf("%s\n", s); }
struct Parser { bool boolval(char) const; bool string_arg = false; };
extern Parser parser;
extern bool g_S;
inline bool Parser::boolval(char) const { return g_S; }
struct GcodeSuite { static void T(const int8_t); };
