"""C9: Struktur-/Sicherheitstests des C9-Workflows (aus dem im Lauf 43484048208 erfolgreichen Route-B-Workflow abgeleitet) und eine Probe des neuen Apply-Schritts mit dem ECHTEN Skripttext. Workflow NIE ausgefuehrt (NOT RUN)."""
import hashlib
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import yaml

CL = Path(__file__).resolve().parents[1]; GEN = CL / 'tools/make_workflow_c9.py'; SRC = CL / 'docs_c8/claude_c8_route_b_patch_no_flash.yml'; OEM_M999 = CL / '01_BASELINE/OEM_309/orig/gcode/control/M999.cpp'
SHA318 = 'b474d80ac3d67a8f5f4f81d8a9c0e7fa1d24996c738b2e6b7001aefce15a18dd'; SHA9 = hashlib.sha256(b'platzhalter c9 test').hexdigest()
BUILD = 'Build STM32 profiles independently, framework-first, NO FLASH'


def gen(src=SRC, sha9=SHA9, sha318=SHA318, name=None):
    out = Path(tempfile.mkdtemp()) / 'w.yml'; a = [sys.executable, '-B', str(GEN), str(src), sha318, sha9, str(out)] + ([name] if name else []); r = subprocess.run(a, capture_output=True, text=True); return r, out


class Workflow(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        r, out = gen(); assert r.returncode == 0, r.stderr; cls.t = out.read_text(); cls.d = yaml.safe_load(cls.t)

    def runs(self, job): return dict((s.get('name', ''), s['run']) for s in self.d['jobs'][job]['steps'] if 'run' in s)

    def test_W901_two_build_jobs_plus_evaluation_no_control_job_and_the_evaluation_waits_for_both_even_after_failures(self):
        self.assertEqual(list(self.d['jobs']), ['modified_318_c6', 'c9_changes', 'evaluate_builds']); ev = self.d['jobs']['evaluate_builds']
        self.assertEqual(sorted(ev['needs']), ['c9_changes', 'modified_318_c6']); self.assertEqual(ev['if'], 'always()')
        for j in ('modified_318_c6', 'c9_changes'): self.assertNotIn('needs', self.d['jobs'][j])

    def test_W902_the_baseline_builds_only_oem318_and_the_c9_job_builds_only_the_new_copy_oem_c9_after_applying_the_patch(self):
        b, c = self.runs('modified_318_c6')[BUILD], self.runs('c9_changes')[BUILD]
        self.assertIn('pio run -d oem318 -e', b); self.assertNotIn('oem_c9', b); self.assertIn('evidence/modified_318/', b); self.assertIn('ROUTE_B_MODIFIED_318_NEW_COPY_OF_PATCH_REPRODUCED_309', b)
        self.assertIn('pio run -d oem_c9 -e', c); self.assertNotIn('oem318', c); self.assertIn('evidence/c9/', c); self.assertIn('BUILD_TREE=oem_c9', c); self.assertIn('ROUTE_B_C9_ON_318_NEW_COPY', c)
        names = [s.get('name', '') for s in self.d['jobs']['c9_changes']['steps']]; ia = [i for i, n in enumerate(names) if n.startswith('Apply C9 patch')][0]; ib = [i for i, n in enumerate(names) if n.startswith('Build STM32')][0]; self.assertLess(ia, ib)
        self.assertFalse(any(n.startswith('Apply C9 patch') for n in (s.get('name', '') for s in self.d['jobs']['modified_318_c6']['steps'])), 'die Baseline bleibt die unveraenderte 318')
        a = [r for n, r in self.runs('c9_changes').items() if n.startswith('Apply C9 patch')][0]; self.assertIn('cp -a oem318 oem_c9', a); self.assertIn('-eq 1', a); self.assertIn('set -euo pipefail', a)

    def test_W903_names_pins_and_evaluation_use_the_inputs_proven_by_the_successful_run_and_the_corrected_evaluator(self):
        self.assertEqual(self.t.count(SHA9 + '  SV04_NEXT_CLAUDE_C9_IDEX_BLTOUCH_G28_ABSCHLUSS.zip'), 3); self.assertIn(SHA318 + '  SV04_NEXT_318_GITHUB_UPLOAD_06.zip', self.t); self.assertNotIn('GESAMTINTEGRATION_UND_C6', self.t)
        for n in ('SV04_C9_BASELINE_318_STM32_LOGS_NO_FLASH', 'SV04_C9_CHANGED_STM32_LOGS_NO_FLASH'): self.assertEqual(self.t.count('name: ' + n), 1)
        self.assertIn('pattern: SV04_C9_*_STM32_LOGS_NO_FLASH', self.t); ev = [r for n, r in self.runs('evaluate_builds').items() if n.startswith('Evaluate')][0]
        self.assertIn('evaluate_builds_c9.py art --trees oem318,oem_c9', ev); self.assertIn('exit "${PIPESTATUS[0]}"', ev); self.assertNotIn('evaluate_c7_builds', self.t)

    def test_W904_valid_bash_strict_installer_only_and_no_flash_or_287_or_control_remnants(self):
        for j in self.d['jobs']:
            for n, r in self.runs(j).items(): p = Path(tempfile.mkdtemp()) / 's.sh'; p.write_text(r); self.assertEqual(subprocess.run(['bash', '-n', str(p)], capture_output=True).returncode, 0, j + ': ' + n)
        self.assertIn('c9pkg/02_PATCHES/integrate_318_strict.py c318 oem oem318', self.t); self.assertNotIn('c318/integrate_318.py', self.t)
        for bad in ('upload-binary', 'st-flash', 'dfu-util', 'openocd', '-t upload', 'pio run -t clean', 'SV04_NEXT_287', 'point1', 'integrate_286', 'control_309', 'c8pkg', 'SV04_C8'): self.assertNotIn(bad, ''.join(l for l in self.t.splitlines() if not l.lstrip().startswith('#')))

    def test_W905_the_real_apply_step_patches_only_m999_in_a_new_copy_and_leaves_the_318_copy_untouched(self):
        w = Path(tempfile.mkdtemp()); (w / 'oem318/Marlin/src/gcode/control').mkdir(parents=True); (w / 'oem318/Marlin/src/gcode/control/M999.cpp').write_bytes(OEM_M999.read_bytes()); (w / 'oem318/Marlin/src/module').mkdir(parents=True); (w / 'oem318/Marlin/src/module/x.cpp').write_text('// x\n')
        (w / 'c9pkg').mkdir(); os.symlink(CL / '03_PATCHES', w / 'c9pkg/02_PATCHES'); (w / 'evidence').mkdir()
        step = [r for n, r in self.runs('c9_changes').items() if n.startswith('Apply C9 patch')][0]; (w / 's.sh').write_text(step)
        r = subprocess.run(['bash', '-e', '-o', 'pipefail', 's.sh'], cwd=w, capture_output=True, text=True); self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertIn(b'SV04 NEXT C9', (w / 'oem_c9/Marlin/src/gcode/control/M999.cpp').read_bytes()); self.assertEqual((w / 'oem318/Marlin/src/gcode/control/M999.cpp').read_bytes(), OEM_M999.read_bytes(), '318 bleibt unveraendert'); self.assertIn('M999.cpp', (w / 'evidence/diff_318_vs_c9.txt').read_text())
        w2 = Path(tempfile.mkdtemp()); shutil.copytree(w / 'oem318', w2 / 'oem318'); (w2 / 'oem318/Marlin/src/gcode/control/M999.cpp').write_bytes(OEM_M999.read_bytes() + b'// fremd\n'); (w2 / 'c9pkg').mkdir(); os.symlink(CL / '03_PATCHES', w2 / 'c9pkg/02_PATCHES'); (w2 / 'evidence').mkdir(); (w2 / 's.sh').write_text(step)
        r2 = subprocess.run(['bash', '-e', '-o', 'pipefail', 's.sh'], cwd=w2, capture_output=True, text=True); self.assertNotEqual(r2.returncode, 0, 'fremde M999.cpp -> der Schritt scheitert'); self.assertNotIn(b'SV04 NEXT C9', (w2 / 'oem_c9/Marlin/src/gcode/control/M999.cpp').read_bytes())

    def test_W906_the_generator_refuses_bad_input_and_a_changed_source_workflow(self):
        self.assertEqual(gen(sha9='zz')[0].returncode, 2); self.assertEqual(gen(sha318='0' * 64)[0].returncode, 2); self.assertEqual(gen(name='../x.zip')[0].returncode, 2)
        x = Path(tempfile.mkdtemp()) / 'x.yml'; x.write_text(SRC.read_text().replace('Apply 318 installer to a NEW copy', 'Etwas anderes')); self.assertEqual(gen(src=x)[0].returncode, 2)


if __name__ == '__main__':
    unittest.main(verbosity=2)
