"""Struktur- und Sicherheitstests des C7-Workflows (abgeleitet aus dem gelieferten C6-Workflow). NIE ausgefuehrt (NOT RUN): hier wird nur geprueft, was ohne GitHub pruefbar ist."""
import hashlib
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import yaml

CLAUDE = Path(__file__).resolve().parents[1]
GEN = CLAUDE / 'tools' / 'make_workflow_c7.py'
C6 = CLAUDE / 'docs_c6' / 'claude_c6_stm32_no_flash.yml'
SHA318 = 'b474d80ac3d67a8f5f4f81d8a9c0e7fa1d24996c738b2e6b7001aefce15a18dd'; SHA7 = hashlib.sha256(b'platzhalter fuer den test').hexdigest()


def gen(src=C6, sha7=SHA7, sha318=SHA318):
    out = Path(tempfile.mkdtemp()) / 'w.yml'; r = subprocess.run([sys.executable, '-B', str(GEN), str(src), sha318, sha7, str(out)], capture_output=True, text=True); return r, out


class Workflow(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        r, out = gen(); assert r.returncode == 0, r.stderr; cls.t = out.read_text(); cls.d = yaml.safe_load(cls.t)

    def runs(self, job): return [(s.get('name', ''), s['run']) for s in self.d['jobs'][job]['steps'] if 'run' in s]

    def test_W701_three_jobs_the_two_build_jobs_stay_separate_and_the_evaluation_waits_for_both_even_after_failures(self):
        self.assertEqual(list(self.d['jobs']), ['control_309_original', 'modified_318_c6', 'evaluate_builds']); ev = self.d['jobs']['evaluate_builds']
        self.assertEqual(sorted(ev['needs']), ['control_309_original', 'modified_318_c6']); self.assertEqual(ev['if'], 'always()'); self.assertNotIn('needs', self.d['jobs']['control_309_original']); self.assertNotIn('needs', self.d['jobs']['modified_318_c6'])

    def test_W702_the_installer_runs_only_through_the_strict_wrapper_and_never_directly(self):
        allrun = '\n'.join(r for j in self.d['jobs'] for _, r in self.runs(j)); self.assertNotIn('c318/integrate_318.py', allrun); self.assertIn('c7pkg/02_PATCHES/integrate_318_strict.py c318 oem oem318', allrun)
        step = dict(self.runs('modified_318_c6'))['Apply 318 installer to a NEW copy through the STRICT wrapper (309 stays untouched, fail-closed)']; self.assertIn("grep -F 'STRICT_PRECHECK=OK'", step); self.assertIn("grep -F '318 SOURCE OVERLAY APPLIED'", step); self.assertIn('set -euo pipefail', step)
        self.assertNotIn('integrate_318_strict', '\n'.join(r for _, r in self.runs('control_309_original')), 'der Kontrollbuild bleibt die unveraenderte 309')

    def test_W703_every_run_block_is_valid_bash(self):
        for j in self.d['jobs']:
            for n, r in self.runs(j):
                p = Path(tempfile.mkdtemp()) / 's.sh'; p.write_text(r); self.assertEqual(subprocess.run(['bash', '-n', str(p)], capture_output=True).returncode, 0, j + ': ' + n)

    def test_W704_the_build_trees_are_not_mixed_and_both_profiles_are_built_with_the_failclosed_flag_only_for_failclosed(self):
        c = dict(self.runs('control_309_original'))['Build STM32 profiles independently, framework-first, NO FLASH']; m = dict(self.runs('modified_318_c6'))['Build STM32 profiles independently, framework-first, NO FLASH']
        self.assertIn('pio run -d oem -e', c); self.assertNotIn('oem318', c); self.assertIn('pio run -d oem318 -e', m); self.assertIn('evidence/control_309/', c); self.assertIn('evidence/modified_318/', m)
        for b in (c, m): self.assertIn('integrated_backend integrated_failclosed', b); self.assertIn("-DSV04_CLAUDE_HOME_BACKEND_AVAILABLE=0", b); self.assertIn("'[SUCCESS]'", b); self.assertIn('FLASH_ALLOWED=NO', b); self.assertIn('HARDWARE_TESTED=NO', b)
        self.assertNotIn('pio run -t clean', ''.join(l for l in (c + m).splitlines() if not l.lstrip().startswith('#')))

    def test_W705_pins_and_artifact_names_are_consistent_and_no_flash_command_exists(self):
        self.assertEqual(self.t.count(SHA7 + '  SV04_NEXT_CLAUDE_C7_BUILD_KORREKTUR_NO_FLASH.zip'), 3, 'der C7-Hash steht im Verify-Schritt beider Build-Jobs und im Auswertungsjob'); self.assertIn(SHA318 + '  SV04_NEXT_318_GESAMTINTEGRATION_UND_C6_UEBERGABE_NO_FLASH.zip', self.t)
        for name in ('SV04_C7_CONTROL_309_ORIGINAL_STM32_LOGS_NO_FLASH', 'SV04_C7_MODIFIED_318_STM32_LOGS_NO_FLASH'): self.assertEqual(self.t.count('name: ' + name), 1)
        self.assertIn('pattern: SV04_C7_*_STM32_LOGS_NO_FLASH', self.t)
        for bad in ('upload-binary', 'st-flash', 'dfu-util', 'STM32_Programmer', 'openocd', 'pio run -t upload', '-t upload'): self.assertNotIn(bad, self.t)
        self.assertNotIn('C6_GESAMT', self.t); self.assertNotIn('c6pkg', self.t)

    def test_W706_the_evaluation_step_returns_the_evaluator_exit_code_and_the_generator_refuses_bad_input(self):
        ev = dict(self.runs('evaluate_builds'))['Evaluate (exit code 0 only if control_309 and modified_318 are PASS for both profiles)']; self.assertIn('exit "${PIPESTATUS[0]}"', ev); self.assertIn('evaluate_c7_builds.py art', ev)
        self.assertEqual(gen(sha7='zz')[0].returncode, 2); self.assertEqual(gen(sha318='0' * 64)[0].returncode, 2)
        broken = Path(tempfile.mkdtemp()) / 'x.yml'; broken.write_text(C6.read_text().replace('c318/integrate_318.py oem oem318', 'etwas anderes')); self.assertEqual(gen(src=broken)[0].returncode, 2, 'fehlender Anker -> Abbruch, keine halb erzeugte Datei')


if __name__ == '__main__':
    unittest.main(verbosity=2)
