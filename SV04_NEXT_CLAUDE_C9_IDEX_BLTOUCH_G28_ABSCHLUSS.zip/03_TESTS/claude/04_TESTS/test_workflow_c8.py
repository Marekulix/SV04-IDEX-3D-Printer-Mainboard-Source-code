"""C8: Struktur-/Sicherheitstests der beiden Workflow-Routen (aus dem gelieferten C7-Workflow abgeleitet) und des Eingabepruefwerkzeugs. Die Workflows sind NIE ausgefuehrt worden (NOT RUN)."""
import hashlib
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

import yaml

CLAUDE = Path(__file__).resolve().parents[1]
GEN = CLAUDE / 'tools/make_workflow_c8.py'; VER = CLAUDE / 'tools/verify_inputs_c8.py'; C7 = CLAUDE / 'docs_c7/claude_c7_stm32_no_flash.yml'
SHA318 = 'b474d80ac3d67a8f5f4f81d8a9c0e7fa1d24996c738b2e6b7001aefce15a18dd'; SHA8 = hashlib.sha256(b'platzhalter c8 test').hexdigest(); PATCH = 'caaa7ccf7d9263fa74b383f726428c3fc463e825b27617b999dd68cfc7c251cc'
SHA287 = '2126fa983800e38106c57a5a542d33b81980b284bd2a3e6f2a197e49cec9a599'


def gen(route, src=C7, sha8=SHA8, patch=PATCH, sha318=SHA318):
    out = Path(tempfile.mkdtemp()) / 'w.yml'; a = [sys.executable, '-B', str(GEN), str(src), sha318, sha8, route, str(out)] + ([patch] if patch else []); r = subprocess.run(a, capture_output=True, text=True); return r, out


class Routes(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ta = gen('a')[1].read_text(); cls.tb = gen('b')[1].read_text(); cls.da, cls.db = yaml.safe_load(cls.ta), yaml.safe_load(cls.tb)

    def runs(self, d, job): return [(s.get('name', ''), s['run']) for s in d['jobs'][job]['steps'] if 'run' in s]

    def test_W801_route_a_adds_a_preflight_that_names_every_missing_input_and_gates_both_build_jobs_without_renaming_or_bypassing_anything(self):
        self.assertEqual(list(self.da['jobs']), ['preflight_inputs', 'control_309_original', 'modified_318_c6', 'evaluate_builds'])
        for j in ('control_309_original', 'modified_318_c6'): self.assertEqual(self.da['jobs'][j]['needs'], 'preflight_inputs')
        self.assertEqual(sorted(self.da['jobs']['evaluate_builds']['needs']), ['control_309_original', 'modified_318_c6', 'preflight_inputs']); self.assertEqual(self.da['jobs']['evaluate_builds']['if'], 'always()')
        pre = dict(self.runs(self.da, 'preflight_inputs'))['Check all pinned inputs and name every missing one']; import re; self.assertEqual(len(re.findall(r"(?m)^\s*check '", pre)), 8)
        for n in ('SV04_NEXT_287.zip', 'SV04_NEXT_289.zip', 'SV04_NEXT_291.zip', 'SV04_NEXT_294.zip', 'SV04_NEXT_295.zip', 'A 309.zip', 'SV04_NEXT_318_GESAMTINTEGRATION_UND_C6_UEBERGABE_NO_FLASH.zip', 'SV04_NEXT_CLAUDE_C8_BUILD_EVIDENZ_NO_FLASH.zip'): self.assertIn("'" + n + "'", pre)
        self.assertIn("'" + SHA287 + "' 'SV04_NEXT_287.zip'", pre); self.assertIn('MISSING', pre); self.assertIn('BAD_HASH', pre); self.assertIn('Do NOT rename another file', pre)
        for bad in (' mv ', ' cp ', 'ln -s', 'sed -i', 'unzip -q'): self.assertNotIn(bad, pre, 'der Preflight veraendert nichts')

    def test_W802_route_b_never_touches_the_287_package_and_reproduces_309_only_from_the_pinned_patch_with_eleven_file_pins(self):
        self.assertEqual(list(self.db['jobs']), ['control_309_original', 'modified_318_c6', 'evaluate_builds'])
        for bad in ('SV04_NEXT_287', 'point1', 'integrate_286', 'planner289', 'planner290', 'work309', 'integrate_308', 'preflight'): self.assertNotIn(bad, self.tb)
        for j in ('control_309_original', 'modified_318_c6'):
            r = dict(self.runs(self.db, j))['Reproduce 309 from the recorded combined_308.patch (ROUTE B - without the 287 package; a DIFFERENT route than the original 309 build)']
            self.assertIn(PATCH + '  c318/combined_308.patch', r); self.assertEqual(r.count('  oem/Marlin/src/'), 11); self.assertIn('git -C oem apply --check', r); self.assertIn('test -z "$(git -C oem status --porcelain)"', r); self.assertIn('-eq 15', r); self.assertIn('set -euo pipefail', r)
            self.assertLess(r.index('apply --check'), r.index('git -C oem apply --whitespace'), 'erst pruefen, dann anwenden')
        self.assertIn('ROUTE_B_309_REPRODUCED_FROM_PATCH_UNMODIFIED_CONTROL', self.tb); self.assertIn('ROUTE_B_MODIFIED_318_NEW_COPY_OF_PATCH_REPRODUCED_309', self.tb); self.assertNotIn("'SOURCE_BASE=ORIGINAL_309_UNMODIFIED_CONTROL'", self.tb)

    def test_W803_both_routes_keep_the_strict_installer_the_separate_build_trees_valid_bash_and_no_flash_command(self):
        for t, d, pref, n8 in ((self.ta, self.da, 'SV04_C8A_', 4), (self.tb, self.db, 'SV04_C8B_', 3)):
            self.assertEqual(t.count(SHA8 + '  SV04_NEXT_CLAUDE_C8_BUILD_EVIDENZ_NO_FLASH.zip') + t.count("'" + SHA8 + "' 'SV04_NEXT_CLAUDE_C8"), n8); self.assertIn('c8pkg/02_PATCHES/integrate_318_strict.py c318 oem oem318', t); self.assertNotIn('c318/integrate_318.py', t)
            self.assertIn(f'pattern: {pref}*_STM32_LOGS_NO_FLASH', t); self.assertIn('pio run -d oem -e', t); self.assertIn('pio run -d oem318 -e', t); self.assertNotIn('c7pkg', t); self.assertNotIn('SV04_C7_', t)
            for bad in ('upload-binary', 'st-flash', 'dfu-util', 'openocd', '-t upload', 'pio run -t clean'): self.assertNotIn(bad, ''.join(l for l in t.splitlines() if not l.lstrip().startswith('#')))
            for j in d['jobs']:
                for name, r in self.runs(d, j):
                    p = Path(tempfile.mkdtemp()) / 's.sh'; p.write_text(r); self.assertEqual(subprocess.run(['bash', '-n', str(p)], capture_output=True).returncode, 0, j + ': ' + name)

    def test_W804_the_generator_refuses_bad_input_and_a_changed_source_workflow(self):
        self.assertEqual(gen('c')[0].returncode, 2); self.assertEqual(gen('a', sha8='zz')[0].returncode, 2); self.assertEqual(gen('b', patch=None)[0].returncode, 2); self.assertEqual(gen('b', patch='12')[0].returncode, 2); self.assertEqual(gen('a', sha318='0' * 64)[0].returncode, 2)
        x = Path(tempfile.mkdtemp()) / 'x.yml'; x.write_text(C7.read_text().replace('Verify packages and unpack', 'Etwas anderes')); self.assertEqual(gen('a', src=x)[0].returncode, 2); self.assertEqual(gen('b', src=x)[0].returncode, 2)


def make_zip(path, members):
    with zipfile.ZipFile(path, 'w') as z:
        for n, b in members.items(): z.writestr(n, b)


class Inputs(unittest.TestCase):
    def setUp(self):
        self.d = Path(tempfile.mkdtemp()); self.a = b'a-zip'; make_zip(self.d / 'A.zip', {'tool/run.py': 'x'}); make_zip(self.d / 'B.zip', {'readme.txt': 'y'})
        ha, hb = (hashlib.sha256((self.d / n).read_bytes()).hexdigest() for n in ('A.zip', 'B.zip'))
        self.wf = self.d / 'w.yml'; self.wf.write_text(f"echo '{ha}  A.zip' | sha256sum -c -\necho '{hb}  B.zip' | sha256sum -c -\nunzip -q A.zip -d adir\npython3 adir/run.py\n")
        self.ha, self.hb = ha, hb

    def run_(self): r = subprocess.run([sys.executable, '-B', str(VER), str(self.wf), str(self.d)], capture_output=True, text=True); return r.returncode, r.stdout

    def test_I801_all_inputs_present_with_exact_hash_and_referenced_members_pass(self):
        rc, out = self.run_(); self.assertEqual(rc, 0, out); self.assertIn('ALLE_EINGABEN_OK', out); self.assertIn("['run.py']", out)

    def test_I802_a_missing_file_is_missing_and_a_similar_file_is_never_used_as_a_substitute(self):
        (self.d / 'B.zip').rename(self.d / 'B_umbenannt.zip'); rc, out = self.run_(); self.assertEqual(rc, 3); self.assertIn('MISSING', out); self.assertIn('B.zip', out); self.assertIn('NICHT als Ersatz', out); self.assertIn('B_umbenannt.zip', out)

    def test_I803_a_wrong_hash_is_bad_hash_even_if_the_name_is_right(self):
        make_zip(self.d / 'B.zip', {'readme.txt': 'anderer inhalt'}); rc, out = self.run_(); self.assertEqual(rc, 3); self.assertIn('BAD_HASH', out); self.assertIn(self.hb, out)

    def test_I804_a_referenced_member_missing_in_a_hash_correct_archive_is_bad_struct(self):
        make_zip(self.d / 'A.zip', {'andere/datei.py': 'x'}); self.wf.write_text(self.wf.read_text().replace(self.ha, hashlib.sha256((self.d / 'A.zip').read_bytes()).hexdigest())); rc, out = self.run_(); self.assertEqual(rc, 3); self.assertIn('BAD_STRUCT', out); self.assertIn("['run.py']", out)


if __name__ == '__main__':
    unittest.main(verbosity=2)
