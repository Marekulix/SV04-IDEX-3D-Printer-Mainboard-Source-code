"""Fuehrt die C++-Kerntests (ECHTER Koordinator, Testwelt mit EEPROM-Modell) streng uebersetzt aus und prueft Mindestanzahl und Gruppen."""
import re
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class CoreTests(unittest.TestCase):
    def test_K01_all_cpp_core_tests_pass_under_strict_compilation(self):
        exe = Path(tempfile.mkdtemp()) / 't'
        cc = subprocess.run(['g++', '-std=c++11', '-O2', '-Wall', '-Wextra', '-Werror', '-pedantic', '-I', str(ROOT), str(ROOT / '04_TESTS/core/test_auto60_core.cpp'), '-o', str(exe)], capture_output=True, text=True)
        self.assertEqual(cc.returncode, 0, cc.stderr[-2000:])
        r = subprocess.run([str(exe)], capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, '\n'.join(l for l in r.stdout.splitlines() if l.startswith(('FAIL', '  FEHLER'))))
        m = re.search(r'SUMMARY tests=(\d+) pass=(\d+) fail=(\d+)', r.stdout)
        n, p, f = map(int, m.groups())
        self.assertEqual((p, f), (n, 0))
        self.assertGreaterEqual(n, 120)
        groups = {}
        for l in r.stdout.splitlines():
            if l.startswith('PASS '):
                groups.setdefault(l.split()[1][0], 0)
                groups[l.split()[1][0]] += 1
        self.assertEqual(set(groups), set('ABCDEFGJK'), 'Gruppen: A Start, B Heizung, C G28-Schnittstelle, D Messung, E Persistenz, F Abbruch, G Robustheit, J Undo-Journal und unabhaengige Rohlesung (283), K Speichern ueberspringen (283)')
        print('KERNTESTS: %d bestanden, Gruppen %s' % (n, dict(sorted(groups.items()))))

    def test_K02_the_eeprom_core_tests_pass_under_strict_compilation_and_cover_the_required_groups(self):
        exe = Path(tempfile.mkdtemp()) / 't'
        cc = subprocess.run(['g++', '-std=c++11', '-O2', '-Wall', '-Wextra', '-Werror', '-pedantic', '-I', str(ROOT), str(ROOT / '04_TESTS/core/test_eeprom_core.cpp'), '-o', str(exe)], capture_output=True, text=True)
        self.assertEqual(cc.returncode, 0, cc.stderr[-2000:])
        r = subprocess.run([str(exe)], capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, '\n'.join(l for l in r.stdout.splitlines() if l.startswith(('FAIL', '  FEHLER'))))
        n, p, f = map(int, re.search(r'SUMMARY tests=(\d+) pass=(\d+) fail=(\d+)', r.stdout).groups())
        self.assertEqual((p, f), (n, 0)); self.assertGreaterEqual(n, 33)
        ids = {l.split()[1] for l in r.stdout.splitlines() if l.startswith('PASS ')}
        for need in ('EE01', 'EE10', 'EE20', 'EE31', 'EE40', 'EE42', 'EE43', 'EE44', 'EE45', 'EE46'):
            self.assertIn(need, ids, need)
        print('EEPROM-KERNTESTS: %d bestanden' % n)

if __name__ == '__main__':
    unittest.main(verbosity=2)
