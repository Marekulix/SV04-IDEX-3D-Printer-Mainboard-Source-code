# Ergebnisbericht SV04 NEXT: Claude parallel (Auto60 → G29 → Mesh → M420 → M500 → Rücklesung → DWIN)

**Kein Flash, kein Hardwaretest, kein STM32-Build.** Alles unten ist Host-Simulation um die echte `G29.cpp` und gelesene OEM-Quellen. Keine Firmware-Freigabe. Ich verändere Ihre Fortschrittsanzeige **nicht** und nenne keine Prozentwerte.

## 1. Was tatsächlich gebaut und geprüft ist
- **Koordinator** (`sv04_claude_auto60_core.h`): 12 Zustände (IDLE, HEATING, STABILIZING, HOMING_PENDING, PROBING, VALIDATING, ENABLING, SAVE_PENDING, VERIFYING, SUCCESS, FAILED, CANCELLED), jeder Wechsel mit Sitzungs-ID, Grund und Zeit. Fail-closed: fehlender Nachweis → FAILED, nie SUCCESS.
- **Marlin-Adapter** (`sv04_claude_auto60_marlin.inc`): benutzt nur Symbole, die in den echten Dateien belegt sind (56 verifizierte Fundstellen, `07_AUDIT/A01_QUELLENINVENTAR.md`); G29-Haken; DWIN über den vorhandenen Sendeweg; passive G28/IDEX-Schnittstelle (`SV04Claude_HomeBackendRequest` / `…HomeResult`).
- **Patchwerkzeug** (`apply_claude_parallel.py`): nur **Einfügungen** in `G29.cpp` (+20), `LCD_RTS.cpp` (+14), `gcode.cpp` (+7), 0 Zeilen entfernt; `G28.cpp`, `motion.cpp/.h`, `probe.cpp` unberührt. Reproduzierbar (`03_PATCHES/*.patch`, mit `patch(1)` und reinem Python hashgleich).
- **Tests** (alle bestanden, Rohlogs in `06_EVIDENCE/host/`): **126 C++-Kerntests** über den echten Koordinator (Start-/Heiz-/Homing-/Mess-/Persistenz-/Abbruch-/Robustheitssequenzen, Positiv/Negativ/Grenzwert, Fehlerinjektion) und **80 Python-Tests** (Kettensimulation mit echter gepatchter `G29.cpp`, DWIN-Rohframes, strenge Übersetzung in 16 Konfigurationen, Patch-/Workflow-Prüfungen, Mutationstests); insgesamt **206** verschiedene Tests (ein Wrapper-Test führt die 126 Kerntests erneut aus und ist nicht mitgezählt).
- **Mutationstests**: Kern **24/24 erkannt** (+1 begründet gleichwertig), Adapter **13/13 erkannt** (+1 begründet gleichwertig); kein überlebender Mutant.
- **Audit** (`07_AUDIT/ANFORDERUNGEN_STATUS.csv`): 49 Zeilen, **29 PASS, 20 BLOCKED, 0 FAIL**. Jede PASS-Zeile ist an Tests gebunden, die im Rohlog bestanden stehen (der Generator setzt sonst automatisch FAIL).

## 2. Befunde aus dem echten Code (ändern Ihre Annahmen)
Siehe `07_AUDIT/KONFLIKTE_UND_OFFEN.md` A.1–A.6. Die wichtigsten: **`save()` ist nicht atomar** (alter EEPROM-Inhalt wird bei einem Abbruch ungültig), **`G29` schaltet die Nivellierung selbst ein** (G29.cpp:883) und führt **`G28 XY`** aus, die Platine ist laut Konfiguration **`BOARD_CREALITY_V4`** mit I²C-EEPROM, die „Baseline 275" besteht nur aus Patchskripten für `G28.cpp`/`motion.*` (42 String-Tests in 0,002 s).

## 3. Während der Entwicklung gefundene und behobene Fehler
| # | Fehler | Gefunden durch | Behebung |
|---|---|---|---|
| 1 | Prüfung „M420 aktiv?" wäre wertlos gewesen: die OEM-G29 hatte die Nivellierung schon eingeschaltet | Fehlerszenarien der Kettensimulation | Nivellierung nach der G29 wieder aus, Aktivierung nur in `ENABLING`; Tests `S01b`, `S01c`, Mutant A01 |
| 2 | Tick lief mitten im G29-Abschluss-Haken (`synchronize()` → `idle()`), Rollback sah einen scheinbar „gleichen" Zustand | Kettensimulation (S22) | Sperrabschnitt `Sv04cSection`; Mutant A02 |
| 3 | Beim Abbruch erschien die Fehlerseite **vor** der Display-Wiederherstellung (veraltete Zahlen sichtbar) | Rohdatenstrom-Test (V09) | erst Mesh+Display zurücksetzen, dann Ergebnis melden; Mutant A04b |
| 4 | Ein ungültiges, von der G29 aber akzeptiertes Mesh (z. B. 12 mm) blieb im RAM | Szenario S22 | Rollback-Port im Koordinator + erzwungener Rollback im Abschluss-Haken |
| 5 | Nach der Ablehnung wurde der Nivellierungszustand nicht auf „vor dem Lauf" zurückgesetzt | Szenario S24b (Ausgangszustand aus) | Zustand wird gesichert und wiederhergestellt; Mutant A03 |
| 6 | Wiederholung von `save()` auch bei reinem Nivellierungsproblem (EEPROM war in Ordnung) | Kerntest E17 | Wiederholung nur bei zweifelhaftem EEPROM-Inhalt; Mutant C16 |
| 7 | Abbruch hätte eine laufende Wiederherstellung nach einem fehlgeschlagenen `save()` beenden können (EEPROM bliebe ungültig, Meldung „CANCELLED") | Entwurfsprüfung, Test F07 | nach dem ersten `save()` wirkt kein Abbruch mehr; Mutant C14 |
| 8 | Sofortige G29-Ablehnung („nicht gehomed") hätte den Koordinator bis zum 15-min-Timeout warten lassen | Entwurfsprüfung, Tests D25/D26 | Frist `g29_begin_grace_ms`; Mutant C18 |
| 9 | Zwei Testlücken (Mesh-Änderung zwischen Aktivierung und Speichern; nur der Z-Offset weicht im EEPROM ab) | Mutationstest (C05, C08) | neue Tests E29, E30 |
| 10 | Eigene Testfehler (zu schwache Grenzwerttests D09/D27, falsche Erwartungen, Zählfehler, doppelt definierter Mutant) | Testläufe | korrigiert; nichts davon betraf den Kern |

## 4. Wiederverwendet aus meiner früheren Lieferung (194–196), nicht neu
Siehe `01_BASELINE/CARRYOVER_FROM_194_196.json`: die G29-Sitzungslogik (`sv04_claude_g29_session.h`), Hilfsfunktionen des Patchwerkzeugs (Kommentar-/`#if 0`-Erkennung, Klammertiefe, Ankersuche, OEM-Sendeschleife) und die Simulationsumgebung (umbenannt, erweitert). Neu sind Koordinator, Adapter, Haken, die Anker für `LCD_RTS.cpp`/`gcode.cpp`/Punkt-Haken, alle Kern-, Ketten-, DWIN-, Strikt- und Mutationstests, Katalog, Inventar und Audit.

## 5. Was bewusst nicht behauptet wird
STM32-Build, echter Persistenzpfad, Hardwareverhalten, HMI-Darstellung, physischer G29-Stopp, farbige Karte/Cancel-Taste/Texte: **BLOCKED** (Gründe und benötigte Eingaben in `KONFLIKTE_UND_OFFEN.md`). Auto60 startet auf der Firmware erst, wenn ChatGPTs Backend vorhanden ist (fail-closed).

## 6. Quell-Hashes (SHA-256)
`sv04_claude_auto60_core.h` `690c4ac87dc400fd28d1585e43ae424fe5b8e3b3220feab6b9fefa04aee4fa5c`
`sv04_claude_auto60_marlin.inc` `e2a9d7dbccc10a6171548a4648ec5370f0606f8409519614c41244f5b931ebcf`
`sv04_claude_hooks.h` `9446a91733b2a02d964d82d2749b7648cc2dff23006aef76112e8dbbb82304e7`
`sv04_claude_g29_session.h` `d616c3e94826ffaac50e5e43fa842a53f17a091ff24537433edc8ce1c8afa250`
`apply_claude_parallel.py` `dc7ca87db3f267c4a03f02ed0d153b5154c25b74e6f3b4db773d11b0b69bb14f`
Vollständiges Manifest: `MANIFEST_SHA256.json`. Original-Commit laut Auftrag: `1867fcba75354a5c65e0631d6972dd19f1bd6cbe` (ohne Netz nicht prüfbar; die CI-Vorlage prüft ihn).
