# Integrationsanleitung für ChatGPT (Punkt 1: IDEX + BLTouch)

Dieses Paket trägt **keine** SV04-NEXT-Nummer (kein 276). Sie nummerieren die Integration neu.

## 1. Reihenfolge
1. Paket entpacken, `python3 tools/verify_manifest.py .` (muss `ALLES STIMMT` melden), dann `python3 tools/run_all_tests_a60.py` (ca. 1,5 Minuten; Python 3.8+, g++, PyYAML, optional `patch`). Erwartung: `ALLE TESTS BESTANDEN`.
2. Ihren OEM-Stand mit Ihren G28/IDEX-Patches (268–275 …) herstellen. Mein Overlay ändert **keine** dieser Dateien und kann danach angewendet werden:
   ```
   python3 03_PATCHES/apply_claude_parallel.py --lcd-oem Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp \
       --g29-oem Marlin/src/gcode/bedlevel/abl/G29.cpp --gcode-oem Marlin/src/gcode/gcode.cpp \
       --out patched_claude --source-root 02_SOURCE --report patch_claude_report.json
   cp -r patched_claude/Marlin/src/. Marlin/src/
   ```
   Das Werkzeug schreibt nie in die Eingaben, lehnt ein zweites Anwenden ab und bricht bei verändertem Anker ab (nichts wird geschrieben).
3. **Backend bereitstellen** (Ihr Teil): `SV04Claude_HomeBackendRequest(sid)` und nach Abschluss `SV04Claude_Auto60_HomeResult(sid, success, idex_gate_confirmed)` (Vertrag: `07_AUDIT/INTEGRATION_CONFLICTS.md` §4). Dann mit `-DSV04_CLAUDE_HOME_BACKEND_AVAILABLE=1` bauen.
4. Bauen mit den Profilen aus `05_BUILD/claude_parallel_build.yml` (Vorlage, nie ausgeführt) und die Nachweise sichern (Commit, Hashes, Log, RAM/Flash).
5. Erst danach `07_AUDIT/HARDWARE_ABNAHMEPLAN.md`.

## 2. Was Sie prüfen sollten
- **G29-Endskript `G28 XY`** (Befund, `INTEGRATION_CONFLICTS.md` §3): Ist dieses G28 mit Ihrem IDEX-Gate verträglich, auch mitten in Auto60?
- Wo wird `RTSUpdate()` aufgerufen (`MarlinCore.cpp` lag mir nicht vor)? Der Tick sitzt am Anfang von `RTSUpdate()`.
- Ob die Umgebung `LCD_RTS.cpp` überhaupt baut (siehe `BUILD_STATUS.md`).

## 3. Testharness erweitern
`04_TESTS/sim/driver_chain.cpp` stellt das G28/IDEX-Backend als Test-Double dar (`home=ok|fail|nogate|wrongext|noz|zoffs|reject|never`). Wenn Ihr Backend verfügbar ist, bildet das Double dessen Verhalten nach und die Tests `S11`–`S17` und `C01`–`C15` sichern die Schnittstelle weiter ab.

## 4. Merge-Punkte
Nur Einfügungen an Textankern in `G29.cpp`, `LCD_RTS.cpp`, `gcode.cpp` (Tabelle in `INTEGRATION_CONFLICTS.md` §2). Ändern Sie diese Stellen, passen Sie die Anker in `apply_claude_parallel.py` an; die Ankertests (`P05`) zeigen, welche Stelle betroffen ist.
