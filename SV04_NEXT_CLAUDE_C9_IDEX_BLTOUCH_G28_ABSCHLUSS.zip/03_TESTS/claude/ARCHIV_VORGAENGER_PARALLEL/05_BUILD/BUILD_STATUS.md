# Build-Status

| Punkt | Status |
|---|---|
| STM32-Build (PlatformIO `STM32F103RET6_creality`) | **BLOCKED** (keine ARM-Toolchain, kein PlatformIO, kein Netz; kein vollständiger Marlin-Baum) |
| Baseline-Build der unveränderten OEM | **BLOCKED** (ebenso) |
| GitHub-Actions-Lauf | **NOT RUN** (`claude_parallel_build.yml` ist eine Vorlage, nur auf Struktur geprüft, Test `B04`–`B06`) |
| RAM/Flash/SHA256 der Firmware | **nicht vorhanden** |
| `git diff --check` | wird im Workflow ausgeführt (NOT RUN) |
| Strenge Host-Übersetzung (`-Wall -Wextra -Werror`) von Kern, Session und Adapter in **16 Konfigurationskombinationen** | bestanden (`test_strict_a60.py`); **kein** Build-Nachweis |
| Keine neuen Compiler-Warnungen an der echten `G29.cpp` durch den Patch (Host, gcc) | bestanden (`X04`) |
| Statischer RAM (Host, 64 Bit; auf dem 32-Bit-STM32 kleiner) | Coordinator 1176 B, Mesh-Sitzung 332 B, G29-Sitzung 316 B, Config 64 B (`X06`) |

Profile der Workflow-Vorlage: `default_failclosed` (Auto60 kompiliert, Backend fehlt → startet nie), `backend_stub` (nur Link-Test mit einem **Test-Double**, das jede Anforderung ablehnt), `oem_equivalent` (Auto60 aus, kein Rollback, keine Live-Sperre), `ram_only` (kein erneutes Senden an das Display).

Offene Build-Risiken (Annahmen, nicht belegt): C++-Standard/Toolchain-Version des Ziels (die Header sind streng als C++11 übersetzt), Verfügbarkeit von `isfinite` in der Ziel-Toolchain, ob die Umgebung `LCD_RTS.cpp` kompiliert (der `common`-Abschnitt von `platformio.ini` schließt `src/lcd/e3v2/creality` per `-<…>` aus; der alte 275-Log zeigt aber `LCD_RTS.cpp.o`, die Umgebungsdefinition liegt in keiner Upload-Datei).
