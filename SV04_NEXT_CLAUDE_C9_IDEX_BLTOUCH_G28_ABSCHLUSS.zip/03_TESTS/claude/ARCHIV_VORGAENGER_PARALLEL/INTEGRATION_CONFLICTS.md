# Integrationskonflikte und Schnittstellenvertrag mit ChatGPT (Punkt 1: IDEX + BLTouch)

## 1. Gesperrte Dateien: unberührt
`G28.cpp`, `motion.cpp`, `motion.h`, T1-Parklogik, `BLTouch::deploy_proc` werden von diesem Paket **nicht** geändert (Test `P02`, `B03`). Ein „Minimaldiff" für diese Dateien ist **nicht nötig**; es gibt daher keinen.
Die ChatGPT-Patches 268–275 ändern genau `G28.cpp`, `motion.h`, `motion.cpp` (Skripte in `SV04_NEXT_275.zip`). Mein Adapter liest dort nur OEM-Symbole (`axis_is_trusted`, `active_extruder`, `dual_x_carriage_mode`, `extruder_duplication_enabled`), keine `sv04_p1_*`-Variablen.

## 2. Gemeinsam betroffene Dateien (OEM-basierter Diff, Merge-Punkte)
Nur **Einfügungen**, jeweils an einem Textanker. Ändert ChatGPT diese Stellen, bricht das Patchwerkzeug fail-closed ab (nichts wird geschrieben).

| Datei | Anker (Einfügung) | Umfang |
|---|---|---|
| `gcode/bedlevel/abl/G29.cpp` | nach dem `LCD_RTS.h`-Include; nach `if (homing_needed_error()) G29_RETURN(false);`; nach `const ProbePtRaise raise_after…`; nach `TERN_(EXTENSIBLE_UI, ExtUI::onMeshUpdate(abl.meshCount, z));`; um die OEM-Live-Sendezeile (OEM-Zeile bleibt byte-identisch im `#else`); vor `RTS_AutoBedLevelPage();` | +20 Zeilen, 0 entfernt |
| `lcd/e3v2/creality/LCD_RTS.cpp` | nach `#include "LCD_RTS.h"`; am Anfang von `RTS_HandleData()` (Touch-Sperre); am Anfang von `RTSUpdate()` (Tick); vor `void RTS_AutoBedLevelPage()` (Adapter) | +14 Zeilen, 0 entfernt |
| `gcode/gcode.cpp` | nach `#include "../MarlinCore.h"`; vor `default:` des M-Schalters (`M1060`) | +7 Zeilen, 0 entfernt |

`probe.cpp` wird **nicht** geändert.

## 3. Befund, der ChatGPTs G28-Zweig betrifft
`G29.cpp` führt am Ende `Z_PROBE_END_SCRIPT` aus (`Configuration.h`: `"G28 XY"`), also ein **G28 XY innerhalb jeder G29**, auch innerhalb der Auto60-Messung. Dieses G28 läuft über ChatGPTs G28/IDEX-Logik. Auto60 hat darauf keinen Einfluss und prüft danach nur den Zustand (Z/X/Y vertraut, T0, Modus). Ob G28 XY nach der Messung mit dem IDEX-Gate verträglich ist, muss ChatGPT beurteilen.

## 4. Schnittstellenvertrag (passiv)
```cpp
// Von ChatGPT zu implementieren, wenn SV04_CLAUDE_HOME_BACKEND_AVAILABLE=1 gesetzt wird:
bool SV04Claude_HomeBackendRequest(const uint32_t sid);   // true = Anforderung angenommen (sichere Referenzfahrt wird ausgeführt)
// Von ChatGPTs Zweig nach Abschluss aufzurufen (aus der Hauptschleife, nie aus einer ISR):
void SV04Claude_Auto60_HomeResult(const uint32_t sid, const bool success, const bool idex_gate_confirmed);
```
- `idex_gate_confirmed` darf nur `true` sein, wenn ChatGPTs Prüfung (T1 geparkt, Kollisionsfreiheit, BLTouch-Freigabe) **tatsächlich bestanden** hat. Auto60 behauptet das nie selbst.
- Achs-Vertrauen X/Y/Z, `active_extruder==0`, IDEX-Modus (Full Control oder Auto Park), Duplizierung aus liest der Adapter **selbst** aus dem Marlin-Zustand.
- Ohne Backend (Standard) lehnt Auto60 den Start ab (`PRE_HOME_BACKEND_MISSING`) und selbst eine erzwungene Anforderung wird abgelehnt (zwei unabhängige Sperren).
- Der Z-Offset (`probe.offset.z`) darf während des Homings nicht verändert werden, sonst `HOME_ZOFFSET_CHANGED`.
- Anregung (ungeprüft): ChatGPTs Zweig könnte `idex_gate_confirmed` aus seinen eigenen Abschlussvariablen (`sv04_p1_t1_x_completed`, `sv04_p1_z_completed`) ableiten.

## 5. Weitere mögliche Kollisionen
- **M-Code `M1060`**: frei in diesem Baum (belegt: 1000, 1001, 1002, 1004). Falls ChatGPT dieselbe Nummer vergibt, bitte abstimmen.
- **Touch-Sperre**: `RTS_HandleData()` wird während eines Auto60-Laufs übersprungen. Das schließt auch den OEM-Stopp per Touch aus (kein Abbruchknopf, siehe `KONFLIKTE_UND_OFFEN.md`).
- **`waitway`**: Auto60-eigene G29 setzt `waitway=0` vor dem OEM-Seitenwechsel, damit `RTS_AutoBedLevelPage()` keine „fertig"-Seite zeigt.
