#!/usr/bin/env python3
"""A20 Abschlussaudit: erzeugt 07_AUDIT/ANFORDERUNGEN_STATUS.csv. Jede Anforderung einzeln PASS / FAIL / BLOCKED mit Test-ID, Quellstelle (Datei:Zeile, aus den echten Dateien gesucht), Build-Hash, Logzeile.
Ein referenzierter Test, der im Rohlog nicht als bestanden steht, setzt die Zeile AUTOMATISCH auf FAIL (und der Exitcode ist 1): kein Erfolg ohne Log.
Evidenzebene: HOST_SIM = Host-Simulation (Stubs um die echte G29.cpp), STATIC = Quelltext-Inventar, NONE = keine. Es gibt KEINEN Firmware-Build-Hash (STM32-Build BLOCKED)."""
import csv
import hashlib
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
H = ROOT / '06_EVIDENCE' / 'host'
CORE = '02_SOURCE/Marlin/src/feature/sv04_claude_auto60/sv04_claude_auto60_core.h'
G29S = '02_SOURCE/Marlin/src/feature/sv04_claude_auto60/sv04_claude_g29_session.h'
INC = '02_SOURCE/Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc'
HOOKS = '02_SOURCE/Marlin/src/lcd/e3v2/creality/sv04_claude_hooks.h'
O = '01_BASELINE/OEM_FILES/Marlin/'
G29 = O + 'src/gcode/bedlevel/abl/G29.cpp'
SETC = O + 'src/module/settings.cpp'
LCDC = O + 'src/lcd/e3v2/creality/LCD_RTS.cpp'
LCDH = O + 'src/lcd/e3v2/creality/LCD_RTS.h'
CONF = O + 'Configuration.h'
BLC = O + 'src/HAL/STM32F1/eeprom_bl24cxx.cpp'


def sha(p):
    return hashlib.sha256((ROOT / p).read_bytes()).hexdigest()[:12]


def line_of(path, needle):
    for i, l in enumerate((ROOT / path).read_text(encoding='utf-8', errors='replace').split('\n'), 1):
        if needle in l:
            return f'{path.split("/")[-1]}:{i}'
    raise SystemExit(f'Quellstelle nicht gefunden: {path} :: {needle}')


def load_logs():
    cpp = {}
    for l in (H / '01_core_tests_cpp.txt').read_text().splitlines():
        m = re.match(r'(PASS|FAIL) (\w+) (.*)', l)
        if m:
            cpp[m.group(2)] = (m.group(1), l)
    py = {}
    for f in ('02_unittest_04_TESTS.txt', '03_unittest_04_TESTS_sim.txt'):
        lines = (H / f).read_text().splitlines()
        for i, l in enumerate(lines):
            m = re.match(r'(test_\w+) \(', l)
            if m:
                seg = ' '.join(lines[i:i + 3])
                st = 'ok' if re.search(r'\.\.\. ok\b', seg) else 'NOT_OK'
                py[m.group(1)] = (st, (l + ' ... ' + st)[:160])
    return cpp, py


# (id, anforderung, status, evidenz, [tests], [(pfad, suchtext)], einschraenkung)
def C(*ids): return ['C++:' + i for i in ids]
def P(*pre): return ['py:' + p for p in pre]


ROWS = [
 ('R-01', 'Ablaufkette 1: Start nur bei nachweislichem Idle/erlaubtem Zustand; G28/IDEX nur ueber kleine Schnittstelle', 'PASS', 'HOST_SIM',
  C(*[f'A{n:02d}' for n in range(1, 14)], 'G09') + P('S03_', 'S04_', 'S05_', 'S06_', 'S07_', 'S08_', 'S09_', 'S10_'), [(CORE, 'Reason start()'), (INC, 'p.home_backend_available'), (HOOKS, 'SV04_CLAUDE_HOME_BACKEND_AVAILABLE')],
  'Auf der Firmware startet Auto60 erst, wenn ChatGPTs Backend SV04Claude_HomeBackendRequest bereitstellt (Standard SV04_CLAUDE_HOME_BACKEND_AVAILABLE=0: fail-closed). Heizungsfehler-Fahne ist in Marlin nicht abfragbar (kill() bei Fehler).'),
 ('R-02', 'Ablaufkette 2: Bett exakt 60 C, Stabilitaetsbedingung, Timeout, Temperaturfehler', 'PASS', 'HOST_SIM', C(*[f'B{n:02d}' for n in range(1, 16)], 'A17') + P('S25_', 'S26_', 'S27_'), [(CORE, 'bool heater_ok('), (INC, 'thermalManager.setTargetBed')],
  'Thermik ist ein einfaches Modell (keine Regelung). Fenster +-1 K, Haltezeit 30 s, Aufheiz-Timeout 15 min sind VORSCHLAEGE (Config::defaults) und vom Eigentuemer zu bestaetigen.'),
 ('R-03', 'Ablaufkette 3: Vor Z-Referenzfahrt IDEX/BLTouch-Freigabe anfordern, G28 in OEM-Routine, Z-Offset unveraendert', 'BLOCKED', 'HOST_SIM', C(*[f'C{n:02d}' for n in range(1, 16)]) + P('S11_', 'S12_', 'S13_', 'S14_', 'S15_', 'S16_', 'S17_'),
  [(HOOKS, 'SV04Claude_HomeBackendRequest'), (HOOKS, 'SV04Claude_Auto60_HomeResult'), (INC, 'sv04c_home_request')],
  'Schnittstelle, Nachweisauswertung und fail-closed sind getestet (Backend = Test-Double). Das ECHTE G28/IDEX-Backend gehoert ChatGPT und liegt nicht vor: ohne es kann die Referenzfahrt nicht ausgeloest werden.'),
 ('R-04', 'Ablaufkette 4: G29 16/16 Punkte, nachgewiesene Reihenfolge; Sollkoordinaten, Rohwert, Einheiten, Punktnummer, Session-ID', 'PASS', 'HOST_SIM', C(*[f'D{n:02d}' for n in range(1, 29)]) + P('S01_', 'S24_', 'V03_', 'V06_'),
  [(CORE, 'inline unsigned point_no'), (CORE, 'class MeshSession'), (G29, 'z_values[abl.meshCount.x][abl.meshCount.y] = z;')], 'Sonde/BLTouch ist ein Stub; Koordinaten und Reihenfolge entstehen aus der ECHTEN G29.cpp. Punktnummer wird aus (x,y) abgeleitet und mit der Ankunftsfolge verglichen.'),
 ('R-05a', 'Ablaufkette 5: G29-Fehler/Abbruch/Timeout: Session ungueltig, kein M420, kein M500, EEPROM unberuehrt, RAM-Mesh/Display/Nivellierung zurueckgesetzt', 'PASS', 'HOST_SIM',
  C('D13', 'D14', 'D15', 'D20', 'D21', 'E18', 'E19', 'E20', 'E23', 'E24', 'F04', 'F01', 'F02', 'F03') + P('S18_', 'S19_', 'S20_', 'S21_', 'S22_', 'S23_', 'S24b_', 'S29_', 'S30_', 'S31_', 'S32_', 'S43_', 'V09_'),
  [(INC, 'sv04c_rollback_mesh'), (INC, 'void SV04Claude_G29Complete'), (G29S, 'class Session')], 'Rollback getestet mit der ECHTEN G29.cpp in der Host-Simulation; Rollback = RAM + Display + Nivellierungszustand.'),
 ('R-05b', 'Ablaufkette 5: laufende OEM-G29 physisch unterbrechen', 'BLOCKED', 'HOST_SIM', P('S23_', 'S32_'), [(G29, 'G29_RETURN(isnan(abl.measured_z));')],
  'Die laufende G29 ist ohne Eingriff in Marlin-Kernlogik nicht unterbrechbar: sie laeuft zu Ende (probe=16), nur ihre Folgen werden gesperrt. Ein physischer Stopp waere ein Eingriff in G29/motion und ist laut Auftrag nicht erlaubt.'),
 ('R-06', 'Ablaufkette 6: M420 S1 erst nach vollstaendig validierter Sitzung; Status wirklich pruefen', 'PASS', 'HOST_SIM', C('E03', 'E04', 'E05', 'E06', 'E24') + P('S01_', 'S01b_', 'S01c_'), [(INC, 'static bool sv04c_m420'), (G29, 'planner.leveling_active = !abl.dryrun || abl.reenable;')],
  'BEFUND: die OEM-G29 schaltet die Nivellierung am Ende SELBST ein (G29.cpp:883); Auto60 schaltet sie bis zur Validierung wieder aus. M420.cpp liegt nicht vor: die Aktivierung ist set_bed_leveling_enabled(true) direkt.'),
 ('R-07a', 'Ablaufkette 7: Vor M500 alles pruefen (Kette vollstaendig, Mesh/Z-Offset unveraendert, keine Bewegung); alter Zustand bleibt bei jedem Fehler vor dem Speichern', 'PASS', 'HOST_SIM',
  C('E04', 'E05', 'E06', 'E07', 'E08', 'E09', 'E18', 'E19', 'E20', 'E25', 'E29') + P('S43_', 'S33_'), [(CORE, 'void do_save()')], 'Gilt fuer alle Fehler VOR save(). Siehe R-07b fuer Fehler WAEHREND save().'),
 ('R-07b', 'Ablaufkette 7: atomares / stromausfallsicheres Speichern des alten Zustands', 'BLOCKED', 'STATIC', C('E12') + P('S33_', 'S34_'), [(SETC, 'char ver[4] = "ERR";'), (SETC, 'EEPROM_WRITE(version);'), (BLC, 'bool PersistentStore::access_finish() { return true; }')],
  'BEFUND aus dem echten Code: save() schreibt zuerst "ERR" und erst am Ende Version+CRC; der Speicher (I2C 24C16) puffert nicht. Bei Stromausfall mitten im Speichern ist das ALTE EEPROM (auch der Z-Offset) ungueltig, load() faellt auf Standardwerte. Ohne Layoutaenderung (A/B-Kopie) oder Hardware nicht absicherbar.'),
 ('R-08a', 'Ablaufkette 8: unabhaengige Ruecklesung nach dem Speichern (validate + Ladepfad + Vergleich Werte/Z-Offset/Version/Groesse)', 'PASS', 'HOST_SIM', C('E01', 'E10', 'E11', 'E13', 'E14', 'E15', 'E16', 'E17', 'E21', 'E22', 'E30') + P('S01_', 'S33_', 'S34_', 'S35_', 'S36_', 'S37_'), [(INC, 'static bool sv04c_readback'), (CORE, 'void do_verify()')],
  'Getestet gegen ein EEPROM-MODELL mit der save()-Semantik (nicht gegen den echten settings.cpp-Code). SUCCESS nur nach bestandener Ruecklesung; "nicht verfuegbar" ist FAILED.'),
 ('R-08b', 'Ablaufkette 8: Ruecklesung ueber den ECHTEN Marlin-Pfad (settings.cpp/HAL) ausgefuehrt', 'BLOCKED', 'NONE', [], [(INC, 'settings.load()'), (SETC, 'bool MarlinSettings::validate() {')],
  'settings.cpp ist ohne vollstaendigen Marlin-Baum nicht uebersetzbar (Conditionals_LCD.h, boards.h, SanityCheck.h u. a. fehlen); keine Hardware. NICHT als PASS ausgeben.'),
 ('R-09a', 'Ablaufkette 9: DWIN Fortschritt 1-16 und tatsaechliche Messwerte ueber den echten Sendeweg (RTS_SndData)', 'PASS', 'HOST_SIM', P('V03_', 'V05_', 'V06_', 'V07_', 'V10_', 'V11_', 'V12_', 'V13_'), [(G29, 'rtscheck.RTS_SndData(z*1000'), (LCDH, '#define AUTO_BED_LEVEL_ICON_VP')],
  'Die ECHTE RTS_SndData wurde woertlich extrahiert und gegen den rohen Datenstrom geprueft. Dezimalstellen/Vorzeichenanzeige im HMI sind NICHT belegt (HMI-Binaerdateien fehlen).'),
 ('R-09b', 'Ablaufkette 9: DWIN Temperaturanzeige', 'BLOCKED', 'NONE', [], [(LCDC, 'void RTSUpdate()')], 'Wird vom OEM (EachMomentUpdate) gesendet und nicht von Auto60; der OEM-Pfad ist in der Simulation nicht abgebildet.'),
 ('R-09c', 'Ablaufkette 9: DWIN farbige 4x4-Messkarte', 'BLOCKED', 'NONE', [], [(LCDH, '#define AUTO_BED_LEVEL_1POINT_VP')], 'Braucht neue Grafikobjekte im HMI-Projekt; die HMI-Binaerdateien liegen nicht vor, es werden nur die 16 vorhandenen Zahlenfelder beschrieben.'),
 ('R-09d', 'Ablaufkette 9: DWIN Busy/Cancel-Bedienung', 'BLOCKED', 'HOST_SIM', P('S01_', 'S29_', 'S31_'), [(LCDC, 'void RTSSHOW::RTS_HandleData()')], 'Touch-Sperre waehrend des Laufs getestet (S01 BUSY). Eine Cancel-TASTE braucht ein neues HMI-Objekt: BLOCKED. Abbruch ueber M1060 S0 getestet.'),
 ('R-09e', 'Ablaufkette 9: DWIN Erfolg-/Fehlertexte', 'BLOCKED', 'HOST_SIM', P('V08_'), [(HOOKS, 'SV04_CLAUDE_PAGE_FAIL')], 'Es gibt kein belegtes Text-VP fuer Status; verwendet werden nur Seiten (38 Messung, 22 Erfolg, 28 Fehler). Seite 28 ist eine ANNAHME (HMI-Binaerdatei fehlt).'),
 ('R-09f', 'Ablaufkette 9: Display zeigt bei Fehler/Abbruch nie "fertig"', 'PASS', 'HOST_SIM', C('G04', 'G05', 'E14') + P('V08_', 'V09_', 'S18_', 'S32_'), [(INC, 'static void sv04c_display')], 'Seite 22 erscheint nur bei SUCCESS nach bestandener Ruecklesung. Seiten-IDs 28/38 sind HMI-Annahmen.'),
 ('R-10', 'Ablaufkette 10: Konfigurations-/Zeit-/Zustandsfehler, FAIL-CLOSED, Flashfreigabe NEIN', 'PASS', 'HOST_SIM', C('A14', 'A15', 'A16', 'G08', 'G10', 'G11') + P('S08_', 'S10_', 'P06_', 'P07_'), [(CORE, 'bool valid() const'), (HOOKS, 'SV04_CLAUDE_HOME_BACKEND_AVAILABLE')], 'Flash-/Hardwarefreigabe: NEIN.'),
 ('A01', 'Quelleninventar (Commit pinnen, 275-Basis und Artefakte SHA256, G29/G28/probe/temperature/settings/EEPROM-HAL/bedlevel/DWIN/M420-M503)', 'BLOCKED', 'STATIC', P('V01_', 'V02_'), [(SETC, 'bool MarlinSettings::save() {')],
  'PASS-Anteil: 56 Fundstellen maschinell verifiziert, 275-Hashes gegen MANIFEST_SHA256.json geprueft, G28-Blob stimmt mit dem 275-Skript. BLOCKED-Anteil: M420.cpp, M500-M504.cpp, M190_M109.cpp, MarlinCore.cpp, ini/*.ini fehlen; Commit 1867fcb ohne Netz nicht nachpruefbar.'),
 ('A02', 'Integrationsarchitektur: realer Marlin-Auto60-Koordinator mit 12 Zustaenden, Wechsel mit Grund und Session-ID', 'PASS', 'HOST_SIM', C('G03', 'G11') + P('S01_', 'X01_', 'X02_'), [(CORE, 'enum State'), (CORE, 'struct TransitionRec'), (INC, 'static sv04c::Coordinator sv04c_coord')], 'Der Koordinator ist Firmware-Quelltext (derselbe Header im Host-Test); er wurde NICHT fuer STM32 gebaut (siehe A17).'),
 ('A03', 'Start- und Konfliktsperren', 'PASS', 'HOST_SIM', C(*[f'A{n:02d}' for n in range(2, 14)], 'B12', 'B13', 'D16', 'D17', 'D18') + P('S03_', 'S04_', 'S05_', 'S06_', 'S07_', 'S28_'), [(CORE, 'Reason start()'), (INC, 'static void sv04c_precond')], 'DWIN-Touch wird waehrend des Laufs gesperrt (RTS_HandleData-Anker).'),
 ('A04', 'Heizbett 60 C: Stabilisierung, Timeout, Fehler, Abbruch; nicht "einmal kurz erreicht"', 'PASS', 'HOST_SIM', C('B02', 'B03', 'B04', 'B05', 'B06', 'B07', 'B08', 'B09', 'B10', 'B11', 'B14', 'B15', 'F01', 'F02') + P('S25_', 'S26_', 'S27_', 'S29_', 'S30_'), [(CORE, 'bool in_band(')], 'siehe R-02'),
 ('A05', 'G28-Schnittstelle: minimale verifizierbare Anforderung/Rueckmeldung; fehlender Nachweis blockiert', 'PASS', 'HOST_SIM', C('A11', 'C01', 'C04', 'C12', 'C15') + P('S08_', 'S12_'), [(HOOKS, 'SV04Claude_HomeBackendRequest'), (HOOKS, 'SV04Claude_Auto60_HomeResult')], 'Nur die Schnittstelle; das Backend ist gesperrt/ChatGPT (siehe R-03).'),
 ('A06', 'G29-Mesh-Sitzung: 4x4, Zellenpositionen, tatsaechliche Reihenfolge, Session-ID, keine Vermischung', 'PASS', 'HOST_SIM', C('D01', 'D02', 'D03', 'D04', 'D05', 'D11', 'D12', 'D24') + P('S01_', 'V03_'), [(CORE, 'class MeshSession')], 'Reihenfolge der OEM-G29: Zeile y=0 mit x absteigend (G29.cpp, PROBE_Y_FIRST aus).'),
 ('A07', 'Messwerte/Einheiten: Marlin-Einheiten, DWIN x1000, Ueberlauf/Rundung, NaN/Inf/Ausreisser, +/-Werte', 'PASS', 'HOST_SIM', C('D07', 'D08', 'D09', 'D10', 'D27', 'D28') + P('V10_', 'V11_', 'V12_', 'V13_', 'S21_', 'S22_'), [(CORE, 'float abs_limit_mm'), (INC, 'void SV04Claude_SendCellLive')], 'Grenzen (+-10 mm, Spannweite 3 mm) sind Vorschlaege; OEM-Fehler gezeigt: 45 mm -> -20536, 70 mm -> 2-Wort-Rahmen.'),
 ('A08', 'G29-Abbruch: Anwender, Probe-Fehler, Firmware-Stop, Temperatur, Host-Timeout, zweiter Start', 'BLOCKED', 'HOST_SIM', C('D13', 'D16', 'D17', 'D20', 'D21', 'F01', 'F02', 'F03', 'F04', 'F05', 'F07', 'F08', 'A13') + P('S09_', 'S18_', 'S23_', 'S28_', 'S29_', 'S30_', 'S31_', 'S32_'), [(CORE, 'void cancel()')],
  'PASS fuer alle logischen Pfade. BLOCKED: physischer Stopp der laufenden OEM-G29 (siehe R-05b); "Firmware-Stop" (kill/M112) beendet den Tick ohnehin und ist nach Neustart IDLE (A19).'),
 ('A09', 'Altes Mesh: was bleibt in RAM und EEPROM; Snapshot-Vergleich; Wiederherstellung getestet', 'PASS', 'HOST_SIM', C('E19', 'E23', 'E24') + P('S18_', 'S22_', 'S24_', 'S24b_', 'S32_', 'S40_', 'S43_'), [(INC, 'static void sv04c_mesh_restore'), (G29S, 'DEC_ROLLBACK')], 'RAM: auf den Stand VOR der G29 zurueck (Mesh, Raster, Faktor, Nivellierung, Display). EEPROM: bei jedem Fehler vor save() byte-unveraendert. Bei Fehler WAEHREND save(): siehe R-07b.'),
 ('A10', 'M420-S1-Integration nur nach vollstaendig validem Mesh', 'PASS', 'HOST_SIM', C('E03', 'E04', 'E05', 'E06', 'E07', 'E24') + P('S01b_', 'S01c_'), [(CORE, 'void do_enable()')], 'siehe R-06'),
 ('A11', 'M500-Aufruf nur nach bestaetigter Kette; Z-Offset unveraendert; Fehler getrennt gemeldet', 'PASS', 'HOST_SIM', C('E01', 'E02', 'E08', 'E10', 'E11', 'E13', 'E14', 'E16', 'E20') + P('S01_', 'S02_', 'S33_', 'S35_', 'S36_', 'P07_'), [(INC, 'static bool sv04c_save'), (INC, 'settings.save()')], 'save() wird direkt aufgerufen (= was M500 aufruft; M500.cpp liegt nicht vor): nur so gibt es den Rueckgabewert. Genau EIN Aufruf, nur aus SAVE_PENDING.'),
 ('A12', 'Persistenznachweis ueber den echten Marlin-Pfad (M501 in Simulation/isoliertem Zustand)', 'BLOCKED', 'NONE', [], [(INC, 'settings.load()')], 'Siehe R-08b. Logik gegen Modell: PASS (R-08a).'),
 ('A13', 'DWIN-VP-Katalog: Adressen, Typen, Wortbreiten, Frameformate; 0x110E und Konflikte', 'BLOCKED', 'STATIC', P('V01_', 'V02_', 'V03_', 'V04_'), [(LCDH, '#define AUTO_BED_LEVEL_1POINT_VP'), (LCDH, 'ChangePageKey')],
  'PASS-Anteil (aus der echten LCD_RTS.h): 87 _VP-Adressen, keine doppelte, im Mesh-Bereich nur die Basis; 0x110E = ChangePageKey (Index 34) = Mesh-Zelle k=7. BLOCKED: Typen/Wortbreiten/Dezimalstellen und die HMI-seitige Wirkung von 0x110E (HMI-Binaerdateien fehlen).'),
 ('A14', 'DWIN-Transport: tatsaechlicher Sendepfad, Frame-Checks, Datentypen, Reihenfolge, Timeout', 'BLOCKED', 'HOST_SIM', P('V05_', 'V06_', 'V07_', 'V09_', 'V10_'), [(LCDC, 'void RTSSHOW::RTS_SndData(int n')],
  'PASS: echter Sendepfad, Rahmenaufbau (Kopf, Laenge, 0x82, Adresse, Worte; das Protokoll hat hier keine Pruefsumme), Reihenfolge, Datentypen. BLOCKED: serielle Timeouts/Quittungen werden in der Simulation nicht abgebildet.'),
 ('A15', 'DWIN-Karte und Bedienung: farbige Karte, Live-Punkt, Temperatur, Busy/Cancel, Texte; kein "fertig" bei Abbruch', 'BLOCKED', 'HOST_SIM', P('V06_', 'V08_', 'S01_'), [(INC, 'static void sv04c_display')], 'PASS: Live-Punkt 1-16, kein "fertig" bei Abbruch/Fehler, Touch-Sperre. BLOCKED: farbige Karte, Cancel-Taste, Texte (HMI-Assets), Temperaturanzeige (OEM-Pfad nicht simuliert).'),
 ('A16', 'Reproduzierbarer Host-Test mit realer Koordinatorlogik; mind. 40 Positiv-/Negativ-/Grenztests; jede fehlerhafte Sequenz dokumentiert', 'PASS', 'HOST_SIM', C('G12') + P('K01_', 'S01_'), [(CORE, 'class Coordinator')], 'Kern: C++-Tests ueber den echten Koordinator; Kette: Adapter + echte G29.cpp. Zaehlung siehe ERGEBNISBERICHT und Logs.'),
 ('A17', 'Echter STM32-Build (OEM + Overlay, PlatformIO), RAM/Flash, SHA256, Exitcode, diff --check; Baseline und Konfigurationen', 'BLOCKED', 'NONE', P('X01_', 'X02_', 'X03_', 'X04_', 'X06_', 'B04_', 'B05_'), [(HOOKS, 'SV04_CLAUDE_AUTO60_ENABLE')],
  'Kein STM32-Build moeglich (keine ARM-Toolchain, kein PlatformIO, kein Netz). Workflow-Vorlage 05_BUILD/claude_parallel_build.yml ist nur STRUKTURGEPRUEFT (nie ausgefuehrt). Die strenge Host-Uebersetzung (16 Konfigurationskombinationen) ist KEIN Build-Nachweis.'),
 ('A18', 'Integrations-/Regressionstest: OEM-G28, IDEX-Modi, manuelles Leveling, Menues, Temperatur, andere G29/M420/M500-Aufrufe kompilieren/laufen weiter', 'BLOCKED', 'HOST_SIM', P('S38_', 'S39_', 'S40_', 'S41_', 'S42_', 'P01_', 'P02_', 'X02_', 'X04_'), [(LCDC, 'queue.enqueue_now_P(PSTR("M420 S1"));')],
  'PASS (Host): manuelle G29 ist im Erfolgsfall DRAHT-IDENTISCH zur unveraenderten OEM-G29; alle Aenderungen sind reine Einfuegungen; G28/motion unberuehrt. BLOCKED: Kompilierung der uebrigen OEM-Pfade und Laufzeit auf dem Ziel. Hardwarepruefungen siehe HARDWARE_ABNAHMEPLAN.md.'),
 ('A19', 'Robustheit/Wiederaufnahme: nach Neustart/Abbruch keine alte Session als neu; kein EEPROM-Schreiben beim Start', 'PASS', 'HOST_SIM', C('G01', 'G02', 'G07', 'G08') + P('S10_'), [(CORE, 'void boot_reset()'), (INC, 'static sv04c::Coordinator sv04c_coord')], 'Zustand ist reines RAM; die Sitzungs-ID beginnt nach jedem Neustart bei 1, alte Ereignisse existieren nach einem Reset nicht mehr.'),
 ('A20', 'Abschlussaudit: jede Anforderung PASS/FAIL/BLOCKED; nachweisbar loesbare FAIL korrigiert; keine Prozentwerte', 'PASS', 'HOST_SIM', P('K01_'), [(CORE, 'class Coordinator')], 'Dieses Dokument. Waehrend der Entwicklung gefundene und behobene Fehler: 08_HANDOVER/ERGEBNISBERICHT.md.'),
 ('AK-01', 'G29 16/16 reale Messpunkte in korrekter Koordinatenordnung, identische Session-ID, keine stale Werte', 'PASS', 'HOST_SIM', C('D01', 'D05', 'D12', 'D24') + P('S01_', 'V03_'), [(CORE, 'class MeshSession')], 'siehe R-04'),
 ('AK-02', 'Temperaturstabilisierung und alle Abbruchpfade nachvollziehbar', 'PASS', 'HOST_SIM', C('B02', 'B04', 'B05', 'B06', 'F01', 'F03', 'F04') + P('S25_', 'S26_', 'S29_', 'S31_', 'S32_'), [(CORE, 'void tick()')], 'siehe R-02/A08'),
 ('AK-03', 'Bei G29-Fehler: M420-S1- und M500-Pfad gesperrt; altes EEPROM-Mesh nicht ungefragt ueberschrieben', 'PASS', 'HOST_SIM', C('E18', 'E19', 'E20', 'D13') + P('S18_', 'S19_', 'S20_', 'S21_', 'S22_', 'S23_', 'S43_'), [(CORE, 'void do_save()')], 'Gilt fuer Fehler VOR save(). Ein Fehler WAEHREND save() kann das alte EEPROM ungueltig machen (R-07b).'),
 ('AK-04', 'M420 S1 nur bei gueltiger Meshlage; M500 nur bei explizit bestaetigt vollstaendiger Kette', 'PASS', 'HOST_SIM', C('E03', 'E04', 'E07', 'E08', 'E20', 'E29') + P('S01b_', 'S01c_', 'P07_'), [(CORE, 'void do_enable()'), (CORE, 'void do_save()')], 'siehe R-06/R-07a'),
 ('AK-05', 'EEPROM: unabhaengige Persistenzpruefung oder BLOCKED; nie RAM-Anzeige als EEPROM-Beweis', 'BLOCKED', 'HOST_SIM', C('E13', 'E14', 'E30') + P('S35_', 'S37_'), [(CORE, 'if (ev.validate_ok && !avail)')], 'Der echte Pfad ist BLOCKED (R-08b). Im Koordinator gilt "Ruecklesung nicht verfuegbar" als FAILED, nie als SUCCESS.'),
 ('AK-06', 'Keine Aenderung des gespeicherten Z-Offsets (Wert nicht hartkodiert)', 'PASS', 'HOST_SIM', C('E02', 'C09', 'E08') + P('S01_', 'S02_', 'S15_'), [(INC, 'static float sv04c_zoffset'), (CORE, 'zoff0_')], 'Z-Offset wird nur gelesen und verglichen. Ausnahme: nach einer Ruecklesung mit Abweichung stellt der Adapter den VORHER gelesenen Wert im RAM wieder her.'),
 ('AK-07', 'Alle 16 DWIN-Elemente mit echtem Sendeweg oder einzeln BLOCKED; VP-Kollisionen geloest', 'BLOCKED', 'HOST_SIM', P('V01_', 'V02_', 'V03_', 'V07_'), [(LCDH, 'ChangePageKey')], 'Sendeweg fuer alle 16: PASS (siehe A13_DWIN_16_ELEMENTE.csv). Einzeln BLOCKED: HMI-Objektsemantik aller 16 und die HMI-seitige Wirkung der Kollision 0x110E (ChangePageKey). Es wird nichts ueberschrieben, was das OEM braucht (V07).'),
 ('AK-08', 'CPU/Flash/RAM-Aufwand nachvollziehbar; erfolgreicher STM32-Build belegt', 'BLOCKED', 'HOST_SIM', P('X06_'), [(CORE, 'class Coordinator')], 'RAM-Schaetzung (Host, 64 Bit): Coordinator ~1,2 KB + G29-Sitzung ~0,3 KB. Flash/CPU und STM32-Build: BLOCKED.'),
 ('AK-09', 'Test- und Quellnachweise inkl. sha256sum, Original-Commit, Patch-Diff, Compilerausgabe', 'BLOCKED', 'HOST_SIM', P('B01_'), [(HOOKS, '#pragma once')], 'Vorhanden: sha256-Manifest, Commit (laut Auftrag), Patch-Diffs, Host-Compilerlaeufe (streng). Fehlt: Compilerausgabe des STM32-Builds.'),
 ('AK-10', 'Flash-/Hardware-Freigabe NEIN', 'PASS', 'STATIC', [], [(HOOKS, 'SV04_CLAUDE_HOME_BACKEND_AVAILABLE')], 'FLASH_ALLOWED=NO, HARDWARE_TESTED=NO.'),
 ('AK-11', 'Niemals eine installierbare Firmware anbieten', 'PASS', 'STATIC', [], [(HOOKS, '#pragma once')], 'Das Paket enthaelt Quelltext, Patches, Tests und Doku; keine .bin/.hex/.elf.'),
]


def main():
    cpp, py = load_logs()
    srcsha = f'src:{sha(CORE)}+{sha(INC)}'
    out, bad = [], []
    for rid, req, status, ev, tests, refs, note in ROWS:
        lines, ok = [], True
        for t in tests:
            kind, name = t.split(':', 1)
            if kind == 'C++':
                got = cpp.get(name)
                if not got or got[0] != 'PASS':
                    ok = False
                    lines.append(f'FEHLT/NICHT BESTANDEN: {t}')
                else:
                    lines.append(got[1][:110])
            else:
                hits = [(n, v) for n, v in py.items() if n.startswith('test_' + name)]
                if not hits or any(v[0] != 'ok' for _, v in hits):
                    ok = False
                    lines.append(f'FEHLT/NICHT BESTANDEN: {t}')
                else:
                    lines.append(hits[0][1][1][:110])
        refstr = '; '.join(line_of(p, n) for p, n in refs)
        st = status
        if not ok:
            st = 'FAIL'
            bad.append(rid)
        out.append([rid, req, st, ev, ' | '.join(tests), refstr, srcsha if ev == 'HOST_SIM' else 'n/a', 'KEIN Firmware-Build-Hash (STM32-Build BLOCKED)' if ev != 'NONE' else 'n/a', lines[0] if lines else '-', note])
    p = ROOT / '07_AUDIT' / 'ANFORDERUNGEN_STATUS.csv'
    with open(p, 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['id', 'anforderung', 'status', 'evidenzebene', 'tests', 'quelle', 'quell_hash', 'firmware_build_hash', 'logzeile', 'einschraenkung_oder_befund'])
        w.writerows(out)
    c = {}
    for r in out:
        c[r[2]] = c.get(r[2], 0) + 1
    print(f'{len(out)} Zeilen: {c}')
    if bad:
        print('FAIL-Zeilen (Test nicht im Log bestanden):', bad, file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
