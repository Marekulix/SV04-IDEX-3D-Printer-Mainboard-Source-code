# CLAUDE_SV04_PARALLEL_ERGEBNIS (kurze Übergabe)

**Status:** Host-Simulation bestanden; **STM32-Build BLOCKED**; Flash/Hardware **NEIN**. Nicht „Firmware fertig".

**Pfade (im ZIP `SV04_NEXT_CLAUDE_PARALLEL_GROSSBLOCK.zip`)**
- Neuer Quelltext: `02_SOURCE/Marlin/src/feature/sv04_claude_auto60/{sv04_claude_auto60_core.h, sv04_claude_g29_session.h}`, `02_SOURCE/Marlin/src/lcd/e3v2/creality/{sv04_claude_hooks.h, sv04_claude_auto60_marlin.inc}`
- Patchwerkzeug: `03_PATCHES/apply_claude_parallel.py`; Patches: `03_PATCHES/{G29,LCD_RTS,gcode}_OEM_nach_Claude.patch` (+20/+14/+7 Zeilen, 0 entfernt)
- Tests: `04_TESTS/core/test_auto60_core.cpp`, `04_TESTS/sim/test_{chain,dwin,strict}_a60.py`, `04_TESTS/test_{core,mutations,patch_and_build}_a60.py`
- Workflow-Vorlage (NOT RUN): `05_BUILD/claude_parallel_build.yml`
- Nachweise: `06_EVIDENCE/host/*` (Rohlogs), `06_EVIDENCE/patch_report.json`, `06_EVIDENCE/stm32/BLOCKED.txt`
- Audit: `07_AUDIT/ANFORDERUNGEN_STATUS.csv` (49 Zeilen: 29 PASS, 20 BLOCKED, 0 FAIL)

**Testsummen:** 126/126 C++-Kerntests, 80 Python-Tests ohne Fehler, Mutanten Kern 24/24, Adapter 13/13 erkannt (je +1 geprüft gleichwertig).

**Quell-Hashes (SHA-256):** core `690c4ac87dc400fd…` | inc `e2a9d7dbccc10a61…` | hooks `9446a91733b2a02d…` | g29_session `d616c3e94826ffaa…` | Werkzeug `dc7ca87db3f267c4…` (volle Werte: `08_HANDOVER/ERGEBNISBERICHT.md` §6). Original-Commit laut Auftrag `1867fcba75354a5c65e0631d6972dd19f1bd6cbe`. ZIP-Hash: nicht im ZIP selbst, siehe Begleitdatei `.sha256`.

**Befunde:** `save()` ist nicht atomar (alter EEPROM bei Abbruch ungültig); `G29` schaltet die Nivellierung selbst ein (G29.cpp:883) und führt `G28 XY` aus; Platine `BOARD_CREALITY_V4`, I²C-EEPROM 24C16; „Baseline 275" = Patchskripte für `G28.cpp`/`motion.*`.

**BLOCKED:** STM32-Build/GitHub; echter Persistenzpfad; atomares Speichern; echtes G28/IDEX-Backend (ChatGPT); physischer G29-Stopp; farbige Karte/Cancel-Taste/Texte; HMI-Seite (Binärdateien fehlen); Heizungsfehler-Fahne; M420/M500/MarlinCore-Quellen fehlen.

**Nächste Merge-Schritte:** (1) Backend `SV04Claude_HomeBackendRequest`/`…HomeResult` bereitstellen, (2) Overlay mit `apply_claude_parallel.py` auf Ihren Stand anwenden, (3) `G28 XY`-Endskript der G29 gegen das IDEX-Gate prüfen, (4) STM32-Build mit `05_BUILD/claude_parallel_build.yml`, (5) Entscheidungen aus `07_AUDIT/KONFLIKTE_UND_OFFEN.md` §D, (6) erst dann Hardware-Plan.
