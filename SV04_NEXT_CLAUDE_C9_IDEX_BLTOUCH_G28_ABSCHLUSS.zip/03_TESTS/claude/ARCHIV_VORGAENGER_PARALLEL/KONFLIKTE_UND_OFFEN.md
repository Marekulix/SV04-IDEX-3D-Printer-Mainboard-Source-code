# Konflikte, Befunde und offene Punkte

## A. Befunde aus dem echten OEM-Code (belegt, Fundstellen in `A01_QUELLENINVENTAR.md`)
1. **Aktiver Speicher**: `MOTHERBOARD` ist `BOARD_CREALITY_V4` (nicht V4210/V5.2.1 wie im Auftrag); der EEPROM ist ein **I²C 24C16 (2 KB)** (`IIC_BL24CXX_EEPROM`), byteweise geschrieben, ohne Puffer, Rückprüfung je Byte nur im Schreibpfad.
2. **`save()` ist nicht atomar**: Platzhalter-Version `"ERR"` wird **zuerst** geschrieben, die echte Version und die CRC erst **am Ende**. Ein Abbruch (Stromausfall) dazwischen macht das **alte EEPROM ungültig** (auch den Z-Offset); `load()` fällt dann auf Standardwerte. Atomares Speichern ist ohne geänderte Speicheraufteilung oder Hardware nicht erreichbar.
3. **`G29` schaltet die Nivellierung am Ende selbst ein** (`planner.leveling_active = !abl.dryrun || abl.reenable`), vor jeder Validierung. Auto60 schaltet sie bis zur Validierung wieder aus.
4. **`G29` führt `G28 XY` aus** (Endskript).
5. **OEM-Anzeige**: 45 mm erscheint als −20536; 70 mm erzeugt einen Zwei-Wort-Rahmen auf die Folgeadresse (OEM-Fehler, in der Simulation gezeigt, vom Live-Schutz verhindert).
6. **`planner.synchronize()` und `settings.save()` rufen `idle()`** auf; der Tick läuft dadurch mitten in Befehlen. Ein Fehler meines ersten Entwurfs (Tick im G29-Abschluss-Haken) wurde so gefunden und behoben (Sperrabschnitt, Mutant A02).

## B. BLOCKED (nicht nachweisbar) mit Grund
| Punkt | Grund | Was fehlt |
|---|---|---|
| STM32-Build, GitHub-Lauf, RAM/Flash/Hash | keine Toolchain/Netz | Ausführung von `05_BUILD/claude_parallel_build.yml` in Ihrer CI |
| Echter Persistenzpfad (`settings.cpp`) | nicht übersetzbar ohne vollständigen Baum | Build/Host-Lauf mit vollständigem Marlin, oder Hardware |
| Atomares Speichern / Stromausfall | siehe A.2 | Entwurfsentscheidung (A/B-Kopie) oder Hardware-Schutz |
| Echtes G28/IDEX-Backend | gehört ChatGPT | `SV04Claude_HomeBackendRequest` + `…HomeResult` |
| Laufende G29 physisch stoppen | Eingriff in G29/motion nötig, laut Auftrag verboten | Entscheidung, ob ein minimaler Eingriff gewünscht ist |
| Farbige Karte, Cancel-Taste, Statustexte | brauchen neue HMI-Objekte | HMI-Projekt (`14ShowFile.bin`, `13TouchFile.bin`) |
| HMI-Seite: Dezimalstellen, Vorzeichen, Objekttypen, Wirkung von `0x110E` | HMI-Binärdateien liegen nicht vor | beide Dateien bereitstellen |
| Seiten 38/22/28 | 38 und 22 stammen aus dem OEM-Ablauf, 28 ist eine **Annahme** | HMI prüfen |
| Heizungsfehler-Fahne | in Marlin nicht abfragbar (`kill()`) | — |
| Serielle Timeouts/Quittungen des DWIN | in der Simulation nicht abgebildet | Hardware |
| `M420.cpp`, `M500-M504.cpp`, `M190_M109.cpp`, `MarlinCore.cpp` | nicht in den Uploads | Dateien bereitstellen; insbesondere wo `RTSUpdate()` aufgerufen wird |
| Bindung der OEM-Dateien an Commit `1867fcb` | ohne Netz nicht prüfbar | Der CI-Workflow prüft Commit und Hashes |

## C. Grenzen der Simulation
Parser, Planner, Probe, Thermik, Queue, G28-Backend und EEPROM sind **meine Stubs/Modelle** (Ausnahme: die echte `G29.cpp`, die echte `RTS_SndData`, `RTS_AutoBedLevelPage`, die OEM-Bootschleife und `bilinear_z_offset` laufen als echter Quelltext). Das EEPROM-Modell folgt der **gelesenen** `save()`-Semantik, ist aber nicht der echte Code. Die Aufrufstelle von `RTSUpdate()` und die Reihenfolge in `idle()` sind nicht simuliert.

## D. Entscheidungen für Sie / ChatGPT
1. **Vorschlagswerte** bestätigen: Bett 60 °C ±1 K, 30 s Haltezeit, 15 min Aufheiz-Timeout, ±10 mm Betragsgrenze, 3 mm Spannweite (`Config::defaults()`).
2. **Rollback bei manueller G29** (Standard AN, nur im Fehlerfall; Erfolgsläufe sind drahtidentisch zum OEM): behalten oder mit `-DSV04_CLAUDE_G29_ROLLBACK=0` abschalten.
3. **Touch-Sperre** während Auto60 (kein Touch-Notstopp): gewollt?
4. **Speicherrisiko** (A.2): akzeptieren, mit A/B-Layout lösen oder Auto60 nur beaufsichtigt betreiben.
5. **`M1060`** als Startbefehl (statt DWIN-Taste): ok?
