# SV04 NEXT: Claude parallel (Großblock)

**Kein Flash. Kein Hardwaretest. Kein STM32-Build (BLOCKED). Keine installierbare Firmware.** Dieses Paket enthält Quelltext, Patches, Tests, Nachweise und Doku. Keine SV04-NEXT-Nummer (kein 276, keine `276.yml`).

## Lesereihenfolge
1. `CLAUDE_SV04_PARALLEL_ERGEBNIS.md` (kurze Übergabe)
2. `08_HANDOVER/ERGEBNISBERICHT.md` (was gebaut ist, Befunde, behobene Fehler)
3. `07_AUDIT/ANFORDERUNGEN_STATUS.csv` (jede Anforderung PASS/FAIL/BLOCKED mit Test, Quellstelle, Logzeile)
4. `07_AUDIT/KONFLIKTE_UND_OFFEN.md`, `07_AUDIT/INTEGRATION_CONFLICTS.md`, `07_AUDIT/HARDWARE_ABNAHMEPLAN.md`
5. `08_HANDOVER/CHATGPT_INTEGRATIONSANLEITUNG.md`

## Nachprüfen
```
python3 tools/verify_manifest.py .          # vor dem Testlauf: ALLES STIMMT
python3 tools/run_all_tests_a60.py          # ca. 1,5 Minuten: ALLE TESTS BESTANDEN
```
Erwartung: 126 C++-Kerntests, 80 Python-Tests (+ Wrapper), Mutationstests 24+13 erkannt. Anforderungen: python3, g++ (C++11/14), optional PyYAML und `patch`.

## Struktur
`01_BASELINE/` Original-Commit, Manifest, echte OEM-Dateien, Herkunft | `02_SOURCE/` neuer Marlin-Quelltext | `03_PATCHES/` Patchwerkzeug + `.patch` | `04_TESTS/` Kern-, Ketten-, DWIN-, Strikt-, Mutationstests | `05_BUILD/` Workflow-Vorlage + Build-Status | `06_EVIDENCE/` Rohlogs, Patchbericht, Review-Kopie, STM32-BLOCKED | `07_AUDIT/` Audit, Inventar, VP-Katalog, Konflikte | `08_HANDOVER/` Berichte | `tools/` Werkzeuge.

Unveränderliche Referenz: `SV04_NEXT_275.zip` und der Evidenz-Log wurden nur gelesen (Hashes in `01_BASELINE/BASELINE_MANIFEST.json`).
