# Hardware-Abnahmeplan (nur ein Plan; nichts davon wurde ausgeführt)

**Voraussetzungen, bevor irgendetwas am Gerät geschieht:** (1) ein erfolgreicher STM32-Build mit Nachweisen aus `05_BUILD/claude_parallel_build.yml`, (2) die Entscheidungen aus `KONFLIKTE_UND_OFFEN.md` Abschnitt D, (3) Ihre ausdrückliche Freigabe. Dieses Paket gibt **keine** Flash- oder Hardwarefreigabe und keine Anleitung, Sicherheitseinrichtungen zu umgehen. Insbesondere soll ein Stromausfall oder BLTouch-Fehler **nicht absichtlich ausgelöst** werden; das Verhalten dort ist durch den Quelltext (A.2) und die Simulation beschrieben.

| # | Prüfung | Erwartung / Beobachtung | Sicherheitshinweis |
|---|---|---|---|
| H1 | Bootverhalten nach dem Flashen (nur Beobachtung): Display, Temperaturen, keine Heizung | Zustand wie OEM; `M1060` (ohne S) meldet `state=IDLE`; **kein** EEPROM-Schreiben (Zähler/Verhalten vergleichen) | ohne Filament, ohne Heizen |
| H2 | `M1060 S1` **ohne** G28/IDEX-Backend | wird mit `PRE_HOME_BACKEND_MISSING` abgelehnt; kein Heizbefehl | fail-closed erwartet |
| H3 | Display-Abgleich: Bild nach dem Boot gegen Bild nach einer **regulär** abgeschlossenen manuellen G29 | beide zeigen die 16 Werte des Meshes; Seite 22 | nur bei freiem Druckbett |
| H4 | HMI-Binärdateien auswerten (`tools/…hmi_extract` aus meinem früheren Paket oder eigene Prüfung) | Dezimalstellen, Vorzeichen, Objekttypen, `0x110E` | keine Hardware nötig |
| H5 | Backend von ChatGPT vorhanden: Auto60-Lauf mit Beobachtung | Zustandsfolge `HEATING→…→SUCCESS`, Z-Offset unverändert, Bett-Soll danach wie vorher | Bediener am Gerät, Notaus erreichbar |
| H6 | EEPROM nach erfolgreichem Lauf: `M503` und Neustart; Mesh/Z-Offset vergleichen | gleiche Werte nach Neustart | nur Beobachtung |
| H7 | Touch während des Laufs | wird ignoriert (Sperre); es gibt keinen Touch-Abbruch | Notaus/Netzschalter erreichbar halten |
| H8 | Abbruch per `M1060 S0` während Aufheizen/Homing | `CANCELLED`, Bett-Soll zurück | — |
| H9 | Laufende G29 abbrechen | **nicht möglich** (siehe BLOCKED); sie läuft zu Ende | — |

Aufzeichnen: Firmware-Hash, Commit, Seriell-Log (`M1060`-Statuszeilen), Fotos des Displays, Werte vor/nach (M503). Kein Test gilt als bestanden, ohne dass diese Aufzeichnung vorliegt.
