# 02_SOURCE: neuer Marlin-Quelltext (Claude parallel)

Pfade spiegeln den Marlin-Baum. Das Patchwerkzeug (`03_PATCHES/apply_claude_parallel.py`) legt diese Dateien neben die OEM-Dateien und fügt in drei OEM-Dateien **nur Zeilen ein**.

| Datei | Inhalt | Neu / wiederverwendet |
|---|---|---|
| `feature/sv04_claude_auto60/sv04_claude_auto60_core.h` | Auto60-Koordinator (12 Zustände, Sitzungs-IDs, Mesh-Sitzung, Heiz-/Persistenzlogik); reines C++11, keine Marlin-Abhängigkeit, kein Heap | **neu** |
| `feature/sv04_claude_auto60/sv04_claude_g29_session.h` | RAM-Rollback der G29-Sitzung | **wiederverwendet** aus meiner früheren Lieferung 194–196 (siehe `01_BASELINE/CARRYOVER_FROM_194_196.json`) |
| `lcd/e3v2/creality/sv04_claude_hooks.h` | Konfigurationsschalter, Haken-Deklarationen, RAII-Wächter, passive Schnittstelle zu ChatGPTs G28/IDEX | **neu** |
| `lcd/e3v2/creality/sv04_claude_auto60_marlin.inc` | Marlin-Adapter: verbindet den Kern über Ports mit den belegten Marlin-Symbolen; G29-Haken; DWIN-Anbindung | **neu** |

Wird in `LCD_RTS.cpp` vor `RTS_AutoBedLevelPage()` eingebunden (`#include "sv04_claude_auto60_marlin.inc"`).
Zusätzlich erzeugt das Werkzeug `sv04_claude_oem_mesh_loop.inc` wörtlich aus der OEM-Datei (OEM-Sendeschleife ohne `M420 S1`).

**Nicht auf dem Ziel gebaut.** Kein Flash. Siehe `05_BUILD/BUILD_STATUS.md`.
