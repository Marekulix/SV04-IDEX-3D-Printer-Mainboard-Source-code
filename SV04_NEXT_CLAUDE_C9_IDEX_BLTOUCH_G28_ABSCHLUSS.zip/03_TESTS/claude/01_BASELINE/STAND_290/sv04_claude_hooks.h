#pragma once
/**
 * SV04 NEXT / Claude parallel: Haken-Header. Wird von G29.cpp UND LCD_RTS.cpp eingebunden (siehe 03_PATCHES). Enthaelt NUR Deklarationen, Schalter und den RAII-Waechter.
 * Schalter (Standard in Klammern; alle per -D ueberschreibbar):
 *   SV04_CLAUDE_AUTO60_ENABLE (1)          Auto60-Koordinator kompilieren (braucht BILINEAR + EEPROM_SETTINGS)
 *   SV04_CLAUDE_HOME_BACKEND_AVAILABLE (1 bei IDEX+BLTouch+Z_SAFE_HOMING) 1 = produktives Backend in diesem Baum (sv04_claude_auto60_marlin.inc). 0 = FAIL-CLOSED: Auto60 startet nie.
 *   SV04_CLAUDE_G29_ROLLBACK (1)           RAM-Rollback von Mesh/Raster/Faktor nach fehlgeschlagener/abgebrochener Messphase (aus frueherer Lieferung, siehe sv04_claude_g29_session.h)
 *   SV04_CLAUDE_G29_RESEND (= ROLLBACK)    wiederhergestelltes Mesh ueber die woertliche OEM-Sendeschleife erneut an das Display senden
 *   SV04_CLAUDE_G29_GUARD_LIVE (1)         OEM-Live-Anzeige je Messpunkt nur fuer endliche Werte in +-30 mm
 *   SV04_CLAUDE_PAGE_PROBING (38) / _SUCCESS (22) / _FAIL (28)   DWIN-Seiten (Annahme: 38/22 stammen aus dem OEM-Ablauf, 28 ist ANNAHME und OFFEN)
 */
#include <stdint.h>
#ifndef SV04_CLAUDE_AUTO60_ENABLE
  #define SV04_CLAUDE_AUTO60_ENABLE 1
#endif
// Das PRODUKTIONS-Backend (G28-Haken + Anforderung) braucht das exportierte P1-Ergebnis je G28 (motion.h, Stufe 1 von apply_277.py) und die IDEX/BLTouch-Konfiguration dieses Druckers.
#if ENABLED(RTS_AVAILABLE) && ENABLED(DUAL_X_CARRIAGE) && ENABLED(BLTOUCH) && ENABLED(Z_SAFE_HOMING)
  #define SV04_CLAUDE_HAS_P1_RESULT 1
#else
  #define SV04_CLAUDE_HAS_P1_RESULT 0
#endif
#ifndef SV04_CLAUDE_HOME_BACKEND_AVAILABLE
  #define SV04_CLAUDE_HOME_BACKEND_AVAILABLE SV04_CLAUDE_HAS_P1_RESULT   // 1 = produktives Backend in diesem Baum; -D...=0 = fail-closed-Profil (Auto60 startet nie)
#endif
// NUR FUER HOST-TESTS: ein EXTERNES Test-Double statt des Produktions-Backends. Wird von keinem Firmware-Profil gesetzt (277.yml setzt es nie).
#ifdef SV04_CLAUDE_HOME_BACKEND_EXTERNAL
  #undef SV04_CLAUDE_HOME_BACKEND_AVAILABLE
  #define SV04_CLAUDE_HOME_BACKEND_AVAILABLE 1
#endif
#ifndef SV04_CLAUDE_G29_ROLLBACK
  #define SV04_CLAUDE_G29_ROLLBACK 1
#endif
#ifndef SV04_CLAUDE_G29_RESEND
  #define SV04_CLAUDE_G29_RESEND SV04_CLAUDE_G29_ROLLBACK
#endif
#ifndef SV04_CLAUDE_G29_GUARD_LIVE
  #define SV04_CLAUDE_G29_GUARD_LIVE 1
#endif
#ifndef SV04_CLAUDE_PAGE_PROBING
  #define SV04_CLAUDE_PAGE_PROBING 38
#endif
#ifndef SV04_CLAUDE_PAGE_SUCCESS
  #define SV04_CLAUDE_PAGE_SUCCESS 22
#endif
#ifndef SV04_CLAUDE_PAGE_FAIL
  #define SV04_CLAUDE_PAGE_FAIL 28
#endif

// ---- G29-Haken (Definitionen in sv04_claude_auto60_marlin.inc, eingebunden in LCD_RTS.cpp)
extern uint32_t SV04Claude_G29Begin();
extern void SV04Claude_G29Probing(const uint32_t id);
extern void SV04Claude_G29Point(const uint32_t id, const int ix, const int iy, const float tx, const float ty, const float raw_z, const float stored_z);
extern void SV04Claude_G29Complete(const uint32_t id, const bool successful, const bool dryrun, const bool faux);
extern void SV04Claude_G29Abort(const uint32_t id);
extern void SV04Claude_SendCellLive(const float z, const int index);

// ---- Auto60 (Definitionen ebenfalls im .inc; bei deaktiviertem Auto60 leere/ablehnende Rumpfe)
extern void SV04Claude_Auto60_Tick();      // aus RTSUpdate() (Hauptschleife); mit Re-Entranz-Sperre
extern bool SV04Claude_Auto60_Busy();      // DWIN-Touch ignorieren, solange ein Lauf aktiv ist
extern void SV04Claude_Auto60_Gcode();     // M1060 (S1 = Start, S0 = Abbruch, sonst Status)
extern void SV04Claude_Auto60_TouchCancel(); // Touch waehrend eines Laufs = ausfallsichere Abbruchanforderung (die gedrueckte Taste selbst wird verworfen)
extern bool SV04Claude_G29CancelRequested(); // G29-Schleife (G29.cpp, Haken VOR und NACH jeder Messung; 289 "G29-CANCEL V1"): true = der laufende AUTO60-Lauf soll abgebrochen werden. Liest den DWIN-Empfangspuffer SELBST (ohne auf RTSUpdate() zu warten) und leitet einen Touch der EIGENEN Sitzung sofort an den Koordinator weiter; fuer eine Benutzer-G29 immer false
// Schnittstelle Auto60 <-> G28/IDEX (277: in diesem Baum IMPLEMENTIERT, nicht mehr ein externer Vertrag):
//  SV04Claude_HomeBackendRequest(sid): stellt EINE Referenzfahrt "G28 X Y Z" in die Queue (true = ANGENOMMEN, NICHT "Homing erfolgreich"). Nicht reentrant; verlangt gueltige Sitzung, Zustand HOMING_PENDING, kein Druck.
//  SV04Claude_G28Begin/End (RAII-Waechter in G28.cpp): bindet das naechste vollformatige G28 an die Anforderung bzw. verweigert eine verworfene; meldet GENAU EINMAL nach dem realen G28-Ende
//   SV04Claude_Auto60_HomeResult(sid, success, idex_gate_confirmed), abgeleitet aus dem P1-Ergebnis DIESES G28 (nie aus alten Flags).
extern void SV04Claude_Auto60_HomeResult(const uint32_t sid, const bool success, const bool idex_gate_confirmed);
extern bool SV04Claude_HomeBackendRequest(const uint32_t sid);     // Produktion: Definition im Adapter; bei -D...=0 eine ablehnende Hohlform
extern bool SV04Claude_G28Begin(uint32_t *token);                  // false = dieses G28 verweigern (KEINE Bewegung)
extern void SV04Claude_G28End(const uint32_t token, const bool allowed);

struct SV04Claude_G29Guard {
  uint32_t id_;
  bool done_;
  SV04Claude_G29Guard() : id_(SV04Claude_G29Begin()), done_(false) {}
  ~SV04Claude_G29Guard() { if (!done_) SV04Claude_G29Abort(id_); }      // jeder Ausstieg ohne finish(): G29_RETURN, Fehlerpfade, break
  void probing() { SV04Claude_G29Probing(id_); }
  void point(const int ix, const int iy, const float tx, const float ty, const float raw_z, const float stored_z) { SV04Claude_G29Point(id_, ix, iy, tx, ty, raw_z, stored_z); }
  void finish(const bool successful, const bool dryrun, const bool faux) { done_ = true; SV04Claude_G29Complete(id_, successful, dryrun, faux); }
 private:
  SV04Claude_G29Guard(const SV04Claude_G29Guard &);
  SV04Claude_G29Guard &operator=(const SV04Claude_G29Guard &);
};

// RAII-Waechter fuer GcodeSuite::G28() (G28.cpp, Stufe 2 von apply_277.py). Wird VOR dem P1-Commit deklariert und daher NACH ihm zerstoert: das Ergebnis dieses G28 ist dann schon festgeschrieben.
struct SV04Claude_G28Guard {
  uint32_t tok_;
  bool ok_;
  SV04Claude_G28Guard() : tok_(0), ok_(SV04Claude_G28Begin(&tok_)) {}
  ~SV04Claude_G28Guard() { SV04Claude_G28End(tok_, ok_); }
  bool allowed() const { return ok_; }
 private:
  SV04Claude_G28Guard(const SV04Claude_G28Guard &);
  SV04Claude_G28Guard &operator=(const SV04Claude_G28Guard &);
};
