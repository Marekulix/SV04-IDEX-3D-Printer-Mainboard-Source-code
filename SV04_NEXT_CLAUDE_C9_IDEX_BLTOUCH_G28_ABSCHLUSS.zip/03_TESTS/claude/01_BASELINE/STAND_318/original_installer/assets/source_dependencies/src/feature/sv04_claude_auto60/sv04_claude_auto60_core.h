#pragma once
/**
 * SV04 NEXT / Claude parallel: Auto60-Koordinator (Kern). Reines C++11, KEINE Marlin-Abhaengigkeit, kein Heap, keine Exceptions, kein EEPROM-Zugriff.
 * Dieselbe Datei wird in der Firmware (ueber sv04_claude_auto60_marlin.inc) und im Host-Test verwendet.
 * Zustaende: IDLE, HEATING, STABILIZING, HOMING_PENDING, PROBING, VALIDATING, ENABLING, SAVE_PENDING, VERIFYING, SUCCESS, FAILED, CANCELLED.
 * Jeder Zustandswechsel wird mit Sitzungs-ID, Grund und Zeit protokolliert. FAIL-CLOSED: unbekannter/fehlender Nachweis => FAILED, nie SUCCESS.
 * Kein Zustand ausserhalb von SAVE_PENDING/VERIFYING ruft save() auf; save() wird nur nach vollstaendig validierter Kette aufgerufen.
 */
#include <stdint.h>
#include <string.h>
#include <math.h>

namespace sv04c {

static const unsigned kN = 4, kPts = 16;

enum State : uint8_t { ST_IDLE = 0, ST_HEATING, ST_STABILIZING, ST_HOMING_PENDING, ST_PROBING, ST_VALIDATING, ST_ENABLING, ST_SAVE_PENDING, ST_VERIFYING, ST_SUCCESS, ST_FAILED, ST_CANCELLED, ST_COUNT };
enum Reason : uint8_t {
  R_NONE = 0, R_START_OK,
  R_PRE_PRINTING, R_PRE_PAUSED, R_PRE_MOVING, R_PRE_QUEUE_BUSY, R_PRE_HEATER_FAULT, R_PRE_WRONG_EXTRUDER, R_PRE_IDEX_MODE, R_PRE_DWIN_BUSY, R_PRE_HOME_BACKEND_MISSING, R_PRE_EEPROM_UNAVAILABLE, R_PRE_ALREADY_RUNNING, R_PRE_CONFIG_INVALID,
  R_BAND_REACHED, R_HEAT_STABLE, R_HEAT_TIMEOUT, R_STAB_TIMEOUT, R_HEAT_SENSOR_FAULT, R_HEAT_TARGET_CHANGED, R_HEAT_OVERSHOOT, R_TEMP_EXCURSION,
  R_HOME_REQUESTED, R_HOME_REJECTED, R_HOME_FAILED, R_HOME_TIMEOUT, R_HOME_NO_EVIDENCE, R_HOME_ZOFFSET_CHANGED, R_STATE_LOST,
  R_PROBE_STARTED, R_PROBE_REJECTED, R_PROBE_FAILED, R_PROBE_TIMEOUT, R_FOREIGN_G29, R_POINT_ORDER, R_POINT_DUPLICATE, R_POINT_INVALID, R_POINT_SESSION, R_MESH_INCOMPLETE, R_MESH_RANGE, R_MESH_OUTLIER, R_MESH_GEOMETRY, R_MESH_STALE, R_G29_ENDSCRIPT_FAILED,
  R_VALIDATED, R_M420_REJECTED, R_M420_NOT_ACTIVE, R_M420_TIMEOUT, R_MESH_CHANGED, R_ZOFFSET_CHANGED,
  R_SAVE_ERROR, R_SAVE_TIMEOUT, R_VERIFY_INVALID, R_VERIFY_MISMATCH, R_VERIFY_UNAVAILABLE, R_VERIFY_LEVELING, R_EEPROM_RECOVERY_REQUIRED, R_EEPROM_PREPARE_FAILED, R_VERIFY_CRC, R_VERIFY_NOT_FOUND, R_VERIFY_GEOMETRY, R_VERIFIED,
  R_USER_CANCEL, R_CANCEL_AFTER_STEP, R_MARLIN_STOPPED /* SV04 NEXT C4: am ENDE, damit alle bisherigen Zahlenwerte bleiben */, R_PRE_Z_UNKNOWN /* SV04 NEXT C5: ebenfalls am Ende */, R_COUNT };

inline const char *state_name(State s) {
  static const char *n[ST_COUNT] = {"IDLE", "HEATING", "STABILIZING", "HOMING_PENDING", "PROBING", "VALIDATING", "ENABLING", "SAVE_PENDING", "VERIFYING", "SUCCESS", "FAILED", "CANCELLED"};
  return s < ST_COUNT ? n[s] : "?";
}
inline const char *reason_name(Reason r) {
  static const char *n[R_COUNT] = {"NONE", "START_OK", "PRE_PRINTING", "PRE_PAUSED", "PRE_MOVING", "PRE_QUEUE_BUSY", "PRE_HEATER_FAULT", "PRE_WRONG_EXTRUDER", "PRE_IDEX_MODE", "PRE_DWIN_BUSY", "PRE_HOME_BACKEND_MISSING", "PRE_EEPROM_UNAVAILABLE", "PRE_ALREADY_RUNNING", "PRE_CONFIG_INVALID",
    "BAND_REACHED", "HEAT_STABLE", "HEAT_TIMEOUT", "STAB_TIMEOUT", "HEAT_SENSOR_FAULT", "HEAT_TARGET_CHANGED", "HEAT_OVERSHOOT", "TEMP_EXCURSION",
    "HOME_REQUESTED", "HOME_REJECTED", "HOME_FAILED", "HOME_TIMEOUT", "HOME_NO_EVIDENCE", "HOME_ZOFFSET_CHANGED", "STATE_LOST",
    "PROBE_STARTED", "PROBE_REJECTED", "PROBE_FAILED", "PROBE_TIMEOUT", "FOREIGN_G29", "POINT_ORDER", "POINT_DUPLICATE", "POINT_INVALID", "POINT_SESSION", "MESH_INCOMPLETE", "MESH_RANGE", "MESH_OUTLIER", "MESH_GEOMETRY", "MESH_STALE", "G29_ENDSCRIPT_FAILED",
    "VALIDATED", "M420_REJECTED", "M420_NOT_ACTIVE", "M420_TIMEOUT", "MESH_CHANGED", "ZOFFSET_CHANGED",
    "SAVE_ERROR", "SAVE_TIMEOUT", "VERIFY_INVALID", "VERIFY_MISMATCH", "VERIFY_UNAVAILABLE", "VERIFY_LEVELING", "EEPROM_RECOVERY_REQUIRED", "EEPROM_PREPARE_FAILED", "VERIFY_CRC", "VERIFY_NOT_FOUND", "VERIFY_GEOMETRY", "VERIFIED", "USER_CANCEL", "CANCEL_AFTER_STEP", "MARLIN_STOPPED", "PRE_Z_UNKNOWN"};
  return r < R_COUNT ? n[r] : "?";
}

// ---------------------------------------------------------------------------------------------------- Konfiguration
// ALLE Zahlenwerte sind VORSCHLAEGE (Entwicklungsannahmen), keine Messwerte; sie muessen vom Eigentuemer bestaetigt werden.
struct Config {
  float bed_target_c;        // Soll 60 C
  float band_c;              // |T - Soll| <= band gilt als "im Fenster" (Grenzen eingeschlossen)
  uint32_t stable_ms;        // ununterbrochen im Fenster, bevor es weitergeht
  uint32_t heat_timeout_ms;  // Start -> erstmals im Fenster
  uint32_t stab_timeout_ms;  // erstmals im Fenster -> stabil
  uint32_t home_timeout_ms, probe_timeout_ms, enable_timeout_ms;
  uint32_t g29_begin_grace_ms; // nach dem Einstellen von G29 bei ruhiger Queue: so lange darf der G29-Beginn ausbleiben (z. B. sofortige Ablehnung 'nicht gehomed')
  float overshoot_c;         // T > Soll + overshoot => Fehler
  float excursion_c;         // waehrend HOMING/PROBING: |T - Soll| > excursion => Fehler
  float abs_limit_mm;        // |z| <= abs_limit
  float spread_limit_mm;     // max - min <= spread_limit (Ausreisser/Kippung)
  float geom_tol_mm;         // Zielkoordinate gegen Raster
  float zoffset_tol;         // erlaubte Abweichung des Z-Offsets (0 = bitgleich ausser Rundung)
  uint8_t max_save_retries;  // Wiederholungen von save() NUR nach fehlgeschlagener Verifikation (RAM-Abbild unveraendert)
  bool require_idex_gate;    // Nachweis "IDEX-Gate bestaetigt" vom G28/IDEX-Zweig verlangen
  bool restore_heater_on_exit;
  bool rollback_after_activation; // false (Standard): ein bereits AKTIVIERTES, validiertes Mesh bleibt bei Abbruch/Fehler VOR dem Speichern im RAM aktiv (EEPROM bleibt alt). true: auch dann wird das alte Mesh wiederhergestellt (nichts ist gespeichert)
  static Config defaults() {
    Config c; c.bed_target_c = 60.0f; c.band_c = 1.0f; c.stable_ms = 30000; c.heat_timeout_ms = 900000; c.stab_timeout_ms = 600000;
    c.home_timeout_ms = 300000; c.probe_timeout_ms = 900000; c.enable_timeout_ms = 20000; c.g29_begin_grace_ms = 5000; c.overshoot_c = 10.0f; c.excursion_c = 5.0f;
    c.abs_limit_mm = 10.0f; c.spread_limit_mm = 3.0f; c.geom_tol_mm = 0.05f; c.zoffset_tol = 0.0f; c.max_save_retries = 1; c.require_idex_gate = true; c.restore_heater_on_exit = true; c.rollback_after_activation = false; return c;
  }
  bool valid() const {
    return isfinite(bed_target_c) && bed_target_c > 0 && bed_target_c <= 110 && isfinite(band_c) && band_c > 0 && band_c <= 10 && stable_ms > 0 && heat_timeout_ms > 0 && stab_timeout_ms >= stable_ms && home_timeout_ms > 0 && probe_timeout_ms > 0 && enable_timeout_ms > 0 && g29_begin_grace_ms > 0
      && isfinite(overshoot_c) && overshoot_c > 0 && isfinite(excursion_c) && excursion_c >= band_c && isfinite(abs_limit_mm) && abs_limit_mm > 0 && isfinite(spread_limit_mm) && spread_limit_mm > 0 && isfinite(geom_tol_mm) && geom_tol_mm > 0 && isfinite(zoffset_tol) && zoffset_tol >= 0;
  }
};

// ---------------------------------------------------------------------------------------------------- Mesh
struct MeshImage { float z[kN][kN]; float spacing[2], start[2], factor[2]; };   // z[x][y] wie Marlin
inline bool mesh_same(const MeshImage &a, const MeshImage &b) { return memcmp(&a, &b, sizeof(MeshImage)) == 0; }

// OEM-Messreihenfolge dieses Builds (G29.cpp: zig = PR_OUTER_SIZE & 1 = false => Zeile y=0 mit x absteigend, y=1 aufsteigend, ...). Punktnummer 0..15 aus (x,y).
inline unsigned point_no(unsigned ix, unsigned iy) { return iy * kN + ((iy & 1u) ? ix : (kN - 1u - ix)); }

enum MeshErr : uint8_t { ME_OK = 0, ME_SESSION, ME_ORDER, ME_DUPLICATE, ME_INDEX, ME_NONFINITE, ME_FULL };
struct Point { uint8_t seq, ix, iy; float target_x, target_y, raw_z, stored_z; };

class MeshSession {
  Point pts_[kPts];
  uint32_t sid_;
  uint8_t n_;
  uint16_t seen_;
  MeshErr err_;
 public:
  MeshSession() : pts_(), sid_(0), n_(0), seen_(0), err_(ME_OK) {}
  void begin(uint32_t sid) { memset(pts_, 0, sizeof pts_); sid_ = sid; n_ = 0; seen_ = 0; err_ = ME_OK; }
  void invalidate() { sid_ = 0; }
  uint32_t sid() const { return sid_; }
  unsigned count() const { return n_; }
  MeshErr error() const { return err_; }
  const Point &at(unsigned i) const { return pts_[i]; }
  // seq = Ankunftsnummer; die Punktnummer wird aus (ix,iy) abgeleitet und MUSS der Ankunftsnummer entsprechen.
  MeshErr add(uint32_t sid, unsigned ix, unsigned iy, float tx, float ty, float raw, float stored) {
    MeshErr e = ME_OK;
    if (sid == 0 || sid != sid_) e = ME_SESSION;
    else if (ix >= kN || iy >= kN) e = ME_INDEX;
    else if (n_ >= kPts) e = ME_FULL;
    else if (seen_ & (1u << point_no(ix, iy))) e = ME_DUPLICATE;
    else if (point_no(ix, iy) != n_) e = ME_ORDER;
    else if (!isfinite(tx) || !isfinite(ty) || !isfinite(raw) || !isfinite(stored)) e = ME_NONFINITE;
    if (e != ME_OK) { if (err_ == ME_OK && e != ME_SESSION) err_ = e; return e; }
    Point &p = pts_[n_]; p.seq = n_; p.ix = (uint8_t)ix; p.iy = (uint8_t)iy; p.target_x = tx; p.target_y = ty; p.raw_z = raw; p.stored_z = stored;
    seen_ = (uint16_t)(seen_ | (1u << point_no(ix, iy))); ++n_;
    return ME_OK;
  }
  // Abschlusspruefung gegen das RAM-Mesh. Liefert den ersten gefundenen Grund.
  Reason verify(const MeshImage &ram, const Config &c) const {
    if (err_ != ME_OK) return err_ == ME_ORDER ? R_POINT_ORDER : err_ == ME_DUPLICATE ? R_POINT_DUPLICATE : R_POINT_INVALID;
    if (n_ != kPts || seen_ != 0xFFFFu) return R_MESH_INCOMPLETE;
    float mn = pts_[0].stored_z, mx = mn;
    for (unsigned i = 0; i < kPts; i++) {
      const Point &p = pts_[i];
      if (fabsf(p.raw_z) > c.abs_limit_mm || fabsf(p.stored_z) > c.abs_limit_mm) return R_MESH_RANGE;
      if (p.stored_z < mn) mn = p.stored_z;
      if (p.stored_z > mx) mx = p.stored_z;
      if (!isfinite(ram.spacing[0]) || !isfinite(ram.spacing[1]) || ram.spacing[0] <= 0 || ram.spacing[1] <= 0 || !isfinite(ram.start[0]) || !isfinite(ram.start[1])) return R_MESH_GEOMETRY;
      if (fabsf(p.target_x - (ram.start[0] + p.ix * ram.spacing[0])) > c.geom_tol_mm || fabsf(p.target_y - (ram.start[1] + p.iy * ram.spacing[1])) > c.geom_tol_mm) return R_MESH_GEOMETRY;
      if (memcmp(&ram.z[p.ix][p.iy], &p.stored_z, sizeof(float)) != 0) return R_MESH_STALE;      // aufgezeichneter Wert == aktueller RAM-Wert (bitgleich)
    }
    if (mx - mn > c.spread_limit_mm) return R_MESH_OUTLIER;
    return R_NONE;
  }
};

// ---------------------------------------------------------------------------------------------------- Ports (Schnittstelle zur Aussenwelt)
struct Precond {
  bool printing, paused, moving, queue_busy, heater_fault, dxc_mode_ok, duplication_off, dwin_busy, home_backend_available, eeprom_available, marlin_stopped /* SV04 NEXT C4: IsStopped(), z. B. nach BLTouch-stop(); KEIN Initialisierer: Precond bleibt trivial (boot_reset() nutzt memset) */, z_unknown /* SV04 NEXT C5: Z nicht referenziert/vertrauenswuerdig (Kaltstart); ohne Initialisierer */;
  uint8_t active_extruder;
};
struct BedState { float temp_c; float target_c; bool sensor_ok; };
// Nachweis des G28/IDEX-Zweigs (ChatGPT, Punkt 1). Wir ERFINDEN keinen Nachweis: idex_gate_confirmed kommt vom Backend oder bleibt false.
struct HomeEvidence { bool x_trusted, y_trusted, z_trusted, dxc_mode_ok, duplication_off, idex_gate_confirmed; uint8_t active_extruder; };
// endscript_ok: das G29-Endskript (Z_PROBE_END_SCRIPT "G28 XY", G29.cpp:897) und der Zustand danach (Achsen vertraut, T0, Modus, Duplizierung aus) wurden vom Adapter AUSGEWERTET und sind in Ordnung.
struct G29Result { bool success, dryrun, faux, endscript_ok; G29Result() : success(false), dryrun(false), faux(false), endscript_ok(true) {} };
// 283: Die Rueckablesung ist UNABHAENGIG (Rohlesung aus dem EEPROM, kein settings.load(), das RAM bleibt unberuehrt). Bedeutung der Felder:
//  readback_ok = Speicher lesbar | version_ok = Kopf versioniert | datasize_ok = Block vollstaendig, eigene CRC stimmt | mesh_equal = Raster/Start und ALLE 16 Werte bitgleich zum gemessenen Mesh
//  zoff_equal = gespeichertes probe.offset == Z-Offset vor dem Lauf | independent = Rohlesung (nicht RAM) | crc_ok = eigene CRC ueber die Rohbytes | mesh_found = Mesh genau einmal gefunden
//  geometry_ok = gespeicherte Zahlen endlich/im Rahmen, Raster/Start plausibel | ram_unchanged = die Rueckablesung hat kein Konfigurations-RAM veraendert
struct EepromEvidence { bool save_ok, validate_ok, readback_available, readback_ok, mesh_equal, zoff_equal, version_ok, datasize_ok, leveling_active_after, independent, crc_ok, mesh_found, geometry_ok, ram_unchanged; };

enum DispKind : uint8_t { D_STATE, D_PROGRESS, D_CELL, D_TEMP, D_RESULT };
struct DisplayEvent { DispKind kind; State state; Reason reason; uint8_t n; float a, b; uint32_t sid; };   // PROGRESS: n=1..16; CELL: n=Punktnummer, a=z; TEMP: a=ist, b=soll

struct Ports {
  void *ctx;
  uint32_t (*now_ms)(void *);
  void (*read_precond)(void *, Precond &);
  void (*bed_read)(void *, BedState &);
  void (*bed_set_target)(void *, float c);
  bool (*home_request)(void *, uint32_t sid);                 // true = Anforderung angenommen; Ergebnis kommt ueber on_home_result()
  bool (*g29_start)(void *, uint32_t sid);                    // bindet die naechste G29 an sid und stellt sie ein; Ergebnis ueber on_g29_*()
  bool (*cmd_idle)(void *);                                   // Queue leer und Planner ruhig
  void (*mesh_read)(void *, MeshImage &);
  float (*zoffset)(void *);
  bool (*m420_s1)(void *, uint32_t sid);                      // M420 S1 einstellen
  void (*leveling_state)(void *, bool &active, bool &valid);
  bool (*eeprom_validate)(void *);                            // Marlin: settings.validate() (liest + CRC/Version, uebernimmt NICHTS)
  bool (*save)(void *, uint32_t sid);                         // Marlin: settings.save() (= was M500 aufruft); true = ok
  bool (*eeprom_readback)(void *, const MeshImage &expected, float expected_zoff, EepromEvidence &ev);   // 283: UNABHAENGIGE Rohlesung aus dem EEPROM (kein Ladepfad, RAM unberuehrt); false = nicht lesbar
  bool (*eeprom_prepare)(void *, uint32_t sid);               // optional (nullptr erlaubt): VOR dem ersten Schreiben des Hauptblocks Undo-Journal anlegen; false = nicht moeglich wegen E/A-Fehler (es wurde NICHTS veraendert). Ohne Platz/ohne gueltigen Hauptblock: true (ungeschuetzt)
  bool (*eeprom_unchanged)(void *, const MeshImage &expected, float expected_zoff);   // optional (nullptr erlaubt): steht das gemessene Mesh samt Z-Offset BEREITS bitgleich (gueltiger Block) im EEPROM? Dann entfaellt das Speichern (kein Verschleiss, kein "ERR"-Fenster); die unabhaengige Pruefung laeuft trotzdem
  bool (*eeprom_commit)(void *, uint32_t sid, bool verified); // optional: Transaktion abschliessen (verified: Journal verwerfen; sonst Hauptblock zurueckspielen). true = EEPROM danach konsistent (verifiziert oder alt wiederhergestellt)
  void (*home_abort)(void *, uint32_t sid);                   // optional: eine noch wartende/laufende Referenzfahrt-Anforderung wurde verworfen (Fehler/Abbruch in HOMING_PENDING); das Backend darf sie nicht mehr als gueltig behandeln
  void (*rollback_mesh)(void *);                              // optional (nullptr erlaubt): RAM-Mesh auf den Stand VOR der G29 zuruecksetzen (nur solange die Nivellierung nicht aktiviert wurde)
  void (*display)(void *, const DisplayEvent &);
};

struct TransitionRec { uint32_t sid, ms; State from, to; Reason why; };

// ---------------------------------------------------------------------------------------------------- Koordinator
class Coordinator {
  static const unsigned kLog = 32;
  Ports p_; Config c_;
  State st_; Reason last_reason_;
  uint32_t sid_, next_sid_, enter_ms_, start_ms_, stable_since_, stale_events_;
  bool cancel_pending_, g29_begun_, in_band_seen_, save_issued_, enable_issued_, home_issued_, verifying_started_, mesh_touched_, m420_enabled_, rolled_back_, save_prepared_, commit_done_, save_skipped_;
  float prev_target_, zoff0_;
  uint8_t save_attempts_;
  MeshSession mesh_; MeshImage validated_; MeshImage ram_at_save_;
  EepromEvidence evidence_;
  TransitionRec log_[kLog]; uint32_t log_n_;
  Precond pre_;

  uint32_t now() { return p_.now_ms(p_.ctx); }
  void disp(DispKind k, uint8_t n = 0, float a = 0, float b = 0) { DisplayEvent e; e.kind = k; e.state = st_; e.reason = last_reason_; e.n = n; e.a = a; e.b = b; e.sid = sid_; p_.display(p_.ctx, e); }
  void go(State to, Reason why) {
    TransitionRec &r = log_[log_n_ % kLog]; r.sid = sid_; r.ms = now(); r.from = st_; r.to = to; r.why = why; ++log_n_;
    st_ = to; last_reason_ = why; enter_ms_ = r.ms;
    disp(D_STATE);
  }
  void restore_heater() { if (c_.restore_heater_on_exit && p_.bed_set_target) p_.bed_set_target(p_.ctx, prev_target_); }
  // Ein neues, noch nicht aktiviertes Mesh darf bei Fehlschlag/Abbruch NICHT im RAM bleiben (ab VALIDATING; waehrend PROBING stellt der G29-Haken selbst her).
  void maybe_rollback() {
    const bool after = c_.rollback_after_activation;                                       // Option: auch NACH der Aktivierung, solange noch nichts gespeichert wurde
    if (p_.rollback_mesh && mesh_touched_ && (!m420_enabled_ || after) && !save_issued_ && st_ >= ST_VALIDATING && st_ <= (after ? ST_SAVE_PENDING : ST_ENABLING)) { p_.rollback_mesh(p_.ctx); rolled_back_ = true; }
  }
  void abort_home() { if (st_ == ST_HOMING_PENDING && p_.home_abort) p_.home_abort(p_.ctx, sid_); }
  // 283: Abschluss der EEPROM-Transaktion GENAU EINMAL (Journal verwerfen bzw. alten Block zurueckspielen). true = EEPROM danach konsistent. Fehler hier aendern das Ergebnis nicht (der Adapter meldet sie).
  bool finish_eeprom(bool verified) {
    if (!save_prepared_ || commit_done_) return false;
    commit_done_ = true;
    return p_.eeprom_commit ? p_.eeprom_commit(p_.ctx, sid_, verified) : false;
  }
  void fail(Reason why) { abort_home(); maybe_rollback(); mesh_.invalidate(); finish_eeprom(false); go(ST_FAILED, why); restore_heater(); disp(D_RESULT); }
  void cancelled(Reason why) { abort_home(); maybe_rollback(); mesh_.invalidate(); finish_eeprom(false); go(ST_CANCELLED, why); restore_heater(); disp(D_RESULT); }
  bool active() const { return st_ >= ST_HEATING && st_ <= ST_VERIFYING; }
  bool in_band(const BedState &b) const { return fabsf(b.temp_c - c_.bed_target_c) <= c_.band_c; }
  // Heizungspruefung, die in HEATING/STABILIZING/HOMING/PROBING gilt. true = ok.
  bool heater_ok(const BedState &b, bool excursion_check) {
    if (!b.sensor_ok || !isfinite(b.temp_c) || !isfinite(b.target_c) || b.temp_c < -5.0f || b.temp_c > 150.0f) { fail(R_HEAT_SENSOR_FAULT); return false; }
    if (fabsf(b.target_c - c_.bed_target_c) > 0.01f) { fail(R_HEAT_TARGET_CHANGED); return false; }
    if (b.temp_c > c_.bed_target_c + c_.overshoot_c) { fail(R_HEAT_OVERSHOOT); return false; }
    if (excursion_check && fabsf(b.temp_c - c_.bed_target_c) > c_.excursion_c) { fail(R_TEMP_EXCURSION); return false; }
    return true;
  }
  bool precond_ok_running() {            // Neuprufung der Bedingungen waehrend des Laufs (Druck/Pause/Heizerfehler duerfen nicht eintreten)
    Precond q; p_.read_precond(p_.ctx, q);
    if (q.printing) { fail(R_PRE_PRINTING); return false; }
    if (q.paused) { fail(R_PRE_PAUSED); return false; }
    if (q.heater_fault) { fail(R_PRE_HEATER_FAULT); return false; }
    return true;
  }
  void do_validate() {
    MeshImage ram; p_.mesh_read(p_.ctx, ram);
    const Reason r = mesh_.verify(ram, c_);
    if (r != R_NONE) { fail(r); return; }
    validated_ = ram;
    go(ST_ENABLING, R_VALIDATED);
    enable_issued_ = false;
  }
  void do_enable() {
    if (!enable_issued_) {
      if (!p_.m420_s1(p_.ctx, sid_)) { fail(R_M420_REJECTED); return; }
      enable_issued_ = true; enter_ms_ = now(); return;
    }
    if (now() - enter_ms_ > c_.enable_timeout_ms) { fail(R_M420_TIMEOUT); return; }
    if (!p_.cmd_idle(p_.ctx)) return;
    bool act = false, val = false; p_.leveling_state(p_.ctx, act, val);
    if (!act || !val) { fail(R_M420_NOT_ACTIVE); return; }
    MeshImage ram; p_.mesh_read(p_.ctx, ram);
    if (!mesh_same(ram, validated_)) { fail(R_MESH_CHANGED); return; }
    m420_enabled_ = true;                                    // ab hier ist ein validiertes Mesh AKTIV: kein Rollback mehr (Nivellierung bliebe sonst inkonsistent)
    if (cancel_pending_) { cancelled(R_CANCEL_AFTER_STEP); return; }
    go(ST_SAVE_PENDING, R_VALIDATED);
  }
  void do_save() {
    // Vorbedingungen fuer M500: ALLES muss noch gelten (Kette vollstaendig, Mesh/Z-Offset unveraendert, keine Bewegung).
    if (cancel_pending_ && !save_issued_) { cancelled(R_USER_CANCEL); return; }      // nach dem ersten save() wirkt KEIN Abbruch mehr (ein ungueltiges EEPROM darf nicht als CANCELLED enden)
    if (!p_.cmd_idle(p_.ctx)) return;
    MeshImage ram; p_.mesh_read(p_.ctx, ram);
    if (!mesh_same(ram, validated_)) { fail(R_MESH_CHANGED); return; }
    if (fabsf(p_.zoffset(p_.ctx) - zoff0_) > c_.zoffset_tol) { fail(R_ZOFFSET_CHANGED); return; }
    bool act = false, val = false; p_.leveling_state(p_.ctx, act, val);
    if (!act || !val) { fail(R_M420_NOT_ACTIVE); return; }
    ram_at_save_ = ram;
    if (p_.eeprom_unchanged && save_attempts_ == 0 && p_.eeprom_unchanged(p_.ctx, ram_at_save_, zoff0_)) {      // 283: bereits bitgleich gespeichert -> KEIN Schreibzyklus
      save_skipped_ = true; save_issued_ = true; ++save_attempts_; evidence_.save_ok = true; go(ST_VERIFYING, R_NONE); return;   // der uebersprungene Versuch zaehlt: scheitert die Pruefung, speichert die Wiederholung WIRKLICH (sonst Endlosschleife)
    }
    if (p_.eeprom_prepare && !save_prepared_) {                                       // 283: VOR jedem Schreiben des Hauptblocks das Undo-Journal anlegen (Stromausfall-Schutz)
      if (!p_.eeprom_prepare(p_.ctx, sid_)) { fail(R_EEPROM_PREPARE_FAILED); return; }   // nichts am Hauptblock veraendert
      save_prepared_ = true;
    }
    save_issued_ = true; ++save_attempts_;
    const bool ok = p_.save(p_.ctx, sid_);             // Marlin: settings.save(); ab hier NICHT mehr abbrechbar
    evidence_.save_ok = ok;
    go(ST_VERIFYING, ok ? R_NONE : R_SAVE_ERROR);
  }
  void do_verify() {
    EepromEvidence ev; memset(&ev, 0, sizeof ev); ev.save_ok = evidence_.save_ok;
    ev.validate_ok = p_.eeprom_validate(p_.ctx);
    // 283: Die unabhaengige Rohlesung laeuft IMMER (auch wenn validate() scheitert), damit die Ursache unterscheidbar bleibt (CRC / nicht gefunden / Geometrie / Abweichung).
    const bool avail = p_.eeprom_readback(p_.ctx, ram_at_save_, zoff0_, ev);
    evidence_ = ev;
    if (ev.validate_ok && !avail) { fail(R_VERIFY_UNAVAILABLE); return; }       // fail() schliesst die Journal-Transaktion selbst ab (finish_eeprom ist idempotent)          // NIE aus RAM-Anzeige auf EEPROM schliessen
    const bool good = ev.save_ok && ev.validate_ok && avail && ev.readback_ok && ev.mesh_equal && ev.zoff_equal && ev.version_ok && ev.datasize_ok && ev.leveling_active_after
                      && ev.independent && ev.crc_ok && ev.mesh_found && ev.geometry_ok && ev.ram_unchanged;
    if (good) {
      // SV04 NEXT 294: successful readback alone cannot prove journal finalization.
      // A failed final EEPROM write must never produce ST_SUCCESS / R_VERIFIED.
      // If saving was skipped because bytes were already identical, there is
      // deliberately no journal to close.
      if (save_prepared_ && !finish_eeprom(true)) {
        fail(R_EEPROM_RECOVERY_REQUIRED);
        return;
      }
      go(ST_SUCCESS, R_VERIFIED); restore_heater(); disp(D_RESULT); return;
    }
    Reason why = !ev.validate_ok ? R_VERIFY_INVALID : !ev.leveling_active_after ? R_VERIFY_LEVELING
               : !ev.crc_ok ? R_VERIFY_CRC : !ev.mesh_found ? R_VERIFY_NOT_FOUND : !ev.geometry_ok ? R_VERIFY_GEOMETRY
               : (!ev.mesh_equal || !ev.zoff_equal || !ev.version_ok || !ev.datasize_ok || !ev.readback_ok || !ev.independent || !ev.ram_unchanged) ? R_VERIFY_MISMATCH : R_SAVE_ERROR;
    if (why != R_VERIFY_LEVELING && save_attempts_ <= c_.max_save_retries) {          // Wiederholung NUR wenn der EEPROM-Inhalt zweifelhaft ist (nicht bei reinem Nivellierungszustand); das Journal bleibt dabei GUELTIG
      MeshImage ram; p_.mesh_read(p_.ctx, ram);
      if (mesh_same(ram, ram_at_save_) && fabsf(p_.zoffset(p_.ctx) - zoff0_) <= c_.zoffset_tol) { go(ST_SAVE_PENDING, why); return; }
    }
    const bool consistent = finish_eeprom(false);                                      // alten gueltigen Block zurueckspielen (falls das Journal gilt)
    // "Wiederherstellung noetig" nur, wenn das EEPROM NICHT nachweislich konsistent ist; wurde der alte Block wiederhergestellt, bleibt die genaue Ursache erhalten
    fail((why == R_VERIFY_INVALID || why == R_SAVE_ERROR) && !consistent ? R_EEPROM_RECOVERY_REQUIRED : why);
  }

 public:
  Coordinator(const Ports &p, const Config &c) : p_(p), c_(c) { boot_reset(); }

  // A19: konservativer Reset. KEIN EEPROM-Zugriff, keine alte Sitzung gilt als neu. (Die ID-Zaehlung beginnt nach jedem Neustart bei 1; Zustand ist reines RAM.)
  void boot_reset() {
    st_ = ST_IDLE; last_reason_ = R_NONE; sid_ = 0; next_sid_ = 1; enter_ms_ = start_ms_ = stable_since_ = 0; stale_events_ = 0;
    cancel_pending_ = g29_begun_ = in_band_seen_ = save_issued_ = enable_issued_ = home_issued_ = verifying_started_ = mesh_touched_ = m420_enabled_ = rolled_back_ = save_prepared_ = commit_done_ = save_skipped_ = false; prev_target_ = 0; zoff0_ = 0; save_attempts_ = 0;
    mesh_.begin(0); mesh_.invalidate(); memset(&validated_, 0, sizeof validated_); memset(&ram_at_save_, 0, sizeof ram_at_save_); memset(&evidence_, 0, sizeof evidence_); memset(log_, 0, sizeof log_); log_n_ = 0; memset(&pre_, 0, sizeof pre_);
  }

  State state() const { return st_; }
  Reason reason() const { return last_reason_; }
  uint32_t session() const { return sid_; }
  bool running() const { return active(); }
  bool terminal() const { return st_ == ST_SUCCESS || st_ == ST_FAILED || st_ == ST_CANCELLED; }
  uint32_t stale_events() const { return stale_events_; }
  uint8_t save_attempts() const { return save_attempts_; }
  bool save_issued() const { return save_issued_; }
  bool save_skipped() const { return save_skipped_; }          // 283: das Mesh stand schon bitgleich im EEPROM; es wurde nicht geschrieben
  bool rolled_back() const { return rolled_back_; }
  bool cancel_requested() const { return cancel_pending_; }
  const EepromEvidence &evidence() const { return evidence_; }
  const MeshSession &mesh() const { return mesh_; }
  uint32_t log_count() const { return log_n_; }
  bool log_at(unsigned back, TransitionRec &r) const { if (back >= kLog || back >= log_n_) return false; r = log_[(log_n_ - 1 - back) % kLog]; return true; }
  const Config &config() const { return c_; }

  // A03: Start nur bei nachweislichem Idle. Liefert R_START_OK oder den Ablehnungsgrund; bei Ablehnung bleibt ALLES unveraendert.
  Reason start() {
    if (active()) return R_PRE_ALREADY_RUNNING;
    if (!c_.valid()) return R_PRE_CONFIG_INVALID;
    Precond q; p_.read_precond(p_.ctx, q);
    if (q.printing) return R_PRE_PRINTING;
    if (q.paused) return R_PRE_PAUSED;
    if (q.moving) return R_PRE_MOVING;
    if (q.queue_busy) return R_PRE_QUEUE_BUSY;
    if (q.marlin_stopped) return R_MARLIN_STOPPED;           // SV04 NEXT C4: kein Start im gestoppten Zustand
    if (q.z_unknown) return R_PRE_Z_UNKNOWN;                 // SV04 NEXT C5: kein Auto60-Start aus unbekanntem Z (erst von Hand referenzieren)
    if (q.heater_fault) return R_PRE_HEATER_FAULT;
    if (q.active_extruder != 0) return R_PRE_WRONG_EXTRUDER;
    if (!q.dxc_mode_ok || !q.duplication_off) return R_PRE_IDEX_MODE;
    if (q.dwin_busy) return R_PRE_DWIN_BUSY;
    if (!q.home_backend_available) return R_PRE_HOME_BACKEND_MISSING;
    if (!q.eeprom_available) return R_PRE_EEPROM_UNAVAILABLE;
    BedState b; p_.bed_read(p_.ctx, b);
    if (!b.sensor_ok || !isfinite(b.temp_c) || !isfinite(b.target_c)) return R_HEAT_SENSOR_FAULT;
    // neue Sitzung
    sid_ = next_sid_++; if (next_sid_ == 0) next_sid_ = 1;
    cancel_pending_ = g29_begun_ = in_band_seen_ = save_issued_ = enable_issued_ = home_issued_ = verifying_started_ = mesh_touched_ = m420_enabled_ = rolled_back_ = save_prepared_ = commit_done_ = save_skipped_ = false; save_attempts_ = 0; stable_since_ = 0;
    memset(&evidence_, 0, sizeof evidence_); mesh_.begin(0); mesh_.invalidate(); pre_ = q;
    prev_target_ = b.target_c; zoff0_ = p_.zoffset(p_.ctx); start_ms_ = now();
    st_ = ST_IDLE;                                  // Quelle des ersten Eintrags
    go(ST_HEATING, R_START_OK);
    p_.bed_set_target(p_.ctx, c_.bed_target_c);
    return R_START_OK;
  }

  // A08: Anwenderabbruch. Nicht unterbrechbare Schritte (laufendes G28/G29, M500) werden zu Ende gefuehrt; danach CANCELLED und KEINE Folgeaktion.
  void cancel() {
    if (!active()) return;
    switch (st_) {
      case ST_HEATING: case ST_STABILIZING: case ST_VALIDATING: cancelled(R_USER_CANCEL); break;
      case ST_HOMING_PENDING: case ST_PROBING: case ST_ENABLING: cancel_pending_ = true; break;
      case ST_SAVE_PENDING: if (!save_issued_) cancelled(R_USER_CANCEL); break;   // nach save(): nicht abbrechbar
      default: break;                                                         // VERIFYING: nur lesend, wird beendet
    }
  }

  // Ereignisse vom G28/IDEX-Zweig und den G29-Haken. Falsche Sitzung/Zustand => ignoriert und gezaehlt (nie wirksam).
  void on_home_result(uint32_t sid, bool ok, const HomeEvidence &ev) {
    if (st_ != ST_HOMING_PENDING || sid != sid_) { ++stale_events_; return; }
    if (cancel_pending_) { cancelled(R_CANCEL_AFTER_STEP); return; }
    if (!ok) { fail(R_HOME_FAILED); return; }
    if (!ev.x_trusted || !ev.y_trusted || !ev.z_trusted || ev.active_extruder != 0 || !ev.dxc_mode_ok || !ev.duplication_off || (c_.require_idex_gate && !ev.idex_gate_confirmed)) { fail(R_HOME_NO_EVIDENCE); return; }
    if (fabsf(p_.zoffset(p_.ctx) - zoff0_) > c_.zoffset_tol) { fail(R_HOME_ZOFFSET_CHANGED); return; }
    if (!precond_ok_running()) return;
    mesh_.begin(sid_); g29_begun_ = false; mesh_touched_ = true;
    go(ST_PROBING, R_PROBE_STARTED);
    if (!p_.g29_start(p_.ctx, sid_)) fail(R_PROBE_REJECTED);
  }
  void on_g29_begin(uint32_t sid) {
    if (!active()) return;                                                  // keine Auto60-Sitzung: normale G29 des Anwenders, nicht unsere Sache
    if (st_ != ST_PROBING || sid != sid_) { fail(R_FOREIGN_G29); return; }
    g29_begun_ = true;
  }
  void on_g29_point(uint32_t sid, unsigned ix, unsigned iy, float tx, float ty, float raw_z, float stored_z) {
    if (st_ != ST_PROBING || sid != sid_ || !g29_begun_) { ++stale_events_; return; }
    const MeshErr e = mesh_.add(sid, ix, iy, tx, ty, raw_z, stored_z);
    if (e != ME_OK) { fail(e == ME_ORDER ? R_POINT_ORDER : e == ME_DUPLICATE ? R_POINT_DUPLICATE : e == ME_SESSION ? R_POINT_SESSION : R_POINT_INVALID); return; }
    const uint8_t no = (uint8_t)(point_no(ix, iy) + 1);
    disp(D_PROGRESS, no);
    disp(D_CELL, (uint8_t)(no - 1), stored_z);
  }
  void on_g29_finished(uint32_t sid, const G29Result &r) {
    if (st_ != ST_PROBING || sid != sid_) { ++stale_events_; return; }
    if (cancel_pending_) { cancelled(R_CANCEL_AFTER_STEP); return; }
    if (!g29_begun_) { fail(R_PROBE_FAILED); return; }
    if (!r.endscript_ok) { fail(R_G29_ENDSCRIPT_FAILED); return; }       // spezifischer Grund zuerst: das Endskript-G28 oder der Zustand danach ist nicht in Ordnung
    if (!r.success || r.dryrun || r.faux) { fail(R_PROBE_FAILED); return; }
    go(ST_VALIDATING, R_PROBE_STARTED);
  }

  void tick() {
    if (!active()) return;
    { Precond sq; p_.read_precond(p_.ctx, sq); if (sq.marlin_stopped) { fail(R_MARLIN_STOPPED); return; } }      // SV04 NEXT C4: Marlin gestoppt (z. B. BLTouch-stop()) -> in JEDEM aktiven Zustand sofort FAILED mit dem richtigen Grund, vor der Heizungspruefung
    const uint32_t t = now();
    switch (st_) {
      case ST_HEATING: case ST_STABILIZING: {
        BedState b; p_.bed_read(p_.ctx, b);
        if (!heater_ok(b, false)) return;
        if (!precond_ok_running()) return;
        disp(D_TEMP, 0, b.temp_c, b.target_c);
        if (st_ == ST_HEATING) {
          if (in_band(b)) { stable_since_ = t; in_band_seen_ = true; go(ST_STABILIZING, R_BAND_REACHED); }
          else if (t - enter_ms_ > c_.heat_timeout_ms) fail(R_HEAT_TIMEOUT);
          return;
        }
        if (!in_band(b)) stable_since_ = 0;                                         // verlassen => Zeitmessung beginnt neu
        else if (stable_since_ == 0) stable_since_ = t;
        if (stable_since_ != 0 && t - stable_since_ >= c_.stable_ms) {
          go(ST_HOMING_PENDING, R_HEAT_STABLE);
          home_issued_ = true;
          if (!p_.home_request(p_.ctx, sid_)) fail(R_HOME_REJECTED);
          return;
        }
        if (t - enter_ms_ > c_.stab_timeout_ms) fail(R_STAB_TIMEOUT);
        return;
      }
      case ST_HOMING_PENDING: case ST_PROBING: {
        BedState b; p_.bed_read(p_.ctx, b);
        if (!heater_ok(b, true)) return;
        if (st_ == ST_PROBING && !g29_begun_ && t - enter_ms_ > c_.g29_begin_grace_ms && p_.cmd_idle(p_.ctx)) { fail(R_PROBE_FAILED); return; }   // G29 hat nie begonnen und nichts ist mehr in der Queue
        const uint32_t lim = st_ == ST_HOMING_PENDING ? c_.home_timeout_ms : c_.probe_timeout_ms;
        if (t - enter_ms_ > lim) fail(st_ == ST_HOMING_PENDING ? R_HOME_TIMEOUT : R_PROBE_TIMEOUT);
        return;
      }
      case ST_VALIDATING: do_validate(); return;
      case ST_ENABLING: do_enable(); return;
      case ST_SAVE_PENDING: do_save(); return;
      case ST_VERIFYING: do_verify(); return;
      default: return;
    }
  }
};

}  // namespace sv04c
