#pragma once
/**
 * SV04 NEXT C3 (Claude), AP1: begrenzte Z-Fahrstrecke beim Z-Homing mit BLTouch, wenn die Z-Position BEKANNT ist.
 * BEFUND (echter OEM-Code): homeaxis(Z) faehrt "Fast move towards endstop" mit move_length = 1.5 x max_length(Z) (motion.cpp, "Home Fast"). Bei Z_MAX_POS 400 sind das bis zu 600 mm bei 4 mm/s (ca. 150 s). Kommt der
 * Trigger NIE (Kabelbruch, Sensor taub), gibt es vor dem Ende dieser Strecke keinen Schutz.
 * REGEL (konservativ, nur aus Marlin-/Konfigurationswerten abgeleitet, KEINE mechanische Behauptung):
 *   - Z war VOR dem Homing referenziert und vertrauenswuerdig und ist endlich  ->  der Trigger wird bei z = -probe.offset.z erwartet, also nach (z + probe.offset.z) mm. Erlaubt werden diese Strecke PLUS eine
 *     Toleranz (Standard: Z_CLEARANCE_DEPLOY_PROBE = 10 mm, die Marlin-eigene Sicherheitshoehe fuer Sonde), nie mehr als die OEM-Strecke. Kommt der Trigger in dieser Strecke nicht, ist das ein Homing-Fehler
 *     (Sovol-Variante: kill) statt einer 600-mm-Fahrt.
 *   - Z unbekannt (Kaltstart, Vertrauen entzogen) oder irgendein Wert nicht endlich  ->  UNVERAENDERTE OEM-Strecke. Hier KANN keine Grenze begruendet werden (Position unbekannt); das bleibt ein dokumentiertes Restrisiko.
 * Aendert nur die LAENGE der schnellen Fahrt; Richtung, Geschwindigkeit, Deploy/Stow und alle Alarmpfade bleiben unveraendert.
 */
#include <math.h>
namespace sv04c {

struct ZhIn {
  float move_length;       // OEM-Strecke in mm (negativ bei Z_HOME_DIR = -1)
  bool  z_known;           // Z war referenziert UND vertrauenswuerdig, bevor das Homing begann
  float z;                 // aktuelle logische Z-Position
  float probe_offset_z;    // probe.offset.z (negativ: Duese unter der Sonde)
  float margin;            // Toleranz in mm
};

inline bool zh_finite(const float v) { return v == v && (v - v) == 0.0f; }

inline float zh_limit(const ZhIn &in) {
  if (!in.z_known || !zh_finite(in.z) || !zh_finite(in.probe_offset_z) || !zh_finite(in.margin) || !zh_finite(in.move_length) || in.margin <= 0.0f || in.move_length == 0.0f) return in.move_length;
  float bound = in.z + in.probe_offset_z + in.margin;          // erwartete Strecke bis zum Trigger + Toleranz
  if (bound < in.margin) bound = in.margin;                    // steht die Duese schon auf/unter der erwarteten Triggerhoehe: mindestens die Toleranz
  const float full = in.move_length < 0.0f ? -in.move_length : in.move_length;
  const float lim = bound < full ? bound : full;               // nie laenger als die OEM-Strecke
  return in.move_length < 0.0f ? -lim : lim;
}

// SV04 NEXT C5: Z UNBEKANNT (Kaltstart). Die Position ist unbekannt, deshalb ist KEINE Strecke ab der aktuellen Position begruendbar. Begruendbar ist nur eine Obergrenze aus der KONFIGURATION: die Z-Bewegung ueber den
// konfigurierten Verfahrweg (max_length(Z) = Z_MAX_POS - Z_MIN_POS) plus die Marlin-eigene Sondenfreiheit hinaus kann kein gueltiger Referenzweg sein. Marlin selbst nimmt 1,5 x max_length (Reserve fuer verlorene Schritte).
// Annahme (NICHT gemessen): die Konfiguration bildet die Mechanik ab. Stimmt das nicht (Verfahrweg > Z_MAX_POS + Toleranz), scheitert ein Homing aus der obersten Stellung fail-closed.
inline float zh_cold_limit(const float move_length, const float max_len, const float margin) {
  if (!zh_finite(move_length) || !zh_finite(max_len) || !zh_finite(margin) || max_len <= 0.0f || margin <= 0.0f || move_length == 0.0f) return move_length;
  const float cap = max_len + margin;
  const float full = move_length < 0.0f ? -move_length : move_length;
  const float lim = cap < full ? cap : full;
  return move_length < 0.0f ? -lim : lim;
}

} // namespace sv04c

#ifndef SV04_CLAUDE_ZHOME_LIMIT
  #define SV04_CLAUDE_ZHOME_LIMIT 1          // 0 = OEM-Verhalten unveraendert
#endif
#ifdef Z_CLEARANCE_DEPLOY_PROBE
  #ifndef SV04_CLAUDE_ZHOME_MARGIN_MM
    #define SV04_CLAUDE_ZHOME_MARGIN_MM Z_CLEARANCE_DEPLOY_PROBE
  #endif
  inline float sv04c_zhome_limit(const float move_length, const bool z_known, const float z, const float probe_offset_z) {
    return sv04c::zh_limit(sv04c::ZhIn{ move_length, z_known, z, probe_offset_z, (float)(SV04_CLAUDE_ZHOME_MARGIN_MM) });
  }
  // SV04 NEXT C5: mit max_length(Z) wird auch bei UNBEKANNTEM Z auf die konfigurationsabgeleitete Obergrenze begrenzt (Kaltstart)
  inline float sv04c_zhome_limit(const float move_length, const bool z_known, const float z, const float probe_offset_z, const float max_len) {
    return z_known ? sv04c_zhome_limit(move_length, true, z, probe_offset_z) : sv04c::zh_cold_limit(move_length, max_len, (float)(SV04_CLAUDE_ZHOME_MARGIN_MM));
  }
#endif
