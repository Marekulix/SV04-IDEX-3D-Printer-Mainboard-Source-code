#!/usr/bin/env python3
"""318 NO-FLASH integration into a NEW copy of an already composed 309 Marlin repo."""
import pathlib,hashlib,json,shutil,sys

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 if len(sys.argv)!=3:
  print('usage: python integrate_318.py /path/to/COMPLETE_COMPOSED_309 /path/to/NEW_318_DIR');return 2
 src=pathlib.Path(sys.argv[1]).resolve();dst=pathlib.Path(sys.argv[2]).resolve()
 here=pathlib.Path(__file__).resolve().parent;assets=here/'assets'
 if src==dst or dst.exists() or not (src/'Marlin'/'src'/'MarlinCore.cpp').exists():
  print('BLOCKED: existing target, identical paths, or missing complete OEM Marlin source');return 2
 mapping={'tool_change.cpp':'Marlin/src/module/tool_change.cpp','motion.cpp':'Marlin/src/module/motion.cpp','G29.cpp':'Marlin/src/gcode/bedlevel/abl/G29.cpp'}
 expected=json.loads((assets/'base_309_hashes.json').read_text())
 for k,v in mapping.items():
  p=src/v
  if not p.is_file() or sha(p)!=expected[k]:
   print('BLOCKED: source hash mismatch:',v,sha(p) if p.is_file() else 'missing');return 3
 shutil.copytree(src,dst)
 for k,v in mapping.items():shutil.copy2(assets/'patched_309'/k,dst/v)
 # Only overwrite the explicit coordinator and adapter. All other 309 OEM sources preserved.
 for rel,file in [('Marlin/src/feature/sv04_claude_auto60/sv04_claude_auto60_core.h','sv04_claude_auto60_core.h'),('Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc','sv04_claude_auto60_marlin.inc')]:
  target=dst/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(assets/file,target)
 # The C5 policy header is required for motion.cpp; leave all other 309 dependencies intact.
 policy=assets/'source_dependencies'/'src/feature/sv04_claude_auto60/sv04_claude_zhome_policy.h'
 target=dst/'Marlin/src/feature/sv04_claude_auto60/sv04_claude_zhome_policy.h'
 target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(policy,target)
 after=json.loads((assets/'expected_318_hashes.json').read_text())
 for k,v in mapping.items():
  if sha(dst/v)!=after[k]:raise RuntimeError('post integration hash mismatch '+v)
 print('318 SOURCE OVERLAY APPLIED; NOT COMPILED; NOT HARDWARE-TESTED; DO NOT FLASH')
 return 0
if __name__=='__main__':sys.exit(main())
