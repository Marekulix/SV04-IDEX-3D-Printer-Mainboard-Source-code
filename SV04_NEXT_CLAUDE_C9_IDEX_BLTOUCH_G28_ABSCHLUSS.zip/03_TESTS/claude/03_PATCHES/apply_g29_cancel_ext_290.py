#!/usr/bin/env python3
"""SV04 NEXT 290: Erweiterung von 289 "G29-CANCEL V1" (ChatGPT) um GENAU EINE Pruefung unmittelbar VOR dem G29-Endskript.
V1 prueft VOR und NACH jeder Messung. Trifft ein Abbruch nach der letzten Pruefung ein (Fenster zwischen letzter Messung und Endskript), lief das Endskript "G28 XY" trotzdem und bewegte beide IDEX-Wagen.
Hier wird an dieser einen Stelle ZUSAETZLICH SV04Claude_G29CancelRequested() gefragt (liest den DWIN-Puffer selbst, nur Auto60/PROBING; Benutzer-G29 -> immer false).
Aufruf: apply_g29_cancel_ext_290.py <Pfad zu G29.cpp>   (idempotent; bricht bei fehlendem/mehrdeutigem Anker ab; setzt V1 voraus)"""
import sys
from pathlib import Path

MARK = 'SV04 NEXT G29-CANCEL EXT 290'
OLD = """    // SV04 NEXT G29-CANCEL V1: do NOT move both IDEX carriages after Auto60 cancel.
    #if ENABLED(RTS_AVAILABLE) && ENABLED(AUTO_BED_LEVELING_BILINEAR)
      if (!sv04_g29_cancelled)
    #endif
        process_subcommands_now_P(PSTR(Z_PROBE_END_SCRIPT));"""
NEW = """    // SV04 NEXT G29-CANCEL V1: do NOT move both IDEX carriages after Auto60 cancel.
    // SV04 NEXT G29-CANCEL EXT 290: ask ONCE MORE right before the end script (a cancel arriving after the last per-probe check).
    #if ENABLED(RTS_AVAILABLE) && ENABLED(AUTO_BED_LEVELING_BILINEAR)
      if (!sv04_g29_cancelled && SV04Claude_G29CancelRequested()) sv04_g29_cancelled = true;
      if (!sv04_g29_cancelled)
    #endif
        process_subcommands_now_P(PSTR(Z_PROBE_END_SCRIPT));"""


def transform(text):
    if MARK in text:
        return text, False
    if text.count(OLD) != 1:
        raise ValueError('CONFLICT: Anker des V1-Endskript-Blocks %d-mal gefunden (erwartet 1); V1 nicht installiert oder G29.cpp veraendert' % text.count(OLD))
    return text.replace(OLD, NEW), True


def main(argv):
    if len(argv) != 2:
        print(__doc__); return 2
    p = Path(argv[1]); t = p.read_text(encoding='utf-8')
    t2, changed = transform(t)
    if changed:
        p.write_text(t2, encoding='utf-8'); print('APPLIED G29-CANCEL EXT 290', p)
    else:
        print('ALREADY APPLIED G29-CANCEL EXT 290', p)
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
