#!/usr/bin/env python3
"""SV04 NEXT / Claude parallel: reproduzierbare Patchanwendung auf PRISTINE OEM-Dateien (kopierend, byte-genau, fail-closed). KEIN Flash, KEINE Aenderung der Eingaben.
Patcht NUR Einfuegungen in: Marlin/src/gcode/bedlevel/abl/G29.cpp, Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp, Marlin/src/gcode/gcode.cpp.
NICHT angefasst (gesperrt, ChatGPT Punkt 1): G28.cpp, motion.cpp, motion.h, T1-Parklogik, BLTouch::deploy_proc.
Legt zusaetzlich die neuen Dateien ab (Haken-Header, Adapter, Kern, G29-Sitzung) und erzeugt die OEM-Sendeschleife WOERTLICH aus der OEM-Datei (ohne M420 S1).
Die Hilfsfunktionen (Kommentar-/#if-0-Erkennung, Klammertiefe, Ankersuche, Sendeschleife) sind uebernommen aus meiner frueheren Lieferung patch194.py (sha256 der Quelle: 6a7aaa97ccf9baee6eb4adba061df6b0d8a2b48d5b371e655475521183726372).
Aufruf: apply_claude_parallel.py --lcd-oem LCD_RTS.cpp --g29-oem G29.cpp --gcode-oem gcode.cpp --out ORDNER [--source-root ../02_SOURCE] [--report r.json]"""
import argparse
import hashlib
import json
import os
import re
import sys
import tempfile
from pathlib import Path

class PatchError(Exception):
    pass


def sha(b):
    return hashlib.sha256(b).hexdigest()


def eol_of(data):
    crlf = data.count(b'\r\n')
    lf = data.count(b'\n') - crlf
    if data.count(b'\r') != crlf:
        raise PatchError('einzelne CR-Zeichen: Zeilenenden nicht eindeutig')
    if crlf and lf:
        raise PatchError('gemischte Zeilenenden (CRLF und LF): nicht eindeutig')
    return b'\r\n' if crlf else b'\n'


def code_mask(data):
    n, m, i, state = len(data), bytearray(len(data)), 0, 0
    while i < n:
        c, two = data[i:i + 1], data[i:i + 2]
        if state == 0:
            if two == b'//':
                state = 1; i += 2; continue
            if two == b'/*':
                state = 2; i += 2; continue
            if c == b'"':
                state = 3; i += 1; continue
            if c == b"'":
                state = 4; i += 1; continue
            m[i] = 1
        elif state == 1:
            if c == b'\n':
                state = 0
        elif state == 2:
            if two == b'*/':
                state = 0; i += 2; continue
        elif state == 3:
            if c == b'\\':
                i += 2; continue
            if c == b'"' or c == b'\n':
                state = 0
        elif state == 4:
            if c == b'\\':
                i += 2; continue
            if c == b"'" or c == b'\n':
                state = 0
        i += 1
    return m


def inactive_if0(data):
    inactive, pos, stack = bytearray(len(data)), 0, []
    for line in data.split(b'\n'):
        start, pos = pos, pos + len(line) + 1
        s = line.strip()
        if s.startswith(b'#'):
            d = re.sub(rb'^#\s*', b'', s)
            if re.match(rb'if\s*\(?\s*0\s*\)?\s*$', d):
                stack.append(True); continue
            if re.match(rb'(if|ifdef|ifndef)\b', d):
                stack.append(False); continue
            if re.match(rb'(else|elif)\b', d) and stack:
                stack[-1] = False; continue
            if re.match(rb'endif\b', d) and stack:
                stack.pop(); continue
        if any(stack):
            for k in range(start, min(start + len(line), len(data))):
                inactive[k] = 1
    return inactive


def to_eol(text, eol):
    return text.replace('\n', eol.decode()).encode('ascii')


def find_one(data, anchor, probe, label, eol, mask, ina):
    a = to_eol(anchor, eol)
    hits, i = [], 0
    while True:
        j = data.find(a, i)
        if j < 0:
            break
        hits.append(j)
        i = j + 1
    if len(hits) != 1:
        raise PatchError('%s: Anker muss genau einmal vorkommen, gefunden %d' % (label, len(hits)))
    p = hits[0]
    q = p + a.find(probe.encode('ascii'))
    if not all(mask[q:q + len(probe)]) or any(ina[q:q + len(probe)]):
        raise PatchError('%s: Anker liegt in Kommentar/String/#if 0 (kein aktiver Code)' % label)
    return p, len(a)


def depth_at(data, mask, pos):
    d = 0
    for i in range(pos):
        if mask[i]:
            if data[i:i + 1] == b'{':
                d += 1
            elif data[i:i + 1] == b'}':
                d -= 1
                if d < 0:
                    raise PatchError('Klammern unausgewogen (Tiefe < 0)')
    return d


def function_span(data, mask):
    m = re.search(rb'GcodeSuite::G29\s*\(', data)
    if not m or not mask[m.start()]:
        raise PatchError('GcodeSuite::G29( nicht gefunden')
    d, i, start = 0, m.end(), None
    while i < len(data):
        if mask[i]:
            ch = data[i:i + 1]
            if ch == b'{':
                d += 1
                start = i if start is None else start
            elif ch == b'}':
                d -= 1
                if start is not None and d == 0:
                    return start, i
        i += 1
    raise PatchError('Ende von GcodeSuite::G29 nicht gefunden')


def oem_mesh_loop(lcd_text, eol):
    """WOERTLICH die Sendeschleife des OEM (zweite Stelle, ohne auskommentierte Zeile) ohne die abschliessende M420-Zeile."""
    lines = lcd_text.split('\n')
    starts = [i for i, l in enumerate(lines) if l.strip() == 'bool zig = false;']
    if len(starts) != 2:
        raise PatchError('OEM-Sendeschleife: erwartet 2 Stellen, gefunden %d' % len(starts))
    s = starts[1]
    e = next((i for i in range(s, len(lines)) if M420 in lines[i]), None)
    if e is None:
        raise PatchError('OEM-Sendeschleife: M420-Zeile nicht gefunden')
    body = lines[s:e]
    txt = '\n'.join(body)
    if txt.count('RTS_SndData(z_values[x][y] * 1000, AUTO_BED_LEVEL_1POINT_VP + showcount * 2);') != 1 or re.search(r'queue|settings|M420|M500', txt):
        raise PatchError('OEM-Sendeschleife entspricht nicht der erwarteten Form')
    ws = len(body[0]) - len(body[0].lstrip())
    out = '\n'.join(('  ' + l[ws:]) if l.strip() else '' for l in body).replace('\t', '  ')
    # EINZIGE textuelle Anpassung: im Original steht die Schleife in der Memberfunktion RTSSHOW::RTS_Init() (unqualifizierter Aufruf); hier ist sie eine freie Funktion.
    if out.count('RTS_SndData(') != 1:
        raise PatchError('OEM-Sendeschleife: genau ein RTS_SndData-Aufruf erwartet')
    return out.replace('RTS_SndData(', 'rtscheck.RTS_SndData(')




# ---------------------------------------------------------------------------------------------------- Ziele und Anker
G29_REL = Path('Marlin/src/gcode/bedlevel/abl/G29.cpp')
LCD_REL = Path('Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp')
GCODE_REL = Path('Marlin/src/gcode/gcode.cpp')
G28_REL = Path('Marlin/src/gcode/calibrate/G28.cpp')
NEW_FILES = (Path('Marlin/src/lcd/e3v2/creality/sv04_claude_hooks.h'), Path('Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc'),
             Path('Marlin/src/feature/sv04_claude_auto60/sv04_claude_auto60_core.h'), Path('Marlin/src/feature/sv04_claude_auto60/sv04_claude_g29_session.h'),
             Path('Marlin/src/feature/sv04_claude_auto60/sv04_claude_eeprom_core.h'))      # 283: portabler EEPROM-Kern (Rohlesung, Undo-Journal, Startwiederherstellung)
LOOP_REL = Path('Marlin/src/lcd/e3v2/creality/sv04_claude_oem_mesh_loop.inc')
LCD_INCLUDE = '#include "LCD_RTS.h"'
LCD_FUNC = 'void RTS_AutoBedLevelPage()\n{\n  if(waitway == 3)\n  {'
LCD_FUNC_CODE = 'void RTS_AutoBedLevelPage()'
LCD_TICK = '// looping at the loop function\nvoid RTSUpdate()\n{\n'
LCD_TICK_CODE = 'void RTSUpdate()'
LCD_LOCK = 'void RTSSHOW::RTS_HandleData()\n{\n  int Checkkey = -1;\n'
LCD_LOCK_CODE = 'int Checkkey = -1;'
G29_A1 = '#elif ENABLED(RTS_AVAILABLE)\n  #include "../../../lcd/e3v2/creality/LCD_RTS.h"\n#endif\n'
G29_A1_CODE = '#include'
G29_A2 = "  // Don't allow auto-leveling without homing first\n  if (homing_needed_error()) G29_RETURN(false);\n"
G29_A2_CODE = 'if (homing_needed_error()) G29_RETURN(false);'
G29_A3 = "    const ProbePtRaise raise_after = parser.boolval('E') ? PROBE_PT_STOW : PROBE_PT_RAISE;\n"
G29_A3_CODE = 'const ProbePtRaise raise_after'
G29_A4P = '            TERN_(EXTENSIBLE_UI, ExtUI::onMeshUpdate(abl.meshCount, z));\n'
G29_A4P_CODE = 'TERN_(EXTENSIBLE_UI, ExtUI::onMeshUpdate(abl.meshCount, z));'
G29_A4 = '              rtscheck.RTS_SndData(z*1000, AUTO_BED_LEVEL_1POINT_VP + (showcount - 1) * 2);\n'
G29_A4_CODE = 'rtscheck.RTS_SndData(z*1000'
G29_A5 = '  #if ENABLED(RTS_AVAILABLE)\n    RTS_AutoBedLevelPage();\n  #endif\n  report_current_position();\n'
G29_A5_CODE = 'RTS_AutoBedLevelPage();'
G28_INC = '  #include "../../lcd/e3v2/creality/LCD_RTS.h"\n#endif\n'
G28_INC_CODE = '#include'
G28_ENTRY = 'void GcodeSuite::G28() {\n  DEBUG_SECTION(log_G28, "G28", DEBUGGING(LEVELING));\n'
G28_ENTRY_CODE = 'void GcodeSuite::G28()'
GC_A1 = '#include "../MarlinCore.h" // for idle, kill\n'
GC_A1_CODE = '#include'
GC_A2 = '        case 7219: M7219(); break;                                // M7219: Set LEDs, columns, and rows\n      #endif\n\n      default: parser.unknown_command_warning(); break;\n'
GC_A2_CODE = 'default: parser.unknown_command_warning(); break;'
OLD_MARKERS = (b'sv04next190', b'sv04next191', b'sv04next192', b'sv04next193', b'sv04next194', b'SV04Next_G29', b'SV04Next_SendCellLive194')
MARK = b'SV04Claude_'
M420 = 'queue.enqueue_now_P(PSTR("M420 S1"));'   # letzte Zeile der OEM-Sendeschleife; wird NICHT uebernommen (kein M420 S1 durch den Patch)
COND = '#if ENABLED(RTS_AVAILABLE) && ENABLED(AUTO_BED_LEVELING_BILINEAR)'


def _edit(data, edits, eol):
    out, cur = bytearray(), 0
    for pos, rm, txt in sorted(edits):
        out += data[cur:pos] + to_eol(txt, eol)
        cur = pos + rm
    out += data[cur:]
    return bytes(out)


def _guard(data):
    for mk in OLD_MARKERS:
        if mk in data:
            raise PatchError('Vorgaengerpatch 190-194 gefunden: nur auf pristine OEM-Datei anwenden')
    if MARK in data:
        raise PatchError('Claude-Parallel-Patch bereits angewendet')


def patch_g29(data, allow_unverified_depth=False):
    _guard(data)
    eol = eol_of(data)
    mask, ina = code_mask(data), inactive_if0(data)
    p1, l1 = find_one(data, G29_A1, G29_A1_CODE, 'G29 A1 Include', eol, mask, ina)
    p2, l2 = find_one(data, G29_A2, G29_A2_CODE, 'G29 A2 Homing-Waechter', eol, mask, ina)
    p3, l3 = find_one(data, G29_A3, G29_A3_CODE, 'G29 A3 Messbeginn', eol, mask, ina)
    p4p, l4p = find_one(data, G29_A4P, G29_A4P_CODE, 'G29 A4p Punkt-Haken', eol, mask, ina)
    p4, l4 = find_one(data, G29_A4, G29_A4_CODE, 'G29 A4 Live-Senden', eol, mask, ina)
    p5, l5 = find_one(data, G29_A5, G29_A5_CODE, 'G29 A5 Abschluss', eol, mask, ina)
    if not (p1 < p2 < p3 < p4p < p4 < p5):
        raise PatchError('Anker in unerwarteter Reihenfolge')
    b0, b1 = function_span(data, mask)
    if not all(b0 < p < b1 for p in (p2, p3, p4p, p4, p5)) or p1 > b0:
        raise PatchError('Anker liegen nicht an der erwarteten Stelle relativ zu GcodeSuite::G29')
    try:
        d2, d5, d3, d4 = depth_at(data, mask, p2), depth_at(data, mask, p5), depth_at(data, mask, p3), depth_at(data, mask, p4p)
    except PatchError:
        if not allow_unverified_depth:
            raise
        d2 = d5 = 1
        d3 = d4 = 2
    if (d2 != 1 or d5 != 1) and not allow_unverified_depth:
        raise PatchError('Klammertiefe Homing-Waechter/Abschluss ist %d/%d (erwartet 1/1)' % (d2, d5))
    if (d3 < 1 or d4 < 1) and not allow_unverified_depth:
        raise PatchError('Messbeginn/Punkt-Haken liegen ausserhalb von Bloecken der Funktion')
    body = data[b0:p5].decode('latin-1')
    if not re.search(r'\bbool\s+faux\b|\bfaux\s*=', body):
        raise PatchError("'faux' ist vor dem Abschluss-Anker nicht deklariert")
    for need in (b'abl.measured_z', b'abl.dryrun', b'abl.probePos', b'abl.meshCount'):
        if need not in data[b0:b1]:
            raise PatchError(need.decode() + ' in GcodeSuite::G29 nicht gefunden')
    ins = [
        (p1 + l1, 0, '#if ENABLED(RTS_AVAILABLE)\n  #include "../../../lcd/e3v2/creality/sv04_claude_hooks.h"\n#endif\n'),
        (p2 + l2, 0, '  ' + COND + '\n    // SV04 Claude: RAII guard. Starts a G29 session (backs up mesh/grid/factor), binds an armed Auto60 session and reports an abort on EVERY return path.\n    SV04Claude_G29Guard sv04claude_guard;\n  #endif\n'),
        (p3 + l3, 0, '    ' + COND + '\n      sv04claude_guard.probing();   // measurement phase reached: from here a failure/abort rolls the RAM mesh back\n    #endif\n'),
        (p4p + l4p, 0, '            ' + COND + '\n              sv04claude_guard.point(abl.meshCount.x, abl.meshCount.y, abl.probePos.x, abl.probePos.y, abl.measured_z, z);   // actual cell order, raw + stored value\n            #endif\n'),
        (p4, l4, '              #if SV04_CLAUDE_G29_GUARD_LIVE\n                SV04Claude_SendCellLive(z, (showcount - 1));\n              #else\n' + G29_A4 + '              #endif\n'),
        (p5, 0, '  ' + COND + '\n    sv04claude_guard.finish(!isnan(abl.measured_z), abl.dryrun, faux);   // before the OEM page switch\n  #endif\n'),
    ]
    return _edit(data, ins, eol)


def patch_lcd(data):
    _guard(data)
    eol = eol_of(data)
    mask, ina = code_mask(data), inactive_if0(data)
    inc_p, inc_len = find_one(data, LCD_INCLUDE, '#include', 'LCD include', eol, mask, ina)
    fn_p, _ = find_one(data, LCD_FUNC, LCD_FUNC_CODE, 'LCD RTS_AutoBedLevelPage', eol, mask, ina)
    tk_p, tk_len = find_one(data, LCD_TICK, LCD_TICK_CODE, 'LCD RTSUpdate', eol, mask, ina)
    lk_p, lk_len = find_one(data, LCD_LOCK, LCD_LOCK_CODE, 'LCD RTS_HandleData', eol, mask, ina)
    if not (inc_p < lk_p < tk_p < fn_p):
        raise PatchError('LCD-Anker in unerwarteter Reihenfolge')
    oem_mesh_loop(data.decode('utf-8'), eol)           # prueft, dass die OEM-Sendeschleife in der erwarteten Form vorliegt
    ins = [
        (inc_p + inc_len, 0, '\n#include "sv04_claude_hooks.h"\n#include "../../../feature/sv04_claude_auto60/sv04_claude_auto60_core.h"\n#include "../../../feature/sv04_claude_auto60/sv04_claude_g29_session.h"'),
        (lk_p + lk_len, 0, '  if (SV04Claude_Auto60_Busy())   // SV04 Claude: while an Auto60 run is active a touch is a fail-safe CANCEL request; the touched key itself is discarded (the cancel path never depends on a locked UI)\n  {\n    SV04Claude_Auto60_TouchCancel();\n    memset(&recdat, 0, sizeof(recdat));\n    recdat.head[0] = FHONE;\n    recdat.head[1] = FHTWO;\n    return;\n  }\n'),
        (tk_p + tk_len, 0, '  SV04Claude_Auto60_Tick();   // SV04 Claude: cooperative Auto60 coordinator tick (re-entrancy guarded)\n'),
        (fn_p, 0, '// SV04 Claude: Auto60 adapter + G29 hooks (see 02_SOURCE). No G28/IDEX/motion/BLTouch change.\n#include "sv04_claude_auto60_marlin.inc"\n\n'),
    ]
    return _edit(data, ins, eol)


def patch_gcode(data):
    _guard(data)
    eol = eol_of(data)
    mask, ina = code_mask(data), inactive_if0(data)
    a1, l1 = find_one(data, GC_A1, GC_A1_CODE, 'gcode include', eol, mask, ina)
    a2, _ = find_one(data, GC_A2, GC_A2_CODE, 'gcode M-default', eol, mask, ina)
    dflt = a2 + data[a2:].find(b'      default:')
    ins = [
        (a1 + l1, 0, '#if ENABLED(RTS_AVAILABLE)\n  extern void SV04Claude_Auto60_Gcode();   // SV04 Claude: M1060 (defined in LCD_RTS.cpp)\n#endif\n'),
        (dflt, 0, '      #if ENABLED(RTS_AVAILABLE)\n        case 1060: SV04Claude_Auto60_Gcode(); break;   // M1060: SV04 Claude Auto60 (S1 start, S0 cancel, no S = status)\n      #endif\n\n'),
    ]
    return _edit(data, ins, eol)


def patch_g28(data):
    """Stufe 2 auf dem durch apply_277_p1.py gehaerteten G28.cpp: Include + RAII-Waechter am Eintritt. Reine Einfuegungen."""
    _guard(data)
    if b'SV04_NEXT_P1_277' not in data:
        raise PatchError('G28.cpp: Stufe 1 (apply_277_p1.py) fehlt - das Backend braucht das exportierte P1-Ergebnis')
    eol = eol_of(data)
    mask, ina = code_mask(data), inactive_if0(data)
    i1, l1 = find_one(data, G28_INC, G28_INC_CODE, 'G28 include', eol, mask, ina)
    e1, l2 = find_one(data, G28_ENTRY, G28_ENTRY_CODE, 'G28 entry', eol, mask, ina)
    if not i1 < e1:
        raise PatchError('G28-Anker in unerwarteter Reihenfolge')
    ins = [
        (i1 + l1, 0, '#if ENABLED(RTS_AVAILABLE)\n  #include "../../lcd/e3v2/creality/sv04_claude_hooks.h"\n#endif\n'),
        (e1 + len(to_eol('void GcodeSuite::G28() {\n', eol)), 0, '  #if ENABLED(RTS_AVAILABLE) && SV04_CLAUDE_HOME_BACKEND_AVAILABLE\n    // SV04 Claude: binds a G28 requested by Auto60 (or refuses the G28 of a discarded request) and reports the P1 result of THIS G28 exactly once on EVERY exit path.\n    // Declared BEFORE the P1 result guard, so it is destroyed AFTER the result was committed.\n    SV04Claude_G28Guard sv04claude_g28_guard;\n    if (!sv04claude_g28_guard.allowed()) return;\n  #endif\n'),
    ]
    return _edit(data, ins, eol)


def write_atomic(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix='.sv04c_')
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
        os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.remove(tmp)
        raise


def run(lcd, g29, gcode, out, source_root, overwrite=False, allow_unverified_depth=False, report=None, g28=None):
    lcd, g29, gcode, out, source_root = Path(lcd), Path(g29), Path(gcode), Path(out), Path(source_root)
    ins = [p.resolve() for p in (lcd, g29, gcode) + ((Path(g28),) if g28 else ())]
    if out.resolve() in {p.parent for p in ins} or any(str(p).startswith(str(out.resolve()) + os.sep) for p in ins):
        raise PatchError('Ausgabeverzeichnis enthaelt/ist ein Eingabeverzeichnis: In-place-Aenderung der Originale ist verboten')
    for n in NEW_FILES:
        if not (source_root / n).is_file():
            raise PatchError('Quelldatei fehlt: ' + str(source_root / n))
    raws = {'lcd': lcd.read_bytes(), 'g29': g29.read_bytes(), 'gcode': gcode.read_bytes()}
    loop = oem_mesh_loop(raws['lcd'].decode('utf-8'), eol_of(raws['lcd'])) + '\n'
    plan = [(out / LCD_REL, patch_lcd(raws['lcd']), raws['lcd']), (out / G29_REL, patch_g29(raws['g29'], allow_unverified_depth), raws['g29']), (out / GCODE_REL, patch_gcode(raws['gcode']), raws['gcode'])]
    if g28:
        raws['g28'] = Path(g28).read_bytes()
        plan.append((out / G28_REL, patch_g28(raws['g28']), raws['g28']))
    for n in NEW_FILES:
        plan.append((out / n, (source_root / n).read_bytes(), None))
    plan.append((out / LOOP_REL, loop.encode('utf-8'), None))
    if not overwrite:
        ex = [str(p) for p, _, _ in plan if p.exists()]
        if ex:
            raise PatchError('Ausgabe existiert bereits (--overwrite ausdruecklich angeben): ' + ', '.join(ex))
    rep = {'tool': 'apply_claude_parallel.py', 'flash_allowed': False, 'hardware_tested': False, 'touches_locked_files': False,   # 277: G28/motion-Aenderungen stammen aus Stufe 1, nicht aus diesem Werkzeug
           'note_277': 'Stufe 2: G28.cpp erhaelt NUR den Waechter (Einfuegung); die Haertung von G28/motion liegt in apply_277_p1.py (Stufe 1). In diesem Auftrag ist G28/motion NICHT mehr gesperrt.',
           'adds_settings_save': 'ja: genau ein Aufruf (sv04c_save), nur aus dem Koordinator-Zustand SAVE_PENDING nach vollstaendig validierter Kette erreichbar',
           'files': [{'path': str(p.relative_to(out)), 'sha256': sha(n), 'input_sha256': sha(o) if o is not None else None, 'bytes': len(n)} for p, n, o in plan]}
    for p, n, _ in plan:
        write_atomic(p, n)
    if report:
        Path(report).write_text(json.dumps(rep, indent=1))
    return rep


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--lcd-oem', required=True)
    ap.add_argument('--g29-oem', required=True)
    ap.add_argument('--gcode-oem', required=True)
    ap.add_argument('--g28-oem', help='G28.cpp NACH Stufe 1 (apply_277_p1.py): erhaelt den G28-Waechter')
    ap.add_argument('--out', required=True)
    ap.add_argument('--source-root', default=str(Path(__file__).resolve().parents[1] / '02_SOURCE'))
    ap.add_argument('--overwrite', action='store_true')
    ap.add_argument('--allow-unverified-depth', action='store_true')
    ap.add_argument('--report')
    a = ap.parse_args(argv)
    try:
        rep = run(a.lcd_oem, a.g29_oem, a.gcode_oem, a.out, a.source_root, a.overwrite, a.allow_unverified_depth, a.report, a.g28_oem)
    except PatchError as e:
        print('PATCH ABGELEHNT (nichts geschrieben):', e, file=sys.stderr)
        return 3
    print(json.dumps(rep, indent=1))
    return 0


if __name__ == '__main__':
    sys.exit(main())
