#!/usr/bin/env python3
"""Erzeugt die reproduzierbaren Diffs 282 -> 290 der Claude-Firmwaredateien (unified) nach diffs/4_* und 285 -> 300 (Adapter, Kern, hooks.h) nach diffs/5_*. Die 282-Originale liegen in claude/01_BASELINE/STAND_282/. Aufruf (Paketwurzel): make_diffs_283.py --out diffs"""
import argparse
import difflib
import sys
from pathlib import Path

CLAUDE = Path(__file__).resolve().parents[1]
BASE = CLAUDE / '01_BASELINE' / 'STAND_282'
BASE285 = CLAUDE / '01_BASELINE' / 'STAND_285'
TAG = 'C6'           # provisorische Versionsnummer der Gesamtintegration (die Nummer ist Sache des Nutzers)
MAP = [('sv04_claude_auto60_core.h', '02_SOURCE/Marlin/src/feature/sv04_claude_auto60/sv04_claude_auto60_core.h'),
       ('sv04_claude_auto60_marlin.inc', '02_SOURCE/Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc'),
       ('apply_claude_parallel.py', '03_PATCHES/apply_claude_parallel.py'),
       (None, '02_SOURCE/Marlin/src/feature/sv04_claude_auto60/sv04_claude_eeprom_core.h')]        # None = NEUE Datei


def plan():
    out = []
    for n, rel in MAP:
        name = '4_%s_%s_%s.patch' % (TAG, Path(rel).name.replace('.', '_'), '282_nach_' + TAG if n else 'NEU')
        out.append((name, BASE / n if n else None, CLAUDE / rel, 'claude/' + rel))
    for n, rel in ((MAP[1][0], MAP[1][1]), (MAP[0][0], MAP[0][1]), ('sv04_claude_hooks.h', '02_SOURCE/Marlin/src/lcd/e3v2/creality/sv04_claude_hooks.h')):      # 285 -> 290 (unveraenderter Stand 285 als Referenz)
        out.append(('5_%s_%s_285_nach_%s.patch' % (TAG, Path(rel).name.replace('.', '_'), TAG), BASE285 / n, CLAUDE / rel, 'claude/' + rel))
    return out


def udiff(a, b, rel):
    A = a.read_bytes().decode('utf-8').splitlines(True) if a else []
    B = b.read_bytes().decode('utf-8').splitlines(True)
    return ''.join(difflib.unified_diff(A, B, 'a/' + rel if a else '/dev/null', 'b/' + rel, n=3))


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', required=True)
    a = ap.parse_args(argv)
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    for name, base, tgt, rel in plan():
        d = udiff(base, tgt, rel)
        (out / name).write_text(d, encoding='utf-8')
        print(f'{name:<64} +{sum(1 for l in d.splitlines() if l.startswith("+") and not l.startswith("+++")):>4} -{sum(1 for l in d.splitlines() if l.startswith("-") and not l.startswith("---")):>4}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
