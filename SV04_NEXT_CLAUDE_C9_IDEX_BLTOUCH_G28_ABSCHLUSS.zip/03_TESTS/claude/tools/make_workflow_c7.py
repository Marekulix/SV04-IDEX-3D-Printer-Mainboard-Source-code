#!/usr/bin/env python3
"""Erzeugt claude_c7_stm32_no_flash.yml TEXTUELL aus dem gelieferten claude_c6_stm32_no_flash.yml (die Build-Jobs bleiben unveraendert getrennt):
 * der 318-Installer laeuft NUR noch ueber den gehaerteten Aufruf integrate_318_strict.py (alle acht Claude-Dateien gepinnt, unbekannte Claude-Dateien abgewiesen);
 * die Paketreferenz zeigt auf das C7-Paket (Hash fest eingetragen);
 * ein dritter Job wertet beide Build-Jobs mit evaluate_c7_builds.py aus und meldet NIE pauschal Erfolg (rot, solange nicht alle vier Kombinationen belegt PASS sind).
Aufruf: make_workflow_c7.py <claude_c6_stm32_no_flash.yml> <sha256_318_zip> <sha256_c7_zip> <out.yml>"""
import re
import sys
from pathlib import Path

src, sha318, shac7, out = Path(sys.argv[1]).read_text(encoding='utf-8'), sys.argv[2], sys.argv[3], sys.argv[4]
if not re.fullmatch(r'[0-9a-f]{64}', shac7) or sha318 not in src:
    print('FEHLER: Hash ungueltig oder der 318-Hash steht nicht im C6-Workflow', file=sys.stderr); sys.exit(2)
t = src


def rep(a, b, n=1):
    global t
    if t.count(a) != n:
        print(f'FEHLER: Anker {a[:70]!r} {t.count(a)} mal gefunden (erwartet {n})', file=sys.stderr); sys.exit(2)
    t = t.replace(a, b)


m = re.search(r"echo '([0-9a-f]{64})  SV04_NEXT_CLAUDE_C6_GESAMTINTEGRATION\.zip'", t)
if not m:
    print('FEHLER: C6-Paketpin nicht gefunden', file=sys.stderr); sys.exit(2)
rep(m.group(1), shac7, 2)                       # der Hash steht im Verify-Schritt BEIDER Build-Jobs
for a, b in (('SV04_NEXT_CLAUDE_C6_GESAMTINTEGRATION', 'SV04_NEXT_CLAUDE_C7_BUILD_KORREKTUR_NO_FLASH'), ('c6pkg', 'c7pkg'), ('c6_host_tests', 'c7_host_tests'), ('input_c6_sha', 'input_c7_sha'), ('zip_c6_integrity', 'zip_c7_integrity'), ('Verify C6 inputs (318 hand-over and Claude C6 package)', 'Verify C7 inputs (318 hand-over and Claude C7 package)'),
             ('Run Claude C6 host regression', 'Run Claude C7 host regression'), ('SV04_C6_CONTROL_309_ORIGINAL_STM32_LOGS_NO_FLASH', 'SV04_C7_CONTROL_309_ORIGINAL_STM32_LOGS_NO_FLASH'), ('SV04_C6_MODIFIED_318_STM32_LOGS_NO_FLASH', 'SV04_C7_MODIFIED_318_STM32_LOGS_NO_FLASH')):
    t = t.replace(a, b)
assert 'C6_GESAMT' not in t and 'c6pkg' not in t
rep('name: "C6 - SV04 NEXT 318 integration, control 309 vs modified 318, STM32 NO FLASH (number-free)"', 'name: "C7 - SV04 NEXT 318 integration with STRICT installer, control 309 vs modified 318, STM32 NO FLASH, evaluated (number-free)"')
rep('      - name: Apply 318 installer to a NEW copy (309 stays untouched, fail-closed)', '      - name: Apply 318 installer to a NEW copy through the STRICT wrapper (309 stays untouched, fail-closed)')
rep('          python3 c318/integrate_318.py oem oem318 2>&1 | tee evidence/integrate_318.txt\n          grep -F \'318 SOURCE OVERLAY APPLIED\' evidence/integrate_318.txt\n',
    '          python3 c7pkg/02_PATCHES/integrate_318_strict.py c318 oem oem318 2>&1 | tee evidence/integrate_318_strict.txt\n          grep -F \'STRICT_PRECHECK=OK\' evidence/integrate_318_strict.txt\n          grep -F \'318 SOURCE OVERLAY APPLIED\' evidence/integrate_318_strict.txt\n')
assert 'c318/integrate_318.py' not in t
t = t.rstrip('\n') + f'''

  evaluate_builds:
    name: "Evaluate both build jobs (no blanket success; red unless all four combinations are proven PASS)"
    runs-on: ubuntu-24.04
    needs: [control_309_original, modified_318_c6]
    if: always()
    steps:
      - name: Checkout input files
        uses: actions/checkout@v4
      - name: Verify and unpack the C7 package
        shell: bash
        run: |
          set -euo pipefail
          echo '{shac7}  SV04_NEXT_CLAUDE_C7_BUILD_KORREKTUR_NO_FLASH.zip' | sha256sum -c -
          unzip -q SV04_NEXT_CLAUDE_C7_BUILD_KORREKTUR_NO_FLASH.zip -d c7pkg
      - name: Download both build artifacts (whatever exists)
        uses: actions/download-artifact@v4
        with:
          pattern: SV04_C7_*_STM32_LOGS_NO_FLASH
          path: art
      - name: Evaluate (exit code 0 only if control_309 and modified_318 are PASS for both profiles)
        shell: bash
        run: |
          set -uo pipefail
          mkdir -p evaluation
          python3 c7pkg/02_PATCHES/evaluate_c7_builds.py art --out evaluation/EVALUATION.md 2>&1 | tee evaluation/evaluation_stdout.txt
          exit "${{PIPESTATUS[0]}}"
      - name: Upload evaluation
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: SV04_C7_EVALUATION
          path: evaluation/
          if-no-files-found: warn
'''
Path(out).write_text(t, encoding='utf-8', newline='\n'); print('geschrieben', out, len(t.splitlines()), 'Zeilen')
