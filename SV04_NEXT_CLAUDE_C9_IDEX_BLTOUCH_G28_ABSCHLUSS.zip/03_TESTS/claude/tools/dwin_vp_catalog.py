#!/usr/bin/env python3
"""A13: DWIN-VP-Katalog, MASCHINELL aus der echten LCD_RTS.h erzeugt (nichts von Hand). Listet alle *_VP-Adressen, Kollisionen (gleiche Adresse), die Belegung des Mesh-Bereichs 0x1100-0x111F
und die Empfangstabelle (PROC_COM/Addrbuf). Optional Abgleich mit der transkribierten HMI-Signaturdatei (die ECHTEN HMI-Binaerdateien liegen NICHT vor).
Aufruf: dwin_vp_catalog.py --header LCD_RTS.h [--signatures SIGS.json] [--out katalog.json] [--md katalog.md]"""
import argparse
import json
import re
import sys
from pathlib import Path

MESH_LO, MESH_HI = 0x1100, 0x111F


def parse(header_text):
    lines = header_text.split('\n')
    vps = []
    for i, l in enumerate(lines, 1):
        m = re.match(r'\s*#define\s+(\w*_VP)\s+\(?\s*(0[xX][0-9A-Fa-f]+)\s*\)?', l)
        if m:
            vps.append({'name': m.group(1), 'addr': int(m.group(2), 16), 'line': i})
    # Empfangstabelle
    e0 = header_text.index('enum PROC_COM')
    enum_body = header_text[header_text.index('{', e0) + 1:header_text.index('};', e0)]
    members = re.findall(r'^\s*([A-Za-z_]\w*)\s*(?:=\s*\w+)?\s*,?\s*(?://.*)?$', enum_body, re.M)
    b0 = header_text.index('const unsigned long Addrbuf[]')
    buf = header_text[b0:header_text.index('};', b0)]
    addrs = [int(v, 16) if v != '0' else 0 for v in re.findall(r'(0[xX][0-9A-Fa-f]+|\b0\b)\s*,?', buf)]
    return vps, members, addrs


def build(header_path, sig_path=None):
    t = Path(header_path).read_text(encoding='utf-8')
    vps, members, addrs = parse(t)
    by_addr = {}
    for v in vps:
        by_addr.setdefault(v['addr'], []).append(v['name'])
    dup = {hex(a): n for a, n in sorted(by_addr.items()) if len(n) > 1}
    mesh_defs = [v for v in vps if MESH_LO <= v['addr'] <= MESH_HI]
    cat = {'header': str(header_path), 'vp_defines': len(vps), 'duplicate_addresses': dup, 'defines_inside_mesh_range': mesh_defs,
           'mesh_cells': [{'point_k': k, 'vp': hex(MESH_LO + 2 * k), 'cell_xy': list(_cell(k))} for k in range(16)],
           'receive_table': {'enum_members': len(members), 'addrbuf_entries_excl_terminator': len(addrs) - 1,
                             'entries_inside_mesh_range': [{'index': i, 'name': members[i] if i < len(members) else None, 'addr': hex(a)} for i, a in enumerate(addrs) if MESH_LO <= a <= MESH_HI]}}
    if sig_path:
        S = json.loads(Path(sig_path).read_text())
        cat['hmi_signature_file'] = {'source': 'transkribiert, NICHT aus der echten HMI-Datei', 'records': [{'vp': r['vp'], 'x': r['x'], 'y': r['y']} for r in S['records']]}
    return cat


def _cell(k):
    iy, pos = divmod(k, 4)
    return ((pos if iy & 1 else 3 - pos), iy)


def md(cat):
    o = ['# A13 DWIN-VP-Katalog (maschinell aus LCD_RTS.h)', '', f"*_VP-Definitionen: {cat['vp_defines']}", '', '## Mesh-Zellen (Anzeige, OEM-Reihenfolge = Messreihenfolge)', '', '| Punkt k | VP | Zelle (x,y) |', '|---|---|---|']
    o += [f"| {c['point_k']} | {c['vp']} | {tuple(c['cell_xy'])} |" for c in cat['mesh_cells']]
    o += ['', '## Gleiche Adresse unter mehreren Namen (Kollisionen in LCD_RTS.h)', '']
    o += [f'- {a}: {", ".join(n)}' for a, n in cat['duplicate_addresses'].items()] or ['- keine']
    o += ['', '## Definitionen im Mesh-Bereich 0x1100-0x111F', ''] + [f"- {d['name']} = 0x{d['addr']:04X} (Zeile {d['line']})" for d in cat['defines_inside_mesh_range']]
    o += ['', '## Empfangstabelle (Touch/Rueckmeldung) im Mesh-Bereich', ''] + [f"- Index {e['index']} {e['name']} = {e['addr']}" for e in cat['receive_table']['entries_inside_mesh_range']]
    return '\n'.join(o) + '\n'


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--header', required=True)
    ap.add_argument('--signatures')
    ap.add_argument('--out')
    ap.add_argument('--md')
    a = ap.parse_args(argv)
    cat = build(a.header, a.signatures)
    if a.out:
        Path(a.out).write_text(json.dumps(cat, indent=1))
    if a.md:
        Path(a.md).write_text(md(cat), encoding='utf-8')
    print(json.dumps({k: cat[k] for k in ('vp_defines', 'duplicate_addresses', 'defines_inside_mesh_range')}, indent=1))
    return 0


if __name__ == '__main__':
    sys.exit(main())
