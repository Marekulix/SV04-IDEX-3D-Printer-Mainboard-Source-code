#!/usr/bin/env python3
"""Prueft MANIFEST_SHA256.txt (Format '<sha256>  <relativer/pfad>') ohne externe Programme. Meldet abweichende, fehlende und zusaetzliche Dateien sowie Nicht-ASCII-Namen.
Aufruf: python3 tools/verify_manifest.py [ORDNER]   (Exit 0 nur bei voller Uebereinstimmung). Hinweis: Die Tests schreiben nach 06_EVIDENCE/host/, 07_AUDIT/A01*/A13* und 04_TESTS/LAST_*; Manifest daher VOR dem Testlauf pruefen."""
import hashlib
import sys
from pathlib import Path

NAME = 'MANIFEST_SHA256.txt'


def collect(base):
    base = Path(base)
    return sorted(p for p in base.rglob('*') if p.is_file() and p.name != NAME and '__pycache__' not in p.parts and p.suffix != '.pyc')


def build(base):
    base = Path(base)
    files = collect(base)
    bad = [p.relative_to(base).as_posix() for p in files if not p.relative_to(base).as_posix().isascii()]
    if bad:
        raise SystemExit('Nicht-ASCII-Dateinamen: ' + ', '.join(bad))
    (base / NAME).write_bytes(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(base).as_posix()}\n' for p in files).encode('ascii'))
    return len(files)


def verify(base):
    base = Path(base)
    m = base / NAME
    if not m.is_file():
        return {'ok': False, 'fehler': [NAME + ' fehlt']}
    ent = {}
    for n, l in enumerate(m.read_text(encoding='ascii').splitlines(), 1):
        h, sep, rel = l.partition('  ')
        if len(h) != 64 or not sep or not rel:
            return {'ok': False, 'fehler': [f'Zeile {n} ungueltig']}
        ent[rel] = h
    files = {p.relative_to(base).as_posix(): p for p in collect(base)}
    abw = sorted(k for k in ent if k in files and hashlib.sha256(files[k].read_bytes()).hexdigest() != ent[k])
    fehlt = sorted(k for k in ent if k not in files)
    neu = sorted(k for k in files if k not in ent)
    return {'ok': not (abw or fehlt or neu), 'geprueft': len(ent), 'abweichend': abw, 'fehlend': fehlt, 'nicht_im_manifest': neu, 'fehler': []}


def main(argv=None):
    r = verify((argv or sys.argv[1:] or ['.'])[0])
    print(('ALLES STIMMT: ' if r['ok'] else 'ABWEICHUNG: ') + ', '.join(f'{k}={v}' for k, v in r.items() if k != 'ok' and v))
    return 0 if r['ok'] else 1


if __name__ == '__main__':
    sys.exit(main())
