#!/usr/bin/env python3
"""Statusmatrix der GESAMTINTEGRATION (283 EEPROM + M420 V2-V6): je Arbeitsschritt des Uebergabe-Auftrags, je Kernfunktion (P1-P6) und je Pruefthema eine Zeile. Spalte HERKUNFT trennt SELBST AUSGEFUEHRT (dieser Lauf, Rohlog in
06_EVIDENCE/host) von UEBERNOMMEN (Ihre GitHub-Logs). Jeder Test wird gegen die Rohlogs geprueft; steht er dort nicht als bestanden, bricht das Skript mit Exitcode 1 ab.
Aufruf (Paketwurzel): python3 claude/tools/make_status_gesamtintegration.py [--out DOCS]"""
import argparse
import csv
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import make_status_283 as S  # noqa: E402

H = S.H
SELF, TAKEN = 'SELBST AUSGEFUEHRT (dieser Lauf)', 'UEBERNOMMEN (Ihr GitHub-Lauf 282, nicht erneut gebaut)'


def P(*a): return S.P(*a)
def C(*a): return S.C(*a)
def EE(*a): return S.EE(*a)


def LOG(f, s): return [f'LOG:{f}|{s}']


ROWS = [
 ('G1', 'Integritaet und Versionsstaende der Uebergabe unabhaengig verifizieren (283 Hauptzweig, 279 Buildreferenz, OEM-Commit 1867fcba…)', SELF, 'JA', 'JA', '-',
  LOG('13_uebergabe_integritaet.txt', 'ALLES STIMMT: geprueft=211') + LOG('13_uebergabe_integritaet.txt', '01_CLAUDE_283/SV04_NEXT_283.zip: OK') + LOG('13_uebergabe_integritaet.txt', 'GLEICH   SV04_NEXT_283.zip'), [],
  'Alle 10 Dateien der Uebergabe gegen deren Manifest, die 283-Dateien gegen meine Auslieferung, das Paket gegen sein eigenes Manifest. 279: BUILD_EXIT=0 (P1 + M420 V2-V5, ohne Auto60/V6) - UEBERNOMMEN aus dem mitgelieferten Log. 280: nie bis zum Build gekommen (kein BUILD_EXIT).'),
 ('G2', 'M420-V6-Installationsfehler aus Run 280 reproduzieren und beheben; M420-Funktionen erhalten', 'GEMISCHT: Reproduktion SELBST, Anwendung am echten OEM-Baum UEBERNOMMEN', 'JA', 'JA', 'V6 am ECHTEN OEM-M420.cpp: nur Ihr 282-Lauf (kein vollstaendiger OEM-M420.cpp lokal)',
  LOG('14_v6_run280_reproduktion.txt', 'CONFLICT midrange: expected one anchor, found 0') + LOG('14_v6_run280_reproduktion.txt', 'V6-Skript 282/283: OLD-Anker im OEM-Fragment: True') + LOG('11_m420_tests.txt', 'PASS 14 executed V6 centering/rollback scenarios') + LOG('11_m420_tests.txt', 'PASS 8 extrema scenarios outside legacy range') + LOG('11_m420_tests.txt', 'PASS: OEM whitespace, V6 install and idempotency'), [],
  'URSACHE (reproduziert): das V6-Skript aus 280 sucht den Anker mit 10 statt 12 Leerzeichen Einrueckung -> "CONFLICT midrange: expected one anchor, found 0". Behoben in 282 (OEM-genauer Anker), Skript im 283-Paket identisch; Ihr 282-Lauf: APPLIED V6 am echten Baum, BUILD_EXIT=0 in beiden Profilen. Es war nichts mehr zu beheben.'),
 ('G3', 'Bedleveling-Integration von 283 und M420 konfliktfrei zusammenfuehren; set_bed_leveling_enabled x G28/G29 x Auto60 x M500 x EEPROM-Rohlesung per Quellcode und ausfuehrbaren Tests', SELF, 'JA', 'JA', 'M420.cpp (V4-/V5-/V6-Haelfte) nicht lokal ausfuehrbar; STM32-Link',
  [], P('BL01_', 'BL02_', 'BL03_', 'BL04_', 'BL05_', 'BL06_', 'BL08_', 'BL09_', 'BL10_'), 'BEFUND: mit den ECHTEN V2+V4-Funktionen endete der Drucker in zwei realistischen Faellen im Notstopp (leeres EEPROM + Fehler/Abbruch nach der G29: altes Mesh NaN wurde bei aktiver Nivellierung hergestellt; V4: aktiv + ungueltig = kill). BEHOBEN in sv04_claude_auto60_marlin.inc (sv04c_mesh_rollback_safe), seit 282 latent.'),
 ('G4', 'G29 + Auto60 liefern bei Messfehler/Abbruch keine Erfolgsrueckmeldung und kein M500; G28 XY als Endskript beruecksichtigen', SELF, 'JA', 'JA', 'Verhalten am Geraet',
  [], P('E17_', 'I10_', 'I11_', 'I25_', 'BL02_', 'BL03_', 'BL06_'), 'Auch mit den echten V2/V4-Funktionen: settings_save=0, 0 geaenderte EEPROM-Bytes, keine Erfolgsseite.'),
 ('G5', 'EEPROM-Rohlesen veraendert RAM-Mesh, Z-Offset, aktives Leveling und Fahrzustand nicht; Journaloption, Platzbedarf, fehlende Hardwareevidenz dokumentieren', SELF, 'JA', 'JA', 'Journal-Platz (datasize) und echter I2C-Chip nur am Geraet',
  [], P('BL05_', 'E18_', 'E12_', 'E20_', 'E21_') + C('J09') + EE('EE20'), 'M1060 S2/S3: lev=1 pos=1 mesh=1 zoff=1 offset=1 no_motion=1 (auch bei leerem und beschaedigtem EEPROM). Journaloption SV04_CLAUDE_EEPROM_REQUIRE_JOURNAL (Standard 0), Bedarf datasize <= 962: docs/EEPROM_ANALYSE_283.md.'),
 ('G6', 'Alle vier IDEX-Modi, T0/T1-Homing, BLTouch-Alarm, DWIN (16 Anzeigeobjekte, Abbruch) im gemeinsamen Source-Branch regressieren', SELF, 'JA', 'JA', 'Mechanik/Display am Geraet',
  [], P('I09_', 'F07_', 'F11_', 'F03_', 'F04_', 'G03_', 'F01_', 'F02_', 'I05_', 'I06_', 'V01_', 'V06_', 'V07_', 'V08_', 'V09_', 'I20_', 'I22_'), 'Mit der Attrappe UND (BL-Tests) mit den echten V2/V4-Funktionen; DWIN: 13 Tests (V01-V13), 16 Meshzellen einzeln und Abbruch.'),
 ('G7', 'Vollstaendiger STM32-Build der gemeinsamen Version (beide Profile), Compiler-/Linkerfehler beheben', 'NICHT AUSGEFUEHRT', 'JA', 'NEIN', 'KEIN Build moeglich: keine ARM-Toolchain, kein PlatformIO, kein Netz (in dieser Umgebung geprueft)',
  [], P('B20_', 'B21_', 'B22_'), 'Workflow vorbereitet. 282 (P1 + M420 V6 + Auto60-277): UEBERNOMMEN BUILD_EXIT=0 in beiden Profilen; 283/284 (EEPROM, Rollback-Fix): NIE gebaut.'),
 ('G8', 'Reproduzierbarer GitHub-Workflow: <N>.yml + SV04_NEXT_<N>.zip, kein Flash, keine Nummer blind vergeben', SELF, 'JA', 'JA', 'Nummer: ob 284 frei ist, weiss nur der Nutzer',
  [], P('B20_', 'B21_', 'B22_', 'D03_', 'D04_'), 'Provisorisch 284 (in den Unterlagen kommen 268-283 vor); Nummer ist Parameter: make_workflow_283.py --version N.'),
 ('K1', 'Kernfunktion P1 IDEX + BLTouch', SELF, 'JA', 'JA', 'Geraet', [], P('F01_', 'F03_', 'F07_', 'I05_', 'I09_'), 'Entwicklungsstand, keine Hardwarefreigabe.'),
 ('K2', 'Kernfunktion P2 G28 Homing', SELF, 'JA', 'JA', 'Geraet', [], P('G01_', 'G03_', 'F04_', 'F08_', 'F11_', 'I01_'), '15 G28-Tests mit der echten G28.cpp.'),
 ('K3', 'Kernfunktion P3 G29 + Abbruch', SELF, 'JA', 'JA', 'Geraet', [], P('I10_', 'I19_', 'I20_', 'I22_', 'BL02_', 'BL08_'), '-'),
 ('K4', 'Kernfunktion P4 M420 (V2/V4/V5/V6)', 'GEMISCHT: V4-V6-Tests von ChatGPT SELBST ausgefuehrt; bedlevel-Teil SELBST getestet', 'JA', 'TEILWEISE', 'M420.cpp V4-V6 am echten Baum nur ueber Ihren 282-Lauf; Geraet',
  LOG('11_m420_tests.txt', 'PASS 16 actual extracted guard scenarios') + LOG('11_m420_tests.txt', 'PASS 18 executed M420 Z-fade guard scenarios') + LOG('11_m420_tests.txt', 'PASS 14 executed V6 centering/rollback scenarios') + LOG('12_integration_281.txt', 'OK'), P('BL01_', 'BL07_', 'BL10_'), '-'),
 ('K5', 'Kernfunktion P5 M500 EEPROM', SELF, 'JA', 'JA', 'Geraet', [], P('E01_', 'E04_', 'E17_', 'E18_'), '-'),
 ('K6', 'Kernfunktion P6 EEPROM-Ruecklesung', SELF, 'JA', 'JA', 'Geraet', [], P('E18_', 'E22_', 'E23_') + EE('EE10', 'EE20'), '-'),
]


def check(tests, cpp, ee, py):
    res = []
    for t in tests:
        kind, name = t.split(':', 1)
        if kind == 'LOG':
            f, sub = name.split('|', 1)
            ok = (H / f).exists() and sub in (H / f).read_text(errors='replace')
        elif kind == 'C++':
            ok = cpp.get(name) == 'PASS'
        elif kind == 'EE':
            ok = ee.get(name) == 'PASS'
        else:
            hits = [k for k in py if k.startswith('test_' + name)]
            ok = bool(hits) and all(py[k] == 'ok' for k in hits)
        res.append((t, ok))
    return res


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default=str(S.PKG / 'docs'))
    a = ap.parse_args(argv)
    cpp, ee, py = S.logs()
    out, bad = [], []
    for rid, req, herkunft, impl, tested, blocked, logs, tests, note in ROWS:
        res = check(logs + tests, cpp, ee, py)
        fail = [t for t, ok in res if not ok]
        if fail:
            bad.append((rid, fail))
        out.append([rid, req, herkunft, impl, 'FEHLER (Nachweis nicht im Log)' if fail else tested, 'NEIN', 'NEIN', blocked, ' | '.join(logs + tests) or '-', note])
    outdir = Path(a.out); outdir.mkdir(parents=True, exist_ok=True)
    with open(outdir / 'STATUS_GESAMTINTEGRATION.csv', 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['nr', 'anforderung', 'HERKUNFT_DES_NACHWEISES', 'IMPLEMENTIERT', 'LOKAL_GETESTET', 'STM32_GEBAUT', 'HARDWARE_GEPRUEFT', 'BLOCKIERT_oder_offen', 'nachweise', 'einschraenkung'])
        w.writerows(out)
    print(len(out), 'Zeilen; STM32_GEBAUT=NEIN, HARDWARE_GEPRUEFT=NEIN in allen')
    if bad:
        print('Nachweise nicht im Log bestanden:', bad, file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
