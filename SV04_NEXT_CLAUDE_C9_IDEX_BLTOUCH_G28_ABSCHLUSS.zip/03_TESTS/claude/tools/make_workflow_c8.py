#!/usr/bin/env python3
"""Erzeugt aus dem gelieferten claude_c7_stm32_no_flash.yml zwei Workflow-Routen (TEXTUELL; die Build-Schritte bleiben unveraendert):
 Route A  Originalweg ueber SV04_NEXT_287.zip (unveraendert) + Preflight-Job, der JEDE fehlende/falsche Eingabe einzeln benennt, bevor gebaut wird. Nichts wird umbenannt, keine Pruefsumme umgangen.
 Route B  Die 309 entsteht NICHT aus SV04_NEXT_287.zip/integrate_286.py, sondern aus dem aufgezeichneten combined_308.patch (git apply auf dem festgelegten OEM-Commit) und wird gegen die gepinnten 309-Dateihashes geprueft.
          ACHTUNG: ein ANDERER Reproduktionsweg als der, der die 309 urspruenglich gebaut hat; alle Ergebnisse tragen das Etikett ROUTE_B.
Aufruf: make_workflow_c8.py <c7.yml> <sha256_318_zip> <sha256_c8_zip> <a|b> <out.yml> [<sha256_combined_308.patch>]   (Route b braucht den Patch-Hash)"""
import re
import sys
from pathlib import Path

OEM_PINS = {   # SHA-256 der 309-Dateien (3 OEM-Dateien nach ChatGPTs base_309_hashes.json, 8 sv04_claude_*-Dateien aus dem vollstaendigen 309-Baum / source_hashes_after_308)
    'Marlin/src/module/tool_change.cpp': '4f1698bc3b16052d9855b0504ef7728c41bc127a0da551fc77efcb6c8f58c93d',
    'Marlin/src/module/motion.cpp': '54ff1c0c034f76b1c795e747cbc0fad525c259c6ce6ffd0e8c7fd4c90062ec96',
    'Marlin/src/gcode/bedlevel/abl/G29.cpp': 'c1b44b74784eaaa45da8c13d1765a2094a3823c45912fc7200e3873924c1de24',
    'Marlin/src/feature/sv04_claude_auto60/sv04_claude_auto60_core.h': 'faf2d034a067ccecea5e0d413028e9598935fe577486748a6a5493bc16c6a097',
    'Marlin/src/feature/sv04_claude_auto60/sv04_claude_eeprom_core.h': '379848c3a0e3cd2f2a67e4f560b0a02592b6d95bd414818d8d4fc8ad0f04a2a3',
    'Marlin/src/feature/sv04_claude_auto60/sv04_claude_g29_session.h': 'd616c3e94826ffaac50e5e43fa842a53f17a091ff24537433edc8ce1c8afa250',
    'Marlin/src/feature/sv04_claude_auto60/sv04_claude_toolchange_policy.h': 'a6ea813001b6a81547c17834811aba68bc6022a526e19145643be2bfe445b16d',
    'Marlin/src/gcode/control/sv04_claude_toolchange_guard.h': 'b417b83080615d869ffd3b5115a057b10d4ce50187cfc12de3e8649888cad06d',
    'Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc': '03543e739c3fe75d668f57202441597a3a5050b62ffaa25c2f8ca45573db4f1f',
    'Marlin/src/lcd/e3v2/creality/sv04_claude_hooks.h': '7ca925326ca62b286c529c2ef2f722cb0899b6319c1f47aece5fb2f9d0b484aa',
    'Marlin/src/lcd/e3v2/creality/sv04_claude_oem_mesh_loop.inc': 'f7cf74f644d473927e13478d2f851d24c9b77f29c7c7f9b628f48809186a3b0b',
}
if len(sys.argv) < 6:
    print(__doc__); sys.exit(2)
src, sha318, shac8, route, out = Path(sys.argv[1]).read_text(encoding='utf-8'), sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5]
patch_sha = sys.argv[6] if len(sys.argv) > 6 else ''
if route not in ('a', 'b') or not re.fullmatch(r'[0-9a-f]{64}', shac8) or sha318 not in src or (route == 'b' and not re.fullmatch(r'[0-9a-f]{64}', patch_sha)):
    print('FEHLER: Argumente ungueltig (Route a|b, 64-stellige Hashes, 318-Hash muss im C7-Workflow stehen, Route b braucht den Patch-Hash)', file=sys.stderr); sys.exit(2)
t = src


def rep(a, b, n=1):
    global t
    if t.count(a) != n:
        print(f'FEHLER: Anker {a[:70]!r} {t.count(a)} mal gefunden (erwartet {n})', file=sys.stderr); sys.exit(2)
    t = t.replace(a, b)


m = re.search(r"echo '([0-9a-f]{64})  SV04_NEXT_CLAUDE_C7_BUILD_KORREKTUR_NO_FLASH\.zip'", t)
if not m:
    print('FEHLER: C7-Paketpin nicht gefunden', file=sys.stderr); sys.exit(2)
rep(m.group(1), shac8, 3)
pref = 'SV04_C8A_' if route == 'a' else 'SV04_C8B_'
for a, b in (('SV04_NEXT_CLAUDE_C7_BUILD_KORREKTUR_NO_FLASH', 'SV04_NEXT_CLAUDE_C8_BUILD_EVIDENZ_NO_FLASH'), ('c7pkg', 'c8pkg'), ('c7_host_tests', 'c8_host_tests'), ('input_c7_sha', 'input_c8_sha'), ('zip_c7_integrity', 'zip_c8_integrity'), ('Verify C7 inputs', 'Verify C8 inputs'),
             ('Claude C7 package', 'Claude C8 package'), ('Run Claude C7 host regression', 'Run Claude C8 host regression'), ('SV04_C7_', pref), ('Verify and unpack the C7 package', 'Verify and unpack the C8 package')):
    t = t.replace(a, b)
if 'C7_BUILD' in t or 'c7pkg' in t or 'SV04_C7_' in t:
    print('FEHLER: Reste von C7 im Workflow', file=sys.stderr); sys.exit(2)
rep('name: "C7 - SV04 NEXT 318 integration with STRICT installer, control 309 vs modified 318, STM32 NO FLASH, evaluated (number-free)"',
    'name: "C8 route A - ORIGINAL 287 route with preflight, STRICT installer, control 309 vs modified 318, STM32 NO FLASH, evaluated (number-free)"' if route == 'a'
    else 'name: "C8 route B - 309 reproduced from combined_308.patch (NO 287, different route than the original 309 build), STRICT installer, control 309 vs modified 318, STM32 NO FLASH, evaluated (number-free)"')
pre_jobs, jobs_text = t.split('\njobs:\n', 1)
head = pre_jobs + '\njobs:\n'
jobs = re.split(r'(?m)^(?=  [a-z_0-9]+:\n)', jobs_text)[1:]
J = {re.match(r'  ([a-z_0-9]+):', j).group(1): j for j in jobs}
if list(J) != ['control_309_original', 'modified_318_c6', 'evaluate_builds']:
    print('FEHLER: unerwartete Jobs', list(J), file=sys.stderr); sys.exit(2)


def steps_of(job):
    h, *s = re.split(r'(?m)^(?=      - name: )', job); return h, s


def sname(s): return re.match(r'      - name: (.*)', s).group(1)


if route == 'a':
    cand = [s for s in steps_of(J['control_309_original'])[1] if sname(s) == 'Verify packages and unpack']
    if len(cand) != 1:
        print('FEHLER: der Schritt "Verify packages and unpack" fehlt oder ist mehrfach vorhanden (Quell-Workflow veraendert?)', file=sys.stderr); sys.exit(2)
    vb = cand[0]
    pins = re.findall(r"echo '([0-9a-f]{64})  ([^'\n]+?\.zip)'\s*\|\s*sha256sum -c", vb)
    if len(pins) != 6 or not any(n == 'SV04_NEXT_287.zip' for _, n in pins):
        print('FEHLER: unerwartete Eingabe-Pins im Quell-Workflow:', pins, file=sys.stderr); sys.exit(2)
    checks = ''.join(f"            check '{h}' '{n}'\n" for h, n in pins) + f"            check '{shac8}' 'SV04_NEXT_CLAUDE_C8_BUILD_EVIDENZ_NO_FLASH.zip'\n            check '{sha318}' 'SV04_NEXT_318_GESAMTINTEGRATION_UND_C6_UEBERGABE_NO_FLASH.zip'\n"
    pre = ('  preflight_inputs:\n    name: "Preflight - every required input present with the exact pinned SHA-256 (nothing is renamed, no hash is bypassed)"\n    runs-on: ubuntu-24.04\n    steps:\n      - name: Checkout input files\n        uses: actions/checkout@v4\n'
           '      - name: Check all pinned inputs and name every missing one\n        shell: bash\n        run: |\n          set -uo pipefail\n          mkdir -p evidence\n          check() {\n            if [ ! -f "$2" ]; then echo "MISSING   $2   (expected SHA-256 $1)"; return; fi\n            got=$(sha256sum "$2" | cut -d" " -f1)\n'
           '            if [ "$got" != "$1" ]; then echo "BAD_HASH  $2   (found $got, expected $1)"; return; fi\n            if ! unzip -tq "$2" >/dev/null 2>&1; then echo "BAD_ZIP   $2"; return; fi\n            echo "OK        $2   $1"\n          }\n          {\n' + checks + '          } | tee evidence/preflight_inputs.txt\n'
           '          bad=$(grep -cE "^(MISSING|BAD_HASH|BAD_ZIP)" evidence/preflight_inputs.txt || true)\n          if [ "$bad" -ne 0 ]; then\n            echo "BLOCKED: $bad required input(s) missing or wrong. Add the EXACT original file(s) with the exact name to the repository root. Do NOT rename another file and do NOT edit a pinned hash." | tee -a evidence/preflight_inputs.txt\n            exit 1\n          fi\n          echo PREFLIGHT_OK | tee -a evidence/preflight_inputs.txt\n'
           f'      - name: Upload preflight evidence\n        if: always()\n        uses: actions/upload-artifact@v4\n        with:\n          name: {pref}PREFLIGHT_INPUTS_NO_FLASH\n          path: evidence/\n          if-no-files-found: warn\n\n')
    for k in ('control_309_original', 'modified_318_c6'):
        assert J[k].count('    runs-on: ubuntu-24.04\n') == 1
        J[k] = J[k].replace('    runs-on: ubuntu-24.04\n', '    runs-on: ubuntu-24.04\n    needs: preflight_inputs\n')
    assert J['evaluate_builds'].count('needs: [control_309_original, modified_318_c6]') == 1
    J['evaluate_builds'] = J['evaluate_builds'].replace('needs: [control_309_original, modified_318_c6]', 'needs: [preflight_inputs, control_309_original, modified_318_c6]')
    text = head + pre + J['control_309_original'] + J['modified_318_c6'] + J['evaluate_builds']
else:
    pinlines = ''.join(f'          {h}  oem/{p}\n' for p, h in OEM_PINS.items())
    repro = ('      - name: Reproduce 309 from the recorded combined_308.patch (ROUTE B - without the 287 package; a DIFFERENT route than the original 309 build)\n        shell: bash\n        run: |\n          set -euo pipefail\n          mkdir -p evidence\n'
             f"          echo '{patch_sha}  c318/combined_308.patch' | sha256sum -c - | tee evidence/combined_308_sha.txt\n"
             '          test -z "$(git -C oem status --porcelain)"\n          git -C oem apply --check --whitespace=nowarn ../c318/combined_308.patch\n          git -C oem apply --whitespace=nowarn ../c318/combined_308.patch\n          git -C oem status --porcelain | tee evidence/route_b_status.txt\n'
             '          test "$(git -C oem status --porcelain | wc -l)" -eq 15\n          sha256sum -c - <<\'ROUTE_B_PINS\' | tee evidence/route_b_309_pins.txt\n' + pinlines + '          ROUTE_B_PINS\n')
    for k, lab_old, lab_new in (('control_309_original', 'ORIGINAL_309_UNMODIFIED_CONTROL', 'ROUTE_B_309_REPRODUCED_FROM_PATCH_UNMODIFIED_CONTROL'), ('modified_318_c6', 'MODIFIED_318_NEW_COPY_OF_309', 'ROUTE_B_MODIFIED_318_NEW_COPY_OF_PATCH_REPRODUCED_309')):
        h, ss = steps_of(J[k]); new = []
        for s in ss:
            n = sname(s)
            if n == 'Verify packages and unpack': continue
            if n.startswith('Integrate planner, guarded 282-to-287'): new.append(repro); continue
            if n.startswith('Build STM32 profiles'):
                if s.count(lab_old) != 1:
                    print('FEHLER: SOURCE_BASE-Etikett nicht gefunden', file=sys.stderr); sys.exit(2)
                s = s.replace(lab_old, lab_new)
            new.append(s)
        J[k] = h + ''.join(new)
    text = head + J['control_309_original'] + J['modified_318_c6'] + J['evaluate_builds']
    for bad in ('SV04_NEXT_287', 'point1', 'integrate_286', 'planner289', 'planner290', 'work309', 'integrate_308'):
        if bad in text:
            for i, l in enumerate(text.splitlines(), 1):
                if bad in l: print(f'FEHLER: Route B enthaelt noch {bad!r} in Zeile {i}: {l.strip()[:150]}', file=sys.stderr)
            sys.exit(2)
Path(out).write_text(text, encoding='utf-8', newline='\n'); print('geschrieben', out, len(text.splitlines()), 'Zeilen, Route', route.upper())
