#!/usr/bin/env python3
"""Beweist, dass der in der Host-Simulation getestete Code TEXTGLEICH zu dem Code im integrierten OEM-Baum ist: die drei Funktionen leveling_is_valid / set_bed_leveling_enabled / reset_bed_level des
ECHTEN, nach M420 V2 und V4 gepatchten bedlevel.cpp (--integrated) werden woertlich mit der Extraktion verglichen, die die Simulation benutzt (aus der mitgelieferten OEM-Kopie + ChatGPTs Patchskripten).
Ausgabe: BEDLEVEL_HOST_EQUALS_BUILD=YES|NO. Aufruf (Paketwurzel): compare_bedlevel_real.py --integrated oem/Marlin/src/feature/bedlevel/bedlevel.cpp"""
import argparse
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
PKG = HERE.parents[1]
sys.path.insert(0, str(PKG / 'claude' / '04_TESTS' / 'sim'))
import extract_bedlevel_a60 as X  # noqa: E402


def compare(integrated_text, shipped_text):
    rows = []
    for f in X.FUNCS:
        a, b = X.extract(integrated_text, f), X.extract(shipped_text, f)
        rows.append((f, a == b))
    return rows


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--integrated', type=Path, required=True)
    ap.add_argument('--shipped-oem', type=Path, default=PKG / 'claude' / '01_BASELINE' / 'OEM_FILES' / 'Marlin' / 'src' / 'feature' / 'bedlevel' / 'bedlevel.cpp')
    ap.add_argument('--m420-dir', type=Path, default=PKG / 'm420')
    a = ap.parse_args(argv)
    host = X.patched_text(a.shipped_oem, a.m420_dir, 'v2v4')
    rows = compare(a.integrated.read_text(encoding='utf-8'), host)
    for f, ok in rows:
        print(('GLEICH     ' if ok else 'ABWEICHEND ') + f)
    ok = all(r[1] for r in rows)
    print('BEDLEVEL_HOST_EQUALS_BUILD=' + ('YES' if ok else 'NO'))
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
