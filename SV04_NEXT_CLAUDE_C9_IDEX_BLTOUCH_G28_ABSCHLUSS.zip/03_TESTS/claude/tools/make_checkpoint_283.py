#!/usr/bin/env python3
"""Erzeugt einen SELBSTAENDIG FORTSETZBAREN Checkpoint SV04_NEXT_283_CHECKPOINT_<pct>.zip.
Inhalt: SOURCE/ (kompletter Arbeitsbaum, = Stand 282 + alle Aenderungen), PATCHES/ (Unterschied zu 282), TESTS/ (neue/geaenderte Tests), BUILD_LOGS/, REPORTS/, STATE.json, WEITERARBEITEN.md, SHA256SUMS.txt.
Aufruf: make_checkpoint_283.py --pct 10 --tree <Arbeitsbaum> --base <unveraenderter Stand 282> --state STATE.json --weiter WEITERARBEITEN.md --reports DIR --logs DIR --out DIR"""
import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

SKIP = ('__pycache__',)


def files(base):
    return sorted(p for p in Path(base).rglob('*') if p.is_file() and not any(s in p.parts for s in SKIP) and p.suffix != '.pyc')


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--pct', required=True, type=int)
    ap.add_argument('--tree', required=True, type=Path)
    ap.add_argument('--base', required=True, type=Path)
    ap.add_argument('--state', required=True, type=Path)
    ap.add_argument('--weiter', required=True, type=Path)
    ap.add_argument('--reports', type=Path)
    ap.add_argument('--logs', type=Path)
    ap.add_argument('--out', required=True, type=Path)
    a = ap.parse_args(argv)
    root = Path(tempfile.mkdtemp(prefix='cp283_')) / 'SV04_NEXT_283_CHECKPOINT'
    for d in ('SOURCE', 'PATCHES', 'TESTS', 'BUILD_LOGS', 'REPORTS'):
        (root / d).mkdir(parents=True)
    for f in files(a.tree):
        t = root / 'SOURCE' / f.relative_to(a.tree)
        t.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(f, t)
    # Unterschied zu 282 (unveraendert): nur Text; Quelle der Wahrheit fuer "geaenderte Dateien"
    changed, new = [], []
    bf = {p.relative_to(a.base).as_posix(): p for p in files(a.base)}
    tf = {p.relative_to(a.tree).as_posix(): p for p in files(a.tree)}
    for rel, p in tf.items():
        if rel not in bf:
            new.append(rel)
        elif p.read_bytes() != bf[rel].read_bytes():
            changed.append(rel)
    removed = sorted(r for r in bf if r not in tf)
    r = subprocess.run(['diff', '-ruN', '-x', '__pycache__', '-x', '*.pyc', str(a.base), str(a.tree)], capture_output=True, text=True)
    (root / 'PATCHES' / '282_nach_283.patch').write_text(r.stdout.replace(str(a.base), 'a/282').replace(str(a.tree), 'b/283'), encoding='utf-8')
    (root / 'PATCHES' / 'GEAENDERTE_DATEIEN.txt').write_text('GEAENDERT gegenueber 282:\n' + '\n'.join(changed) + '\n\nNEU gegenueber 282:\n' + '\n'.join(new) + '\n\nENTFERNT gegenueber 282:\n' + '\n'.join(removed) + '\n', encoding='utf-8')
    for rel in changed + new:
        if '04_TESTS' in rel or rel.startswith('test_') or '/test_' in rel:
            t = root / 'TESTS' / rel
            t.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(tf[rel], t)
    for src, dst in ((a.reports, 'REPORTS'), (a.logs, 'BUILD_LOGS')):
        if src and Path(src).exists():
            for f in files(src):
                t = root / dst / f.relative_to(src)
                t.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(f, t)
    state = json.loads(a.state.read_text(encoding='utf-8'))
    state['checkpoint_prozent'] = a.pct
    state['geaenderte_dateien'] = changed
    state['neue_dateien'] = new
    state['entfernte_dateien'] = removed
    state['sha256_basis_282_zip'] = state.get('sha256_basis_282_zip', 'cde72f1e3037350d37db4be84540928cf8b32ec12a94fdab853515eeb2b4a535 (SV04_NEXT_CLAUDE_START_283_MIT_STAND_282.zip)')
    (root / 'STATE.json').write_text(json.dumps(state, indent=1, ensure_ascii=False) + '\n', encoding='utf-8')
    shutil.copyfile(a.weiter, root / 'WEITERARBEITEN.md')
    lines = [f'{hashlib.sha256(f.read_bytes()).hexdigest()}  {f.relative_to(root).as_posix()}' for f in files(root) if f.name != 'SHA256SUMS.txt']
    (root / 'SHA256SUMS.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    a.out.mkdir(parents=True, exist_ok=True)
    out = a.out / f'SV04_NEXT_283_CHECKPOINT_{a.pct}.zip'
    if out.exists():
        out.unlink()
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for f in files(root.parent):
            z.write(f, f.relative_to(root.parent).as_posix())
    # Selbstpruefung: ZIP lesbar, Summen stimmen
    with zipfile.ZipFile(out) as z:
        assert z.testzip() is None
        sums = z.read('SV04_NEXT_283_CHECKPOINT/SHA256SUMS.txt').decode().splitlines()
        bad = [l for l in sums if hashlib.sha256(z.read('SV04_NEXT_283_CHECKPOINT/' + l.split('  ', 1)[1])).hexdigest() != l.split('  ', 1)[0]]
        assert not bad, bad
    print(f'{out} {out.stat().st_size} Bytes | {len(lines)} Dateien | geaendert {len(changed)} | neu {len(new)}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
