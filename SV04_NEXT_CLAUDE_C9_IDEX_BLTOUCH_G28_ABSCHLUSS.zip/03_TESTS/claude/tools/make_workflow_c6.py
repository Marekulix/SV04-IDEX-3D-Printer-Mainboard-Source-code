#!/usr/bin/env python3
"""Erzeugt claude_c6_stm32_no_flash.yml TEXTUELL aus ChatGPTs funktionierendem B 309.yml (gleiche Schritte fuer Pruefung, OEM-Checkout, 309-Zusammensetzung, PlatformIO 6.1.18, Build).
Zwei strikt getrennte Jobs: control_309_original (unveraenderte 309, beide Profile) und modified_318_c6 (neue Kopie, 318-Installer, beide Profile). NO FLASH. Aufruf: make_workflow_c6.py <B 309.yml> <sha318> <shaC6> <out.yml>"""
import re
import sys
from pathlib import Path

b309, sha318, shac6, out = Path(sys.argv[1]).read_text(encoding='utf-8'), sys.argv[2], sys.argv[3], sys.argv[4]
steps = re.split(r'(?m)^(?=      - name: )', b309)
head, blocks = steps[0], steps[1:]
by = {re.match(r'      - name: (.*)', s).group(1): s for s in blocks}
need = lambda n: by[n].rstrip('\n') + '\n'
checkout = '      - name: Checkout input files\n        uses: actions/checkout@v4\n' if 'Checkout input files' not in by else need('Checkout input files')
verify = need('Verify packages and unpack')
clone = need('Checkout pinned OEM firmware (not user GitHub branch)')
integ = need('Integrate planner, guarded 282-to-287 migration, G29, C2 and EEPROM 306')
pio = need('Install PlatformIO 6.1.18')
build = need('Build STM32 profiles independently, framework-first, NO FLASH')
arch = need('Archive every log on success or failure')

def build_for(dirname, tag, label):
    s = build.replace('oem/.pio/build/STM32F103RET6_creality', f'{dirname}/.pio/build/STM32F103RET6_creality').replace('pio run -d oem -e', f'pio run -d {dirname} -e').replace("echo 'SOURCE_BASE=308_WITH_NO_FIRMWARE_CHANGES'", f"echo 'SOURCE_BASE={label}'").replace('evidence/$profile', f'evidence/{tag}/$profile').replace('mkdir -p "evidence/$profile"', f'mkdir -p "evidence/{tag}/$profile"').replace("echo \"PROFILE=$profile\"", f"echo \"BUILD_TREE={dirname}\"\n              echo \"PROFILE=$profile\"")
    assert s != build
    return s

extra_inputs = f'''      - name: Verify C6 inputs (318 hand-over and Claude C6 package)
        shell: bash
        run: |
          set -euo pipefail
          mkdir -p evidence c318 c6pkg
          echo '{sha318}  SV04_NEXT_318_GESAMTINTEGRATION_UND_C6_UEBERGABE_NO_FLASH.zip' | sha256sum -c - | tee evidence/input_318_sha.txt
          echo '{shac6}  SV04_NEXT_CLAUDE_C6_GESAMTINTEGRATION.zip' | sha256sum -c - | tee evidence/input_c6_sha.txt
          unzip -t SV04_NEXT_318_GESAMTINTEGRATION_UND_C6_UEBERGABE_NO_FLASH.zip > evidence/zip_318_integrity.txt
          unzip -t SV04_NEXT_CLAUDE_C6_GESAMTINTEGRATION.zip > evidence/zip_c6_integrity.txt
          unzip -q SV04_NEXT_318_GESAMTINTEGRATION_UND_C6_UEBERGABE_NO_FLASH.zip -d c318
          unzip -q SV04_NEXT_CLAUDE_C6_GESAMTINTEGRATION.zip -d c6pkg
          (cd c318 && python3 - <<'PYV'
          import json, hashlib, pathlib
          m = json.load(open('SHA256_MANIFEST_318.json')); items = m if isinstance(m, list) else m.get('files', m)
          if isinstance(items, dict): items = [{{'path': k, 'sha256': v if isinstance(v, str) else v.get('sha256')}} for k, v in items.items()]
          bad = [i for i in items if pathlib.Path(i.get('path') or i.get('file')).is_file() and hashlib.sha256(pathlib.Path(i.get('path') or i.get('file')).read_bytes()).hexdigest() != i.get('sha256')]
          print('MANIFEST_318 geprueft', len(items), 'abweichend', len(bad)); assert not bad
          PYV
          ) | tee evidence/manifest_318.txt
'''
host_tests = '''      - name: Run Claude C6 host regression (no network, no hardware)
        shell: bash
        run: |
          set -euo pipefail
          python3 -m venv /tmp/sv04host && /tmp/sv04host/bin/pip install pyyaml > evidence/pip_host.txt 2>&1
          export PATH=/tmp/sv04host/bin:$PATH
          (cd c6pkg && python3 run_tests.py --logs ../evidence/c6_host_tests) 2>&1 | tee evidence/c6_host_tests_summary.txt
          grep -q 'GESAMT: ALLE TESTS BESTANDEN' evidence/c6_host_tests_summary.txt
'''
install318 = '''      - name: Apply 318 installer to a NEW copy (309 stays untouched, fail-closed)
        shell: bash
        run: |
          set -euo pipefail
          sha256sum oem/Marlin/src/module/tool_change.cpp oem/Marlin/src/module/motion.cpp oem/Marlin/src/gcode/bedlevel/abl/G29.cpp | tee evidence/source_hashes_309_before_318.txt
          python3 c318/integrate_318.py oem oem318 2>&1 | tee evidence/integrate_318.txt
          grep -F '318 SOURCE OVERLAY APPLIED' evidence/integrate_318.txt
          diff -rq oem oem318 2>&1 | grep -v '^Only in .*\\.git' | tee evidence/diff_309_vs_318.txt || true
          for f in Marlin/src/module/tool_change.cpp Marlin/src/module/motion.cpp Marlin/src/gcode/bedlevel/abl/G29.cpp Marlin/src/feature/sv04_claude_auto60/sv04_claude_auto60_core.h Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc Marlin/src/feature/sv04_claude_auto60/sv04_claude_zhome_policy.h; do sha256sum "oem318/$f"; done | tee evidence/source_hashes_318.txt
          # the unmodified 309 tree must be byte-identical after the installer ran
          sha256sum oem/Marlin/src/module/tool_change.cpp oem/Marlin/src/module/motion.cpp oem/Marlin/src/gcode/bedlevel/abl/G29.cpp | diff - evidence/source_hashes_309_before_318.txt
'''
def job(jid, title, steps, art):
    return f"  {jid}:\n    name: \"{title}\"\n    runs-on: ubuntu-24.04\n    timeout-minutes: 240\n    steps:\n" + ''.join(steps) + f"\n      - name: Archive every log on success or failure\n        if: always()\n        uses: actions/upload-artifact@v4\n        with:\n          name: {art}\n          path: evidence/\n          if-no-files-found: warn\n"
base_prep = [checkout, verify, extra_inputs, clone, integ, pio]
j1 = job('control_309_original', 'Control build: UNMODIFIED 309 (both profiles)', base_prep + [build_for('oem', 'control_309', 'ORIGINAL_309_UNMODIFIED_CONTROL')], 'SV04_C6_CONTROL_309_ORIGINAL_STM32_LOGS_NO_FLASH')
j2 = job('modified_318_c6', 'Modified build: NEW 318 copy by integrate_318.py (both profiles)', base_prep + [host_tests, install318, build_for('oem318', 'modified_318', 'MODIFIED_318_NEW_COPY_OF_309')], 'SV04_C6_MODIFIED_318_STM32_LOGS_NO_FLASH')
txt = 'name: "C6 - SV04 NEXT 318 integration, control 309 vs modified 318, STM32 NO FLASH (number-free)"\n\non:\n  workflow_dispatch:\n\npermissions:\n  contents: read\n\njobs:\n' + j1 + '\n' + j2
Path(out).write_text(txt, encoding='utf-8', newline='\n'); print('geschrieben', out, len(txt.splitlines()), 'Zeilen')
