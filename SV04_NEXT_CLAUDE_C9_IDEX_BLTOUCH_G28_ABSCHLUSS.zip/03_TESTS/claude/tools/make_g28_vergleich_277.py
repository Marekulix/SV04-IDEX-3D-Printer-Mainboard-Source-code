#!/usr/bin/env python3
"""Fuehrt dieselben G28-Szenarien mit der ECHTEN G28.cpp im Stand 276 (ChatGPT) und im Stand 277 aus und schreibt die Vergleichstabelle (Markdown + CSV). Host-Simulation, KEINE Hardware.
Aufruf: python3 claude/tools/make_g28_vergleich_277.py --out DOCS"""
import argparse
import csv
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / '04_TESTS' / 'sim'))
import test_g28_a60 as G  # noqa: E402

CASES = [
    ('N1', 'Normalfall: volles G28, Modus AUTO_PARK (1)', ['p=', 'homed=none', 'mode=1']),
    ('N2', 'Normalfall: volles G28, Modus FULL_CONTROL (0)', ['p=', 'homed=none', 'mode=0']),
    ('N3', 'G28 Z allein (Achsen schon referenziert)', ['p=Z', 'homed=all']),
    ('F1', 'BLTouch meldet Alarm beim Einfahren (probe.stow)', ['p=', 'homed=none', 'stow_fail=1']),
    ('F2', 'T0-Referenzfahrt kehrt frueh zurueck (T1 war erfolgreich)', ['p=', 'homed=none', 'x_early_t0=1']),
    ('F3', 'T1-Offset ausserhalb des Verfahrwegs (M218-Wert 400)', ['p=', 'homed=none', 'hotend_x1=400']),
    ('F5a', 'volles G28 im Modus DUPLICATION (2)', ['p=', 'homed=none', 'mode=2']),
    ('F5b', 'volles G28 im Modus MIRRORED (3)', ['p=', 'homed=none', 'mode=3']),
    ('F6', 'Modus DUPLICATION: zweiter X-Durchgang scheitert', ['p=', 'homed=none', 'mode=2', 'x_t1_on_call=2']),
]
BITS = lambda b: ''.join(c for c, m in (('X', 1), ('Y', 2), ('Z', 4)) if int(b) & m) or '-'


def row(r):
    z = 'ja' if 'homeaxis Z T0' in r['t'] else 'nein'
    ui = 'ja' if 'RTS_MoveAxisHoming' in r['t'] else 'nein'
    return {'Z gefahren': z, 'homed': BITS(r['axes']['homed']), 'trusted': BITS(r['axes']['trusted']), 'Y gefahren': 'ja' if 'homeaxis Y T0' in r['t'] else 'nein',
            'Erfolg ans Display': ui, 'Duplizierung danach': r['tool']['dupl'], 'Leveling danach': r['LEV'].split('=')[1], 'Ergebnisstatus': ('ok=' + r['res']['ok']) if r['res'] else 'nicht exportiert'}


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', required=True)
    a = ap.parse_args(argv)
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    rows = []
    for cid, title, args in CASES:
        for which in ('276', '277'):
            rows.append({'Fall': cid, 'Szenario': title, 'Stand': which, **row(G.run(which, *args))})
    with open(out / 'G28_VERGLEICH_276_277.csv', 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader(); w.writerows(rows)
    md = ['# G28: Stand 276 gegen Stand 277 (echte G28.cpp, Host-Simulation, KEINE Hardware)', '',
          'Gleiche Szenarien, gleiche Simulation; nur der Quellstand unterscheidet sich. `homed`/`trusted` = Achsen, die danach als referenziert bzw. vertraut gelten. Beleg: `claude/04_TESTS/sim/test_g28_a60.py`.', '',
          '| Fall | Szenario | Stand | Z gefahren | Y gefahren | homed | trusted | Erfolg ans Display | Duplizierung danach | Leveling danach | Ergebnisstatus |', '|---|---|---|---|---|---|---|---|---|---|---|']
    for r in rows:
        md.append(f"| {r['Fall']} | {r['Szenario']} | {r['Stand']} | {r['Z gefahren']} | {r['Y gefahren']} | {r['homed']} | {r['trusted']} | {r['Erfolg ans Display']} | {r['Duplizierung danach']} | {r['Leveling danach']} | {r['Ergebnisstatus']} |")
    (out / 'G28_VERGLEICH_276_277.md').write_text('\n'.join(md) + '\n', encoding='utf-8')
    print(len(rows), 'Zeilen')
    return 0


if __name__ == '__main__':
    sys.exit(main())
