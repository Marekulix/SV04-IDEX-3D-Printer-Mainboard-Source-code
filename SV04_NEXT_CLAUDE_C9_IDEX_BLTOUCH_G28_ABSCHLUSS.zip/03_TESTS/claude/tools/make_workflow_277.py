#!/usr/bin/env python3
"""Erzeugt 277.yml aus der Vorlage und traegt den SHA-256 von SV04_NEXT_277.zip fest ein (wie 276.yml). Aufruf: make_workflow_277.py --zip-sha256 HEX --out 277.yml"""
import argparse
from pathlib import Path

TEMPLATE = r"""name: '277 - SV04 P1 IDEX BLTouch + Auto60 Integration STM32 - NO FLASH'

on:
  workflow_dispatch:

permissions:
  contents: read

env:
  ZIP_SHA256: '@@ZIP_SHA256@@'
  OEM_COMMIT: '1867fcba75354a5c65e0631d6972dd19f1bd6cbe'

jobs:
  tests:
    runs-on: ubuntu-24.04
    timeout-minutes: 60
    steps:
      - name: Checkout your repository
        uses: actions/checkout@v4

      - name: Verify source package
        shell: bash
        run: |
          set -euo pipefail
          mkdir -p evidence point1
          test -f SV04_NEXT_277.zip || {
            echo 'ERROR: Upload SV04_NEXT_277.zip into repository root first'
            exit 1
          }
          echo "${ZIP_SHA256}  SV04_NEXT_277.zip" | sha256sum -c - | tee evidence/source_sha256_verified.txt
          unzip -t SV04_NEXT_277.zip | tee evidence/archive_check.txt
          unzip -q SV04_NEXT_277.zip -d point1
          sha256sum SV04_NEXT_277.zip | tee evidence/source_checksum.txt

      - name: ChatGPT patch tests 268-276 (unchanged)
        shell: bash
        run: |
          set -euo pipefail
          cd point1
          python3 -m unittest -v test_268.py test_272.py test_274.py test_275.py test_276.py 2>&1 | tee ../evidence/chatgpt_patch_tests.txt

      - name: Python environment for the host simulation tests
        shell: bash
        run: |
          set -euo pipefail
          python3 -m venv /tmp/sv04-test
          /tmp/sv04-test/bin/python -m pip install pyyaml > evidence/pip_test_env.log 2>&1
          g++ --version | head -1 | tee evidence/gpp_version.txt

      - name: Host tests - core, pipeline, patch and workflow structure
        shell: bash
        run: |
          set -euo pipefail
          cd point1/claude
          /tmp/sv04-test/bin/python -m unittest -v 04_TESTS.test_core_a60 04_TESTS.test_pipeline_a60 04_TESTS.test_patch_and_build_a60 2>&1 | tee ../../evidence/host_core_pipeline_tests.txt

      - name: Host tests - real G28 / G29 / backend simulation (no hardware)
        shell: bash
        run: |
          set -euo pipefail
          cd point1/claude
          /tmp/sv04-test/bin/python -m unittest discover -s 04_TESTS/sim -p 'test_*.py' -v 2>&1 | tee ../../evidence/host_sim_tests.txt

      - name: Host mutation tests (sensitivity, informational)
        continue-on-error: true
        shell: bash
        run: |
          cd point1/claude
          /tmp/sv04-test/bin/python -m unittest -v 04_TESTS.test_mutations_a60 2>&1 | tee ../../evidence/host_mutation_tests.txt

      - name: Save diagnostics (never firmware binaries)
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: SV04_NEXT_277_HOST_TESTS
          path: evidence/
          if-no-files-found: warn

  build:
    needs: tests
    runs-on: ubuntu-24.04
    timeout-minutes: 90
    strategy:
      fail-fast: false
      matrix:
        include:
          - profile: baseline_oem
            stage: none
            flags: ''
          - profile: p1_corrections
            stage: p1
            flags: ''
          - profile: integrated_backend
            stage: integrated
            flags: ''
          - profile: integrated_failclosed
            stage: integrated
            flags: '-DSV04_CLAUDE_HOME_BACKEND_AVAILABLE=0'
    steps:
      - name: Checkout your repository
        uses: actions/checkout@v4

      - name: Verify source package
        shell: bash
        run: |
          set -euo pipefail
          mkdir -p evidence point1
          test -f SV04_NEXT_277.zip || { echo 'ERROR: Upload SV04_NEXT_277.zip into repository root first'; exit 1; }
          echo "${ZIP_SHA256}  SV04_NEXT_277.zip" | sha256sum -c - | tee evidence/source_sha256_verified.txt
          unzip -q SV04_NEXT_277.zip -d point1

      - name: Clone immutable Sovol OEM
        shell: bash
        run: |
          set -euo pipefail
          git clone -q https://github.com/Sovol3d/SV04-IDEX-3D-Printer-Mainboard-Source-code.git oem
          git -C oem checkout -q --detach "${OEM_COMMIT}"
          test "$(git -C oem rev-parse HEAD)" = "${OEM_COMMIT}"
          git -C oem rev-parse HEAD | tee evidence/oem_revision.txt

      - name: Verify the OEM files against the shipped reference copies
        shell: bash
        run: |
          set -euo pipefail
          # CI-verified blobs (G28/G29/LCD_RTS.cpp) MUST match; the others are reported (their shipped copies were not CI-verified)
          chk() { got="$(git -C oem hash-object "$1")"; if [ "$got" = "$2" ]; then echo "MATCH     $1 $got"; else echo "DIFFERENT $1 got=$got shipped=$2"; return 1; fi; }
          {
            chk Marlin/src/gcode/calibrate/G28.cpp 5700ac25228ef7405797a80b840bab1dacddfcc7
            chk Marlin/src/gcode/bedlevel/abl/G29.cpp 02df6e4c8d017cf4dd1d4c9e6986a8967a317a8b
            chk Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp 2a63c281c8d8861e9780997df60e82becaa02805
          } | tee evidence/oem_verified_blobs.txt
          {
            chk Marlin/src/module/motion.h b9885c95fb8fe294a921c068ed95414818377f22 || true
            chk Marlin/src/module/motion.cpp dd5b25147389605d7efe5aa9ea959255fcdea4d0 || true
            chk Marlin/src/gcode/gcode.cpp 888dbe7027eba36e4a9cf2ef6b6ce5d71feb8bd8 || true
          } | tee evidence/oem_reported_blobs.txt

      - name: Apply the ChatGPT patch chain 268-276 (unchanged scripts)
        if: matrix.stage != 'none'
        shell: bash
        run: |
          set -euo pipefail
          python3 point1/apply_268.py oem/Marlin/src/gcode/calibrate/G28.cpp --verify-oem --out oem/Marlin/src/gcode/calibrate/G28.cpp.patched
          mv oem/Marlin/src/gcode/calibrate/G28.cpp.patched oem/Marlin/src/gcode/calibrate/G28.cpp
          python3 point1/apply_272.py oem/Marlin/src/gcode/calibrate/G28.cpp --out oem/Marlin/src/gcode/calibrate/G28.cpp.patched
          mv oem/Marlin/src/gcode/calibrate/G28.cpp.patched oem/Marlin/src/gcode/calibrate/G28.cpp
          python3 point1/apply_274.py --root oem | tee evidence/patch274_apply.txt
          python3 point1/apply_275.py oem/Marlin/src/gcode/calibrate/G28.cpp | tee evidence/patch275_apply.txt
          python3 point1/apply_276.py --root oem | tee evidence/patch276_apply.txt
          sha256sum oem/Marlin/src/gcode/calibrate/G28.cpp | tee evidence/g28_after_276.txt

      - name: Apply 277 (P1 corrections and, for the integrated profiles, the Auto60 integration)
        if: matrix.stage != 'none'
        shell: bash
        run: |
          set -euo pipefail
          python3 point1/apply_277.py --root oem --profile "${{ matrix.stage }}" --report evidence/patch277_report.json | tee evidence/patch277_apply.txt
          git -C oem diff --check | tee evidence/diff_check.txt
          git -C oem diff --stat | tee evidence/diff_stat.txt
          git -C oem diff > evidence/total_diff_vs_oem.patch
          test -s evidence/total_diff_vs_oem.patch
          sha256sum oem/Marlin/src/gcode/calibrate/G28.cpp oem/Marlin/src/module/motion.cpp oem/Marlin/src/module/motion.h oem/Marlin/src/gcode/bedlevel/abl/G29.cpp oem/Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp oem/Marlin/src/gcode/gcode.cpp | tee evidence/patched_file_checksums.txt

      - name: Assert that no test double and no foreign build flag is used
        shell: bash
        run: |
          set -euo pipefail
          ! grep -R "SV04_CLAUDE_HOME_BACKEND_EXTERNAL" oem/platformio.ini oem/Marlin/Configuration.h oem/Marlin/Configuration_adv.h
          ! find oem -name '*TEST_ONLY*' | grep .
          echo "no test double: OK" | tee evidence/no_test_double.txt

      - name: Install pinned PlatformIO
        shell: bash
        run: |
          set -euo pipefail
          python3 -m venv /tmp/sv04-pio
          /tmp/sv04-pio/bin/python -m pip install 'platformio==6.1.18' > evidence/pio_install.log 2>&1
          /tmp/sv04-pio/bin/python -m platformio --version | tee evidence/pio_version.txt

      - name: Build STM32 firmware (no upload)
        shell: bash
        env:
          PLATFORMIO_BUILD_FLAGS: ${{ matrix.flags }}
        run: |
          set +e
          /tmp/sv04-pio/bin/python -m platformio run -d oem -e STM32F103RET6_creality > evidence/build.log 2>&1
          rc=$?
          echo "PROFILE=${{ matrix.profile }}" | tee evidence/result.txt
          echo "BUILD_FLAGS=${PLATFORMIO_BUILD_FLAGS}" | tee -a evidence/result.txt
          echo "BUILD_EXIT=$rc" | tee -a evidence/result.txt
          echo 'FLASH_ALLOWED=NO' | tee -a evidence/result.txt
          echo 'HARDWARE_TESTED=NO' | tee -a evidence/result.txt
          grep -nE 'fatal error:|error:|undefined reference|SUCCESS|FAILED' evidence/build.log > evidence/errors.txt || true
          grep -nE 'warning:' evidence/build.log > evidence/warnings.txt || true
          grep -nE '^(RAM|Flash):' evidence/build.log | tee evidence/ram_flash.txt || true
          tail -n 60 evidence/build.log
          exit "$rc"

      - name: Post-build evidence (symbols and strings; no firmware is stored)
        if: always()
        shell: bash
        run: |
          set +e
          ELF=oem/.pio/build/STM32F103RET6_creality/firmware.elf
          BIN=oem/.pio/build/STM32F103RET6_creality/firmware.bin
          NM="$(find ~/.platformio -name arm-none-eabi-nm -type f 2>/dev/null | head -1)"
          if [ -f "$ELF" ]; then
            sha256sum "$BIN" | tee evidence/firmware_sha256.txt
            [ -n "$NM" ] && "$NM" -C "$ELF" | grep -E 'SV04Claude_|sv04_p1_' | tee evidence/symbols.txt
            echo "G28_X_Y_Z_strings=$(strings -n 4 "$BIN" | grep -c 'G28 X Y Z')" | tee evidence/backend_string_count.txt
          else
            echo 'no ELF (build failed)' | tee evidence/symbols.txt
          fi

      - name: Save diagnostics (never firmware binaries)
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: SV04_NEXT_277_${{ matrix.profile }}_STM32_LOGS_NO_FLASH
          path: evidence/
          if-no-files-found: warn
"""


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--zip-sha256', required=True)
    ap.add_argument('--out', required=True)
    a = ap.parse_args(argv)
    if len(a.zip_sha256) != 64 or any(c not in '0123456789abcdef' for c in a.zip_sha256):
        raise SystemExit('ungueltiger SHA-256')
    Path(a.out).write_text(TEMPLATE.replace('@@ZIP_SHA256@@', a.zip_sha256), encoding='utf-8', newline='\n')
    print('geschrieben:', a.out)


if __name__ == '__main__':
    main()
