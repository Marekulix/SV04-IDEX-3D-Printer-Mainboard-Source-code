#!/usr/bin/env python3
"""Statusmatrix 277: eine Zeile je Arbeitsschritt (1-30) und je harter Abnahmebedingung mit den Kategorien IMPLEMENTIERT / LOKAL GETESTET / STM32 GEBAUT / HARDWARE GEPRUEFT / BLOCKIERT.
Jeder referenzierte Test wird gegen die ROHLOGS (06_EVIDENCE/host) geprueft; steht er dort nicht als bestanden, bricht das Skript mit Exitcode 1 ab (kein Erfolg ohne Log).
Aufruf: python3 claude/tools/make_status_277.py [--out DOCS]"""
import argparse
import csv
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PKG = ROOT.parent
H = ROOT / '06_EVIDENCE' / 'host'
S = {
    'p1': PKG / 'apply_277_p1.py', 'orch': PKG / 'apply_277.py', 'inc': ROOT / '02_SOURCE/Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc', 'hooks': ROOT / '02_SOURCE/Marlin/src/lcd/e3v2/creality/sv04_claude_hooks.h',
    'core': ROOT / '02_SOURCE/Marlin/src/feature/sv04_claude_auto60/sv04_claude_auto60_core.h', 'tool': ROOT / '03_PATCHES/apply_claude_parallel.py', 'wf': ROOT / 'tools/make_workflow_277.py',
}


def ref(key, needle):
    p = S[key]
    for i, l in enumerate(p.read_text(encoding='utf-8').split('\n'), 1):
        if needle in l:
            return f'{p.name}:{i}'
    raise SystemExit(f'Quellstelle nicht gefunden: {p.name} :: {needle}')


def logs():
    cpp = {}
    for l in (H / '01_core_tests_cpp.txt').read_text().splitlines():
        m = re.match(r'(PASS|FAIL) (\w+) (.*)', l)
        if m:
            cpp[m.group(2)] = m.group(1)
    py = {}
    for f in ('02_unittest_host_core_pipeline.txt', '03_unittest_sim.txt'):
        lines = (H / f).read_text().splitlines()
        for i, l in enumerate(lines):
            m = re.match(r'(test_\w+) \(', l)
            if m:
                py[m.group(1)] = 'ok' if re.search(r'\.\.\. ok\b', ' '.join(lines[i:i + 3])) else 'NOT_OK'
    return cpp, py


def P(*pre): return ['py:' + p for p in pre]
def C(*ids): return ['C++:' + i for i in ids]


ROWS = [
 (1, 'OEM + vollstaendige 276-Kette reproduzierbar anwenden; vorher/nachher SHA-256; git diff --check; Quellvergleich', 'JA', 'JA', '`git diff --check` selbst nur im Workflow; Hygiene-Aequivalent lokal',
  P('O01_', 'O02_', 'O03_', 'O05_', 'H01_', 'H04_', 'D01_', 'D02_'), [('orch', 'def apply('), ('p1', 'def apply(')], 'Reale Ausfuehrung von `git diff --check` und der Klon-Hashes erst in 277.yml (NOT RUN).'),
 (2, 'T1-X- und T0-X-Homing innerhalb derselben Sitzung bestaetigen; nie aus Sollwert/alten Flags/axis_is_trusted', 'JA', 'JA', '-',
  P('F03_', 'F04_', 'G03_', 'G04_', 'I03_', 'I04_'), [('p1', "sv04_p1_t1_ok = sv04_t1_homed_this_g28;"), ('p1', 'sv04_p1_t0_ok = sv04_p1_t0_x_completed;')], 'Evidenz = Abschlussflags NACH dem Ende von homeaxis() (Software), nicht der Endschalter selbst.'),
 (3, 'Abschlussflags NACH Endstopp/Homing/BLTouch; bei frueher Rueckkehr/Fehltrigger/Alarm/Timeout/Abbruch nie gueltig', 'JA', 'JA', 'echte Endschalter/BLTouch-Reaktion',
  P('F01_', 'F02_', 'F03_', 'F05_', 'I05_', 'I06_', 'I08_'), [('p1', 'homeaxis() runs set_axis_is_at_home() BEFORE probe.stow()'), ('p1', 'sv04_p1_g28_end = true;')], 'BEFUND am OEM-Code: set_axis_is_at_home() laeuft VOR probe.stow(); ein Endschalter-Fehler ist im OEM ein kill(). homeaxis() ist in der Simulation ein MODELL mit der OEM-Reihenfolge.'),
 (4, 'Physische T1-Position nicht behaupten; Software- von physischer Evidenz trennen', 'JA', 'NEIN', 'physischer Beleg (Sensor/Hardware) nicht vorhanden',
  P('F06_'), [('p1', 'NOT a physical position proof')], 'Alle Ergebnisfelder heissen/dokumentieren SOFTWARE-Evidenz; keine Parkbestaetigung wird behauptet.'),
 (5, 'Parkkoordinate mit x_home_pos(1) und Achsgrenzen validieren; Hotend-Offsets; vier IDEX-Modi', 'JA', 'JA', 'Kollisionsfreiheit/physische Grenzen',
  P('F06_', 'F07_', 'F11_', 'I07_', 'I09_'), [('p1', 'bool sv04_p1_t1_home_plausible()' if False else 'sv04_p1_t1_home_plausible()')], 'Plausibilitaet gegen X2_MIN_POS/X2_MAX_POS und x_home_pos(0); ein Offset <= 0 faellt laut OEM-Formel auf X2_HOME_POS zurueck.'),
 (6, 'T1-Fehler verhindert T0-Folgebewegung; T0-Fehler verhindert Z; Z/BLTouch-Fehler verhindert Erfolg, Nachlauf, Restore', 'JA', 'JA', '-',
  P('F01_', 'F03_', 'F04_', 'F08_', 'I03_', 'I04_', 'I05_'), [('p1', '&& !sv04_p1_x_failed')], 'Nach einem Fehler laeuft auch keine Y-Referenzfahrt mehr (neu in 277).'),
 (7, 'Safe-Homing, Toolchange, G28-Varianten (G28, X, Y, Z, XY, XYZ, O, Moduswechsel) und Fehlerpfade getrennt regressieren', 'JA', 'JA', 'Verhalten am Geraet',
  P('G01_', 'G02_', 'F10_', 'F11_'), [('p1', 'SV04_P1_Z_ONLY_REHOMES_X')], 'Normalfaelle (Modus 0/1) laufen auf 276 und 277 SPURGLEICH. Absichtliche Abweichungen: Modi 2/3 (276 verweigerte Z), Fehlerpfade.'),
 (8, 'Z-Offset, EEPROM, gespeichertes Mesh durch Nebeneffekte unveraendert', 'JA', 'JA', '-',
  P('H02_', 'I25_', 'I26_'), [('p1', 'set_axis_unhomed(X_AXIS)')], 'Bekannte Nebenwirkung UNVERAENDERT aus 276: jedes gescheiterte/verweigerte G28 laesst die Nivellierung AUS (siehe OFFEN).'),
 (9, 'Tests mit echten, aus OEM abgeleiteten C++-Aufrufpfaden (nicht nur Regex); Negativtests', 'JA', 'JA', '-',
  P('G01_', 'F01_', 'F07_', 'F08_', 'I01_', 'I10_'), [('p1', 'class Sv04P1Commit' if False else 'struct Sv04P1Commit')], 'Die ECHTE G28.cpp/G29.cpp werden uebersetzt und ausgefuehrt; motion-Bloecke wortwoertlich extrahiert; homeaxis() ist ein Modell.'),
 (10, 'Kritische Faelle konservativ stoppen; kein Compile-Erfolg als Bewegungsbeweis', 'JA', 'JA', 'Bewegungsablauf am Geraet',
  P('F05_', 'F09_', 'I08_', 'I25_'), [('p1', 'sv04_p1_x_failed')], 'Ein Compile beweist keine Bewegungssequenz: die Bewegungsablauf-Pruefung am Geraet ist offen (HARDWARE_ABNAHME_277.md).'),
 (11, 'Produktives SV04Claude_HomeBackendRequest(sid): nur annehmen wenn bereit, nicht reentrant, Zustand zulaessig, SID gueltig; true = angenommen', 'JA', 'JA', '-',
  P('I01_', 'I02_', 'I12_', 'I13_', 'I16_', 'I23_', 'I27_'), [('inc', 'bool SV04Claude_HomeBackendRequest(const uint32_t sid) {')], 'Fuehrt selbst nichts aus: stellt nur "G28 X Y Z" in die Queue.'),
 (12, 'G28 zur Laufzeit sicher anstossen (Queue/Hauptschleife), nicht synchron aus Tick/ISR', 'JA', 'JA', 'Reihenfolge in idle()/MarlinCore.cpp nicht verifizierbar',
  P('I02_', 'I12_', 'I13_'), [('inc', 'queue.enqueue_now_P(PSTR("G28 X Y Z"));')], 'MarlinCore.cpp lag nicht vor: der Aufrufort von RTSUpdate() ist nicht belegt (Tick sitzt am Anfang von RTSUpdate()).'),
 (13, 'HomeResult genau einmal; falsche/alte SID, doppelte Callbacks, Timeouts, Druckstart, Wiederholung abwehren', 'JA', 'JA', '-',
  P('I01_', 'I13_', 'I14_', 'I15_', 'I16_', 'I17_', 'I18_', 'I27_'), [('inc', 'static void sv04c_hb_finish(const bool success, const bool gate) {')], 'Mutationsnachweis: P01-P10 erkannt (07_mutationen_backend.txt).'),
 (14, 'idex_gate_confirmed nur nach durchgehender T1-/T0-/BLTouch-Sitzungsevidenz; Homing-Erfolg getrennt', 'JA', 'TEILWEISE', 'Pfad "Homing ok, Gate false" im Backend nicht erreichbar (done impliziert die Gate-Bedingungen)',
  P('I01_', 'I03_', 'I04_', 'I05_', 'I07_') + C('C04', 'C05', 'C07'), [('inc', 'const bool gate = done && r.x_attempted && r.t1_ok && r.t0_ok')], 'Der Koordinator verlangt das Gate (Config::require_idex_gate=true); das Fehlen wird im Kern getestet (C04).'),
 (15, 'Produktionsbackend nur mit echter Verbindung; Test-Double nicht im Release; ...AVAILABLE=1 erst nach Link-Nachweis', 'JA', 'TEILWEISE', 'Link-Nachweis auf dem Ziel (STM32)',
  P('C01_', 'B03_', 'I23_', 'X02_'), [('hooks', 'SV04_CLAUDE_HOME_BACKEND_AVAILABLE SV04_CLAUDE_HAS_P1_RESULT')], 'Host-Link der Kette (G28 + G29 + Adapter + Backend) belegt; Ziel-Link nur ueber 277.yml. Der Test-Double-Schalter wird von keinem Profil gesetzt.'),
 (16, 'Claude-G29/LCD/gcode-Overlay auf demselben 276-Stand integrieren (Header, Call-Sites, Linkbarkeit)', 'JA', 'JA', 'Ziel-Link',
  P('O01_', 'I01_', 'X02_', 'X03_', 'P01_', 'P05_'), [('orch', "P.run(root / REL['lcd']")], 'Dasselbe Werkzeug wie die Testpipeline; hashgleich (O01).'),
 (17, 'G29-Endskript "G28 XY": keine unerwartete Bewegung, kein Verlust des Auto60-Zustands, keine falsche Homing-/Leveling-Bestaetigung; Negativtests', 'JA', 'JA', '-',
  P('I01_', 'I10_', 'I11_', 'I26_'), [('inc', 'r.endscript_ok = end_ok &&')], 'BEFUND: Das Endskript ist ein echter G28 XY INNERHALB jeder G29 und bewegt beide Wagen (OEM-Verhalten). Sein Ergebnis und der Zustand danach werden ausgewertet.'),
 (18, 'Sicherer Cancel waehrend Auto60; nicht von der Touch-Sperre abhaengig; Fehler/Abbruch sichtbar; kein M500 ohne Erfolg', 'JA', 'JA', 'Verhalten des realen DWIN',
  P('I14_', 'I19_', 'I20_', 'I21_', 'I22_', 'I25_'), [('inc', 'void SV04Claude_Auto60_TouchCancel()')], 'Touch = Abbruchanforderung; die gedrueckte Taste wird verworfen. Eine laufende G28/G29 laesst sich nicht physisch stoppen, nur ihre Folgen.'),
 (19, 'Tests: Start/Abbruch/Wiederholung, G28-SIDs, Timeout, BLTouch-Alarm, Endstopp, T1-Plausibilitaet, vier IDEX-Modi, G29+G28XY, schlechtes Mesh, kein EEPROM bei Fehler', 'JA', 'JA', 'Kollisionserkennung: nur Software-Plausibilitaet',
  P('I03_', 'I05_', 'I08_', 'I09_', 'I10_', 'I13_', 'I25_', 'I26_', 'F11_') + C('A18', 'G07'), [('inc', 'static bool sv04c_hb_full_form()')], 'Eine echte Kollisionserkennung ist ohne Hardware nicht moeglich.'),
 (20, 'Header-/Linkfehlerfreiheit, keine toten Backend-Pfade, kein ISR-Blockieren, keine falsche Erfolgsanzeige', 'JA', 'TEILWEISE', 'STM32-Compile und -Link',
  P('X01_', 'X02_', 'X03_', 'X07_', 'I23_', 'I22_'), [('inc', 'static void sv04c_hb_tick()')], 'Streng uebersetzt in 16 Konfigurationen; keine neuen Warnungen in der echten G28.cpp (X07). Der Tick laeuft im Hauptschleifenkontext und ist gegen Re-Entranz gesperrt.'),
 (21, 'Mindestens zwei STM32-Profile bauen (a) 276+P1, (b) 276+Auto60+Backend; BUILD_EXIT, Diagnosen, RAM/Flash', 'JA', 'NEIN', 'Kein STM32-Build moeglich: keine ARM-Toolchain, kein PlatformIO, kein Netz',
  P('B01_', 'B02_', 'B03_', 'B04_'), [('wf', 'integrated_backend')], '277.yml baut VIER Profile (baseline_oem, p1_corrections, integrated_backend, integrated_failclosed). NOT RUN. RAM/Flash: nicht vorhanden.'),
 (22, 'Regression: 57 P1-Tests, 126 C++-Tests, 80 Python-Tests des alten Pakets; neue Integrationstests', 'JA', 'JA', '-',
  P('S01_', 'S08_', 'P02_', 'V10_', 'X02_') + C('E01', 'F07', 'G13'), [('core', 'class Coordinator')], 'Angepasst: S08 (fail-closed braucht jetzt ausdruecklich ...AVAILABLE=0) und P02 (G28.cpp ist nicht mehr gesperrt). Alle anderen Altests unveraendert; Testinfrastruktur baut jetzt ueber den integrierten Stand.'),
 (23, 'Statische Pruefung aller modifizierten Dateien; reproduzierbare Diffs; SHA-256; GPL-Hinweise', 'JA', 'JA', 'cppcheck/Zielcompiler',
  P('X01_', 'X04_', 'X07_', 'D01_', 'D02_', 'C02_', 'H02_'), [('tool', 'def patch_g28(data):')], 'Statisch = strenger Host-Compiler (-Wall -Wextra -Werror auf eigenem Code) und Warnungsvergleich; kein Zielcompiler.'),
 (24, 'Einheitlicher Quellstand und ein eindeutiges Patch-/Build-Skript', 'JA', 'JA', '-',
  P('O01_', 'O02_', 'O03_', 'O04_'), [('orch', 'def main(argv=None):')], 'python3 apply_277.py --root oem --profile p1|integrated'),
 (25, 'GitHub-Workflow fuer das Android-Tablet, ohne Flashfreigabe; genau zwei Upload-Dateien 277.yml + SV04_NEXT_277.zip', 'JA', 'TEILWEISE', 'Ausfuehrung auf GitHub',
  P('B01_', 'B02_', 'B03_', 'B05_', 'B06_'), [('wf', 'workflow_dispatch')], '277 war laut Auftrag die naechste freie Version; ob sie inzwischen vergeben ist, kann ich nicht pruefen.'),
 (26, 'ZIP mit Patchkette, Integrationsquelle, Tests, Logs, Doku; keine installierbare Firmware', 'JA', 'JA', '-', P('C01_'), [('wf', 'path:' if False else 'upload-artifact')], 'Keine .bin/.hex/.elf; das ZIP enthaelt nur Quelltext, Tests, Logs, Doku.'),
 (27, 'Gesamtbericht mit den Kategorien IMPLEMENTIERT / LOKAL GETESTET / STM32 GEBAUT / HARDWARE GEPRUEFT / BLOCKIERT', 'JA', 'JA', '-', [], [('wf', 'TEMPLATE')], 'docs/ERGEBNISBERICHT_277.md; dieses Blatt (STATUS_277.csv).'),
 (28, 'Sichere, getrennte Hardware-Abnahmecheckliste; keine Hardware-Erfolge erfinden', 'JA', 'NEIN', 'Hardwarepruefung NICHT durchgefuehrt', [], [('wf', 'TEMPLATE')], 'docs/HARDWARE_ABNAHME_277.md'),
 (29, 'Fehler im ersten STM32-Lauf selbst korrigieren und erneut bauen', 'NEIN', 'NEIN', 'Es gab keinen STM32-Lauf: nichts zu korrigieren und nichts erneut zu bauen', [], [('wf', 'TEMPLATE')], 'Das groesste verbleibende Risiko: der erste Compile auf dem Ziel (docs/ERGEBNISBERICHT_277.md).'),
 (30, 'Blockaden mit Reproduktionsschritten melden, nicht als bestanden werten', 'JA', 'JA', '-', [], [('wf', 'TEMPLATE')], 'docs/OFFEN_UND_BLOCKIERT_277.md'),
]
HARD = [
 ('A1', 'P1-G28/BLTouch/IDEX und Claude-Auto60 nicht nur textuell, sondern mit realen Funktionen zusammengeschlossen', 'JA', 'JA', 'Verbindung auf dem Ziel (Compile/Link)', P('I01_', 'I10_', 'O01_'), 'Echter G28 + echte G29 + produktives Backend in einer Host-Kette.'),
 ('A2', 'Keine falschen Erfolgs-/Park-/Homing-Rueckmeldungen', 'JA', 'JA', 'physische Parkposition', P('F01_', 'F02_', 'F09_', 'I03_', 'I05_', 'I25_'), 'Erfolg = Software-Evidenz; es wird nie eine physische Parkung behauptet.'),
 ('A3', 'Fehler-/Cancel-Pfade verhindern unzulaessige Folgebewegung und M500', 'JA', 'JA', 'Verhalten am Geraet', P('I03_', 'I14_', 'I19_', 'I20_', 'I25_'), 'Ausnahme: eine bereits laufende G28/G29 laeuft zu Ende.'),
 ('A4', 'Kein toter Produktionsbackend-Pfad und keine Test-Double-Abhaengigkeit', 'JA', 'TEILWEISE', 'Ziel-Link', P('C01_', 'B03_', 'I23_'), 'Das Test-Double lebt nur in Host-Tests hinter -DSV04_CLAUDE_HOME_BACKEND_EXTERNAL.'),
 ('A5', 'Gemeinsamer STM32-Gesamtbuild erfolgreich oder Fehler dokumentiert und korrigiert', 'NEIN', 'NEIN', 'KEIN STM32-BUILD durchgefuehrt', [], 'NICHT erfuellt. Vorbereitet: 277.yml.'),
 ('A6', 'Altes funktionierendes Referenzpaket unveraendert', 'JA', 'JA', '-', P('O05_'), 'ChatGPTs Skripte und Tests liegen byte-identisch bei; Claudes Vorlieferung liegt unveraendert im Archivordner (nur Dokumente).'),
 ('A7', 'Kein Flashen, kein "installierbar" ohne separate Hardware-Abnahme', 'JA', 'NEIN', 'Hardware-Abnahme', P('B03_', 'C01_'), 'FLASH_ALLOWED=NO, HARDWARE_TESTED=NO in jedem Profil.'),
 ('A8', 'Keine Aenderung der Prozentanzeige ohne belegte Integration', 'JA', 'NEIN', 'Wertaenderung nur nach Hardware-/STM32-Beleg', [], 'Unveraendert: 55 / 52 / 43 / 55 / 55 / 25, gesamt 47,5 % (Entwicklungsschaetzung).'),
]


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default=str(PKG / 'docs'))
    a = ap.parse_args(argv)
    cpp, py = logs()
    out, bad = [], []

    def check(tests):
        lines = []
        for t in tests:
            kind, name = t.split(':', 1)
            if kind == 'C++':
                ok = cpp.get(name) == 'PASS'
            else:
                hits = [k for k in py if k.startswith('test_' + name)]
                ok = bool(hits) and all(py[k] == 'ok' for k in hits)
            lines.append((t, ok))
        return lines

    for n, req, impl, tested, blocked, tests, refs, note in ROWS:
        res = check(tests)
        fail = [t for t, ok in res if not ok]
        if fail:
            bad.append((n, fail))
        files = '; '.join(ref(k, nd) for k, nd in refs)
        out.append([n, req, impl, 'FEHLER (Test nicht im Log bestanden)' if fail else tested, 'NEIN', 'NEIN', blocked, files, ' | '.join(tests) or '-', note])
    for n, req, impl, tested, blocked, tests, note in HARD:
        res = check(tests)
        fail = [t for t, ok in res if not ok]
        if fail:
            bad.append((n, fail))
        out.append([n, req, impl, 'FEHLER (Test nicht im Log bestanden)' if fail else tested, 'NEIN', 'NEIN', blocked, '-', ' | '.join(tests) or '-', note])
    outdir = Path(a.out)
    outdir.mkdir(parents=True, exist_ok=True)
    with open(outdir / 'STATUS_277.csv', 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['nr', 'anforderung', 'IMPLEMENTIERT', 'LOKAL_GETESTET', 'STM32_GEBAUT', 'HARDWARE_GEPRUEFT', 'BLOCKIERT_oder_offen', 'dateien_zeilen', 'tests', 'einschraenkung'])
        w.writerows(out)
    print(len(out), 'Zeilen; STM32_GEBAUT=NEIN, HARDWARE_GEPRUEFT=NEIN in allen')
    if bad:
        print('Tests nicht im Log bestanden:', bad, file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
