#!/usr/bin/env python3
"""Offline-Probe von Route B mit dem ECHTEN Skripttext aus dem erzeugten Workflow (kein GitHub, kein Build): Reproduktion der 309 per git apply, 11 Pins, strikter 318-Installer, optional Vergleich mit einem erwarteten 318-Baum, plus zwei Negativfaelle.
Aufruf: dryrun_route_b_c8.py <route_b.yml> <OEM_BAUM_OHNE_GIT> <ORDNER_318_UEBERGABE_ENTPACKT> <ORDNER_C8_PAKET_ENTPACKT> [<ERWARTETER_318_BAUM>]   Exitcode 0 = alle Erwartungen erfuellt."""
import hashlib
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import yaml

yml, oem, c318, c8pkg = (Path(a) for a in sys.argv[1:5]); exp = Path(sys.argv[5]) if len(sys.argv) > 5 else None
steps = yaml.safe_load(yml.read_text())['jobs']['modified_318_c6']['steps']
get = lambda key: [s for s in steps if s.get('name', '').startswith(key)][0]['run']
repro, inst = get('Reproduce 309'), get('Apply 318 installer')
res = []


def fresh():
    w = Path(tempfile.mkdtemp()); (w / 'evidence').mkdir()
    shutil.copytree(oem, w / 'oem'); shutil.copytree(c318, w / 'c318'); shutil.copytree(c8pkg, w / 'c8pkg')
    for c in (['git', 'init', '-q'], ['git', 'config', 'user.email', 'a@b'], ['git', 'config', 'user.name', 'ci'], ['git', 'add', '-A'], ['git', 'commit', '-qm', 'base']): subprocess.run(c, cwd=w / 'oem', capture_output=True, check=True)
    return w


def sh(w, text): return subprocess.run(['bash', '-e', '-o', 'pipefail', '-c', text], cwd=w, capture_output=True, text=True)      # wie der Workflow-Schritt: set -euo pipefail


def tree(p): return {f.relative_to(p).as_posix(): hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*') if f.is_file() and '.git/' not in f.as_posix()}


w = fresh(); r = sh(w, repro); res.append(('1 Reproduktion der 309 per git apply + 11 Pins', r.returncode == 0 and r.stdout.count(': OK') == 12, f'exit={r.returncode}, OK-Zeilen: {r.stdout.count(": OK")} (11 Dateipins + Patch-Hash)'))
r2 = sh(w, inst); res.append(('2 strikter 318-Installer auf dem reproduzierten Baum', r2.returncode == 0 and 'STRICT_PRECHECK=OK' in r2.stdout and '318 SOURCE OVERLAY APPLIED' in r2.stdout, f'exit={r2.returncode}'))
if exp: a, b = tree(w / 'oem318'), tree(exp); res.append(('3 reproduzierter 318-Baum == erwarteter 318-Baum (byteweise)', a == b, f'Dateien {len(a)}/{len(b)}, abweichend {[k for k in a if k in b and a[k] != b[k]][:3]}, nur in einem {sorted(set(a) ^ set(b))[:3]}'))
w = fresh(); sh(w, repro); (w / 'oem/Marlin/src/lcd/e3v2/creality/sv04_claude_hooks.h').write_text((w / 'oem/Marlin/src/lcd/e3v2/creality/sv04_claude_hooks.h').read_text() + '// manipuliert\n')
pins = re.search(r"sha256sum -c - <<'ROUTE_B_PINS'.*", repro, re.S).group(0); r3 = sh(w, pins); res.append(('4 NEGATIV: manipulierte reproduzierte Datei -> Pinpruefung scheitert', r3.returncode != 0 and 'hooks.h: FAILED' in r3.stdout, f'exit={r3.returncode}'))
w = fresh(); bad = re.sub(r"(echo ')[0-9a-f]{64}(  c318/combined_308\.patch)", r"\g<1>" + '0' * 64 + r"\g<2>", repro); r4 = sh(w, bad); st = subprocess.run(['git', 'status', '--porcelain'], cwd=w / 'oem', capture_output=True, text=True).stdout
res.append(('5 NEGATIV: falscher Patch-Hash -> Abbruch ohne jede Aenderung', r4.returncode != 0 and st.strip() == '', f'exit={r4.returncode}, Aenderungen im Baum: {len(st.splitlines())}'))
w = fresh(); (w / 'c318/combined_308.patch').write_bytes((w / 'c318/combined_308.patch').read_bytes() + b'\n# manipuliert\n'); r5 = sh(w, repro); st = subprocess.run(['git', 'status', '--porcelain'], cwd=w / 'oem', capture_output=True, text=True).stdout
res.append(('6 NEGATIV: veraenderter Patch -> Hashpruefung scheitert, Baum unveraendert', r5.returncode != 0 and st.strip() == '', f'exit={r5.returncode}'))
for n, ok, d in res: print(('PASS ' if ok else 'FAIL ') + n + ' | ' + d)
print('DRYRUN_ROUTE_B=' + ('OK' if all(o for _, o, _ in res) else 'FAIL')); sys.exit(0 if all(o for _, o, _ in res) else 1)
