#!/usr/bin/env python3
"""Konfigurations- und Quellaudit IDEX / BLTouch / G28 gegen die ECHTE OEM-Konfiguration (Sovol-Revision 1867fcba..., 29 mitgelieferte Dateien). Gibt eine Faktentabelle MIT Zeilenbelegen aus.
FAIL (Exitcode 1): ein gepinnter Konfigurationswert oder eine Invariante weicht ab. FEHLENDE DATEI (Exitcode 2). WARN beeinflusst den Exitcode nicht (Hinweise, die der Nutzer/die Hardware klaeren muss).
Das Werkzeug beweist NICHTS ueber die Hardware (Parkabstaende, Wagenbreite, Kollisionsfreiheit, T1-Position): es liest nur die Konfiguration.
Aufruf: check_idex_bltouch_config_c1.py [OEM_Marlin_Verzeichnis]   (Standard: claude/01_BASELINE/OEM_FILES/Marlin)"""
import re
import sys
from pathlib import Path

DEFAULT = Path(__file__).resolve().parents[1] / '01_BASELINE' / 'OEM_FILES' / 'Marlin'
FILES = ('Configuration.h', 'Configuration_adv.h', 'src/module/motion.cpp')


def load(root):
    out = {}
    for f in FILES:
        p = root / f
        if not p.is_file():
            print('FEHLENDE DATEI:', p); return None
        out[f] = p.read_text(encoding='utf-8', errors='replace').split('\n')
    return out


def define(lines, name):
    """(Wert, Zeilennummer) der ersten AKTIVEN (nicht auskommentierten) #define; None wenn nur auskommentiert oder fehlt."""
    pat = re.compile(r'^\s*#\s*define\s+' + re.escape(name) + r'\b\s*(.*?)\s*(//.*)?$')
    for i, l in enumerate(lines, 1):
        m = pat.match(l)
        if m and not l.lstrip().startswith('//'):
            return m.group(1), i
    return None


def num(v, env):
    if v is None:
        return None
    v = re.sub(r'\s+', '', v)
    try:
        return float(eval(re.sub(r'[A-Z_][A-Z_0-9]*', lambda m: str(env.get(m.group(0), m.group(0))), v), {'__builtins__': {}}))
    except Exception:
        return None


def audit(files):
    c, a, m = files['Configuration.h'], files['Configuration_adv.h'], files['src/module/motion.cpp']
    rows, fails, warns = [], [], []
    env = {}

    def fact(file, lines, name, expect=None, as_num=True, note='', req=True):
        r = define(lines, name)
        val, ln = (r if r else (None, None))
        if as_num and val is not None:
            n = num(val, env); env[name] = n if n is not None else val
        shown = val if val is not None else 'NICHT DEFINIERT'
        if expect is None:
            ok = (val is not None) or not req                                   # Vorhandensein: ein FEHLENDES #define ist ein FAIL (ausser req=False)
        else:
            ok = val is not None and ((num(val, env) == expect) if isinstance(expect, (int, float)) else (re.sub(r'\s+', '', val) == re.sub(r'\s+', '', expect)))
        rows.append((file, ln, name, shown, 'ok' if ok else 'FAIL', note))
        if not ok:
            fails.append(f'{file}:{ln} {name} = {shown} (erwartet {expect})')
        return env.get(name)
    fact('Configuration.h', c, 'X_BED_SIZE', 302); fact('Configuration.h', c, 'Y_BED_SIZE', 302); fact('Configuration.h', c, 'X_MIN_POS', -62); fact('Configuration.h', c, 'X_MAX_POS', 302); fact('Configuration.h', c, 'Z_MAX_POS', 400)
    fact('Configuration.h', c, 'EXTRUDERS', 2); fact('Configuration.h', c, 'X_HOME_DIR', -1); fact('Configuration.h', c, 'Y_HOME_DIR', -1); fact('Configuration.h', c, 'Z_HOME_DIR', -1)
    fact('Configuration.h', c, 'BLTOUCH', None, False, 'BLTouch als Z-Sensor'); fact('Configuration.h', c, 'USE_PROBE_FOR_Z_HOMING', None, False, 'Z-Homing MIT Sonde'); fact('Configuration.h', c, 'Z_SAFE_HOMING', None, False)
    fact('Configuration.h', c, 'NOZZLE_TO_PROBE_OFFSET', '{ 0, 25, 0 }', False); fact('Configuration.h', c, 'Z_PROBE_END_SCRIPT', '"G28 XY"', False, 'Endskript der G29')
    fact('Configuration.h', c, 'HOMING_FEEDRATE_MM_M', '{ (50*60), (50*60), (4*60) }', False, 'Z 4 mm/s'); fact('Configuration.h', c, 'Z_CLEARANCE_DEPLOY_PROBE', 10)
    fact('Configuration_adv.h', a, 'DUAL_X_CARRIAGE', None, False); fact('Configuration_adv.h', a, 'X1_MIN_POS', None, False); fact('Configuration_adv.h', a, 'X1_MAX_POS', 302); fact('Configuration_adv.h', a, 'X2_MIN_POS', 0)
    fact('Configuration_adv.h', a, 'X2_MAX_POS', 362); fact('Configuration_adv.h', a, 'X2_HOME_DIR', 1); fact('Configuration_adv.h', a, 'X2_HOME_POS', 362)
    fact('Configuration_adv.h', a, 'DEFAULT_DUAL_X_CARRIAGE_MODE', 'DXC_AUTO_PARK_MODE', False)
    tz = fact('Configuration_adv.h', a, 'TOOLCHANGE_ZRAISE', None, True, 'WARN: 0 mm Anhebung beim Werkzeugwechsel (Block #if HAS_MULTI_EXTRUDER, gilt bei EXTRUDERS=2; Marlin-Standardwert)', req=False)
    if tz == 0:
        warns.append('TOOLCHANGE_ZRAISE = 0 (Marlin-Standardwert, Block #if HAS_MULTI_EXTRUDER): beim Werkzeugwechsel wird nicht angehoben; ob das mechanisch gewollt ist, ist NICHT belegbar (Hardwarefrage)')
    # abgeleitete Groessen (reine Rechnung aus der Konfiguration)
    clearance = env['X2_MAX_POS'] - env['X1_MAX_POS']
    rows.append(('abgeleitet', None, 'X2_MAX_POS - X1_MAX_POS (T0 am Maximum, T1 geparkt)', f'{clearance:g} mm', 'ok' if clearance == 60 else 'FAIL', 'Konfigurierter Abstand der Wagenanschlaege; die REALE Wagenbreite ist unbekannt'))
    if clearance != 60:
        fails.append(f'Abstand T0-Maximum/T1-Park {clearance} mm statt 60')
    ztravel = 1.5 * (env['Z_MAX_POS'] - 0)
    secs = ztravel / 4.0
    rows.append(('abgeleitet', None, '1,5 x max_length(Z) / 4 mm/s', f'{ztravel:g} mm, {secs:g} s', 'ok', 'Z-Homing mit Sonde fuer den Fall, dass der Trigger NIE kommt (motion.cpp:%s)' % next((i for i, l in enumerate(m, 1) if 'const float move_length = 1.5f * max_length' in l), '?')))
    warns.append(f'BLTouch ohne Trigger: das Z-Homing faehrt bis zu {ztravel:g} mm (ca. {secs:g} s bei 4 mm/s) ohne Schutz vor dem Ende der Strecke; softwareseitig nicht begrenzbar (Z-Position vor dem Homing unbekannt)')
    if define(c, 'PROBE_TRIGGERED_WHEN_STOWED_TEST') is None:
        warns.append('PROBE_TRIGGERED_WHEN_STOWED_TEST ist NICHT aktiv: ein dauerhaft ausgeloester Sensor im eingefahrenen Zustand wird nicht erkannt (Konfigurationsentscheidung, Hardwarepruefung noetig)')
    return rows, fails, warns


def main(argv):
    root = Path(argv[1]) if len(argv) > 1 else DEFAULT
    files = load(root)
    if files is None:
        return 2
    rows, fails, warns = audit(files)
    print('| Datei | Zeile | Name | Wert | Status | Hinweis |\n|---|---|---|---|---|---|')
    for f, ln, n, v, st, note in rows:
        print(f'| {f} | {ln if ln else "-"} | {n} | {v} | {st} | {note} |')
    for w in warns:
        print('WARN:', w)
    for f in fails:
        print('FAIL:', f)
    print('IDEX_BLTOUCH_CONFIG_AUDIT=' + ('FAIL' if fails else 'OK'), f'fails={len(fails)} warns={len(warns)}')
    return 1 if fails else 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
