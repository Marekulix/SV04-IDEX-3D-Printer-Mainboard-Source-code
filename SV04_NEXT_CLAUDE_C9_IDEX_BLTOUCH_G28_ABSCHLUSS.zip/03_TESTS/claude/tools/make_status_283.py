#!/usr/bin/env python3
"""Statusmatrix 283 (Punkt 5 M500 EEPROM, Punkt 6 EEPROM-Ruecklesung): eine Zeile je Arbeitsschritt 1-40 des Auftrags und je Abnahmebedingung mit den Kategorien
IMPLEMENTIERT / LOKAL GETESTET / STM32 GEBAUT / HARDWARE GEPRUEFT / BLOCKIERT. Jeder referenzierte Test wird gegen die ROHLOGS (06_EVIDENCE/host) geprueft; steht er dort nicht als bestanden, bricht das Skript
mit Exitcode 1 ab (kein Erfolg ohne Log). Aufruf (Paketwurzel): python3 claude/tools/make_status_283.py [--out DOCS]"""
import argparse
import csv
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PKG = ROOT.parent
H = ROOT / '06_EVIDENCE' / 'host'
S = {
    'inc': ROOT / '02_SOURCE/Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc', 'ee': ROOT / '02_SOURCE/Marlin/src/feature/sv04_claude_auto60/sv04_claude_eeprom_core.h',
    'core': ROOT / '02_SOURCE/Marlin/src/feature/sv04_claude_auto60/sv04_claude_auto60_core.h', 'tool': ROOT / '03_PATCHES/apply_claude_parallel.py', 'wf': ROOT / 'tools/make_workflow_283.py',
    'ana': PKG / 'docs/EEPROM_ANALYSE_283.md', 'hw': PKG / 'docs/HARDWARE_ABNAHME_283.md', 'rep': PKG / 'docs/ERGEBNISBERICHT_283.md', 'wfm': PKG / 'docs/GITHUB_UPLOAD_ANLEITUNG_283.md',
}


def ref(key, needle):
    p = S[key]
    for i, l in enumerate(p.read_text(encoding='utf-8').split('\n'), 1):
        if needle in l:
            return f'{p.name}:{i}'
    raise SystemExit(f'Quellstelle nicht gefunden: {p.name} :: {needle}')


def logs():
    cpp, ee, py = {}, {}, {}
    for f, d in (('01_core_tests_cpp.txt', cpp), ('01b_eeprom_core_tests_cpp.txt', ee)):
        for l in (H / f).read_text().splitlines():
            m = re.match(r'(PASS|FAIL) (\w+) ', l)
            if m:
                d[m.group(2)] = m.group(1)
    for f in ('02_unittest_host_core_pipeline.txt', '03_unittest_sim.txt'):
        lines = (H / f).read_text().splitlines()
        for i, l in enumerate(lines):
            m = re.match(r'(test_\w+) \(', l)
            if m:
                py[m.group(1)] = 'ok' if re.search(r'\.\.\. ok\b', ' '.join(lines[i:i + 3])) else 'NOT_OK'
    return cpp, ee, py


def P(*a): return ['py:' + x for x in a]
def C(*a): return ['C++:' + x for x in a]
def EE(*a): return ['EE:' + x for x in a]


ROWS = [
 # (nr, anforderung, impl, getestet, blockiert/offen, tests, [(key, needle)], einschraenkung)
 (1, 'Originale EEPROM-Speicherung des SV04 untersuchen', 'JA', 'NEIN', 'nur Quelltext-Analyse; kein Geraet', [], [('ana', 'Hardware und Treiber')], 'Belegt an den mitgelieferten OEM-Dateien (settings.cpp/.h, eeprom_bl24cxx.cpp, pins_CREALITY_V4.h); nichts am Geraet geprueft.'),
 (2, 'Alle relevanten Schreibfunktionen und Speicherbereiche ermitteln', 'JA', 'JA', 'Feldreihenfolge und CRC am echten Geraet unverifiziert', EE('EE05', 'EE06', 'EE10') + P('E15_'), [('ana', 'Speicherformat')], 'EEPROM 24C16 2 KB, Offset 100 (settings.cpp:40, dort nur lokal definiert), Version V85, 82-Byte-Meshfolge nach probe.offset + 36 Bytes Planar-Platzhalter.'),
 (3, 'M500-Speicherung mit der Auto60-Steuerung verbinden', 'JA', 'JA', 'STM32-Link', P('I01_', 'E18_', 'S01_') + C('J01'), [('inc', 'static bool sv04c_save(void *, uint32_t)'), ('core', 'void do_save()')], 'Auto60 ruft settings.save() (= M500) nur aus dem Zustand SAVE_PENDING auf (Test P07).'),
 (4, 'Neues Mesh ausschliesslich nach vollstaendig erfolgreicher Vermessung speichern', 'JA', 'JA', '-', P('E17_', 'E18_', 'I03_', 'I10_') + C('J01'), [('core', 'void do_save()')], 'do_save verlangt: gueltige Kette, Mesh/Z-Offset unveraendert, Nivellierung aktiv, Queue ruhig.'),
 (5, 'Keine EEPROM-Schreibvorgaenge bei abgebrochener oder fehlgeschlagener Messung', 'JA', 'JA', '-', P('E17_', 'I25_'), [('core', 'void do_save()')], '15 Fehler-/Abbruchfaelle: 0 geaenderte Bytes, auch kein Journal angelegt.'),
 (6, 'Fehlgeschlagene Speicheroperationen erkennen', 'JA', 'JA', '-', P('E04_', 'E05_', 'E07_', 'E08_') + EE('EE20', 'EE43'), [('inc', 'static bool sv04c_ee_wr('), ('inc', 'static bool sv04c_ee_commit(')], 'Marlins save() verwirft Schreibfehler (settings.h:129); sie werden indirekt ueber size_error erkannt und beim Kopf GAR nicht: die Rohlesung erkennt in jedem Fall.'),
 (7, 'Nachvollziehbare Erfolgskontrolle implementieren', 'JA', 'JA', '-', P('E18_', 'E12_'), [('inc', 'static bool sv04c_readback('), ('inc', 'static void sv04c_ee_report_status()')], 'M1060 S2 (Rohverifikation lesend) und S3 (Journal-Status, letzter Abschluss).'),
 (8, 'Unnoetige EEPROM-Schreibzyklen vermeiden', 'JA', 'JA', 'Verschleiss am Geraet nicht gemessen', P('E13_', 'E15_', 'E16_') + C('K01', 'K02') + EE('EE31'), [('core', 'save_skipped_ = true;')], 'Bitgleiches Mesh: kein Speichern. Der Treiber schreibt nur geaenderte Bytes; das Journal im Dauerbetrieb <= 6 Bytes.'),
 (9, 'Umgang mit beschaedigten oder unvollstaendigen EEPROM-Daten', 'JA', 'JA', '-', P('E09_', 'E10_', 'E11_', 'E12_') + EE('EE05', 'EE18', 'EE44'), [('inc', 'static bool sv04c_ee_start_ok()')], 'Ungueltiger, unterbrochener, fremder oder andersversionierter Block wird NIE automatisch ueberschrieben; leerer Block ist erlaubt.'),
 (10, 'Stromausfall waehrend des Schreibens: Auswirkung und mit der Hardware realisierbare Absicherung', 'JA', 'JA', 'Stromausfall am echten Geraet; datasize() des Ziel-Builds unbekannt (Journal braucht <= 962 Bytes); Anwender-M500 ungeschuetzt', P('E01_', 'E02_', 'E03_', 'E20_', 'E21_') + EE('EE40', 'EE41', 'EE42', 'EE43', 'EE46'), [('ee', 'inline Commit commit_transaction('), ('ee', 'inline BootResult recover_at_boot(')], 'Undo-Journal am EEPROM-Ende; Hauptblock nach jeder Abschaltung gueltig, genau alt oder neu. Am Geraet NICHT geprueft.'),
 (11, 'Zuverlaessige Ruecklesung der gespeicherten Meshdaten', 'JA', 'JA', '-', EE('EE10', 'EE11', 'EE13') + P('E18_'), [('ee', 'inline bool verify_mesh(')], 'Rohlesung ueber persistentStore; KEIN settings.load() (es schaltet die Nivellierung aus, settings.cpp:1676).'),
 (12, 'Alle 16 Messpunkte pruefen', 'JA', 'JA', '-', EE('EE11', 'EE14'), [('ee', 'r.z_equal = r.bad_mask == 0')], 'bad_mask: jeder der 16 Punkte einzeln; jedes einzelne gekippte Byte der 82 Mesh-Bytes wird erkannt.'),
 (13, 'Rasterabstaende und Startkoordinaten pruefen', 'JA', 'JA', '-', EE('EE10', 'EE16'), [('ee', 'bool vals = isfinite(sp[0])')], 'Raster/Start sind Teil des bitgleich verglichenen 82-Byte-Musters und werden auf endlich und > 0 geprueft.'),
 (14, 'Ungueltige Zahlenwerte erkennen', 'JA', 'JA', '-', EE('EE15'), [('ee', 'fabsf(v[i]) > abs_limit')], 'NaN, Inf und Werte ausserhalb der Betragsgrenze.'),
 (15, 'Gespeicherte Werte mit dem zuvor gemessenen Mesh vergleichen', 'JA', 'JA', '-', EE('EE10', 'EE11') + P('E18_', 'E06_'), [('inc', 'ev.mesh_equal = r.found')], 'Vergleich gegen das Messabbild (nicht gegen das RAM danach) und gegen den Rohblock.'),
 (16, 'Integritaetskontrolle fuer die tatsaechliche Speichertechnik', 'JA', 'JA', 'CRC-Verhalten am Geraet unverifiziert', EE('EE01', 'EE06', 'EE12', 'EE13') + P('E23_'), [('inc', 'static void sv04c_ee_crc(')], 'Marlins eigene CRC-16/XMODEM (crc16()) ueber die Rohbytes plus bitgleicher Mesh-Vergleich.'),
 (17, 'Fehlende, beschaedigte oder unvollstaendige Datensaetze erkennen', 'JA', 'JA', '-', EE('EE05', 'EE18', 'EE44') + P('E09_', 'E10_'), [('ee', 'enum PrimaryState')], 'Zustaende: unlesbar, leer, unterbrochen (ERR), fremd/andere Version, CRC falsch, gueltig.'),
 (18, 'Falsche Erfolgsmeldungen verhindern', 'JA', 'JA', '-', P('E04_', 'E06_', 'E22_', 'E23_') + EE('EE20', 'EE43') + C('J08', 'J09'), [('core', 'const bool good = ev.save_ok')], '12 Bedingungen muessen zugleich gelten; Mutationstests: EEPROM-Kern 17/17, Koordinator 11/11, Adapter 11/11 erkannt.'),
 (19, 'Ruecklesung darf andere Konfigurationen nicht veraendern', 'JA', 'JA', '-', C('J09') + P('E18_'), [('inc', 'ev.ram_unchanged = sv04c::mesh_same')], 'Die Rohlesung schreibt nie ins RAM; ram_unchanged ist eine Sicherung (Mutant AG01 beobachtungsgleich: durch Konstruktion nicht beobachtbar).'),
 (20, 'Wiederherstellung der gespeicherten Daten nach einem Neustart pruefen', 'JA', 'JA', 'Neustart am echten Geraet; Marlin-Boot-load() als Modell', P('E01_', 'E03_', 'E12_'), [('inc', 'static void sv04c_ee_report_verify()')], 'Zwei-Phasen-Test (Abschalten, dann Neustart mit dem Abbild): RAM-Mesh == EEPROM-Mesh; M1060 S2 beweist es am Geraet.'),
 (21, 'EEPROM-Funktionen mit der Auto60-Ablaufsteuerung verbinden', 'JA', 'JA', 'STM32-Link', P('I01_', 'E18_') + C('J01', 'J10'), [('inc', 'p.eeprom_prepare = sv04c_ee_prepare')], 'Ports eeprom_prepare / eeprom_commit / eeprom_unchanged / eeprom_readback im Koordinator.'),
 (22, 'Reihenfolge: 60 C, Homing, G29 (16 Punkte), Meshpruefung, Leveling, speichern, zuruecklesen, verifizieren', 'JA', 'JA', 'Zeitverhalten im echten idle()', P('E18_', 'I01_', 'S01_', 'S01b_'), [('core', 'void do_verify()')], 'Der Test E18 beweist: settings.save vor der Pruefung, kein settings.load, Nivellierung danach AN.'),
 (23, 'Rueckmeldungen zwischen Marlin, Auto60 und DWIN', 'JA', 'JA', 'DWIN am Geraet', P('I01_', 'S01_', 'E18_'), [('inc', 'static void sv04c_display(')], 'Erfolgsseite nur im Zustand SUCCESS, Fehlerseite sonst; Zellrahmen/Seiten laufen ueber die echte RTS_SndData.'),
 (24, 'Fehler und Abbrueche verhindern einen EEPROM-Schreibvorgang', 'JA', 'JA', '-', P('E17_', 'I25_', 'I14_', 'I20_'), [('core', 'void do_save()')], 'Abbruch nach dem ersten save() ist nicht mehr moeglich (Block waere sonst ungueltig).'),
 (25, 'Bisheriges Mesh bei fehlgeschlagener Vermessung nicht ueberschreiben', 'JA', 'JA', '-', P('E17_', 'E04_', 'E06_', 'E07_'), [('inc', 'static bool sv04c_ee_commit(')], 'Ausfall nach dem Speichern: alter Block wird bytegleich zurueckgespielt (EEMAINEQ=1).'),
 (26, 'Beeinflusst das G29-Endskript G28 XY den Speicherablauf?', 'JA', 'JA', 'Bewegung am Geraet', P('I10_', 'I11_', 'I26_'), [('core', 'R_G29_ENDSCRIPT_FAILED')], 'Befund (277): das Endskript ist ein echter G28 XY innerhalb jeder G29. Es laeuft VOR Validierung und Speichern; scheitert er, entsteht kein EEPROM-Schreibzugriff.'),
 (27, 'Fehler nach der Messung, aber vor dem Speichern erkennen', 'JA', 'JA', '-', P('I10_', 'I26_', 'E17_') + C('J01'), [('core', 'void do_save()')], 'Validierung, Aktivierung und Vorbedingungen vor save().'),
 (28, 'Fehler nach dem Speichern, insbesondere bei der Ruecklesung, korrekt behandeln', 'JA', 'JA', '-', P('E04_', 'E05_', 'E06_', 'E07_', 'E08_', 'E22_', 'E23_', 'S33_', 'S34_', 'S37_') + C('J10'), [('core', 'const bool consistent = finish_eeprom(false);')], 'Nur bei NACHGEWIESENER Konsistenz bleibt die Ursache erhalten; sonst EEPROM_RECOVERY_REQUIRED.'),
 (29, 'M420 S1 nach erfolgreicher Ruecklesung mit den gueltigen gespeicherten Daten', 'TEILWEISE', 'TEILWEISE', 'M420 S1 nach Neustart nur am Geraet; M420.cpp (V4-/V5-/V6-Haelfte) nur ueber ChatGPTs Tests und Ihren 282-Lauf', P('E18_', 'E01_', 'S01c_', 'BL01_', 'BL04_', 'BL09_'), [('inc', 'static bool sv04c_m420(')], 'In der Sitzung bleibt die Nivellierung AN. Fuer Bilinear wird das Flag NICHT gespeichert (settings.cpp:833): nach dem Neustart ist sie aus bis M420 S1 (OEM-Verhalten); die Daten dafuer sind verifiziert.'),
 (30, 'DWIN zeigt Erfolg erst nach bestaetigter Speicherung und Ruecklesung', 'JA', 'JA', 'DWIN am Geraet', P('E18_', 'S01_', 'E17_') + C('J01'), [('inc', 'case sv04c::D_RESULT:')], 'Der Koordinator erreicht SUCCESS erst nach finish_eeprom(true); die Erfolgsseite wird nur dann gesendet.'),
 (31, 'Alle Aenderungen in den vollstaendigen gemeinsamen Firmwarequellcode integrieren', 'JA', 'TEILWEISE', 'vollstaendiger OEM-Baum/STM32-Compile nur im Workflow', P('O01_', 'O02_', 'B10_', 'B11_'), [('tool', 'NEW_FILES')], 'apply_277.py/integrate_281.py bringen die 6 Claude-Dateien samt EEPROM-Kern in den OEM-Baum; der volle Baum wird erst in 283.yml gebaut (NOT RUN).'),
 (32, 'Alle neuen C++-Funktionen pruefen', 'JA', 'JA', 'Zielcompiler', EE('EE01', 'EE46') + C('K01') + P('X01_', 'X02_', 'X05_', 'K02_'), [('ee', 'namespace ee')], 'Streng uebersetzt (-Wall -Wextra -Werror -pedantic) und in 16 Konfigurationen des Adapters; keine Heap-/Exception-/RTTI-/STL-Nutzung.'),
 (33, 'Positive und negative Funktionstests erstellen', 'JA', 'JA', '-', P('E01_', 'E09_', 'E17_', 'E18_', 'E22_', 'E23_'), [('ana', 'Beleg der Absicherung')], '33 EEPROM-Kerntests, 17 Koordinatortests (J/K), 23 Ende-zu-Ende-Tests.'),
 (34, 'Beschaedigte EEPROM-Daten testen', 'JA', 'JA', '-', P('E09_', 'E10_', 'E11_', 'E12_') + EE('EE05', 'EE13', 'EE14', 'EE44'), [('ana', 'Beleg der Absicherung')], 'Jedes einzelne Byte des Blocks gekippt: nie ein Erfolg (EE13/EE14).'),
 (35, 'Unterbrochene Schreibvorgaenge testen (softwareseitig simulierbar)', 'JA', 'JA', 'Zeitfenster am Geraet', P('E01_', 'E02_', 'E04_', 'E07_') + EE('EE40', 'EE42', 'EE43'), [('ana', 'Beleg der Absicherung')], 'Kern: 882 Abschaltpunkte, 1094 verschachtelte Abschaltungen, 887 Schreibfehlerpositionen; Ende-zu-Ende ca. 38 Punkte plus verschachtelte.'),
 (36, 'Abbruch und Wiederholung von Auto60 testen', 'JA', 'JA', '-', P('E17_', 'E08_', 'E13_', 'I19_', 'I20_', 'I21_', 'I22_') + C('J11', 'K04'), [('core', 'void cancel()')], 'Zweiter Lauf: frisches Journal, commit wieder genau einmal; bitgleiches Mesh wird nicht erneut geschrieben.'),
 (37, 'Schnittstellen zu G28, G29 und M420 pruefen', 'JA', 'TEILWEISE', 'M420.cpp (V4-/V5-/V6-Haelfte) am echten Baum nur ueber Ihren 282-Lauf; STM32-Link', P('I01_', 'I10_', 'I11_', 'I26_', 'G01_', 'BL02_', 'BL03_', 'BL06_', 'BL08_'), [('core', 'R_G29_ENDSCRIPT_FAILED')], 'G28/G29 mit der ECHTEN G28.cpp/G29.cpp; seit der Gesamtintegration (284) auch mit den ECHTEN bedlevel-Funktionen nach M420 V2 + V4 (BL-Tests; fand und behob einen Notstopp-Fehler im Rollback). M420 V4-V6 (M420.cpp): ChatGPTs eigene Tests; Auto60 ruft set_bed_leveling_enabled direkt (nicht M420).'),
 (38, 'STM32-Firmware mit aktiviertem Auto60-Backend bauen', 'JA', 'NEIN', 'KEIN Build moeglich: keine ARM-Toolchain, kein PlatformIO, kein Netz', P('B10_', 'B11_', 'B13_', 'B14_'), [('wf', 'integrated_backend')], '283.yml vorbereitet (aus dem bewaehrten 282.yml, 5 Zeilen Abweichung). NOT RUN.'),
 (39, 'STM32-Firmware mit deaktiviertem Backend bauen', 'JA', 'NEIN', 'KEIN Build moeglich (siehe 38)', P('B10_', 'B13_'), [('wf', 'integrated_failclosed')], 'Profil -DSV04_CLAUDE_HOME_BACKEND_AVAILABLE=0; die kosmetischen Warnungen aus 282 sind behoben (Host).'),
 (40, 'Compiler- und Integrationsfehler selbst beheben und Tests wiederholen', 'TEILWEISE', 'JA', 'Compilerfehler des ZIELCOMPILERS koennen erst nach dem GitHub-Lauf behoben werden', P('X02_', 'E09_') + EE('EE44', 'EE46'), [('ana', 'Befunde')], 'Auf dem Host gefundene Fehler (V84-Version, Endlosschleife, falsche Konsistenzbehauptung, Testluecken) sind behoben und mit Tests abgesichert.'),
]
HARD = [
 ('A1', 'Zwei erfolgreiche STM32-Builds (Backend an/aus)', 'NEIN', 'NEIN', 'KEIN STM32-BUILD durchgefuehrt', [], 'NICHT erfuellt. Vorbereitet: 283.yml.'),
 ('A2', 'Vollstaendige, reproduzierbare Integration', 'JA', 'TEILWEISE', 'Zielbuild', P('O01_', 'O02_', 'B11_', 'B12_'), 'Host-Pipeline reproduzierbar (echte Patchskripte, Manifest, ZIP); der volle OEM-Compile steht aus.'),
 ('A3', 'Z-Offset wird nie durch die automatische Vermessung geaendert', 'JA', 'JA', 'Geraet', P('E18_', 'E22_', 'I25_') + C('E03'), 'Vor dem Speichern und im gespeicherten Block geprueft.'),
 ('A4', 'Speichern gilt nie allein deshalb als erfolgreich, weil der Befehl aufgerufen wurde', 'JA', 'JA', '-', P('E04_', 'E06_', 'E22_', 'E23_') + EE('EE20'), 'Erfolg = Rohlesung des Blocks bitgleich zum Messabbild, CRC ok, Z-Offset ok.'),
 ('A5', 'Vergleich mit RAM-Daten ersetzt keine unabhaengige Pruefung der dauerhaften Speicherung', 'JA', 'JA', '-', P('E18_') + C('J09'), 'Die Rohlesung geht ueber persistentStore, nicht ueber das RAM.'),
 ('A6', 'Hardwaretests ohne Drucker klar als offen dokumentiert', 'JA', 'NEIN', 'Hardwarepruefung NICHT durchgefuehrt', [], 'docs/HARDWARE_ABNAHME_283.md (Plan).'),
 ('A7', 'Version 282 bleibt unveraendert', 'JA', 'JA', '-', P('O05_'), 'ChatGPTs Skripte byte-identisch (O05); Aenderungen nur an Claudes Dateien; 282.yml.referenz liegt unveraendert bei.'),
 ('A8', 'Keine Aenderung der Prozentanzeige ohne belegte Integration', 'JA', 'NEIN', 'Zielbuild und Hardwarebeleg fehlen', [], 'Unveraendert: 55 / 52 / 43 / 55 / 55 / 25.'),
]


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default=str(PKG / 'docs'))
    a = ap.parse_args(argv)
    cpp, ee, py = logs()
    out, bad = [], []

    def check(tests):
        res = []
        for t in tests:
            kind, name = t.split(':', 1)
            if kind == 'C++':
                ok = cpp.get(name) == 'PASS'
            elif kind == 'EE':
                ok = ee.get(name) == 'PASS'
            else:
                hits = [k for k in py if k.startswith('test_' + name)]
                ok = bool(hits) and all(py[k] == 'ok' for k in hits)
            res.append((t, ok))
        return res

    for n, req, impl, tested, blocked, tests, refs, note in ROWS:
        fail = [t for t, ok in check(tests) if not ok]
        if fail:
            bad.append((n, fail))
        files = '; '.join(ref(k, nd) for k, nd in refs)
        out.append([n, req, impl, 'FEHLER (Test nicht im Log bestanden)' if fail else tested, 'NEIN', 'NEIN', blocked, files, ' | '.join(tests) or '-', note])
    for n, req, impl, tested, blocked, tests, note in HARD:
        fail = [t for t, ok in check(tests) if not ok]
        if fail:
            bad.append((n, fail))
        out.append([n, req, impl, 'FEHLER (Test nicht im Log bestanden)' if fail else tested, 'NEIN', 'NEIN', blocked, '-', ' | '.join(tests) or '-', note])
    outdir = Path(a.out)
    outdir.mkdir(parents=True, exist_ok=True)
    with open(outdir / 'STATUS_283.csv', 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['nr', 'anforderung', 'IMPLEMENTIERT', 'LOKAL_GETESTET', 'STM32_GEBAUT', 'HARDWARE_GEPRUEFT', 'BLOCKIERT_oder_offen', 'dateien_zeilen', 'tests', 'einschraenkung'])
        w.writerows(out)
    print(len(out), 'Zeilen; STM32_GEBAUT=NEIN, HARDWARE_GEPRUEFT=NEIN in allen')
    if bad:
        print('Tests nicht im Log bestanden:', bad, file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
