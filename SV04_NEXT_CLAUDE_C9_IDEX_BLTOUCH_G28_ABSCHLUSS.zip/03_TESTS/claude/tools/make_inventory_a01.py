#!/usr/bin/env python3
"""A01 Quelleninventar: sucht jede genannte Stelle in den ECHTEN OEM-Dateien (01_BASELINE/OEM_FILES) und schreibt Datei:Zeile. Fehlt eine Stelle, bricht das Skript ab (keine erfundenen APIs).
Aufruf: make_inventory_a01.py [--root ../01_BASELINE] [--out ../07_AUDIT/A01_QUELLENINVENTAR.md]"""
import argparse
import json
import sys
from pathlib import Path

M = 'Marlin/src/'
ITEMS = [  # (Bereich, Datei relativ zu OEM_FILES, Suchtext, Bedeutung)
 ('G29', M + 'gcode/bedlevel/abl/G29.cpp', 'tool_change(0)', 'bei aktivem T1 wird auf T0 gewechselt (IDEX)'),
 ('G29', M + 'gcode/bedlevel/abl/G29.cpp', 'if (homing_needed_error()) G29_RETURN(false);', 'G29 verlangt vorheriges Homing (sonst sofortiger Rueckkehr)'),
 ('G29', M + 'gcode/bedlevel/abl/G29.cpp', 'abl.reenable = planner.leveling_active;', 'Nivellierungszustand vor dem Lauf'),
 ('G29', M + 'gcode/bedlevel/abl/G29.cpp', 'z_values[abl.meshCount.x][abl.meshCount.y] = z;', 'Messwert wird WAEHREND der Messung ins RAM-Mesh geschrieben (kein Rollback im OEM)'),
 ('G29', M + 'gcode/bedlevel/abl/G29.cpp', 'rtscheck.RTS_SndData(z*1000', 'OEM sendet jeden Messpunkt live an das DWIN (x1000)'),
 ('G29', M + 'gcode/bedlevel/abl/G29.cpp', 'planner.leveling_active = !abl.dryrun || abl.reenable;', 'BEFUND: G29 schaltet die Nivellierung am Ende SELBST ein (vor jeder Validierung)'),
 ('G29', M + 'gcode/bedlevel/abl/G29.cpp', 'process_subcommands_now_P(PSTR(Z_PROBE_END_SCRIPT));', 'BEFUND: Endskript wird ausgefuehrt (laut Configuration.h "G28 XY")'),
 ('G29', M + 'gcode/bedlevel/abl/G29.cpp', 'RTS_AutoBedLevelPage();', 'OEM-Seitenwechsel am G29-Ende (auch nach Fehlschlag, wenn waitway==3)'),
 ('G29', M + 'gcode/bedlevel/abl/G29.cpp', 'G29_RETURN(isnan(abl.measured_z));', 'Rueckgabe am Ende'),
 ('Konfiguration', 'Marlin/Configuration.h', '#define MOTHERBOARD BOARD_CREALITY_V4', 'BEFUND: Platine laut Konfiguration BOARD_CREALITY_V4 (Auftrag nennt V5.2.1)'),
 ('Konfiguration', 'Marlin/Configuration.h', '#define EEPROM_SETTINGS', 'EEPROM-Einstellungen aktiv'),
 ('Konfiguration', 'Marlin/Configuration.h', '#define Z_PROBE_END_SCRIPT', 'Endskript nach der Messung'),
 ('Konfiguration', 'Marlin/Configuration.h', '#define AUTO_BED_LEVELING_BILINEAR', 'Bilinear-Mesh aktiv'),
 ('Konfiguration', 'Marlin/Configuration.h', '#define BLTOUCH', 'BLTouch (nicht Teil dieses Auftrags: ChatGPT)'),
 ('Konfiguration', 'Marlin/Configuration_adv.h', '#define DUAL_X_CARRIAGE', 'IDEX (nicht Teil dieses Auftrags: ChatGPT)'),
 ('EEPROM', M + 'pins/stm32f1/pins_CREALITY_V4.h', '#define IIC_BL24CXX_EEPROM', 'BEFUND: aktiver Speicher = I2C-EEPROM 24C16'),
 ('EEPROM', M + 'pins/stm32f1/pins_CREALITY_V4.h', '#define MARLIN_EEPROM_SIZE             0x800', 'EEPROM-Groesse 2 KB'),
 ('EEPROM', M + 'HAL/STM32F1/eeprom_bl24cxx.cpp', 'bool PersistentStore::access_finish() { return true; }', 'kein gepuffertes Schreiben: jedes Byte wird sofort geschrieben'),
 ('EEPROM', M + 'HAL/STM32F1/eeprom_bl24cxx.cpp', 'if (v != eeprom_read_byte(p))', 'nur geaenderte Bytes werden geschrieben'),
 ('EEPROM', M + 'HAL/STM32F1/eeprom_bl24cxx.cpp', 'if (eeprom_read_byte(p) != v) {', 'Rueckpruefung je Byte im Schreibpfad (nicht unabhaengig vom Schreibpfad)'),
 ('EEPROM', M + 'module/settings.cpp', '#define EEPROM_VERSION "V85"', 'Versionskennung'),
 ('EEPROM', M + 'module/settings.cpp', '#define EEPROM_OFFSET 100', 'Offset des Abbilds'),
 ('EEPROM', M + 'module/settings.cpp', 'bool MarlinSettings::save() {', 'save() (= was M500 aufruft; M500.cpp liegt nicht vor)'),
 ('EEPROM', M + 'module/settings.cpp', 'char ver[4] = "ERR";', 'BEFUND: Platzhalter-Version "ERR" wird zuerst geschrieben'),
 ('EEPROM', M + 'module/settings.cpp', 'EEPROM_WRITE(version);', 'echte Version erst am ENDE (Commit-Marker)'),
 ('EEPROM', M + 'module/settings.cpp', 'EEPROM_WRITE(final_crc);', 'CRC erst am ENDE'),
 ('EEPROM', M + 'module/settings.cpp', 'bool MarlinSettings::validate() {', 'validate(): liest + prueft CRC/Version, uebernimmt nichts (validating=true)'),
 ('EEPROM', M + 'module/settings.cpp', 'bool MarlinSettings::load() {', 'load(): validate(), sonst reset() auf Standardwerte'),
 ('EEPROM', M + 'module/settings.h', 'static bool save();', 'oeffentliche API'),
 ('EEPROM', M + 'module/settings.h', 'static bool validate();', 'oeffentliche API'),
 ('EEPROM', M + 'module/settings.h', 'static bool load();', 'oeffentliche API'),
 ('EEPROM', M + 'module/settings.h', 'static uint16_t datasize();', 'oeffentliche API'),
 ('Temperatur', M + 'module/temperature.h', 'static bed_info_t temp_bed;', 'Bett: temp_bed.celsius / .target'),
 ('Zustand', M + 'module/motion.h', 'inline bool axis_is_trusted(const AxisEnum axis)', 'Achs-Vertrauen (read-only genutzt)'),
 ('Zustand', M + 'module/motion.h', 'extern bool extruder_duplication_enabled;', 'IDEX-Duplizierung (read-only genutzt)'),
 ('Zustand', M + 'module/motion.h', 'enum DualXMode : char {', 'IDEX-Modi (read-only genutzt)'),
 ('Zustand', M + 'module/planner.h', 'static bool leveling_active;', 'Nivellierung aktiv'),
 ('Zustand', M + 'gcode/queue.h', 'static bool has_commands_queued()', 'Queue-Zustand'),
 ('Zustand', M + 'gcode/queue.h', 'static void enqueue_now_P(PGM_P const cmd);', 'Befehl einstellen (G29)'),
 ('Dispatch', M + 'gcode/gcode.cpp', 'case 420: M420(); break;', 'M420 (M420.cpp liegt nicht vor)'),
 ('Dispatch', M + 'gcode/gcode.cpp', 'case 500: M500(); break;', 'M500 (M500.cpp liegt nicht vor)'),
 ('Dispatch', M + 'gcode/gcode.cpp', 'case 501: M501(); break;', 'M501 = Ladepfad'),
 ('Dispatch', M + 'gcode/gcode.cpp', 'case 504: M504(); break;', 'M504 = Validierung'),
 ('Dispatch', M + 'gcode/gcode.cpp', 'case 190: M190(); break;', 'M190 (M190_M109.cpp liegt nicht vor)'),
 ('Dispatch', M + 'gcode/gcode.cpp', 'case 1004: M1004(); break;', 'hoechste belegte M-Nummer vor 7219: M1060 ist frei (M1000/1001/1002/1004 belegt)'),
 ('DWIN', M + 'lcd/e3v2/creality/LCD_RTS.h', '#define AUTO_BED_LEVEL_1POINT_VP           0x1100', 'Basis der 16 Mesh-Zellen'),
 ('DWIN', M + 'lcd/e3v2/creality/LCD_RTS.h', '#define AUTO_BED_LEVEL_ICON_VP             0x108D', 'Fortschritts-Icon'),
 ('DWIN', M + 'lcd/e3v2/creality/LCD_RTS.h', 'ChangePageKey', 'Empfangsschluessel (VP 0x110E, kollidiert mit Mesh-Zelle k=7)'),
 ('DWIN', M + 'lcd/e3v2/creality/LCD_RTS.cpp', 'void RTSUpdate()', 'Hauptschleifen-Tick (Aufrufstelle in MarlinCore.cpp: NICHT verifizierbar)'),
 ('DWIN', M + 'lcd/e3v2/creality/LCD_RTS.cpp', 'void RTSSHOW::RTS_HandleData()', 'Touch-Auswertung (waitway-Sperre am Anfang)'),
 ('DWIN', M + 'lcd/e3v2/creality/LCD_RTS.cpp', 'void RTS_AutoBedLevelPage()', 'Seitenwechsel nach G29'),
 ('DWIN', M + 'lcd/e3v2/creality/LCD_RTS.cpp', 'queue.enqueue_now_P(PSTR("M420 S1"));', 'OEM-M420 S1 (Menue/Boot; unveraendert)'),
 ('DWIN', M + 'lcd/e3v2/creality/LCD_RTS.cpp', 'settings.save()', 'OEM-Menue ruft settings.save() an mehreren Stellen (waehrend Auto60 per Touch-Sperre blockiert)'),
 ('Mesh', M + 'feature/bedlevel/abl/abl.cpp', 'float bilinear_z_offset(', 'Interpolation (keine NaN-Behandlung)'),
 ('Mesh', M + 'feature/bedlevel/bedlevel.h', 'bool leveling_is_valid();', 'Meshgueltigkeit'),
 ('Mesh', M + 'feature/bedlevel/bedlevel.h', 'void set_bed_leveling_enabled(', 'Nivellierung ein/aus'),
]
MISSING_SOURCES = [
 ('M420.cpp / M500-M504.cpp / M190_M109.cpp', 'nicht in den Uploads: M420 S1, M500, M501, M504 sind nur ueber gcode.cpp-Dispatch und settings.h belegt; das Verhalten stammt aus der oeffentlichen settings-API, nicht aus ihrem Quelltext'),
 ('MarlinCore.cpp', 'nicht in den Uploads: Aufrufstelle von RTSUpdate() und die Reihenfolge von idle() nicht verifizierbar'),
 ('temperature.cpp (Regelung/Thermal Protection)', 'als Datei vorhanden, hier nur read-only; Heizungsfehler-Fahnen sind nicht oeffentlich abfragbar (kill() bei Fehler)'),
 ('HAL/STM32F1/eeprom_if_iic.cpp, I2C-Treiber', 'Hardware-nahe Bitebene nicht Teil der Uploads'),
 ('ini/*.ini (Definition von env:STM32F103RET6_creality)', 'nicht in den Uploads; nur default_envs in platformio.ini'),
 ('HMI-Binaerdateien 14ShowFile.bin / 13TouchFile.bin', 'nicht in den Uploads'),
]


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root', default=str(Path(__file__).resolve().parents[1] / '01_BASELINE'))
    ap.add_argument('--out')
    a = ap.parse_args(argv)
    root = Path(a.root)
    man = json.loads((root / 'BASELINE_MANIFEST.json').read_text())
    rows, bad = [], []
    for area, rel, needle, meaning in ITEMS:
        f = root / 'OEM_FILES' / rel
        if not f.is_file():
            bad.append((rel, 'Datei fehlt'))
            continue
        lines = f.read_text(encoding='utf-8', errors='replace').split('\n')
        hits = [i + 1 for i, l in enumerate(lines) if needle in l]
        if not hits:
            bad.append((rel, needle))
            continue
        rows.append((area, rel, hits[0], len(hits), needle, meaning))
    if bad:
        print('FEHLENDE FUNDSTELLEN:', *bad, sep='\n  ', file=sys.stderr)
        return 3
    o = ['# A01 Quelleninventar (maschinell erzeugt; jede Zeilennummer stammt aus der echten Datei)', '',
         f"Original-Commit laut Auftrag: `{(root / 'ORIGINAL_COMMIT.txt').read_text().splitlines()[0]}`. Die Dateien stammen aus Ihrem frueheren CI-Lauf (Repo-Stand `840143cd...`); die Bindung an den Commit ist ohne Netz NICHT beweisbar.",
         'Git-Blobs, die der CI-Lauf erwartet hat und die uebereinstimmen: ' + ', '.join(sorted(Path(r).name for r, v in man['dateien'].items() if v.get('blob_verified_by_ci'))) + '. Alle anderen Dateien sind nur STRONG (kein erwarteter Blob).', '',
         '| Bereich | Datei | Zeile | Treffer | Suchtext | Bedeutung |', '|---|---|---|---|---|---|']
    for area, rel, line, n, needle, meaning in rows:
        o.append(f"| {area} | `{rel.replace('Marlin/src/', '')}` | {line} | {n} | `{needle.replace('|', '/')}` | {meaning} |")
    o += ['', '## NICHT vorhanden (daher nur eingeschraenkt inventarisierbar)', ''] + [f'- **{n}**: {w}' for n, w in MISSING_SOURCES]
    o += ['', '## Gesperrt (ChatGPT Punkt 1; Claude liest nur)', '', '- `Marlin/src/gcode/calibrate/G28.cpp`, `Marlin/src/module/motion.cpp`, `Marlin/src/module/motion.h`: werden von den 275-Patchskripten geaendert (apply_268/272/274/275). Dieses Paket aendert sie NICHT.']
    text = '\n'.join(o) + '\n'
    if a.out:
        Path(a.out).write_text(text, encoding='utf-8')
    print(f'{len(rows)} Fundstellen verifiziert')
    return 0


if __name__ == '__main__':
    sys.exit(main())
