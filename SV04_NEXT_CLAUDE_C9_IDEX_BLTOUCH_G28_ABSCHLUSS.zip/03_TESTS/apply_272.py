#!/usr/bin/env python3
"""Fix 271's incorrect T1 home coordinate comparison, without touching OEM itself.
Patch source is the post-268 G28.cpp derived from pinned Sovol OEM commit.
"""
from pathlib import Path
import argparse, hashlib
BEFORE = '(fabsf(inactive_extruder_x - X2_HOME_POS) <= 1.0f)'
AFTER = '(fabsf(inactive_extruder_x - x_home_pos(1)) <= 1.0f)'
EXPECTED_OCCURRENCES = 2

def correct(text):
    if text.count(BEFORE) != EXPECTED_OCCURRENCES:
        raise ValueError('Expected exactly two original 271 T1 guard comparisons')
    if AFTER in text:
        raise ValueError('already patched')
    if 'SV04_NEXT_P1_268' not in text:
        raise ValueError('271 patch missing')
    return text.replace(BEFORE, AFTER)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('source',type=Path)
    ap.add_argument('--out',type=Path,required=True)
    a=ap.parse_args()
    if a.source.resolve() == a.out.resolve():
        ap.error('Refusing in-place mutation')
    content=correct(a.source.read_text(encoding='utf-8'))
    a.out.write_text(content,encoding='utf-8',newline='')
    print('P1_272_HOME_REFERENCE_FIXED comparisons=2 NO_FLASH')
if __name__ == '__main__':
    main()
