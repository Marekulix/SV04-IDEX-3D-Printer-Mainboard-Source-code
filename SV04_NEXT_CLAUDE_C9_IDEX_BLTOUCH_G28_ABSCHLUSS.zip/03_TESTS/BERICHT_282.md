# SV04 NEXT 282 – Fix GitHub 281 V6 integration installer

Evidence: both 281 profiles exited before PlatformIO due to
`CONFLICT midrange: expected one anchor, found 0` in `m420/apply_m420_v6.py`.

Cause: The installer and test fixture assumed 10 leading spaces before
`// Get the midrange ...`; the Sovol OEM file has 12. The guard deliberately
failed closed and no STM32 compilation was performed in run 281.

Fix: Correct the OEM V6 anchor and the host test fixture to 12 spaces. Add
`m420/test_oem_v6_anchor_282.py` for an isolated regression reproducing the
exact OEM snippet, with idempotence verification. No changes to Claude 277
firmware files, G28, Auto60, or underlying V6 centering logic.

281 remains unchanged. 282 reruns the two profiles and saves all logs.
NO FLASH. Hardware checks are not performed.
