#!/usr/bin/env python3
"""Static inspection of OEM IDEX modes; fail if expected controls disappeared.
Not a simulation or hardware validation.
"""
import pathlib,sys
root=pathlib.Path(sys.argv[1]);
m=(root/'Marlin/src/module/motion.h').read_text()
t=(root/'Marlin/src/module/tool_change.cpp').read_text()
g=(root/'Marlin/src/gcode/calibrate/G28.cpp').read_text()
p=(root/'Marlin/src/feature/bltouch.cpp').read_text()
checks={
 'full_control': 'DXC_FULL_CONTROL_MODE' in m and 'DXC_FULL_CONTROL_MODE' in t,
 'auto_park': 'DXC_AUTO_PARK_MODE' in m and 'DXC_AUTO_PARK_MODE' in t,
 'duplication': 'DXC_DUPLICATION_MODE' in m and 'DXC_DUPLICATION_MODE' in t,
 'mirror': 'DXC_MIRRORED_MODE' in m and 'DXC_MIRRORED_MODE' in t,
 'g28_preserves_mode': 'IDEX_saved_mode' in g and 'dual_x_carriage_mode = IDEX_saved_mode' in g,
 'bltouch_alarm_paths': 'BLTouch Recovery Failed' in p and 'bool BLTouch::deploy_proc()' in p,
 'no_success_on_failed_z': 'sv04_p1_z_failed' in g and 'homing NOT complete' in g,
 'z_completion': 'sv04_p1_z_completed' in g,
}
for k,v in checks.items():print(('PASS' if v else 'FAIL'),k)
print('STATIC_AUDIT_PASS=',sum(checks.values()),'/',len(checks))
if not all(checks.values()):sys.exit(1)
