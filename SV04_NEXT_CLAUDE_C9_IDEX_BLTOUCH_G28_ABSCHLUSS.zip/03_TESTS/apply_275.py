#!/usr/bin/env python3
'''P1 275: Suppress false G28 success signals on rejected BLTouch Z homing.
Applies after the pinned OEM -> 268 -> 272 -> 274 patch lineage.
Does not attest physical endstop position or permit flashing.
'''
from pathlib import Path
import argparse

def once(src, before, after, title):
    n=src.count(before)
    if n!=1: raise ValueError('%s: expected one anchor, got %d'%(title,n))
    return src.replace(before,after,1)

def patch(src):
    if 'SV04_NEXT_P1_268' not in src or 'sv04_p1_z_completed' not in src:
        raise ValueError('Need 274 patch lineage')
    src=once(src,
'''      bool sv04_t1_homed_this_g28 = false;
      sv04_p1_t1_x_completed = false;''',
'''      bool sv04_t1_homed_this_g28 = false;
      bool sv04_p1_z_failed = false;
      sv04_p1_t1_x_completed = false;''','G28 local failure flag')
    src=once(src,
'''          if (sv04_z_homed) probe.move_z_after_homing();''',
'''          if (sv04_z_homed) probe.move_z_after_homing();
          #if ENABLED(DUAL_X_CARRIAGE) && ENABLED(BLTOUCH)
            else sv04_p1_z_failed = true;
          #endif''','Z failed feedback')
    src=once(src,
'''  TERN_(RTS_AVAILABLE, RTS_MoveAxisHoming());
  TERN_(EXTENSIBLE_UI, ExtUI::onHomingComplete());''',
'''  // SV04_NEXT_P1_275: do not claim success to the display after Z refusal.
  #if ENABLED(DUAL_X_CARRIAGE) && ENABLED(BLTOUCH) && ENABLED(Z_SAFE_HOMING)
    if (sv04_p1_z_failed) {
      SERIAL_ERROR_MSG("SV04 P1 275: G28 Z failed; homing NOT complete");
      LCD_MESSAGEPGM(MSG_ZPROBE_OUT);
    }
    else {
      TERN_(RTS_AVAILABLE, RTS_MoveAxisHoming());
      TERN_(EXTENSIBLE_UI, ExtUI::onHomingComplete());
    }
  #else
    TERN_(RTS_AVAILABLE, RTS_MoveAxisHoming());
    TERN_(EXTENSIBLE_UI, ExtUI::onHomingComplete());
  #endif''','UI success on failure')
    return src

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('path',type=Path);a=ap.parse_args()
    p=a.path; old=p.read_text();new=patch(old);p.write_text(new,newline=''); print('P1_275_REPORTING_GUARD_APPLIED FLASH=NO')
if __name__=='__main__':main()
