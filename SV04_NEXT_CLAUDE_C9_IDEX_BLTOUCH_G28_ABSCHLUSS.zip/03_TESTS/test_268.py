import unittest
from apply_268 import *

OEM_FIXTURE='''#if ENABLED(Z_SAFE_HOMING)
'''+OLD_HELPER+'''
    // OEM writes position after the guard
    current_position_x1_axis = X2_MAX_POS;
'''+OLD_END+'''
#endif
void GcodeSuite::G28() {
'''+OLD_TOP+'''
    if (doX) {
'''+OLD_HOME_X+'''
    }
    if (doZ) {
'''+OLD_CALL+'''
    }
}
'''
class PatchTests(unittest.TestCase):
    def setUp(self): self.result=patch(OEM_FIXTURE)
    def test_all_anchors_apply(self): self.assertIn(MARK,self.result)
    def test_no_duplicate(self):
        with self.assertRaises(ValueError): patch(self.result)
    def test_fail_if_missing_anchor(self):
        with self.assertRaises(ValueError): patch(OEM_FIXTURE.replace(OLD_CALL,''))
    def test_fail_if_duplicate_anchor(self):
        with self.assertRaises(ValueError): patch(OEM_FIXTURE+OLD_CALL)
    def test_guard_before_position_reset(self):
        self.assertLess(self.result.index('if (!sv04_t1_gate)'),self.result.index('current_position_x1_axis = X2_MAX_POS'))
    def test_this_g28_local(self):
        self.assertIn('bool sv04_t1_homed_this_g28 = false;',self.result)
    def test_t1_event_tracking(self):
        self.assertLess(self.result.index('sv04_t1_homed_this_g28 = axis_is_trusted(X_AXIS)'),self.result.index('// Home the 1st (left) extruder'))
    def test_z_only_fail_closed(self): self.assertIn('sv04_t1_homed_this_g28\n        && active_extruder == 0',self.result)
    def test_tool_t0_required(self): self.assertIn('active_extruder == 0',self.result)
    def test_duplication_blocked(self): self.assertIn('!idex_is_duplicating()',self.result)
    def test_x_trust_required(self): self.assertIn('&& axis_is_trusted(X_AXIS)',self.result)
    def test_position_tolerance(self): self.assertIn('fabsf(inactive_extruder_x - X2_HOME_POS) <= 1.0f',self.result)
    def test_z_success_check(self): self.assertIn('return axis_is_trusted(Z_AXIS);',self.result)
    def test_reject_skips_post_probe_move(self): self.assertIn('if (sv04_z_homed) probe.move_z_after_homing();',self.result)
    def test_no_eeprom_change(self): self.assertNotIn('settings.save',self.result)
    def test_non_safe_z_path_preserved(self): self.assertIn('#else\n          homeaxis(Z_AXIS);\n          probe.move_z_after_homing();',self.result)

if __name__ == '__main__': unittest.main(verbosity=2)
