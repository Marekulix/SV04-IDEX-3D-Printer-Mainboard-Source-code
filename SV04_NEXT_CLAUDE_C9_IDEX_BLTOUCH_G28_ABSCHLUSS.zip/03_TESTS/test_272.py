import unittest
from apply_272 import correct, BEFORE, AFTER
from apply_268 import patch as patch271

class T1HomePositionTests(unittest.TestCase):
    def setUp(self):
        self.original='SV04_NEXT_P1_268\n' + BEFORE+'\n'+ BEFORE
    def test_two_occurrences_updated(self):
        v=correct(self.original)
        self.assertEqual(v.count(AFTER),2)
        self.assertNotIn(BEFORE,v)
    def test_wrong_count_rejected(self):
        with self.assertRaises(ValueError): correct('SV04_NEXT_P1_268\n'+BEFORE)
    def test_duplicate_patch_rejected(self):
        with self.assertRaises(ValueError): correct(correct(self.original))
    def test_requires_prior_271(self):
        with self.assertRaises(ValueError): correct(BEFORE+'\n'+BEFORE)
    def test_runtime_override_case(self):
        x2_home_pos=362.0
        configured_t1_home=188.0
        actual_position=188.0
        self.assertFalse(abs(actual_position-x2_home_pos)<=1.0)
        self.assertTrue(abs(actual_position-configured_t1_home)<=1.0)
    def test_nominal_home_case(self):
        self.assertTrue(abs(362.0-362.0)<=1.0)
    def test_far_from_runtime_home_is_rejected(self):
        self.assertFalse(abs(340.0-188.0)<=1.0)
    def test_signed_offset_is_respected(self):
        self.assertFalse(abs(362.0-188.0)<=1.0)

if __name__=='__main__': unittest.main()
