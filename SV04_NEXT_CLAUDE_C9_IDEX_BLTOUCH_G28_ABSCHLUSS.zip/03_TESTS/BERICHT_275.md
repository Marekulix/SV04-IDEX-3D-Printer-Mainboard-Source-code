# SV04 NEXT 275 – gebündelter Punkt-1-Angriff
Ausgang: GitHub 274 vollständiger STM32-Build SUCCESS; RAM 14,1 %, Flash 29,4 %, 34/34 Hosttests.
Neu: G28 zeigt nach verweigertem sicherem Z-Homing keine RTS/ExtUI-Erfolgsmeldung mehr an. Ein separater statischer Audit prüft die vier IDEX-Moduspfade und BLTouch-Alarmbehandlung. Ein einzelner Build beweist nicht deren korrekte Laufzeitfunktion.
Risiken/offen: T1-Position nur durch Firmwarezustand, Endstop-Funktionsfehler nicht physisch ausgeschlossen, Homingabbruch kann andere nachgelagerte G28-Aktionen auslösen. Hardwareprüfung und alle echten Fehler-Injektionstests fehlen. Kein Flashen.
