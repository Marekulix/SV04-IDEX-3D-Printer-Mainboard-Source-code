#!/usr/bin/env python3
"""Apply a single conflict-sensitive OEM patch to Marlin bedlevel.cpp.
Does not alter any other source, EEPROM values, G28, G29, or DWIN.
"""
from pathlib import Path
import argparse

OLD='''bool leveling_is_valid() {
  return TERN1(MESH_BED_LEVELING,          mbl.has_mesh())
      && TERN1(AUTO_BED_LEVELING_BILINEAR, !!bilinear_grid_spacing.x)
      && TERN1(AUTO_BED_LEVELING_UBL,      ubl.mesh_is_valid());
}'''
NEW='''bool leveling_is_valid() {
  #if ENABLED(AUTO_BED_LEVELING_BILINEAR)
    // M420 S1 must not activate a partly measured or damaged mesh.
    // Checking only spacing.x allows NaN/Inf mesh points to slip through.
    // Keep this side-effect-free: no mesh mutation, EEPROM write, or motion.
    if (!__builtin_isfinite(bilinear_start.x)
        || !__builtin_isfinite(bilinear_start.y)
        || !__builtin_isfinite(bilinear_grid_spacing.x)
        || !__builtin_isfinite(bilinear_grid_spacing.y)
        || bilinear_grid_spacing.x <= 0 || bilinear_grid_spacing.y <= 0)
      return false;

    // A finite origin and spacing can still overflow at the far mesh edge.
    // Reject invalid geometry before it can reach M420 S1 or the planner.
    if (!__builtin_isfinite(bilinear_start.x + (GRID_MAX_POINTS_X - 1) * bilinear_grid_spacing.x)
        || !__builtin_isfinite(bilinear_start.y + (GRID_MAX_POINTS_Y - 1) * bilinear_grid_spacing.y))
      return false;

    GRID_LOOP(x, y)
      if (!__builtin_isfinite(z_values[x][y])) return false;
  #endif
  return TERN1(MESH_BED_LEVELING, mbl.has_mesh())
      && TERN1(AUTO_BED_LEVELING_UBL, ubl.mesh_is_valid());
}'''

V1='''bool leveling_is_valid() {
  #if ENABLED(AUTO_BED_LEVELING_BILINEAR)
    // M420 S1 must not activate a partly measured or damaged mesh.
    // Checking only spacing.x allows NaN/Inf mesh points to slip through.
    // Keep this side-effect-free: no mesh mutation, EEPROM write, or motion.
    if (!__builtin_isfinite(bilinear_start.x)
        || !__builtin_isfinite(bilinear_start.y)
        || !__builtin_isfinite(bilinear_grid_spacing.x)
        || !__builtin_isfinite(bilinear_grid_spacing.y)
        || bilinear_grid_spacing.x <= 0 || bilinear_grid_spacing.y <= 0)
      return false;

    GRID_LOOP(x, y)
      if (!__builtin_isfinite(z_values[x][y])) return false;
  #endif
  return TERN1(MESH_BED_LEVELING, mbl.has_mesh())
      && TERN1(AUTO_BED_LEVELING_UBL, ubl.mesh_is_valid());
}'''

def apply(root):
    p=root/'Marlin/src/feature/bedlevel/bedlevel.cpp'
    text=p.read_text(encoding='utf8')
    if text.count(NEW)==1: print('ALREADY_APPLIED',p); return
    if text.count(V1)==1:
        p.write_text(text.replace(V1, NEW),encoding='utf8')
        print('UPGRADED_V1_TO_V2',p); return
    if text.count(OLD)!=1:
        raise SystemExit('CONFLICT: expected OEM implementation missing; do not overwrite Claude modifications')
    p.write_text(text.replace(OLD,NEW),encoding='utf8')
    print('PATCHED',p)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('firmware_root',type=Path)
    apply(ap.parse_args().firmware_root)
