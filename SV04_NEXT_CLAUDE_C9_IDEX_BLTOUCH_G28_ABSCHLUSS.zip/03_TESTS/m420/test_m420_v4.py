#!/usr/bin/env python3
import tempfile, subprocess, pathlib, importlib.util, shutil
root=pathlib.Path(__file__).parent
spec=importlib.util.spec_from_file_location('a',root/'apply_m420_v4.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)

M420='''#include "../../inc/MarlinConfig.h"
void GcodeSuite::M420() {
  xyz_pos_t oldpos = current_position;

  // If disabling leveling do it right away
}'''
BED='''#define DEBUG_OUT ENABLED(DEBUG_LEVELING_FEATURE)
void set_bed_leveling_enabled(const bool enable/*=true*/) {
  const bool can_change = TERN1(AUTO_BED_LEVELING_BILINEAR, !enable || leveling_is_valid());
}'''

with tempfile.TemporaryDirectory() as td:
 p=pathlib.Path(td); (p/'Marlin/src/gcode/bedlevel').mkdir(parents=True); (p/'Marlin/src/feature/bedlevel').mkdir(parents=True)
 mp=p/'Marlin/src/gcode/bedlevel/M420.cpp'; bp=p/'Marlin/src/feature/bedlevel/bedlevel.cpp'
 mp.write_text(M420);bp.write_text(BED)
 a.apply(p)
 m=mp.read_text();b=bp.read_text()
 assert 'planner.leveling_active = false' not in m
 assert 'kill(PSTR("Invalid active mesh"), nullptr, true);' in m and 'kill(PSTR("Invalid active mesh"), nullptr, true);' in b
 a.apply(p);assert mp.read_text()==m and bp.read_text()==b
 # A known V3 input must be upgraded, not stacked on top
 mp.write_text(m.replace(a.V4,a.V3).replace(a.M420_INCLUDE_REPLACE,a.M420_INCLUDE_ANCHOR))
 a.apply(p);assert mp.read_text()==m
 # conflict prevents either file from being rewritten
 mp.write_text(m.replace(a.V4,'// modified unknown V4\n'+a.V4.replace('kill(', 'kill_bad(',1)))
 oldb=bp.read_text()
 try: a.apply(p)
 except RuntimeError: pass
 else: raise AssertionError('conflict not detected')
 assert bp.read_text()==oldb
 print('PASS 5 patch upgrade/idempotency/conflict checks')

# Compile actual extracted V4 guard AND actual extracted shared-setter guard.
start=a.V4[a.V4.index('#if ENABLED'):]
setter=a.SETTER_REPLACEMENT[a.SETTER_REPLACEMENT.index('#if ENABLED'):a.SETTER_REPLACEMENT.index('  const bool can_change')]
cpp='''#include <cassert>
#include <cstdio>
#include <stdexcept>
#define ENABLED(v) 1
#define AUTO_BED_LEVELING_BILINEAR 1
#define PSTR(x) x
struct Planner { bool leveling_active=false; } planner;
static bool valid_mesh=true;
static int errors=0,kills=0,transforms=0,writes=0,moves=0;
static bool leveling_is_valid(){return valid_mesh;}
static void SERIAL_ERROR_MSG(const char *){++errors;}
static void kill(const char *, decltype(nullptr), bool steppers_off){assert(steppers_off);++kills;throw std::runtime_error("HALTED");}
static void run_m420(bool to_enable){
''' + start + '''
  ++transforms;
}
static void run_setter(){
''' + setter + '''
  ++transforms;
}
int main(){
  int scenarios=0;
  for(int which=0;which<2;++which)
    for(int old=0;old<2;++old)
      for(int mesh=0;mesh<2;++mesh)
        for(int to_enable=0;to_enable<2;++to_enable){
          planner.leveling_active=old;valid_mesh=mesh;
          errors=kills=transforms=moves=writes=0;
          bool halted=false;
          try { if(which==0)run_m420(to_enable); else run_setter(); }
          catch(const std::runtime_error&){halted=true;}
          if(old && !mesh){ assert(halted && kills==1 && transforms==0 && planner.leveling_active); }
          else if(which==0 && !old && to_enable && !mesh){assert(!halted && kills==0 && transforms==0 && errors==1);}
          else {assert(!halted && kills==0 && transforms==1);}
          assert(writes==0 && moves==0);++scenarios;
        }
  printf("PASS %d actual extracted guard scenarios\\n",scenarios);
}
'''
with tempfile.TemporaryDirectory() as td:
 src=pathlib.Path(td)/'test.cpp';exe=pathlib.Path(td)/'test';src.write_text(cpp)
 subprocess.run(['g++','-std=c++11','-Wall','-Wextra','-Werror',str(src),'-o',str(exe)],check=True)
 subprocess.run([str(exe)],check=True)
