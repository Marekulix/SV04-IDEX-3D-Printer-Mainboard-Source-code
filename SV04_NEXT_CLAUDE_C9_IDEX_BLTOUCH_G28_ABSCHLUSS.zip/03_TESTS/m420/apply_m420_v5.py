#!/usr/bin/env python3
"""SV04 NEXT M420 V5: reject non-finite / negative fade before any M420 state change.
Compatible with exactly OEM M420.cpp or the V4 guard from apply_m420_v4.py.
Does not touch Claude's G28/G29/Auto60 files. Fail on any unknown modification.
"""
from pathlib import Path
import argparse

ANCHOR='  xyz_pos_t oldpos = current_position;'
GUARD='''  // SV04 NEXT V5: validate Z fade before the S0/S1, C or fade path can
  // mutate any leveling state. A corrupted fade can poison planner math.
  #if ENABLED(ENABLE_LEVELING_FADE_HEIGHT)
    const bool sv04_fade_requested = parser.seen('Z');
    const float sv04_requested_fade = sv04_fade_requested ? parser.value_linear_units() : 0.0f;
    if (sv04_fade_requested && (!__builtin_isfinite(sv04_requested_fade) || sv04_requested_fade < 0.0f)) {
      SERIAL_ERROR_MSG("M420: invalid Z fade height; no changes applied.");
      return;
    }
  #endif
'''
OLD_SETTER="    if (parser.seen('Z')) set_z_fade_height(parser.value_linear_units(), false);"
NEW_SETTER="    if (sv04_fade_requested) set_z_fade_height(sv04_requested_fade, false);"

def apply(root):
    path=Path(root)/'Marlin/src/gcode/bedlevel/M420.cpp'
    s=path.read_text(encoding='utf-8')
    if s.count(GUARD)==1 and s.count(NEW_SETTER)==1:
        print('ALREADY_APPLIED',path);return
    if 'SV04 NEXT V5' in s or 'sv04_requested_fade' in s:
        raise RuntimeError('CONFLICT: unrecognized partial V5 patch')
    if s.count(ANCHOR)!=1 or s.count(OLD_SETTER)!=1:
        raise RuntimeError('CONFLICT: M420 source differs from supported OEM/V4')
    if 'SV04 NEXT V4' not in s:
        raise RuntimeError('CONFLICT: V4 guard not present; install V2 and V4 before V5')
    ns=s.replace(ANCHOR,GUARD+'\n'+ANCHOR,1).replace(OLD_SETTER,NEW_SETTER,1)
    assert ns.count('sv04_requested_fade')==4
    path.write_text(ns,encoding='utf-8')
    print('APPLIED M420 V5',path)

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('firmware_root',type=Path);apply(a.parse_args().firmware_root)
