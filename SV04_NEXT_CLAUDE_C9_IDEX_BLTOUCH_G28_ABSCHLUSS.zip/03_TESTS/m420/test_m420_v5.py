#!/usr/bin/env python3
"""C++ execution of exact V5 guard, plus OEM/V4/V5 patch compatibility tests."""
import pathlib, tempfile, subprocess, importlib.util
root=pathlib.Path(__file__).resolve().parent

def get(name):
    s=importlib.util.spec_from_file_location(name,root/(name+'.py'))
    m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
v2=get('apply_m420_guard_v2');v4=get('apply_m420_v4');v5=get('apply_m420_v5')
# In-memory OEM snippets preserve exact anchors. v4/v5 guard implementations, not independent rewrites.
M='''#include "../../inc/MarlinConfig.h"
void GcodeSuite::M420() {
  xyz_pos_t oldpos = current_position;

  // If disabling leveling do it right away
  #if ENABLED(ENABLE_LEVELING_FADE_HEIGHT)
    if (parser.seen('Z')) set_z_fade_height(parser.value_linear_units(), false);
  #endif
}'''
B='''#define DEBUG_OUT ENABLED(DEBUG_LEVELING_FEATURE)
void set_bed_leveling_enabled(const bool enable/*=true*/) {
  const bool can_change = TERN1(AUTO_BED_LEVELING_BILINEAR, !enable || leveling_is_valid());
}'''
L=v2.OLD+'\n'+B
with tempfile.TemporaryDirectory() as td:
    p=pathlib.Path(td)
    mp=p/'Marlin/src/gcode/bedlevel/M420.cpp';bp=p/'Marlin/src/feature/bedlevel/bedlevel.cpp'
    mp.parent.mkdir(parents=True);bp.parent.mkdir(parents=True)
    mp.write_text(M);bp.write_text(L)
    v2.apply(p);v4.apply(p);v5.apply(p)
    m=mp.read_text(); b=bp.read_text()
    assert v5.GUARD in m and v5.NEW_SETTER in m
    v2.apply(p);v4.apply(p);v5.apply(p)
    assert mp.read_text()==m and bp.read_text()==b
    # A corruption of an expected anchor must fail and leave source untouched
    bad=m.replace(v5.NEW_SETTER, '    set_z_fade_height(999, false);')
    mp.write_text(bad)
    try: v5.apply(p)
    except RuntimeError: pass
    else: raise AssertionError('partial-patch conflict not detected')
    assert mp.read_text()==bad
    print('PASS integration: OEM->V2->V4->V5 + idempotency + conflict')

# C++ executable contains exact production guard, tests actual control flow
cpp='''#include <cassert>
#include <cmath>
#include <limits>
#include <cstdio>
#define ENABLED(x) 1
#define ENABLE_LEVELING_FADE_HEIGHT 1
static bool request=false;
static float value=0.0f;
static int errors=0, calls=0, changes=0;
struct FakeParser { bool seen(char c) { assert(c=='Z'); return request; } float value_linear_units(){++calls;return value;} } parser;
static void SERIAL_ERROR_MSG(const char*) {++errors;}
static void set_z_fade_height(float v, bool do_report){assert(!do_report);assert(std::isfinite(v)); ++changes;}
static void execute() {
'''+v5.GUARD+'''
  #if ENABLED(ENABLE_LEVELING_FADE_HEIGHT)
'''+v5.NEW_SETTER+'''
  #endif
}
int main() {
  const float v[]={0.0f,0.1f,10.0f,-0.1f,-1.0f,std::numeric_limits<float>::quiet_NaN(),std::numeric_limits<float>::infinity(),-std::numeric_limits<float>::infinity(),3.4e38f};
  int tests=0;
  for(int i=0;i<9;++i) for(int r=0;r<2;++r) {
    request=r;value=v[i];errors=calls=changes=0;execute();
    bool valid=(value>=0 && std::isfinite(value));
    assert(errors==(r&&!valid));
    assert(changes==(r&&valid));
    assert(calls==r);
    ++tests;
  }
  std::printf("PASS %d executed M420 Z-fade guard scenarios\\n",tests);
}
'''
with tempfile.TemporaryDirectory() as td:
    s=pathlib.Path(td)/'test.cpp'; exe=pathlib.Path(td)/'test';s.write_text(cpp)
    subprocess.run(['g++','-std=c++11','-Wall','-Wextra','-Werror',str(s),'-o',str(exe)],check=True)
    subprocess.run([str(exe)],check=True)
