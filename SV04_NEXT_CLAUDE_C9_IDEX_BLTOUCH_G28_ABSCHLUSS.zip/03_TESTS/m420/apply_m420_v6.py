#!/usr/bin/env python3
"""SV04 NEXT 282: OEM-accurate V6 anchors; preflight M420 C normalization, no partial mesh modification.
Requires V2/V4/V5, touches only Marlin/src/gcode/bedlevel/M420.cpp.
"""
from pathlib import Path
import argparse

OLD_EXTREMA = '            float lo_val = 100, hi_val = -100;'
NEW_EXTREMA = '''            // SV04 NEXT V6: initialize from a real mesh point, not an assumed\n            // +/-100 mm range. This also handles meshes outside that range.\n            float lo_val = Z_VALUES(0, 0), hi_val = Z_VALUES(0, 0);'''.replace('\\n','\n')

OLD = '''            // Get the midrange plus C value. (The median may be better.)
            const float zmean = (lo_val + hi_val) / 2.0 + cval;'''
NEW = '''          // SV04 NEXT V6: use double for the intermediate average. The
          // original float addition can overflow for otherwise finite data.
          const double zmean = (double(lo_val) + double(hi_val)) * 0.5 + double(cval);'''

OLD_MUTATION = '''          // If not very close to 0, adjust the mesh
          if (!NEAR_ZERO(zmean)) {
            set_bed_leveling_enabled(false);
            // Subtract the mean from all values
            GRID_LOOP(x, y) {
              Z_VALUES(x, y) -= zmean;
              TERN_(EXTENSIBLE_UI, ExtUI::onMeshUpdate(x, y, Z_VALUES(x, y)));
            }
            TERN_(ABL_BILINEAR_SUBDIVISION, bed_level_virt_interpolate());
          }'''
NEW_MUTATION = '''          // SV04 NEXT V6: reject the ENTIRE C operation before any changes
          // when a result is non-finite or outside the representable range
          // of a float. Do not leave a partly updated 4x4 grid.
          // Both branches of M420_C_USE_MEAN use zmean here.
          bool sv04_center_valid = __builtin_isfinite(cval) && __builtin_isfinite(zmean);
          if (sv04_center_valid) {
            GRID_LOOP(x, y) {
              const double next = double(Z_VALUES(x, y)) - double(zmean);
              if (!__builtin_isfinite(next) || next > double(FLT_MAX) || next < -double(FLT_MAX))
                sv04_center_valid = false;
            }
          }
          if (!sv04_center_valid) {
            SERIAL_ERROR_MSG("M420 C: invalid centering result; mesh unchanged.");
            return;
          }
          if (!NEAR_ZERO(zmean)) {
            set_bed_leveling_enabled(false);
            // All the results passed preflight, so apply them atomically
            // with respect to validation (no early exit within this loop).
            GRID_LOOP(x, y) {
              Z_VALUES(x, y) = float(double(Z_VALUES(x, y)) - double(zmean));
              TERN_(EXTENSIBLE_UI, ExtUI::onMeshUpdate(x, y, Z_VALUES(x, y)));
            }
            TERN_(ABL_BILINEAR_SUBDIVISION, bed_level_virt_interpolate());
          }'''
INCLUDE_ANCHOR = '#include "../../inc/MarlinConfig.h"'
INCLUDE_NEW = '#include "../../inc/MarlinConfig.h"\n#include <float.h>  // SV04 NEXT V6: range-check prospective mesh values'

def replace_once(s,old,new,where):
    if s.count(new)==1:return s
    if s.count(old)!=1:raise RuntimeError(f'CONFLICT {where}: expected one anchor, found {s.count(old)}')
    return s.replace(old,new,1)

def apply(root):
    p=Path(root)/'Marlin/src/gcode/bedlevel/M420.cpp'
    s=p.read_text(encoding='utf8')
    if 'SV04 NEXT V5:' not in s or 'SV04 NEXT V4:' not in s:
        raise RuntimeError('CONFLICT: V4/V5 not present')
    if 'SV04 NEXT V6' in s and (s.count(NEW_MUTATION)!=1 or s.count(NEW)!=1 or s.count(NEW_EXTREMA)!=1):
        raise RuntimeError('CONFLICT: partial or different V6 patch')
    n=replace_once(s,OLD_EXTREMA,NEW_EXTREMA,'extrema')
    n=replace_once(n,OLD,NEW,'midrange')
    n=replace_once(n,OLD_MUTATION,NEW_MUTATION,'centering')
    n=replace_once(n,INCLUDE_ANCHOR,INCLUDE_NEW,'float include')
    if n!=s:p.write_text(n,encoding='utf8')
    print('APPLIED V6' if n!=s else 'ALREADY APPLIED V6',p)

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('root',type=Path);apply(a.parse_args().root)
