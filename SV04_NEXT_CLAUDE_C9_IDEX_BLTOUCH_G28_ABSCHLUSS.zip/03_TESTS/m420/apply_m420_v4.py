#!/usr/bin/env python3
"""SV04 NEXT V4: fail-closed mesh validation. OEM/previous V3 -> V4.
No modifications to Claude-owned G28, G29, DWIN, or EEPROM code.
"""
from pathlib import Path
import argparse

V3 = '''  // SV04 NEXT: fail closed when the bilinear mesh becomes invalid.
  // Reject S1 before any Z fade or centering operation can mutate state.
  // This also detects a stale active flag after RAM mesh corruption.
  #if ENABLED(AUTO_BED_LEVELING_BILINEAR)
    if ((to_enable || planner.leveling_active) && !leveling_is_valid()) {
      if (planner.leveling_active) {
        // Don't run coordinate corrections through an invalid mesh.
        // No motion and no EEPROM writes. Require G28 before moving again.
        planner.leveling_active = false;
        SERIAL_ERROR_MSG("M420: invalid active mesh; leveling disabled. Re-home before motion.");
      }
      else
        SERIAL_ERROR_MSG("M420: invalid mesh; leveling not enabled.");
      return;
    }
  #endif'''

V4 = '''  // SV04 NEXT V4: validate before ANY state changes (including S0, C, Z).
  // Never flip planner.leveling_active directly: disabling active leveling
  // requires coordinate transforms which are unsafe with corrupted mesh data.
  #if ENABLED(AUTO_BED_LEVELING_BILINEAR)
    if ((to_enable || planner.leveling_active) && !leveling_is_valid()) {
      if (planner.leveling_active) {
        SERIAL_ERROR_MSG("M420: active leveling mesh invalid; emergency halt.");
        kill(PSTR("Invalid active mesh"), nullptr, true);
      }
      else
        SERIAL_ERROR_MSG("M420: invalid mesh; leveling not enabled.");
      return;
    }
  #endif'''

M420_ANCHOR = '''  xyz_pos_t oldpos = current_position;

  // If disabling leveling do it right away'''

SETTER_ANCHOR = '''  const bool can_change = TERN1(AUTO_BED_LEVELING_BILINEAR, !enable || leveling_is_valid());'''
SETTER_REPLACEMENT = '''  // SV04 NEXT V4: this public setter is used by G28/G29 and other callers.
  // An invalid ACTIVE mesh must not enter apply_leveling(), which assumes
  // valid interpolation data. An emergency halt is safer than silently
  // changing the planner flag without correcting current_position.
  #if ENABLED(AUTO_BED_LEVELING_BILINEAR)
    if (planner.leveling_active && !leveling_is_valid()) {
      SERIAL_ERROR_MSG("Leveling: active mesh invalid; emergency halt.");
      kill(PSTR("Invalid active mesh"), nullptr, true);
      return;
    }
  #endif

  const bool can_change = TERN1(AUTO_BED_LEVELING_BILINEAR, !enable || leveling_is_valid());'''

# bedlevel.cpp already includes its own Marlin headers; insert direct declaration.
CORE_ANCHOR = '''#define DEBUG_OUT ENABLED(DEBUG_LEVELING_FEATURE)'''
CORE_REPLACEMENT = '''#include "../../MarlinCore.h"  // SV04 NEXT V4: emergency stop on corrupt active mesh

#define DEBUG_OUT ENABLED(DEBUG_LEVELING_FEATURE)'''
M420_INCLUDE_ANCHOR = '#include "../../inc/MarlinConfig.h"'
M420_INCLUDE_REPLACE = '''#include "../../inc/MarlinConfig.h"
#include "../../MarlinCore.h"  // SV04 NEXT V4: kill on invalid active mesh'''


def replace_once(s, old, new, where):
    if s.count(new) == 1:
        return s
    if s.count(old) != 1:
        raise RuntimeError(f'CONFLICT: expected exactly one source block in {where} (found {s.count(old)})')
    return s.replace(old, new, 1)

def apply(root):
    a = root / 'Marlin/src/gcode/bedlevel/M420.cpp'
    b = root / 'Marlin/src/feature/bedlevel/bedlevel.cpp'
    ms = a.read_text(encoding='utf-8')
    bs = b.read_text(encoding='utf-8')
    if 'SV04 NEXT V4:' in ms and ms.count(V4) != 1:
        raise RuntimeError('CONFLICT: unknown modified V4 M420')
    if 'SV04 NEXT V4:' in bs and bs.count(SETTER_REPLACEMENT) != 1:
        raise RuntimeError('CONFLICT: unknown modified V4 setter')
    if ms.count(V3)==1:
        ms=replace_once(ms,V3,V4,'M420 V3')
    elif ms.count(V4)!=1:
        if 'SV04 NEXT: fail closed' in ms:
            raise RuntimeError('CONFLICT: unknown earlier M420 guard')
        ms=replace_once(ms,M420_ANCHOR,V4+'\n\n'+M420_ANCHOR,'M420 OEM')
    ms=replace_once(ms,M420_INCLUDE_ANCHOR,M420_INCLUDE_REPLACE,'M420 include')
    bs=replace_once(bs,SETTER_ANCHOR,SETTER_REPLACEMENT,'bedlevel setter')
    bs=replace_once(bs,CORE_ANCHOR,CORE_REPLACEMENT,'bedlevel include')
    # atomic-ish two-phase validation: no writes until every anchor is checked
    if ms!=a.read_text(encoding='utf-8'):
        a.write_text(ms,encoding='utf-8')
    if bs!=b.read_text(encoding='utf-8'):
        b.write_text(bs,encoding='utf-8')
    print('APPLIED V4 (or already current):',a,b)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('firmware_root',type=Path)
    apply(p.parse_args().firmware_root)
