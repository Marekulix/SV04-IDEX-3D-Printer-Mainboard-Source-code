#!/usr/bin/env python3
# Regression reproducing exact OEM line indentation in M420.cpp.
# Source-fragment fixture, not an entire firmware build.
import importlib.util, tempfile
from pathlib import Path
spec=importlib.util.spec_from_file_location('patch',Path(__file__).with_name('apply_m420_v6.py'))
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
actual_oem_fragment="""            float lo_val = 100, hi_val = -100;
            GRID_LOOP(x, y) {
              const float z = Z_VALUES(x, y);
              NOMORE(lo_val, z);
              NOLESS(hi_val, z);
            }
            // Get the midrange plus C value. (The median may be better.)
            const float zmean = (lo_val + hi_val) / 2.0 + cval;

          #endif

          // If not very close to 0, adjust the mesh
          if (!NEAR_ZERO(zmean)) {
            set_bed_leveling_enabled(false);
            // Subtract the mean from all values
            GRID_LOOP(x, y) {
              Z_VALUES(x, y) -= zmean;
              TERN_(EXTENSIBLE_UI, ExtUI::onMeshUpdate(x, y, Z_VALUES(x, y)));
            }
            TERN_(ABL_BILINEAR_SUBDIVISION, bed_level_virt_interpolate());
          }"""
assert p.OLD in actual_oem_fragment
assert p.OLD_MUTATION in actual_oem_fragment
with tempfile.TemporaryDirectory() as tmp:
    src=Path(tmp)/'Marlin/src/gcode/bedlevel/M420.cpp';src.parent.mkdir(parents=True)
    source=p.INCLUDE_ANCHOR+'\n// SV04 NEXT V4: checked\n// SV04 NEXT V5: checked\n'+actual_oem_fragment
    src.write_text(source)
    p.apply(Path(tmp))
    result=src.read_text()
    assert p.NEW in result and p.NEW_EXTREMA in result and p.NEW_MUTATION in result
    p.apply(Path(tmp))
    assert src.read_text()==result
    print('PASS: OEM whitespace, V6 install and idempotency')
