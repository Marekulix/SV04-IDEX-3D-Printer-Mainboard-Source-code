# SV04 NEXT 300 (Entwicklungsstand, Nummer provisorisch) – Ergebnisbericht: G29 + Abbruch nach Stand 299

Basis: der gemeinsame Stand **299** (ChatGPT: Merge von Claudes G29-Abbruch plus EEPROM 292/293/294) auf dem **erfolgreich gebauten Stand 291** (beide Profile `BUILD_EXIT=0`, Ihre GitHub-Logs). **Nicht flashbar. STM32 GEBAUT = NEIN** für 299 und 300 (in Claudes Umgebung unmöglich: keine ARM-Toolchain, kein PlatformIO, kein GitHub). **HARDWARE GEPRÜFT = NEIN.** Alles „getestet“ ist Host-Simulation um die **echten** Quelldateien. Claude hat **keine** Datei von ChatGPT (EEPROM 292–294, Merge 299, Planner-Guards) verändert; der eine Zusatz ist ein **eigenes, getrenntes Patchskript**.

## 1. Ergebnis in sechs Sätzen

1. Der Merge 299 ist **inhaltlich dasselbe wie mein getestetes 290** (`hooks.h` identisch, Adapter bis auf `{ }`/`{}`, `G29.cpp` ohne Kommentare gleich); meine G29-Abbruchtests gelten damit auch für 299.
2. Die drei Claude-Quelldateien des Stands 299 entstehen **byteidentisch** aus meinen unveränderten 285-Dateien und den Skripten (Merge 299, 292, 293, 294, mein Zusatz 300): Test `R02`.
3. **Neuer Integrationsfehler (behoben, getrennt):** Seit 292 liefert die Startprüfung die Ablehnung „kein Platz für das Undo-Journal“, **ohne** ihren Grund zu nennen (meine Meldung war toter Code). Behoben durch `apply_ee_refusal_message_300.py`.
4. **293/294 ändern das Verhalten bewusst:** Scheitert nur das **Beenden** des Journals, ist das Ergebnis `FAILED (EEPROM_RECOVERY_REQUIRED)`, nie `SUCCESS`; weitere Auto60-Schreibzugriffe sind gesperrt, der Neustart schließt ab. Meine Tests `E04`/`OP32` prüfen jetzt diese Invarianten.
5. **292 setzt `REQUIRE_JOURNAL` standardmäßig auf 1.** Der ungeschützte Modus ist nur noch mit ausdrücklichem `=0` möglich.
6. Beide Planner-Guards (288 und der neue Finite-Guard 290/291) sind in der Simulation **nachgebildet** (nicht aus `planner.cpp`); alle 48 Abbruchfälle laufen ohne Notstopp, und eine Positivkontrolle zeigt, dass der Guard einen `NaN`-Zug wirklich auslösen würde.

## 2. Was am Abbruch implementiert ist (Punkte 3–5 des Auftrags)

Unverändert aus 290, jetzt im Stand 299/300 geprüft: Abbruchtest `SV04Claude_G29CancelRequested()` (liest den DWIN-Puffer **selbst**, nur Auto60/`PROBING`, nur die **eigene** Sitzung), Prüfung vor dem Endskript, Leeren des Puffers beim Start.

| Moment, in dem der Touch eintrifft | Ergebnis | Test |
|---|---|---|
| Aufheizen, Referenzfahrt | `CANCELLED`, die G29 startet nie | `I19`, `I20`, `GC13` |
| unmittelbar nach dem G29-Beginn | 0 Messungen, kein Endskript | `GC12` |
| **während Messpunkt k** (1–16) | genau k Messungen, die Messung k wird **nicht** übernommen, kein Endskript | `GC11b` |
| **zwischen** zwei Messpunkten | genau k Messungen, kein Endskript | `GC11` |
| nach der letzten Messung, **vor** dem Endskript | **kein** `G28 XY` | `GC11` (k = 16), `GM06` |
| **während** des Endskripts | läuft zu Ende, danach `CANCELLED`, Rollback, nie Erfolg | `GC14` |
| vor dem Speichern | `CANCELLED`, 0 EEPROM-Bytes | `OP14` |
| ab dem ersten `save()` | kein Abbruch mehr; scheitert das **Beenden des Journals**: `FAILED (EEPROM_RECOVERY_REQUIRED)` | `OP14`, `GC40`, `GC41`, `K09` |
| **Benutzer-G29** | wird nie angefasst, alle 16 Messungen | `GC15` |

**Grenzen:** Der Abbruch greift **frühestens nach dem laufenden Messpunkt**; eine laufende Messfahrt oder ein laufendes `G28 XY` wird nicht gestoppt (kein Sofortstopp). Ein **serielles `M1060 S0`** ist ein eingereihter Befehl und unterbricht eine laufende G29 nicht; wirksam sind der **Touch** und **M112**. Ob ein echter DWIN-Touch ankommt und ob `idle()` den DWIN-Puffer bedient (deshalb liest der Abbruchtest ihn selbst), ist nur am Gerät prüfbar.

## 3. Konfliktliste zu ChatGPTs Punkt 6 (EEPROM)

| Nr | Fund | Auswirkung auf Claudes Teil | Maßnahme / Bitte an ChatGPT |
|---|---|---|---|
| **K1** | **292 ändert den Standard** `SV04_CLAUDE_EEPROM_REQUIRE_JOURNAL` von 0 auf **1**. | Ohne Platz für das Journal startet Auto60 nicht mehr; Tests `E20`, `OP21` mit ungeschütztem Modus mussten `=0` ausdrücklich setzen. | Angepasst; neuer Test `OP22b` für den Standard. **Bitte bestätigen, dass 1 der gewollte Standard ist.** |
| **K2** | **292 schreibt `sv04c_ee_start_ok` um:** die Richtlinienzeile steht **vor** dem Block, der die Begründung ausgibt → meine Meldung „Start verweigert, kein Platz …“ ist toter Code. | Der Nutzer sieht nur `refused: PRE_EEPROM_UNAVAILABLE`. Sicherheitlich harmlos (die Ablehnung erfolgt). | **`apply_ee_refusal_message_300.py`** (nach 292/293 anzuwenden, idempotent, bricht bei unbekanntem Anker ab). **Bitte in 292 übernehmen** oder bestätigen, dass der getrennte Patch bleiben soll. |
| **K3** | **293/294:** Scheitert das letzte Schreiben (Journal-Ende), ist das Ergebnis `FAILED (EEPROM_RECOVERY_REQUIRED)`, der Block ist neu und gültig. | Meine Tests `E04`/`OP32` nahmen „sonst alter Block“ an. | Angepasst: Block gültig, alt **oder** neu, nie gemischt, auch nach Neustart. **Bitte bestätigen, dass `FAILED` an dieser Stelle gewollt ist.** |
| **K4** | **`test_eeprom_coordinator_294.py` beendet sich immer mit Exitcode 0** (es gibt die Ausgabe nur aus). | Im Workflow bricht ein **fehlgeschlagener** C++-Koordinatortest den Schritt **nicht** ab. | Aktuell `SUMMARY tests=150 pass=150 fail=0` (Log 23). **Bitte im Workflow `grep -q 'fail=0'` ergänzen.** |
| **K5** | **294 ändert die Erfolgsbedingung** (`save_prepared_ && !finish_eeprom(true)` → `FAILED`). | Mein Mutant `CK06` hatte seinen Anker verloren. | Nachgeführt; neu `CK16`, Kerntests `K09`/`K10`. |
| **K6** | **Meine Mutationssignaturen** kannten den neuen Standard nicht (zwei Mutanten überlebten scheinbar). | – | Signaturen erweitert; `AE01` ist seit 292 **belegt gleichwertig** (die Richtlinie verweigert einen ungültigen Block ohnehin). |
| **K7** | **Nicht geliefert:** `SV04_NEXT_287.zip` und `SV04_NEXT_295.zip` (nur die 287-Übergabe liegt bei). | Ihre Hashes in `B 299.yml` waren nicht prüfbar; der Text von ChatGPTs G29-CANCEL-V1-Installer (Claudes `hooks.h`/Adapter nach der Installation) liegt nur als Hash vor. | Beide Datei-Hashes, die prüfbar waren (A 299, 291, 294, 289), stimmen (Log 21). **Bitte den Installer-Text mitliefern.** |

**Unberührt von Claude:** `apply_eeprom_policy_292.py`, `apply_eeprom_commit_guard_293.py`, `apply_eeprom_coordinator_294.py`, `apply_g29_merge_299.py` (Kopien mit Hash in `claude/03_PATCHES/chatgpt_299/`, Test `R01`), der Planner (288, 290/291), M420 V9.

## 4. Tests (Rohlogs: `claude/06_EVIDENCE/host/`)

| Prüfung | Ergebnis |
|---|---|
| C++-Kerntests Koordinator / EEPROM-Kern | 153/153 · 33/33 |
| Host-/Pipeline-/Workflow-/Reproduzierbarkeitstests | 48/48 |
| Simulationstests (darunter 21 G29-Abbruch `GC*`, 20 Betrieb `OP*`) | 190/190 |
| ChatGPT: P1 268–276, M420 V4–V6 + OEM-Anker, Integration 281 | bestanden (Logs 10–12) |
| ChatGPTs EEPROM-/Merge-Tests (A 299 + 294) | bestanden, mit echten Exitcodes (Log 23) |
| Mutationstests, **0 Überlebende** | G29-Abbruch 11 · Betrieb 5 · Adapter 12 · Backend 10 · Koordinator 16 · EEPROM-Adapter 12 · Bedlevel 6 · Kern 24 · EEPROM-Kern 17 (dazu belegt gleichwertige Fälle) |

**Testanpassungen (begründet):** `E20`/`OP21` (ungeschützter Modus nur mit `=0`), `OP22` (Begründung der Ablehnung), `E04`/`OP32` (Journal-Ende gescheitert = `FAILED`), `S32`/`V09` (aus 290: die früher offene Grenze „G29 wird nicht gestoppt“ ist behoben), Mutantenanker `CK06`, `AE01`, `AE02`, `AE05`, `AM01`.

## 5. Einbindung in den nächsten Build

`300.yml` entsteht **textuell aus Ihrem `B 299.yml`** (2 Zeilen geändert, Schritte hinzugefügt) und **ersetzt keine Datei** des integrierten Baums: Prüfung/Entpacken von `SV04_NEXT_300.zip`; Host-Tests ohne Netz; **ein** zusätzlicher Patch (`apply_ee_refusal_message_300.py`) **nach** 292/293/294; ein informierender Beweisschritt „Host-Quellen = integrierte Quellen“ (die fünf Claude-Dateien und fünf OEM-Dateien byteweise bzw. per Hash, `G29.cpp` ohne die 299-Zeile gegen den gebauten 289). **Voraussetzung im Repository:** die Dateien von `B 299.yml` (287, 289, 291, 294, 295, `A 299.zip`) plus `SV04_NEXT_300.zip`. **Probelauf:** Patchschritt und Beweisschritt liefen gegen einen nachgebauten Baum mit Git, inklusive Gegenproben (abweichende Datei → `NO`, fehlendes 292 → Abbruch); alle neuen Shell-Schritte sind mit `bash -n` geprüft. **Nicht nachstellbar:** OEM-Klon, `integrate_286.py`, PlatformIO. **Hauptrisiko:** Der Text von ChatGPTs V1-Installer liegt nur als Hash vor; ob der Merge 299 dessen Rückstände restlos entfernt, zeigt im ersten Lauf der Beweisschritt (`host_vs_build_*.diff`).

## 6. Noch nicht hardwarevalidiert (Plan: `HARDWARE_ABNAHME_G29_300.md`)

Touch während der Messung am echten Gerät (Latenz bis zum Ende des Messpunkts), ob `idle()` den DWIN-Puffer bedient, `G28 XY` nach Abbruch (T1-Parkposition), M112 während der G29, BLTouch-Alarm in der Messung, die vier IDEX-Modi, **Stromausfall und gescheitertes Journal-Ende am echten EEPROM**, HMI-Felder (Typ, Dezimalstellen, Seite 28, Rasterkarte).

## 7. Fortschritt

Zuletzt dokumentiert: P3 75 %, Gesamt 77,0 %. **Ich ändere die Zahlen nicht eigenmächtig.** Neu seit 290 ist die **Integration** (Merge-Äquivalenz, Reproduzierbarkeit, drei Befunde an der Naht zu 292–294) und kein neuer Abbruchmechanismus; ohne STM32-Build von 299/300 und Hardwarebeleg ist das keine Freigabe. Bereits Erbrachtes wird nicht doppelt gezählt.

## 8. Reproduzieren

`python3 claude/tools/verify_manifest.py .` · `python3 claude/tools/run_all_tests_a60.py --stages core,host,sim` (ca. 105 s) · `python3 claude/tools/make_status_300.py` (prüft jeden Nachweis gegen die Rohlogs, inklusive „kein überlebender Mutant“) · Mutationen klassenweise aus `claude/`, z. B. `G29_MUT_SLICE=0:6 python3 -m unittest 04_TESTS.test_mutations_a60.G29CancelMutants`; **zwischen den Mutationsläufen `/tmp` aufräumen** (jeder Lauf hinterlässt Bauverzeichnisse).
