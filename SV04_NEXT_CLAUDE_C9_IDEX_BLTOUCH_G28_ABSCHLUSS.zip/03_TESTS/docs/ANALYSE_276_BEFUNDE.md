# Befunde im Stand 276 (ChatGPT) – belegt durch Ausführung der echten G28.cpp

Methode: Die **echte** `G28.cpp` (Stand 276 und Stand 277) wird mit wörtlich aus `motion.h/.cpp` extrahierten P1-Blöcken übersetzt und in einer Host-Simulation ausgeführt (`claude/04_TESTS/sim/test_g28_a60.py`). `homeaxis()` ist dabei ein **Modell** mit der Reihenfolge des OEM (`motion.cpp:2004` `set_axis_is_at_home`, danach `motion.cpp:2035` `probe.stow()`); die Endschalter, der BLTouch und die Bewegung selbst sind nicht simuliert. Gegenüberstellung aller Szenarien: `G28_VERGLEICH_276_277.md` / `.csv`.

ChatGPTs 57 String-Tests bestehen (unverändert, `claude/06_EVIDENCE/host/10_chatgpt_tests_268_276.txt`). Sie prüfen aber nur, ob Textbausteine vorhanden sind – **keiner** führt G28 aus. Die folgenden Fehler sind in 276 deshalb unentdeckt geblieben.

| Nr | Befund in 276 | Stelle (Stand 276) | Auswirkung | Test (Differenz 276/277) | Stand 277 |
|---|---|---|---|---|---|
| F1 | Nach einem BLTouch-Alarm beim Einfahren (`probe.stow`) bleibt **Z als referenziert und vertraut** markiert, weil `set_axis_is_at_home()` (`motion.cpp:2004`) **vor** `probe.stow()` (`motion.cpp:2035`) läuft | `motion.cpp` (OEM) | Ein Folgebefehl darf auf eine Z-Referenz vertrauen, die nach einem Sensoralarm nicht gesichert ist | F01 | Z-Vertrauen wird nach dem Alarm widerrufen (`homed=XY`) |
| F2 | Nach einem T0-Fehler (T1 war ok) bleibt **X vertraut**, und die **Y-Achse wird trotzdem gefahren** | `G28.cpp` (Y-Block) | Weiterfahrt trotz bekanntem Fehler; X gilt als gesichert | F03 (und F04: T1-Fehler startet T0 nie) | X-Vertrauen widerrufen, Y nicht gefahren (`homed=-`) |
| F3 | Die T1-Plausibilitätsprüfung `fabsf(inactive_extruder_x - x_home_pos(1))` ist **tautologisch**: `set_axis_is_at_home()` hat `inactive_extruder_x` kurz zuvor genau auf diesen Wert gesetzt | `G28.cpp:140` | Ein falscher T1-Offset (M218) wird nie erkannt | F06 | Prüfung gegen `X2_MIN_POS`/`X2_MAX_POS` und `x_home_pos(0)`: Offset 400 → G28 scheitert, Z nicht gefahren |
| F4 | Es gibt **keinen exportierten G28-Ergebnisstatus** | (fehlt) | Auto60 kann das Ergebnis eines G28 nicht auslesen; ein Backend wäre blind | G03, G04 | `sv04_p1_g28_result` (Seq, completed, ok, t1/t0/z) wird auf **jedem** Austrittspfad per RAII geschrieben |
| F5 | Das Z-Gate prüft `!idex_is_duplicating()` (Modus), aber G28 schaltet die Duplizierung am Anfang ab (`set_duplication_enabled(false)`, `G28.cpp:362`) | `G28.cpp:138` | In den Modi DUPLICATION/MIRRORED wird Z **immer verweigert**, und die Duplizierung des Anwenders bleibt danach aus | F07 (Modi 2/3: 276 scheitert, 277 läuft), F11 (alle vier Modi) | Gate prüft das **Laufzeit-Flag** `extruder_duplication_enabled`; beide Modi laufen durch, Duplizierung wird wiederhergestellt |
| F6 | Der zweite X-Durchgang der Duplizierungs-Wiederherstellung ist **ungeprüft**; `sv04_p1_any_failed` ist `const` (`G28.cpp:536`) und wird danach nicht neu bewertet | `G28.cpp:536` | Ein Fehler beim Wiederherstellen wird als Erfolg gemeldet | F08 | `non-const`, nach dem zweiten Durchgang neu ausgewertet (`homed=YZ`, ok=0) |

## Weitere Beobachtungen (kein Fehler von 276, aber wichtig)

* **O1 – das G29-Endskript ist ein echter G28 XY** innerhalb *jeder* G29 (OEM-Konfiguration). Er bewegt beide Wagen erneut. Auto60 wertet sein Ergebnis und den Zustand danach jetzt aus (Test I01, I10, I11). Wird er in einer Anwender-G29 ausgeführt, geschieht das wie bisher.
* **O2 – Nach jedem gescheiterten oder verweigerten G28 bleibt die Nivellierung AUS** (`G28` schaltet sie am Anfang ab). Das gilt auch für das in 276 absichtlich verweigerte `G28 Z` (Zeile N3 der Vergleichstabelle: „Leveling danach 0“, in 276 **und** 277). Nach einem solchen Aufruf muss der Anwender `M420 S1` setzen oder ein volles `G28` fahren. Unverändert gelassen, siehe `OFFEN_UND_BLOCKIERT_277.md`.
* **O3 – ein Endschalter-Fehler ist im OEM ein `kill()`** (`endstops.cpp:394`, `MSG_KILL_HOMING_FAILED`). Die „frühe Rückkehr“-Fehlerfälle des Modells (`x_early_*`) stehen für Pfade, in denen `homeaxis()` ohne Bewegung zurückkehrt; die kill-Fälle prüft F05/I08 (Prozessende, nichts läuft weiter).

## Was die Befunde NICHT sagen

Sie sagen nicht, dass 276 am Gerät falsch fährt. Sie sagen, dass die **Software-Marker** (homed/trusted/Erfolg) in den genannten Fehlerpfaden etwas behaupten, das die Software nicht belegt. Ob ein Wagen wirklich dort steht, wo die Software es annimmt, ist Hardwarefrage (siehe `HARDWARE_ABNAHME_277.md`).
