# SV04 NEXT 290 (Entwicklungsstand, Nummer provisorisch) – Ergebnisbericht Punkt 3: G29 + zuverlässiger Abbruch

Basis: der gemeinsame, **erfolgreich gebaute Stand 289** (beide Profile `BUILD_EXIT=0`, Ihre GitHub-Logs). **Nicht flashbar. STM32 GEBAUT = NEIN** für 290 (in Claudes Umgebung unmöglich: keine ARM-Toolchain, kein PlatformIO, kein GitHub). **HARDWARE GEPRÜFT = NEIN.** Alles „getestet“ ist Host-Simulation um die **echten** Quelldateien. Es wurde **nichts** an M420, Bedleveling oder Planner geändert; der Planner-Guard von ChatGPT bleibt unberührt.

## 1. Ergebnis

Der Abbruch erreicht jetzt eine **laufende** G29-Messung. Bisher (285 und der in 289 integrierte „G29-CANCEL V1“) hing das an einer Annahme, die im OEM-Code unbelegt ist: dass `idle()` während der G29 je `RTSUpdate()` aufruft. Der neue Abbruchtest liest den DWIN-Puffer **selbst** und braucht diese Annahme nicht.

| Nr | Fund / Änderung | Beleg |
|---|---|---|
| **F1** | **Lücke in der Übergabe:** Die G29.cpp von 289 **ruft** `SV04Claude_G29CancelRequested()` nur auf. Die Definition steckt in `hooks.h` und im Adapter, die ChatGPTs Installer zur Laufzeit verändert hat; davon liegen **nur Hashes** vor (und `SV04_NEXT_287.zip` selbst fehlt). Ich habe die Funktion deshalb **selbst** geschrieben: Sie liest den DWIN-Puffer (`RTS_RecData()` kehrt bei leerem Puffer sofort zurück), gibt einen Touch der **eigenen Sitzung** sofort an den Koordinator weiter und liefert für eine Benutzer-G29 immer `false`. | `GC11`, `GC11b`, `GC15`; Mutanten `AM01`–`AM04` |
| **F2** | **Neue Prüfung vor dem Endskript** (Erweiterung über V1): Ein Abbruch, der nach der letzten Messprüfung eintrifft, ließ das Endskript `G28 XY` noch beide IDEX-Wagen fahren. | `GC11` (k = 16), Mutant `GM06` |
| **F3** | **Rennen „alter Touch bricht neuen Lauf ab“:** Ein DWIN-Rahmen, der **vor** dem Start im Puffer lag, wurde nach dem Start als Abbruch des **neuen** Laufs gewertet. Der Start leert jetzt den Puffer. | `GC20`; Mutant `AM05` |
| **F4** | **Testlücke und Dokumentationsfehler (meiner):** Der Mutant `CK12` (Journal-Transaktion bei nicht verfügbarer Rohlesung) war in 283 als **Überlebender** gemeldet und danach **stillschweigend aus der Liste genommen** worden. Er ist kein gleichwertiger Mutant (der unverifizierte Block bliebe im EEPROM). Test `E14` ist geschärft, `CK12` wieder aufgenommen und erkannt. Der veraltete Zwischenbericht `07b_mutationen_koordinator283.txt` steckt noch im ausgelieferten 285-Paket und ist aus 290 entfernt. | `E14`, `07b_mutationen_koordinator.txt` |
| **F5** | **Zwei Altannahmen wurden bewusst geändert:** `S32` hielt die früher als OFFEN markierte Grenze „laufende G29 wird nicht gestoppt“ fest, jetzt gilt `probe == 0`. `V09` setzte eine vollständige Messung vor dem Abbruch voraus; neu aufgesetzt, dazu `V09b`. | `S32`, `V09`, `V09b` |

## 2. Beweis, dass die Simulation den gebauten Stand ausführt (Punkt 1)

* `G28.cpp`, `gcode.cpp`, `LCD_RTS.cpp`, `motion.cpp`, `motion.h` der Simulation sind **byteidentisch** mit den Dateien des erfolgreich gebauten Stands 289 (SHA-256 im Test `GC01`).
* `G29.cpp` der Simulation ist die G29.cpp des Builds 289 **plus genau eine Zeile** (Erweiterung 290); ohne diese Zeile ist sie bitgleich zu `0ec947ae…` (Test `GC01`).
* Die bedlevel-Funktionen (`leveling_is_valid`, `set_bed_leveling_enabled`, `reset_bed_level`) sind **textgleich** mit denen im Build (`compare_bedlevel_real.py`).
* **Nicht** vorhanden: `planner.cpp` (der Guard ist mit gleichem Text nachgebildet), `M420.cpp` (V9) und der vollständige OEM-Baum. Der Workflow beweist den Gleichstand im GitHub-Lauf erneut (`host_equals_build_290.txt`).

## 3. Abbruchmatrix für den Lauf (Punkte 3–5)

| Moment, in dem der Touch eintrifft | Ergebnis | Test |
|---|---|---|
| Aufheizen, Stabilisieren, Referenzfahrt | sofort bzw. nach dem laufenden G28 `CANCELLED`, die G29 startet nie | `I19`, `I20`, `GC13` |
| unmittelbar nach dem G29-Beginn | 0 Messungen, kein Endskript | `GC12` |
| **während Messpunkt k** (1–16) | genau k Messungen, die Messung k wird **nicht** übernommen (nur k−1 Zellrahmen), kein Endskript | `GC11b` |
| **zwischen** Messpunkt k und k+1 | genau k Messungen, kein Endskript | `GC11` (beide Umgebungen) |
| nach der letzten Messung, **vor** dem Endskript | kein Endskript | `GC11` (k = 16), `GM06` |
| **während** des Endskripts | `G28 XY` läuft zu Ende (nicht unterbrechbar), danach `CANCELLED`, Rollback, **nie Erfolg** | `GC14` |
| Validieren, Aktivieren, vor dem Speichern | `CANCELLED`, 0 EEPROM-Bytes | `OP14` |
| ab dem ersten `save()` | kein Abbruch mehr (es wird verifiziert) | `OP14` |
| **Benutzer-G29** (kein Auto60) | wird nie angefasst, alle 16 Messungen | `GC15` |

Das gilt in beiden Umgebungen: (a) `idle()` ruft `RTSUpdate()` auf, (b) `idle()` ruft es **nie** auf (der Touch kommt als DWIN-Rahmen und wird nur vom Abbruchtest gelesen). Negativkontrolle `GC23`: ohne die Abfrage erreicht der Touch die laufende G29 **nicht**.

**Grenzen (ehrlich):**
* Der Abbruch greift **frühestens nach dem laufenden Messpunkt**. Eine laufende Bewegung (Messfahrt, `G28 XY`) wird nicht gestoppt; ein Quickstop mit Positionsnachführung wäre ein Eingriff in den Planner und gehört in eine kontrollierte Hardware-Abnahme.
* Ein **serielles `M1060 S0`** ist ein eingereihter Befehl und kann eine **laufende** G29 nicht unterbrechen. Wirksam sind der **Touch** und der Notstopp **M112**.
* Ob ein echter DWIN-Touch bei aktiver Eingabesperre ankommt, ist nur am Gerät prüfbar (die Tastenverwerfung im Lauf steht **vor** jeder OEM-Logik in `RTS_HandleData`).

## 4. Mesh-Transaktion, M420, M500 (Punkte 6–8)

* Rückweg bei jedem Abbruch/Fehler: **zuerst** die Nivellierung ausschalten (nur wenn das alte Mesh ungültig ist), **dann** das alte Mesh herstellen, **dann** den Zustand vor dem Lauf. **48 Abbruchfälle** (altes Mesh leer/gültig, Nivellierung aus/an, k = 1–16) mit den **echten** V2/V4-Funktionen und dem **Planner-Guard** (aktiv + ungültig → `kill()`): kein Notstopp (`GC30`). Der Planner-Guard ist nur **nachgebildet**.
* Nach der G29: Aktivierung wird am tatsächlichen Zustand geprüft; ein nicht wirkendes M420 oder ein ungültiges Mesh ist `FAILED`, nie Erfolg, nie M500 (Kerntests `E03`–`E07`, `E17`).
* M500 nur nach verifiziertem Erfolg; Abbruch/Timeout/unvollständiges Mesh: 0 EEPROM-Bytes, Z-Offset unverändert (`E17`, `S43`, `I25`, `GC11`).
* **Offene Sicherheitsentscheidung:** `SV04_CLAUDE_EEPROM_REQUIRE_JOURNAL` (Standard 0). Ohne Platz für das Journal speichert Auto60 ungeschützt, meldet das aber beim Start und bei der Speicherfreigabe laut. **Das ist keine Ausfallsicherheit.**

## 5. Anzeige, IDEX, Sitzungen (Punkte 9–11)

* **DWIN:** MCU-seitig verdrahtet (echte `RTS_SndData`, OEM-Live-G29 je Messpunkt, Bootschleife, Rollback); 16 Zellen `0x1100…0x111E`, Fortschritt 1–16, Erfolgsseite nur nach verifiziertem Speichern. **Unbewiesen** (kein HMI-Projekt): Objekttyp/Dezimalstellen, Seite 28, farbige Rasterkarte, Anzeigefelder für Phasen. Es wurde kein Anzeigefeld erfunden.
* **IDEX:** alle vier Modi, T0/T1, BLTouch, Endstop mit der echten G28.cpp (`I03`–`I09`, `F03`–`F11`); echte Positionen unbestätigt.
* **Sitzungen:** alter Touch, mehrfacher Touch (5 Rahmen = 1 Abbruch), sofortiger Neustart nach Abbruch, fremde G29/G28, falsche SID (`GC20`–`GC22`, `OP10`–`OP13`, `I11`–`I15`, `I27`, `S28`).

## 6. Tests

| Prüfung | Ergebnis |
|---|---|
| C++-Kerntests Koordinator / EEPROM-Kern | 151/151 · 33/33 |
| Host-/Pipeline-/Workflow-Tests | 39/39 |
| Simulationstests (darunter 18 G29-Abbruch `GC*`, 19 Betrieb `OP*`, 10 Bedleveling) | 186/186 |
| ChatGPT: P1 268–276, M420 V4–V6 + OEM-Anker, Integration 281 | bestanden (Logs 10–12) |
| Mutationstests, **0 Überlebende** | G29-Abbruch 11 · Betrieb 5 · Adapter 12 · Backend 10 · Koordinator 15 · EEPROM-Adapter 11 · Bedlevel 6 · Kern 24 · EEPROM-Kern 17 |

## 7. Einbindung in den echten Build (Punkt 13)

`290.yml` entsteht **textuell aus Ihrem erfolgreichen `289.yml`** (3 Zeilen geändert, Schritte hinzugefügt). Neu: Prüfung und Entpacken von `SV04_NEXT_290.zip`; Host-Tests ohne Netz; **nach** `integrate_286.py` und Planner-Guard das Overlay (meine `hooks.h` und `sv04_claude_auto60_marlin.inc` ersetzen die vom Installer erzeugten, `cmp` der drei unveränderten Kern-Dateien, Erweiterung in der integrierten `G29.cpp`, Prüfsummen vorher/nachher, **Diff gegen die vom Installer erzeugten Dateien als Beleg**, neuer kombinierter Patch); ein Beweisschritt „Simulation = Build“ (informierend). Patch-Reihenfolge ab OEM unverändert. **Voraussetzung im Repository:** `SV04_NEXT_287.zip` und `SV04_NEXT_289.zip` (wie bei 289). **Hauptrisiko:** Hat der Installer in `hooks.h` oder im Adapter mehr verändert, als ich sehe (nur Hashes bekannt), kann der erste Build brechen; `overlay_marlin.diff` zeigt dann genau, was fehlt. Alle Bezeichner, die die 289-Quelldateien nutzen, sind in meiner `hooks.h` deklariert (Test `GC04`). Die zwei neuen Shell-Schritte sind mit `bash -n` syntaktisch geprüft und liefen im Probelauf gegen einen nachgebauten Baum mit Git (Beweisschritt inklusive Gegenprobe).

## 8. Offene Hardware-Abnahme (Plan: `HARDWARE_ABNAHME_PUNKT3_290.md`)

Erst nach grünem Build beider Profile und nur mit separater Freigabe. Offen bleiben: Touch während der Messung am echten Gerät (Latenz bis zum Messpunktende), ob `idle()` den DWIN-Puffer während der G29 bedient, das Verhalten von `G28 XY` nach einem Abbruch (T1-Parkposition), Notstopp M112 während der G29, BLTouch-Alarm mitten in der Messung, die vier IDEX-Modi, Journal und EEPROM, Seite 28 und Rasterkarte im HMI.

## 9. Fortschritt

Punkt 3 war zuletzt mit 65 % geschätzt. **Ich ändere die Zahl nicht eigenmächtig.** Entwicklungsseitig neu programmiert und hostgetestet: der Abbruch erreicht die laufende Messung, drei Sicherheitslücken sind geschlossen (F1–F3). Ohne STM32-Build von 290 und ohne Hardwarebeleg ist das **keine** Hardwarefreigabe; eine Anhebung wäre nach grünem Build beider Profile begründbar.

## 10. Reproduzieren

`python3 claude/tools/verify_manifest.py .` · `python3 claude/tools/run_all_tests_a60.py --stages core,host,sim` (ca. 115 s) · `python3 claude/tools/make_status_290.py` (prüft jeden genannten Nachweis gegen die Rohlogs, inklusive „kein überlebender Mutant“) · Mutationen klassenweise aus `claude/`, z. B. `G29_MUT_SLICE=0:6 python3 -m unittest 04_TESTS.test_mutations_a60.G29CancelMutants`.
