# SV04 NEXT 277 – Ergebnisbericht

## Kurzfassung

**Nicht flashbar. STM32 GEBAUT = NEIN. HARDWARE GEPRÜFT = NEIN.** In meiner Umgebung gibt es keinen ARM-Compiler, kein PlatformIO und kein Netz; der Zielbuild ist deshalb Aufgabe des mitgelieferten Workflows `277.yml` und **bisher nicht gelaufen**. Alles, was ich „getestet“ nenne, ist **Host-Simulation um die echte `G28.cpp`/`G29.cpp`** (siehe „Was die Simulation beweist“).

Was in dieser Runde tatsächlich entstanden ist:

1. **Stufe 1 – Korrekturen am Stand 276 (ChatGPT).** Beim Ausführen der echten `G28.cpp` habe ich **sechs Fehler in 276** gefunden und belegt (`ANALYSE_276_BEFUNDE.md`); ChatGPTs 57 Tests prüfen nur Textbausteine und haben sie nicht gesehen. Sie sind in `apply_277_p1.py` korrigiert (+110/−19 Zeilen in G28/motion).
2. **Stufe 2 – Auto60 mit PRODUKTIONS-Backend und G28-Wächter.** Das Backend `SV04Claude_HomeBackendRequest` ist **kein Test-Double mehr**: es stellt `G28 X Y Z` in die Marlin-Queue, ein Wächter in `G28.cpp` (+9 Zeilen) bindet das G28 an die Anforderung und meldet das P1-Ergebnis **genau einmal**.
3. **Gesamtkette in einer Simulation:** Auto60 → Aufheizen → Backend → **echter G28** (T1, T0, Y, Z) → **echte G29** mit dem OEM-Endskript `G28 XY` als echtem G28-Lauf → Validierung → Speichern → Rücklesung.
4. **Ein einziges Patchskript** (`apply_277.py --profile p1|integrated`) und ein **Workflow mit vier Profilen**.

## Eingaben (alle verifiziert)

Auftrags-ZIP und alle sechs Eingabedateien gegen `SHA256_MANIFEST.txt` geprüft; OEM-Commit `1867fcba75354a5c65e0631d6972dd19f1bd6cbe`, `G28.cpp` Blob `5700ac25…`. Das Paket `files-3.zip` enthält meine frühere Lieferung (byte-identisch). Hashes: `claude/01_BASELINE/EINGABEN_277.json`.

## Die fünf Kategorien

| Kategorie | Stand |
|---|---|
| **IMPLEMENTIERT** | Stufe 1: `apply_277_p1.py` (19 Anker; ersetzt 14 Zeilen in G28.cpp, fügt sonst nur ein). Stufe 2: Backend und G28-Wächter in `sv04_claude_auto60_marlin.inc` (352 Zeilen) und `sv04_claude_hooks.h` (94), Kern `sv04_claude_auto60_core.h` (406; neu: Endskript-Fehler, Verwurf-Port), Overlay-Werkzeug `apply_claude_parallel.py`. Orchestrator `apply_277.py`, `277.yml` (Generator `make_workflow_277.py`), Diffs in `diffs/` (10 Dateien). |
| **LOKAL GETESTET** | **130** C++-Kerntests · **22** Host-/Pipeline-/Workflow-Tests · **115** Simulationstests (53 Kette, 13 DWIN, 7 streng, 15 G28, 27 Integration) · **57** ChatGPT-Tests unverändert · Mutationen: **24/24** Kern, **13/13** Adapter, **10/10** Backend erkannt (zusätzlich je 1 geprüft gleichwertiger Mutant in Kern und Adapter). Rohlogs: `claude/06_EVIDENCE/host/`. |
| **STM32 GEBAUT** | **NEIN.** Kein Lauf. Vorbereitet: `277.yml` mit `baseline_oem`, `p1_corrections`, `integrated_backend`, `integrated_failclosed` (NOT RUN). |
| **HARDWARE GEPRÜFT** | **NEIN.** Plan: `HARDWARE_ABNAHME_277.md`. |
| **BLOCKIERT** | STM32-Build, RAM/Flash, Hardware, HMI-Binärdateien, `MarlinCore.cpp`-Reihenfolge von `RTSUpdate()`, Versionsnummer 277 – mit Reproduktion in `OFFEN_UND_BLOCKIERT_277.md`. |

Zeilengenaue Matrix aller 30 Arbeitsschritte und 8 Abnahmebedingungen: `STATUS_277.csv`. **Jeder dort genannte Test wurde gegen die Rohlogs geprüft** (das Skript bricht ab, wenn einer dort nicht bestanden ist).

## Die sechs Befunde in 276 (Kurzform; Details und Zeilenverweise in `ANALYSE_276_BEFUNDE.md`)

| | Befund | Wirkung in 277 |
|---|---|---|
| F1 | Z bleibt nach BLTouch-Stow-Alarm „referenziert und vertraut“ (`set_axis_is_at_home` läuft vor `probe.stow`) | Z-Vertrauen wird widerrufen |
| F2 | Nach T0-Fehler bleibt X vertraut, Y wird trotzdem gefahren | X widerrufen, Y nicht gefahren |
| F3 | T1-Plausibilität vergleicht einen Wert mit sich selbst (tautologisch) | echte Prüfung gegen Verfahrweg |
| F4 | kein exportierter G28-Ergebnisstatus | Ergebnisstruktur auf jedem Austrittspfad |
| F5 | Z-Gate verweigert in Duplizierung/Spiegel immer und schaltet die Duplizierung ab | Laufzeit-Flag; beide Modi laufen, Modus wird wiederhergestellt |
| F6 | zweiter X-Durchgang ungeprüft, `any_failed` ist `const` | geprüft, neu bewertet |

Gegenüberstellung am laufenden Code: `G28_VERGLEICH_276_277.md` (Normalfälle Modus 0/1 laufen auf 276 und 277 **spurgleich**).

## Was die Simulation beweist – und was nicht

**Beweist** (Ausführung der echten Quelldateien): die Reihenfolge und Logik von `G28`/`G29`, wer wann welches Ergebnis meldet, dass nach einem Fehler weder Folgebewegung noch EEPROM-Schreiben noch „fertig“-Anzeige folgt, die Zustände der Auto60-Sitzung, und dass das Backend **eine** Anforderung stellt, das G28 daran bindet und ein verspätetes G28 einer verworfenen Anforderung **verweigert**.

**Beweist nicht:** Mechanik, Endschalter, BLTouch, Kollisionsfreiheit, Timing im echten `idle()`, DWIN-Touch, den ersten Zielcompile. `homeaxis()`, Planner, Thermik, Queue und EEPROM sind Modelle, die die Reihenfolge des OEM nachbilden.

## Eigene Korrekturen in dieser Runde (offen benannt)

* **Lücke im eigenen Backend:** Beim Entwerfen der Abbruchtests stellte sich heraus, dass ein Abbruch, solange das G28 nur **eingestellt, aber noch nicht gestartet** ist, nur ein Flag setzte; das G28 wäre später trotzdem gefahren. Behoben (`sv04c_hb_cancel_armed`), Mutant P02 sichert es ab.
* **Drei Tests waren zunächst wirkungslos:** Meine Szenarien beendeten die Simulation vor der späten Queue-Freigabe, so dass „verspätetes G28 wird verweigert“ trivial bestand. Mutationstests haben das aufgedeckt; die Simulation läuft nun nach dem Endzustand weiter (`tail_s`), und die Tests sehen den Versuch tatsächlich.
* Test-Infrastruktur auf die echten Patchskripte umgestellt; zwei Altests mussten angepasst werden (`S08`: Fail-closed braucht jetzt ausdrücklich `…AVAILABLE=0`; `P02`: `G28.cpp` ist nicht mehr gesperrt). Sonst alle 53+13+7 Alt-Szenarien **unverändert** grün.

## Verhaltensänderungen gegenüber 276 (Entscheidungen in `OFFEN_UND_BLOCKIERT_277.md`)

1. In den Modi DUPLICATION/MIRRORED läuft ein volles `G28` jetzt durch (276: Z verweigert).
2. Touch während Auto60 löst einen **kontrollierten Abbruch** aus (vorher Sperre).
3. Nach Fehlern in G28 gilt **kein** Vertrauen mehr in X/Z, das die Software nicht belegt; Y wird nach einem X-Fehler nicht mehr gefahren.
4. Unverändert: `G28 Z` allein bleibt verweigert; nach einem gescheiterten G28 bleibt die Nivellierung aus (Verhalten des OEM/276).

## Größtes verbleibendes Risiko

**Der erste Compile auf dem Ziel.** Die neuen Teile (RAII-Klasse im G28, `queue.enqueue_now_P`, Fremdaufrufe aus `G28.cpp` in den Adapter) sind auf dem Host streng übersetzt (16 Konfigurationen, keine neuen Warnungen in der echten `G28.cpp`), aber nicht mit dem Zielcompiler. Der Workflow `integrated_backend` ist genau dafür gemacht. Ich erwarte dabei ehrlich gesagt **eher keinen** sauberen ersten Lauf ohne eine Kleinigkeit, und werte jede Meldung aus.

## Fortschrittsanzeige

Unverändert (Ihre sechs Entwicklungsschätzungen 55 / 52 / 43 / 55 / 55 / 25, Ø 47,5 %). Es liegt weder ein Zielbuild noch ein Hardwarebeleg vor, der eine Änderung rechtfertigen würde.

## Nächster Schritt

`GITHUB_UPLOAD_ANLEITUNG.md`: `277.yml` und `SV04_NEXT_277.zip` hochladen, Workflow starten, die Ergebnispakete schicken.

## Paketinhalt

`apply_268…276.py`, `test_268…276.py` (ChatGPT, unverändert) · `apply_277_p1.py` · `apply_277.py` · `diffs/` · `claude/` (Quellen `02_SOURCE`, Patchwerkzeug `03_PATCHES`, Tests `04_TESTS`, Logs `06_EVIDENCE`, Audit `07_AUDIT`, Werkzeuge `tools`, OEM-Referenz `01_BASELINE`, Archiv der Vorlieferung) · `docs/` · `MANIFEST_SHA256.txt`. Keine Firmware.
