# SV04 NEXT – Claude-Rückgabe C1: IDEX + BLTouch (Punkt 1) und G28 Homing (Punkt 2)

Stand 12.11.2026 · Basis: gemeinsamer Stand 299, ChatGPTs EEPROM-Kette 300–305, Claudes Stand 300 (`files-7.zip`, byte-identisch zu Claudes Auslieferung). Die Bezeichnung **C1** ist ein Claude-internes Kürzel und **nicht** ChatGPTs Versionsnummer 300/305.

> **Ehrlicher Gesamtstand:** Programmiert und in der Host-Simulation um die **echten** Quelldateien geprüft. **STM32 GEBAUT = NEIN** (in Claudes Umgebung unmöglich: keine ARM-Toolchain, kein PlatformIO, kein GitHub). **HARDWARE GEPRÜFT = NEIN.** Gebaut ist nur der Stand **291** (Ihre Logs, beide Profile `BUILD_EXIT=0`). **Claude hat in dieser Rückgabe keine Firmwaredatei geändert.** Neu sind Tests, Werkzeuge und Belege.

## 0. Quellbasis (Auftrag 1)

* **Gewählt:** die vier Claude-Quelldateien des Stands 299 **mit** ChatGPTs Kette 300–305 (`02_SOURCE`); entsteht **byteidentisch** aus Claudes unveränderten 285-Dateien + Merge 299 + 292/293/294 + Kern 300→301→304 + Adapter 302→303→305 (Test `R02`; Hashes der Skripte in `03_PATCHES/chatgpt_299/` und `chatgpt_305/`, Test `R01`).
* **Manifest:** `MANIFEST_SHA256.txt` (alle Dateien dieser ZIP), Basis-Eingaben mit Hash: Log `21_uebergabe_integritaet_305.txt` (alle 12 Dateien der Übergabe stimmen).
* **Verschachtelte ZIPs nicht ignoriert:** 299-Übergabe, 287-Referenz, EEPROM 304 (mit den Vorgängern 300–303) und 305 wurden entpackt und ausgewertet.
* **Nicht vorhanden, daher nicht prüfbar:** `tool_change.cpp`, `gcode/control/T.cpp`, `feature/bltouch.cpp` (der ChatGPT-Audit pinnt sie per Git-Blob-SHA, sie liegen nicht bei).

## 1. Neue und unabhängig geprüfte Erkenntnisse

| Nr | Erkenntnis | Beleg |
|---|---|---|
| **N1** | **ChatGPTs EEPROM-Kette 300–305 passt zu Claudes Stand:** Alle sechs Patches lassen sich auf Claudes 285-Dateien anwenden; auf dem so entstehenden Stand bestehen **alle** Claude-Suiten unverändert (Kern 153, EEPROM-Kern 33, Simulation 193). Der EEPROM-Teil wurde **nicht** angefasst. | `R01`–`R04`, Logs `01`–`03`, `23` |
| **N2** | **303 erhält Claudes Neusenden des Meshs nach der Start-Wiederherstellung** (F1 aus 290) und stellt es hinter die Prüfung des EEPROM-Hauptblocks. | `OP01`, `R04`, Mutant `OM01` |
| **N3** | **Der gesamte G28-Zustandsraum ist invariant geprüft:** 4 Modi × 2 Startwerkzeuge × 2 Druckzustände × 8 Achsauswahlen × 7 Fehlerfälle (T1-/T0-Endschalter früh, T1 scheitert im 2. Aufruf, BLTouch stow/deploy/Alarm) × 1–2 Aufrufe = **1792 Fälle**, echte `G28.cpp`: **0 Verletzungen**. **Negativkontrolle:** derselbe Satz findet am alten 276er-G28 **504** Verletzungen in 6 Klassen. | `test_g28_matrix_305` (`M01`–`M03`), Log `25` |
| **N4** | **Tatsächliches Verhalten des G28 (aus dieser Prüfung gelernt):** (a) `G28 Z` allein wird **abgelehnt**, ohne jede Bewegung, auch mit BLTouch-Fehler; (b) im Duplikations- und Spiegelmodus (2/3) referenziert **auch `G28 Y`** den T1 in X (OEM-Durchgang zum Wiederherstellen der Duplikation), dort wird T1 **zweimal pro G28** referenziert; (c) scheitert T1 in einem späteren Aufruf, wird X entzogen, bereits referenziertes Y/Z bleibt gültig, T0 bewegt sich nicht; (d) nach einem fehlgeschlagenen G28 bleibt T1 das aktive Werkzeug und die Nivellierung aus (fail-closed, Absicht von 277). | `M01`, `M03`, `F03`, `F08`, `F09` |
| **N5** | **Konfigurationsaudit mit Zeilenbelegen** gegen die echte OEM-Konfiguration (neues Werkzeug, endet bei jeder Abweichung mit Exitcode ≠ 0; fehlende Definition = FAIL). | `check_idex_bltouch_config_c1.py`, `A01`–`A05`, Log `24` |

### Faktentabelle aus der echten Konfiguration (Auszug, vollständig in Log `24`)

| Größe | Wert | Beleg |
|---|---|---|
| Bett / Reichweite X | `X_MIN_POS -62` … `X_MAX_POS 302` (`X_BED_SIZE 302`), `Y_BED_SIZE 302`, `Z_MAX_POS 400` | `Configuration.h:1377–1386` |
| IDEX | `DUAL_X_CARRIAGE`, `EXTRUDERS 2`, `X1_MAX_POS 302`, `X2_MIN_POS 0`, `X2_MAX_POS 362`, `X2_HOME_DIR 1`, `X2_HOME_POS 362`, Standardmodus `DXC_AUTO_PARK_MODE` | `Configuration_adv.h:752–766` |
| Abstand T0-Maximum / T1-Park (konfiguriert) | `362 − 302 = 60 mm` (reale Wagenbreite **unbekannt**) | abgeleitet |
| BLTouch / Homing | `BLTOUCH`, `USE_PROBE_FOR_Z_HOMING`, `Z_SAFE_HOMING`, `NOZZLE_TO_PROBE_OFFSET { 0, 25, 0 }`, Endskript der G29 `"G28 XY"`, Homing-Vorschub Z `4*60` mm/min | `Configuration.h:1041–1753` |
| Z-Homing ohne Trigger | `1,5 × max_length(Z)` = **600 mm** (≈ **150 s** bei 4 mm/s) | `motion.cpp:1810` |

## 2. Vorherige Annahmen korrigiert

* **Alte Zahl „536 Verletzungen am 276er-G28“** aus meiner Zwischenmeldung: maßgeblich sind **504** (Log `25`).
* **„Der Z-Homing-Fehler ohne Trigger lässt sich per Guard begrenzen“** ist **nicht haltbar:** Vor dem Homing ist die Z-Position unbekannt, die 600 mm sind der **Marlin-Normalfall** für diesen Fall. Ein Guard würde das normale Homing aus großer Höhe brechen. Es bleibt eine dokumentierte Hardware-/Konfigurationsfrage.
* **`AE05` (Mutationstest)** war im Stand 299 durch ein Szenario unterscheidbar, im Stand 305 nicht mehr: Der verschärfte Kern 304 meldet früher `CM_ROLLBACK_FAILED`. Das Ergebnis ist identisch; geführt als „beobachtungsgleich seit 304“ mit Begründung (Zweite Verteidigungslinie, **kein** Szenario trifft nur die Adapterprüfung).

## 3. Eigene frühere Fehlinterpretationen (Claude)

* Meine G28-Invarianten waren **viermal falsch**, bevor sie stimmten: (1) sie vermischten die Spur zweier Aufrufe, (2) sie nahmen an, `x_t1_on_call=2` treffe immer den zweiten *Aufruf* (im Modus 2/3 trifft es den zweiten *Durchgang* desselben Aufrufs), (3) sie nahmen an, jedes `G28` ohne X führe nie T1 an, (4) die **Negativkontrolle prüfte anfangs gar nichts**, weil der 276er-Stand kein Ergebnisobjekt hat. Erst die wirksame Negativkontrolle hat das aufgedeckt.
* Mein Konfigurationsaudit hat anfangs ein **fehlendes `#define BLTOUCH` durchgewunken** (`ok`). Korrigiert, Test `A03`.
* Der Mutant `CK12` (283) wurde in einer früheren Runde stillschweigend aus der Liste genommen; seit 300 wieder geführt und erkannt.

## 4. Offen und unbewiesen

* **Werkzeugwechsel (`T0`/`T1`) in unsicheren Zuständen:** `tool_change.cpp`, `T.cpp`, `bltouch.cpp` liegen nicht vor. Eine Guard-Implementierung oder Analyse im echten Code ist dort **nicht möglich**; es wurde keine erfunden.
* **BLTouch:** reale Reaktion auf Alarm, Trigger-Ausbleiben, Kabelbruch, `PROBE_TRIGGERED_WHEN_STOWED_TEST` (in der OEM-Konfiguration **nicht aktiv**) und alle Zeiten sind nur am Gerät prüfbar.
* **IDEX-Mechanik:** Wagenbreite, reale Parkabstände, Kollisionsfreiheit, T1-Position, `TOOLCHANGE_ZRAISE = 0` (Marlin-Standardwert; Block `#if HAS_MULTI_EXTRUDER`) – ob 0 mm mechanisch gewollt ist, ist **nicht belegbar**.
* **STM32:** Buildbarkeit von 299/C1 nicht belegt; 291 ist der letzte gebaute Stand.
* **DWIN:** unverändert gegenüber 290 (16 Zellen `0x1100…0x111E`, MCU-seitig verdrahtet; HMI-Objekttypen, Seite 28 und Phasenfelder unbewiesen).
* **ChatGPTs Tests:** `test_eeprom_post_boot_302.py` hat einen **harten Pfad** (`/mnt/data/work299/…`) und läuft außerhalb von ChatGPTs Umgebung nicht (Log `23`); die Einzeltests der Stände 300/301 sind hier ebenfalls nicht lauffähig. Maßgeblich sind die ausführbaren 304-Tests (45/45), 301-Kerntest (39/39), 303- und 305-Tests.

## 5. Fortschritt (Schätzung, host-seitig, keine Hardwarefreigabe)

| Punkt | vorher | jetzt | Begründung |
|---|---|---|---|
| **1 IDEX + BLTouch** | 75 % | **75 %** | Keine neue Implementierung und keine neuen IDEX-/BLTouch-Guards (die dafür nötigen Dateien fehlen); das Konfigurationsaudit dokumentiert nur. **Unverändert.** |
| **2 G28 Homing** | 75 % | **76 %** | Neu ist **Verifikation**, keine Implementierung: erschöpfende Invariantenprüfung (1792 Fälle, wirksame Negativkontrolle) der **bestehenden** G28. +1 %, weil Belege für bereits Programmiertes erweitert wurden. |

Unveränderte Bereiche (G29-Abbruch, M420/Planner, EEPROM 304/305) werden **nicht** als Fortschritt gebucht.

## 6. Konkrete nächste Schritte nach der Integration

1. **STM32-Build beider Profile** des gemeinsamen Stands (299 + 300–305) auf GitHub, sobald verfügbar; erst dann ist die Buildbarkeit belegt.
2. **Dateien nachliefern:** `tool_change.cpp`, `gcode/control/T.cpp`, `feature/bltouch.cpp` (Revision `1867fcba…`), damit Werkzeugwechsel- und BLTouch-Guards im echten Code analysiert werden können.
3. **Hardwareentscheidungen:** `TOOLCHANGE_ZRAISE`, `PROBE_TRIGGERED_WHEN_STOWED_TEST`, reale Parkabstände (siehe Hardware-Plan `HARDWARE_ABNAHME_G29_300.md`).
4. **ChatGPT:** `test_eeprom_post_boot_302.py` portabel machen (relativer Pfad); im Workflow `grep 'fail=0'` für `test_eeprom_coordinator_294.py` (K4 aus 300).

## 7. Reproduzieren

Im Wurzelverzeichnis dieser ZIP (benötigt `g++`, `python3`, `PyYAML`, `patch`): `python3 claude/tools/verify_manifest.py .` · `python3 claude/tools/run_all_tests_a60.py --stages core,host,sim` (ca. 135 s) · `python3 claude/tools/check_idex_bltouch_config_c1.py` · Mutationen klassenweise aus `claude/`, z. B. `python3 -m unittest 04_TESTS.test_mutations_a60.AdapterMutants` (**zwischen den Läufen `/tmp` aufräumen**).

## 8. Tests dieser Rückgabe (Rohlogs: `claude/06_EVIDENCE/host/`)

| Prüfung | Ergebnis |
|---|---|
| C++-Kerntests Koordinator / EEPROM-Kern | 153/153 · 33/33 |
| Host-/Pipeline-/Reproduzierbarkeits-/Audit-Tests | 34/34 |
| Simulationstests (darunter 3 G28-Matrix `M01`–`M03`) | 193/193 |
| ChatGPT: P1 268–276, M420 V4–V6, Integration 281; EEPROM 304/305 | bestanden (Logs `10`–`12`, `23`) |
| Mutationstests, **0 Überlebende** | G29-Abbruch 11 · Betrieb 5 · Adapter 12 · Backend 10 · Koordinator 16 · EEPROM-Adapter 11 · Bedlevel 6 · Kern 24 · EEPROM-Kern 17 (dazu belegt gleichwertige Fälle) |

**Es gibt keine neue Guard-Funktion** in dieser Rückgabe; Tests für „jede neue Guard-Funktion“ entfallen daher. Die vorhandenen P1-Guards sind durch `F01`–`F11`, `G01`–`G04`, `I03`–`I09` und die Matrix `M01`–`M03` gegen die echte `G28.cpp` ausgeführt geprüft.
