# GitHub-Lauf 283 – mit dem Android-Tablet

Es gibt **genau zwei Dateien** zum Hochladen (im Ausgabeordner, nicht im ZIP): `283.yml` und `SV04_NEXT_283.zip`.

1. Im Repository **Add file → Upload files**: `SV04_NEXT_283.zip` in den **Wurzelordner** laden (Name genau so, **nicht** verändern, der Workflow prüft den fest eingetragenen SHA-256).
2. `283.yml` nach `.github/workflows/283.yml` legen: **Add file → Create new file**, als Dateiname `.github/workflows/283.yml` eintippen (die Schrägstriche legen die Ordner an), den Inhalt einfügen, speichern. (Oder wie bei 282 hochladen.)
3. Reiter **Actions** → „283 – SV04 Claude 282 + EEPROM M500/Rücklesung merged STM32 – NO FLASH“ → **Run workflow**.
4. Der Workflow läuft für **zwei Profile**: `integrated_backend` und `integrated_failclosed` (`-DSV04_CLAUDE_HOME_BACKEND_AVAILABLE=0`). Er prüft das ZIP, führt ChatGPTs Tests, die M420-Tests, die Claude-Host-Tests und die **EEPROM-Kerntests** aus, klont den OEM, integriert alles in einen Baum, baut für den STM32 und druckt die Größe gegen Ihre 282-Werte.
5. Danach unter **Artifacts** die beiden Pakete `SV04_NEXT_283_integrated_backend_STM32_LOGS_NO_FLASH` und `…_integrated_failclosed_…` laden. Es werden **nur Logs** hochgeladen, nie Firmware.

## Was ich danach brauche (je Profil)

`result.txt` (`BUILD_EXIT=…`), `errors.txt`, `warnings.txt`, `ram_flash.txt`, **`size_vs_282.txt`**, **`eeprom_strings.txt`**, `git_diff_check.txt`, bei Rot zusätzlich `claude_sim_tests.txt` und `eeprom_core_tests.txt`.

**Lesehilfe:** `size_vs_282.txt` zeigt Flash- und RAM-Zuwachs gegenüber Ihren 282-Builds. `eeprom_strings.txt` zählt die neuen Meldungen `Auto60 EEPROM` im Abbild; beide Profile sollten einen Wert **> 0** zeigen (das EEPROM-Teil ist auch im fail-closed-Profil kompiliert). Ein rotes Profil ist **kein** Beweis, dass der Code falsch ist; ich werte die Meldung aus und korrigiere. Ein erfolgreicher Build ist **kein** Beweis, dass die Hardware funktioniert (`HARDWARE_ABNAHME_283.md`).
