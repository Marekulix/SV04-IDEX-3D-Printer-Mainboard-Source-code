# Hardware-Abnahme 283 (EEPROM-Teil) – NICHT DURCHGEFÜHRT (Plan, kein Ergebnis)

**Stand: HARDWARE GEPRÜFT = NEIN. STM32 GEBAUT = NEIN.** Dieses Dokument ist ein Plan. Er wird erst relevant, wenn der STM32-Build beider Profile in `283.yml` grün ist und Sie die Firmware **bewusst selbst und getrennt vom Produktivgerät** einspielen. Dieses Paket enthält keine Firmware, `FLASH_ALLOWED=NO`.

## Voraussetzungen und Schutz
* Möglichst ein Gerät, das nicht für laufende Drucke gebraucht wird. **Vorher sichern** (`M503` mitschreiben: besonders `M851` Z-Offset, `M218` Hotend-Offset, das Mesh über `M420 V`).
* Bett leer, Düsen kalt, kein Filament, Netzschalter in Reichweite.
* **Bei jedem unerwarteten Geräusch, Anschlag oder Verhalten sofort Netzschalter; nicht weiterprüfen, sondern melden.**
* Ein Schritt gilt nur dann als bestanden, wenn das erwartete Ergebnis eintritt **und nichts abweicht**.
* Serielle Ausgaben mitschreiben (Zeilen `Auto60 EEPROM: …`).

## Schritte (in dieser Reihenfolge)
| # | Schritt | Erwartung | Abbruch bei |
|---|---|---|---|
| H0 | Start, `M115`, `M503` mit der Sicherung vergleichen, `M1060 S3` | `block=100+<datasize>`, `kapazitaet=2048`, `start_ergebnis=0`. **`datasize` notieren.** Steht `journal_platz=NEIN`, ist die Absicherung nicht verfügbar (siehe Analyse §6) – dann hier stoppen und melden. | abweichende Werte |
| H1 | `M1060 S2` (lesende Rohprüfung gegen das RAM-Mesh) | `=> OK` (primary=5, mesh_found=1, zoff_found=1). Bei noch nie gespeichertem EEPROM: `ABWEICHUNG` ist erwartbar. | – |
| H2 | **Auto60-Lauf** über das Display, beaufsichtigt (Bett 60 °C): Start → Aufheizen → Referenz → Messung → Endskript → Speichern → Prüfen → Fertig | Erfolgsseite erst am Ende; die Pause beim Speichern/Journal (erster Lauf mehrere Sekunden) ist normal. Danach `M1060 S3`: `letzter_abschluss=1`; `M1060 S2`: `=> OK`; `M503`: **nur das Mesh geändert**, `M851` unverändert. | Z-Offset geändert; Erfolgsseite vor Ende; Bett über Soll ohne Auto60-Zustand |
| H3 | **Neustart** (Netz aus/an) | `M1060 S3`: `start_ergebnis=0`; `M1060 S2`: `=> OK` (gespeichertes Mesh wurde wiederhergestellt). Nivellierung ist nach dem Neustart **aus** (OEM): `M420 S1` einschalten und `M420 V` prüfen. | Mesh weicht ab |
| H4 | Auto60 **zweimal hintereinander** | Zweiter Lauf eigenständig; die Dauer des Speicherns ist kürzer (Journal schreibt nur Unterschiede). | zweiter Lauf startet ohne Referenz |
| H5 | Auto60 per **Touch abbrechen**: (a) beim Aufheizen, (b) während der Referenzfahrt | kein EEPROM-Schreibvorgang: `M503` und `M1060 S3` (`letzter_abschluss`) unverändert | EEPROM-Wert geändert |
| H6 | `M1060 S2` nach H5 | `=> OK` | ABWEICHUNG |

## Nur mit zusätzlicher Vorsicht (optional, erst nach H0–H6)
* **Stromausfall während des Speicherns** (Test der Journal-Absicherung): nur mit gesicherten Werten und nur wenn H0 `journal_platz=ja` zeigte. Das Zeitfenster ist kurz (Sekunden beim ersten Lauf). Nach dem Wiedereinschalten: `M1060 S3` zeigt `start_ergebnis=2` (zurückgespielt) oder `0`/`1`; `M1060 S2` und `M503` zeigen entweder **vollständig den alten oder vollständig den neuen** Stand. **Nicht** künstlich beschädigte Daten schreiben.
* **Anwender-`M500` während Auto60 oder Stromausfall bei Anwender-`M500`:** nicht prüfen; dort gibt es **keine** Absicherung.

## Was Sie mir zurückmelden sollten
Pro Schritt Bestanden/Abgebrochen, das serielle Log und Auffälligkeiten (Geräusch, Verzögerung, Display). Erst auf dieser Grundlage darf sich eine Prozentzahl ändern.
