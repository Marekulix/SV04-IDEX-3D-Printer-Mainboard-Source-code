# Hardware-Abnahme 277 – NICHT DURCHGEFÜHRT (Plan, kein Ergebnis)

**Stand: HARDWARE GEPRÜFT = NEIN.** Dieses Dokument ist ein Plan. Nichts darin wurde am Gerät ausgeführt. Er wird erst relevant, wenn (1) der STM32-Build aller Profile in `277.yml` grün ist und (2) Sie die Firmware bewusst selbst und getrennt vom Produktivgerät einspielen. `FLASH_ALLOWED=NO` steht in jedem Profil; dieses Paket enthält keine Firmware.

## Voraussetzungen und Schutz

* Möglichst **ein Gerät, das nicht für laufende Drucke gebraucht wird**; sonst vorher Sicherung der EEPROM-Werte (`M503` mitschreiben, besonders `M851` (Z-Offset), `M218` (Hotend-Offset T1) und die Mesh-Werte `G29 T`/`M420 V`).
* Druckbett leer, Düsen **kalt**, kein Filament eingelegt, Netzschalter/Notaus in Reichweite, beide Wagen von Hand frei beweglich.
* Bei **jedem** unerwarteten Geräusch, Anschlag, Verklemmen oder Bewegung: sofort Netzschalter. Danach nicht weiterprüfen, sondern melden.
* Je Schritt gilt: Bestanden nur, wenn das **erwartete Ergebnis** eintritt **und** nichts davon abweicht. Ein „fast“ ist ein Abbruchgrund.

## Schritte (in dieser Reihenfolge; nach jedem Schritt Ergebnis notieren)

| # | Schritt | Erwartung | Abbruch bei |
|---|---|---|---|
| H0 | Start, `M115`, `M503` ausgeben und mit der Sicherung vergleichen | identische Werte; Firmware meldet den neuen Stand | abweichender Z-Offset oder Mesh |
| H1 | **Modus 1 (AUTO_PARK), `G28 X`**, Wagen in Ausgangsstellung, Hand am Netzschalter | T1 referenziert, dann T0; kein Anschlag am Nachbarwagen | Wagen berühren einander |
| H2 | **volles `G28`** (Modus 1) | T1, T0, Y, Z mit BLTouch; Serial-Log zeigt keinen Fehler; Display zeigt Referenz erfolgreich | Z-Fahrt ohne vorherige X-Referenz |
| H3 | `M503`/`M420 V` nach H2 | **unverändert** gegenüber H0 (kein Schreiben durch G28) | geänderter Wert |
| H4 | **Modus 0 (FULL_CONTROL)**, volles `G28` | wie H2 | wie H2 |
| H5 | **Modus 2 (DUPLICATION)** und **Modus 3 (MIRRORED)**, je volles `G28` (Betten frei!) | Z wird gefahren (in 276 wurde Z hier verweigert); danach ist die Duplizierung **wieder an** | Wagen fahren in der Duplizierung gegeneinander |
| H6 | `G28 Z` allein | wird **verweigert** (Meldung), keine Bewegung | Bewegung |
| H7 | Nach H6: Nivellierung prüfen (`M420 V`); sie ist **aus** (bekannte Eigenschaft, `OFFEN_UND_BLOCKIERT_277.md` B/3). Mit `M420 S1` wieder einschalten | wie beschrieben | – |
| H8 | **Auto60 Probelauf** über das Display, Bett/Zimmer überwacht: Start → Aufheizen → Referenz → Messung → Endskript → Fertig | Reihenfolge wie im Log der Simulation (`I01`); danach genau **ein** EEPROM-Schreibvorgang, Z-Offset unverändert | Bett über 65 °C ohne Auto60-Zustand |
| H9 | Auto60 – **Abbruch per Touch** (a) beim Aufheizen, (b) während der Referenzfahrt, (c) während der Messung. Erst nach (a) und (b) mit (c) fortfahren | (a) sofort abgebrochen; (b), (c) laufende Fahrt endet normal, **dann** Abbruch, **kein** EEPROM-Schreiben, altes Mesh bleibt | EEPROM-Wert geändert |
| H10 | Auto60 **zweimal hintereinander** nach Abschluss | jeder Lauf ist eigenständig; zweiter Lauf ohne Reste des ersten | zweiter Lauf startet ohne Referenz |
| H11 | Zustand nach `G29`-Endskript beobachten (`G28 XY`) | beide Wagen referenzieren erneut, T0 aktiv, Mesh wird danach bewertet | Wagen verklemmt |
| H12 | `M503` nach H8–H11 gegen die Sicherung vergleichen | nur Mesh/Level wie erwartet verändert | Z-Offset (`M851`) verändert |

## Nur mit zusätzlicher Vorsicht (optional, erst nach H0–H12)

* **BLTouch-Fehler:** Das Gerät **bei ausgeschaltetem Strom** abziehen und **neu starten**, dann `G28`. Im OEM endet das im `kill()` (siehe Befund O3); erwartet wird ein sauberer Stopp, nicht eine Bewegung. Keinen Sensorfehler durch Festhalten des Stiftes erzeugen.
* **Endschalter-Ausfall:** nicht künstlich herbeiführen. Das Modell der Software zeigt nur, dass die Software dann stoppt (`I08`).

## Was Sie mir zurückmelden sollten (ohne Auswertung durch mich)

Pro Schritt: Bestanden / Abgebrochen, das Serial-Log (falls verfügbar) und Auffälligkeiten (Geräusch, Verzögerung, Display). Erst auf dieser Grundlage darf sich eine Prozentzahl ändern.
