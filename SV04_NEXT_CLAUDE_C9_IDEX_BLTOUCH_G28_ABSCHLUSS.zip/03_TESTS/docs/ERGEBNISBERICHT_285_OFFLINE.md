# SV04 NEXT 285 (Entwicklungsstand auf der unveränderten Basis 284) – Ergebnisbericht zum Offline-Großauftrag

**Nicht flashbar. STM32 GEBAUT = NEIN** (in dieser Umgebung unmöglich: keine ARM-Toolchain, kein PlatformIO, kein GitHub/Netz; geprüft). **HARDWARE GEPRÜFT = NEIN.** Alles „getestet“ ist Host-Simulation um die echten Quelldateien (Adapter, Koordinator, EEPROM-Kern, echte `G28.cpp`/`G29.cpp`, byte-genaues EEPROM-Modell, HMI-Modell der 16 Zellen). Der **Stand 284 ist unverändert** (Hash); 285 ist ein getrennter Entwicklungsstand, die Nummer ist **provisorisch**.

## 1. Ergebnis

Vier echte Funde in meinem Zuständigkeitsbereich, alle behoben und abgesichert, ein Verdacht widerlegt, eine Entwurfsentscheidung als Option statt stillschweigender Änderung. Es wurde **nichts** an M420, Bedleveling oder Planner geändert (kein separater Interface-Patch nötig).

| Nr | Fund | Beleg | Maßnahme |
|---|---|---|---|
| **F1** | **Veraltetes Display nach Stromausfall:** Nach einem Stromausfall im Speichern und der Start-Wiederherstellung steht im RAM wieder das gültige alte Mesh, das Display zeigte aber **lauter Nullen** (die OEM-Bootschleife sendet vor der Wiederherstellung die Standardwerte, danach wurde nichts mehr gesendet). Der Benutzer hätte sein Mesh für verloren gehalten. | Test `OP01` (vor dem Fix: `Display=[0,0,0,0,0] ≠ RAM=[160,210,…]`) | Nach dem Neuladen wird das Mesh an die 16 Zellen gesendet. Mutant `OM01` erkannt. |
| **F2** | **Touch-Abbruch nicht an die Sitzung gebunden:** Ein Touch im Leerlauf oder ein später Touch nach dem Ende eines Laufs konnte den **nächsten** Lauf sofort abbrechen. | Tests `OP11`, `OP12`; Mutant `OM05` (= altes 284-Verhalten) verhält sich nachweislich anders | Abbruch nur **während** eines Laufs, an die Sitzung gebunden, beim Start verworfen; mehrere Touches = ein Abbruch. |
| **F3** | **Schutzstatus des EEPROM wurde nicht gezeigt:** Ohne Platz für das Journal speicherte Auto60 stillschweigend ungeschützt (`SV04_CLAUDE_EEPROM_REQUIRE_JOURNAL=0`). | Tests `OP20`–`OP23`; Mutanten `OM02`–`OM04` erkannt | Der Schutz wird **beim Start und noch einmal bei der Speicherfreigabe** gemeldet („Undo-Journal“ / „KEINER, WARNUNG: …Stromausfall kann den Einstellungsblock zerstören“); `M1060 S3` zählt Speicherungen ohne Journal. Das Flag wird **nirgends** als ausfallsicher dargestellt. |
| **F4** | **Abbruch nach der Aktivierung hinterlässt ein nie gespeichertes Mesh:** Bricht man in `ENABLING`/`SAVE_PENDING` ab, bleibt das validierte, aber ungespeicherte Mesh aktiv (EEPROM bleibt alt; Display und RAM konsistent). Die Kerntests `E25`/`E27` halten das als **bewusste Entscheidung** fest. | Test `OP14` | **Nicht umgekehrt.** Neue Option `SV04_CLAUDE_ROLLBACK_AFTER_ENABLE` (Standard 0 = wie 284; 1 = altes Mesh kommt zurück, solange nichts gespeichert ist). Getestet in beiden Stellungen (`K05`–`K08`, `OP14b`) und **gegen die echten V2/V4-Funktionen** (`OP17`: auch bei leerem EEPROM kein Notstopp). **Entscheidung beim Nutzer.** |
| – | **Verdacht widerlegt:** „Nach Rollback auf ein ungültiges altes Mesh bleiben verworfene Werte im Display.“ | Test `OP02` | Display zeigt den Startzustand; **kein** Handlungsbedarf. |

## 2. DWIN: die 16 Anzeigeobjekte (Punkt 2 und Abnahmekriterium 1)

Die „16 Objekte“ sind die Mesh-Zellen `0x1100…0x111E`. **Kein Element war im Produktionscode ungebunden.** Es gibt **keinen Namenskonflikt**: In der OEM ist nur `AUTO_BED_LEVEL_1POINT_VP = 0x1100` definiert (`LCD_RTS.h:72`), `2POINT…16POINT` sind auskommentiert; alle Zellen werden über `AUTO_BED_LEVEL_1POINT_VP + k*2` adressiert. Die OEM-Empfangstabelle enthält `ChangePageKey = 0x110e` (Zelle 7); das ist eine **OEM-eigene** Koexistenz, die weder bestätigt noch ausgeräumt werden kann, solange das HMI-Projekt fehlt. Objekttyp, Dezimalstellen und Vorzeichen im HMI sind ebenfalls **unbewiesen**; alles Nachfolgende gilt nur für die MCU-Seite.

| k | VP | Zelle (x,y) | Position (transkribiert) | Wortbreite | MCU-Anbindung im Produktionscode | HMI-seitig |
|---|---|---|---|---|---|---|
| 0 | `0x1100` | (3, 0) | (202, 440) | 1 Wort (16 Bit, Zweierkomplement) | **verdrahtet**: OEM-Live-G29 (`RTS_SndData(z*1000, AUTO_BED_LEVEL_1POINT_VP + k*2)`), OEM-Bootschleife, Auto60-Rollback, Start-Wiederherstellung (neu) | **unbewiesen** (kein HMI-Projekt) |
| 1 | `0x1102` | (2, 0) | (141, 440) | 1 Wort (16 Bit, Zweierkomplement) | **verdrahtet**: OEM-Live-G29 (`RTS_SndData(z*1000, AUTO_BED_LEVEL_1POINT_VP + k*2)`), OEM-Bootschleife, Auto60-Rollback, Start-Wiederherstellung (neu) | **unbewiesen** (kein HMI-Projekt) |
| 2 | `0x1104` | (1, 0) | (76, 440) | 1 Wort (16 Bit, Zweierkomplement) | **verdrahtet**: OEM-Live-G29 (`RTS_SndData(z*1000, AUTO_BED_LEVEL_1POINT_VP + k*2)`), OEM-Bootschleife, Auto60-Rollback, Start-Wiederherstellung (neu) | **unbewiesen** (kein HMI-Projekt) |
| 3 | `0x1106` | (0, 0) | (10, 440) | 1 Wort (16 Bit, Zweierkomplement) | **verdrahtet**: OEM-Live-G29 (`RTS_SndData(z*1000, AUTO_BED_LEVEL_1POINT_VP + k*2)`), OEM-Bootschleife, Auto60-Rollback, Start-Wiederherstellung (neu) | **unbewiesen** (kein HMI-Projekt) |
| 4 | `0x1108` | (0, 1) | (10, 340) | 1 Wort (16 Bit, Zweierkomplement) | **verdrahtet**: OEM-Live-G29 (`RTS_SndData(z*1000, AUTO_BED_LEVEL_1POINT_VP + k*2)`), OEM-Bootschleife, Auto60-Rollback, Start-Wiederherstellung (neu) | **unbewiesen** (kein HMI-Projekt) |
| 5 | `0x110a` | (1, 1) | (76, 390) | 1 Wort (16 Bit, Zweierkomplement) | **verdrahtet**: OEM-Live-G29 (`RTS_SndData(z*1000, AUTO_BED_LEVEL_1POINT_VP + k*2)`), OEM-Bootschleife, Auto60-Rollback, Start-Wiederherstellung (neu) | **unbewiesen** (kein HMI-Projekt) |
| 6 | `0x110c` | (2, 1) | (142, 390) | 1 Wort (16 Bit, Zweierkomplement) | **verdrahtet**: OEM-Live-G29 (`RTS_SndData(z*1000, AUTO_BED_LEVEL_1POINT_VP + k*2)`), OEM-Bootschleife, Auto60-Rollback, Start-Wiederherstellung (neu) | **unbewiesen** (kein HMI-Projekt) |
| 7 | `0x110e` | (3, 1) | (208, 390) | 1 Wort (16 Bit, Zweierkomplement) | **verdrahtet**: OEM-Live-G29 (`RTS_SndData(z*1000, AUTO_BED_LEVEL_1POINT_VP + k*2)`), OEM-Bootschleife, Auto60-Rollback, Start-Wiederherstellung (neu) | **unbewiesen** (kein HMI-Projekt) |
| 8 | `0x1110` | (3, 2) | (208, 340) | 1 Wort (16 Bit, Zweierkomplement) | **verdrahtet**: OEM-Live-G29 (`RTS_SndData(z*1000, AUTO_BED_LEVEL_1POINT_VP + k*2)`), OEM-Bootschleife, Auto60-Rollback, Start-Wiederherstellung (neu) | **unbewiesen** (kein HMI-Projekt) |
| 9 | `0x1112` | (2, 2) | (142, 340) | 1 Wort (16 Bit, Zweierkomplement) | **verdrahtet**: OEM-Live-G29 (`RTS_SndData(z*1000, AUTO_BED_LEVEL_1POINT_VP + k*2)`), OEM-Bootschleife, Auto60-Rollback, Start-Wiederherstellung (neu) | **unbewiesen** (kein HMI-Projekt) |
| 10 | `0x1114` | (1, 2) | (76, 340) | 1 Wort (16 Bit, Zweierkomplement) | **verdrahtet**: OEM-Live-G29 (`RTS_SndData(z*1000, AUTO_BED_LEVEL_1POINT_VP + k*2)`), OEM-Bootschleife, Auto60-Rollback, Start-Wiederherstellung (neu) | **unbewiesen** (kein HMI-Projekt) |
| 11 | `0x1116` | (0, 2) | (10, 390) | 1 Wort (16 Bit, Zweierkomplement) | **verdrahtet**: OEM-Live-G29 (`RTS_SndData(z*1000, AUTO_BED_LEVEL_1POINT_VP + k*2)`), OEM-Bootschleife, Auto60-Rollback, Start-Wiederherstellung (neu) | **unbewiesen** (kein HMI-Projekt) |
| 12 | `0x1118` | (0, 3) | (10, 290) | 1 Wort (16 Bit, Zweierkomplement) | **verdrahtet**: OEM-Live-G29 (`RTS_SndData(z*1000, AUTO_BED_LEVEL_1POINT_VP + k*2)`), OEM-Bootschleife, Auto60-Rollback, Start-Wiederherstellung (neu) | **unbewiesen** (kein HMI-Projekt) |
| 13 | `0x111a` | (1, 3) | (76, 290) | 1 Wort (16 Bit, Zweierkomplement) | **verdrahtet**: OEM-Live-G29 (`RTS_SndData(z*1000, AUTO_BED_LEVEL_1POINT_VP + k*2)`), OEM-Bootschleife, Auto60-Rollback, Start-Wiederherstellung (neu) | **unbewiesen** (kein HMI-Projekt) |
| 14 | `0x111c` | (2, 3) | (142, 290) | 1 Wort (16 Bit, Zweierkomplement) | **verdrahtet**: OEM-Live-G29 (`RTS_SndData(z*1000, AUTO_BED_LEVEL_1POINT_VP + k*2)`), OEM-Bootschleife, Auto60-Rollback, Start-Wiederherstellung (neu) | **unbewiesen** (kein HMI-Projekt) |
| 15 | `0x111e` | (3, 3) | (202, 290) | 1 Wort (16 Bit, Zweierkomplement) | **verdrahtet**: OEM-Live-G29 (`RTS_SndData(z*1000, AUTO_BED_LEVEL_1POINT_VP + k*2)`), OEM-Bootschleife, Auto60-Rollback, Start-Wiederherstellung (neu) | **unbewiesen** (kein HMI-Projekt) |

Beleg MCU-Seite (Host-Simulation, echte `RTS_SndData`): `V01` (16 eindeutige gerade Adressen, nur die Basis definiert), `V02` (Empfangstabelle), `V03` (Katalog = beobachtete Zuordnung), `V05` (alle Rahmen wohlgeformt), `V06` (Fortschrittssymbol zählt 1–16 und geht jeder Zelle voraus), `V07` (Auto60 schreibt nur Symbol, Zellen und Seitenwechsel), `V09` (Wiederherstellung sendet exakt die OEM-Bootbytes), `V10`/`V12` (Werte als Zweierkomplement, ungültige Werte nie als falscher Rahmen), neu `OP01`/`OP02`. **Aktualisierungstakt:** ereignisgesteuert (je Messpunkt, beim Boot, beim Rollback, nach der Start-Wiederherstellung); kein periodisches Senden der Zellen.

## 3. Auto60-Bedienung: was das Display zeigt und was nicht (Punkt 3)

Ohne HMI-Projekt gibt es für die meisten Phasen **kein eigenes Anzeigefeld**. Es wurde **keines erfunden**; kein Test-Double im Produktionspfad, kein Erfolg vor der Bestätigung.

| Zustand | DWIN | Seriell / `M1060 S3` |
|---|---|---|
| Start, Aufheizen 60 °C, Stabilisieren | nichts durch Auto60 (OEM-Temperaturanzeige) | `Auto60 state=…`, EEPROM-Schutzstatus (neu) |
| Homing (G28) | nichts durch Auto60 | Zustand, P1-Ergebnis |
| Messen | Seite 38 + Symbol 1, Fortschritt 1–16, die 16 Zellwerte (OEM-Live-G29) | – |
| Validieren, Aktivieren | Seite 38 bleibt | Zustand |
| Speichern, Prüfen | Seite 38 bleibt; **keine** Erfolgsseite | Schutzstatus bei der Freigabe (neu), Journal-Platz |
| **Erfolg** | Seite 22 **nur nach verifiziertem Speichern** | `VERIFIED` |
| Fehler / Abbruch | Symbol 0 + Seite 28 (**Annahme**, offen) + altes Mesh wieder gesendet | Grund |
| Nach Stromausfall + Neustart | **Mesh wird neu gesendet (neu)** | `M1060 S3` |

## 4. Abbruch (Punkt 4 und Abnahmekriterium 2)

Der Abbruch steht am **Anfang von `RTS_HandleData`** (`diffs/2_OVERLAY_LCD_RTS_OEM_nach_277.patch`), also **vor** jeder OEM-Logik; die gedrückte Taste wird verworfen. Er hängt nicht an einer Touch-Sperre.

| Zustand | Wirkung | Test |
|---|---|---|
| HEATING, STABILIZING, VALIDATING | sofort `CANCELLED`, altes Mesh | `OP14`, `I19`–`I22` |
| HOMING_PENDING, PROBING, ENABLING | vorgemerkt, nach dem laufenden Schritt `CANCELLED` (ein laufendes G28/G29 lässt sich nicht physisch stoppen, nur seine Folgen) | `I20`–`I22`, `OP10` |
| SAVE_PENDING (vor dem Speichern) | sofort `CANCELLED`, **kein** EEPROM-Byte | `OP14` |
| nach dem ersten `save()` / VERIFYING | **nicht abbrechbar** (ehrlich: es wird verifiziert, Erfolg oder Rückspielen) | `OP14` |

Zusätzlich: 7 Touches im selben Moment = ein Abbruch (`OP10`); Touch im Leerlauf wirkt nie auf den nächsten Lauf (`OP11`); später Touch vor einem neuen Lauf (`OP12`); abgebrochener Lauf sofort neu startbar (`OP13`); Touch + `M1060 S0` zusammen (`OP15`); wartendes/verspätetes G28 bewegt nichts (`OP16`); Stromausfall und Neustart (`E01`, `OP30`). Alte Sitzungs-IDs: Rückmeldungen falscher Sitzungen werden ignoriert und gezählt (`STALE`).

## 5. EEPROM (Punkte 5–7)

* **Bedarf:** `EEPROM_OFFSET + datasize + 8 + 16 + datasize ≤ 2048`, also `datasize() ≤ 962`. Der echte Wert des Ziel-Builds ist **unbekannt**; `M1060 S3` zeigt `journal_platz=ja/NEIN`.
* **Laufzeit:** der erste Lauf schreibt **877 geänderte Bytes** (Journal ca. 816 + Mesh/Kopf ca. 61), danach nur Unterschiede; bitgleiche Wiederholung schreibt nichts (`OP12`). Dauer **geschätzt 4–6 s** (je Byte 5–7 ms laut Treiberquelltext), **nicht gemessen**; die Heizung wird dabei bedient (8-Byte-Stücke mit `safe_delay`).
* **Ohne Platz:** Standard speichert ohne Journal, meldet das laut (F3) und zählt es; mit `REQUIRE_JOURNAL=1` startet Auto60 nicht. `REQUIRE_JOURNAL=0` ist **keine** Ausfallsicherheit.
* **Roh-Rücklesung:** `persistentStore`, eigene CRC, Mesh bitgleich, Z-Offset, Version `V85`; ändert weder RAM-Mesh, Nivellierung noch Fahrzustand (`BL05`, `OP33`); `settings.load()` nur nach einer Start-Wiederherstellung.
* **Datensätze:** ungültig (CRC), fremd, andere Version (`V84`), unterbrochen (`ERR`), halb überschrieben (`V8R`): `M1060 S2` meldet `ABWEICHUNG` mit Code, `S2/S3` schreiben nie, Auto60 startet dort nicht (`OP33`); fehlendes Journal (`OP31`).
* **Stromausfall:** toter Bus beim Start schreibt nichts, die Wiederherstellung geht nicht verloren (`OP30`); Schreibfehler an jeder der letzten 12 Änderungen inkl. Kopf (`OP32`); unterbrochene Wiederherstellung (`E02`); die Grenze alt/neu liegt exakt am letzten geänderten Byte (`E01`).

## 6. Tests (Rohlogs: `claude/06_EVIDENCE/host/`)

| Prüfung | Ergebnis |
|---|---|
| C++-Kerntests Koordinator / EEPROM-Kern | 151/151 · 33/33 |
| Host-/Pipeline-/Workflow-Tests | 35/35 |
| Simulationstests (darunter 19 Betrieb `OP*`, 10 Bedlevel, 23 EEPROM) | 167/167 |
| ChatGPT: P1 268–276, M420 V4–V6 + OEM-Anker, Integration 281 | bestanden (Logs 10–12) |
| Mutationstests, **0 Überlebende** | Kern 24 · Adapter 12 · Backend 10 · Koordinator 14 · EEPROM-Adapter 11 · Bedlevel 6 · Betrieb 5 · EEPROM-Kern 17 (aus 284, Quelle unverändert); dazu geprüfte gleichwertige Fälle (Berichte `07*`) |

Dabei **drei Testlücken geschlossen** (K08, Betriebsszenarien) und mehrere Mutantenanker nach meinen Änderungen nachgeführt. Ein Fehlversuch meinerseits: meine erste Fassung der Rollback-Option hätte `E25`/`E27` (bewusste 284-Entscheidung) umgekehrt; ich habe sie als Option mit Standard „wie 284“ neu gebaut.

## 7. STM32-Vorbereitung (Punkt 9)

Patch-Reihenfolge **unverändert**: `integrate_281.py` ruft `apply_268…276` → `apply_277_p1` → Claude-Overlay (`apply_277.py --profile integrated`) → M420 V2–V6. Workflow `285.yml` wird mit `claude/tools/make_workflow_283.py --version 285` aus dem bewährten `282.yml` erzeugt (nur Name, ZIP-Name/Hash, Artefaktname, Beschriftung weichen ab); er enthält den **Beweisschritt Host-Code = Build-Code** (`compare_bedlevel_real.py`) und die Größenauswertung gegen die 282-Werte. **Nicht ausgeführt:** OEM-Klon, `integrate_281.py` auf dem echten Baum, PlatformIO; die ohne Netz ausführbaren Schritte liefen im Probelauf.

## 8. Offen / Entscheidungen

1. **STM32-Build beider Profile** und Hardwareprüfung (Plan: `HARDWARE_ABNAHME_283.md`; zusätzlich prüfen: Abbruch im Zustand `ENABLING` mit beiden Stellungen der Rollback-Option, Anzeige des Mesh nach einem echten Stromausfall im Speichern).
2. **HMI-Projekt** nötig für: Objekttyp/Dezimalstellen/Vorzeichen der 16 Felder, die `0x110e`-Koexistenz, eigene Anzeigefelder für Phasen und EEPROM-Schutz, Bestätigung von Seite 28.
3. **Rollback-Option** `SV04_CLAUDE_ROLLBACK_AFTER_ENABLE` (Standard 0) und **`SV04_CLAUDE_EEPROM_REQUIRE_JOURNAL`** (Standard 0): Nutzerentscheidung.
4. **Versionsnummer** 285 (provisorisch); Änderung über `--version N`.
5. `MarlinCore.cpp` lag nicht vor: ob `RTSUpdate()` während `planner.synchronize()` in G28/G29 läuft, ist unbelegt; wenn nicht, greift der Abbruch erst nach dem laufenden Schritt.

## 9. Fortschritt je Codeänderung

| Änderung | Datei | Nachweis | Kategorie |
|---|---|---|---|
| Mesh nach Start-Wiederherstellung neu senden | `sv04_claude_auto60_marlin.inc` | `OP01`, Mutant `OM01` | programmiert + lokal getestet |
| Sitzungsgebundener Touch-Abbruch | dto. | `OP10`–`OP13`, `OP15`, Mutant `OM05` | programmiert + lokal getestet |
| EEPROM-Schutzstatus vor der Speicherfreigabe | dto. | `OP20`–`OP23`, `OM02`–`OM04` | programmiert + lokal getestet |
| Rollback-Option nach Aktivierung | `sv04_claude_auto60_core.h` (+ Adapter) | `K05`–`K08`, `OP14b`, `OP17`, `CK13`–`CK15` | programmiert + lokal getestet |
| Neue Betriebs-, Wiederherstellungs- und Abbruchtests | `test_ops_a60.py`, Treiber | 19 Tests | lokal getestet |

Die Fortschrittsanzeige (P1 75 · P2 75 · P3 50 · P4 90 · P5 70 · P6 60 · Gesamt 70 %) **ändere ich nicht eigenmächtig**; die Änderungen oben sind entwicklungsseitig Beiträge zu P3 (Abbruch), P5/P6 (EEPROM) und zur Anzeige, ohne Zielbuild und Hardwarebeleg aber **keine** Hardwarefreigabe. Eine Pauschal-Null ist das nicht: jede Zeile oben ist programmiert und geprüft.

## 10. Reproduzieren

`python3 claude/tools/verify_manifest.py .` · `python3 claude/tools/run_all_tests_a60.py --stages core,host,sim` (ca. 100 s) · `python3 claude/tools/make_status_285.py` (prüft jeden genannten Nachweis gegen die Rohlogs) · Mutationen klassenweise aus `claude/`, z. B. `OPS_MUT_SLICE=0:3 python3 -m unittest 04_TESTS.test_mutations_a60.OpsMutants`.
