# GitHub-Lauf 277 – mit dem Android-Tablet

Es gibt **genau zwei Dateien** zum Hochladen. Sie sind im Ausgabeordner (nicht im ZIP): `277.yml` und `SV04_NEXT_277.zip`.

1. In Ihrem Repository im Browser **Add file → Upload files** und `SV04_NEXT_277.zip` in den **Wurzelordner** laden (Name genau so).
2. `277.yml` nach `.github/workflows/277.yml` legen: **Add file → Create new file**, als Dateiname `.github/workflows/277.yml` eintippen (die Schrägstriche legen die Ordner an), den Inhalt von `277.yml` einfügen, speichern. (Oder wie bei 276 hochladen, falls das bei Ihnen funktioniert hat.)
3. Reiter **Actions** → Workflow „277 – SV04 P1 IDEX BLTouch + Auto60 Integration STM32 – NO FLASH“ → **Run workflow**.
4. Der Workflow prüft zuerst den fest eingetragenen SHA-256 des ZIPs (falls Sie ein anderes ZIP hochladen, bricht er mit einer klaren Meldung ab), führt die Tests aus (ChatGPT 268–276 sowie die Host-Tests) und baut dann **vier** Profile: `baseline_oem` (unverändert, zum Vergleich), `p1_corrections`, `integrated_backend`, `integrated_failclosed`.
5. Wenn fertig: unter **Artifacts** die fünf Ergebnispakete laden (`SV04_NEXT_277_HOST_TESTS` und je Profil `…_STM32_LOGS_NO_FLASH`). Es werden **nur Logs** hochgeladen, nie Firmware.

## Was ich danach brauche

* je Profil `result.txt` (`BUILD_EXIT=…`), `errors.txt`, `warnings.txt`, `ram_flash.txt`, `diff_check.txt`, `symbols.txt`, `backend_string_count.txt`
* aus `SV04_NEXT_277_HOST_TESTS` die Datei `host_sim_tests.txt` (falls rot) und `chatgpt_patch_tests.txt`

**Lesehilfe:** Die Zeichenkette `G28 X Y Z` steht im Quelltext nur im Produktions-Backend. `backend_string_count.txt` von `integrated_backend` muss deshalb **um 1 höher** sein als bei `baseline_oem` und `integrated_failclosed` (die beiden sollten gleich sein; ich kann nicht ausschließen, dass andere Marlin-Teile dieselbe Zeichenkette enthalten, darum der Vergleich statt eines Absolutwerts). `baseline_oem` hat keine `SV04Claude_*`-Symbole. Ein rotes Profil ist **kein** Beweis, dass der Code falsch ist; ich werte die Meldung aus und korrigiere.

## Wenn der Dateiname 277 schon vergeben ist

`python3 claude/tools/make_workflow_277.py --zip-sha256 <SHA256 des neuen ZIP-Namens> --out NEU.yml` erzeugt eine neue Workflow-Datei; der Dateiname im ZIP muss dann zum Namen im Workflow passen (Zeilen mit `SV04_NEXT_277.zip`).
