# SV04 NEXT 283 – Analyse der EEPROM-Speicherung (Punkt 5 und 6), belegt am OEM-Code

Alle Zeilenverweise beziehen sich auf die mitgelieferten OEM-Dateien in `claude/01_BASELINE/OEM_FILES/Marlin/` (Sovol, Commit 1867fcba…). **Nichts davon wurde am Gerät geprüft.** Die Ende-zu-Ende-Läufe sind eine Host-Simulation mit einem byte-genauen Modell des BL24CXX-Treibers und von Marlins `save()/validate()/load()`.

## 1. Hardware und Treiber
| Befund | Beleg |
|---|---|
| Board `BOARD_CREALITY_V4`, EEPROM **I²C 24C16, 2 KB** (`MARLIN_EEPROM_SIZE 0x800`), Treiber BL24CXX | `Configuration.h:146`, `src/pins/stm32f1/pins_CREALITY_V4.h:46-55` |
| `write_data()` schreibt **nur geänderte Bytes**, liest jedes Byte **nach**; bei Abweichung Rückkehr **mit `true` = Fehler** und ohne `pos` weiterzuzählen | `HAL/STM32F1/eeprom_bl24cxx.cpp:49-67` |
| `read_data()` meldet **nie** einen Lesefehler (liefert bei einem Busfehler Müll) und zählt mit `do…while(--size)`: `size == 0` wäre ein Überlauf | ebd. `:69-79` |
| je geändertes Byte ca. 5–7 ms; `safe_delay()` (Heizung + Watchdog) nur beim 128. geänderten Byte **eines** Aufrufs | ebd. `:56` |
| `EEPROM_SETTINGS` an, `EEPROM_AUTO_INIT` **aus** (ein ungültiger Block bleibt bis zum nächsten M500 liegen) | `Configuration.h:1830, 1835` |
| `PRINTCOUNTER` und `SD_FIRMWARE_UPDATE` **aus** → der obere EEPROM-Bereich ist frei (Platz für das Journal) | `Configuration.h:2012`, `Configuration_adv.h:1528` |
| `RESTORE_LEVELING_AFTER_G28` an, `ENABLE_LEVELING_AFTER_G28` aus | `Configuration.h:1553-1554` |

## 2. Speicherformat (Marlin 2.0.x, `settings.cpp`)
* `EEPROM_OFFSET 100` und `EEPROM_VERSION "V85"` sind **lokale** `#define`s in `settings.cpp:39-40`, kein Header. Der Adapter trägt sie als `SV04_CLAUDE_EEPROM_OFFSET` / `SV04_CLAUDE_EEPROM_VERSION` nach; ein falscher Wert macht Auto60 **fail-closed** (kein gültiger Block gefunden, Test E19).
* Block = `version[4]` + `crc16` + Felder, **sequentiell ohne Füllbytes**; Größe = `datasize()` = `sizeof(SettingsData)` (`:517`), sonst `size_error` (`:642-648`).
* Reihenfolge um das Mesh (`:764-837`): MBL-Platzhalter (4 + 1 + 1 + 36) → **`probe.offset` (12 Bytes, `:785`)** → Planar-Platzhalter (36, `:796`) → Bilinear `gx, gy, spacing(8), start(8), z_values[16]` = **82 Bytes** (`:815-821`) → `ubl_active` (für Bilinear **immer `false`**, `:833`) + `storage_slot`.
* CRC = CRC-16/XMODEM über die Bytes **nach dem Kopf** bis zum Blockende (`working_crc`).
* `validate()` führt `_load()` mit `validating=true` aus: liest und prüft Version/Größe/CRC, **übernimmt nichts ins RAM**. `load()` = `validate()` + `_load()` + `postprocess()`: **überschreibt das gesamte RAM**.

## 3. Befunde
| Nr | Befund | Wirkung |
|---|---|---|
| **E1** | Die Rücklesung in Stand 282 ruft `settings.load()` (= M501) auf und vergleicht das danach überschriebene RAM. Das ist keine unabhängige Prüfung und lädt **alle** Einstellungen neu. | Punkt 6 nicht erfüllt. Ersetzt durch Rohlesung (`persistentStore`, eigene CRC, bitgleicher Mesh-Vergleich). |
| **E2** | `save()` schreibt **zuerst „ERR“** in den Kopf (`:655`) und Version+CRC **erst am Ende** (`:1461-1464`). | Ein Stromausfall mitten im Schreiben macht den **ganzen** Einstellungsblock ungültig; ohne `EEPROM_AUTO_INIT` bleibt er es bis zum nächsten M500 (Standardwerte beim Booten). → Undo-Journal. |
| **E3** | `EEPROM_WRITE` verwirft den Rückgabewert von `write_data` (`settings.h:127-130`). Schreibfehler werden nur **indirekt** über `size_error` bemerkt und **gar nicht**, wenn sie beim Schreiben des **Kopfes** (3 Versionsbytes + 2 CRC-Bytes) auftreten. | `save()` meldet dann Erfolg bei falschem Block: Test EE20 (5 von 5 solchen Fällen), die Rohlesung erkennt alle 66 Schreibfehlerpositionen. |
| **E4** | Der Zähler `written` in `write_data` ist **je Aufruf** lokal; `safe_delay()` kommt nur beim 128. geänderten Byte **eines** Aufrufs. | Schreibt man in Blöcken < 128 Bytes, würde das erste Anlegen des Journals (~800 Bytes ≈ mehrere Sekunden) die Heizung **nicht** bedienen. Der Adapter schreibt in 8-Byte-Stücken mit `safe_delay(1)` dazwischen. |
| **E5** | `primary_info` hielt jeden Kopf der Form `V<zz>` für „gültig“, sofern die CRC stimmt. Ein Block einer **anderen Version** (z. B. `V84` einer älteren Firmware) wäre stillschweigend überschrieben worden, obwohl Marlin ihn beim Laden ablehnt. | **Fehler im eigenen Kern (in 283 gefunden und behoben).** `Block.ver` wird vom Adapter mit `"V85"` gefüllt; eine andere Version ist `FOREIGN`. Tests E09, EE44/EE45, Mutanten EC07/AE03. |
| **E6** | `_load()` schaltet bei passendem Bilinear-Raster die Nivellierung **ab** (`settings.cpp:1676`) und stellt sie nicht wieder her; das Flag wird für Bilinear nicht gespeichert (`:833`). | Die Rücklesung in 282 hätte am Gerät die Nivellierung **zerstört** (Folge: `VERIFY_LEVELING`). Auch eine meiner früheren Simulationen hatte das Gegenteil angenommen. Die Rohlesung vermeidet es konstruktionsbedingt; Test E18 prüft `leveling=1` danach und kein `settings.load` im Ablauf. |

## 4. Umsetzung
1. **Rohlesung** (`sv04_claude_eeprom_core.h`, `sv04_claude_auto60_marlin.inc`): Block über `persistentStore` lesen, **eigene CRC**, Mesh über seine exakte 82-Byte-Folge finden (genau einmal), bitgleicher Vergleich mit dem Messabbild, `probe.offset` (12 Bytes) im Block gefunden, gespeicherte Zahlen endlich und im Rahmen, Version erwartet. Verändert weder RAM noch Konfiguration (`ram_unchanged`).
2. **Undo-Journal** am EEPROM-Ende: Kopie des letzten **gültigen** Blocks + 16-Byte-Kopf, der **zuletzt** gültig und **zuerst** zurückgenommen wird. Beim Start wird ein unterbrochenes Schreiben zurückgespielt (Daten zuerst, Kopf zuletzt) und danach `settings.load()` aufgerufen (Marlins eigener Ladeversuch war an dem halben Block gescheitert). **Konsistenz wird nachgewiesen** (Hauptblock nach dem Zurückspielen wieder `VALID`), nicht aus „kein Journal“ geschlossen.
3. **Start-Check**: Auto60 startet nur bei **gültigem** oder noch **leerem** Block; ungültig, unterbrochen, fremd oder andere Version wird nie automatisch überschrieben.
4. **Verschleiss**: steht das gemessene Mesh samt Z-Offset schon bitgleich im gültigen Block, entfällt das Speichern (kein „ERR“-Fenster, keine Mitnahme ungespeicherter anderer Einstellungen); die Wiederholung nach einer gescheiterten Prüfung speichert dann **wirklich**. Journal im Dauerbetrieb ≤ 6 geänderte Bytes (EE31).
5. **Nebenbefund**: Auto60 speichert wie M500 den **ganzen** Block. Ungespeicherte Änderungen anderer Einstellungen werden mitgenommen und per Serial gemeldet (`weitere Bytes des Einstellungsblocks`).

## 5. Beleg der Absicherung (Host-Modell, KEIN Gerät)
* **Kern, erschöpfend:** 882 Abschaltpunkte über die gesamte Transaktion → nach dem Neustart **immer** ein gültiger Block, genau der alte oder der neue; 1094 verschachtelte Abschaltungen (im Speichern **und** in der Wiederherstellung): 0 fehlerhafte Endzustände (EE40–EE42); 887 Schreibfehlerpositionen: nie falscher Erfolg (EE43); ein Speicher, der Erfolg meldet und ein Byte verliert, wird erkannt (EE46).
* **Ende-zu-Ende (echter Adapter + G28/G29 + Modell):** ca. 38 Abschaltpunkte eines vollständigen Laufs, je Zwei-Phasen-Test mit Neustart; die Grenze „alt oder neu“ liegt **exakt** am letzten geänderten Byte (Journal verwerfen) und wird aus dem Lauf berechnet (E01). Verschachtelte Abschaltung in der Wiederherstellung (E02), Schreibfehler an ~22 Positionen (E04), beschädigte/unterbrochene/fremde/andersversionierte Daten (E09), leeres EEPROM (E10), toter Bus (E11), `M1060 S2/S3` (E12), Überspringen (E13), Mitnahme anderer Einstellungen (E14), falscher Offset und „kein Platz“ (E19–E21), verfälschter Z-Offset (E22), CRC-Lüge von `validate()` (E23).
* **Mutationstests:** EEPROM-Kern 17/17, Koordinator 11/11, Adapter 11/11 erkannt; als beobachtungsgleich bestätigt: EC16 (redundante Kapazitätsprüfung, `rd()` prüft jeden Zugriff selbst), AG01 (durch Konstruktion nicht beobachtbar), AG02/AG03 (nur Zeitverhalten der Heizungsbedienung).

## 6. Grenzen / offen
* **`datasize()` des Ziel-Builds ist unbekannt.** Das Journal braucht `EEPROM_OFFSET + datasize + 8 + 16 + datasize ≤ 2048`, also `datasize() ≤ 962`. Reicht der Platz nicht, speichert Auto60 **ohne** Journal (Gleichstand zu 282), und `M1060 S3` meldet `journal_platz=NEIN`. Mit `SV04_CLAUDE_EEPROM_REQUIRE_JOURNAL=1` startet Auto60 dann gar nicht.
* **Anwender-M500 bleibt ungeschützt:** das Journal gilt nur im Auto60-Pfad.
* **Toter Bus:** Der echte Treiber meldet Lesefehler nie; ein toter Bus sieht wie ein leeres EEPROM aus. Auto60 startet dann, endet aber **nie** mit Erfolg (E11).
* **Nivellierung nach Neustart:** für Bilinear nicht gespeichert → nach dem Neustart aus bis `M420 S1` (OEM-Verhalten, unverändert).
* **Blockierend:** das erste Journal schreibt ca. 800 Bytes (mehrere Sekunden; Heizung wird dabei bedient); danach nur Unterschiede.
* Das Modell bildet Marlin/BL24CXX nach; der echte `settings.cpp`-Code wurde nicht ausgeführt. Offset 100, die Version, der CRC-Algorithmus und die 82-Byte-Reihenfolge sind aus dem Quelltext belegt, aber **unverifiziert am Gerät**.
