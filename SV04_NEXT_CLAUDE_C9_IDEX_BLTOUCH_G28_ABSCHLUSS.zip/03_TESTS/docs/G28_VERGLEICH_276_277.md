# G28: Stand 276 gegen Stand 277 (echte G28.cpp, Host-Simulation, KEINE Hardware)

Gleiche Szenarien, gleiche Simulation; nur der Quellstand unterscheidet sich. `homed`/`trusted` = Achsen, die danach als referenziert bzw. vertraut gelten. Beleg: `claude/04_TESTS/sim/test_g28_a60.py`.

| Fall | Szenario | Stand | Z gefahren | Y gefahren | homed | trusted | Erfolg ans Display | Duplizierung danach | Leveling danach | Ergebnisstatus |
|---|---|---|---|---|---|---|---|---|---|---|
| N1 | Normalfall: volles G28, Modus AUTO_PARK (1) | 276 | ja | ja | XYZ | XYZ | ja | 0 | 1 | nicht exportiert |
| N1 | Normalfall: volles G28, Modus AUTO_PARK (1) | 277 | ja | ja | XYZ | XYZ | ja | 0 | 1 | ok=1 |
| N2 | Normalfall: volles G28, Modus FULL_CONTROL (0) | 276 | ja | ja | XYZ | XYZ | ja | 0 | 1 | nicht exportiert |
| N2 | Normalfall: volles G28, Modus FULL_CONTROL (0) | 277 | ja | ja | XYZ | XYZ | ja | 0 | 1 | ok=1 |
| N3 | G28 Z allein (Achsen schon referenziert) | 276 | nein | nein | XYZ | XYZ | nein | 0 | 0 | nicht exportiert |
| N3 | G28 Z allein (Achsen schon referenziert) | 277 | nein | nein | XYZ | XYZ | nein | 0 | 0 | ok=0 |
| F1 | BLTouch meldet Alarm beim Einfahren (probe.stow) | 276 | ja | ja | XYZ | XYZ | nein | 0 | 0 | nicht exportiert |
| F1 | BLTouch meldet Alarm beim Einfahren (probe.stow) | 277 | ja | ja | XY | XY | nein | 0 | 0 | ok=0 |
| F2 | T0-Referenzfahrt kehrt frueh zurueck (T1 war erfolgreich) | 276 | nein | ja | XY | XY | nein | 0 | 0 | nicht exportiert |
| F2 | T0-Referenzfahrt kehrt frueh zurueck (T1 war erfolgreich) | 277 | nein | nein | - | - | nein | 0 | 0 | ok=0 |
| F3 | T1-Offset ausserhalb des Verfahrwegs (M218-Wert 400) | 276 | ja | ja | XYZ | XYZ | ja | 0 | 1 | nicht exportiert |
| F3 | T1-Offset ausserhalb des Verfahrwegs (M218-Wert 400) | 277 | nein | nein | - | - | nein | 0 | 0 | ok=0 |
| F5a | volles G28 im Modus DUPLICATION (2) | 276 | nein | ja | XY | XY | nein | 0 | 0 | nicht exportiert |
| F5a | volles G28 im Modus DUPLICATION (2) | 277 | ja | ja | XYZ | XYZ | ja | 1 | 1 | ok=1 |
| F5b | volles G28 im Modus MIRRORED (3) | 276 | nein | ja | XY | XY | nein | 0 | 0 | nicht exportiert |
| F5b | volles G28 im Modus MIRRORED (3) | 277 | ja | ja | XYZ | XYZ | ja | 1 | 1 | ok=1 |
| F6 | Modus DUPLICATION: zweiter X-Durchgang scheitert | 276 | nein | ja | XY | XY | nein | 0 | 0 | nicht exportiert |
| F6 | Modus DUPLICATION: zweiter X-Durchgang scheitert | 277 | ja | ja | YZ | YZ | nein | 0 | 0 | ok=0 |
