# SV04 NEXT – Gesamtintegration 283 (EEPROM) + M420 V2–V6 – technischer Bericht

Version **284 (provisorisch)**. Nicht flashbar. **STM32 GEBAUT = NEIN** (in dieser Umgebung unmöglich: keine ARM-Toolchain, kein PlatformIO, kein Netz; geprüft). **AM GERÄT BESTÄTIGT = NEIN.** Ein Fehlschlag eines Patchschritts wird hier nirgends als Compilerlauf ausgegeben: es gibt für 283/284 **keinen** Compilerlauf.

## 1. Ergebnis in vier Sätzen

1. **Die Übergabe ist an einer Stelle veraltet:** M420 V6 ist **bereits in 282 und damit in 283 enthalten** und wurde auf Ihrem GitHub-Lauf 282 in beiden Profilen angewendet und gebaut (`APPLIED V6` am echten OEM-Baum, `BUILD_EXIT=0`). Den V6-Fehler aus Run 280 habe ich reproduziert (Anker mit 10 statt 12 Leerzeichen Einrückung); er ist seit 282 behoben, es war nichts mehr zu beheben.
2. **Der echte offene Integrationspunkt war ein anderer, und er war ein Fehler:** Mit den **echten** Funktionen aus dem OEM-`bedlevel.cpp` nach M420 V2 + V4 endete Auto60 in zwei realistischen Fällen im **Notstopp** (`kill()`); meine Simulation benutzte bis dahin Attrappen, die das nie zeigen konnten. Der Fehler steckt seit 282 im Adapter, ist **behoben** und mit Tests und Mutationstests abgesichert.
3. Alles andere der Reihenfolge des Auftrags wurde **ausgeführt oder dokumentiert** (Abschnitt 4).
4. Es bleibt, was nur Sie auslösen können: der **STM32-Build beider Profile** (`284.yml` + `SV04_NEXT_284.zip`) und die Hardwareprüfung.

## 2. Der gefundene Fehler (belegt)

**Ursache.** M420 V4 verändert die öffentliche `set_bed_leveling_enabled()` so, dass sie bei **aktiver Nivellierung und ungültigem Mesh** `kill("Invalid active mesh")` auslöst (V2 macht `leveling_is_valid()` streng: endliche Werte, Raster > 0). Die OEM-G29 schaltet die Nivellierung am Ende **selbst ein**. Mein Rollback (nach einem Fehler oder Abbruch) stellte **zuerst** das alte Mesh her und schaltete **danach** aus. War das alte Mesh ungültig (leeres EEPROM: `NaN` und Raster 0), entstand „aktiv + ungültig“ → Notstopp.

**Reproduktion** (Rohlog: `claude/06_EVIDENCE/host/03_unittest_sim.txt`, Test `BL02`, vor dem Fix `KILLED`):

| Fall (echte V2+V4-Funktionen) | vor dem Fix | nach dem Fix |
|---|---|---|
| Validierung scheitert nach der G29, **EEPROM leer** | `KILLED` | `FAILED`, Nivellierung wie vorher, nichts geschrieben |
| Touch-Abbruch **während** der G29, EEPROM leer | `KILLED` | `CANCELLED`, dto. |
| dieselben Fälle, altes Mesh gültig | `FAILED`/`CANCELLED` | unverändert |

Betrifft auch den RAM-Rollback einer **manuellen** G29 (Haken `sv04c_g29_apply`).

**Fix** (`sv04_claude_auto60_marlin.inc`, +16/−3 Zeilen; Diff `diffs/5_284_…_283_nach_284.patch`): neues Hilfsstück `sv04c_mesh_rollback_safe` – **nur wenn** die Nivellierung aktiv **und** das alte Mesh ungültig ist, wird **zuerst** ausgeschaltet (solange das Mesh noch das gerade gemessene, gültige ist); bei gültigem altem Mesh bleibt alles wie vorher (kein zusätzlicher Aus-/Ein-Zyklus). Das Hilfsstück steht **außerhalb** des Auto60-Blocks, weil der G29-Haken auch ohne Auto60 übersetzt wird.

**Zwei Fehlversuche, die die Tests aufdeckten** (damit Sie wissen, wie es dazu kam): (a) Mein erster Fix stand im Auto60-Block und hätte den Build **ohne Auto60** gebrochen (Strikt-Test X03 und Konfigurationsmatrix S42). (b) Er schaltete auch bei gültigem Mesh aus und ein (Test S32/P07). Beides behoben.

## 3. Wie die Integration geprüft wurde

* **Echte Funktionen statt Attrappen.** `claude/04_TESTS/sim/extract_bedlevel_a60.py` erzeugt aus dem **echten OEM-`bedlevel.cpp`** die Funktionen `leveling_is_valid`, `set_bed_leveling_enabled`, `reset_bed_level` – nach **ChatGPTs eigenen Patchskripten** `apply_m420_guard_v2.py` und dem bedlevel-Teil von `apply_m420_v4.py` (über deren Konstanten und Ankerprüfung, nichts nachgeschrieben) – und hängt sie wörtlich in die Simulation ein (`SIM_REAL_BEDLEVEL`). `kill()` beendet den Prozess wie am Gerät.
* **Beweis „Host-Code = Build-Code“:** `claude/tools/compare_bedlevel_real.py` vergleicht diese Funktionen mit dem **im Workflow integrierten** `bedlevel.cpp` (`BEDLEVEL_HOST_EQUALS_BUILD=YES|NO`; als Schritt in `284.yml`, nach der Integration und vor dem Build).
* **Tests `BL01–BL10`** (`test_bedlevel_a60.py`): Erfolgspfad; leeres EEPROM × 15 Fehler-/Abbruchfälle; gültiges altes Mesh × Nivellierung vorher an/aus; Stromausfall an 11 Punkten und Neustart ohne Notstopp; **M1060 S2/S3 verändern weder Mesh, Z-Offset, Nivellierung noch `current_position` und bewegen nichts** (auch bei leerem und beschädigtem EEPROM); G29-Endskript-Fehler und ungültiges neues Mesh: keine Aktivierung, kein M500; manuelle G29; altes Mesh nur aus **einem** Grund ungültig (NaN **oder** Raster 0).
* **Mutationstests Bedlevel:** 6/6 erkannt, 1 als gleichwertig geprüft (`BG01`: im Zustand VALIDATING/ENABLING ist die Nivellierung schon aus).

## 4. Die zehn Punkte des Auftrags

| Nr | Punkt | Stand | Herkunft des Nachweises |
|---|---|---|---|
| 1 | Integrität/Versionsstände | alle 10 Dateien gegen das Manifest ok; 283-Dateien identisch mit meiner Auslieferung; Paket gegen sein Manifest (211) ok. **279**: `BUILD_EXIT=0` (P1 + M420 V2–V5, ohne Auto60/V6). **280**: nie bis zum Build gekommen. | selbst (279/280-Logs: übernommen) |
| 2 | V6-Fehler Run 280 | reproduziert: `CONFLICT midrange: expected one anchor, found 0`; seit 282 behoben; am echten Baum angewendet laut **Ihrem** 282-Log | Reproduktion selbst, Anwendung am echten Baum **übernommen** |
| 3 | bedlevel × V6 konfliktfrei | Notstopp-Fehler gefunden und behoben (Abschnitt 2); `set_bed_leveling_enabled`/G28/G29/Auto60/M500/Rohlesung per Quelltext und 10 Tests geprüft; M420 V5/V6 ändern nur `M420.cpp`, Auto60 ruft `set_bed_leveling_enabled` direkt | selbst |
| 4 | Messfehler/Abbruch: keine Erfolgsmeldung, kein M500 (inkl. `G28 XY`) | `settings_save=0`, 0 EEPROM-Bytes, keine Erfolgsseite, auch mit den echten Funktionen | selbst |
| 5 | Rohlesung verändert nichts; Journal/Platz/Hardwareevidenz | `M1060 S2/S3`: Mesh, Z-Offset, Nivellierung, Fahrzustand unverändert (`lev=1 pos=1 mesh=1 zoff=1 offset=1 no_motion=1`); Journal: Option `SV04_CLAUDE_EEPROM_REQUIRE_JOURNAL`, Bedarf `datasize() ≤ 962`, am Gerät unbekannt | selbst |
| 6 | IDEX-Modi, T0/T1, BLTouch, DWIN (16 Objekte, Abbruch), sechs Kernfunktionen | gesamte Regression grün (unten) | selbst |
| 7 | STM32-Build | **nicht möglich**; 282 (Ihr Lauf): `BUILD_EXIT=0` beide Profile = **übernommen**; 283/284: **nie gebaut** | – |
| 8 | Workflow, nächste freie Nummer | `284.yml` + `SV04_NEXT_284.zip`; **Nummer provisorisch** (in den Unterlagen kommen 268–283 vor, ob 284 frei ist, weiß nur der Nutzer); `python3 claude/tools/make_workflow_283.py --zip-sha256 <hex> --version N --out N.yml` (Namen im ZIP bleiben; ZIP umbenennen und Hash neu eintragen) | selbst (Struktur-Tests B20–B22) |
| 9 | Welche Tests wirklich ausgeführt | Abschnitt 5 | – |
| 10 | Nicht nach dem ersten Fehler anhalten | die lokal lösbaren Fehler (Notstopp, Kompilierfehler ohne Auto60, Zusatzzyklus, veraltete Mutanten/Diffs) in einem Arbeitsgang behoben | – |

## 5. Welche Nachweise selbst ausgeführt, welche übernommen sind

**Selbst ausgeführt (dieser Lauf; Rohlogs in `claude/06_EVIDENCE/host/`):**

| Prüfung | Ergebnis |
|---|---|
| C++-Kerntests Koordinator / EEPROM-Kern | 147/147 · 33/33 |
| Host-/Pipeline-/Workflow-Tests | 35/35 |
| Simulationstests (53 Kette, 13 DWIN, 7 streng, 15 G28, 27 Integration, 23 EEPROM, **10 Bedlevel**) | 148/148 |
| ChatGPT: P1 268–276 / M420 V4–V6 + OEM-Anker / Integration 281 | 57/57 · OK · 4/4 |
| Mutationstests **neu gegen den 284-Adapter**: Adapter 12 (+1 gleichwertig) · Backend 10 · EEPROM-Adapter 11 (+3 beobachtungsgleich) · Bedlevel 6 (+1) | 0 Überlebende |
| Mutationstests aus 283 übernommen, **Quelldateien in 284 per Hash unverändert** (`15_unveraenderte_dateien.txt`): Kern 24, EEPROM-Kern 17, Koordinator 11 | 0 Überlebende |

**Aus Ihren Logs übernommen, nicht erneut gebaut:** `BUILD_EXIT=0` für 279 (P1 + M420 V2–V5) und 282 (P1 + Auto60-277 + M420 V2–V6, beide Profile), dort `APPLIED V6` am echten OEM-Baum. **Nicht vorhanden:** jeder Build von 283/284.

## 6. Grenzen (was nicht belegt ist)

* **M420.cpp (V4-Hälfte, V5, V6)** konnte ich nicht gegen einen vollständigen OEM-`M420.cpp` ausführen (nicht lokal vorhanden); dort gelten ChatGPTs Tests und Ihr 282-Lauf. Auto60 ruft M420 nicht auf.
* **Der Host-Code ist nur dann Build-Code, wenn der Beweisschritt in `284.yml` `YES` meldet** (er läuft im GitHub-Lauf, bisher nie).
* Weiterhin offen wie in 283: `datasize()` des Ziel-Builds, Anwender-`M500` ohne Journal, Nivellierung nach Neustart bis `M420 S1`, erste Journal-Pause, I²C-Chip und Timing am Gerät.
* V4 löst auch **außerhalb** von Auto60 `kill()` aus, wenn Sie bei aktiver Nivellierung das Mesh ungültig machen (z. B. `M421` auf `NaN`) und danach etwas `set_bed_leveling_enabled` aufruft. Das ist das Design von V4, kein Fehler dieser Integration.

## 7. Hardwareprüfungen, die bleiben (Plan: `HARDWARE_ABNAHME_283.md`, Ergänzung)

Zusätzlich zu H0–H6: **H7 (nur nach grünem Build und H0–H6)** – Auto60 bei **leerem** EEPROM starten und per Touch abbrechen bzw. eine Messung scheitern lassen: erwartet **kein** Notstopp, Nivellierung aus, `M500`-frei. Vor dem Fix wäre das ein Notstopp gewesen (Drucker hält an, Heizung aus – sicherer Zustand, aber ein Fehlverhalten). Nicht künstlich ein ungültiges Mesh bei aktiver Nivellierung erzeugen.

## 8. Fortschrittsanzeige

Ihre Entwicklungsschätzungen (P1 75 · P2 75 · P3 50 · P4 90 · P5 70 · P6 60 · Gesamt 70 %): **unverändert, keine Änderung beantragt.** Begründung: Neu programmiert und lokal getestet ist die bedlevel-Integration und ein behobener Notstopp (das betrifft P3/P4/P5/P6 entwicklungsseitig), aber ohne STM32-Build und ohne Hardwarebeleg sehe ich keinen eindeutigen Grund für eine Zahl. Bereits erreichte Programmierung wird nicht als null gewertet. Eine Anhebung für P3/P4 wäre nach grünem Build beider Profile begründbar.

## 9. Was ChatGPT beim Zusammenführen beachten sollte

* **284 ändert gegenüber 283 genau eine Firmwaredatei:** `sv04_claude_auto60_marlin.inc` (Diff 283→284: `diffs/5_284_…`). `core.h`, `eeprom_core.h`, `g29_session.h`, `hooks.h`, alle `m420/`-Skripte, `integrate_281.py` und alle OEM-Dateien sind **unverändert** (Hash).
* **Keine ältere G28-/Auto60-Datei über 284 kopieren** (der Rollback-Fix steckt im Adapter).
* Änderungen an `bedlevel.cpp` (V2/V4) **bitte nur mit** `compare_bedlevel_real.py` und `test_bedlevel_a60.py` weiterentwickeln: sie sind der ausführbare Vertrag zwischen M420 und Auto60.
