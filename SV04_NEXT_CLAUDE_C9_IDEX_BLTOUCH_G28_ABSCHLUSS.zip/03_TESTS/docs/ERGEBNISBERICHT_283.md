# SV04 NEXT 283 – Ergebnisbericht (Punkt 5: M500 EEPROM, Punkt 6: EEPROM-Rücklesung)

## Kurzfassung

**Nicht flashbar. STM32 GEBAUT = NEIN. AM GERÄT BESTÄTIGT = NEIN.** In der Claude-Umgebung gibt es keinen ARM-Compiler, kein PlatformIO und kein Netz; die zwei STM32-Builds laufen über `283.yml` und sind **bisher nicht gelaufen**. Alles, was ich „getestet“ nenne, ist **Host-Simulation um die echten Quelldateien** (Adapter, Koordinator, EEPROM-Kern, `G28.cpp`, `G29.cpp`) mit einem byte-genauen Modell des EEPROM-Treibers.

Für den GitHub-Lauf werden wie gewohnt genau **zwei Dateien** gebraucht: `283.yml` und `SV04_NEXT_283.zip` (Anleitung: `GITHUB_UPLOAD_ANLEITUNG_283.md`). Version 282 ist unverändert.

## Was gebaut wurde

1. **Rohlesung statt `settings.load()`** (Punkt 6). Der Block wird über `persistentStore` roh gelesen: eigene CRC, das Mesh genau einmal gefunden und bitgleich zum Messabbild, `probe.offset` im Block, Zahlen endlich und im Rahmen, Version `V85`. Das RAM wird nicht verändert.
2. **Undo-Journal und Startwiederherstellung** (Punkt 5, Stromausfall). Vor dem Speichern wird der letzte gültige Block am EEPROM-Ende gesichert; ein beim Schreiben unterbrochener Vorgang wird beim Start zurückgespielt. Konsistenz wird nachgewiesen, nicht angenommen.
3. **Start-Check und Verschleiss.** Auto60 startet nur bei gültigem oder noch leerem Block; steht das Mesh schon bitgleich im EEPROM, entfällt das Speichern.
4. **Verbindung mit dem Koordinator.** Neue Fehlergründe, Ports `eeprom_prepare/commit/unchanged`, die Journal-Transaktion wird genau einmal abgeschlossen, Erfolg erst nach bestätigter Rohlesung.
5. **`M1060 S2`/`S3`**: lesende Rohprüfung gegen das RAM-Mesh bzw. Journal-/Startstatus.

Geänderte/neue Firmwaredateien gegenüber 282: `sv04_claude_auto60_core.h` (433 Zeilen, geändert), `sv04_claude_auto60_marlin.inc` (513, geändert), **neu** `sv04_claude_eeprom_core.h` (313), `03_PATCHES/apply_claude_parallel.py` (Dateiliste, damit der EEPROM-Kern in den OEM-Baum kommt). OEM-Dateien werden von 283 **nicht zusätzlich** angefasst.

## Die fünf Kategorien

| Kategorie | Stand |
|---|---|
| **PROGRAMMIERT** | Alles oben; Werkzeuge: `tools/make_workflow_283.py`, `tools/make_status_283.py`, `tools/make_checkpoint_283.py`. |
| **LOKAL GETESTET** (Host-Simulation) | EEPROM-Kern **33/33** · Koordinator-Kern **147/147** (130 aus 282 + 17 neue) · Host/Pipeline/Workflow **30/30** · Simulation **138/138** (53 Kette, 13 DWIN, 7 streng, 15 G28, 27 Integration, **23 EEPROM** `test_ee_a60.py`) · **Mutationstests**: neu EEPROM-Kern 17/17, Koordinator 11/11, EEPROM-Adapter 11/11 erkannt; alt in 283 neu bestätigt: Kern 24/24, Adapter 12/12, Backend 10/10; 0 Überlebende. ChatGPTs P1-Tests 57/57, M420 V4/V5/V6 + OEM-Anker und Integration 4/4 bestehen. Logs: `claude/06_EVIDENCE/host/`. |
| **STM32 GEBAUT** | **NEIN.** Vorbereitet: `283.yml` (2 Profile: Backend aktiv / deaktiviert), abgeleitet aus Ihrem 282.yml (5 Zeilen Abweichung). NOT RUN. |
| **AM GERÄT BESTÄTIGT** | **NEIN.** Plan: `HARDWARE_ABNAHME_283.md`. |
| **BLOCKIERT / OFFEN** | STM32-Builds, RAM/Flash-Verbrauch, Hardwareprüfung, `datasize()` des Ziel-Builds, Zusammenspiel Auto60 + M420 V6 am Gerät. Details: unten. |

Zeilengenaue Matrix der 40 Arbeitsschritte und 8 Abnahmebedingungen: **`STATUS_283.csv`**. Jeder dort genannte Test wurde gegen die Rohlogs geprüft (das Skript bricht ab, wenn einer dort nicht bestanden ist).

## Befunde (belegt am OEM-Code; Details in `EEPROM_ANALYSE_283.md`)

* **E1/E6 (bedeutend):** Die Rücklesung in 282 über `settings.load()` hätte am Gerät die **Nivellierung abgeschaltet** (bei passendem Bilinear-Raster `settings.cpp:1676`, das Flag wird für Bilinear nicht gespeichert `:833`) und damit vermutlich regelmäßig mit `VERIFY_LEVELING` geendet. Meine frühere Simulation hatte das Gegenteil angenommen. Belegt am Quelltext, **nicht am Gerät**.
* **E2:** `save()` macht bei Stromausfall den **ganzen** Einstellungsblock ungültig (Kopf „ERR“ zuerst).
* **E3:** `save()` merkt Schreibfehler nur indirekt und beim Kopf gar nicht (5 von 5 solchen Fällen meldeten Erfolg); die Rohlesung erkennt alle.
* **E4:** Würde man in kleinen Stücken schreiben, würde die Heizung nicht bedient; der Adapter schreibt in 8-Byte-Stücken mit `safe_delay(1)`.

## Fehler, die ich selbst gemacht und behoben habe

* **Versionsprüfung (E5):** Mein Kern hielt jeden `V<zz>`-Kopf mit gültiger CRC für gültig; ein Block von `V84` wäre überschrieben worden. Jetzt wird gegen `V85` geprüft. Gefunden durch einen Test, der „fremde Version“ erwartete.
* **Endlosschleife:** Nach übersprungenem Speichern und gescheiterter Prüfung pendelte der Koordinator zwischen `VERIFYING` und `SAVE_PENDING`.
* **Unbelegte Konsistenzbehauptung:** Bei totem Bus (der echte Treiber meldet Lesefehler nie) wurde „kein Journal“ als „konsistent“ gewertet; jetzt wird `primary==VALID` nachgewiesen.
* **Drei Testlücken**, aufgedeckt durch Mutationstests: Nachprüfung des Zurückspielens (Speicher, der Erfolg meldet und ein Byte verliert, EE46), gespeicherter Z-Offset (E22) und eigene CRC (E23).
* **Simulationsartefakt (kein Produktfehler):** Der Boot-`load()` meines Treibers löste den Auto60-Tick aus und überschrieb das wiederhergestellte RAM; der Boot ist jetzt ohne Display-Schleife nachgebildet.
* Aus 282 übernommen und bereinigt: die zwei Warnungen `sv04c_hb_ms`/`sv04c_hb_seq0` im fail-closed-Profil.

## Was die Simulation beweist – und was nicht

**Beweist** (Ausführung der echten Quelldateien): Reihenfolge und Logik des Speicherablaufs; dass vor dem Speichern kein EEPROM-Byte geändert wird; dass nach **jedem** simulierten Stromausfall (ca. 38 Punkte eines kompletten Laufs, dazu verschachtelte Abschaltungen; im Kern erschöpfend 882) der Block gültig und **genau alt oder genau neu** ist; dass ein Erfolg nur bei bitgleichem, CRC-gültigem Rohblock samt Z-Offset gemeldet wird.
**Beweist nicht:** das Verhalten des echten I²C-EEPROMs, den echten `settings.cpp`-Code (nachgebildet), Timing im echten `idle()`, den DWIN-Touch, den Zielcompile. Die Treiberkonvention (Fehler = `true`, `read_data` meldet nie einen Fehler, 8-Byte-Schreibblöcke) ist aus dem mitgelieferten Treiberquelltext abgelesen.

## Verhaltensänderungen gegenüber 282 (Entscheidungen, jeweils mit sicherem Standard)

1. **Auto60 startet nicht**, wenn der Einstellungsblock ungültig, unterbrochen, fremd oder andersversioniert ist (`PRE_EEPROM_UNAVAILABLE`); leeres EEPROM ist erlaubt. Vorher wurde überschrieben.
2. **Bei Fehlschlag nach dem Speichern bleibt der alte Block erhalten** (bytegleich zurückgespielt). Vorher war er verloren.
3. **Nach dem Neustart** wird ein unterbrochenes Speichern einmalig zurückgespielt und `settings.load()` aufgerufen. Neu: `M1060 S2/S3`.
4. **Journal-Pflicht**: Standard `SV04_CLAUDE_EEPROM_REQUIRE_JOURNAL=0` (ohne Journal speichern, wenn der Platz fehlt, und melden). Mit `1` startet Auto60 dann nicht. *Ihre Entscheidung* – ich würde nach dem ersten Lauf von `M1060 S3` (zeigt `journal_platz`) entscheiden.
5. **Mitgespeicherte andere Einstellungen** (ungespeicherte M-Befehle) werden gemeldet, nicht verhindert (wie M500).

## Risiken für den ersten Zielcompile (ehrlich)

Der Host übersetzt streng (`-Wall -Wextra -Werror -pedantic`, 16 Konfigurationen), aber **nicht mit dem Zielcompiler**. Aus dem Quelltext erschlossen, nicht gesehen: `safe_delay` ist über `MarlinConfig.h` erreichbar (der Treiber `eeprom_bl24cxx.cpp` benutzt es mit denselben Includes); `crc16` kommt über `HAL/shared/eeprom_api.h`; `xyz_pos_t` ist 12 Bytes (`static_assert`); `settings.datasize()` ist öffentlich (schon in 282 benutzt). Ich erwarte beim ersten Lauf **eher nicht** einen völlig sauberen Zielcompile und werte jede Meldung aus. `283.yml` druckt zusätzlich die Größe gegen Ihre 282-Werte (166260/11028 und 165020/11012) und zählt die neuen Meldungen im Abbild.

## Offen / blockiert

* **STM32-Builds** (beide Profile): nur über GitHub.
* **Hardwareprüfung**: `HARDWARE_ABNAHME_283.md` (Plan, nichts ausgeführt).
* **`datasize()` des Ziel-Builds** unbekannt (Journal braucht ≤ 962 Bytes).
* **Anwender-`M500`** bleibt ohne Journal.
* **Zusammenspiel Auto60 + M420 V4–V6** am Gerät: Auto60 ruft `set_bed_leveling_enabled` direkt (nicht M420); M420 wird nur von ChatGPTs eigenen Tests geprüft.
* **Nivellierung nach Neustart** ist für Bilinear aus bis `M420 S1` (OEM-Verhalten, unverändert).

## Fortschrittsanzeige für Punkt 5 und 6

Programmiert und lokal getestet, aber **weder gebaut noch am Gerät bestätigt**. Meine Empfehlung: **keine Erhöhung** der Prozentwerte (55 / 52 / 43 / 55 / 55 / 25), bis der STM32-Build beider Profile grün ist; eine Änderung für Punkt 5 und 6 wäre erst nach dem Hardwareschritt H2/H3 (`HARDWARE_ABNAHME_283.md`) belegt.

## Reproduzieren

`python3 claude/tools/verify_manifest.py .` · `python3 claude/tools/run_all_tests_a60.py --stages core,host,sim` (ca. 90 s) · Mutationen klassenweise `python3 -m unittest 04_TESTS.test_mutations_a60.<Klasse>` (aus `claude/`) · `python3 claude/tools/make_status_283.py`.
