# SV04 NEXT – Claude-Rückgabe C2: IDEX, BLTouch und Homing mit den echten OEM-Quellen

Stand 12.11.2026 · Basis: gemeinsamer Stand 299, ChatGPTs EEPROM-Kette 300–305, Claudes C1. **C2 ist ein Claude-internes Kürzel**, nicht ChatGPTs Versionsnummer (nicht als 306 ausgeben).

> **Ehrlicher Gesamtstand:** Programmiert und in der Host-Simulation geprüft, teils gegen die **echte, unveränderte OEM-Datei** (`T.cpp`, Git-Blob-SHA-1 geprüft). **STM32 GEBAUT = NEIN** (keine ARM-Toolchain, kein PlatformIO, kein GitHub in Claudes Umgebung). **HARDWARE GEPRÜFT = NEIN.** Gebaut ist nur der Stand **291**. Keine Flashfreigabe.

## 0. Herkunft der OEM-Quellen (Auftrag 3)

* Der Abruf per `02_OEM_QUELLEN_HOLEN.py` **schlug fehl** (`Name or service not known`, Netz in Claudes Umgebung deaktiviert). Es wurde **kein Umweg** versucht und **nichts ersetzt**.
* Stattdessen lag der vollständige OEM-Stand als Upload vor (`SV04-IDEX-…-1867fcba….zip`, sha256 in Log `21`). Die **Git-Blob-SHA-1 aller drei Pins wurden selbst berechnet und stimmen** (`tool_change.cpp` cb551647…, `T.cpp` 5bb139f9…, `bltouch.cpp` 49a10f62…). Die drei Dateien liegen jetzt als Baseline im Paket (Byte-Vergleich mit dem Upload: identisch).

## 1. Neue Befunde im echten Code

| Nr | Befund | Beleg (OEM, Commit 1867fcba) | Folge |
|---|---|---|---|
| **B1** | **`dualx_tool_change()` markiert X bei JEDEM Werkzeugwechsel als referenziert und vertrauenswürdig, auch ohne Bewegung.** `tool_change()` setzt bei nicht referenzierten Achsen nur `no_move = true` (`tool_change.cpp:1025`), ruft aber trotzdem `dualx_tool_change()` (`:1139`) auf, und dort steht unbedingt `active_extruder = new_tool;` (`:868`) und `set_axis_is_at_home(X_AXIS);` (`:871`). `set_axis_is_at_home()` setzt `set_axis_trusted(axis)` und `set_axis_homed(axis)` (`motion.cpp:2092–2093`) und überschreibt `current_position.x` mit der Heimposition des **neuen** Werkzeugs. | Ein `T1`/`T0` bei nicht vertrauenswürdigem X macht X **ohne jede Bewegung wieder „referenziert“**, auch nachdem mein fail-closed `G28` X entzogen hat. Das fail-closed-Verhalten aus 277 ließ sich so umgehen. **Gelesen, nicht ausgeführt:** die echte `tool_change()` läuft in keiner Simulation. |
| **B2** | **`T.cpp` hat keinerlei Guard:** `tool_change(tool_index, …)` wird sofort aufgerufen (`T.cpp:64`). | Jeder Slicer-/Host-/Display-Befehl geht ungeprüft durch. | siehe Fix A |
| **B3** | **BLTouch-Fehler rufen `stop()`, nicht `kill()`:** `deploy_proc()` (`bltouch.cpp:96`, `stop()` in Zeile 113) und `stow_proc()` (`:131`, `stop()` in Zeile 156). `stop()` (`MarlinCore.cpp:932`) **schaltet alle Heizungen ab** und setzt `marlin_state = MF_STOPPED` (`:945`); `IsStopped()` steht in `MarlinCore.h:57`. | Das System läuft weiter (Seriell, Anzeige), `M999` hebt den Zustand auf. |
| **B4** | **Auto60 schaltete das Bett nach so einem `stop()` wieder ein.** Der Koordinator ruft in jedem Endzustand `restore_heater()` auf; der Adapter setzte den früheren Sollwert ohne Prüfung. **Ausgeführt belegt** (Simulation mit der echten `stop()`-Semantik): Spur `bed_target 60 → stop(): heaters off → bed_target 70`. | Nach einem BLTouch-Alarm heizte das vorgeheizte Bett wieder auf. Sicherheitsrelevant, weil Marlin den Stopp gerade zum Abschalten der Heizungen auslöst. | siehe Fix B |
| **B5** | **Display-Extruderwechsel** (`LCD_RTS.cpp:1718` `SelectExtruderKey`): der Knopf stellt `G28 X` und danach `T1`/`T0` in die Warteschlange und **setzt `active_extruder` vorab selbst**. Der echte Wechsel geschieht am Ende von `G28 X`; das nachfolgende `T1` ist dann ein Nullbefehl (gleiches Werkzeug). | **Meine erste Annahme war falsch** (dass das Display über `T.cpp` physisch wechselt). Der Schutz in `T.cpp` trifft daher **echte** Wechsel: `T1` aus Slicer-G-Code, Host, Makro. Der Display-Weg bleibt unberührt. |
| **B6** | Weitere OEM-Eigenheiten, **unverändert gelassen und nur dokumentiert:** `T.cpp:70` setzt `active_extruder_font = parser.boolval('S')` (nicht den Werkzeugindex); beim Start wird `active_extruder` aus dem gespeicherten Font gesetzt (`MarlinCore.cpp:1314`, `LCD_RTS.cpp:281`); im Duplikations-/Spiegelmodus verweigert das OEM `T1` selbst (`tool_change.cpp:1018`); `M605` setzt nur den Modus (`M605.cpp:84` ruft `tool_change(0)`). | – |

## 2. Was C2 ändert (alles host-geprüft)

**Fix A – Werkzeugwechsel-Schutz.** Ein *echter* Wechsel (`T`≠aktives Werkzeug) über `GcodeSuite::T` wird **abgelehnt**, wenn X nicht referenziert oder nicht vertrauenswürdig ist oder ein Auto60-Lauf aktiv ist. Gleiches Werkzeug, ungültiges Werkzeug (die OEM-Fehlermeldung bleibt) und alle **internen** Aufrufe (`G28`, `G29`, `M600`, …, sie rufen `tool_change()` direkt) sind unberührt. Meldung: `SV04: T1 abgelehnt: X nicht referenziert oder nicht vertrauenswuerdig, erst G28`. Schalter `SV04_CLAUDE_TOOLCHANGE_GUARD` (Standard 1; 0 = OEM-Verhalten).
* `claude/02_SOURCE/.../sv04_claude_toolchange_policy.h` (reine Richtlinie), `.../gcode/control/sv04_claude_toolchange_guard.h` (Marlin-Anbindung), `claude/03_PATCHES/apply_toolchange_guard_c2.py` (**+4 Zeilen in `T.cpp`**; prüft zuerst den Git-Blob-SHA-1 der Original-Datei und bricht bei Abweichung ab; idempotent; Diff: `diffs/6_C2_T_cpp_OEM_nach_C2.patch`).

**Fix B – Heizungssperre nach `stop()`.** `sv04c_bed_set()` setzt einen Sollwert > 0 im Zustand `IsStopped()` nicht; Abschalten bleibt möglich. `claude/03_PATCHES/apply_stop_heater_guard_c2.py` (ein Anker, idempotent).

**Reihenfolge der Anwendung** (nach den EEPROM-Patches 292–305, auf dem integrierten OEM-Baum): `python3 claude/03_PATCHES/apply_stop_heater_guard_c2.py <OEM_ROOT>` und `python3 claude/03_PATCHES/apply_toolchange_guard_c2.py <OEM_ROOT>`. ChatGPTs Dateien und die EEPROM-Patches bleiben unverändert (Test `R01`).

## 3. Tests (Rohlogs: `claude/06_EVIDENCE/host/`)

| Prüfung | Ergebnis |
|---|---|
| Richtlinie: Orakelvergleich über 336 Fälle + 9 Mutanten | 353/353, 0 Überlebende (`T01`, `T02`) |
| Patchskript gegen die **echte** `T.cpp`: Pin, idempotent, verweigert jede Abweichung | bestanden (`T03`) |
| **Echte `T.cpp`** (OEM vs. gepatcht) im Harness, 96 Kombinationen | 68 identisch zum OEM, 28 abgelehnt (`tool_change` nie erreicht, Font unverändert), 0 unerwartet; Guard=0 ist byte-gleich zum OEM (`T04`) |
| Verknüpfung mit den **echten G28-Ergebnissen** (1792 Fälle) | Wechsel erlaubt genau dann, wenn X referenziert und vertrauenswürdig; beide Ausgänge kommen vor (`T05`) |
| Strukturfakten der echten Quellen (B1, B3), gegen die Pins | bestanden; ändert sich der OEM-Code, schlägt der Test an (`T06`) |
| Heizungssperre: Alarm, stow-Fehler, Erfolg, Nicht-Stopp-Fehler, Bett war aus | bestanden (`OP40`–`OP43`) |
| G28-Matrix (1792 Fälle, unverändert) | 0 Verletzungen; Negativkontrolle am 276er-G28: 504 in 6 Klassen |
| Kern / EEPROM-Kern / Host / Simulation | 153/153 · 33/33 · 34/34 · 203/203 |
| Mutationstests, **0 Überlebende** | G29-Abbruch 11 · Betrieb 7 · Adapter 12 · Backend 10 · Koordinator 16 · EEPROM-Adapter 11 · Bedlevel 6 · Kern 24 · EEPROM-Kern 17 (dazu belegt gleichwertige Fälle) |
| ChatGPT: P1 268–276, M420 V4–V6, Integration 281, EEPROM 304/305 | bestanden (Logs `10`–`12`, `23`) |

## 4. Eigene Fehler und Korrekturen in dieser Runde

* **Display-Annahme (B5):** Ich wollte zuerst den Display-Wechsel schützen. Der Code zeigt, dass er über `G28 X` läuft; der Guard gehört auf den *echten* `T`-Pfad.
* **Mutationssignatur leer:** Meine Erweiterung der Betriebssignatur las den Schlüssel `TRACE`, der Treiber liefert `CMDS`. Der neue Mutant `OM10` (genau das alte Fehlverhalten) **überlebte** und hat die leere Signatur aufgedeckt; korrigiert, jetzt erkannt.
* **Selbstgebaute Makro-Attrappe** (`ENABLED`) im Harness durch die **echte `macros.h`** des OEM ersetzt; eine sinnlose Prüfzeile im Richtlinientest durch die exakte Fallzahl.
* **Teststub am falschen Ort** (`04_TESTS/test_ops_a60.py`) entfernt und die Tests in die echte Datei verlegt.
* **Paketfehler, erst durch die Prüfung aus dem entpackten ZIP gefunden:** Das Harness-Verzeichnis `t_harness/Marlin/src/gcode/control/` war im Arbeitsbaum leer (die `T.cpp` schreibt erst der Test hinein) und fehlte deshalb im ZIP; `setUpClass` scheiterte (201 statt 203 Tests). Der Test legt das Verzeichnis jetzt selbst an; geprüft in einer Kopie ohne leere Verzeichnisse. Eine erste Fassung dieser ZIP (SHA-256 `9edae028…`) enthielt den Fehler und ist **ungültig**.

## 5. Offen und unbewiesen

* **B1 ist aus dem Code gelesen**, die echte `tool_change()` wurde nicht ausgeführt (Marlin-Kern nicht in der Simulation). Der Harness beweist, was `T.cpp` tut, nicht was `tool_change()` danach tut.
* **BLTouch ohne Trigger:** weiterhin bis zu 600 mm Z-Fahrt (C1, `motion.cpp:1810`), nicht begrenzbar. `deploy_proc`/`stow_proc` melden nach zwei Versuchen `true` nach `stop()`; reale Reaktion am Gerät unbewiesen. `PROBE_TRIGGERED_WHEN_STOWED_TEST` bleibt aus.
* **IDEX-Mechanik:** Wagenbreite, reale Parkabstände, Kollisionsfreiheit, `TOOLCHANGE_ZRAISE = 0`.
* **Nutzerentscheidung nötig:** Der Schutz lehnt `T1` vor dem Homing ab (OEM würde X still als referenziert markieren). Wenn ein Start-G-Code absichtlich `T1` vor `G28` sendet, ist das jetzt abgelehnt; `-DSV04_CLAUDE_TOOLCHANGE_GUARD=0` stellt das OEM-Verhalten wieder her.
* **STM32 / Hardware:** nicht gebaut, nicht geprüft; HMI-Projekt weiterhin fehlend.

## 6. Fortschritt (Schätzung, host-seitig, keine Hardwarefreigabe)

| Punkt | vorher | jetzt | Begründung |
|---|---|---|---|
| **1 IDEX + BLTouch** | 75 % | **80 %** | Neue Implementierung (Werkzeugwechsel-Schutz, Heizungssperre nach BLTouch-`stop()`) gegen die echten Quellen; Befunde B1–B4 belegt. Gebaut/Hardware: nein. |
| **2 G28 Homing** | 76 % | **77 %** | G28 selbst unverändert; Fix A schließt die Umgehung des fail-closed X-Vertrauens über `T`. |

## 7. Reproduzieren

Wurzel dieser ZIP (benötigt `g++`, `python3`, `PyYAML`, `patch`): `python3 claude/tools/verify_manifest.py .` · `python3 claude/tools/run_all_tests_a60.py --stages core,host,sim` (ca. 145 s) · `python3 claude/tools/check_idex_bltouch_config_c1.py` · Mutationen klassenweise (z. B. `OPS_MUT_SLICE=0:4 python3 -m unittest 04_TESTS.test_mutations_a60.OpsMutants`; **zwischen den Läufen `/tmp` aufräumen**).
