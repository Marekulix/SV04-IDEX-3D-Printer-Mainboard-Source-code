# Offen, blockiert und Entscheidungen – 277

## A. BLOCKIERT (mit Reproduktion)

| Nr | Was | Warum blockiert | So reproduzieren / aufheben |
|---|---|---|---|
| B1 | **STM32-Build (alle Profile)** | In meiner Umgebung gibt es weder `arm-none-eabi-gcc` noch PlatformIO, kein Netz (Befehle `which arm-none-eabi-gcc pio platformio` liefern nichts; `claude/06_EVIDENCE/host/00_umgebung.txt`) | `277.yml` + `SV04_NEXT_277.zip` ins Repository legen, Workflow starten (`GITHUB_UPLOAD_ANLEITUNG.md`). **Ich habe keinen Zielcompiler-Lauf; es gibt deshalb keinen belegten „Build erfolgreich“.** |
| B2 | RAM-/Flash-Verbrauch | folgt aus B1 | `evidence/ram_flash.txt` je Profil im Workflow |
| B3 | Hardware-Abnahme (Endschalter, BLTouch, beide Wagen, DWIN-Touch) | kein Gerät | `HARDWARE_ABNAHME_277.md`, **erst nach grünem STM32-Build** |
| B4 | HMI-Binärdateien | nicht vorhanden; der `.inc` schreibt nur auf bestehende Seiten/VPs | unverändert aus früheren Runden |
| B5 | Aufrufreihenfolge von `RTSUpdate()` in `MarlinCore.cpp` (läuft sie während `planner.synchronize()` in `G28`/`G29`?) | `MarlinCore.cpp` lag nicht vor | `MarlinCore.cpp` aus dem OEM-Klon einlesen und `idle()` prüfen. **Folge bei Nichtlauf:** Zeitüberwachung und Touch-Abbruch greifen dann erst nach dem G28; die Ergebnismeldung selbst (G28Guard) hängt nicht davon ab. |
| B6 | Ob die Versionsnummer 277 inzwischen vergeben ist | ich sehe Ihr Repository nicht | bei Kollision `SV04_NEXT_277.zip` und `277.yml` umbenennen und im Workflow den Dateinamen sowie den fest eingetragenen SHA-256 neu setzen: `python3 claude/tools/make_workflow_277.py --zip-sha256 <HEX> --out 277.yml` |

## B. Entscheidungen, die bei Ihnen liegen (alle mit sicherem Standard)

1. **`G28 Z` allein bleibt verweigert** (`SV04_P1_Z_ONLY_REHOMES_X=0`, Standard). Mit `1` würde ein Z-Aufruf zuerst beide X-Wagen neu referenzieren (sicher, aber ein Z-Befehl bewegt dann X). Empfehlung: Standard lassen.
2. **Touch während Auto60 = Abbruch statt Tastensperre.** In 275/276 war der Touch nur gesperrt; nun löst er einen *kontrollierten* Abbruch aus (ausfallsicher; die gedrückte Taste wird verworfen). Eine laufende G28/G29 läuft dabei zu Ende, danach wird abgebrochen und das neue Mesh verworfen. Wenn Sie die frühere Sperre ohne Abbruch bevorzugen, ist das ein Eingriff in `RTS_HandleData` (Marker `SV04CLAUDE_TOUCH`).
3. **Nach einem gescheiterten/verweigerten G28 bleibt die Nivellierung aus** (Verhalten des OEM und von 276, siehe Befund O2). Soll Auto60 die Nivellierung nach einem Homing-Fehler selbst wieder einschalten? Das wäre eine Verhaltensänderung außerhalb der Auto60-Sitzung; ich habe sie **nicht** eingebaut.
4. **Z-Gate als Laufzeit-Flag** (Befund F5) ändert das OEM-Verhalten in den Modi DUPLICATION/MIRRORED: dort fährt G28 jetzt Z, wo 276 es verweigerte. Empfehlung: so lassen; ein Aufruf mit ausgeschaltetem Modus ist physisch derselbe Ablauf wie im Modus AUTO_PARK.

## C. Bekannte Grenzen der Tests (nicht als Mangel zu verstehen)

* `homeaxis()`, Planner, Thermik, Queue und EEPROM sind **Modelle**; sie bilden die Reihenfolge des OEM ab, nicht die Mechanik.
* Pfad „Homing ok, aber IDEX-Gate unerfüllt“ ist im Backend nicht erreichbar: `done` setzt dieselben Bedingungen voraus. Das Fehlen des Gates wird im Kern (C04) getestet.
* Kollisionserkennung: nur Software-Plausibilität (T1-Offset gegen Verfahrweg), keine physische.
* Mutationstests: 2 Mutanten (je einer in Kern und Adapter) sind als gleichwertig geprüft, nicht als erkannt gezählt (`05_mutationen_kern.txt`, `06_mutationen_adapter.txt`).
