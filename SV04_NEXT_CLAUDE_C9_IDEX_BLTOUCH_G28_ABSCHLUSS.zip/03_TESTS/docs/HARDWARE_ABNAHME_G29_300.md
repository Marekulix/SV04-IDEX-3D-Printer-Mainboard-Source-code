# Kontrollierte Hardware-Abnahme G29 + Abbruch + EEPROM-Schutz (Stand 300) – Plan, NICHT ausgeführt

**Dies ist ein Plan, kein Ergebnis.** Nichts davon wurde ausgeführt. Voraussetzung: STM32-Build **beider** Profile grün (`BUILD_EXIT=0`) **und** `host_equals_build_300.txt` = `HOST_EQUALS_BUILD=YES`, dazu Ihre **separate** Freigabe zum Flashen. Claude flasht nichts.

## Sicherheitsrahmen (für jeden Schritt)
* Betten leer, Druckraum frei, **eine Hand am Netzschalter**, nie unbeaufsichtigt, Bett höchstens 60 °C, kein Filament eingelegt.
* **Sofort abbrechen** (Netzschalter) bei: unerwarteter Bewegung, Wagen fährt gegen einen Anschlag oder auf den anderen Wagen zu, Heizung schaltet nach dem Abbruch nicht ab, Display friert ein, Brandgeruch oder ungewöhnlichen Geräuschen.
* Nur die Normal-Betriebsart (T0/T1 unabhängig). Duplikation/Mirrored darf Auto60 verweigern; das gehört zu den Prüfungen.
* Vor und nach jedem Schritt: `M1060 S3` (Zustand, Journal-Platz) und `M1060 S2` (Rohprüfung des EEPROM) abfragen und protokollieren.

## Schritte
| Nr | Prüfung | Erwartung | Abbruchkriterium |
|---|---|---|---|
| H3-0 | `M1060 S3`, `M1060 S2`; `journal_platz` und `datasize` notieren | Block gültig, Schutzstatus wird gemeldet | Block ungültig/fremd → Auto60 darf nicht starten (ist so gewollt) |
| H3-1 | Normaler, vollständiger Lauf (`M1060 S1`) | 16 Messungen, Zellen erscheinen einzeln, Erfolgsseite **erst nach** verifiziertem Speichern, `M1060 S2` gültig | Erfolgsseite vor Ende des Speicherns, fehlende Zellen |
| H3-2 | Touch **während Aufheizen** | sofort `CANCELLED`, keine Bewegung, Heizung wie vorher, Fehlerseite | jede Bewegung |
| H3-3 | Touch **während der Referenzfahrt** | G28 läuft zu Ende, danach `CANCELLED`, **keine** G29 | G29 startet |
| H3-4 | Touch **während einer Messung** (Punkt 2, 8, 15), Zeit bis zum Stillstand notieren | Stopp nach dem laufenden Messpunkt (Latenz ≤ Dauer eines Messpunkts), **kein** Endskript, altes Mesh wieder im Display, `M1060 S2` unverändert | weitere Messpunkte, `G28 XY` nach dem Abbruch |
| H3-5 | Touch **nach dem letzten Messpunkt / während `G28 XY`** | Vor dem Endskript: kein Endskript. Währenddessen: `G28 XY` läuft zu Ende, danach `CANCELLED`, nie Erfolg | Erfolgsseite, M500 |
| H3-6 | **Sitzung:** zwei schnelle Touches, Touch kurz vor dem Start, Neustart direkt nach Abbruch | ein Abbruch; der neue Lauf wird **nicht** abgebrochen | Abbruch des neuen Laufs |
| H3-7 | Kommt der Touch ohne die Abfrage an? Variante mit `-DSV04_CLAUDE_G29_POLL_DWIN=0` bauen und H3-4 wiederholen | beantwortet, ob `idle()` den DWIN-Puffer während der G29 bedient; **keine** Erwartung | – |
| H3-8 | **Notstopp M112** (seriell) während einer Messung | Halt, Heizungen aus; nach Reset Auto60 ruhig, `M1060 S2` gültig | Heizung bleibt an |
| H3-9 | Normalbetrieb-Kontrolle: Benutzer-`G29` (ohne Auto60), Touch während der Messung | alle 16 Messungen, **kein** Abbruch (normale Semantik) | Benutzer-G29 bricht ab |
| H3-10 | **BLTouch-Alarm** mitten in der Messung (nur kontrolliert, z. B. Pin-Test nach Herstellerangabe) | `FAILED`, kein M500, altes Mesh | Messung läuft weiter |
| H3-11 | **IDEX-Modi** (Vollkontrolle, Autopark, Duplikation, Mirrored): Auto60 starten | läuft nur in den erlaubten Betriebsarten, sonst klare Ablehnung; keine T1-Kollision | Kollision |
| H3-12 | **Journal/Stromausfall** (nur mit separat freigegebenem Test-EEPROM): Netz trennen während des Speicherns, neu starten | Wiederherstellung beim Start, Mesh im Display == EEPROM, `M1060 S2` gültig | Block zerstört |
| H3-13 | HMI: 16 Zellen, Seite 22/28, Rasterkarte fotografieren | Abgleich der Adressen `0x1100…0x111E`, Dezimalstellen, Vorzeichen, Rolle von `0x110e` | falsche Werte, Seite 28 fehlt |

## Protokoll
Je Schritt: Datum, Firmwarestand (Hash des ZIP), Profil, Ergebnis bestanden/nicht bestanden, Foto/Video, serielles Log (`M1060 S3`-Ausgaben, `Auto60 EEPROM: Schutz beim Speichern = …`). Ohne Protokoll gilt der Schritt als **nicht erledigt**.

## Ergänzung für den Stand 299/300 (EEPROM 292–294)
| Nr | Prüfung | Erwartung | Abbruchkriterium |
|---|---|---|---|
| H3-14 | Standard `REQUIRE_JOURNAL=1`: `M1060 S3` lesen (`journal_platz`, `datasize`) | Ist `journal_platz=NEIN`, startet Auto60 **nicht** und nennt den Grund („Start verweigert, kein Platz für das Undo-Journal …“) | Start ohne Journal |
| H3-15 | Normaler Lauf, danach `M1060 S2` | Block gültig, `Auto60 EEPROM: Schutz beim Speichern = Undo-Journal` | – |
| H3-16 | **Journal-Ende scheitert** (nur mit separat freigegebenem Test-EEPROM, z. B. Bus-Störung beim letzten Schreiben) | `FAILED (EEPROM_RECOVERY_REQUIRED)`, Fehlerseite, Meldung „Auto60-Speicherung gesperrt“, **kein** zweiter Start in dieser Sitzung; nach Neustart `M1060 S2` gültig | Erfolgsseite, zweiter Schreibzugriff |
| H3-17 | Touch-Abbruch in der Phase Speichern/Prüfen | kein Abbruch mehr möglich; Ergebnis wie H3-1 bzw. H3-16 | Erfolgsmeldung bei unverifiziertem Block |
