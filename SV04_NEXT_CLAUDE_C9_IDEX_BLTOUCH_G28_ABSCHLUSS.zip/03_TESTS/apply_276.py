#!/usr/bin/env python3
"""SV04 NEXT 276: P1 fail-closed G28 restoration, T0 and T1 completion evidence.

Applies after 268/272/274/275 to the *pinned* Sovol OEM files. For diagnosis,
not flashing. Does not prove hardware placement, endstop quality or BLTouch health.
"""
from pathlib import Path
import argparse

def replace_one(s, old, new, desc):
    n = s.count(old)
    if n != 1:
        raise ValueError(f'{desc}: expected one anchor, got {n}')
    return s.replace(old, new, 1)

def patch_header(s):
    return replace_one(s,
        'extern bool sv04_p1_t1_x_completed, sv04_p1_z_completed;',
        'extern bool sv04_p1_t1_x_completed, sv04_p1_t0_x_completed, sv04_p1_z_completed;',
        'T0 completion declaration')

def patch_motion(s):
    s = replace_one(s,
        'bool sv04_p1_t1_x_completed = false, sv04_p1_z_completed = false;',
        'bool sv04_p1_t1_x_completed = false, sv04_p1_t0_x_completed = false, sv04_p1_z_completed = false;',
        'T0 completion definition')
    s = replace_one(s,
        'if (axis == X_AXIS && active_extruder == 1) sv04_p1_t1_x_completed = axis_is_trusted(X_AXIS);',
        '''if (axis == X_AXIS && active_extruder == 1) sv04_p1_t1_x_completed = axis_is_trusted(X_AXIS);
      if (axis == X_AXIS && active_extruder == 0) sv04_p1_t0_x_completed = axis_is_trusted(X_AXIS);''',
        'T0 homing success tail')
    return s

def patch_g28(s):
    if 'SV04_NEXT_P1_275' not in s or 'sv04_p1_z_failed' not in s:
        raise ValueError('Requires version 275 patched G28')
    s = replace_one(s,
        '''      bool sv04_p1_z_failed = false;
      sv04_p1_t1_x_completed = false;
      sv04_p1_z_completed = false;''',
        '''      bool sv04_p1_z_failed = false;
      bool sv04_p1_x_failed = false;
      sv04_p1_t1_x_completed = false;
      sv04_p1_t0_x_completed = false;
      sv04_p1_z_completed = false;''',
        'per-G28 failure and completion reset')
    s = replace_one(s,
        '''        && active_extruder == 0
        && !idex_is_duplicating()''',
        '''        && active_extruder == 0
        && sv04_p1_t0_x_completed
        && !idex_is_duplicating()''',
        'require completed T0 X homing for safe Z')
    s = replace_one(s,
        '''          sv04_t1_homed_this_g28 = sv04_p1_t1_x_completed
            && axis_is_trusted(X_AXIS)
            && (fabsf(inactive_extruder_x - x_home_pos(1)) <= 1.0f);''',
        '''          sv04_t1_homed_this_g28 = sv04_p1_t1_x_completed
            && axis_is_trusted(X_AXIS)
            && (fabsf(inactive_extruder_x - x_home_pos(1)) <= 1.0f);
          if (!sv04_t1_homed_this_g28) sv04_p1_x_failed = true;''',
        'record T1 failure')
    s = replace_one(s,
        '''        // Home the 1st (left) extruder
        active_extruder = 0;
        homeaxis(X_AXIS);

        // Consider the active extruder to be in its "parked" position''',
        '''        // SV04_NEXT_P1_276: if the right carriage failed homing,
        // do not begin the left carriage move.
        #if ENABLED(Z_SAFE_HOMING) && ENABLED(BLTOUCH)
          if (!sv04_p1_x_failed) {
        #endif
          // Home the 1st (left) extruder
          active_extruder = 0;
          #if ENABLED(Z_SAFE_HOMING) && ENABLED(BLTOUCH)
            sv04_p1_t0_x_completed = false;
          #endif
          homeaxis(X_AXIS);
          #if ENABLED(Z_SAFE_HOMING) && ENABLED(BLTOUCH)
            if (!sv04_p1_t0_x_completed) sv04_p1_x_failed = true;
          #endif

        // Consider the active extruder to be in its "parked" position''',
        'record T0 failure')
    s = replace_one(s,
        '''        // Consider the active extruder to be in its "parked" position
        idex_set_parked();''',
        '''        // Mark parked only after both X homing operations complete.
        #if ENABLED(Z_SAFE_HOMING) && ENABLED(BLTOUCH)
          if (!sv04_p1_x_failed) idex_set_parked();
          }
        #else
          idex_set_parked();
        #endif''',
        'prevent T0 move and parked state after failed T1')
    s = replace_one(s,
        '''  #if ENABLED(DUAL_X_CARRIAGE)

    if (idex_is_duplicating()) {''',
        '''  #if ENABLED(DUAL_X_CARRIAGE)

    // SV04_NEXT_P1_276: on a failed homing attempt, do not reactivate a
    // previously selected duplication or mirror mode with extra moves.
    #if ENABLED(BLTOUCH) && ENABLED(Z_SAFE_HOMING)
      const bool sv04_p1_any_failed = sv04_p1_x_failed || sv04_p1_z_failed;
    #else
      constexpr bool sv04_p1_any_failed = false;
    #endif
    if (!sv04_p1_any_failed && idex_is_duplicating()) {''',
        'do not rehome for duplication after failure')
    s = replace_one(s,
        '''    else if((save_dual_x_carriage_mode == 4) && card.isPrinting()){''',
        '''    else if(!sv04_p1_any_failed && (save_dual_x_carriage_mode == 4) && card.isPrinting()){''',
        'do not trigger special X rehoming after failure')
    s = replace_one(s,
        '''  TERN_(CAN_SET_LEVELING_AFTER_G28, if (leveling_restore_state) set_bed_leveling_enabled());''',
        '''  // SV04_NEXT_P1_276: failed homing must not restore leveling.
  #if ENABLED(DUAL_X_CARRIAGE) && ENABLED(BLTOUCH) && ENABLED(Z_SAFE_HOMING)
    if (!sv04_p1_any_failed)
      TERN_(CAN_SET_LEVELING_AFTER_G28, if (leveling_restore_state) set_bed_leveling_enabled());
  #else
    TERN_(CAN_SET_LEVELING_AFTER_G28, if (leveling_restore_state) set_bed_leveling_enabled());
  #endif''',
        'prevent leveling reactivation on failure')
    s = replace_one(s,
        '''    tool_change(old_tool_index, TERN(PARKING_EXTRUDER, !pe_final_change_must_unpark, DISABLED(DUAL_X_CARRIAGE)));   // Do move if one of these''',
        '''    // Do not restore old tool with movement after an unsuccessful homing.
    #if ENABLED(DUAL_X_CARRIAGE) && ENABLED(BLTOUCH) && ENABLED(Z_SAFE_HOMING)
      if (!sv04_p1_any_failed)
    #endif
        tool_change(old_tool_index, TERN(PARKING_EXTRUDER, !pe_final_change_must_unpark, DISABLED(DUAL_X_CARRIAGE)));''',
        'avoid dangerous tool restoration after failure')
    s = replace_one(s,
        '''    if (sv04_p1_z_failed) {
      SERIAL_ERROR_MSG("SV04 P1 275: G28 Z failed; homing NOT complete");''',
        '''    if (sv04_p1_any_failed) {
      SERIAL_ERROR_MSG("SV04 P1 276: X or Z homing failed; completion refused");''',
        'combined failure reported to UI')
    return s

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root',type=Path,required=True)
    a=p.parse_args()
    paths = [('Marlin/src/module/motion.h',patch_header),('Marlin/src/module/motion.cpp',patch_motion),('Marlin/src/gcode/calibrate/G28.cpp',patch_g28)]
    output=[]
    for rel,fn in paths:
        path=a.root/rel
        output.append((path,fn(path.read_text(encoding='utf-8'))))
    for path,src in output:
        path.write_text(src,encoding='utf-8',newline='')
    print('P1_276_G28_ERROR_CLEANUP_APPLIED; FLASH_ALLOWED=NO')
if __name__=='__main__':main()
