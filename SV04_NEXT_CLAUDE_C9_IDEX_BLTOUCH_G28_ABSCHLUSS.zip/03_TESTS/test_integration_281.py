from pathlib import Path
import unittest
P=Path(__file__).resolve().parent
class Integration(unittest.TestCase):
 def test_production_sources(self):
  self.assertTrue((P/'claude/02_SOURCE/Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc').is_file())
  self.assertTrue((P/'apply_277_p1.py').is_file())
 def test_separate_m420_code(self):
  self.assertTrue((P/'m420/apply_m420_guard_v2.py').is_file())
  self.assertTrue((P/'m420/apply_m420_v6.py').is_file())
 def test_patch_order_and_overlap(self):
  s=(P/'integrate_281.py').read_text()
  self.assertLess(s.index('apply_277.py'),s.index('m420/apply_m420_guard_v2.py'))
  self.assertLess(s.index('m420/apply_m420_v5.py'),s.index('m420/apply_m420_v6.py'))
 def test_no_firmware_outputs(self):
  self.assertFalse(list(P.rglob('firmware.bin')))
if __name__=='__main__':unittest.main()
