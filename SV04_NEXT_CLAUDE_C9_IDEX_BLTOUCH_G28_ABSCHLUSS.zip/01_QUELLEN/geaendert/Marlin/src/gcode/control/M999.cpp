/**
 * Marlin 3D Printer Firmware
 * Copyright (c) 2020 MarlinFirmware [https://github.com/MarlinFirmware/Marlin]
 *
 * Based on Sprinter and grbl.
 * Copyright (c) 2011 Camiel Gubbels / Erik van der Zalm
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 */

#include "../gcode.h"

#include "../../lcd/marlinui.h" // for lcd_reset_alert_level
#include "../../MarlinCore.h"   // for marlin_state
#include "../queue.h"           // for flush_and_request_resend
#include "../../module/motion.h" // SV04 NEXT C9: set_all_unhomed()

/**
 * M999: Restart after being stopped
 *
 * Default behavior is to flush the serial buffer and request
 * a resend to the host starting on the last N line received.
 *
 * Sending "M999 S1" will resume printing without flushing the
 * existing command buffer.
 */
void GcodeSuite::M999() {
  // SV04 NEXT C9: ein Neustart nach dem Stopp-Zustand (z. B. nach einem BLTouch-stop()) darf KEINE Sicherheitsfreigabe erzeugen: X/Y/Z muessen erneut referenziert (und damit bestaetigt) werden.
  // Ausserhalb des Stopp-Zustands bleibt M999 unveraendert. Die Warteschlange wird nicht geleert (RingBuffer-Laengenzaehler, siehe apply_m999_reset_c9.py).
  #ifndef SV04_CLAUDE_M999_REHOME_REQUIRED
    #define SV04_CLAUDE_M999_REHOME_REQUIRED 1
  #endif
  #if SV04_CLAUDE_M999_REHOME_REQUIRED
    const bool sv04c9_was_stopped = IsStopped();
  #endif
  marlin_state = MF_RUNNING;
  ui.reset_alert_level();
  #if SV04_CLAUDE_M999_REHOME_REQUIRED
    if (sv04c9_was_stopped) {
      set_all_unhomed();
      SERIAL_ECHO_MSG("SV04 C9: restart after STOPPED state, axes are now UNHOMED: home (G28) and re-check before Auto60, G29 or a tool change");
    }
  #endif

  if (parser.boolval('S')) return;

  queue.flush_and_request_resend(queue.ring_buffer.command_port());
}
