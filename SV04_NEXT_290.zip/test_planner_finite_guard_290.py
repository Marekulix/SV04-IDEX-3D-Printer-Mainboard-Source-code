#!/usr/bin/env python3
"""Compile/run exact V290 C++ guard snippets and verify idempotent installation."""
import tempfile,pathlib,subprocess
from apply_planner_finite_guard_290 import *

fixture = ('#include "../MarlinCore.h"\n#include "../feature/bedlevel/bedlevel.h"\n'
 +SIGN_SEGMENT+' float feed) {\n'+ANCHOR_SEGMENT+'\n return true;\n}\n'
 +SIGN_LINE+' float feed){\n'+ANCHOR_LINE+'\n return true;\n}\n')
p,modified=transform(fixture)
assert modified and GUARD_LINE in p and GUARD_SEGMENT in p
assert transform(p)==(p,False)
for bad in (fixture.replace(SIGN_LINE,'wrong'),fixture.replace(ANCHOR_SEGMENT,'wrong'),p.replace(GUARD_LINE,'')):
    try:transform(bad);raise AssertionError('missed conflict')
    except ValueError:pass
assert p.index(GUARD_SEGMENT)<p.index(ANCHOR_SEGMENT)
assert p.index(GUARD_LINE)<p.index(ANCHOR_LINE)
print('PATCH CHECKS 7/7')
cpp = '''#include <cmath>
#include <cassert>
#include <cstdio>
#include <limits>
using std::isfinite;
struct P{float x,y,z,e;};struct A{float a,b,c,e;};
int killed=0,errors=0,queued=0;
#define PSTR(x) x
#define SERIAL_ERROR_MSG(x) (++errors)
void kill(const char*,void*,bool){++killed;}
bool segment(const A &abce,float fr_mm_s) {
'''+GUARD_SEGMENT+'''  ++queued;return true;
}
bool line(const P &cart,float fr_mm_s) {
'''+GUARD_LINE+'''  A abce{cart.x,cart.y,cart.z,cart.e};return segment(abce,fr_mm_s);
}
int main(){
 const float nan=std::numeric_limits<float>::quiet_NaN();
 const float inf=std::numeric_limits<float>::infinity();
 for(int i=0;i<64;i++){
   P p{1,2,3,4};A a{1,2,3,4};float feed=10;
   int slot=i%8;int group=i/8;bool bad=(group%4)!=0;
   float value=(group%2)?inf:nan;
   if(bad){
     switch(slot){
       case 0:p.x=value;break;case 1:p.y=value;break;
       case 2:p.z=value;break;case 3:p.e=value;break;
       case 4:feed=value;break;case 5:a.a=value;break;
       case 6:a.c=value;break;case 7:a.e=value;break;
     }
   }
   int k=killed,q=queued,e=errors;
   bool ok=slot<=4 ? line(p,feed) : segment(a,feed);
   assert(ok != bad);assert(killed==k+int(bad));
   assert(errors==e+int(bad));assert(queued==q+int(!bad));
 }
 puts("C++ MOTION GUARDS 64/64");
}
'''
with tempfile.TemporaryDirectory() as tmp:
    p=pathlib.Path(tmp)/'test.cpp';exe=pathlib.Path(tmp)/'run';p.write_text(cpp)
    subprocess.run(['g++','-std=c++11','-Wall','-Wextra','-Werror',str(p),'-o',str(exe)],check=True)
    subprocess.run([str(exe)],check=True)
print('ALL LOCAL 290 TESTS PASSED')
