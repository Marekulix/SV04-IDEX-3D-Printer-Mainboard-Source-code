#!/usr/bin/env python3
"""Apply finite-coordinate guard after integrated SV04 NEXT 289 to planner.cpp only."""
import argparse,hashlib
from pathlib import Path

GUARD_LINE = '''  // SV04 NEXT 290: Validate Cartesian move before modifiers / leveling.
  if (!isfinite(cart.x) || !isfinite(cart.y) || !isfinite(cart.z)
      || !isfinite(cart.e) || !isfinite(fr_mm_s)) {
    SERIAL_ERROR_MSG("SV04: non-finite Cartesian move");
    kill(PSTR("Invalid motion coordinates"), nullptr, true);
    return false;
  }

'''
GUARD_SEGMENT = '''  // SV04 NEXT 290: Final validation before float-to-step conversion.
  // Also protects direct segment callers and modifier-generated NaN/Inf.
  if (!isfinite(abce.a) || !isfinite(abce.b) || !isfinite(abce.c)
      || !isfinite(abce.e) || !isfinite(fr_mm_s)) {
    SERIAL_ERROR_MSG("SV04: non-finite planner segment");
    kill(PSTR("Invalid motion coordinates"), nullptr, true);
    return false;
  }

'''
SIGN_LINE='bool Planner::buffer_line(const xyze_pos_t &cart,'
SIGN_SEGMENT='bool Planner::buffer_segment(const abce_pos_t &abce'
ANCHOR_LINE='  // SV04 NEXT 288: refuse further queued motion if an active bilinear mesh'
ANCHOR_SEGMENT='  // If we are cleaning, do not accept queuing of movements'

def transform(src):
    if any(src.count(x)!=1 for x in (SIGN_LINE,SIGN_SEGMENT,ANCHOR_LINE,ANCHOR_SEGMENT)):
        raise ValueError('Integrated 289 anchors not unique; refusing patch')
    if GUARD_LINE.strip() in src and GUARD_SEGMENT.strip() in src:return src,False
    if 'SV04 NEXT 290:' in src:raise ValueError('Conflicting or partial V290 patch')
    for sign,anchor,guard in ((SIGN_SEGMENT,ANCHOR_SEGMENT,GUARD_SEGMENT),(SIGN_LINE,ANCHOR_LINE,GUARD_LINE)):
        if src.index(sign)>=src.index(anchor):raise ValueError('Unexpected planner code order')
        pos=src.index(anchor);src=src[:pos]+guard+src[pos:]
    return src,True

def main():
    parser=argparse.ArgumentParser();parser.add_argument('oem_root',type=Path);args=parser.parse_args()
    path=args.oem_root/'Marlin/src/module/planner.cpp'
    content=path.read_text(encoding='utf-8')
    patched,changed=transform(content)
    if changed:path.write_text(patched,encoding='utf-8')
    print('PATCHED' if changed else 'ALREADY_APPLIED',path)
    print('SHA256',hashlib.sha256(patched.encode()).hexdigest())
if __name__=='__main__':main()
