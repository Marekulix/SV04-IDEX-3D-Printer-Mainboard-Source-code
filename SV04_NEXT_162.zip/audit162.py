#!/usr/bin/env python3
"""Mutation-aware fail-closed audits, no false claims about firmware capabilities."""
import pathlib,subprocess,tempfile,json,sys
p=pathlib.Path(__file__).resolve().parent
h=(p/'SV04NextDiagnostics162.hpp').read_text()
for s in ['DeniedNotVerified','ReadOnlyStatus','static_assert','SV04NextAuto60Gate161.hpp','(void)raw_vp','(void)value']:
 assert s in h,s
for forbidden in ['queue.inject','settings.save(','G29()','thermalManager.setTargetBed(','G28();','#define SV04_NEXT_FLASH_RELEASE']:
 assert forbidden not in h,forbidden
r=subprocess.run(['g++','-std=c++11','-Wall','-Wextra','-Werror','-pedantic','-I'+str(p/'old161'),'-I'+str(p),str(p/'test162.cpp'),'-o',str(p/'test162')],capture_output=True,text=True)
assert r.returncode==0,r.stdout+r.stderr
assert subprocess.run([str(p/'test162')]).returncode==0
# Compile-time mutation: forbidden release switches must FAIL to compile.
for macro in ['SV04_NEXT_AUTO60_RELEASE','SV04_NEXT_DWIN_TOUCH_RELEASE','SV04_NEXT_T1_MOTION_RELEASE','SV04_NEXT_EEPROM_RELEASE','SV04_NEXT_FLASH_RELEASE']:
 with tempfile.TemporaryDirectory() as tmp:
  r=subprocess.run(['g++','-std=c++11','-D'+macro,'-I'+str(p/'old161'),'-I'+str(p),'-fsyntax-only',str(p/'test162.cpp')],capture_output=True,text=True)
  assert r.returncode!=0 and 'forbidden' in r.stderr.lower(),(macro,r.stderr)
print('PASS: C++11 read-only query, 256 request types x 3 VP inputs, 5 forbidden build variants')
