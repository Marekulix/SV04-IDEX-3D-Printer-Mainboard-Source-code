#!/usr/bin/env python3
"""Apply only AFTER the immutable 161 staging step; do not bind a real UI event."""
import argparse,hashlib,json,pathlib,shutil
ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);ap.add_argument('--bundle',required=True);ap.add_argument('--out',required=True);a=ap.parse_args()
root=pathlib.Path(a.root);bundle=pathlib.Path(a.bundle);out=pathlib.Path(a.out);out.mkdir(parents=True,exist_ok=True)
feature=root/'Marlin/src/feature';lcd=root/'Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp'
assert lcd.is_file() and (feature/'SV04NextAuto60Gate161.hpp').is_file(), '161 must be staged first'
txt=lcd.read_text();anchor='#include "../../../feature/SV04NextAuto60Gate161.hpp"'
assert txt.count(anchor)==1,'161 LCD include is absent or duplicated'
assert 'SV04NextDiagnostics162.hpp' not in txt, '162 must never overwrite existing integration'
new=feature/'SV04NextDiagnostics162.hpp';assert not new.exists(), '162 source already exists'
shutil.copy2(bundle/'SV04NextDiagnostics162.hpp',new)
lcd.write_text(txt.replace(anchor,anchor+'\n#include "../../../feature/SV04NextDiagnostics162.hpp"',1))
assert lcd.read_text().count('SV04NextDiagnostics162.hpp')==1
report={'version':162,'scope':'READ_ONLY_LINKED_DIAGNOSTICS_NO_ACTUATORS','status':'SOURCE_STAGED_NOT_HARDWARE_VALIDATED','release_allowed':False,'flash_approved':False,'runtime_touch_event_bound':False,'runtime_auto60_command_bound':False,'real_bl_touch_motion_validated':False,'eeprom_write_allowed':False,'pending':['verified DWIN VP mapping','actuator state machine and Marlin hooks','EEPROM transaction backend with rollback','physical T0/T1 and BLTouch safety tests'], 'files':{str(x.relative_to(root)):hashlib.sha256(x.read_bytes()).hexdigest() for x in (new,lcd)}}
(out/'integration162.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS: 162 header staged in actual Marlin LCD compile unit, all actuator routes closed')
