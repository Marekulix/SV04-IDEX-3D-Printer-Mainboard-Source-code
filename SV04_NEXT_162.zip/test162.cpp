#include "SV04NextDiagnostics162.hpp"
#include <cassert>
#include <stdint.h>
#include <initializer_list>
int main() {
  const sv04next162::Status s = sv04next162::status();
  assert(s.diagnostics_module_compiled && !s.hmi_mapping_verified && !s.auto60_operational);
  assert(!s.eeprom_write_allowed && !s.hardware_validated && !s.flash_approved);
  for (int raw=0; raw<256; ++raw) {
    const sv04next162::Request r=static_cast<sv04next162::Request>(raw);
    for (unsigned vp : {0u, 59u, 0xffffu}) {
      const sv04next162::Decision d=sv04next162::request(r,static_cast<uint16_t>(vp),0xffff);
      assert(d.allowed == (r==sv04next162::Request::Query));
      assert(d.reason == (r==sv04next162::Request::Query ? sv04next162::Reason::ReadOnlyStatus : sv04next162::Reason::DeniedNotVerified));
    }
  }
  sv04::Guards g; sv04::PersistenceInterlocks141 e;
  assert(!sv04next161::auto60_start_authorized(g));
  assert(!sv04next161::permit_eeprom_commit(e));
  assert(!sv04next161::dispatch_dwin_touch(59,0xffff));
}
