# SV04 NEXT 162 – verified read-only integration boundary

**DO NOT FLASH. NO HEAT, MOTION, G28/G29, EEPROM WRITE OR NEW TOUCH MAPPING.**

A Marlin-LCD compile-linked diagnostic request API is introduced. A read-only Query is permitted, but EVERY state-changing request, including unknown raw request types and unverified DWIN VPs, is denied. This is source-level integration, not a working DWIN display or an Auto60 start button.

CI validates 161 -> 162 staging, compiles the combined STM32 project, tests all 29 Auto60 regressions from 159, performs exhaustive deny-list sweeps, rejects five release macros and inventories original DWIN 112 assets. Hardware and physical IDEX safety tests cannot be performed on GitHub runners. Untrusted ZIPs remain code; nothing is ever flashed or released.

These are genuine limits: actual DWIN raw VP mapping is not known; no authenticated hardware mapping has been added. The printer's original firmware must be retained.
