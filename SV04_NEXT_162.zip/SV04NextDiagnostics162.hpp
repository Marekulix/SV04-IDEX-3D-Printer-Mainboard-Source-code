#pragma once
// SV04 NEXT 162: a read-only compile-linked diagnostic API. NOT FOR INSTALL.
// No touch address, G-code hook, movement, heater, BLTouch or EEPROM backend.
#if defined(SV04_NEXT_AUTO60_RELEASE) || defined(SV04_NEXT_DWIN_TOUCH_RELEASE) || defined(SV04_NEXT_T1_MOTION_RELEASE) || defined(SV04_NEXT_EEPROM_RELEASE) || defined(SV04_NEXT_FLASH_RELEASE)
#error "SV04 NEXT 162: actuator/release flags forbidden"
#endif
#include <stdint.h>
#include "SV04NextAuto60Gate161.hpp"
namespace sv04next162 {
enum class Request : uint8_t { Query=0, Start=1, Heat=2, Home=3, Mesh=4, Persist=5, Touch=6, Unknown=255 };
enum class Reason : uint8_t { ReadOnlyStatus=0, DeniedNotVerified=1 };
struct Decision { bool allowed; Reason reason; };
struct Status {
  bool diagnostics_module_compiled;
  bool hmi_mapping_verified;
  bool auto60_operational;
  bool eeprom_write_allowed;
  bool hardware_validated;
  bool flash_approved;
};
inline Status status() {
  Status s = { true, false, false, false, false, false };
  return s;
}
inline Decision request(const Request request_type, const uint16_t raw_vp, const uint16_t value) {
  // Deliberately ignore untrusted raw VP/value. The original resource map is not proven.
  (void)raw_vp; (void)value;
  if (request_type == Request::Query) return {true, Reason::ReadOnlyStatus};
  return {false, Reason::DeniedNotVerified};
}
static_assert(!sv04next161::motion_enabled && !sv04next161::heat_enabled &&
              !sv04next161::eeprom_write_enabled && !sv04next161::hmi_touch_enabled,
              "161 safety boundary must remain closed");
}
