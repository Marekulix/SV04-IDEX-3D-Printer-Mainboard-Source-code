SV04 NEXT 297 – verified build-retry source package, NO FLASH.

IMPORTANT: Upload A 297.zip to repository ROOT without renaming.
Upload B 297.yml to .github/workflows/ without renaming.
The workflow deliberately uses A 297.zip, not SV04_NEXT_297.zip, so no Android rename is needed.
Firmware logic is unchanged from the verified 292/293/294 patch chain.
Changes: full workflow audit, quoted filename, independent SHA-256, no matrix.
This is NOT a successful STM32 build or hardware approval.
