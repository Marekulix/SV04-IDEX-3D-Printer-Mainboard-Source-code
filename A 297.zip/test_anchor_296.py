#!/usr/bin/env python3
"""Check 292->293 against the exact pinned 285 Auto60 adapter source.
This prevents repeating the actual failure encountered in GitHub Run 295.
"""
from pathlib import Path
from apply_eeprom_policy_292 import apply as apply292
from apply_eeprom_commit_guard_293 import apply as apply293
base = (Path(__file__).parent / 'BASELINE_AUTO60_285.inc').read_text(encoding='utf-8')
first, change292 = apply292(base)
assert change292 and '#define SV04_CLAUDE_EEPROM_REQUIRE_JOURNAL 1' in first
assert apply292(first) == (first, False)
second, change293 = apply293(first)
assert change293 and 'SV04 NEXT 293: journal closure must be confirmed' in second
assert apply293(second) == (second, False)
assert 'SV04 NEXT 292: testable conservative policy' in second
print('296 REGRESSION PASS: pinned source -> 292 -> 293, both idempotent')
