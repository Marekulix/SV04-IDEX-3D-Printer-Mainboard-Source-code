// Shared offline-model timing limits. No implicit permission to actuate.
#pragma once
#include <stdint.h>
namespace sv04next {
struct Auto60Policy final {
  static constexpr uint32_t CommandAcceptMs=30000u;
  static constexpr uint32_t HeatTimeoutMs=720000u; // agrees with SequencedController
  static constexpr uint32_t TemperatureHoldMs=20000u;
  static constexpr uint32_t SensorGapMs=3000u;
  static constexpr uint32_t HomeTimeoutMs=180000u;
  static constexpr uint32_t ProbeTimeoutMs=900000u;
  static constexpr float BedTargetC=60.f;
  static constexpr float StableWindowC=1.f;
  // Stand 20: Fortschrittswaechter beim Aufheizen. Herleitung aus der EINEN echten Heizkurve (Hardware 02.11., tools/thermal_trace_analyze.py):
  // unter 57 C stieg das Bett mit mindestens 0,144 C/s, kleinster Anstieg in einem 30-s-Fenster +4,62 C. Gefordert wird nur +1,0 C je 30 s unter 55 C
  // (4,6-fache Reserve). KEINE Statistik (ein Lauf, ein Sensor, Probenabstand ca. 30 s): Werte konservativ, nicht optimiert.
  static constexpr uint32_t ProgressWindowMs=30000u;
  static constexpr float MinProgressC=1.f;
  static constexpr float ProgressUntilC=55.f;
};
}
