SV04 NEXT 159: Neu nummeriertes GitHub-Paket mit dem unveraenderten Auto60-Hosttest-Quellstand 157. Keine neu integrierte Firmware; NICHT FLASHEN.
