# SV04 NEXT 147 | EEPROM-Ausfall- und Wiederanlaufkonzept

**NICHT INSTALLIEREN. Nur C++-Host-Modell. GitHub wurde nicht verändert.**

## Quellen und belegte Gefahren

Sovol OEM Marlin (`Sovol3d/SV04-IDEX-3D-Printer-Mainboard-Source-code`, Commit `1867fcba75354a5c65e0631d6972dd19f1bd6cbe`):
- `Marlin/src/HAL/STM32F1/eeprom_flash.cpp`: Im Flash-Backend werden beim Abschluss eines schreibenden Zugriffs die EEPROM-Flashseiten gelöscht und neu programmiert. Stromausfall im kritischen Fenster kann die gespeicherten Einstellungen zerstören.
- `Marlin/src/module/settings.cpp`: `MarlinSettings::save()` speichert komplette Einstellungen, nicht nur das ABL-Mesh, und die Version/CRC werden am Ende geschrieben.
- `Marlin/src/HAL/shared/eeprom_api.h`: `read_data()` / `write_data()` nutzen **true = Fehler**; HAL-`access_finish()` ist backendabhängig.

## Entwicklung

Neues Modul: `eeprom_recovery_journal147.h`, Test: `test147.cpp`.

Ein unabhängiges Journal mit zwei alternierenden Einträgen speichert je Transaktion: Backup-Prüfsumme/-Länge, Sollabbild-Prüfsumme/-Länge, monoton steigende Generation und Status. Der Journal-Eintrag wird **erst nach persistenter Speicherung und Rücklesen** als gültig angenommen.

Zustände:
1. `Empty` = sicherer Ausgangszustand, manuell vorbereitet.
2. `BackupVerified` = unabhängiges Alt-EEPROM-Abbild bestätigt.
3. `WriteIntent` = Schreibabsicht **vor** einem einzigen Schreibversuch dauerhaft notiert.
4. `WriteReported` = Software meldet erfolgreichen Schreibversuch, unabhängige Prüfung fehlt noch.
5. `Verified` = unabhängige Version-/CRC-/Mesh-/Abbild-Prüfung erfolgreich.
6. `Quarantine` = Fehler/unvollständige oder widersprüchliche Daten; keine Schreibfreigabe.

**Nach jedem Neustart** werden `BackupVerified`, `WriteIntent`, `WriteReported` und `Quarantine` gesperrt. Nur `Verified` und `Empty` sind definierte sichere Journalzustände. Bereits an anderer Stelle geänderte EEPROM-Daten erfordern vor jeder neuen Aktion eine erneute vollständige Prüfung.

## Nicht behaupten

- Die zweifache Journal-Ablage schützt nur, wenn das **externe Medium wirklich unabhängig** ist und einzelne Slots atomar und dauerhaft gespeichert werden. Diese Hardwarevoraussetzung ist am SV04 noch **nicht nachgewiesen**.
- Ein erfolgreiches C++-Modell ersetzt weder eine Flash-seitige A/B-Speicherarchitektur noch einen unabhängigen Bootloader-Recovery-Pfad. Der OEM-Treiber ist **nicht stromausfallsicher**.
- Das Journal stellt EEPROM **nicht** selbst wieder her. Kein automatisches M500, kein M501, kein Flash-Schreibzugriff, kein BLTouch-Befehl.
- `BackupProof147` und `TargetProof147` sind Zertifikatsverträge, keine echten Nachweise. Firmware/Hardware müssen sie erst zuverlässig erzeugen.
- Wiederherstellung mit reinem Neuschreiben eines Backups ist während eines Stromausfalls ebenfalls gefährdet. Erst ein hardwaregeprüfter Recovery-Weg mit getrenntem Medium und abgesichertem, kontrolliertem Serviceablauf wäre zulässig.

## Prüfungen

Neu: `g++ -std=c++17 -Wall -Wextra -Werror -pedantic -fsanitize=address,undefined test147.cpp -o test147 && ./test147` => **75 bestandene Assertions**.
Alt: **16 C++-Regressionstests + 2 Python-Tests** aus Stand 146 bestanden.

## Nächste Phase 148

- Konkretes externes Speicherziel am SV04 bestimmen und unabhängig prüfen.
- Aktiven STM32F1-Flash-Backend-Pfad und Flash-Seitengröße im wirklichen Build bestätigen.
- Nichtdestruktive Firmware-Diagnose für Journal und EEPROM-Zustand erstellen.
- Physische Wiederanlauf-/Stromausfallsicherheit erst nach getrenntem Recovery-Verfahren validieren. **Bis dahin M500-Automatik gesperrt.**
