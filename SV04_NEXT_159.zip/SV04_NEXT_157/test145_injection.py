#!/usr/bin/env python3
import pathlib, subprocess, tempfile
source='''} SettingsData;\nbool MarlinSettings::_load() {\n int eeprom_index=100;\n        EEPROM_READ_ALWAYS(grid_max_x);                // 1 byte\n        EEPROM_READ_ALWAYS(grid_max_y);                // 1 byte\n            EEPROM_READ(bilinear_grid_spacing);        // 2 ints\n            EEPROM_READ(bilinear_start);               // 2 ints\n            EEPROM_READ(z_values);                     // 9 to 256 floats\n    EEPROM_FINISH();\n\n    return !eeprom_error;\n  }\n'''
with tempfile.TemporaryDirectory() as td:
 p=pathlib.Path(td)/'settings.cpp';p.write_text(source)
 x=subprocess.run(['python3',__file__.replace('test145_injection.py','settings_layout145_inject.py'),str(p)],capture_output=True,text=True)
 assert x.returncode==0,x.stderr
 t=p.read_text()
 assert t.count('SV04_NEXT_145_LAYOUT_BEGIN')==1
 assert 'captured.grid_x = uint32_t(eeprom_index)' in t
 assert 'captured.verified_load = !eeprom_error' in t
 assert 'EEPROM_WRITE(' not in t and 'M500' not in t
 y=subprocess.run(['python3',__file__.replace('test145_injection.py','settings_layout145_inject.py'),str(p)],capture_output=True,text=True)
 assert y.returncode!=0
 print('SV04 NEXT 145: injection smoke and idempotency checks PASS')
