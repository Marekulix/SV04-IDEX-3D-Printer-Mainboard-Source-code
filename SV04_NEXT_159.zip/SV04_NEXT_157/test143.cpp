#include "eeprom_flash_adapter143.h"
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <vector>
using namespace sv04;
static int checks=0;
#define CHECK(c) do {++checks;if(!(c)){std::cerr<<"FAILED line "<<__LINE__<<" "<<#c<<"\n";std::abort();}}while(0)
struct Flash:FlashRead143 {
 std::vector<uint8_t> b=std::vector<uint8_t>(2048);
 bool certified=true,begin_ok=true,end_ok=true,read_ok=true,drift=false,in_session=false;
 size_t reads=0;int begin_count=0,finish_count=0,write_count=0;
 Flash(){for(size_t i=0;i<b.size();++i)b[i]=uint8_t(i*13+41);}
 bool certified_flash_read_without_write() const override{return certified;}
 size_t capacity()const override{return b.size();}
 bool begin_read() override {++begin_count; if(!begin_ok)return false;in_session=true;return true;}
 bool read_at(size_t offset,uint8_t* dst,size_t len) override {
  ++reads;if(!in_session||!read_ok||offset>b.size()||len>b.size()-offset)return false;
  std::copy(b.begin()+offset,b.begin()+offset+len,dst);
  if(drift && begin_count==2 && offset==0)dst[0]^=1;
  return true;
 }
 bool end_read()override{++finish_count;in_session=false;return end_ok;}
};
struct Store:SeparateStorage143 {
 std::vector<uint8_t> saved;bool separate=true,begin_ok=true,write_ok=true,final_ok=true,verify_ok=true,read_ok=true,end_ok=true,corrupt=false;
 bool independent_durable_and_readable() const override{return separate;}
 bool begin_archive(size_t n) override{if(!begin_ok)return false;saved.assign(n,0);return true;}
 bool write_block(size_t off,const uint8_t*p,size_t n) override{if(!write_ok || off+n>saved.size())return false;std::copy(p,p+n,saved.begin()+off);return true;}
 bool finish_archive()override{return final_ok;}
 bool begin_verify()override{return verify_ok;}
 bool read_archive(size_t off,uint8_t*p,size_t n)override{if(!read_ok||off+n>saved.size())return false;std::copy(saved.begin()+off,saved.begin()+off+n,p);if(corrupt&&off==0)p[0]^=1;return true;}
 bool end_verify()override{return end_ok;}
};
int main(){
 {Flash f;Store s;FullFlashBackup143 x;CHECK(x.capture(f,s,true,true,true));CHECK(x.verified());CHECK(x.size()==2048);CHECK(x.digest()!=0);CHECK(f.write_count==0);CHECK(f.begin_count==2);CHECK(f.finish_count==2);CHECK(!x.capture(f,s,true,true,true));}
 for(int j=0;j<19;j++){
  Flash f;Store s;FullFlashBackup143 x;bool idle=true,locked=true,stopped=true;
  switch(j){case 0:idle=false;break;case 1:locked=false;break;case 2:stopped=false;break;
   case 3:f.certified=false;break;case 4:s.separate=false;break;
   case 5:f.b.resize(127);break;case 6:f.b.resize(kMax143+4);break;case 7:f.b.resize(2049);break;
   case 8:f.begin_ok=false;break;case 9:f.read_ok=false;break;case 10:f.end_ok=false;break;
   case 11:s.begin_ok=false;break;case 12:s.write_ok=false;break;case 13:s.final_ok=false;break;
   case 14:s.verify_ok=false;break;case 15:s.read_ok=false;break;case 16:s.end_ok=false;break;
   case 17:s.corrupt=true;break;case 18:f.drift=true;break;}
  CHECK(!x.capture(f,s,idle,locked,stopped));CHECK(!x.verified());CHECK(x.digest()==0);
  CHECK(!x.capture(f,s,true,true,true));CHECK(f.write_count==0);
 }
 // Check a variety of capacities and all 64-byte boundaries incl. last partial block
 for(size_t n=128;n<=4096;n+=4){Flash f;Store s;FullFlashBackup143 x;f.b.resize(n);
  CHECK(x.capture(f,s,true,true,true));CHECK(x.size()==n);CHECK(s.saved==f.b);CHECK(f.write_count==0);}
 std::cout<<"SV04 NEXT 143: "<<checks<<" adapter assertions PASS; MOCKS ONLY, no flash writes\n";
}
