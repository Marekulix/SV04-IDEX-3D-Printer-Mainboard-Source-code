#include "persistentstore_contract143.h"
#include <vector>
#include <cassert>
#include <iostream>
using namespace sv04;
struct PersistentStoreFake {
 static inline std::vector<uint8_t> content=std::vector<uint8_t>(4096,0xA5);
 static inline int writes=0;static inline bool read_error=false,finish_ok=true;
 static size_t capacity(){return content.size();}
 static bool access_start(){return true;}
 static bool access_finish(){return finish_ok;}
 static bool read_data(int &pos,uint8_t* out,size_t count,uint16_t*,bool writing){
  if(read_error||!writing||pos<0||size_t(pos)+count>content.size())return true;
  for(size_t j=0;j<count;j++)out[j]=content[size_t(pos)+j];
  pos+=int(count);return false;
 }
 static bool write_data(int &,const uint8_t*,size_t,uint16_t*){++writes;return false;}
};
struct ArchiveMock:SeparateStorage143 {
 std::vector<uint8_t> bytes;
 bool independent_durable_and_readable()const override{return true;}
 bool begin_archive(size_t n)override{bytes.resize(n);return true;}
 bool write_block(size_t p,const uint8_t*v,size_t n)override{for(size_t i=0;i<n;i++)bytes[p+i]=v[i];return true;}
 bool finish_archive()override{return true;}
 bool begin_verify()override{return true;}
 bool read_archive(size_t p,uint8_t*v,size_t n)override{for(size_t i=0;i<n;i++)v[i]=bytes[p+i];return true;}
 bool end_verify()override{return true;}
};
int main(){
  {FlashBackend143<PersistentStoreFake> source(false);ArchiveMock archive;FullFlashBackup143 tx;
   assert(!tx.capture(source,archive,true,true,true));assert(PersistentStoreFake::writes==0);}
  {FlashBackend143<PersistentStoreFake> source(true);ArchiveMock archive;FullFlashBackup143 tx;
   assert(tx.capture(source,archive,true,true,true));assert(tx.verified());assert(archive.bytes==PersistentStoreFake::content);assert(PersistentStoreFake::writes==0);}
  {FlashBackend143<PersistentStoreFake> source(true);ArchiveMock archive;FullFlashBackup143 tx;
   PersistentStoreFake::read_error=true;assert(!tx.capture(source,archive,true,true,true));assert(!tx.verified());
   PersistentStoreFake::read_error=false;}
  {FlashBackend143<PersistentStoreFake> source(true);ArchiveMock archive;FullFlashBackup143 tx;
   PersistentStoreFake::finish_ok=false;assert(!tx.capture(source,archive,true,true,true));assert(!tx.verified());
   PersistentStoreFake::finish_ok=true;}
  std::cout<<"SV04 NEXT 143: PersistentStore API error and buffer semantics PASS; MOCK ONLY\n";
}
