#include "eeprom_integrity144.h"
#include <vector>
#include <cassert>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <limits>
using namespace sv04;
static unsigned checks=0;
#define CHECK(x) do {checks++;if(!(x)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x);std::abort();}}while(0)
static Layout144 layout(){Layout144 x; x.total_eeprom_capacity=4096;x.settings_data_size=800;
 x.grid_x_offset=300; x.grid_y_offset=301;x.mesh_spacing_offset=302;x.mesh_origin_offset=310;
 x.mesh_offset=318;x.xy_pos_bytes=8;x.layout_compiled_and_verified=true;x.flash_backend_certified=true;return x;}
static void write32(std::vector<uint8_t>& b,size_t at,float v){uint32_t x;std::memcpy(&x,&v,4);for(int i=0;i<4;i++)b[at+i]=uint8_t(x>>(i*8));}
static void fixcrc(std::vector<uint8_t>& b,const Layout144& l){size_t pos=EEPROM_OFFSET_144+4;uint16_t crc=crc16_marlin144(b.data()+106,l.settings_data_size-6);b[pos]=uint8_t(crc);b[pos+1]=uint8_t(crc>>8);}
static std::vector<uint8_t> specimen(const Layout144& l){std::vector<uint8_t> b(l.total_eeprom_capacity,0xA5);b[100]='V';b[101]='8';b[102]='5';b[103]=0;b[l.grid_x_offset]=4;b[l.grid_y_offset]=4;
 for(int i=0;i<16;i++) {write32(b,l.mesh_offset+i*4,float(i-8)*0.125f);} fixcrc(b,l);return b;}
int main(){auto l=layout();auto b=specimen(l);auto r=verify_eeprom144(b.data(),b.size(),l);
 CHECK(r.verified());CHECK(r.stored_crc==r.computed_crc);CHECK(r.mesh[0]==-1.0f);CHECK(r.mesh[15]==0.875f);
 float expect[16];for(int i=0;i<16;i++)expect[i]=r.mesh[i];CHECK(same_mesh144(b.data(),b.size(),l,expect));
 expect[4]+=0.001f;CHECK(!same_mesh144(b.data(),b.size(),l,expect));expect[4]=r.mesh[4];
 {auto x=l;x.layout_compiled_and_verified=false;CHECK(verify_eeprom144(b.data(),b.size(),x).result==Integrity144::Refused);}
 {auto x=l;x.flash_backend_certified=false;CHECK(verify_eeprom144(b.data(),b.size(),x).result==Integrity144::Refused);}
 {auto x=l;x.settings_data_size=0;CHECK(verify_eeprom144(b.data(),b.size(),x).result==Integrity144::BadBounds);}
 {auto x=l;x.mesh_offset=b.size()-60;CHECK(verify_eeprom144(b.data(),b.size(),x).result==Integrity144::BadBounds);}
 {auto x=l;x.mesh_origin_offset=0;CHECK(verify_eeprom144(b.data(),b.size(),x).result==Integrity144::BadBounds);}
 {auto x=l;x.settings_data_size=b.size();CHECK(verify_eeprom144(b.data(),b.size(),x).result==Integrity144::BadBounds);}
 CHECK(verify_eeprom144(nullptr,b.size(),l).result==Integrity144::Refused);
 CHECK(verify_eeprom144(b.data(),b.size()-1,l).result==Integrity144::BadBounds);
 {auto x=b;x[100]='X';CHECK(verify_eeprom144(x.data(),x.size(),l).result==Integrity144::BadVersion);}
 {auto x=b;x[103]='Q';CHECK(verify_eeprom144(x.data(),x.size(),l).result==Integrity144::BadVersion);}
 {auto x=b;x[105]^=0x80;CHECK(verify_eeprom144(x.data(),x.size(),l).result==Integrity144::BadCRC);}
 {auto x=b;x[107]^=0x80;CHECK(verify_eeprom144(x.data(),x.size(),l).result==Integrity144::BadCRC);}
 {auto x=b;x[l.grid_x_offset]=3;fixcrc(x,l);CHECK(verify_eeprom144(x.data(),x.size(),l).result==Integrity144::GridMismatch);}
 {auto x=b;x[l.grid_y_offset]=5;fixcrc(x,l);CHECK(verify_eeprom144(x.data(),x.size(),l).result==Integrity144::GridMismatch);}
 {auto x=b;write32(x,l.mesh_offset+4*5,std::numeric_limits<float>::quiet_NaN());fixcrc(x,l);CHECK(verify_eeprom144(x.data(),x.size(),l).result==Integrity144::BadMeshNumbers);}
 {auto x=b;write32(x,l.mesh_offset+4*15,std::numeric_limits<float>::infinity());fixcrc(x,l);CHECK(verify_eeprom144(x.data(),x.size(),l).result==Integrity144::BadMeshNumbers);}
 // Every byte in the CRC-covered region must be protected against accidental changes.
 for(size_t i=106;i<900;i++) {auto x=b;x[i]^=0x01;CHECK(verify_eeprom144(x.data(),x.size(),l).result==Integrity144::BadCRC);}
 // Values in unprotected area must not be misinterpreted as a valid mesh provenance proof.
 {auto x=b;x[950]^=0xF0;CHECK(verify_eeprom144(x.data(),x.size(),l).verified());}
 printf("SV04 NEXT 144: %u checks PASS; synthetic layout only. NO FLASH READ OR WRITE.\n",checks);
}
