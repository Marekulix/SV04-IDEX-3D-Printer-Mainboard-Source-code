#include "sd_exclusive151.h"
#include <cassert>
#include <cstdio>
#include <map>
using namespace sv04;
unsigned checks=0;
#define CHECK(x) do { if(!(x)){std::fprintf(stderr,"FAIL at %d: %s\n",__LINE__,#x);return 1;}++checks;}while(0)
struct Shared;
struct Port: SdPort150 {
  Shared* owner=nullptr;
  uint64_t epoch=7;
  bool mounted_value=true;
  unsigned calls=0, mutate_at=0;
  std::map<unsigned,std::vector<uint8_t>> files;
  bool mounted()const override {return mounted_value;}
  uint64_t mount_epoch()const override{return epoch;}
  bool read_exact(unsigned id,size_t limit,std::vector<uint8_t>& out)override;
};
struct Shared: SdOwnership151 {
  SdSnapshot151 state{};bool lease=false, deny=false;unsigned acquires=0,releases=0;
  SdSnapshot151 snapshot()const override{return state;}
  bool try_acquire_exclusive_read()override{++acquires;if(deny||lease)return false;lease=true;return true;}
  void release_exclusive_read()override{++releases;lease=false;}
};
bool Port::read_exact(unsigned id,size_t limit,std::vector<uint8_t>& out){
  ++calls;
  if(mutate_at==calls)owner->state.media_generation++;
  if(!owner->lease)return false;
  auto it=files.find(id);
  if(it==files.end()||it->second.size()>limit)return false;
  out=it->second;return true;
}
int main(){
  Shared s;Port p;p.owner=&s;
  s.state.mounted=true;s.state.mount_epoch=7;s.state.media_generation=2;s.state.card_identity_verified=true;
  Backup149 b{67,19,2,std::vector<uint8_t>(256,0x34)};
  p.files[0]=encode149(b);p.files[1]=commit149(b);
  {auto result=scan_exclusive151(s,p,67,19,256);CHECK(result.gate==SdGate151::Clear);
   CHECK(result.backup_readable_for_diagnostics);CHECK(!result.may_write_sd);
   CHECK(!result.may_write_eeprom);CHECK(!result.may_restore_eeprom);
   CHECK(s.acquires==1);CHECK(s.releases==1);CHECK(!s.lease);}
  for(unsigned bit=0;bit<11;++bit){
    SdSnapshot151 t=s.state;
    switch(bit){case 0:t.mounted=false;break;case 1:t.mount_epoch=0;break;
    case 2:t.card_identity_verified=false;break;case 3:t.media_change_pending=true;break;
    case 4:t.print_active=true;break;case 5:t.print_paused=true;break;
    case 6:t.file_open=true;break;case 7:t.saving=true;break;
    case 8:t.logging=true;break;case 9:t.recovery_busy=true;break;
    case 10:t.other_io_busy=true;break;}
    CHECK(check_sd151(t)!=SdGate151::Clear);
    const unsigned prior=s.acquires;s.state=t;
    auto r=scan_exclusive151(s,p,67,19,256);
    CHECK(r.gate!=SdGate151::Clear);CHECK(s.acquires==prior);CHECK(!r.may_write_eeprom);
    s.state.mounted=true;s.state.mount_epoch=7;s.state.media_generation=2;
    s.state.card_identity_verified=true;s.state.media_change_pending=false;
    s.state.print_active=s.state.print_paused=s.state.file_open=false;
    s.state.saving=s.state.logging=s.state.recovery_busy=s.state.other_io_busy=false;
  }
  s.deny=true;CHECK(scan_exclusive151(s,p,67,19,256).gate==SdGate151::LeaseDenied);
  CHECK(!s.lease);s.deny=false;
  for(unsigned n=1;n<=8;++n){p.calls=0;p.mutate_at=n;
    auto r=scan_exclusive151(s,p,67,19,256);
    CHECK(r.gate==SdGate151::StateChanged);CHECK(!r.backup_readable_for_diagnostics);
    CHECK(s.acquires==s.releases+1);CHECK(!s.lease);
    s.state.media_generation=2;
  }
  p.mutate_at=0;
  {auto r=scan_exclusive151(s,p,67,19,257);CHECK(r.gate==SdGate151::ScanRejected);CHECK(!r.backup_readable_for_diagnostics);}
  p.epoch=8;CHECK(scan_exclusive151(s,p,67,19,256).gate==SdGate151::StateChanged);p.epoch=7;
  for(unsigned i=0;i<200;++i){auto t=s.state;
    if(i%4==0)t.print_paused=true;
    else if(i%4==1)t.file_open=true;
    else if(i%4==2)t.recovery_busy=true;
    else t.logging=true;
    s.state=t;
    CHECK(!scan_exclusive151(s,p,67,19,256).backup_readable_for_diagnostics);
    CHECK(!s.lease);
    s.state.print_paused=s.state.file_open=s.state.recovery_busy=s.state.logging=false;
  }
  CHECK(s.acquires==s.releases+1);
  std::printf("test151 PASS: %u assertions\n",checks);
}
