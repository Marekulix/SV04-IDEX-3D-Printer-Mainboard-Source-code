#include "auto60_idex_bridge.h"
#include <cassert>
#include <iostream>
using namespace sv04;
static IDEXInputs ready(){ IDEXInputs g;g.machine_idle=true;g.planner_empty_and_steppers_stopped=true;g.mode=CarriageMode::AutoPark;g.t0_selected=true;g.t1_parked_sensor_or_verified_homing=true;g.no_obstructions_confirmed=true;g.probe_selfcheck_passed=true;g.endstops_selfcheck_passed=true;g.bed_and_tools_safe=true;g.physical_clearance_confirmed=true;g.geometry_matches_oem=true;return g; }
static Guards guards(){ Guards g;g.idle=g.heaters_ok=g.axes_safe=g.tool_safe=g.probe_ready=g.snapshot_valid=true;return g; }
int main(){int n=0;auto ok=[&](bool b){n++;assert(b);};
 Controller c; IDEXInputs idex=ready();
 ok(!permit_home(c,idex).allowed);
 ok(c.start(guards(),100));
 ok(!permit_home(c,idex).allowed);
 c.ack(Action::SetBed60,true,110);
 c.temperature(60,1000);
 c.temperature(60,31001);
 ok(c.phase()==Phase::Home);
 ok(c.pending()==Action::HomeSafely);
 ok(permit_home(c,idex).allowed);
 auto changed=idex;changed.t1_parked_sensor_or_verified_homing=false;
 ok(!permit_home(c,changed).allowed);
 ok(permit_home(c,changed).reason==GateReason::ParkNotConfirmed);
 changed=idex;changed.mode=CarriageMode::Mirrored;
 ok(!permit_home(c,changed).allowed);
 changed=idex;changed.probe_selfcheck_passed=false;
 ok(!permit_home(c,changed).allowed);
 changed=idex;changed.planner_empty_and_steppers_stopped=false;
 ok(!permit_home(c,changed).allowed);
 HomingResult result;
 ok(!accept_home_completion(c,result,32000));
 ok(c.phase()==Phase::Fault);
 ok(c.needs_restore());
 ok(!permit_home(c,idex).allowed);
 c.restore_done(true);
 ok(!c.needs_restore());
 ok(c.start(guards(),40000));
 c.ack(Action::SetBed60,true,40001);
 c.temperature(60,41000);
 c.temperature(60,71001);
 ok(permit_home(c,idex).allowed);
 result.command_completed=result.x_trusted=result.y_trusted=result.z_trusted=result.t0_remains_active=result.t1_still_parked=result.probe_retracted=result.no_faults=true;
 ok(accept_home_completion(c,result,72000));
 ok(c.phase()==Phase::Probe);
 ok(c.pending()==Action::Probe4x4);
 ok(!permit_home(c,idex).allowed);
 std::cout<<"SV04 NEXT 137 controller bridge: "<<n<<" checks passed\n";
}
