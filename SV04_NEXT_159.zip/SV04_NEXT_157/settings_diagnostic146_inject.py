#!/usr/bin/env python3
"""Add an opt-in serial diagnostic to ALREADY-instrumented SV04 settings.cpp.
No EEPROM calls, no GCode injection, no configuration writes. Strict source guards.
"""
from pathlib import Path
import sys

if len(sys.argv) != 2:
    raise SystemExit('Usage: python3 settings_diagnostic146_inject.py <staged settings.cpp>')
p=Path(sys.argv[1]); s=p.read_text(encoding='utf8')
if 'SV04_NEXT_146_DIAGNOSTIC_BEGIN' in s: raise SystemExit('Refused: already instrumented')
if s.count('SV04_NEXT_145_LAYOUT_BEGIN') != 1 or s.count('SV04_NEXT_145_LAYOUT_END') != 1:
    raise SystemExit('Refused: requires exactly one verified 145 insertion')
anchor='''      sv04_layout145::captured.verified_load = !eeprom_error
        && sv04_layout145::captured.observed_grid
        && sv04_layout145::captured.observed_spacing
        && sv04_layout145::captured.observed_origin
        && sv04_layout145::captured.observed_mesh;
    #endif
    return !eeprom_error;'''
if s.count(anchor)!=1: raise SystemExit('Refused: unfamiliar _load() footer')
# Prints on existing _load() path ONLY and only if build macro explicitly enabled.
# Eeprom finish is already executed by OEM before footer; no storage functions called.
repl='''      sv04_layout145::captured.verified_load = !eeprom_error
        && sv04_layout145::captured.observed_grid
        && sv04_layout145::captured.observed_spacing
        && sv04_layout145::captured.observed_origin
        && sv04_layout145::captured.observed_mesh;
      // SV04_NEXT_146_DIAGNOSTIC_BEGIN
      // Opt in via -DSV04_NEXT_LAYOUT146_DIAGNOSTICS; log ONLY once per normal _load().
      // Not proof of EEPROM backend or physical FLASH integrity.
      #if defined(SV04_NEXT_LAYOUT146_DIAGNOSTICS)
        SERIAL_ECHO_MSG("SV04_LAYOUT146 BEGIN");
        SERIAL_ECHO_MSG("SV04_LAYOUT146 protocol=1");
        SERIAL_ECHO_MSG("SV04_LAYOUT146 version=", EEPROM_VERSION);
        SERIAL_ECHO_MSG("SV04_LAYOUT146 verified=", sv04_layout145::captured.verified_load ? 1 : 0);
        SERIAL_ECHO_MSG("SV04_LAYOUT146 capacity=", sv04_layout145::captured.capacity);
        SERIAL_ECHO_MSG("SV04_LAYOUT146 settings_size=", sv04_layout145::captured.settings_size);
        SERIAL_ECHO_MSG("SV04_LAYOUT146 header_offset=", sv04_layout145::captured.header_offset);
        SERIAL_ECHO_MSG("SV04_LAYOUT146 grid_x=", sv04_layout145::captured.grid_x);
        SERIAL_ECHO_MSG("SV04_LAYOUT146 grid_y=", sv04_layout145::captured.grid_y);
        SERIAL_ECHO_MSG("SV04_LAYOUT146 spacing=", sv04_layout145::captured.spacing);
        SERIAL_ECHO_MSG("SV04_LAYOUT146 origin=", sv04_layout145::captured.origin);
        SERIAL_ECHO_MSG("SV04_LAYOUT146 mesh=", sv04_layout145::captured.mesh);
        SERIAL_ECHO_MSG("SV04_LAYOUT146 xy_bytes=", sv04_layout145::captured.xy_bytes);
        SERIAL_ECHO_MSG("SV04_LAYOUT146 mesh_bytes=", sv04_layout145::captured.mesh_bytes);
        SERIAL_ECHO_MSG("SV04_LAYOUT146 END");
      #endif
      // SV04_NEXT_146_DIAGNOSTIC_END
    #endif
    return !eeprom_error;'''
s=s.replace(anchor,repl,1)
p.write_text(s, encoding='utf8')
print('Injected SV04_LAYOUT146 opt-in serial reporting; no EEPROM IO added')
