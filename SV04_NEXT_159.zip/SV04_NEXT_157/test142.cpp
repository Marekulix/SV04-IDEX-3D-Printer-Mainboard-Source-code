#include "eeprom_backup142.h"
#include "auto60_eeprom141.h"
#include <cassert>
#include <iostream>
#include <cstring>
using namespace sv04;
static int checks=0;
#define CHECK(x) do{++checks;if(!(x)){std::cerr<<"FAIL "<<__LINE__<<" "<<#x<<"\n";std::abort();}}while(0)
struct EEPROM:ReadOnlyEEPROM142 {
  std::vector<uint8_t> d=std::vector<uint8_t>(4096);
  bool trusted=true, fail_read=false, corrupt_second=false, drift_after_archive=false;
  int reads=0;
  EEPROM(){for(size_t i=0;i<d.size();i++)d[i]=uint8_t((i*53+7)%256);}
  bool is_independently_attested_read_only()const override{return trusted;}
  size_t capacity()const override{return d.size();}
  bool read(size_t o,uint8_t*p,size_t n) override {
    ++reads; if(fail_read || o+n>d.size())return false;
    std::memcpy(p,d.data()+o,n);
    if(corrupt_second && reads==2)p[120]^=1;
    if(drift_after_archive && reads==3)p[100]^=2;
    return true;
  }
};
struct Archive:IndependentArchive142 {
  bool durable=true,write_ok=true,read_ok=true,corrupt=false;
  std::vector<uint8_t> saved;
  bool is_independent_durable_storage()const override{return durable;}
  bool save(const std::vector<uint8_t>&v) override{if(!write_ok)return false;saved=v;return true;}
  bool load(std::vector<uint8_t>&v) override{if(!read_ok)return false;v=saved;if(corrupt)v[200]^=1;return true;}
};
int main(){
 {EEPROM e;Archive a;EEPROMBackup142 b;CHECK(!b.verified_prior_eeprom_backup());CHECK(b.capture(e,a,true,true,true));CHECK(e.reads==3);CHECK(b.verified_prior_eeprom_backup());CHECK(b.covered_bytes()==4096);CHECK(EEPROMBackup142::check_archive(a.saved));CHECK(!b.capture(e,a,true,true,true));
   auto bad=a.saved;bad[201]^=1;CHECK(!EEPROMBackup142::check_archive(bad));bad=a.saved;bad[0]^=1;CHECK(!EEPROMBackup142::check_archive(bad));bad=a.saved;bad.pop_back();CHECK(!EEPROMBackup142::check_archive(bad));}
 for(int reason=0;reason<12;reason++){
   EEPROM e;Archive a;EEPROMBackup142 b;bool idle=true,locked=true,stopped=true;
   if(reason==0)idle=false;
   if(reason==1)locked=false;
   if(reason==2)stopped=false;
   if(reason==3)e.trusted=false;
   if(reason==4)a.durable=false;
   if(reason==5)e.d.resize(127);
   if(reason==6)e.d.resize(kMaxEEPROMBytes142+1);
   if(reason==7)e.fail_read=true;
   if(reason==8)e.corrupt_second=true;
   if(reason==9)a.write_ok=false;
   if(reason==10)a.read_ok=false;
   if(reason==11)e.drift_after_archive=true;
   CHECK(!b.capture(e,a,idle,locked,stopped));CHECK(b.state()==BackupPhase142::Failed);
   CHECK(!b.capture(e,a,true,true,true)); // Fail-closed latch
 }
 {EEPROM e;Archive a;EEPROMBackup142 b;a.corrupt=true;CHECK(!b.capture(e,a,true,true,true));CHECK(!b.verified_prior_eeprom_backup());}
 {EEPROM e;Archive a;EEPROMBackup142 b;e.d.resize(128);CHECK(b.capture(e,a,true,true,true));CHECK(b.covered_bytes()==128);}
 {EEPROM e;Archive a;EEPROMBackup142 b;e.d.resize(kMaxEEPROMBytes142);CHECK(b.capture(e,a,true,true,true));CHECK(b.covered_bytes()==kMaxEEPROMBytes142);}
 // No backup does not imply an EEPROM write permission: gate 141 still needs
 // separately proven read-only *DECODER*, current G29 and safety conditions.
 {PersistenceInterlocks141 g;g.machine_idle=g.planner_synchronized=g.all_mesh_writers_locked=
    g.motion_stopped=g.thermal_stable=g.no_other_settings_writers=g.exact_4x4_geometry=
    g.user_authorized_save=true;g.read_only_decoder_available=false;
  EEPROM e;Archive a;EEPROMBackup142 b;
  CHECK(b.capture(e,a,true,true,true));g.verified_prior_eeprom_backup=b.verified_prior_eeprom_backup();
  CHECK(!safe_to_write(g));}
 // Fuzz-like bit corruption across backup envelope + image; all detected.
 {EEPROM e;Archive a;EEPROMBackup142 b;CHECK(b.capture(e,a,true,true,true));
  for(size_t pos=0;pos<a.saved.size();++pos){auto modified=a.saved;modified[pos]^=0x80;CHECK(!EEPROMBackup142::check_archive(modified));}
 }
 std::cout<<"SV04 NEXT 142: "<<checks<<" assertions passed; read-only host mocks only, NO firmware EEPROM write\n";
}
