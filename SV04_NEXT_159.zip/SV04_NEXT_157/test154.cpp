#include "sd_cooperative154.h"
#include <cstdio>
#include <map>
using namespace sv04;
static unsigned checks=0;
#define T(x) do {++checks;if(!(x)){std::fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x);return 1;}}while(0)
struct Owner: SdOwnership151 {
  SdSnapshot151 s{};bool held=false,deny=false;unsigned acquires=0,releases=0;
  SdSnapshot151 snapshot()const override{return s;}
  bool try_acquire_exclusive_read()override{++acquires;if(held||deny)return false;held=true;return true;}
  void release_exclusive_read()override{held=false;++releases;}
};
struct Port: SdSlicePort153 {
  Owner &o;std::map<unsigned,std::vector<uint8_t>> files;unsigned reads=0;
  explicit Port(Owner& owner):o(owner){}
  bool mounted()const override{return o.s.mounted;}
  uint64_t mount_epoch()const override{return o.s.mount_epoch;}
  bool read_slice(unsigned i,size_t off,size_t lim,std::vector<uint8_t>& out,size_t& total)override {
    ++reads;if(!o.held||lim>64)return false;
    auto it=files.find(i);if(it==files.end())return false;
    total=it->second.size();if(off>total)return false;
    size_t n=total-off<lim?total-off:lim;
    out.assign(it->second.begin()+off,it->second.begin()+off+n);return true;
  }
};
int main(){
  Owner o;o.s.mounted=true;o.s.mount_epoch=7;o.s.media_generation=21;o.s.card_identity_verified=true;
  Port p{o}; Backup149 b{42,63,1,std::vector<uint8_t>(2048,0xB5)};
  p.files[0]=encode149(b);p.files[1]=commit149(b);
  Cooperative154 job;T(job.start(o.s,1000,42,63,2048));
  // The SD reader is exclusively cooperative: never more than one slice per scheduler tick.
  for(unsigned i=0;i<400&& (job.state()==Scan154::Running||job.state()==Scan154::Deferred);++i){
    unsigned before=p.reads;
    job.poll(o,p,1000+i);
    T(p.reads-before<=1);T(!o.held);T(o.acquires==o.releases);
    T(!Cooperative154::permits_m500());T(!Cooperative154::permits_restore());
  }
  T(job.state()==Scan154::ValidUntrusted);T(job.selection().backup.data==b.data);
  T(job.chunks()>60);T(job.stats().blocks==job.chunks());
  // Printer and PLR always take precedence, even mid-file.
  for(int mode=0;mode<8;++mode){
    Cooperative154 x;T(x.start(o.s,3000+mode*1000,42,63,2048));
    T(x.poll(o,p,3000+mode*1000)==Scan154::Running);
    unsigned before=p.reads;
    switch(mode){case 0:o.s.print_active=true;break;case 1:o.s.print_paused=true;break;
      case 2:o.s.file_open=true;break;case 3:o.s.saving=true;break;
      case 4:o.s.logging=true;break;case 5:o.s.recovery_busy=true;break;
      case 6:o.s.other_io_busy=true;break;case 7:o.s.media_change_pending=true;break;}
    auto result=x.poll(o,p,3001+mode*1000);
    if(mode==7)T(result==Scan154::Cancelled);else T(result==Scan154::Deferred);
    T(p.reads==before);T(!o.held);
    o.s.print_active=o.s.print_paused=o.s.file_open=o.s.saving=o.s.logging=
      o.s.recovery_busy=o.s.other_io_busy=o.s.media_change_pending=false;
    if(mode!=7){T(x.poll(o,p,3026+mode*1000)==Scan154::Running);T(!o.held);}
  }
  // Event invalidation cannot be resumed with stale bytes.
  for(int event=0;event<=static_cast<int>(SdEvent152::GlobalReset);++event){
    Cooperative154 x;T(x.start(o.s,20000+event*10,42,63,2048));
    T(x.poll(o,p,20000+event*10)==Scan154::Running);
    x.on_event(static_cast<SdEvent152>(event));T(x.state()==Scan154::Cancelled);
    unsigned was=p.reads;T(x.poll(o,p,20001+event*10)==Scan154::Cancelled);T(was==p.reads);
  }
  // Old results invalidated after card change, even after earlier slices.
  for(unsigned i=0;i<25;++i){
    Cooperative154 x;T(x.start(o.s,25000+i*50,42,63,2048));
    for(unsigned k=0;k<i+1;++k)x.poll(o,p,25000+i*50+k);
    unsigned was=p.reads;++o.s.media_generation;
    T(x.poll(o,p,25025+i*50)==Scan154::Cancelled);
    T(x.poll(o,p,25026+i*50)==Scan154::Cancelled);T(was==p.reads);
    --o.s.media_generation;
  }
  // Lock contention causes a bounded deferral without touching the SD port.
  {Cooperative154 x;T(x.start(o.s,50000,42,63,2048));o.deny=true;
   unsigned before=p.reads;T(x.poll(o,p,50000)==Scan154::Deferred);
   T(before==p.reads);o.deny=false;
   T(x.poll(o,p,50025)==Scan154::Running);}
  // Invalid / missing backups never authorize write or recovery.
  {Cooperative154 x;T(x.start(o.s,60000,42,63,2048));p.files[1][0]^=0xFF;
   for(unsigned k=0;k<400&&(x.state()==Scan154::Deferred||x.state()==Scan154::Running);++k)x.poll(o,p,60000+k);
   T(x.state()==Scan154::NoBackup);T(!Cooperative154::permits_restore());p.files[1][0]^=0xFF;}
  // 30s timeout (global scheduler), unknown identity and reset.
  {Cooperative154 x;T(x.start(o.s,70000,42,63,2048));T(x.poll(o,p,100001)==Scan154::Expired);}
  {Cooperative154 x;auto s=o.s;s.card_identity_verified=false;T(!x.start(s,70000,42,63,2048));}
  {Cooperative154 x;T(x.start(o.s,80000,42,63,2048));x.cancel();T(x.state()==Scan154::Cancelled);}
  std::printf("test154 PASS %u assertions, bounded slices=%zu\n",checks,job.chunks());
}
