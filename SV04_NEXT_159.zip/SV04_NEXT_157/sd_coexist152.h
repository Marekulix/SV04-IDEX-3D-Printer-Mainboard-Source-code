#pragma once
// SV04 NEXT 152: HOST-ONLY SD/PLR coexistence policy.
// No Marlin lock is installed; no SD/EEPROM writes. All actions are diagnostic.
#include "sd_exclusive151.h"
#include <cstdint>
namespace sv04 {
enum class SdEvent152:uint8_t {
  PrintStart, PrintPause, PrintResume, PrintStop, FileOpened,
  UploadStart, LogStart, RecoveryStart, RecoveryEnd,
  MediaRemoved, MediaInserted, Remount, UnknownIO, GlobalReset
};
enum class SdJob152:uint8_t {
  Idle, Deferred, Cancelled, ScannedUntrusted, Rejected, Expired
};
struct SdCounters152 {uint32_t attempts=0, deferrals=0, cancellations=0, scans=0;};
class SdCoexist152 {
  SdJob152 state_=SdJob152::Idle;
  uint64_t start_ms_=0;
  uint64_t next_try_ms_=0;
  uint64_t session_epoch_=0;
  uint64_t generation_=0;
  uint32_t max_attempts_=0;
  uint32_t attempts_=0;
  SdCounters152 counters_{};
  static constexpr uint64_t retry_interval_ms_=250;
  static constexpr uint64_t timeout_ms_=30000;
  void cancel_internal() { state_=SdJob152::Cancelled; ++counters_.cancellations; }
public:
  SdJob152 state() const { return state_; }
  SdCounters152 counters() const { return counters_; }
  bool start(const SdSnapshot151& s, uint64_t now_ms, uint32_t max_attempts=4) {
    if (state_==SdJob152::Deferred) return false;
    if (!max_attempts || max_attempts>16 || !now_ms || !s.mount_epoch || !s.media_generation)
      return false;
    // Starting a *diagnostic* is allowed even while busy; it must defer, never interfere.
    start_ms_=next_try_ms_=now_ms;
    session_epoch_=s.mount_epoch;generation_=s.media_generation;
    attempts_=0;max_attempts_=max_attempts;
    state_=SdJob152::Deferred;
    return true;
  }
  void on_event(SdEvent152 event) {
    if (state_!=SdJob152::Deferred)return;
    // Any SD/PLR/media event invalidates the pre-existing safety snapshot.
    (void)event;
    cancel_internal();
  }
  // This is a single synchronous *host-side* attempt, not a real non-blocking Marlin reader.
  // Actual Marlin implementation must replace scan_exclusive151 with a bounded, cooperative
  // operation under a shared lock all SD clients honor. If impossible: disable feature.
  SdJob152 poll(SdOwnership151& owner, SdPort150& port,
                uint32_t card_id,uint32_t device_id,size_t bytes,uint64_t now_ms) {
    if(state_!=SdJob152::Deferred)return state_;
    if(now_ms<start_ms_ || now_ms-start_ms_>timeout_ms_) {
      state_=SdJob152::Expired;return state_;
    }
    const auto s=owner.snapshot();
    if(!s.mounted || s.mount_epoch!=session_epoch_ ||
       s.media_generation!=generation_) { cancel_internal();return state_; }
    if(now_ms<next_try_ms_)return state_;
    if(check_sd151(s)!=SdGate151::Clear){
      ++counters_.deferrals;
      // overflow-safe thanks to bounded timeout and monotonic poll time
      next_try_ms_=now_ms+retry_interval_ms_;
      return state_;
    }
    if(attempts_>=max_attempts_){state_=SdJob152::Rejected;return state_;}
    ++attempts_;++counters_.attempts;
    const auto report=scan_exclusive151(owner,port,card_id,device_id,bytes);
    const auto after=owner.snapshot();
    if(!after.mounted || after.mount_epoch!=session_epoch_ ||
       after.media_generation!=generation_){cancel_internal();return state_;}
    if(report.gate==SdGate151::Clear && report.backup_readable_for_diagnostics &&
       !report.may_write_eeprom && !report.may_restore_eeprom && !report.may_write_sd) {
      ++counters_.scans;state_=SdJob152::ScannedUntrusted;
    }
    else if(report.gate==SdGate151::LeaseDenied || report.gate==SdGate151::BusyOther ||
            report.gate==SdGate151::BusyRecovery || report.gate==SdGate151::BusyFile ||
            report.gate==SdGate151::BusyPrint || report.gate==SdGate151::BusySaving) {
      ++counters_.deferrals;
      next_try_ms_=now_ms+retry_interval_ms_;
    }
    else state_=SdJob152::Rejected;
    return state_;
  }
  // Never grant write authority, regardless of any scan result.
  static constexpr bool permits_sd_write() {return false;}
  static constexpr bool permits_m500() {return false;}
  static constexpr bool permits_flash_restore() {return false;}
};
static_assert(!SdCoexist152::permits_sd_write() && !SdCoexist152::permits_m500() && !SdCoexist152::permits_flash_restore(),"Safety invariant");
}
