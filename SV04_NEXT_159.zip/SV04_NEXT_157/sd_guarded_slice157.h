#pragma once
// SV04 NEXT 157: host-only checked SD slice wrapper, no firmware I/O.
// A cooperative token is NOT an interrupt-safe mutex nor a full Marlin hook.
#include "sd_shared_arbiter156.h"
#include <cstddef>
#include <cstdint>
namespace sv04 {
struct SdContext157 {
  uint64_t media_epoch=0;
  uint64_t generation=0;
  bool mounted=false;
  bool media_changing=false;
  bool printing=false;
  bool paused=false;
  bool print_file_open=false;
  bool recovery_busy=false;
  bool upload_busy=false;
  bool logging_busy=false;
  bool other_busy=false;
  bool hardware_identity_verified=false;
};
enum class Slice157:uint8_t { Ok, Deferred, Invalid, Cancelled, Fault };
// The callback represents ONE bounded read. In actual firmware its implementation
// must be vetted for blocking behavior, concurrent SD access and card removal.
class ReadPort157 {
public:
  virtual ~ReadPort157()=default;
  virtual SdContext157 context()const=0;
  virtual bool read_exact(uint32_t offset,uint8_t* dst,size_t length)=0;
};
class GuardedSlice157 {
  SharedMedia156& gate_;
  ReadPort157& port_;
  bool terminated_=false;
  static bool clear(const SdContext157& s){
    return s.mounted&&!s.media_changing&&!s.printing&&!s.paused&&!s.print_file_open&&
      !s.recovery_busy&&!s.upload_busy&&!s.logging_busy&&!s.other_busy&&
      s.media_epoch!=0&&s.generation!=0&&s.hardware_identity_verified;
  }
  static MediaState156 media(const SdContext157& s){
    MediaState156 out{};out.mounted=s.mounted;out.media_changing=s.media_changing;
    out.print_file_open=s.print_file_open;out.printing=s.printing;out.paused=s.paused;
    out.recovery_busy=s.recovery_busy;out.upload_busy=s.upload_busy;
    out.logging_busy=s.logging_busy;out.other_busy=s.other_busy;out.epoch=s.media_epoch;
    return out;
  }
public:
  GuardedSlice157(SharedMedia156& gate,ReadPort157& port):gate_(gate),port_(port){}
  Slice157 tick(uint32_t offset,uint8_t* dst,size_t len){
    if(terminated_)return Slice157::Cancelled;
    if(!dst||len==0||len>64||offset>UINT32_MAX-len){terminated_=true;return Slice157::Invalid;}
    const auto before=port_.context();
    gate_.update(media(before));
    if(!clear(before))return Slice157::Deferred;
    // Firmware MUST NOT enable diagnostics by setting the host-only test switch.
    uint32_t token=0;
    const auto acquired=gate_.acquire(MediaOwner156::Diagnostic,before.media_epoch,token);
    if(acquired!=Result156::Granted)return acquired==Result156::Fault?Slice157::Fault:Slice157::Deferred;
    // Check again after acquiring the lease, before the physical read.
    const auto pre=port_.context();
    if(!clear(pre)||pre.media_epoch!=before.media_epoch||pre.generation!=before.generation){
      gate_.update(media(pre));gate_.release(MediaOwner156::Diagnostic,before.media_epoch,token);
      terminated_=true;return Slice157::Cancelled;
    }
    // Never expose partial data on read failure / concurrent media change.
    uint8_t scratch[64]{};
    const bool ok=port_.read_exact(offset,scratch,len);
    const auto after=port_.context();
    gate_.update(media(after));
    const auto released=gate_.release(MediaOwner156::Diagnostic,before.media_epoch,token);
    if(!ok||!clear(after)||after.media_epoch!=before.media_epoch||
       after.generation!=before.generation||released!=Result156::Granted){
      terminated_=true;return Slice157::Cancelled;
    }
    for(size_t i=0;i<len;i++)dst[i]=scratch[i];
    return Slice157::Ok;
  }
  bool terminated() const{return terminated_;}
  static constexpr bool permits_m500(){return false;}
  static constexpr bool permits_restore(){return false;}
  static constexpr bool production_ready(){return false;}
};
static_assert(!GuardedSlice157::permits_m500()&&!GuardedSlice157::permits_restore()&&
              !GuardedSlice157::production_ready(),"Never permit writes/production without complete integration");
} // namespace sv04
