# SV04 NEXT 148 | Unabhängiger Speicher und gesperrter Wiederanlauf

**NICHT INSTALLIEREN. Nur lokale Host-Tests. Kein Marlin-Build und kein Hardwareversuch.**

## Quellprüfung
Sovol OEM `Sovol3d/SV04-IDEX-3D-Printer-Mainboard-Source-code` @ `1867fcba75354a5c65e0631d6972dd19f1bd6cbe`:
- `Marlin/Configuration.h`: `SDSUPPORT` und `EEPROM_SETTINGS` aktiv; Board `BOARD_CREALITY_V4`.
- `platformio.ini`: Standardumgebung `STM32F103RET6_creality`.
- `Marlin/src/HAL/STM32F1/eeprom_flash.cpp`: zwei Flashseiten als emuliertes EEPROM; `access_finish()` löscht Seiten vor Neuprogrammierung. Das Verfahren hat **keine nachgewiesene Stromausfall-Atomizität**.
- `Marlin/src/HAL/STM32F1/eeprom_sdcard.cpp`: alternatives EEPROM-Backend; der Zugriff schließt mit einer Dateineuschreibung. Diese Alternative ist **nicht** als sichere Backup-Methode freigegeben.
- `Marlin/src/sd/cardreader.h`: SD-Medium kann erkannt werden; das allein beweist weder SD-Kartenidentität noch stabile Schreibbestätigung/Flush.

## Ergebnis: Medium-Eignung
| Ziel | Ausreichend unabhängig? | Für automatische Wiederherstellung freigegeben? |
|---|---|---|
| Die gleichen Flashseiten | Nein | Nein |
| SD-Karte | Potenziell physisch separat | Nein: Identitätsbindung, atomare Slots, Write-Flush und Ausfalltests fehlen |
| Externer PC/Tablet-Download | Potenziell physisch separat | Nein: Transport und eindeutiger Wiederherstellungspfad fehlen |

**Eine SD-Karte im Drucker ersetzt kein belegtes Power-Loss-Verfahren.** Das Journal147 setzt atomare, haltbare Slot-Schreibvorgänge voraus, die für diese Hardware nicht bestätigt sind. Daher ist `certified_independent_and_atomic_slots()` im echten SV04-Betrieb noch nicht erfüllbar.

## Implementierung
- `recovery_capability148.h`: schreibfreier Host-Entscheidungsautomat zur Prüfung von Backend, Medienidentität, Backupintegrität, Flash-Snapshot, Journalphase und Druckerzustand.
- `test148.cpp`: 669 Prüfungen, inklusive vollständiger Kombinationen sicherheitskritischer Freigabefelder. Es existiert **kein** EEPROM-Schreib- oder Auto-Restore-Pfad.
- Bei gültigem Beleg kann maximal `ManualServiceOnly` signalisiert werden; es findet keinerlei Wiederherstellung statt.
- Bei fehlendem Nachweis fail-closed. `automatic_m500_allowed148()` und `automatic_restore_allowed148()` sind immer `false`.

## Echte Hardware-Grenzen
1. Aktives EEPROM-Backend im *gebauten* Marlin bestätigen.
2. Physisch getrennten Speicher einschließlich Kartenidentität und Integritätsnachweis bestimmen.
3. Unabhängige persistente Speicherung und Neustart nach Stromausfall prüfen; keine Annahme von Dateisystem-Atomizität.
4. Sicherungskopie an der richtigen Marlin-Version/EEPROM-Größe/CRC verifizieren.
5. Service-Recovery-Konzept entwerfen, ohne die einzige gültige Sicherung beim Restore zu gefährden.
6. Niemals ein unbeobachtetes `M500` während des normalen Vermessungsablaufs auslösen, solange die Punkte nicht bewiesen sind.

## Tests
- `g++ -std=c++17 -O1 -g -Wall -Wextra -Werror -pedantic -fsanitize=undefined test148.cpp -o test148 && ./test148`: **669 PASS**.
- Alle **18 C++-Testdateien** aus 135–148 lokal neu kompiliert und erfolgreich durchgeführt (einschließlich `test148.cpp`).
- `test145_injection.py`, `test146.py`: **PASS**.
- Keine direkte Flash- oder SD-Operation ausgeführt. Kein realer Marlin- oder DWIN-Build.

## Nächster Schritt 149
Eine nichtdestruktive **SD-Diagnose-Spezifikation** (Kartenidentität, Dateisystem-/Dateilesezugriff, Journal-Slot-Zustand, Erkennung ausstehender Updates) entwickeln. Vor Nutzung der SD-Karte als Transaktionsmedium muss ein formal getesteter Sicherungsprozess mit tatsächlich dauerhaftem Commit und realen Ausfalltests existieren. Kein automatisches Flash-Restore.
