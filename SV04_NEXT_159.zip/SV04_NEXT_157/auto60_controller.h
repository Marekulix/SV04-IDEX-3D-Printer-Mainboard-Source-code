#pragma once
#include <array>
#include <cmath>
#include <cstdint>

// SV04 NEXT Punkt 3 / Stand 135: Host-testable control logic only.
// The caller MUST implement physical interlocks, a transactional mesh snapshot,
// and feedback from real firmware. No command here is automatically executed.
namespace sv04 {
enum class Phase : uint8_t { Idle, Heat, Stabilize, Home, Probe, Validate, Persist, Verify, Success, Fault };
enum class Action : uint8_t { None, SetBed60, HomeSafely, Probe4x4, RestoreMesh, SaveEEPROM, VerifyEEPROM };
enum class Error : uint8_t { None, Busy, Unsafe, Temperature, Timeout, ProbeFailed, BadMesh, SaveFailed, VerifyFailed, Aborted };

struct Guards {
  bool idle=false, heaters_ok=false, axes_safe=false, tool_safe=false,
       probe_ready=false, snapshot_valid=false;
};
class Controller {
 public:
  static constexpr float TARGET=60.0f;
  static constexpr float TOL=1.0f;
  static constexpr uint32_t STABILITY_MS=30000;
  static constexpr uint32_t HEAT_TIMEOUT_MS=12*60*1000UL;
  static constexpr uint32_t STAGE_TIMEOUT_MS=8*60*1000UL;
  Phase phase() const { return phase_; }
  Error error() const { return error_; }
  Action pending() const { return pending_; }
  unsigned samples() const { return count_; }
  const std::array<float,16>& measurements() const { return values_; }

  bool start(const Guards& g, uint32_t ms) {
    if (phase_ != Phase::Idle && phase_ != Phase::Success && phase_ != Phase::Fault) return false;
    // A previous fault must not be cleared until the old RAM mesh is restored.
    if (restore_needed_) return false;
    reset();
    if (!g.idle || !g.heaters_ok || !g.axes_safe || !g.tool_safe || !g.probe_ready || !g.snapshot_valid) {
      fail(Error::Unsafe); return false;
    }
    start_ms_=phase_ms_=ms; phase_=Phase::Heat; pending_=Action::SetBed60;
    return true;
  }
  void ack(Action a, bool ok, uint32_t ms) {
    if (a == Action::None || a != pending_) { fail(Error::Unsafe); return; }
    pending_=Action::None;
    if (!ok) { fail(a==Action::SaveEEPROM?Error::SaveFailed:a==Action::VerifyEEPROM?Error::VerifyFailed:Error::Unsafe);return; }
    switch(a) {
      case Action::SetBed60: /* wait for independent temperature feedback */ break;
      case Action::HomeSafely: phase_=Phase::Probe;phase_ms_=ms;pending_=Action::Probe4x4;break;
      case Action::Probe4x4: /* G29 completion is a separate callback */ break;
      case Action::SaveEEPROM: phase_=Phase::Verify;phase_ms_=ms;pending_=Action::VerifyEEPROM;break;
      case Action::VerifyEEPROM: phase_=Phase::Success;break;
      case Action::RestoreMesh: phase_=Phase::Fault;break;
      default: fail(Error::Unsafe);break;
    }
  }
  void temperature(float c, uint32_t ms) {
    if (phase_ != Phase::Heat && phase_ != Phase::Stabilize) return;
    if (!std::isfinite(c) || c>125.0f || c<0.0f) {fail(Error::Temperature);return;}
    if ((uint32_t)(ms-start_ms_)>HEAT_TIMEOUT_MS) {fail(Error::Timeout);return;}
    if (pending_ != Action::None) return;  // bed setpoint must have been acknowledged
    if (std::fabs(c-TARGET)>TOL) {phase_=Phase::Heat;stable_since_=ms;return;}
    if (phase_==Phase::Heat) {phase_=Phase::Stabilize; stable_since_=ms;}
    if ((uint32_t)(ms-stable_since_)>=STABILITY_MS) {
      phase_=Phase::Home;phase_ms_=ms;pending_=Action::HomeSafely;
    }
  }
  // Each point must be reported individually by actual G29 instrumentation.
  bool point(unsigned x, unsigned y, float z) {
    if (phase_!=Phase::Probe || x>=4 || y>=4 || !std::isfinite(z) || z < -10.0f || z > 10.0f) {
      if (phase_==Phase::Probe) fail(Error::BadMesh);
      return false;
    }
    const unsigned i=y*4+x;
    if (seen_[i]) {fail(Error::BadMesh);return false;}
    seen_[i]=true; values_[i]=z; ++count_;return true;
  }
  void probe_complete(bool genuine_g29_success, bool dry_run, uint32_t ms) {
    if (phase_!=Phase::Probe || pending_!=Action::None) {fail(Error::Unsafe);return;}
    if (!genuine_g29_success || dry_run) {fail(Error::ProbeFailed);return;}
    if (count_!=16) {fail(Error::BadMesh);return;}
    for (unsigned i=0;i<16;i++) if(!seen_[i] || !std::isfinite(values_[i])) {fail(Error::BadMesh);return;}
    // Actual firmware integration must compare this snapshot to current z_values,
    // confirm probe completed, and ensure mesh topology is exactly 4x4.
    phase_=Phase::Validate;phase_ms_=ms;
  }
  void validation(bool current_mesh_matches, bool safe_to_save, uint32_t ms) {
    if (phase_!=Phase::Validate) {fail(Error::Unsafe);return;}
    if (!current_mesh_matches || !safe_to_save) {fail(Error::BadMesh);return;}
    phase_=Phase::Persist;phase_ms_=ms;pending_=Action::SaveEEPROM;
  }
  void tick(uint32_t ms, bool safety_ok) {
    if (phase_==Phase::Idle || phase_==Phase::Success || phase_==Phase::Fault) return;
    if (!safety_ok) {fail(Error::Unsafe);return;}
    if (phase_==Phase::Heat || phase_==Phase::Stabilize) {
      if ((uint32_t)(ms-start_ms_)>HEAT_TIMEOUT_MS) fail(Error::Timeout);
    } else if ((uint32_t)(ms-phase_ms_)>STAGE_TIMEOUT_MS) fail(Error::Timeout);
  }
  void abort() {if (phase_!=Phase::Idle && phase_!=Phase::Fault && phase_!=Phase::Success) fail(Error::Aborted);}
  // Caller must restore in-memory mesh from captured snapshot before allowing
  // another operation. EEPROM is never written on a failed probe.
  bool needs_restore() const {return restore_needed_;}
  void restore_done(bool ok) {
    if(!restore_needed_) return;
    if(ok){restore_needed_=false;pending_=Action::None;}
    // A failed restore is deliberately latched, requiring operator service.
  }
 private:
  void reset() {phase_=Phase::Idle;error_=Error::None;pending_=Action::None;count_=0;seen_.fill(false);values_.fill(NAN);restore_needed_=false;}
  void fail(Error e) {if(phase_==Phase::Fault) return;error_=e;phase_=Phase::Fault;pending_=Action::None;restore_needed_=true;}
  Phase phase_=Phase::Idle;
  Error error_=Error::None;
  Action pending_=Action::None;
  unsigned count_=0;
  uint32_t start_ms_=0,phase_ms_=0,stable_since_=0;
  std::array<bool,16> seen_{};
  std::array<float,16> values_{};
  bool restore_needed_=false;
};
} // namespace sv04
