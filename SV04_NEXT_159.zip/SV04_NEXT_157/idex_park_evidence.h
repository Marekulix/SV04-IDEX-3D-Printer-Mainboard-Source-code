#pragma once
#include "idex_homing_gate.h"
#include <cstdint>
#include <cmath>

// SV04 NEXT 138: Software bookkeeping, not a park sensor or physical motion proof.
// Evidence is derived only from explicitly reported, successful T1 endstop homing.
// Any untrusted motion, deenergization, failed homing, tool-mode change, or reboot
// invalidates the evidence. Do not use it to waive physical clearance checks.
namespace sv04 {
enum class ParkState : uint8_t { Unknown, T1EndstopConfirmed, Invalidated };
enum class ParkFault : uint8_t { None, BadEndstop, Motion, ModeChange, LostTrust, Reboot, Contradiction };
struct ParkObservation {
  bool t1_endstop_hit=false;  // completion of actual right T1 X homing, not command issued
  bool t1_x_trusted=false;
  bool t1_is_inactive=false;
  bool planner_synchronized=false;
  bool steppers_energized=false;
  bool auto_park_mode=false;
  bool t0_active=false;
  float measured_t1_x=NAN;  // endstop-referenced position, not inactive_extruder_x alone
  float configured_t1_home_x=NAN; // x_home_pos(1), may be overridden by M218
};
class ParkEvidence {
public:
  ParkState state() const { return state_; }
  ParkFault fault() const { return fault_; }
  uint32_t epoch() const { return epoch_; }
  void invalidate(ParkFault why) {state_=ParkState::Invalidated; fault_=why; ++epoch_;}
  void reboot() {invalidate(ParkFault::Reboot);}
  void motion_or_tool_change() {invalidate(ParkFault::Motion);}
  void mode_changed() {invalidate(ParkFault::ModeChange);}
  void lost_position_trust() {invalidate(ParkFault::LostTrust);}
  bool record_completed_t1_home(const ParkObservation& o) {
    if (!o.t1_endstop_hit || !o.t1_x_trusted || !o.t1_is_inactive ||
        !o.planner_synchronized || !o.steppers_energized ||
        !o.auto_park_mode || !o.t0_active ||
        !std::isfinite(o.measured_t1_x) || !std::isfinite(o.configured_t1_home_x) ||
        o.configured_t1_home_x < OemGeometry::X2_MIN || o.configured_t1_home_x > OemGeometry::X2_MAX ||
        std::fabs(o.measured_t1_x-o.configured_t1_home_x)>0.1f) {
      invalidate(ParkFault::BadEndstop);return false;
    }
    state_=ParkState::T1EndstopConfirmed;fault_=ParkFault::None;++epoch_;return true;
  }
  bool still_valid(const ParkObservation& o) {
    if (state_!=ParkState::T1EndstopConfirmed) return false;
    if (!o.t1_x_trusted || !o.t1_is_inactive || !o.planner_synchronized ||
        !o.steppers_energized || !o.auto_park_mode || !o.t0_active ||
        !std::isfinite(o.measured_t1_x) || !std::isfinite(o.configured_t1_home_x) ||
        std::fabs(o.measured_t1_x-o.configured_t1_home_x)>0.1f) {
      invalidate(ParkFault::Contradiction); return false;
    }
    return true;
  }
private:
  ParkState state_=ParkState::Unknown;
  ParkFault fault_=ParkFault::None;
  uint32_t epoch_=0;
};

// Full G28 on the OEM homes T1 X first, then T0 X, so demanding a prior
// T1 homing proof would deadlock initial homing. Initial G28 instead needs
// independent physical clearance and no-obstruction verification.
// This is a logical *permit*, never a claim of actual collision safety.
inline GateReason initial_g28_preflight(IDEXInputs s) {
  if (!s.machine_idle) return GateReason::NotIdle;
  if (!s.planner_empty_and_steppers_stopped) return GateReason::MotionNotStopped;
  if (s.mode!=CarriageMode::AutoPark) return GateReason::WrongMode;
  if (!s.t0_selected) return GateReason::ToolNotT0;
  if (!s.no_obstructions_confirmed) return GateReason::Obstruction;
  if (!s.probe_selfcheck_passed) return GateReason::ProbeNotReady;
  if (!s.endstops_selfcheck_passed) return GateReason::EndstopNotReady;
  if (!s.geometry_matches_oem) return GateReason::GeometryMismatch;
  if (!s.bed_and_tools_safe) return GateReason::UnsafeTemperatures;
  if (!s.physical_clearance_confirmed) return GateReason::MissingPhysicalClearance;
  // Deliberately do NOT infer a parked T1 from a remembered coordinate.
  return GateReason::Ready;
}
inline bool post_g28_safe(const HomingResult& h, ParkEvidence& park, const ParkObservation& o) {
  if (verify_homing(h)!=GateReason::Ready) {park.invalidate(ParkFault::BadEndstop);return false;}
  return park.record_completed_t1_home(o);
}
} // namespace sv04
