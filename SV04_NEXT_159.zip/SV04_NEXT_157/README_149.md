# SV04 NEXT 149 | SD-Zweiplatz-Sicherungsprotokoll (Host-Prototyp)

**NICHT INSTALLIEREN.** Keine Firmware, keine Marlin-Integration, keine echten SD- oder EEPROM-Schreibvorgänge. Punkt 3: 60-°C-Bettvermessung.

## OEM-Recherche
Referenz: Sovol3d/SV04-IDEX-3D-Printer-Mainboard-Source-code, Commit 1867fcba75354a5c65e0631d6972dd19f1bd6cbe.
- `Marlin/Configuration.h`: `SDSUPPORT` und `EEPROM_SETTINGS` sind aktiviert.
- `Marlin/src/sd/cardreader.cpp`: `CardReader::openFileWrite` verwendet `O_CREAT | O_APPEND | O_WRITE | O_TRUNC`; `closefile` ruft `file.sync()` und `file.close()` auf. Ein erfolgreiches `sync` ist allein kein Nachweis von Power-Loss-Atomizität für Karte/Controller/FAT.
- `Marlin/src/HAL/STM32F1/eeprom_flash.cpp`: Das EEPROM-Emulat löscht vor Neuprogrammierung Flash-Seiten. Ein Stromausfall kann beide Seiten beschädigen.
- SDK-/Dateisystemkonkretisierung, eindeutige Medienkennung, realer Flush, Dateisystem-Sektorschreibverhalten und Kartenwechsel-Erkennung sind noch unbewiesen.

## Umsetzung
`sd_backup149.h`: binäres Host-Modell mit zwei getrennten Sicherungsplätzen (A/B), je Datenabbild + Freigabedatensatz; Bindung an erwartete Karten- und Gerätekennung, Generation, Länge und CRC32. Altes, gültiges Slot wird beim neuen Sicherungsvorgang nicht verändert. Nach ungeprüftem Commit oder Datenkorruption gilt er weiterhin als auswählbar. Doppelte Generationen sind ein Fehler; unvollständige oder widersprüchliche Daten werden nicht akzeptiert. `test149.cpp` testet diese Eigenschaften mit Fehler-Injektionen und Manipulation jedes Bytes.

**Grenzen:**
- `card_id` / `device_id` sind im Test explizit vorgegebene Werte, KEINE bereits zuverlässige Hardware-Identität.
- CRC32 erkennt zufällige Fehler, bietet KEINE Authentizität gegen gezielte Manipulation.
- Zwei Dateien pro Slot sind nicht atomar; auch die Änderung/Entfernung des alten Commit-Datensatzes kann bei echtem Stromausfall selbst unerwartete Folgen haben. Keine Garantie durch Hostsimulation.
- Für den echten Marlin-Patch fehlen SD-Low-Level-Adapter, Flush-/Readback-Nachweis, Karten-/Board-Erkennung, Wiederanlaufjournal und Hardware-Power-Loss-Tests.
- Die vorhandene Journal147- und Recovery148-Logik bleibt maßgeblich und sperrt automatische EEPROM-Schreib- oder Restore-Vorgänge.

## Tests am 06.11.2026
- C++17 Hosttest `test149.cpp` mit `-Wall -Wextra -Werror -pedantic -fsanitize=undefined`: **5.205 Prüfaussagen PASS**.
- **19 C++-Testprogramme** aus Stand 135–149 separat gebaut und ausgeführt: PASS.
- `test145_injection.py`, `test146.py`: PASS.
- Kein STM32-Marlin-Build, kein SD-Hardwaretest, kein Druckertest.

## Nächster Schritt (Stand 150)
Ermitteln, welche konkreten SD-Schreib-/Sync-/Readback-Primitiven im verwendeten Marlin-/SdFat-Build real existieren, danach einen rein lesenden Diagnoseadapter für Kartenzustand und zwei Slot-Header planen. Bis zur Bestätigung aus Hardwaretests: keine EEPROM-Flash-Wiederherstellung und kein automatisches `M500`.
