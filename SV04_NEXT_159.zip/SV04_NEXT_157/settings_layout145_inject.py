#!/usr/bin/env python3
"""Instrument the EXISTING EEPROM _load() in a staged settings.cpp.
No additional EEPROM reads or writes, and no M500 / M501 invocation.
The resulting evidence is populated only after normal load returns CRC-success.
Requires manual audit and a full Marlin build before firmware use.
"""
import pathlib, sys
if len(sys.argv)!=2:raise SystemExit('Usage: python3 settings_layout145_inject.py <staged_settings.cpp>')
p=pathlib.Path(sys.argv[1]);s=p.read_text()
anchor='} SettingsData;'
if s.count(anchor)!=1 or s.count('bool MarlinSettings::_load() {')!=1:
    raise SystemExit('Unknown source structure; refused')
if 'SV04_NEXT_145_LAYOUT_BEGIN' in s:raise SystemExit('Already instrumented; refused')
# Always measure serialized positions by Marlin eeprom_index. offsetof(struct) is NOT reliable!
block=r'''
// SV04_NEXT_145_LAYOUT_BEGIN: READ INDEX OBSERVATION ONLY. NO EXTRA EEPROM IO.
#if ENABLED(AUTO_BED_LEVELING_BILINEAR)
namespace sv04_layout145 {
  struct Evidence {
    uint32_t capacity, settings_size, grid_x, grid_y, spacing, origin, mesh;
    uint32_t xy_bytes, mesh_bytes, header_offset;
    bool observed_grid, observed_spacing, observed_origin, observed_mesh, verified_load;
  };
  static Evidence captured = {};
  static_assert(sizeof(float) == 4, "SV04 NEXT requires 4-byte float");
  static_assert(sizeof(z_values) == 16u * 4u, "SV04 NEXT requires 4x4 bilinear mesh");
}
#endif
// SV04_NEXT_145_LAYOUT_END
'''
s=s.replace(anchor,anchor+'\n'+block,1)
# _load is read-only _when EEPROM backend is read-only_; this adds no operations.
head='bool MarlinSettings::_load() {'
s=s.replace(head,head+'\n    #if ENABLED(AUTO_BED_LEVELING_BILINEAR)\n      sv04_layout145::captured = {};\n    #endif',1)
# Insert precisely in _load (not save!)
def once(before,after):
 global s
 # Each needle must appear exactly once in source after the load begins; ensure anchor present.
 n=s.count(before)
 if n!=1:raise SystemExit(f'Expected exactly one insertion site, saw {n}: {before!r}')
 s=s.replace(before,after,1)
needle='''        EEPROM_READ_ALWAYS(grid_max_x);                // 1 byte
        EEPROM_READ_ALWAYS(grid_max_y);                // 1 byte'''
replace='''        #if ENABLED(AUTO_BED_LEVELING_BILINEAR)
          sv04_layout145::captured.grid_x = uint32_t(eeprom_index);
          sv04_layout145::captured.observed_grid = true;
        #endif
        EEPROM_READ_ALWAYS(grid_max_x);                // 1 byte
        #if ENABLED(AUTO_BED_LEVELING_BILINEAR)
          sv04_layout145::captured.grid_y = uint32_t(eeprom_index);
        #endif
        EEPROM_READ_ALWAYS(grid_max_y);                // 1 byte'''
once(needle,replace)
needle='''            EEPROM_READ(bilinear_grid_spacing);        // 2 ints
            EEPROM_READ(bilinear_start);               // 2 ints
            EEPROM_READ(z_values);                     // 9 to 256 floats'''
replace='''            sv04_layout145::captured.spacing = uint32_t(eeprom_index);
            sv04_layout145::captured.observed_spacing = true;
            EEPROM_READ(bilinear_grid_spacing);        // 2 ints
            sv04_layout145::captured.origin = uint32_t(eeprom_index);
            sv04_layout145::captured.observed_origin = true;
            EEPROM_READ(bilinear_start);               // 2 ints
            sv04_layout145::captured.mesh = uint32_t(eeprom_index);
            sv04_layout145::captured.observed_mesh = true;
            EEPROM_READ(z_values);                     // 9 to 256 floats'''
once(needle,replace)
needle='''    EEPROM_FINISH();

    return !eeprom_error;
  }'''
replace='''    EEPROM_FINISH();

    #if ENABLED(AUTO_BED_LEVELING_BILINEAR)
      sv04_layout145::captured.capacity = uint32_t(persistentStore.capacity());
      sv04_layout145::captured.settings_size = uint32_t(sizeof(SettingsData));
      sv04_layout145::captured.header_offset = EEPROM_OFFSET;
      sv04_layout145::captured.xy_bytes = sizeof(bilinear_grid_spacing);
      sv04_layout145::captured.mesh_bytes = sizeof(z_values);
      sv04_layout145::captured.verified_load = !eeprom_error
        && sv04_layout145::captured.observed_grid
        && sv04_layout145::captured.observed_spacing
        && sv04_layout145::captured.observed_origin
        && sv04_layout145::captured.observed_mesh;
    #endif
    return !eeprom_error;
  }'''
once(needle,replace)
p.write_text(s)
print('Added read-index observation; nothing writes or reads EEPROM beyond existing _load(). Full build required.')
