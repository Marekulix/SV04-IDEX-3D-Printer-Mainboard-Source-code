# SV04 NEXT 143 — Punkt 3: read-only EEPROM adapter (NOT FOR FLASH)

Stand: 2026-11-06. Buildstatus: **nur Host-C++-Tests, keine STM32- oder reale EEPROM-Prüfung**.

## Quellnachweise aus Sovol-Originalcommit

Pinned Sovol commit: `1867fcba75354a5c65e0631d6972dd19f1bd6cbe`.

* `Marlin/src/HAL/shared/eeprom_api.h`: `PersistentStore::read_data()` gibt TRUE auf Fehler zurück, `read_data(..., writing=true)` kopiert die Daten in den Ausgabepuffer.
* `Marlin/src/HAL/STM32F1/eeprom_flash.cpp`: Bei `FLASH_EEPROM_EMULATION` kopiert `access_start()` die beiden Flash-Seiten ins RAM und setzt `eeprom_dirty=false`. `read_data()` markiert den Speicher NICHT als schmutzig; `access_finish()` löscht und schreibt nur bei `eeprom_dirty=true`.
* `Marlin/src/HAL/STM32F1/eeprom_sdcard.cpp`: `access_finish()` schreibt die Datei `eeprom.dat` mit `O_TRUNC` neu. **Nicht als read-only zertifizieren.**
* `Marlin/src/module/settings.cpp`: `M500/settings.save()` schreibt die komplette Konfiguration; ein „nachträgliches M501“ ist kein unabhängiger, nebenwirkungsfreier EEPROM-Vergleich.

## Was 143 wirklich kann

`FullFlashBackup143` kopiert die vorhandenen EEPROM-Bytes blockweise (64-Byte-Puffer) in einen eigens geprüften externen Archivspeicher. Zweiter Flash-Lesedurchlauf vergleicht jedes Byte mit einem erneut aus dem Archiv gelesenen Byte; CRC32 wird zusätzlich berechnet. Bei jedem Fehler bleibt `verified=false`. Keine EEPROM-Schreibfunktion ist implementiert. Die Schnittstelle akzeptiert ausschließlich explizit zertifizierte Flash-Backends und nachgewiesen unabhängige, dauerhaft lesbare Archive.

`FlashBackend143<PersistentStoreApi>` zeigt die konkrete Übersetzung der echten Marlin-API einschließlich `true=Lesefehler`. Tests nutzen eine nachgebildete API; sie sind **kein Hardwaretest**.

## Noch zwingend offen

1. Aktiv gewählten STM32F103RET6-PersistentStore-Treiber anhand des vollständig kompilierten Builds bestätigen. Falls SD-EEPROM-Emulation aktiv ist, kein Freigabesignal.
2. Separate dauerhafte Sicherungsablage, einschließlich Verhalten bei SD-Entnahme und Stromausfall, implementieren und am Gerät verifizieren.
3. Archive auf Versionskennung `V85`, EEPROM-Layout, CRC16 von Marlin und unveränderte restliche Einstellungen unabhängig prüfen. CRC32 des Archivstreams alleine reicht nicht.
4. Schreibtransaktion/Stromausfallsicherheit bleibt ungelöst. **Keine M500-Freigabe.**
5. Restore von EEPROM-Daten auf Hardware ist nicht implementiert. Nach Schreibfehler ist EEPROM-Zustand unbekannt.

## Tests

* `test143.cpp`: 4075 assertions (ASan/UBSan, Host-Mocks).
* `test143_persistentstore.cpp`: Adaptertests mit Mock-PersistentStore, auch Fehlersemantik.
* 11 Regressionstests (135–142) erneut bestanden.

**NICHT installieren, NICHT flashen, KEIN GitHub nötig.**
