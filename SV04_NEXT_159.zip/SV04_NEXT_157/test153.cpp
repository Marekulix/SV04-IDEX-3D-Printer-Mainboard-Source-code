#include "sd_incremental153.h"
#include <cstdio>
#include <map>
using namespace sv04;
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x)){std::fprintf(stderr,"FAIL line %d %s\n",__LINE__,#x);return 1;}}while(0)
struct Owner: SdOwnership151 {
 SdSnapshot151 s{};bool lease=false,deny=false;unsigned gets=0,puts=0;
 SdSnapshot151 snapshot()const override{return s;}
 bool try_acquire_exclusive_read()override{++gets;if(deny||lease)return false;lease=true;return true;}
 void release_exclusive_read()override{++puts;lease=false;}
};
struct Port: SdSlicePort153 {
 Owner& owner;std::map<unsigned,std::vector<uint8_t>> files;unsigned calls=0;
 unsigned mutate_on=0;bool bad_length=false,fail=false;
 explicit Port(Owner& o):owner(o){}
 bool mounted()const override{return owner.s.mounted;}
 uint64_t mount_epoch()const override{return owner.s.mount_epoch;}
 bool read_slice(unsigned id,size_t off,size_t limit,std::vector<uint8_t>& out,size_t& total)override{
  ++calls;if(mutate_on==calls)++owner.s.media_generation;
  if(!owner.lease||limit>64||fail)return false;
  auto it=files.find(id);if(it==files.end())return false;
  total=it->second.size();if(off>total)return false;
  auto end=off+((total-off<limit)?total-off:limit);
  out.assign(it->second.begin()+off,it->second.begin()+end);
  if(bad_length)out.push_back(0);
  return true;
 }
};
int main(){
 Owner o; o.s.mounted=true;o.s.mount_epoch=17;o.s.media_generation=13;o.s.card_identity_verified=true;
 Port p{o}; Backup149 b{4,5,2,std::vector<uint8_t>(1024,0xA7)};
 p.files[0]=encode149(b);p.files[1]=commit149(b);
 SdIncremental153 r;CHECK(r.start(o.s,100,4,5,1024));
 // Each call consumes at most one bounded read and releases the shared lease.
 for(unsigned i=0;i<300 && (r.state()==SdStep153::Running||r.state()==SdStep153::Deferred);++i){
  unsigned old=p.calls;CHECK(r.poll(o,p,100+i)==r.state());CHECK(p.calls<=old+1);
  CHECK(!o.lease);CHECK(o.gets==o.puts);CHECK(!SdIncremental153::may_write_eeprom());
 }
 CHECK(r.state()==SdStep153::ValidUntrustedMedia);CHECK(r.selection().backup.data==b.data);
 CHECK(r.chunks()>20);
 // Test pause/resume without retaining lease or holding a file handle.
 for(unsigned k=0;k<20;++k){SdIncremental153 x;CHECK(x.start(o.s,1000+k*50,4,5,1024));
  CHECK(x.poll(o,p,1000+k*50)==SdStep153::Running);
  o.s.print_paused=true;unsigned prior=p.calls;
  CHECK(x.poll(o,p,1001+k*50)==SdStep153::Deferred);CHECK(p.calls==prior);CHECK(!o.lease);
  o.s.print_paused=false;
  CHECK(x.poll(o,p,1030+k*50)==SdStep153::Running);CHECK(!o.lease);
  x.cancel();CHECK(x.state()==SdStep153::Cancelled);
 }
 // Media switches must invalidate all partial chunks.
 for(unsigned k=1;k<30;++k){SdIncremental153 x;CHECK(x.start(o.s,5000+k*100,4,5,1024));
  p.calls=0;p.mutate_on=k;
  for(unsigned i=0;i<k+3 && x.state()==SdStep153::Running;++i)x.poll(o,p,5000+k*100+i);
  CHECK(x.state()==SdStep153::Cancelled);CHECK(!o.lease);
  o.s.media_generation=13;p.mutate_on=0;
 }
 // Missing commit rejects all candidate data and never implies recovery.
 {SdIncremental153 x;p.files.erase(1);CHECK(x.start(o.s,9000,4,5,1024));
  for(unsigned i=0;i<300&&x.state()==SdStep153::Running;++i)x.poll(o,p,9000+i);
  CHECK(x.state()==SdStep153::NoValidBackup);CHECK(!SdIncremental153::may_restore_eeprom());
  p.files[1]=commit149(b);
 }
 // Different content across two passes is a hard cancel.
 {SdIncremental153 x;CHECK(x.start(o.s,10000,4,5,1024));
  for(unsigned i=0;i<300 && x.state()==SdStep153::Running;++i){
    if(i==18)p.files[0][45]^=9;
    x.poll(o,p,10000+i);
  }
  CHECK(x.state()==SdStep153::Cancelled);p.files[0][45]^=9;
 }
 // Invalid claimed lengths and storage failures fail closed.
 for(int bad=0;bad<2;++bad){SdIncremental153 x;CHECK(x.start(o.s,11000+bad*100,4,5,1024));
  p.bad_length=(bad==0);p.fail=(bad==1);
  for(unsigned i=0;i<300&&x.state()==SdStep153::Running;++i)x.poll(o,p,11000+bad*100+i);
  CHECK(x.state()!=SdStep153::ValidUntrustedMedia);CHECK(!o.lease);
  p.bad_length=p.fail=false;
 }
 // Timeout, unknown card, external events, bad size bounds.
 {SdIncremental153 x;CHECK(x.start(o.s,15000,4,5,1024));CHECK(x.poll(o,p,45001)==SdStep153::Expired);}
 {SdIncremental153 x;CHECK(!x.start(o.s,1,4,5,65537));CHECK(!x.start(o.s,0,4,5,1024));}
 for(int mode=0;mode<8;++mode){SdIncremental153 x;CHECK(x.start(o.s,16000+mode*100,4,5,1024));
  auto old=o.s;switch(mode){case 0:o.s.file_open=true;break;case 1:o.s.print_active=true;break;
    case 2:o.s.print_paused=true;break;case 3:o.s.recovery_busy=true;break;
    case 4:o.s.logging=true;break;case 5:o.s.other_io_busy=true;break;
    case 6:o.s.media_change_pending=true;break;case 7:o.s.saving=true;break;}
  CHECK(x.poll(o,p,16000+mode*100)==SdStep153::Deferred);CHECK(!o.lease);o.s=old;
 }
 std::printf("test153 PASS: %u assertions, final %zu bounded chunks\n",checks,r.chunks());
}
