#include "auto60_eeprom141.h"
#include <cassert>
#include <cstdint>
#include <iostream>
#include <limits>
using namespace sv04;
static unsigned checks=0;
#define CHECK(v) do {bool result=static_cast<bool>(v); if(!result){std::cerr<<"FAIL line "<<__LINE__<<": "<<#v<<"\n";std::abort();}++checks;}while(0)
static Guards guards(){Guards g;g.idle=g.heaters_ok=g.axes_safe=g.tool_safe=g.probe_ready=true;return g;}
static MeshImage image(){MeshImage m{};for(unsigned x=0;x<4;x++)for(unsigned y=0;y<4;y++)m.z[x][y]=0.01f*(x+y);m.spacing[0]=m.spacing[1]=80;m.origin[0]=m.origin[1]=20;m.leveling_active=true;return m;}
static BedTelemetry bed(uint32_t t){BedTelemetry b;b.actual=b.target=60;b.sampled_ms=t;b.sensor_ok=b.heater_ok=b.firmware_thermal_ok=true;return b;}
static IDEXInputs clearance(){IDEXInputs i;i.machine_idle=i.planner_empty_and_steppers_stopped=i.t0_selected=i.no_obstructions_confirmed=i.probe_selfcheck_passed=i.endstops_selfcheck_passed=i.bed_and_tools_safe=i.physical_clearance_confirmed=i.geometry_matches_oem=true;i.mode=CarriageMode::AutoPark;return i;}
static HomingResult homing(){HomingResult h;h.command_completed=h.x_trusted=h.y_trusted=h.z_trusted=h.t0_remains_active=h.t1_still_parked=h.probe_retracted=h.no_faults=true;return h;}
static ParkObservation park(){ParkObservation p;p.t1_endstop_hit=p.t1_x_trusted=p.t1_is_inactive=p.planner_synchronized=p.steppers_energized=p.auto_park_mode=p.t0_active=true;p.measured_t1_x=p.configured_t1_home_x=362;return p;}
static PersistenceInterlocks141 interlocks(){PersistenceInterlocks141 g;g.machine_idle=g.planner_synchronized=g.all_mesh_writers_locked=g.motion_stopped=g.thermal_stable=g.no_other_settings_writers=g.exact_4x4_geometry=g.verified_prior_eeprom_backup=g.read_only_decoder_available=g.user_authorized_save=true;return g;}
static void ready(Sequence140& s,MeshImage& m) {
 CHECK(s.begin(m,guards(),true,0)); CHECK(s.setpoint_accepted(true,10));
 for(uint32_t t=1000;t<=31000;t+=1000)CHECK(s.observe_bed(bed(t),t));
 CHECK(s.allow_home(clearance()));CHECK(s.home_finished(homing(),park(),31010));
 CHECK(s.allow_g29(park(),clearance()));CHECK(s.g29_started(true,31020));
 for(unsigned y=0;y<4;y++)for(unsigned x=0;x<4;x++){const float z=float(x)*0.1f+float(y)*0.01f;CHECK(s.point(x,y,z));m.z[x][y]=z;}
 CHECK(s.g29_finished(true,false,32000));CHECK(s.validate(m,true,true,32001));
 CHECK(s.controller.phase()==Phase::Persist);
}
int main() {
 // The precise negative rules, one omitted guard at a time.
 {auto g=interlocks();CHECK(safe_to_write(g));
  bool* b[]={&g.machine_idle,&g.planner_synchronized,&g.all_mesh_writers_locked,
   &g.motion_stopped,&g.thermal_stable,&g.no_other_settings_writers,
   &g.exact_4x4_geometry,&g.verified_prior_eeprom_backup,
   &g.read_only_decoder_available,&g.user_authorized_save};
  for(auto p:b){*p=false;CHECK(!safe_to_write(g));*p=true;CHECK(safe_to_write(g));}}
 // No premature write before verified G29 and frozen exact mesh.
 {Sequence140 s;auto m=image();EEPROMGate141 e;CHECK(!e.arm(s,m,interlocks()));CHECK(!e.begin_write(s,m,interlocks()));CHECK(!e.eeprom_may_be_modified());}
 // Happy path, with actual independent storage image supplied by mock adapter.
 {Sequence140 s;auto m=image();ready(s,m);EEPROMGate141 e;auto g=interlocks();
  CHECK(e.arm(s,m,g));CHECK(e.state()==Persist141::Armed);
  CHECK(!e.acknowledge_write(s,true,32005));CHECK(!e.acknowledge_readback(s,m,true,true,true,g,32006));
  CHECK(e.begin_write(s,m,g));CHECK(!e.begin_write(s,m,g));
  CHECK(e.acknowledge_write(s,true,32005));CHECK(s.controller.phase()==Phase::Verify);
  CHECK(!e.finish_verified());CHECK(e.acknowledge_readback(s,m,true,true,true,g,32006));
  CHECK(e.state()==Persist141::Verified);CHECK(s.controller.phase()==Phase::Success);
  CHECK(!e.begin_write(s,m,g));CHECK(!e.acknowledge_write(s,true,32007));}
 // The previous EEPROM might be partially overwritten after settings.save starts.
 {Sequence140 s;auto m=image();ready(s,m);EEPROMGate141 e;auto g=interlocks();
  CHECK(e.arm(s,m,g));CHECK(e.begin_write(s,m,g));CHECK(!e.acknowledge_write(s,false,32005));
  CHECK(e.eeprom_uncertain());CHECK(e.eeprom_may_be_modified());
  CHECK(!e.begin_write(s,m,g));CHECK(!e.acknowledge_readback(s,m,true,true,true,g,32006));}
 // Even a successful write is NOT success without a read-only verification.
 for(int failure=0;failure<6;failure++){
  Sequence140 s;auto m=image();ready(s,m);EEPROMGate141 e;auto g=interlocks();
  CHECK(e.arm(s,m,g));CHECK(e.begin_write(s,m,g));CHECK(e.acknowledge_write(s,true,32005));
  auto read=m;bool ro=true,integrity=true,settings=true;
  if(failure==0)ro=false;
  if(failure==1)integrity=false;
  if(failure==2)settings=false;
  if(failure==3)read.z[0][0]+=0.001f;
  if(failure==4)read.spacing[0]+=1;
  if(failure==5)g.motion_stopped=false;
  CHECK(!e.acknowledge_readback(s,read,ro,integrity,settings,g,32006));
  CHECK(e.eeprom_uncertain());CHECK(s.controller.phase()==Phase::Fault);
  CHECK(!e.acknowledge_readback(s,m,true,true,true,interlocks(),32007));
 }
 // No save if RAM has changed (even a small difference) after arming.
 for(int failure=0;failure<5;failure++){
  Sequence140 s;auto m=image();ready(s,m);EEPROMGate141 e;auto g=interlocks();CHECK(e.arm(s,m,g));
  if(failure==0)m.z[0][0]+=0.00001f;
  if(failure==1)m.origin[1]++;
  if(failure==2)m.leveling_active=!m.leveling_active;
  if(failure==3)g.no_other_settings_writers=false;
  if(failure==4)g.read_only_decoder_available=false;
  CHECK(!e.begin_write(s,m,g));CHECK(!e.eeprom_may_be_modified());
  e.invalidate();CHECK(e.state()==Persist141::FailedBeforeWrite);
 }
 // No saving when the claimed EEPROM backup is only a RAM snapshot, or no independent decoder.
 {Sequence140 s;auto m=image();ready(s,m);EEPROMGate141 e;auto g=interlocks();
  g.verified_prior_eeprom_backup=false;CHECK(!e.arm(s,m,g));
  g.verified_prior_eeprom_backup=true;g.read_only_decoder_available=false;
  CHECK(!e.arm(s,m,g));CHECK(!e.eeprom_may_be_modified());}
 // Fault after permission started means EEPROM uncertain, never auto-retry.
 {Sequence140 s;auto m=image();ready(s,m);EEPROMGate141 e;auto g=interlocks();
  CHECK(e.arm(s,m,g));CHECK(e.begin_write(s,m,g));e.invalidate();
  CHECK(e.eeprom_uncertain());CHECK(!e.begin_write(s,m,g));}
 std::cout<<"SV04 NEXT 141: "<<checks<<" assertions passed; NO EEPROM writes; NO hardware actions\n";
}
