#include "auto60_controller.h"
#include <cassert>
#include <iostream>
using namespace sv04;
static Guards safe(){return {true,true,true,true,true,true};}
static void to_probe(Controller& c){assert(c.start(safe(),0));assert(c.pending()==Action::SetBed60);c.ack(Action::SetBed60,true,100);c.temperature(59.8,1000);assert(c.phase()==Phase::Stabilize);c.temperature(60.2,32000);assert(c.pending()==Action::HomeSafely);c.ack(Action::HomeSafely,true,32200);assert(c.pending()==Action::Probe4x4);c.ack(Action::Probe4x4,true,32201);}
int main(){int tests=0;
  {Controller c;Guards g=safe();g.tool_safe=false;assert(!c.start(g,0));assert(c.phase()==Phase::Fault);++tests;}
  {Controller c;to_probe(c);for(unsigned y=0;y<4;y++)for(unsigned x=0;x<4;x++){assert(c.point(x,y,(float)(x+y)*.1f));++tests;}assert(c.samples()==16);c.probe_complete(true,false,34000);assert(c.phase()==Phase::Validate);c.validation(true,true,35000);assert(c.pending()==Action::SaveEEPROM);c.ack(Action::SaveEEPROM,true,36000);assert(c.pending()==Action::VerifyEEPROM);c.ack(Action::VerifyEEPROM,true,37000);assert(c.phase()==Phase::Success);++tests;}
  {Controller c;to_probe(c);assert(c.point(0,0,.1f));assert(!c.point(0,0,.2f));assert(c.phase()==Phase::Fault);assert(c.needs_restore());++tests;}
  {Controller c;to_probe(c);assert(!c.point(0,0,NAN));assert(c.pending()==Action::None);++tests;}
  {Controller c;to_probe(c);c.probe_complete(true,false,34000);assert(c.phase()==Phase::Fault);assert(c.error()==Error::BadMesh);++tests;}
  {Controller c;to_probe(c);c.probe_complete(true,true,34000);assert(c.phase()==Phase::Fault);++tests;}
  {Controller c;to_probe(c);c.abort();assert(c.error()==Error::Aborted);assert(c.pending()==Action::None);++tests;}
  {Controller c;assert(c.start(safe(),0));c.ack(Action::SetBed60,true,100);c.temperature(60,1000);c.temperature(58,25000);assert(c.phase()==Phase::Heat);c.temperature(60,26000);c.temperature(60,50000);assert(c.phase()==Phase::Stabilize);c.temperature(60,57000);assert(c.phase()==Phase::Home);++tests;}
  {Controller c;assert(c.start(safe(),0));c.ack(Action::SetBed60,true,100);c.temperature(126,1000);assert(c.error()==Error::Temperature);++tests;}
  {Controller c;to_probe(c);c.tick(1'000'000,true);assert(c.error()==Error::Timeout);++tests;}
  {Controller c;to_probe(c);c.tick(33000,false);assert(c.error()==Error::Unsafe);++tests;}
  {Controller c;assert(c.start(safe(),0));assert(!c.start(safe(),10));++tests;}
  std::cout << "PASS " << tests << " scenarios, plus 16 per-point checks\n";
}
