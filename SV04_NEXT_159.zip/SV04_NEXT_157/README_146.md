# SV04 NEXT 146: Lesende EEPROM-Layout-Diagnose

**Status:** Quellcode und Hosttests. **NICHT INSTALLIEREN. KEIN M500.** GitHub nicht erforderlich.

## Ausgangspunkt

Stand 145 kann den tatsächlichen `eeprom_index` der Bilinear-Felder beim **normalen** `MarlinSettings::_load()` erfassen, stellt ihn aber noch nicht sichtbar bereit. Stand 146 ergänzt eine *opt-in* serielle Diagnosespur **im bereits vorhandenen Ladevorgang**, die nur nach dem regulären `EEPROM_FINISH()` ausgegeben wird.

Inhalt:

- `settings_diagnostic146_inject.py`: ergänzt die vorherige **145-Instrumentierung** in einer **staged Kopie** von `Marlin/src/module/settings.cpp`. Nur auf einen bekannten Quellstand anwenden. Die Änderungen sind nicht installiert und nicht kompiliert.
- `validate_diagnostic146.py`: liest einen gespeicherten seriellen Logauszug, verlangt genau ein abgeschlossenes Protokoll `SV04_LAYOUT146`, verifiziert Wertebereich, Reihenfolge, Feldgrößen und 4x4-Mesh-Lage. Meldet explizit `eeprom_write_permitted=false` und `flash_driver_verified=false`.
- `test146.py`: negative und positive Tests für Parser und Patch-Einfügung.
- Alle übernommenen Quellmodule aus 135–145 für weitere lokale Entwicklung.

## Späterer Integrationsweg

1. **Zuerst** eine separate Kopie der tatsächlichen Sovol-Marlin-Quelle nehmen und Stand 145 mit `python3 settings_layout145_inject.py Marlin/src/module/settings.cpp` einfügen.
2. Stand 146 mit `python3 settings_diagnostic146_inject.py Marlin/src/module/settings.cpp` ergänzen.
3. Erst nach Quellprüfung beim Firmware-Build **optional** die Compilerdefinition `SV04_NEXT_LAYOUT146_DIAGNOSTICS` setzen. Die Diagnose ist sonst vollständig deaktiviert.
4. Nach einem **normalen, validen Boot-Ladevorgang** kann die serielle Ausgabe `SV04_LAYOUT146 BEGIN ... END` erscheinen. **Nicht** `M500` oder `M501` ausführen, nur um einen Bericht zu bekommen.
5. Logdatei auf einem Computer/Cloud-Runner mittels `python3 validate_diagnostic146.py serial-log.txt` prüfen. Die Ausgabe dient nur zur Layoutdiagnose, nicht als Freigabe für EEPROM-Schreibvorgänge.

## Sicherheitsnotizen

- `SERIAL_ECHO_MSG` ist im Marlin-Quellcode vorhanden, **ein vollständiger STM32F103-Build für den Patch wurde nicht ausgeführt**. Kompatibilität und serieller Zugriff am Display/Board sind nicht bestätigt.
- Die aktuell instrumentierten Feldpositionen stammen aus dem normalen `_load()` und gelten nur, wenn der vollständige EEPROM-Ladevorgang erfolgreich war. Bei leeren, beschädigten oder alten EEPROM-Daten wird **kein gültiger Report** erzeugt.
- Der Treiber kann das EEPROM je nach Backend anders behandeln. Insbesondere hat eine SD-Karten-Emulation andere Abschlusssemantik als Flash. Dieser Report verifiziert **weder** das konkrete Backend **noch** die Flash-Zuverlässigkeit.
- `verified=1` sagt lediglich, dass Marlins Ladepfad keine gemeldeten CRC-/Layoutfehler hatte. Ein mitgedrucktes Layout ist **keine** unabhängig authentifizierte Hardwaremessung.
- Das Script verändert ausschließlich die angegebene staged `.cpp`-Datei. Es gibt keine GitHub-Änderung, keinen GCode-Befehl und keinen Firmware-Upload.
- Hardwaretests müssen Drucker- und Kollisionsschutz berücksichtigen. Testarchiv ausdrücklich nicht flashen.

## Lokal ausgeführte Tests

`test146.py`: 34 unabhängige Assertions PASS. Regressionstests aus 135–145 separat geprüft. Kein Hardwaretest und kein wirklicher Marlin-Build.

**Gesamtergebnis: Stand 146 ist eine diagnosefähige Quelldatei-Erweiterung, keine einsetzbare Druckerfirmware.**
