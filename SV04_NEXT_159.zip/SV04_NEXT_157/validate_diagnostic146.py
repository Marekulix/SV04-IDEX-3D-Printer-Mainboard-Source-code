#!/usr/bin/env python3
"""Parse SV04_LAYOUT146 serial log, validate field topology, print JSON.
Never connects to printer, never writes firmware, never marks backend verified.
"""
from pathlib import Path
import json,sys,re

FIELDS=('protocol','version','verified','capacity','settings_size','header_offset','grid_x','grid_y','spacing','origin','mesh','xy_bytes','mesh_bytes')

class Refused(ValueError): pass

def parse_report(text):
    blocks=[];current=None
    for line in text.splitlines():
        # Accept typical serial log prefixes; reject accidental mixed records
        ix=line.find('SV04_LAYOUT146 ')
        if ix<0: continue
        payload=line[ix+len('SV04_LAYOUT146 '):].strip()
        if payload=='BEGIN':
            if current is not None: raise Refused('nested BEGIN')
            current={}; continue
        if payload=='END':
            if current is None: raise Refused('unexpected END')
            if set(current)!=set(FIELDS):raise Refused('missing or unknown fields')
            blocks.append(current);current=None; continue
        if current is None:raise Refused('field outside report')
        if '=' not in payload:raise Refused('bad field')
        key,value=payload.split('=',1)
        if key not in FIELDS or key in current:raise Refused('unknown/duplicate field')
        if key=='version':
            if value!='V85':raise Refused('unknown version')
            current[key]=value
        else:
            if not re.fullmatch(r'[0-9]{1,10}',value):raise Refused('not unsigned integer')
            v=int(value)
            if v>0xffffffff:raise Refused('integer overflow')
            current[key]=v
    if current is not None:raise Refused('partial report')
    if len(blocks)!=1:raise Refused('expected exactly one report')
    e=blocks[0]
    if e['protocol']!=1 or e['verified']!=1:raise Refused('firmware did not verify load')
    if e['header_offset']!=100 or e['xy_bytes']!=8 or e['mesh_bytes']!=64:raise Refused('unexpected layout')
    if not 512<=e['capacity']<=65536:raise Refused('invalid capacity')
    if not 128<=e['settings_size']<=e['capacity']-100:raise Refused('invalid settings size')
    if e['grid_y']!=e['grid_x']+1 or e['spacing']!=e['grid_y']+1:raise Refused('wrong grid fields')
    if e['origin']!=e['spacing']+e['xy_bytes'] or e['mesh']!=e['origin']+e['xy_bytes']:raise Refused('wrong mesh layout')
    if e['grid_x']<106 or e['mesh']+64>100+e['settings_size']:raise Refused('out of range')
    # Diagnostic text is NOT an authenticated observation of firmware or actual flash driver.
    return {'status':'diagnostic_layout_observed_only','source_build_generated':False,
            'flash_driver_verified':False,'eeprom_write_permitted':False,'layout':e}

def main():
    if len(sys.argv)!=2:raise SystemExit('Usage: python3 validate_diagnostic146.py <serial-log.txt>')
    try: d=parse_report(Path(sys.argv[1]).read_text(encoding='utf8'))
    except (Refused, OSError) as ex:print(json.dumps({'status':'REFUSED','reason':str(ex)},indent=2));return 2
    print(json.dumps(d,indent=2));return 0
if __name__=='__main__':sys.exit(main())
