#pragma once
// SV04 NEXT 156: host-tested shared SD arbiter, NOT installed in Marlin.
// Single-thread event-loop design. If moved to interrupt/multithread context,
// protect acquire/release and media epochs with a real critical section.
// Printer operations take priority. This is NOT a safety-critical interlock.
#include "sd_exclusive151.h"
#include <cstdint>
namespace sv04 {
enum class MediaOwner156 : uint8_t { None, Diagnostic, Print, Recovery, Upload, Browser, Directory, MediaManager, Other };
enum class Result156 : uint8_t { Granted, Busy, Invalid, Stale, WrongOwner, Fault };
struct MediaState156 {
  bool mounted=false, media_changing=false, print_file_open=false,
       printing=false, paused=false, recovery_busy=false, upload_busy=false,
       logging_busy=false, other_busy=false;
  uint64_t epoch=0;
};
class SharedMedia156 {
  MediaState156 state_{};
  MediaOwner156 holder_=MediaOwner156::None;
  uint64_t lease_epoch_=0;
  uint32_t sequence_=0;
  bool fault_=false;
  bool diagnostics_enabled_=false; // Do not change for firmware integration without reviewed hooks.
public:
  // This alone is not evidence all SD paths have been instrumented.
  void test_only_enable_diagnostics(const bool enable) { diagnostics_enabled_=enable; }
  void update(const MediaState156& s) {
    const bool epoch_change = state_.epoch != s.epoch || state_.mounted != s.mounted;
    state_=s;
    if (epoch_change || s.media_changing || !s.mounted) {
      // Active physical I/O cannot be safely cancelled. Fault until confirmed quiescent.
      if (holder_ != MediaOwner156::None) fault_=true;
    }
  }
  void quiescent_reset() {
    if(holder_==MediaOwner156::None && state_.mounted && !state_.media_changing)
      fault_=false;
  }
  Result156 acquire(MediaOwner156 who, uint64_t epoch, uint32_t& token) {
    token=0;
    if(who==MediaOwner156::None || epoch==0) return Result156::Invalid;
    if(fault_) return Result156::Fault;
    if(!state_.mounted || state_.media_changing || state_.epoch != epoch) return Result156::Stale;
    if(holder_ != MediaOwner156::None) return Result156::Busy; // no recursive leases
    if(who==MediaOwner156::Diagnostic) {
      if(!diagnostics_enabled_ || state_.printing || state_.paused || state_.print_file_open ||
         state_.recovery_busy || state_.upload_busy || state_.logging_busy || state_.other_busy)
        return Result156::Busy;
    }
    holder_=who; lease_epoch_=epoch;
    // Zero is never a valid token; stale tokens cannot release a new lease.
    if(++sequence_==0) ++sequence_;
    token=sequence_;
    return Result156::Granted;
  }
  Result156 release(MediaOwner156 who, uint64_t epoch, uint32_t token) {
    if(holder_!=who || who==MediaOwner156::None || !token || token!=sequence_) return Result156::WrongOwner;
    const bool stale = epoch != lease_epoch_ || state_.epoch != lease_epoch_ ||
                       !state_.mounted || state_.media_changing;
    holder_=MediaOwner156::None; lease_epoch_=0;
    if(stale){ fault_=true;return Result156::Stale; }
    return Result156::Granted;
  }
  MediaOwner156 owner()const{return holder_;}
  bool faulted()const{return fault_;}
  uint64_t epoch()const{return state_.epoch;}
  bool diagnostics_safe()const{return !fault_ && diagnostics_enabled_ && state_.mounted &&
    !state_.media_changing && !state_.printing && !state_.paused && !state_.print_file_open &&
    !state_.recovery_busy && !state_.upload_busy && !state_.logging_busy && !state_.other_busy;}
  static constexpr bool can_save_eeprom(){return false;}
  static constexpr bool can_restore_eeprom(){return false;}
};
// Adapts the host-owned stepper to the common arbitration model.
// In an actual Marlin integration, all SD pathways must obtain the same arbiter.
class SharedOwnership156: public SdOwnership151 {
  SharedMedia156& gate_;
  SdSnapshot151 snapshot_{};
  uint32_t token_=0;
  uint64_t held_epoch_=0;
public:
  explicit SharedOwnership156(SharedMedia156& gate):gate_(gate){}
  void set_snapshot(const SdSnapshot151& s){snapshot_=s;}
  SdSnapshot151 snapshot()const override{return snapshot_;}
  bool try_acquire_exclusive_read() override{
    if(token_)return false;
    uint32_t t=0;
    if(gate_.acquire(MediaOwner156::Diagnostic,snapshot_.mount_epoch,t)!=Result156::Granted)return false;
    token_=t; held_epoch_=snapshot_.mount_epoch;return true;
  }
  void release_exclusive_read() override{
    if(token_){gate_.release(MediaOwner156::Diagnostic,held_epoch_,token_);token_=0;held_epoch_=0;}
  }
  bool held()const{return token_!=0;}
};
static_assert(!SharedMedia156::can_save_eeprom() && !SharedMedia156::can_restore_eeprom(),"Fail closed");
} // namespace sv04
