# SV04 NEXT 150 | SD-Karten-Lesediagnose (Host-Prototyp)

**NICHT INSTALLIEREN.** Kein STM32-Build. Keine SD-Schreiboperation, kein EEPROM-Schreibzugriff, keine automatische Wiederherstellung.

## Umsetzung
- `sd_readonly150.h`: Abstrakter **rein lesender** SD-Port mit `mounted()`, monotoner Mount-Epoche und `read_exact()` für vier fest zugeordnete Dateien (Slot A: Daten/Commit, Slot B: Daten/Commit). Keine frei wählbaren Dateipfade.
- Je Datei höchstens `expected_bytes+24` (Daten) beziehungsweise 20 Byte (Commit). Erwartete EEPROM-Größe höchstens 65536 Bytes.
- Jede Datei zweimal lesen und vergleichen; bei Kartenwechsel oder geänderter Mount-Epoche sofort abbrechen.
- Vorhandene `decode149()`/`select149()`-Prüfungen für Kartennummer, Gerätekennung, CRC32, Generation, Länge und Commit verwenden.
- Ergebnis `ValidUntrustedMedia` bedeutet ausdrücklich **nur** ein konsistentes logisches Backup bei den vom Host vorgegebenen Kennungen. `mount_epoch()` ist **keine** physische Kartenidentität.
- `may_write_eeprom=false`, `may_restore_eeprom=false` für **alle** Ergebnisse, unabhängig von Prüferfolg.

## Prüfungen
- `test150.cpp`: 318 gezielte Prüfaussagen PASS mit `-fsanitize=undefined`.
- 19 vorhandene C++-Testprogramme und 2 Python-Testprogramme: PASS (21 Regressionstestprogramme).
- Alle Tests sind Host-Simulation. Es wurde weder eine reale Karte verwendet noch der Drucker geflasht.

## Quellen, OEM Sovol Commit `1867fcba75354a5c65e0631d6972dd19f1bd6cbe`
- `Marlin/Configuration.h`: `SDSUPPORT` aktiviert.
- `Marlin/src/sd/cardreader.cpp`: `openFileWrite` mit `O_TRUNC`, `closefile()` verwendet `file.sync()` und `file.close()`.
- `Marlin/src/sd/cardreader.h`: `CardReader::isMounted()` existiert.

## Blockierende Punkte vor echter Marlin-Integration
1. Implementierung eines Marlin-SD-Adapters mit ungestörtem, exklusivem Zugriff auf feste Sicherungsdateien. `CardReader`-Druckstatus, offene Dateien und laufende SD-Jobs beachten.
2. Tatsächliche Kartenidentität und Kartenwechsel während laufender Dateizugriffe prüfen. Mount-Epoche allein reicht nicht aus.
3. Medien-/Dateisystem-Dauerhaftigkeit unter physikalischen Stromausfällen prüfen. CRC32 verhindert keine gezielte Manipulation und beweist keine dauerhafte Speicherung.
4. Marlin-Build, Host-Schnittstellen-Integration, Hardwaretest, Fehler-Injektion und sichere manuelle Recovery-Prozedur.
5. Bis dahin `M500` und Flash-Wiederherstellung für die Automatik gesperrt lassen.

Fortschritt Punkt 3 nach Stand 150: 47 % **subjektive Entwicklungsplanung**, nicht Hardware-Reife.
