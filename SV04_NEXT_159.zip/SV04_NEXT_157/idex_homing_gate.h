#pragma once
#include <cstdint>
#include <cmath>

// SV04 NEXT 137 - purely logical, fail-closed guard against requesting homing
// when the dual-X carriage configuration / geometry is not verified.
// THIS DOES NOT PERFORM A PHYSICAL COLLISION CHECK OR ANY MOTION.
namespace sv04 {

struct OemGeometry {
  static constexpr float X1_MIN = -62.0f;
  static constexpr float X1_MAX = 302.0f;
  static constexpr float X2_MIN = 0.0f;
  static constexpr float X2_MAX = 362.0f;
  static constexpr float Y_MIN = 0.0f;
  static constexpr float Y_MAX = 302.0f;
  static constexpr float Z_MAX = 400.0f;
  static constexpr float PROBE_OFFSET_X = 0.0f;
  static constexpr float PROBE_OFFSET_Y = 25.0f;
  static constexpr float PROBE_MARGIN = 25.0f;
};

enum class CarriageMode : uint8_t { Unknown, AutoPark, Duplication, Mirrored, FullControl };
enum class GateReason : uint8_t {
  Ready, NotIdle, MotionNotStopped, WrongMode, ToolNotT0,
  ParkNotConfirmed, Obstruction, ProbeNotReady, EndstopNotReady,
  GeometryMismatch, UnsafeTemperatures, MissingPhysicalClearance,
  HomeFailed, HomeNotConfirmed
};
struct IDEXInputs {
  bool machine_idle = false;
  bool planner_empty_and_steppers_stopped = false;
  CarriageMode mode = CarriageMode::Unknown;
  bool t0_selected = false;
  bool t1_parked_sensor_or_verified_homing = false;
  bool no_obstructions_confirmed = false;
  bool probe_selfcheck_passed = false;
  bool endstops_selfcheck_passed = false;
  bool bed_and_tools_safe = false;
  bool physical_clearance_confirmed = false;
  bool geometry_matches_oem = false;
};

// If no independent feedback on the T1 park position exists, caller must NOT
// set t1_parked_sensor_or_verified_homing based on a guessed coordinate.
inline GateReason preflight(const IDEXInputs &g) {
  if (!g.machine_idle) return GateReason::NotIdle;
  if (!g.planner_empty_and_steppers_stopped) return GateReason::MotionNotStopped;
  if (g.mode != CarriageMode::AutoPark) return GateReason::WrongMode;
  if (!g.t0_selected) return GateReason::ToolNotT0;
  if (!g.t1_parked_sensor_or_verified_homing) return GateReason::ParkNotConfirmed;
  if (!g.no_obstructions_confirmed) return GateReason::Obstruction;
  if (!g.probe_selfcheck_passed) return GateReason::ProbeNotReady;
  if (!g.endstops_selfcheck_passed) return GateReason::EndstopNotReady;
  if (!g.geometry_matches_oem) return GateReason::GeometryMismatch;
  if (!g.bed_and_tools_safe) return GateReason::UnsafeTemperatures;
  if (!g.physical_clearance_confirmed) return GateReason::MissingPhysicalClearance;
  return GateReason::Ready;
}

// A homing command acknowledgement alone does NOT establish trusted axes.
// Actual Marlin axis_trusted / axes_should_home and probe feedback required.
struct HomingResult {
  bool command_completed = false;
  bool x_trusted = false;
  bool y_trusted = false;
  bool z_trusted = false;
  bool t0_remains_active = false;
  bool t1_still_parked = false;
  bool probe_retracted = false;
  bool no_faults = false;
};
inline GateReason verify_homing(const HomingResult &h) {
  if (!h.command_completed || !h.no_faults) return GateReason::HomeFailed;
  if (!h.x_trusted || !h.y_trusted || !h.z_trusted ||
      !h.t0_remains_active || !h.t1_still_parked || !h.probe_retracted)
    return GateReason::HomeNotConfirmed;
  return GateReason::Ready;
}

// Purely numeric static envelope, NOT a guarantee of collision-free homing.
inline bool nominal_probe_xy(float nozzle_x, float nozzle_y) {
  if (!std::isfinite(nozzle_x) || !std::isfinite(nozzle_y)) return false;
  const float probe_x = nozzle_x + OemGeometry::PROBE_OFFSET_X;
  const float probe_y = nozzle_y + OemGeometry::PROBE_OFFSET_Y;
  return probe_x >= OemGeometry::PROBE_MARGIN &&
         probe_x <= OemGeometry::X1_MAX - OemGeometry::PROBE_MARGIN &&
         probe_y >= OemGeometry::PROBE_MARGIN &&
         probe_y <= OemGeometry::Y_MAX - OemGeometry::PROBE_MARGIN;
}
} // namespace sv04
