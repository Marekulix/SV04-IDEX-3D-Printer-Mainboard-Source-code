#include "sd_marlin_contract155.h"
#include <cstdio>
#include <map>
using namespace sv04;
static int checks=0;
#define CHECK(x) do {++checks;if(!(x)){std::fprintf(stderr,"FAIL %d %s\n",__LINE__,#x);return 1;}}while(0)
struct Owner: SdOwnership151 {
 SdSnapshot151 s{};bool held=false;int grabs=0,releases=0;
 SdSnapshot151 snapshot()const override{return s;}
 bool try_acquire_exclusive_read()override{if(held)return false;held=true;++grabs;return true;}
 void release_exclusive_read()override{held=false;++releases;}
};
struct Port: SdSlicePort153 {
 Owner& o;std::map<unsigned,std::vector<uint8_t>> files;int slices=0;
 explicit Port(Owner& x):o(x){}
 bool mounted()const override{return o.s.mounted;}
 uint64_t mount_epoch()const override{return o.s.mount_epoch;}
 bool read_slice(unsigned id,size_t offset,size_t limit,std::vector<uint8_t>& out,size_t& size)override {
  ++slices;if(!o.held||limit>64)return false;
  auto it=files.find(id);if(it==files.end())return false;
  size=it->second.size();if(offset>size)return false;
  const size_t count=(size-offset<limit)?size-offset:limit;
  out.assign(it->second.begin()+offset,it->second.begin()+offset+count);return true;
 }
};
int main(){
  Owner o;o.s.mounted=true;o.s.mount_epoch=7;o.s.media_generation=3;o.s.card_identity_verified=true;
  Port p{o};Backup149 backup{42,63,1,std::vector<uint8_t>(256,0x7C)};
  p.files[0]=encode149(backup);p.files[1]=commit149(backup);
  MarlinDiagnostic155 gate;
  CHECK(gate.state()==IntegrationStatus155::Blocked);
  CHECK(!gate.start(o.s,1000,42,63,256));
  MarlinEvidence155 evidence{};
  for(unsigned i=0;i<9;++i){
    evidence={true,true,true,true,true,required_hooks155&~(1u<<i)};
    CHECK(!evidence.compatible());gate.configure(evidence);
    CHECK(gate.state()==IntegrationStatus155::Blocked);CHECK(!gate.start(o.s,1000,42,63,256));
  }
  for(unsigned i=0;i<5;++i){
    evidence={true,true,true,true,true,required_hooks155};
    if(i==0)evidence.build_verified=false;
    if(i==1)evidence.hardware_driver_verified=false;
    if(i==2)evidence.shared_atomic_lease_verified=false;
    if(i==3)evidence.independent_sd_path_verified=false;
    if(i==4)evidence.medium_identity_hardware_verified=false;
    CHECK(!evidence.compatible());gate.configure(evidence);CHECK(!gate.start(o.s,2000,42,63,256));
  }
  evidence={true,true,true,true,true,required_hooks155};
  gate.configure(evidence);CHECK(gate.state()==IntegrationStatus155::Idle);
  o.s.file_open=true;CHECK(!gate.start(o.s,3000,42,63,256));o.s.file_open=false;
  CHECK(gate.start(o.s,3000,42,63,256));
  for(unsigned i=0;i<80&&gate.state()!=IntegrationStatus155::VerifiedUntrusted;++i){
    gate.poll(o,p,3000+i);CHECK(!o.held);CHECK(o.grabs==o.releases);
  }
  CHECK(gate.state()==IntegrationStatus155::VerifiedUntrusted);
  CHECK(!MarlinDiagnostic155::may_write_eeprom());CHECK(!MarlinDiagnostic155::may_restore_eeprom());
  CHECK(!MarlinDiagnostic155::may_write_sd());
  gate.configure(evidence);CHECK(gate.start(o.s,5000,42,63,256));
  CHECK(gate.poll(o,p,5000)==IntegrationStatus155::Reading);
  gate.event(SdEvent152::GlobalReset);CHECK(gate.state()==IntegrationStatus155::Cancelled);
  int old=p.slices;CHECK(gate.poll(o,p,5001)==IntegrationStatus155::Cancelled);CHECK(old==p.slices);
  gate.configure(evidence);CHECK(gate.start(o.s,6000,42,63,256));
  CHECK(gate.poll(o,p,6000)==IntegrationStatus155::Reading);
  evidence.shared_atomic_lease_verified=false;gate.configure(evidence);
  CHECK(gate.state()==IntegrationStatus155::Blocked);CHECK(!gate.start(o.s,6001,42,63,256));
  std::printf("SV04 155: %d checks PASS (host simulation; production gate NOT authorized)\n",checks);
}
