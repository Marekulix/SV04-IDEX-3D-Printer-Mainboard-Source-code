# SV04 NEXT 155: Integrationsvertrag für gemeinsame SD-Zugriffe

**Stand:** Host-Prototyp, nicht installieren, keine Freigabe für M500, SD-Schreiben oder EEPROM-Restore.

## Neue Dateien
- `sd_marlin_contract155.h`: fail-closed Abdeckungs- und Freigabevertrag, gebunden an `Cooperative154`.
- `test155.cpp`: Simulatorprüfungen für fehlende SD-Hooks, Konkurrenz, Erfolg (nur `VerifiedUntrusted`), GlobalReset und Zurücknahme der Freigabe.

## Konkrete Integrationsstellen in der geprüften Sovol-Quelle
Originalrepository `Sovol3d/SV04-IDEX-3D-Printer-Mainboard-Source-code`, Commit `1867fcba75354a5c65e0631d6972dd19f1bd6cbe`:
- `Marlin/src/sd/cardreader.h`: `CardReader::isMounted`, `isPrinting`, `isPaused`, `isFileOpen`, Datei-/Mount-Zustand. Sie liefern **nur Status**, keine atomare Sperre.
- `Marlin/src/sd/cardreader.cpp`: `openFileRead`, `openFileWrite`, `closefile`, `removeFile`, Mount/Release, Directory-Operationen; vor jedem Dateizugriff muss ein gemeinsamer Lock gelten.
- `Marlin/src/sd/cardreader.cpp`: Recovery-Methoden (`jobRecoverFileExists`, `openJobRecoveryFile`, `removeJobRecoveryFile`) nutzen eigene Dateiobjekte. Sie müssen **dieselbe Sperre** berücksichtigen.
- `Marlin/src/sd/cardreader.h`: `getWorkDir`, `getroot`, `read`, `write`, `get`, `setIndex` und Dateiauflistung: für vollständige Abdeckung auch deren Aufrufer prüfen.
- Notfallabbruch, Dateiupload/Logging, Touchscreen und Medienwechsel dürfen den SD-Leser invalidieren und müssen vor dessen Lease geschützt sein.

## Architekturentscheidung
**Keine produktive Freigabe aufgrund einer einzigen `card.isPrinting()`-Abfrage.** Die neun in `SdClient155` benannten Nutzungsbereiche sind verbindlich, aber noch nicht instrumentiert. Die fünf Flags in `MarlinEvidence155` sind Platzhalter für später nachzuweisende Bedingungen; sie dürfen **nicht** durch pauschales `true` ersetzt werden.

Der 64-Byte-Leser aus Stand 153 hält derzeit in `SdIncremental153::poll()` innerhalb einer Lease jeweils einen synchronen Slice-Aufruf. Selbst die 64-Byte-Grenze garantiert noch keine zeitliche Obergrenze für reale SD-Karten. Vor Firmware-Integration sind Latenz- und Watchdogtests nötig.

## Freigabesperren
- Kein EEPROM-Schreibpfad (`M500`), kein automatischer Restore, kein SD-Schreiben.
- Keine hardwaregestützte stabile Kartenidentität und kein atomarer, systemweit geteilter Marlin-SD-Lock vorhanden.
- Nur nach vollständiger Instrumentierung aller Nutzer, reproduzierbarem STM32-Build und Prüfung am Testgerät weitere Integration.

## Nächster Schritt
`CardReader`- und Recovery-Dateizugriffe im geklonten Marlin-Baum aufrufen und eine einzige nicht-rekursive, kurz gehaltene SD-Eigentümerverwaltung mit überprüfbarer Abdeckung bauen. Dabei den bestehenden SD-Druckbetrieb unangetastet lassen, solange die vollständige Abdeckung nicht nachgewiesen ist.
