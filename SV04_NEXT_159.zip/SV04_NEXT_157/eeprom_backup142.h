#pragma once
// SV04 NEXT 142: HOST-ONLY independent full-image EEPROM archive. NOT for firmware / NOT for flash.
// READ-ONLY source contract is assumed, not proven for Sovol persistentStore backend.
// No G-code, settings.save(), M500, M501, or EEPROM restore commands here.
#include <cstddef>
#include <cstdint>
#include <vector>
#include <algorithm>

namespace sv04 {
constexpr size_t kMaxEEPROMBytes142 = 65536;
constexpr uint32_t kBackupMagic142 = 0x53563134; // 'SV14', private host archive format

inline uint32_t checksum142(const uint8_t *p, size_t n) {
  uint32_t crc = 0xFFFFFFFFu;
  for (size_t i=0; i<n; ++i) {
    crc ^= p[i];
    for (unsigned k=0; k<8; ++k) crc = (crc >> 1) ^ (0xEDB88320u & (0u - (crc & 1u)));
  }
  return ~crc;
}
inline void u32le142(std::vector<uint8_t>& v, uint32_t x) {
  for (unsigned i=0;i<4;i++) v.push_back(uint8_t(x>>(i*8)));
}
inline uint32_t get32le142(const std::vector<uint8_t>&v, size_t i) {
  return uint32_t(v[i]) | (uint32_t(v[i+1])<<8) | (uint32_t(v[i+2])<<16) | (uint32_t(v[i+3])<<24);
}

struct ReadOnlyEEPROM142 {
  virtual ~ReadOnlyEEPROM142() = default;
  virtual bool is_independently_attested_read_only() const = 0;
  virtual size_t capacity() const = 0;
  virtual bool read(size_t offset, uint8_t* output, size_t length) = 0;
};
struct IndependentArchive142 {
  virtual ~IndependentArchive142() = default;
  // Must be persistent separately from the EEPROM source and genuinely readable.
  virtual bool is_independent_durable_storage() const = 0;
  virtual bool save(const std::vector<uint8_t>& image) = 0;
  virtual bool load(std::vector<uint8_t>& image) = 0;
};

enum class BackupPhase142 : uint8_t { Empty, Verified, Failed };
class EEPROMBackup142 {
public:
  BackupPhase142 state() const { return state_; }
  bool verified_prior_eeprom_backup() const { return state_ == BackupPhase142::Verified; }
  size_t covered_bytes() const { return state_ == BackupPhase142::Verified ? bytes_ : 0; }
  uint32_t image_checksum() const { return crc_; }
  void invalidate() { state_=BackupPhase142::Failed; bytes_=0; crc_=0; }
  bool capture(ReadOnlyEEPROM142& src, IndependentArchive142& archive,
               bool idle, bool writes_locked, bool planner_stopped) {
    if (state_ != BackupPhase142::Empty) return false;
    if (!idle || !writes_locked || !planner_stopped ||
        !src.is_independently_attested_read_only() ||
        !archive.is_independent_durable_storage()) return fail();
    const size_t n=src.capacity();
    if(n<128 || n>kMaxEEPROMBytes142) return fail();
    std::vector<uint8_t> a(n),b(n);
    if(!src.read(0,a.data(),n) || !src.read(0,b.data(),n) || a!=b) return fail();
    // Host archive: magic/version/length/image-crc + image + envelope-crc.
    std::vector<uint8_t> payload;payload.reserve(n+20);
    u32le142(payload,kBackupMagic142);u32le142(payload,1);u32le142(payload,static_cast<uint32_t>(n));
    const uint32_t c=checksum142(a.data(),n);
    u32le142(payload,c);payload.insert(payload.end(),a.begin(),a.end());
    u32le142(payload,checksum142(payload.data(),payload.size()));
    if(!archive.save(payload)) return fail();
    std::vector<uint8_t> recovered;
    if(!archive.load(recovered) || recovered!=payload || !check_archive(recovered)) return fail();
    // Re-read live EEPROM after storing the independent archive: no unexpected drift.
    std::vector<uint8_t> final_image(n);
    if(!src.read(0,final_image.data(),n) || final_image!=a) return fail();
    bytes_=n;crc_=c;state_=BackupPhase142::Verified;return true;
  }
  static bool check_archive(const std::vector<uint8_t>& b) {
    if(b.size()<148 || get32le142(b,0)!=kBackupMagic142 || get32le142(b,4)!=1) return false;
    const size_t n=get32le142(b,8);
    if(n<128 || n>kMaxEEPROMBytes142 || b.size()!=n+20) return false;
    if(checksum142(b.data()+16,n)!=get32le142(b,12)) return false;
    return checksum142(b.data(),b.size()-4)==get32le142(b,b.size()-4);
  }
private:
  bool fail(){invalidate();return false;}
  BackupPhase142 state_=BackupPhase142::Empty;
  size_t bytes_=0;
  uint32_t crc_=0;
};
} // namespace sv04
