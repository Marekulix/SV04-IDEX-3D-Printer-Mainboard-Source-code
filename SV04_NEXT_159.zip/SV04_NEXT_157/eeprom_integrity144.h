#pragma once
// SV04 NEXT 144: HOST-ONLY reference verifier. NEVER writes EEPROM.
// Source: pinned Sovol Marlin settings.cpp, libs/crc16.cpp.
#include <cstddef>
#include <cstdint>
#include <cmath>
#include <cstring>
#include <limits>
namespace sv04 {
constexpr size_t EEPROM_OFFSET_144=100;
constexpr size_t HEADER_BYTES_144=6;
constexpr size_t MESH_POINTS_144=16;

// An independently derived build layout must come from offsetof(SettingsData,...)
// in the exact active firmware configuration, not guessed from source order.
struct Layout144 {
 size_t total_eeprom_capacity=0;
 size_t settings_data_size=0; // sizeof(SettingsData): includes 6-byte header + payload
 size_t grid_x_offset=0, grid_y_offset=0;
 size_t mesh_offset=0;  // beginning of 16 float32 values in persistent storage
 size_t mesh_spacing_offset=0, mesh_origin_offset=0;
 size_t xy_pos_bytes=0;
 bool layout_compiled_and_verified=false;
 bool flash_backend_certified=false;
};
enum class Integrity144 : uint8_t {
 Unchecked, Refused, BadBounds, BadVersion, BadCRC,
 GridMismatch, BadMeshNumbers, VerifiedImageMesh
};
inline uint16_t crc16_marlin144(const uint8_t* data, size_t len) {
 uint16_t crc=0;
 for (size_t p=0;p<len;p++) {
  crc=uint16_t(crc ^ (uint16_t(data[p])<<8));
  for (unsigned b=0;b<8;b++) crc=uint16_t((crc&0x8000u)?((crc<<1)^0x1021u):(crc<<1));
 }
 return crc;
}
inline bool section144(size_t offset, size_t len, size_t lo, size_t hi) {
 return offset>=lo && offset<=hi && len<=hi-offset;
}
inline uint16_t u16le144(const uint8_t* b){return uint16_t(b[0])|uint16_t(uint16_t(b[1])<<8);}
inline float f32le144(const uint8_t* b){
 const uint32_t bits=uint32_t(b[0])|(uint32_t(b[1])<<8)|(uint32_t(b[2])<<16)|(uint32_t(b[3])<<24);
 static_assert(sizeof(float)==4, "requires IEEE 754 float32 host");
 float f;std::memcpy(&f,&bits,4);return f;
}
struct Verification144 {
 Integrity144 result=Integrity144::Unchecked;
 uint16_t stored_crc=0, computed_crc=0;
 float mesh[MESH_POINTS_144]{};
 bool verified()const { return result==Integrity144::VerifiedImageMesh; }
};
inline Verification144 verify_eeprom144(const uint8_t* bytes,size_t length,const Layout144& layout) {
 Verification144 out;
 out.result=Integrity144::Refused;
 if(!bytes || !layout.layout_compiled_and_verified || !layout.flash_backend_certified)
  return out;
 if(length!=layout.total_eeprom_capacity || length<EEPROM_OFFSET_144+HEADER_BYTES_144 ||
    layout.settings_data_size<HEADER_BYTES_144 ||
    !section144(EEPROM_OFFSET_144,layout.settings_data_size,0,length)) {
  out.result=Integrity144::BadBounds;return out;
 }
 const size_t datastart=EEPROM_OFFSET_144+HEADER_BYTES_144;
 const size_t end=EEPROM_OFFSET_144+layout.settings_data_size;
 // Check all field bounds AND keep them inside CRC-protected settings payload.
 if(!section144(layout.grid_x_offset,1,datastart,end) ||
    !section144(layout.grid_y_offset,1,datastart,end) ||
    !section144(layout.mesh_offset,16*4,datastart,end) ||
    layout.xy_pos_bytes==0 ||
    !section144(layout.mesh_spacing_offset,layout.xy_pos_bytes,datastart,end) ||
    !section144(layout.mesh_origin_offset,layout.xy_pos_bytes,datastart,end)) {
  out.result=Integrity144::BadBounds;return out;
 }
 const uint8_t* head=bytes+EEPROM_OFFSET_144;
 if(!(head[0]=='V' && head[1]=='8' && head[2]=='5' && head[3]==0)) {
  out.result=Integrity144::BadVersion;return out;
 }
 out.stored_crc=u16le144(head+4);
 out.computed_crc=crc16_marlin144(bytes+datastart,end-datastart);
 if(out.stored_crc!=out.computed_crc) {
  out.result=Integrity144::BadCRC;return out;
 }
 if(bytes[layout.grid_x_offset]!=4 || bytes[layout.grid_y_offset]!=4) {
  out.result=Integrity144::GridMismatch;return out;
 }
 for(size_t i=0;i<MESH_POINTS_144;i++) {
  out.mesh[i]=f32le144(bytes+layout.mesh_offset+i*4);
  // Finite is required. Never claim plausible float values prove physical measurement.
  if(!std::isfinite(out.mesh[i])) {
   out.result=Integrity144::BadMeshNumbers;return out;
  }
 }
 out.result=Integrity144::VerifiedImageMesh;
 return out;
}
// Extra independent comparison against a known, already-captured RAM mesh.
// Floating point raw representation is compared exactly, without epsilon.
inline bool same_mesh144(const uint8_t* eeprom, size_t len,const Layout144& layout,
                         const float (&expected)[16]) {
 const Verification144 r=verify_eeprom144(eeprom,len,layout);
 if(!r.verified())return false;
 for(size_t i=0;i<16;i++)if(std::memcmp(&r.mesh[i],&expected[i],4)!=0)return false;
 return true;
}
} // namespace sv04
