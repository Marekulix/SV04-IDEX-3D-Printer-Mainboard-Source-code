#include "idex_park_evidence.h"
#include <cassert>
#include <iostream>
#include <limits>
using namespace sv04;
static ParkObservation sample(){ ParkObservation o;o.t1_endstop_hit=o.t1_x_trusted=o.t1_is_inactive=o.planner_synchronized=o.steppers_energized=o.auto_park_mode=o.t0_active=true;o.measured_t1_x=o.configured_t1_home_x=362.0f;return o;}
static IDEXInputs ready(){IDEXInputs s;s.machine_idle=s.planner_empty_and_steppers_stopped=s.t0_selected=s.no_obstructions_confirmed=s.probe_selfcheck_passed=s.endstops_selfcheck_passed=s.bed_and_tools_safe=s.physical_clearance_confirmed=s.geometry_matches_oem=true;s.mode=CarriageMode::AutoPark;return s;}
int main(){int n=0;auto ok=[&](bool x){++n;assert(x);};
 ParkEvidence p;auto o=sample();ok(p.state()==ParkState::Unknown);ok(!p.still_valid(o));
 auto s=ready();ok(initial_g28_preflight(s)==GateReason::Ready);ok(!s.t1_parked_sensor_or_verified_homing);
 for(int i=0;i<10;i++){auto t=s;switch(i){case 0:t.machine_idle=false;break;case 1:t.planner_empty_and_steppers_stopped=false;break;case 2:t.mode=CarriageMode::Mirrored;break;case 3:t.t0_selected=false;break;case 4:t.no_obstructions_confirmed=false;break;case 5:t.probe_selfcheck_passed=false;break;case 6:t.endstops_selfcheck_passed=false;break;case 7:t.geometry_matches_oem=false;break;case 8:t.bed_and_tools_safe=false;break;case 9:t.physical_clearance_confirmed=false;break;}ok(initial_g28_preflight(t)!=GateReason::Ready);}
 for(int i=0;i<11;i++){auto t=o;switch(i){case 0:t.t1_endstop_hit=false;break;case 1:t.t1_x_trusted=false;break;case 2:t.t1_is_inactive=false;break;case 3:t.planner_synchronized=false;break;case 4:t.steppers_energized=false;break;case 5:t.auto_park_mode=false;break;case 6:t.t0_active=false;break;case 7:t.measured_t1_x=360;break;case 8:t.configured_t1_home_x=363;break;case 9:t.measured_t1_x=NAN;break;case 10:t.configured_t1_home_x=NAN;break;}ParkEvidence q;ok(!q.record_completed_t1_home(t));ok(q.state()!=ParkState::T1EndstopConfirmed);}
 ok(p.record_completed_t1_home(o));ok(p.still_valid(o));ok(p.state()==ParkState::T1EndstopConfirmed);
 for(int i=0;i<4;i++){ParkEvidence q;ok(q.record_completed_t1_home(o));switch(i){case 0:q.motion_or_tool_change();break;case 1:q.mode_changed();break;case 2:q.lost_position_trust();break;case 3:q.reboot();break;}ok(!q.still_valid(o));ok(q.state()==ParkState::Invalidated);}
 for(int i=0;i<8;i++){auto t=o;switch(i){case 0:t.t1_x_trusted=false;break;case 1:t.t1_is_inactive=false;break;case 2:t.planner_synchronized=false;break;case 3:t.steppers_energized=false;break;case 4:t.auto_park_mode=false;break;case 5:t.t0_active=false;break;case 6:t.measured_t1_x=350;break;case 7:t.configured_t1_home_x=350;break;}ParkEvidence q;ok(q.record_completed_t1_home(o));ok(!q.still_valid(t));}
 HomingResult h;h.command_completed=h.x_trusted=h.y_trusted=h.z_trusted=h.t0_remains_active=h.t1_still_parked=h.probe_retracted=h.no_faults=true;
 ParkEvidence q;ok(post_g28_safe(h,q,o));ok(q.state()==ParkState::T1EndstopConfirmed);
 h.z_trusted=false;ok(!post_g28_safe(h,q,o));ok(q.state()==ParkState::Invalidated);
 // dynamic M218 offset is allowed ONLY when endstop-referenced positions agree
 ParkEvidence custom;auto c=o;c.configured_t1_home_x=c.measured_t1_x=361.5f;ok(custom.record_completed_t1_home(c));
 // stale coordinates aren't an independent endstop event
 ParkEvidence stale;auto st=o;st.t1_endstop_hit=false;ok(!stale.record_completed_t1_home(st));
 std::cout<<"SV04 NEXT 138 evidence: "<<n<<" checks passed\n";
}
