#include "mesh_transaction.h"
#include <cassert>
#include <cmath>
#include <iostream>
using namespace sv04;
int main(){unsigned checks=0;
  for(unsigned fail_at=0;fail_at<=16;fail_at++) for(unsigned variant=0;variant<16;variant++){
    MeshImage image{};for(int x=0;x<4;x++)for(int y=0;y<4;y++)image.z[x][y]=float((x+1)*(y+1))*.01f;
    image.spacing[0]=23;image.spacing[1]=25;image.origin[0]=3;image.origin[1]=4;image.leveling_active=variant%2;
    MeshImage before=image;
    MeshTransaction tx;assert(tx.capture(image,true,true,true));++checks;
    for(unsigned i=0;i<fail_at;i++) {
      unsigned x=i/4,y=i%4;
      image.z[x][y]=float(i)*-0.5f;
    }
    if(variant&2)image.spacing[0]=42;
    if(variant&4)image.origin[1]=54;
    if(variant&8)image.leveling_active=!image.leveling_active;
    assert(tx.rollback(image,true,true));++checks;
    assert(tx.restored_exactly(image));++checks;
    assert(MeshTransaction::same_bytes(image,before));++checks;
  }
  std::cout<<"PASS "<<checks<<" matrix assertions across 272 distinct scenarios\n";
}
