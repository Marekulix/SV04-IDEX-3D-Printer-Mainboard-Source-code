#include "auto60_sequence140.h"
#include <cassert>
#include <cstring>
#include <iostream>
using namespace sv04;
static unsigned n=0;
static void check(bool v){assert(v);++n;}
static Guards safe_guards(){Guards g;g.idle=g.heaters_ok=g.axes_safe=g.tool_safe=g.probe_ready=true;return g;}
static MeshImage img(){MeshImage m{};for(int x=0;x<4;x++)for(int y=0;y<4;y++)m.z[x][y]=0.01f*(x+y);m.spacing[0]=m.spacing[1]=80;m.origin[0]=m.origin[1]=20;m.leveling_active=true;return m;}
static BedTelemetry temp(uint32_t ms, float t=60){BedTelemetry b;b.actual=t;b.target=60;b.sampled_ms=ms;b.sensor_ok=b.heater_ok=b.firmware_thermal_ok=true;return b;}
static IDEXInputs clearance(){IDEXInputs i;i.machine_idle=i.planner_empty_and_steppers_stopped=i.t0_selected=i.no_obstructions_confirmed=i.probe_selfcheck_passed=i.endstops_selfcheck_passed=i.bed_and_tools_safe=i.physical_clearance_confirmed=i.geometry_matches_oem=true;i.mode=CarriageMode::AutoPark;return i;}
static HomingResult home(){HomingResult h;h.command_completed=h.x_trusted=h.y_trusted=h.z_trusted=h.t0_remains_active=h.t1_still_parked=h.probe_retracted=h.no_faults=true;return h;}
static ParkObservation parkobs(){ParkObservation p;p.t1_endstop_hit=p.t1_x_trusted=p.t1_is_inactive=p.planner_synchronized=p.steppers_energized=p.auto_park_mode=p.t0_active=true;p.measured_t1_x=p.configured_t1_home_x=362;return p;}
static void advance_to_home(Sequence140& s,const MeshImage& m){check(s.begin(m,safe_guards(),true,0));check(!s.allow_home(clearance()));check(s.setpoint_accepted(true,10));for(uint32_t t=1000;t<=31000;t+=1000)check(s.observe_bed(temp(t),t));check(s.controller.phase()==Phase::Home);check(s.allow_home(clearance()));}
static void advance_to_probe(Sequence140& s,const MeshImage& m){advance_to_home(s,m);check(s.home_finished(home(),parkobs(),31010));check(s.controller.phase()==Phase::Probe);check(s.allow_g29(parkobs(),clearance()));check(s.g29_started(true,31020));}
int main(){
 // Complete happy path, no EEPROM writes and no direct motions.
 {Sequence140 s;auto m=img();advance_to_probe(s,m);
  check(!s.g29_finished(true,false,32000));check(s.restore_required());
  check(!s.rollback(m,false,true));check(s.rollback(m,true,true));check(!s.restore_required());
 }
 {Sequence140 s;auto m=img();advance_to_probe(s,m);
  for(unsigned y=0;y<4;y++)for(unsigned x=0;x<4;x++){
   float v=float(x)*0.1f+float(y)*0.01f;
   check(s.point(x,y,v));m.z[x][y]=v;
  }
  check(!s.point(0,0,0.1f));check(s.restore_required());check(s.rollback(m,true,true));
 }
 {Sequence140 s;auto m=img();advance_to_probe(s,m);
  for(unsigned y=0;y<4;y++)for(unsigned x=0;x<4;x++){
   float v=float(x)*0.1f+float(y)*0.01f;
   check(s.point(x,y,v));m.z[x][y]=v;
  }
  check(s.g29_finished(true,false,32000));check(s.validate(m,true,true,32001));
  check(s.controller.phase()==Phase::Persist);check(s.controller.pending()==Action::SaveEEPROM);
  // No automatic M500 is performed by the sequencer.
 }
 {Sequence140 s;auto m=img();advance_to_probe(s,m);
  check(!s.observe_bed(temp(32000,54),32000));check(s.restore_required());
  check(s.rollback(m,true,true));check(s.snapshot.restored_exactly(m));
 }
 {Sequence140 s;auto m=img();advance_to_home(s,m);auto bad=home();bad.z_trusted=false;
  check(!s.home_finished(bad,parkobs(),31010));check(s.restore_required());check(!s.begin(m,safe_guards(),true,33000));check(s.rollback(m,true,true));
 }
 {Sequence140 s;auto m=img();check(s.begin(m,safe_guards(),true,0));check(!s.begin(m,safe_guards(),true,10));
  check(!s.setpoint_accepted(false,10));check(s.restore_required());check(s.rollback(m,true,true));
 }
 std::cout<<"SV04 NEXT 140: "<<n<<" assertions passed\n";
}
