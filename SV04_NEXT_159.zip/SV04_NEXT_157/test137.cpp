#include "idex_homing_gate.h"
#include <cassert>
#include <iostream>
#include <limits>
using namespace sv04;
int main() {
  int checks=0;
  auto ok=[&](bool b){++checks; assert(b);};
  IDEXInputs g;
  ok(preflight(g)==GateReason::NotIdle);
  g.machine_idle=true;
  ok(preflight(g)==GateReason::MotionNotStopped);
  g.planner_empty_and_steppers_stopped=true;
  ok(preflight(g)==GateReason::WrongMode);
  g.mode=CarriageMode::AutoPark;
  ok(preflight(g)==GateReason::ToolNotT0);
  g.t0_selected=true;
  ok(preflight(g)==GateReason::ParkNotConfirmed);
  g.t1_parked_sensor_or_verified_homing=true;
  ok(preflight(g)==GateReason::Obstruction);
  g.no_obstructions_confirmed=true;
  ok(preflight(g)==GateReason::ProbeNotReady);
  g.probe_selfcheck_passed=true;
  ok(preflight(g)==GateReason::EndstopNotReady);
  g.endstops_selfcheck_passed=true;
  ok(preflight(g)==GateReason::GeometryMismatch);
  g.geometry_matches_oem=true;
  ok(preflight(g)==GateReason::UnsafeTemperatures);
  g.bed_and_tools_safe=true;
  ok(preflight(g)==GateReason::MissingPhysicalClearance);
  g.physical_clearance_confirmed=true;
  ok(preflight(g)==GateReason::Ready);
  for(auto mode:{CarriageMode::Unknown, CarriageMode::Duplication,CarriageMode::Mirrored,CarriageMode::FullControl}) {
    auto m=g; m.mode=mode; ok(preflight(m)==GateReason::WrongMode);
  }
  for(int i=0;i<11;++i){auto m=g;switch(i){case 0:m.machine_idle=false;break;case 1:m.planner_empty_and_steppers_stopped=false;break;case 2:m.mode=CarriageMode::Unknown;break;case 3:m.t0_selected=false;break;case 4:m.t1_parked_sensor_or_verified_homing=false;break;case 5:m.no_obstructions_confirmed=false;break;case 6:m.probe_selfcheck_passed=false;break;case 7:m.endstops_selfcheck_passed=false;break;case 8:m.geometry_matches_oem=false;break;case 9:m.bed_and_tools_safe=false;break;case 10:m.physical_clearance_confirmed=false;break;}ok(preflight(m)!=GateReason::Ready);}
  HomingResult h;
  ok(verify_homing(h)==GateReason::HomeFailed);
  h.command_completed=true;h.no_faults=true;
  ok(verify_homing(h)==GateReason::HomeNotConfirmed);
  h.x_trusted=h.y_trusted=h.z_trusted=h.t0_remains_active=h.t1_still_parked=h.probe_retracted=true;
  ok(verify_homing(h)==GateReason::Ready);
  for(int i=0;i<8;++i){auto t=h;switch(i){case 0:t.command_completed=false;break;case 1:t.no_faults=false;break;case 2:t.x_trusted=false;break;case 3:t.y_trusted=false;break;case 4:t.z_trusted=false;break;case 5:t.t0_remains_active=false;break;case 6:t.t1_still_parked=false;break;case 7:t.probe_retracted=false;break;}ok(verify_homing(t)!=GateReason::Ready);}
  ok(nominal_probe_xy(151,126));
  ok(nominal_probe_xy(25,0));
  ok(!nominal_probe_xy(24.99f,0));
  ok(!nominal_probe_xy(278,0));
  ok(!nominal_probe_xy(151,-0.1f));
  ok(!nominal_probe_xy(151,252.01f));
  ok(!nominal_probe_xy(std::numeric_limits<float>::quiet_NaN(),126));
  ok(!nominal_probe_xy(151,std::numeric_limits<float>::infinity()));
  ok(OemGeometry::X1_MIN==-62 && OemGeometry::X2_MAX==362);
  ok(OemGeometry::PROBE_OFFSET_Y==25 && OemGeometry::PROBE_MARGIN==25);
  std::cout<<"SV04 NEXT 137 IDEX gate: "<<checks<<" checks passed\n";
}
