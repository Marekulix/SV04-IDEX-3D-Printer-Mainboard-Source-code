#pragma once
// SV04 NEXT 150: read-only, host-side SD adapter contract. NOT FIRMWARE.
// No directory traversal, no card writes, no EEPROM writes, no automatic repair.
#include "sd_backup149.h"
#include <array>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace sv04 {
struct SdPort150 {
  virtual ~SdPort150() = default;
  // Caller must map these indices to fixed, private filenames, never user paths.
  // false means file missing OR I/O error. Either rejects that slot.
  virtual bool mounted() const = 0;
  virtual uint64_t mount_epoch() const = 0; // monotonic identity of current mount, not card serial
  virtual bool read_exact(unsigned file_id, size_t limit, std::vector<uint8_t>& out) = 0;
};

enum class SdStatus150:uint8_t {
  Unmounted, EpochUnknown, Changed, InvalidSize, ReadFailure,
  NoValidBackup, Ambiguous, ValidUntrustedMedia
};
struct SdReport150 {
  SdStatus150 status = SdStatus150::Unmounted;
  Selection149 selection;
  bool may_read_for_diagnostics=false;
  bool may_write_eeprom=false;
  bool may_restore_eeprom=false;
};
// Fail closed: expected identities are supplied by an independent trusted source.
// mount_epoch != actual card identity, so success is always explicitly untrusted.
// This is a *diagnostic* scan only. No path in this module writes to the card.
inline SdReport150 scan_sd150(SdPort150& port,uint32_t card_id,uint32_t device_id,size_t expected_bytes){
  SdReport150 result;
  if(!port.mounted()) return result;
  const uint64_t epoch=port.mount_epoch();
  if(!epoch){result.status=SdStatus150::EpochUnknown;return result;}
  if(!card_id||!device_id||!expected_bytes||expected_bytes>65536){result.status=SdStatus150::InvalidSize;return result;}
  const std::array<size_t,4> caps{{expected_bytes+24,20,expected_bytes+24,20}};
  // Each file is read twice. Failing either read invalidates the slot.
  // I/O failures in both slots are distinguished from a valid-but-empty card.
  Store149 store;
  bool any_io_failure=false;
  for(unsigned s=0;s<2;++s){
    std::vector<uint8_t> first_image, first_commit, second_image, second_commit;
    const unsigned image_file=s*2, commit_file=s*2+1;
    const bool a=port.read_exact(image_file,caps[image_file],first_image);
    if(!port.mounted()||port.mount_epoch()!=epoch){result.status=SdStatus150::Changed;return result;}
    const bool b=port.read_exact(commit_file,caps[commit_file],first_commit);
    if(!port.mounted()||port.mount_epoch()!=epoch){result.status=SdStatus150::Changed;return result;}
    const bool c=port.read_exact(image_file,caps[image_file],second_image);
    if(!port.mounted()||port.mount_epoch()!=epoch){result.status=SdStatus150::Changed;return result;}
    const bool d=port.read_exact(commit_file,caps[commit_file],second_commit);
    if(!port.mounted()||port.mount_epoch()!=epoch){result.status=SdStatus150::Changed;return result;}
    if(!(a&&b&&c&&d)){any_io_failure=true;continue;}
    if(first_image!=second_image||first_commit!=second_commit){result.status=SdStatus150::Changed;return result;}
    store.slots[s].image=first_image;
    store.slots[s].commit=first_commit;
  }
  result.selection=select149(store,card_id,device_id,expected_bytes);
  if(result.selection.decision==Decision149::AmbiguousSameGeneration)result.status=SdStatus150::Ambiguous;
  else if(result.selection.decision==Decision149::UniqueBackup){
    result.status=SdStatus150::ValidUntrustedMedia;
    result.may_read_for_diagnostics=true;
  }
  else result.status=any_io_failure?SdStatus150::ReadFailure:SdStatus150::NoValidBackup;
  return result;
}
static_assert(!sd_powerloss_durability_proven149(),"Hardware durability must not be assumed");
}
