# SV04 NEXT 152 – SD/Power-Loss-Recovery Koexistenz (HOST-PROTOTYP)
Stand: 2026-11-06. NICHT INSTALLIEREN. Kein Marlin-Patch, kein Firmware-Build.

## Implementierung
- `sd_coexist152.h`: konservativer Diagnose-Scheduler mit prioritätsbasierter Zurückstellung bei SD-Druck, pausiertem SD-Druck, offenen Dateien, Upload, Logging, PLR und Medienwechsel.
- `test152.cpp`: 2640 Assertions inklusive 500 Zustandskombinationen, Ablaufzeitgrenzen und 14 ereignisgesteuerten Abbrüchen.
- Exklusive Leseoperation nur über `SdOwnership151`, niemals SD-Schreiben, `M500` oder Flash-Recovery.
- Unveränderte Sicherheitswarnung aus 151: `SdOwnership151` ist ein simuliertes Schnittstellenversprechen. Solange alle SD-Nutzer nicht dieselbe atomare Zugriffssperre verwenden, ist die Realintegration **gesperrt**.

## Originalcode geprüft
Sovol3d/SV04-IDEX-3D-Printer-Mainboard-Source-code, Commit `1867fcba75354a5c65e0631d6972dd19f1bd6cbe`:
- `Marlin/src/sd/cardreader.h`: `card.isMounted()`, `isPrinting()`, `isPaused()`, `isFileOpen()`, `getroot()` und Recovery-Datei-APIs.
- `Marlin/src/sd/cardreader.cpp`: `openFileRead`, `openFileWrite`, `closefile`, `openJobRecoveryFile` bedienen SD-Datenpfade. Auf diese Funktionen muss spätere gegenseitige Sperre Rücksicht nehmen.
- PLR und Media-Management können Änderungen auslösen, die auch eine laufende Diagnose ungültig machen.

## Wahrheit über den Entwicklungsstand
Der `poll()`-Aufruf ist auf dem Host synchron und führt `scan_exclusive151()` in einem Schritt aus. Das bedeutet: Ein Ereignis kann das Modell **zwischen** zwei Poll-Aufrufen abbrechen, aber keine bereits laufende synchrone Leseoperation unterbrechen. Der vorliegende Code beweist keine Echtzeitfähigkeit, keine atomare Marlin-SD-Sperre und keine Stromausfallsicherheit der SD-Karte.

Es gibt noch keine vertrauenswürdige Hardwareidentität der SD-Karte, keinen echten SD-Treiberadapter, keine SD-Transaktionsgarantie, keinen vollständig validierten EEPROM-Restore und keinen stromausfallsicheren Flash-Speicherpfad.

## Bedingungen für eine spätere Integration
1. Gemeinsame Zugriffssperre in allen SD-Pfaden, **einschließlich** Power-Loss-Recovery, SD-Druck, Verzeichnisliste, Uploads und Medienwechsel.
2. Wirklich kooperativer, begrenzter Leseschritt statt eines längeren blockierenden Dateiscans.
3. Vor und nach jedem Leseblock Mount-Epoche, Dateistatus und PLR-Priorität prüfen. Auf Medienwechsel sofort verwerfen.
4. Ein Diagnoseergebnis darf nur die Anzeige beeinflussen, **nie** direkt einen EEPROM-Schreib-/Restore-Vorgang freigeben.
5. Vor Hardwareeinsatz vollständiger passender Firmware-Build, Code-Audit, Tests und Drucker-Hardwarefreigabe.

## Lokal getestet
`g++ -std=c++17 -Wall -Wextra -Werror -fsanitize=address,undefined test152.cpp -o test152 && ./test152`
Ergebnis: `test152 PASS: 2640 assertions`. Alle 22 C++-Tests (einschließlich 152) und zwei Python-Tests aus dem Paket bestanden.

## Nächster sinnvoller Schritt (153)
Eine **schrittweise** rein lesende Zustandsmaschine für genau 64-Byte-Blöcke implementieren; Karten-/PLR-Zustand und gemeinsame Sperre pro Block prüfen. Noch keine echten Marlin-Schreibzugriffe, keine M500-Freigabe.
