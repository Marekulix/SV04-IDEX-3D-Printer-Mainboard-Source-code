#include "auto60_idex_bridge.h"
#include <cassert>
#include <iostream>
using namespace sv04;
static IDEXInputs safe(){IDEXInputs s;s.machine_idle=s.planner_empty_and_steppers_stopped=s.t0_selected=s.no_obstructions_confirmed=s.probe_selfcheck_passed=s.endstops_selfcheck_passed=s.bed_and_tools_safe=s.physical_clearance_confirmed=s.geometry_matches_oem=true;s.mode=CarriageMode::AutoPark;return s;}
static Guards guards(){Guards g;g.idle=g.heaters_ok=g.axes_safe=g.tool_safe=g.probe_ready=g.snapshot_valid=true;return g;}
static void goto_home(Controller &c){assert(c.start(guards(),1));c.ack(Action::SetBed60,true,2);c.temperature(60.0f,1000);c.temperature(60.0f,31001);assert(c.phase()==Phase::Home);}
int main(){unsigned n=0;auto ok=[&](bool t){n++;assert(t);};
 Controller c;ParkEvidence e;auto s=safe();ok(!permit_initial_home(c,s).allowed);goto_home(c);
 ok(permit_initial_home(c,s).allowed);ok(!permit_home(c,s).allowed);
 auto unsafe=s;unsafe.physical_clearance_confirmed=false;ok(!permit_initial_home(c,unsafe).allowed);
 HomingResult h;h.command_completed=h.x_trusted=h.y_trusted=h.z_trusted=h.t0_remains_active=h.t1_still_parked=h.probe_retracted=h.no_faults=true;
 ParkObservation o;o.t1_endstop_hit=o.t1_x_trusted=o.t1_is_inactive=o.planner_synchronized=o.steppers_energized=o.auto_park_mode=o.t0_active=true;o.measured_t1_x=o.configured_t1_home_x=362;
 ok(accept_initial_home_completion(c,e,h,o,32000));ok(c.phase()==Phase::Probe);ok(e.state()==ParkState::T1EndstopConfirmed);
 ok(!permit_initial_home(c,s).allowed);ok(!accept_initial_home_completion(c,e,h,o,33000));
 e.motion_or_tool_change();ok(!e.still_valid(o));
 Controller d;ParkEvidence p;goto_home(d);auto bad=o;bad.t1_endstop_hit=false;ok(!accept_initial_home_completion(d,p,h,bad,32000));ok(d.phase()==Phase::Fault);ok(d.needs_restore());
 Controller f;ParkEvidence q;goto_home(f);auto hf=h;hf.z_trusted=false;ok(!accept_initial_home_completion(f,q,hf,o,32000));ok(f.phase()==Phase::Fault);ok(q.state()!=ParkState::T1EndstopConfirmed);
 std::cout<<"SV04 NEXT 138 controller bridge: "<<n<<" checks passed\n";
}
