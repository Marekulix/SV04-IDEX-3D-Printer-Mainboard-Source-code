#include "eeprom_integrity144.h"
#include "eeprom_flash_adapter143.h"
#include <vector>
#include <cstring>
#include <cstdio>
#include <cstdlib>
using namespace sv04;
static unsigned nchecks=0;
#define CHECK(c) do{++nchecks;if(!(c)){fprintf(stderr,"FAIL line %d\n",__LINE__);std::abort();}}while(0)
struct Flash144 : FlashRead143 {
 std::vector<uint8_t> bytes;
 bool certified=true;bool opened=false;int writes=0;
 explicit Flash144(std::vector<uint8_t> b):bytes(b){}
 bool certified_flash_read_without_write() const override{return certified;}
 size_t capacity() const override{return bytes.size();}
 bool begin_read() override {opened=true;return true;}
 bool read_at(size_t o,uint8_t*p,size_t n) override {
  if(!opened||o>bytes.size()||n>bytes.size()-o)return false;
  std::memcpy(p,bytes.data()+o,n);return true;
 }
 bool end_read()override{opened=false;return true;}
};
struct Archive144 : SeparateStorage143 {
 std::vector<uint8_t> blob;
 bool independent_durable_and_readable() const override{return true;}
 bool begin_archive(size_t n) override{blob.assign(n,0);return true;}
 bool write_block(size_t o,const uint8_t*p,size_t n) override{if(o>blob.size()||n>blob.size()-o)return false;std::memcpy(blob.data()+o,p,n);return true;}
 bool finish_archive() override{return true;}
 bool begin_verify() override{return true;}
 bool read_archive(size_t o,uint8_t*p,size_t n)override{if(o>blob.size()||n>blob.size()-o)return false;std::memcpy(p,blob.data()+o,n);return true;}
 bool end_verify() override{return true;}
};
static void f32write(uint8_t* p,float v){uint32_t bits;std::memcpy(&bits,&v,4);for(int i=0;i<4;i++)p[i]=uint8_t(bits>>(8*i));}
int main(){
 const char* v="123456789";
 CHECK(crc16_marlin144(reinterpret_cast<const uint8_t*>(v),9)==0x31C3u);
 Layout144 layout;layout.total_eeprom_capacity=4096;layout.settings_data_size=800;
 layout.grid_x_offset=300;layout.grid_y_offset=301;layout.mesh_spacing_offset=302;layout.mesh_origin_offset=310;layout.mesh_offset=318;layout.xy_pos_bytes=8;
 layout.layout_compiled_and_verified=true;layout.flash_backend_certified=true;
 std::vector<uint8_t> b(4096,0xFF);b[100]='V';b[101]='8';b[102]='5';b[103]=0;
 b[300]=4;b[301]=4;
 float expected[16];for(int i=0;i<16;i++){expected[i]=float(i)*0.125f;f32write(b.data()+318+4*i,expected[i]);}
 uint16_t crc=crc16_marlin144(b.data()+106,794);b[104]=uint8_t(crc);b[105]=uint8_t(crc>>8);
 Flash144 flash(b);Archive144 storage;FullFlashBackup143 backup;
 CHECK(backup.capture(flash,storage,true,true,true));CHECK(backup.verified());CHECK(flash.writes==0);
 CHECK(verify_eeprom144(storage.blob.data(),storage.blob.size(),layout).verified());
 CHECK(same_mesh144(storage.blob.data(),storage.blob.size(),layout,expected));
 storage.blob[401]^=1;CHECK(verify_eeprom144(storage.blob.data(),storage.blob.size(),layout).result==Integrity144::BadCRC);
 CHECK(verify_eeprom144(flash.bytes.data(),flash.bytes.size(),layout).verified());
 // Never transform the generic flash backup into a promise of persistence without target evidence.
 layout.flash_backend_certified=false;
 CHECK(!verify_eeprom144(storage.blob.data(),storage.blob.size(),layout).verified());
 printf("SV04 NEXT 144 backup-CRC bridge: %u assertions PASS (mock storage).\n",nchecks);
}
