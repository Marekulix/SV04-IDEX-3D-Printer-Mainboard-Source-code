#pragma once
#include "auto60_controller.h"
#include "bed_thermal_guard.h"
namespace sv04 {
// Call this only with telemetry obtained directly from the current Marlin
// thermal manager and its fault reporting. No synthetic 'heater_ok' allowed.
struct ThermalBridge {
  BedThermalGuard thermal;
  bool started=false;
  void after_setpoint_ack(const Controller& c, uint32_t ms) {
    if (c.phase()==Phase::Heat && c.pending()==Action::None) {
      thermal.arm(ms); started=true;
    }
  }
  // Returns false on unsafe conditions, and latches Controller::Fault.
  bool observe(Controller& c, const BedTelemetry& t, uint32_t now_ms) {
    if (!started || (c.phase()!=Phase::Heat && c.phase()!=Phase::Stabilize)) return false;
    const auto r=thermal.update(t,now_ms);
    if (thermal.failed()) { c.abort(); return false; }
    // The controller holds temperature independently for >= 30 seconds;
    // deliver only telemetry that passed this guard.
    c.temperature(t.actual,now_ms);
    if (c.phase()==Phase::Home) return thermal.ready();
    return r==ThermalReason::Ready || r==ThermalReason::Stabilizing || r==ThermalReason::Heating;
  }
};
} // namespace sv04
