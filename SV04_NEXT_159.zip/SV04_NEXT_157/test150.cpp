#include "sd_readonly150.h"
#include <cassert>
#include <cstdio>
#include <map>
#include <utility>
using namespace sv04;
unsigned checks=0;
#define CHECK(x) do { if(!(x)){std::fprintf(stderr,"check failed at %d: %s\n",__LINE__,#x); return 1;} ++checks; }while(0)
struct Fake: SdPort150 {
 bool online=true;uint64_t epoch=9;unsigned calls=0;unsigned alter_at=0;unsigned fail_at=0;
 std::map<unsigned,std::vector<uint8_t>> files;
 bool mounted()const override{return online;}
 uint64_t mount_epoch()const override{return epoch;}
 bool read_exact(unsigned id,size_t limit,std::vector<uint8_t>& out)override{
   ++calls;
   if(alter_at==calls)++epoch;
   if(fail_at==calls)return false;
   auto it=files.find(id);if(it==files.end()||it->second.size()>limit)return false;
   out=it->second;return true;
 }
};
int main(){
  const uint32_t card=87,device=33;Backup149 b{card,device,1,std::vector<uint8_t>(256,0x91)};
  Fake clean;clean.files[0]=encode149(b);clean.files[1]=commit149(b);
  auto r=scan_sd150(clean,card,device,256);
  CHECK(r.status==SdStatus150::ValidUntrustedMedia);CHECK(r.selection.slot==0);
  CHECK(r.may_read_for_diagnostics);CHECK(!r.may_write_eeprom);CHECK(!r.may_restore_eeprom);
  CHECK(clean.calls==8);
  for(unsigned n=1;n<=8;++n){auto f=clean;f.calls=0;f.alter_at=n;
    auto v=scan_sd150(f,card,device,256);CHECK(v.status==SdStatus150::Changed);
  }
  for(unsigned n=1;n<=8;++n){auto f=clean;f.calls=0;f.fail_at=n;
    auto v=scan_sd150(f,card,device,256);
    CHECK(v.status==SdStatus150::ReadFailure || v.status==SdStatus150::ValidUntrustedMedia);
    CHECK(!v.may_write_eeprom);
  }
  for(size_t idx=0;idx<clean.files[0].size();++idx){
    auto f=clean;f.calls=0;f.files[0][idx]^=0x80;
    CHECK(scan_sd150(f,card,device,256).status==SdStatus150::ReadFailure ||
          scan_sd150(f,card,device,256).status==SdStatus150::NoValidBackup);
  }
  {auto f=clean;f.online=false;CHECK(scan_sd150(f,card,device,256).status==SdStatus150::Unmounted);}
  {auto f=clean;f.epoch=0;CHECK(scan_sd150(f,card,device,256).status==SdStatus150::EpochUnknown);}
  CHECK(scan_sd150(clean,0,device,256).status==SdStatus150::InvalidSize);
  CHECK(scan_sd150(clean,card,device,0).status==SdStatus150::InvalidSize);
  CHECK(scan_sd150(clean,card,device,65537).status==SdStatus150::InvalidSize);
  {auto f=clean;Backup149 c=b;c.generation=2;c.data[3]=2;f.files[2]=encode149(c);f.files[3]=commit149(c);
    auto v=scan_sd150(f,card,device,256);CHECK(v.status==SdStatus150::ValidUntrustedMedia);CHECK(v.selection.slot==1);
    f.files[2]=f.files[0];f.files[3]=f.files[1];v=scan_sd150(f,card,device,256);CHECK(v.status==SdStatus150::Ambiguous);
  }
  std::printf("test150 PASS: %u assertions\n",checks);
}
