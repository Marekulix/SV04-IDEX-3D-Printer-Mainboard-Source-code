#pragma once
#include <cmath>
#include <cstdint>

// SV04 NEXT 139. Host-testable thermal interlock only: NO heater commands,
// NO movement commands, NO attempt to bypass Marlin thermal protections.
namespace sv04 {
enum class ThermalReason : uint8_t {
  Ready, WaitingForSetpoint, Heating, Stabilizing,
  BadReading, BadTarget, Stale, FirmwareFault, HeatingTimeout,
  SensorJump, NotArmed
};
struct BedTelemetry {
  float actual=0, target=0;
  uint32_t sampled_ms=0;
  bool sensor_ok=false, heater_ok=false, firmware_thermal_ok=false;
};
class BedThermalGuard {
public:
  static constexpr float kTarget = 60.0f;
  static constexpr float kTolerance = 1.0f;
  static constexpr uint32_t kHoldMs = 30000UL;
  static constexpr uint32_t kMaxSampleAgeMs = 2000UL;
  static constexpr uint32_t kMaxSampleGapMs = 5000UL;
  static constexpr uint32_t kTimeoutMs = 12UL*60UL*1000UL;

  void arm(uint32_t ms) {
    armed_=true; failed_=false; first_ms_=ms;
    stable_=false; have_sample_=false; reason_=ThermalReason::WaitingForSetpoint;
  }
  void disarm() { armed_=false; stable_=false; }
  bool ready() const { return armed_ && !failed_ && stable_ && reason_==ThermalReason::Ready; }
  bool failed() const { return failed_; }
  ThermalReason reason() const { return reason_; }

  ThermalReason update(const BedTelemetry &t, uint32_t now_ms) {
    if (!armed_) return reason_=ThermalReason::NotArmed;
    if (failed_) return reason_;
    if ((uint32_t)(now_ms-first_ms_) > kTimeoutMs) return latch(ThermalReason::HeatingTimeout);
    if ((int32_t)(now_ms-t.sampled_ms) < 0 ||
        (uint32_t)(now_ms-t.sampled_ms) > kMaxSampleAgeMs)
      return latch(ThermalReason::Stale);
    if (!t.sensor_ok || !t.heater_ok || !t.firmware_thermal_ok)
      return latch(ThermalReason::FirmwareFault);
    if (!std::isfinite(t.actual) || t.actual < 0.0f || t.actual > 125.0f)
      return latch(ThermalReason::BadReading);
    if (!std::isfinite(t.target) || std::fabs(t.target-kTarget) > 0.25f)
      return latch(ThermalReason::BadTarget);
    if (have_sample_) {
      const uint32_t dt=(uint32_t)(t.sampled_ms-last_sample_ms_);
      if (dt==0 || dt>kMaxSampleGapMs) return latch(ThermalReason::Stale);
      // Conservative plausibility check; actual protection remains with Marlin.
      if (std::fabs(t.actual-last_actual_) > 12.0f)
        return latch(ThermalReason::SensorJump);
    }
    have_sample_=true;
    last_sample_ms_=t.sampled_ms;
    last_actual_=t.actual;
    if (std::fabs(t.actual-kTarget)>kTolerance) {
      stable_=false;
      holding_=false;
      return reason_=ThermalReason::Heating;
    }
    if (!holding_) {holding_=true; hold_since_ms_=t.sampled_ms;}
    if ((uint32_t)(t.sampled_ms-hold_since_ms_) < kHoldMs) {
      stable_=false;
      return reason_=ThermalReason::Stabilizing;
    }
    stable_=true;
    return reason_=ThermalReason::Ready;
  }
private:
  ThermalReason latch(ThermalReason r) {failed_=true;stable_=false;return reason_=r;}
  bool armed_=false, failed_=false, stable_=false, holding_=false, have_sample_=false;
  uint32_t first_ms_=0, hold_since_ms_=0, last_sample_ms_=0;
  float last_actual_=0;
  ThermalReason reason_=ThermalReason::NotArmed;
};
} // namespace sv04
