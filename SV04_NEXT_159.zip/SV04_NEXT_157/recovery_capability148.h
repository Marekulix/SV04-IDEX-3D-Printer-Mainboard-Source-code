#pragma once
// SV04 NEXT 148. Host-only recovery preflight. NEVER writes EEPROM or SD.
#include <cstdint>

namespace sv04 {
enum class Backend148 : uint8_t { Unknown, STM32F1_Flash, SD_EmulatedEEPROM, Other };
enum class BackupMedium148 : uint8_t { None, SameFlash, RemovableSD, ExternalHost };
enum class JournalPhase148 : uint8_t { Unknown, Empty, BackupVerified, WriteIntent, WriteReported, Verified, Quarantine };
enum class RecoveryDecision148 : uint8_t {
  DenyUnknownBackend, DenyUnsupportedBackend, DenyNoIndependentMedium,
  DenyNoDurabilityProof, DenyNoVerifiedBackup, DenyBackupMismatch,
  DenyUntrustedEEPROM, DenyAmbiguousJournal, NoActionNecessary,
  ManualServiceOnly
};
struct RecoveryEvidence148 {
  Backend148 backend=Backend148::Unknown;
  BackupMedium148 backup_medium=BackupMedium148::None;
  JournalPhase148 phase=JournalPhase148::Unknown;
  bool printer_idle=false;
  bool motors_stopped=false;
  bool heaters_safe=false;
  bool sd_present_and_identity_checked=false;
  bool backup_complete=false;
  bool backup_readback_verified=false;
  bool backup_version_crc_valid=false;
  bool backup_matches_prewrite_snapshot=false;
  bool journal_slots_independently_durable=false;
  bool external_backup_durable=false;
  bool eeprom_current_version_crc_valid=false;
  bool recorded_previous_eeprom_version_crc_valid=false;
  bool manual_service_authorized=false;
};
inline bool independent_medium148(const RecoveryEvidence148 &e) {
  if(e.backup_medium==BackupMedium148::ExternalHost) return true;
  if(e.backup_medium==BackupMedium148::RemovableSD) return e.sd_present_and_identity_checked;
  return false;
}
inline RecoveryDecision148 recovery_decide148(const RecoveryEvidence148 &e) {
  if(e.backend==Backend148::Unknown) return RecoveryDecision148::DenyUnknownBackend;
  if(e.backend!=Backend148::STM32F1_Flash) return RecoveryDecision148::DenyUnsupportedBackend;
  if(!independent_medium148(e)) return RecoveryDecision148::DenyNoIndependentMedium;
  if(!e.journal_slots_independently_durable || !e.external_backup_durable)
    return RecoveryDecision148::DenyNoDurabilityProof;
  if(!e.backup_complete || !e.backup_readback_verified || !e.backup_version_crc_valid ||
     !e.recorded_previous_eeprom_version_crc_valid) return RecoveryDecision148::DenyNoVerifiedBackup;
  if(!e.backup_matches_prewrite_snapshot) return RecoveryDecision148::DenyBackupMismatch;
  if(e.phase==JournalPhase148::Unknown || e.phase==JournalPhase148::Quarantine ||
     e.phase==JournalPhase148::Empty || e.phase==JournalPhase148::BackupVerified)
    return RecoveryDecision148::DenyAmbiguousJournal;
  if(e.phase==JournalPhase148::Verified && e.eeprom_current_version_crc_valid)
    return RecoveryDecision148::NoActionNecessary;
  // After WriteIntent or WriteReported or inconsistent Verified state: require
  // explicit service review, physical inspection, isolated backups.
  // Never silently reflash. A valid CRC for a NEW EEPROM does not prove that
  // the expected target mesh was saved.
  if(!e.printer_idle || !e.motors_stopped || !e.heaters_safe ||
     !e.manual_service_authorized) return RecoveryDecision148::DenyUntrustedEEPROM;
  return RecoveryDecision148::ManualServiceOnly;
}
// No automatic restore is supported at this development stage.
inline constexpr bool automatic_restore_allowed148() { return false; }
inline constexpr bool automatic_m500_allowed148() { return false; }
}
