#pragma once
#include <array>
#include <cstdint>
#include <cstring>

// Host-side model, NOT Marlin hardware integration.
// 4x4 heights are stored x-major, exactly as Marlin z_values[x][y].
namespace sv04 {
struct MeshImage {
  float z[4][4];
  float spacing[2];
  float origin[2];
  bool leveling_active;
};

// Copy byte-for-byte, including NAN payloads and -0.0: restoring a prior
// uninitialized mesh must not silently replace it with a fabricated valid one.
// Caller must lock out ALL other mesh writers until transaction completes.
class MeshTransaction {
 public:
  enum class State : uint8_t { Empty, Protected, Restored, Committed, RestoreFailure };
  State state() const { return state_; }
  bool protected_mesh() const { return state_ == State::Protected; }
  bool capture(const MeshImage &image, bool idle, bool geometry_4x4, bool no_other_mesh_operation) {
    if (state_ == State::Protected || state_ == State::RestoreFailure || !idle || !geometry_4x4 || !no_other_mesh_operation)
      return false;
    std::memcpy(&saved_, &image, sizeof(MeshImage));
    state_ = State::Protected;
    return true;
  }
  // A caller-provided barrier must ensure G29 has STOPPED before rollback.
  // The helper cannot itself stop a moving probe or restore physical positions.
  bool rollback(MeshImage &live, bool motion_stopped, bool writers_locked) {
    if (state_ != State::Protected || !motion_stopped || !writers_locked) return false;
    std::memcpy(&live, &saved_, sizeof(MeshImage));
    const bool same = same_bytes(live, saved_);
    state_ = same ? State::Restored : State::RestoreFailure;
    return same;
  }
  // Verify that the whole image is unchanged from the snapshot.
  bool restored_exactly(const MeshImage &live) const {
    return state_ == State::Restored && same_bytes(live, saved_);
  }
  // Commit only AFTER the separate 16-point, persistence and EEPROM readback
  // checks have ALL succeeded. Never commit on a failed M500/M501 verification.
  bool commit(bool mesh_validated, bool save_ack, bool eeprom_readback_ok) {
    if (state_ != State::Protected || !mesh_validated || !save_ack || !eeprom_readback_ok) return false;
    state_ = State::Committed;
    return true;
  }
  // Never expose the saved image if capture has not happened.
  bool has_snapshot() const { return state_ != State::Empty; }
  static bool same_bytes(const MeshImage &a, const MeshImage &b) {
    return std::memcmp(&a.z[0][0], &b.z[0][0], sizeof(a.z)) == 0 &&
           std::memcmp(a.spacing, b.spacing, sizeof(a.spacing)) == 0 &&
           std::memcmp(a.origin, b.origin, sizeof(a.origin)) == 0 &&
           a.leveling_active == b.leveling_active;
  }
 private:
  MeshImage saved_{};
  State state_ = State::Empty;
};
}
