#include "eeprom_layout145.h"
#include <cassert>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <cstring>
using namespace sv04;
static unsigned checks=0;
#define CHECK(x) do {++checks; if(!(x)){std::fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x);std::abort();}}while(0)
static LayoutEvidence145 good(){LayoutEvidence145 e; e.magic=LAYOUT_MAGIC_145;e.capacity=4096;e.settings_size=800;e.grid_x=300;e.grid_y=301;e.spacing=302;e.origin=310;e.mesh=318;e.xy_bytes=8;e.mesh_bytes=64;e.settings_header_offset=100;e.source_build_generated=true;e.flash_driver_verified=true;e.version[0]='V';e.version[1]='8';e.version[2]='5';e.version[3]=0;e.firmware_fingerprint=fingerprint145(e);return e;}
static void crc(std::vector<uint8_t>& a,const LayoutEvidence145& e){auto v=crc16_marlin144(a.data()+106,e.settings_size-6);a[104]=uint8_t(v);a[105]=uint8_t(v>>8);}
int main(){auto e=good(); Layout144 l;CHECK(validate_layout145(e,&l));CHECK(l.mesh_offset==318);CHECK(l.settings_data_size==800);
 std::vector<uint8_t> data(e.capacity,0);data[100]='V';data[101]='8';data[102]='5';data[103]=0;data[300]=4;data[301]=4; for(int i=0;i<16;i++){float v=i*0.125f;std::memcpy(data.data()+318+4*i,&v,4);}crc(data,e);CHECK(verify_with_layout145(data.data(),data.size(),e).verified());
 for(int f=0;f<18;f++){auto x=e;switch(f){case 0:x.magic++;break;case 1:x.capacity=100;break;case 2:x.settings_size=5000;break;case 3:x.grid_x=299;break;case 4:x.grid_y=305;break;case 5:x.spacing=306;break;case 6:x.origin=314;break;case 7:x.mesh=320;break;case 8:x.mesh_bytes=60;break;case 9:x.xy_bytes=4;break;case 10:x.settings_header_offset=99;break;case 11:x.version[2]='4';break;case 12:x.firmware_fingerprint++;break;case 13:x.source_build_generated=false;break;case 14:x.flash_driver_verified=false;break;case 15:x.mesh=UINT32_MAX;break;case 16:x.capacity=64;break;case 17:x.settings_size=80;break;}if(f!=12)x.firmware_fingerprint=fingerprint145(x);CHECK(!validate_layout145(x));CHECK(!verify_with_layout145(data.data(),data.size(),x).verified());}
 for(int k=0;k<64;k++){auto x=e;x.mesh+=k+1;x.firmware_fingerprint=fingerprint145(x);CHECK(!validate_layout145(x));}
 for(int k=0;k<64;k++){auto d=data;d[318+k]^=0x10;CHECK(!verify_with_layout145(d.data(),d.size(),e).verified());}
 CHECK(!verify_with_layout145(data.data(),data.size()-1,e).verified());
 std::printf("SV04 NEXT 145: %u checks PASS; build-generated offsets NOT YET available.\n",checks);
}
