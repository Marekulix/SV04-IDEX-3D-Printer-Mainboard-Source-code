# SV04 NEXT 144 – Punkt 3 – EEPROM-Integrität, NICHT INSTALLIEREN

**Ausgangspunkt:** 143. **GitHub nicht benutzt, kein STM32-Build, keine Hardware-/Flash-Schreibzugriffe.**

## Neu
- `eeprom_integrity144.h`: schreibgeschützter Host-Referenzprüfer für die in Sovols Original-Marlin `settings.cpp` und `crc16.cpp` dokumentierte V85-EEPROM-Struktur.
- Versionskennung `V85\0` ab EEPROM-Offset 100, danach CRC16 (little-endian) über die folgenden Nutzdaten.
- CRC-16/CCITT, Polynom 0x1021, Initialwert 0. Bekannter Testvektor `123456789` => 0x31C3.
- Feldpositionen für bilineare Rastermaße, Mesh, Grid-Abstand und Startposition **nur** aus dem kompilierten `SettingsData`-Layout der passenden Firmware zulässig. Hier werden in Tests ausdrücklich synthetische Offsets verwendet; **nicht** die Geräte-Offsets.
- Kontrolle von V85, CRC, 4x4-Raster, 16 endlichen float32-Werten, Grenzen und exaktem Mesh-Vergleich mit bereits vorhandenen RAM-Werten.
- `test144_backup_bridge.cpp`: Verknüpfung mit dem schreibgeschützten Backup-Modul 143.

## Beleg im Sovol-Original
- `Marlin/src/module/settings.cpp`: `EEPROM_VERSION "V85"`, `EEPROM_OFFSET 100`, `SettingsDataStruct { char version[4]; uint16_t crc; ... }`, `EEPROM_WRITE(z_values)` und `EEPROM_READ(z_values)`, Dimensionsprüfung, `working_crc`.
- `Marlin/src/libs/crc16.cpp`: CRC16 mit Polynom 0x1021.
- `Marlin/src/HAL/shared/eeprom_api.h`: `PersistentStore`-API, `read_data()` liefert **true bei Lesefehler**.
- Festgelegter Quellstand: `1867fcba75354a5c65e0631d6972dd19f1bd6cbe`.

## Tests
- 817 gezielte Assertions in `test144.cpp` mit ASan/UBSan (ohne Fehler).
- 9 Integrationsassertions in `test144_backup_bridge.cpp` mit ASan/UBSan.
- Regression: 954 (141), 4171 (142), 4075 (143) sowie API-Vertragstest (143), ältere Tests 135–140 erfolgreich.

## Grenzen: fail closed
1. **Kein** realer EEPROM-Inhalt und **keine** echte `SettingsData`-Offsetliste vorhanden. Ohne unabhängig bestätigtes Firmwarelayout/aktives Flash-Backend verweigert der Prüfer seine Freigabe.
2. Ein gültiger CRC16 ist ein Integritätsnachweis für das gespeicherte Abbild, aber keine Authentizitäts- oder G29-Erfolgsgarantie.
3. Eine externe, dauerhafte Backup-Speicherung wurde nicht auf dem Drucker nachgewiesen.
4. `M500` bleibt gesperrt; selbst bei erfolgreicher Sicherung ist Flash-Schreiben nicht atomar. Ein Stromausfall kann Einstellungen beschädigen.
5. Abschließender Test erfordert korrekten Marlin-Build und Hardwareprüfung; aktuelle Kandidaten **NICHT FLASHEN**.

## Nächster konkreter Schritt 145
Firmware-layoutgenaue `offsetof(SettingsData, ...)`-Ausgabe im aktiven Build und Vergleich der tatsächlichen Marlin-EEPROM-CRC-Semantik mit dem unabhängigen Prüfer. Erst danach darf der read-only Adapter an echte Daten angebunden werden.
