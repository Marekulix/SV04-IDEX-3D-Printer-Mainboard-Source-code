#pragma once
// SV04 NEXT 153. HOST-ONLY cooperative, read-only SD backup diagnostic.
// At most one <=64-byte payload read per poll. No physical SD or Marlin integration.
// Each poll opens/seeks/reads/closes a file inside an exclusive lease, then releases it.
// Real implementation must guarantee EVERY SD user honors the SAME lock.
#include "sd_exclusive151.h"
#include <array>
#include <vector>
#include <cstddef>
#include <cstdint>
namespace sv04 {
struct SdSlicePort153 {
  virtual ~SdSlicePort153() = default;
  virtual bool mounted() const = 0;
  virtual uint64_t mount_epoch() const = 0;
  // Must open/read at `offset`/close under caller's lease, without modifying card.
  // A successful read sets total_size to exact file length and returns exactly
  // min(64, total_size-offset) bytes (never more than limit).
  virtual bool read_slice(unsigned file_id,size_t offset,size_t limit,
                          std::vector<uint8_t>& out,size_t& total_size)=0;
};
enum class SdStep153:uint8_t {Idle, Running, Deferred, ValidUntrustedMedia, NoValidBackup, Ambiguous, Cancelled, Expired};
class SdIncremental153 {
  SdStep153 state_=SdStep153::Idle;
  uint64_t epoch_=0, media_=0, started_=0;
  uint32_t card_id_=0, device_id_=0;
  size_t expected_=0;
  unsigned pass_=0,file_=0;
  size_t offset_=0;
  uint64_t next_try_=0;
  Store149 store_{};
  std::array<std::array<std::vector<uint8_t>,4>,2> passes_{};
  std::array<std::array<bool,4>,2> readable_{};
  Selection149 selected_{};
  size_t chunks_=0;
  static constexpr uint64_t timeout_ms_=30000;
  void advance(){
    offset_=0;
    if(++file_==4){file_=0;++pass_;}
    if(pass_==2){
      for(unsigned f=0;f<4;++f){
        if(readable_[0][f]!=readable_[1][f] ||
           (readable_[0][f] && passes_[0][f]!=passes_[1][f])){
          state_=SdStep153::Cancelled;return;
        }
      }
      for(unsigned f=0;f<4;++f){
        if(readable_[0][f]){
          if(f%2==0)store_.slots[f/2].image=passes_[0][f];
          else store_.slots[f/2].commit=passes_[0][f];
        }
      }
      selected_=select149(store_,card_id_,device_id_,expected_);
      state_=selected_.decision==Decision149::UniqueBackup?SdStep153::ValidUntrustedMedia:
             selected_.decision==Decision149::AmbiguousSameGeneration?SdStep153::Ambiguous:SdStep153::NoValidBackup;
    }
  }
public:
  bool start(const SdSnapshot151& s,uint64_t now,uint32_t card,uint32_t device,size_t bytes){
    if(state_==SdStep153::Running||state_==SdStep153::Deferred||
       !now||!card||!device||bytes==0||bytes>65536||
       check_sd151(s)!=SdGate151::Clear)return false;
    // Reset all previous data; no result can leak into a new session.
    *this=SdIncremental153{};
    epoch_=s.mount_epoch;media_=s.media_generation;started_=now;
    card_id_=card;device_id_=device;expected_=bytes;
    state_=SdStep153::Running;return true;
  }
  SdStep153 state()const{return state_;}
  size_t chunks()const{return chunks_;}
  size_t bytes_done()const {size_t count=0;for(auto& p:passes_)for(auto& f:p)count+=f.size();return count;}
  const Selection149& selection()const{return selected_;}
  static constexpr size_t block_size(){return 64;}
  static constexpr bool may_write_sd(){return false;}
  static constexpr bool may_write_eeprom(){return false;}
  static constexpr bool may_restore_eeprom(){return false;}
  void cancel(){if(state_==SdStep153::Running||state_==SdStep153::Deferred){state_=SdStep153::Cancelled;selected_=Selection149{};}}
  SdStep153 poll(SdOwnership151& owner,SdSlicePort153& port,uint64_t now){
    if(state_!=SdStep153::Running&&state_!=SdStep153::Deferred)return state_;
    if(now<started_||now-started_>timeout_ms_){state_=SdStep153::Expired;selected_=Selection149{};return state_;}
    const auto s=owner.snapshot();
    if(!s.mounted||s.mount_epoch!=epoch_||s.media_generation!=media_||!s.card_identity_verified||
       !port.mounted()||port.mount_epoch()!=epoch_){cancel();return state_;}
    if(now<next_try_)return state_;
    if(check_sd151(s)!=SdGate151::Clear){state_=SdStep153::Deferred;next_try_=now+25;return state_;}
    if(!owner.try_acquire_exclusive_read()){state_=SdStep153::Deferred;next_try_=now+25;return state_;}
    struct Lease{SdOwnership151& o;~Lease(){o.release_exclusive_read();}} lease{owner};
    const auto locked=owner.snapshot();
    if(check_sd151(locked)!=SdGate151::Clear|| !same_sd_identity151(s,locked)||
       !port.mounted()||port.mount_epoch()!=epoch_){cancel();return state_;}
    const size_t cap=(file_%2==0)?expected_+24:20;
    std::vector<uint8_t> piece;
    size_t total=0;
    const bool ok=port.read_slice(file_,offset_,block_size(),piece,total);
    ++chunks_;
    const auto after=owner.snapshot();
    if(check_sd151(after)!=SdGate151::Clear||!same_sd_identity151(locked,after)||
       !port.mounted()||port.mount_epoch()!=epoch_){cancel();return state_;}
    state_=SdStep153::Running;
    if(!ok){readable_[pass_][file_]=false;passes_[pass_][file_].clear();advance();return state_;}
    if(total==0||total>cap||offset_>total||piece.size()>block_size()||
       piece.size()!=((total-offset_<block_size())?total-offset_:block_size())){
      cancel();return state_;
    }
    if(offset_==0)readable_[pass_][file_]=true;
    auto& buffer=passes_[pass_][file_];
    buffer.insert(buffer.end(),piece.begin(),piece.end());
    offset_+=piece.size();
    if(offset_==total)advance();
    return state_;
  }
};
static_assert(SdIncremental153::block_size()==64 && !SdIncremental153::may_write_sd() &&
              !SdIncremental153::may_write_eeprom() && !SdIncremental153::may_restore_eeprom(),"Fail closed");
} // sv04
