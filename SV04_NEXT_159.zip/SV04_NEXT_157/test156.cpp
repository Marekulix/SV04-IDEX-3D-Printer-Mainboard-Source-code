#include "sd_shared_arbiter156.h"
#include "sd_cooperative154.h"
#include <cstdio>
using namespace sv04;
int main(){
 int n=0;
 #define CHECK(e) do{++n; if(!(e)){fprintf(stderr,"fail line %d: %s\n",__LINE__,#e);return 1;}}while(0)
 SharedMedia156 gate;MediaState156 s{};s.mounted=true;s.epoch=7;gate.update(s);
 uint32_t a=0,b=0;CHECK(!gate.diagnostics_safe());
 CHECK(gate.acquire(MediaOwner156::Diagnostic,7,a)==Result156::Busy);
 gate.test_only_enable_diagnostics(true);CHECK(gate.diagnostics_safe());
 CHECK(gate.acquire(MediaOwner156::Diagnostic,7,a)==Result156::Granted);
 CHECK(a!=0);CHECK(gate.acquire(MediaOwner156::Print,7,b)==Result156::Busy);
 CHECK(gate.acquire(MediaOwner156::Diagnostic,7,b)==Result156::Busy);
 CHECK(gate.release(MediaOwner156::Print,7,a)==Result156::WrongOwner);
 CHECK(gate.release(MediaOwner156::Diagnostic,7,a)==Result156::Granted);
 CHECK(gate.release(MediaOwner156::Diagnostic,7,a)==Result156::WrongOwner);
 // Existing open print file blocks diagnostics even if printer paused.
 s.print_file_open=true;s.paused=true;gate.update(s);
 CHECK(!gate.diagnostics_safe());CHECK(gate.acquire(MediaOwner156::Diagnostic,7,b)==Result156::Busy);
 CHECK(gate.acquire(MediaOwner156::Print,7,b)==Result156::Granted);
 CHECK(gate.release(MediaOwner156::Print,7,b)==Result156::Granted);
 s.paused=false;s.print_file_open=false;s.recovery_busy=true;gate.update(s);
 CHECK(gate.acquire(MediaOwner156::Diagnostic,7,a)==Result156::Busy);
 CHECK(gate.acquire(MediaOwner156::Recovery,7,a)==Result156::Granted);
 CHECK(gate.release(MediaOwner156::Recovery,7,a)==Result156::Granted);
 s.recovery_busy=false;gate.update(s);
 // Changing media during active access always faults (cannot claim real I/O aborted).
 CHECK(gate.acquire(MediaOwner156::Diagnostic,7,a)==Result156::Granted);
 s.epoch=8;gate.update(s);CHECK(gate.faulted());
 CHECK(gate.release(MediaOwner156::Diagnostic,7,a)==Result156::Stale);
 CHECK(gate.acquire(MediaOwner156::Diagnostic,8,b)==Result156::Fault);
 gate.quiescent_reset();CHECK(!gate.faulted());
 CHECK(gate.acquire(MediaOwner156::Diagnostic,8,b)==Result156::Granted);
 CHECK(b!=a);CHECK(gate.release(MediaOwner156::Diagnostic,8,a)==Result156::WrongOwner);
 CHECK(gate.release(MediaOwner156::Diagnostic,8,b)==Result156::Granted);
 // When busy state changes while a diagnostic lease is in flight, the next step
 // must fail safe. The arbiter does not pretend to preempt a synchronous read.
 CHECK(gate.acquire(MediaOwner156::Diagnostic,8,a)==Result156::Granted);
 s.printing=true;gate.update(s);CHECK(!gate.diagnostics_safe());
 CHECK(gate.acquire(MediaOwner156::Print,8,b)==Result156::Busy);
 CHECK(gate.release(MediaOwner156::Diagnostic,8,a)==Result156::Granted);
 CHECK(gate.acquire(MediaOwner156::Diagnostic,8,b)==Result156::Busy);
 CHECK(gate.acquire(MediaOwner156::Print,8,b)==Result156::Granted);
 CHECK(gate.release(MediaOwner156::Print,8,b)==Result156::Granted);
 s.printing=false;gate.update(s);
 SdSnapshot151 snap{};snap.mounted=true;snap.mount_epoch=8;snap.media_generation=2;snap.card_identity_verified=true;
 SharedOwnership156 owner{gate};owner.set_snapshot(snap);
 CHECK(owner.try_acquire_exclusive_read());CHECK(owner.held());
 CHECK(!owner.try_acquire_exclusive_read());owner.release_exclusive_read();CHECK(!owner.held());
 for(unsigned i=0;i<64;++i){
   s.other_busy=!!(i%2);s.upload_busy=!!(i%3);s.logging_busy=!!(i%5);gate.update(s);
   const bool blocked=s.other_busy||s.upload_busy||s.logging_busy;
   CHECK(gate.diagnostics_safe()!=blocked);
   uint32_t t=0;const auto res=gate.acquire(MediaOwner156::Diagnostic,8,t);
   CHECK((res==Result156::Busy)==blocked);
   if(!blocked)CHECK(gate.release(MediaOwner156::Diagnostic,8,t)==Result156::Granted);
 }
 CHECK(!SharedMedia156::can_save_eeprom());
 std::printf("SV04 NEXT 156: %d checks passed. Host only.\n",n);
}
