# SV04 NEXT 157 – Guarded SD slice and consolidated audit

**Status: HOST-ONLY, NOT FOR INSTALLATION. NO firmware changes or flash operations.**

New: `sd_guarded_slice157.h` and `test157.cpp` implement and test a 64-byte bounded read with shared-lease acquisition, state checks immediately before and after reading, strict media epoch and generation comparison, and withholding of partial bytes on read failure. The test-only diagnostic-enable flag in `sd_shared_arbiter156.h` **must not be enabled on real firmware**.

Regression: Run `python3 audit_all_157.py`. All standalone C++ host tests use `-fsanitize=undefined` with `-Wall -Wextra -Werror`. C++ test157 additionally passed an AddressSanitizer + UndefinedBehaviorSanitizer run on this host.

## Verified GitHub status (2026-11-06)

Repository `Marekulix/SV04-IDEX-3D-Printer-Mainboard-Source-code`, default branch master.

* Run 112 (42113380433) success on 2026-11-05: DWIN OEM/serial test, NOT a build validating Stands 135–157.
* Run 92 (42084098416) overall failure: STM32 integration job succeeded; host-test/package job failed.
* Run 91 (42079778219) overall failure: both STM32 integration and host-test/package jobs failed.
* Local Stands 135–157 contain host tests and prototypes. None are verified on target hardware or against the full integrated firmware.
* 134_A.zip / 134_B.yml exist locally but latest successful GitHub run is only 112. Stand 134 workflow was not confirmed executed.

## Integration blockers

1. Instrument every SD access path, including `CardReader`, paused prints, file manager, upload/logging, `POWER_LOSS_RECOVERY`, media mounts/removals, and DWIN paths. An isolated arbiter is NOT protection.
2. Enforce atomic ownership and a bounded, driver-reviewed read implementation. A host test lease is not an ISR-safe mutex and does not guarantee flash/SD hardware health.
3. Confirm the exact EEPROM backend selected by the actual STM32 build; `EEPROM_SETTINGS` alone is not proof of flash storage.
4. Compile / test mesh data serialization layout and data integrity against real firmware. `M500` writes all settings; EEPROM flash writes are not power-fail atomic.
5. Validate T0/T1 collisions, homing, BLTouch, bed temperature, 16 points, cancellation, and DWIN UI on actual hardware.
6. No auto EEPROM write/restore until backup durability and recovery procedure are demonstrated.

## Progress interpretation

Point 1 historically reported as 100%, point 2 as 79%, point 3 as 59% before this stand. Those are project estimates, **not certification** of fully integrated hardware functionality. Point 4 and Point 5 scope is not established by current evidence. Stand 157 adds read safety tests, but does not justify calling point 3 'hardware ready'.
