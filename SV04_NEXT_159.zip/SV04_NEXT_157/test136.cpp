#include "auto60_controller.h"
#include "mesh_transaction.h"
#include <cassert>
#include <cstring>
#include <iostream>
#include <limits>
using namespace sv04;
static MeshImage initial() {
  MeshImage a{};
  for(int x=0;x<4;x++) for(int y=0;y<4;y++) a.z[x][y] = (x*4+y)*0.013f - .1f;
  a.z[2][2] = std::numeric_limits<float>::quiet_NaN();
  a.spacing[0]=28; a.spacing[1]=27; a.origin[0]=10; a.origin[1]=12; a.leveling_active = true;
  return a;
}
static void modify(MeshImage &a){a.z[0][0]=8; a.z[2][2]=.2f; a.spacing[1]=55; a.origin[0]=0; a.leveling_active=false;}
int main(){int n=0;
  { MeshTransaction t; MeshImage a=initial();assert(!t.capture(a,false,true,true));++n;
    assert(!t.capture(a,true,false,true));++n;
    assert(!t.capture(a,true,true,false));++n;
    assert(!t.rollback(a,true,true));++n; }
  { MeshTransaction t; MeshImage a=initial(),original=a;
    assert(t.capture(a,true,true,true));++n;
    assert(!t.capture(a,true,true,true));++n;
    modify(a);assert(!MeshTransaction::same_bytes(a,original));++n;
    assert(!t.rollback(a,false,true));++n;
    assert(!t.rollback(a,true,false));++n;
    assert(t.rollback(a,true,true));++n;
    assert(t.restored_exactly(a));++n;
    assert(MeshTransaction::same_bytes(a,original));++n;
    assert(!t.commit(true,true,true));++n;
    modify(a);assert(!t.restored_exactly(a));++n;
  }
  { MeshTransaction t; MeshImage a=initial();assert(t.capture(a,true,true,true));++n;
    assert(!t.commit(false,true,true));++n;
    assert(!t.commit(true,false,true));++n;
    assert(!t.commit(true,true,false));++n;
    assert(t.protected_mesh());++n;
    assert(t.commit(true,true,true));++n;
    assert(!t.rollback(a,true,true));++n;
  }
  { Controller c; Guards g{true,true,true,true,true,true};
    assert(c.start(g,100));++n;
    c.abort();assert(c.needs_restore());++n;
    assert(!c.start(g,200));++n;
    c.restore_done(false);assert(!c.start(g,300));++n;
    c.restore_done(true);assert(!c.needs_restore());++n;
    assert(c.start(g,400));++n;
  }
  { // End-to-end simulated partial G29 mutation, followed by rollback.
    Controller c; MeshTransaction t; MeshImage a=initial(),before=a;
    assert(t.capture(a,true,true,true));++n;
    Guards g{true,true,true,true,true,t.protected_mesh()};
    assert(c.start(g,0));++n;
    c.ack(Action::SetBed60,true,50);c.temperature(60,1000);c.temperature(60,32000);
    c.ack(Action::HomeSafely,true,32010);c.ack(Action::Probe4x4,true,32020);
    for(int y=0;y<2;y++)for(int x=0;x<4;x++){a.z[x][y]=.1f;assert(c.point(x,y,.1f));++n;}
    c.probe_complete(false,false,33000);assert(c.needs_restore());++n;
    assert(t.rollback(a,true,true));++n;
    assert(MeshTransaction::same_bytes(a,before));++n;
    c.restore_done(t.restored_exactly(a));assert(!c.needs_restore());++n;
  }
  std::cout << "PASS " << n << " checks: snapshot, exact rollback, error latch, commit gate, partial G29\n";
}
