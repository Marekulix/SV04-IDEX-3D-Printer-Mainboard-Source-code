#include "recovery_capability148.h"
#include <cassert>
#include <iostream>
using namespace sv04;
static RecoveryEvidence148 valid() {
 RecoveryEvidence148 e;
 e.backend=Backend148::STM32F1_Flash;
 e.backup_medium=BackupMedium148::ExternalHost;
 e.phase=JournalPhase148::WriteIntent;
 e.printer_idle=e.motors_stopped=e.heaters_safe=true;
 e.backup_complete=e.backup_readback_verified=e.backup_version_crc_valid=true;
 e.backup_matches_prewrite_snapshot=true;
 e.journal_slots_independently_durable=e.external_backup_durable=true;
 e.recorded_previous_eeprom_version_crc_valid=true;
 e.manual_service_authorized=true;
 return e;
}
int main(){int n=0;auto ck=[&](bool x){assert(x);++n;};
 auto e=valid();
 ck(recovery_decide148(e)==RecoveryDecision148::ManualServiceOnly);
 ck(!automatic_restore_allowed148());ck(!automatic_m500_allowed148());
 {auto f=e;f.backend=Backend148::Unknown;ck(recovery_decide148(f)==RecoveryDecision148::DenyUnknownBackend);}
 for(auto b:{Backend148::SD_EmulatedEEPROM,Backend148::Other}){auto f=e;f.backend=b;ck(recovery_decide148(f)==RecoveryDecision148::DenyUnsupportedBackend);}
 for(auto b:{BackupMedium148::None,BackupMedium148::SameFlash}){auto f=e;f.backup_medium=b;ck(recovery_decide148(f)==RecoveryDecision148::DenyNoIndependentMedium);}
 {auto f=e;f.backup_medium=BackupMedium148::RemovableSD;ck(recovery_decide148(f)==RecoveryDecision148::DenyNoIndependentMedium);f.sd_present_and_identity_checked=true;ck(recovery_decide148(f)==RecoveryDecision148::ManualServiceOnly);}
 {auto f=e;f.external_backup_durable=false;ck(recovery_decide148(f)==RecoveryDecision148::DenyNoDurabilityProof);}
 {auto f=e;f.journal_slots_independently_durable=false;ck(recovery_decide148(f)==RecoveryDecision148::DenyNoDurabilityProof);}
 for(int i=0;i<4;i++){auto f=e;switch(i){case 0:f.backup_complete=false;break;case 1:f.backup_readback_verified=false;break;case 2:f.backup_version_crc_valid=false;break;case 3:f.recorded_previous_eeprom_version_crc_valid=false;break;}ck(recovery_decide148(f)==RecoveryDecision148::DenyNoVerifiedBackup);}
 {auto f=e;f.backup_matches_prewrite_snapshot=false;ck(recovery_decide148(f)==RecoveryDecision148::DenyBackupMismatch);}
 for(auto p:{JournalPhase148::Unknown,JournalPhase148::Quarantine,JournalPhase148::Empty,JournalPhase148::BackupVerified}) {auto f=e;f.phase=p;ck(recovery_decide148(f)==RecoveryDecision148::DenyAmbiguousJournal);}
 for(auto p:{JournalPhase148::WriteIntent,JournalPhase148::WriteReported}) {auto f=e;f.phase=p;ck(recovery_decide148(f)==RecoveryDecision148::ManualServiceOnly);}
 {auto f=e;f.phase=JournalPhase148::Verified;f.eeprom_current_version_crc_valid=true;ck(recovery_decide148(f)==RecoveryDecision148::NoActionNecessary);f.eeprom_current_version_crc_valid=false;ck(recovery_decide148(f)==RecoveryDecision148::ManualServiceOnly);}
 for(int i=0;i<4;i++){auto f=e;switch(i){case 0:f.printer_idle=false;break;case 1:f.motors_stopped=false;break;case 2:f.heaters_safe=false;break;case 3:f.manual_service_authorized=false;break;}ck(recovery_decide148(f)==RecoveryDecision148::DenyUntrustedEEPROM);}
 // Exhaustively flip every combination of these 7 critical guards.
 for(unsigned mask=0;mask<128;mask++){
   auto f=e;f.backup_complete=mask&1;f.backup_readback_verified=mask&2;
   f.backup_version_crc_valid=mask&4;f.backup_matches_prewrite_snapshot=mask&8;
   f.journal_slots_independently_durable=mask&16;f.external_backup_durable=mask&32;
   f.manual_service_authorized=mask&64;
   bool all=mask==127;
   ck((recovery_decide148(f)==RecoveryDecision148::ManualServiceOnly)==all);
 }
 // No evidence combination grants an automatic EEPROM write.
 for(unsigned mask=0;mask<256;mask++){
   auto f=e; f.printer_idle=mask&1;f.motors_stopped=mask&2;f.heaters_safe=mask&4;
   f.manual_service_authorized=mask&8;f.eeprom_current_version_crc_valid=mask&16;
   f.external_backup_durable=mask&32;f.backup_complete=mask&64;f.backup_readback_verified=mask&128;
   ck(recovery_decide148(f)!=RecoveryDecision148::NoActionNecessary);
   ck(!automatic_m500_allowed148() && !automatic_restore_allowed148());
 }
 std::cout<<"PASS "<<n<<" assertions (SV04 NEXT 148)\n";
}
