#pragma once
// SV04 NEXT 154: HOST-ONLY cooperative SD scan scheduler.
// Replaces the synchronous scan_exclusive151 path from SdCoexist152.
// Does NOT integrate with Marlin, grant EEPROM writes, or confer trust on an SD medium.
#include "sd_incremental153.h"
#include "sd_coexist152.h"
#include <cstdint>
namespace sv04 {
enum class Scan154:uint8_t { Idle, Deferred, Running, ValidUntrusted, NoBackup, Ambiguous, Cancelled, Expired, Rejected };
struct Stats154 {uint32_t deferrals=0, ticks=0, blocks=0, cancellations=0;};
class Cooperative154 {
  Scan154 status_=Scan154::Idle;
  uint64_t start_=0, epoch_=0, gen_=0, retry_at_=0;
  uint32_t card_=0,device_=0;
  size_t length_=0;
  SdIncremental153 reader_{};
  Stats154 stats_{};
  static constexpr uint64_t timeout_=30000;
  void cancel_internal(){ reader_.cancel(); status_=Scan154::Cancelled; ++stats_.cancellations; }
public:
  bool start(const SdSnapshot151& s,uint64_t now,uint32_t card,uint32_t device,size_t bytes){
    if(status_==Scan154::Running||status_==Scan154::Deferred||!now||!card||!device||
       !bytes||bytes>65536||!s.mounted||!s.mount_epoch||!s.media_generation||
       !s.card_identity_verified||s.media_change_pending)return false;
    *this=Cooperative154{};
    start_=retry_at_=now; epoch_=s.mount_epoch;gen_=s.media_generation;
    card_=card;device_=device;length_=bytes;status_=Scan154::Deferred;
    return true;
  }
  Scan154 state()const{return status_;}
  Stats154 stats()const{return stats_;}
  size_t chunks()const{return reader_.chunks();}
  const Selection149& selection()const{return reader_.selection();}
  void on_event(SdEvent152){if(status_==Scan154::Deferred||status_==Scan154::Running)cancel_internal();}
  void cancel(){if(status_==Scan154::Deferred||status_==Scan154::Running)cancel_internal();}
  Scan154 poll(SdOwnership151& owner,SdSlicePort153& port,uint64_t now){
    if(status_!=Scan154::Deferred&&status_!=Scan154::Running)return status_;
    ++stats_.ticks;
    if(now<start_||now-start_>timeout_){reader_.cancel();status_=Scan154::Expired;return status_;}
    auto s=owner.snapshot();
    if(!s.mounted||s.mount_epoch!=epoch_||s.media_generation!=gen_||
       !s.card_identity_verified||s.media_change_pending||!port.mounted()||port.mount_epoch()!=epoch_){
      cancel_internal();return status_;
    }
    if(now<retry_at_)return status_;
    // Do not inspect or modify the ongoing SD job. Print, recovery and other I/O win.
    if(check_sd151(s)!=SdGate151::Clear){
      status_=Scan154::Deferred;++stats_.deferrals;retry_at_=now+25;return status_;
    }
    if(reader_.state()==SdStep153::Idle){
      if(!reader_.start(s,now,card_,device_,length_)){status_=Scan154::Rejected;return status_;}
    }
    const size_t before=reader_.chunks();
    const auto outcome=reader_.poll(owner,port,now);
    const size_t delta=reader_.chunks()-before;
    if(delta>1){cancel_internal();return status_;}
    stats_.blocks+=static_cast<uint32_t>(delta);
    switch(outcome){
      case SdStep153::Running:status_=Scan154::Running;break;
      case SdStep153::Deferred:status_=Scan154::Deferred;++stats_.deferrals;retry_at_=now+25;break;
      case SdStep153::ValidUntrustedMedia:status_=Scan154::ValidUntrusted;break;
      case SdStep153::NoValidBackup:status_=Scan154::NoBackup;break;
      case SdStep153::Ambiguous:status_=Scan154::Ambiguous;break;
      case SdStep153::Expired:status_=Scan154::Expired;break;
      case SdStep153::Cancelled:cancel_internal();break;
      default:status_=Scan154::Rejected;break;
    }
    return status_;
  }
  static constexpr bool permits_m500(){return false;}
  static constexpr bool permits_restore(){return false;}
  static constexpr bool permits_sd_write(){return false;}
};
static_assert(!Cooperative154::permits_m500()&&!Cooperative154::permits_restore()&&
              !Cooperative154::permits_sd_write(),"No write authority in host diagnostic");
}
