#pragma once
#include "auto60_thermal_bridge.h"
#include "auto60_idex_bridge.h"
#include "mesh_transaction.h"
#include <cmath>
#include <cstdint>

// Host-only sequencer. It NEVER sends G-code; firmware adapter must execute
// requested actions and feed independently verified hardware results back.
namespace sv04 {
class Sequence140 {
public:
  Controller controller;
  ThermalBridge thermal;
  MeshTransaction snapshot;
  ParkEvidence park;

  bool begin(const MeshImage& live, const Guards& guards, bool no_mesh_writers, uint32_t ms) {
    if (active_ || restore_required_ || snapshot.state()==MeshTransaction::State::Protected) return false;
    if (!snapshot.capture(live, guards.idle, true, no_mesh_writers)) return false;
    Guards g=guards;g.snapshot_valid=true;
    if (!controller.start(g,ms)) return false;
    active_=true; home_permit_=false; probe_permit_=false; return true;
  }
  bool setpoint_accepted(bool verified_command_execution, uint32_t ms) {
    if (!active_ || controller.phase()!=Phase::Heat || controller.pending()!=Action::SetBed60) return false;
    controller.ack(Action::SetBed60,verified_command_execution,ms);
    if (controller.phase()==Phase::Fault) {fail_latch();return false;}
    thermal.after_setpoint_ack(controller,ms);return true;
  }
  bool observe_bed(const BedTelemetry& telemetry, uint32_t ms) {
    if (!active_ || controller.phase()==Phase::Fault) return false;
    // Always enforce thermal protection during ALL phases, including homing/probing.
    if (controller.phase()==Phase::Heat || controller.phase()==Phase::Stabilize) {
      const bool ok=thermal.observe(controller,telemetry,ms);
      if (controller.phase()==Phase::Fault || thermal.thermal.failed()) {fail_latch();return false;}
      return ok;
    }
    const ThermalReason r=thermal.thermal.update(telemetry,ms);
    if (r!=ThermalReason::Ready || !thermal.thermal.ready()) {
      controller.abort();fail_latch();return false;
    }
    return true;
  }
  bool allow_home(const IDEXInputs& fresh) {
    home_permit_=active_ && !restore_required_ && controller.phase()==Phase::Home &&
           thermal.thermal.ready() && permit_initial_home(controller,fresh).allowed;
    return home_permit_;
  }
  bool home_finished(const HomingResult& h, const ParkObservation& po, uint32_t ms) {
    if (!active_ || !home_permit_ || !thermal.thermal.ready() || !accept_initial_home_completion(controller,park,h,po,ms)) {
      controller.abort();fail_latch();return false;
    }
    home_permit_=false;return true;
  }
  bool allow_g29(const ParkObservation& po, const IDEXInputs& fresh) {
    probe_permit_=active_ && !restore_required_ && controller.phase()==Phase::Probe &&
           controller.pending()==Action::Probe4x4 && thermal.thermal.ready() &&
           fresh.machine_idle && fresh.planner_empty_and_steppers_stopped &&
           fresh.probe_selfcheck_passed && fresh.no_obstructions_confirmed &&
           fresh.physical_clearance_confirmed && park.still_valid(po);
    return probe_permit_;
  }
  bool g29_started(bool command_started, uint32_t ms) {
    if (!active_ || !probe_permit_ || controller.phase()!=Phase::Probe || controller.pending()!=Action::Probe4x4) return false;
    if(!command_started) {controller.abort();fail_latch();return false;}
    controller.ack(Action::Probe4x4,true,ms);probe_permit_=false;
    return true;
  }
  bool point(unsigned x,unsigned y,float z) {
    if (!active_ || controller.pending()!=Action::None || !controller.point(x,y,z)) {
      controller.abort();fail_latch();return false;
    }
    return true;
  }
  // completion is a confirmed final G29 return, not merely queue acceptance
  bool g29_finished(bool genuine_success,bool dry_run,uint32_t ms) {
    if (!active_ || controller.phase()!=Phase::Probe || controller.pending()!=Action::None) return false;
    controller.probe_complete(genuine_success,dry_run,ms);
    if (controller.phase()==Phase::Fault) {fail_latch();return false;}
    return true;
  }
  bool validate(const MeshImage& actual, bool hardware_stopped, bool writers_locked, uint32_t ms) {
    if (!active_ || controller.phase()!=Phase::Validate || !hardware_stopped || !writers_locked) return false;
    bool match=true;
    for (unsigned y=0;y<4;y++)for(unsigned x=0;x<4;x++) {
      float value=controller.measurements()[y*4+x];
      if(!std::isfinite(actual.z[x][y]) || !std::isfinite(value) ||
         std::fabs(actual.z[x][y]-value)>0.0002f) match=false;
    }
    if (!thermal.thermal.ready()) match=false;
    controller.validation(match, match, ms);
    if (controller.phase()==Phase::Fault) {fail_latch();return false;}
    return true;
  }
  // Deliberately NO direct M500 or EEPROM readback here: EEPROM write is a
  // separate safety-critical transaction requiring further integration.
  void abort() {controller.abort();fail_latch();}
  void tick(uint32_t ms,bool safety_ok) {
    controller.tick(ms,safety_ok);
    if(controller.phase()==Phase::Fault) fail_latch();
  }
  bool rollback(MeshImage& live,bool motion_stopped,bool writers_locked) {
    if (!restore_required_ || !motion_stopped || !writers_locked) return false;
    const bool ok=snapshot.rollback(live,motion_stopped,writers_locked);
    if (!ok || !snapshot.restored_exactly(live)) return false;
    controller.restore_done(true);restore_required_=false;active_=false;
    return true;
  }
  bool restore_required() const {return restore_required_;}
  bool active() const {return active_;}
private:
  void fail_latch() {if(controller.phase()==Phase::Fault){restore_required_=true;home_permit_=probe_permit_=false;}}
  bool active_=false,restore_required_=false,home_permit_=false,probe_permit_=false;
};
}
