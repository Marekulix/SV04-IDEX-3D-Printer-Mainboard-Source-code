# SV04 NEXT 154: Kooperativer SD-Scheduler, Punkt 3 (60-°C-Bettvermessung)

**Status:** HOST-PROTOTYP, NICHT INSTALLIEREN. Keine Marlin-Firmwareintegration, keine SD-/EEPROM-Schreibberechtigung.

## Implementierung
- `sd_cooperative154.h` bindet den `SdIncremental153`-Leser an eine neue asynchrone, in `poll()` arbeitende Koexistenz-Steuerung an. Kein Aufruf von `scan_exclusive151`.
- Pro Poll höchstens EIN Aufruf von `SdSlicePort153::read_slice()` mit maximal 64 Bytes. Die Exklusivsperre wird ausschließlich für den jeweiligen Block gehalten und danach freigegeben.
- Laufende/pausierte SD-Drucke, geöffnete Dateien, Schreib-/Log-Aktivität, Power-Loss-Recovery und konkurrierende I/O führen zu einer Zurückstellung, nicht zum Verdrängen anderer Verbraucher.
- Ein Wechsel von Mount-Epoche, Mediengeneration oder ein externes Ereignis verwirft die gesamte aktive Diagnose.
- Nach 30 Sekunden wird die Diagnose ungültig; es gibt keine automatische Reparatur.
- Erfolgreicher Scan liefert ausschließlich `ValidUntrusted`. Statische Sicherheiten `permits_m500() == false`, `permits_restore() == false`, `permits_sd_write() == false`.
- `test154.cpp`: 601 Assertions; Normalablauf 72 gebundene Leseschritte, Fehler-/Druck-/Recovery-/Medienwechseltests.

## Geprüft
24 C++-Testprogramme (`test135.cpp` bis `test154.cpp` inkl. Zwischen-/Bridge-Tests) wurden mit `g++ -std=c++17 -Wall -Wextra -Werror -fsanitize=undefined` gebaut und ausgeführt. Beide Python-Testprogramme bestanden.

## Fehlende Nachweise
1. `SdOwnership151` existiert bisher **nicht** als gemeinsame atomare Sperre in Marlin. Die Sperre muss ALLEN SD-Benutzern gelten (SD-Druck, Recovery, Upload, UI, Logging, Dateiauflistung). Ohne sie darf die Firmwarediagnose nicht aktiviert werden.
2. `SdSlicePort153` ist nur eine Host-Schnittstelle. Es gibt weder einen realen Marlin-Adapter noch nachgewiesene, nichtblockierende SD-Zugriffe.
3. Die Medien-/Gerätekennungen sind derzeit simuliert. `ValidUntrusted` darf niemals als Flash-Recovery-Freigabe interpretiert werden.
4. Stromausfallhaltbarkeit der SD, echter EEPROM-/Mesh-Layout-Nachweis und IDEX-/BLTouch-Hardwaretests fehlen.
5. In den letzten Builds wurde **keine** neue Druckerfirmware erstellt oder installiert.

## Folgeschritt
Spezifizierte Hook-Punkte für einen gesicherten Marlin-SD-Adapter und einen reproduzierbaren Build vorbereiten. Der EEPROM-Schreibpfad bleibt deaktiviert.
