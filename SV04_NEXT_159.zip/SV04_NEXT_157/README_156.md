# SV04 NEXT 156: Gemeinsamer SD-Zugriffskern (Host-Prototyp)

**Sicherheitsstatus: NICHT INSTALLIEREN, KEIN MARLIN-BUILD, KEINE EEPROM-SCHREIBFREIGABE.**

## Umfang
- `sd_shared_arbiter156.h`: nicht-rekursive Eigentümerverwaltung für Diagnose, Druck, Recovery, Upload, Dateibrowser, Verzeichnisse, Medienverwaltung und andere SD-Zugriffe.
- `SharedOwnership156`: Testadapter zur bestehenden `SdOwnership151`-Schnittstelle. Verwendet den gemeinsamen Zugriffskern anstelle einer isolierten Diagnose-Sperre.
- `test156.cpp`: Prüfungen gegen Konkurrenz, pausierten Druck, Medienwechsel, wiederholte/stale Freigaben und andere belegte SD-Zustände.

## Grenzen / noch erforderlicher konkreter Marlin-Patch
Die vorhandene Sovol-Firmware integriert diesen Header **nicht**. Dort müssen die globalen SD-Nutzer tatsächlich dieselbe Eigentümerverwaltung benutzen. Besonders zu erfassen: `CardReader::openFileRead`, `openFileWrite`, `closefile`, `removeFile`, mount/release, Listen/Verzeichnisse, Dateizugriffe in `CardReader`, Power-Loss-Recovery mit eigenen Dateien, Dateitransfers und Bildschirmanzeige. Ein einfaches Flagsystem ist keine vollständige Mutual Exclusion.

Der Prototyp setzt auf eine **einzige, nicht-parallele Hauptschleife**. Unter Interrupts, mehreren Threads oder einem RTOS wäre für die acquire/release-Kernoperation eine reale kritische Sektion notwendig. `update()` während eines aktiven Lesezugriffs kann die laufende Operation nicht abbrechen; Folgeschritte müssen Zustand und Epoch prüfen. Ein vollständiger Hardware-Beweis ist nicht vorhanden.

**Priorität:** laufende Druck- und Recovery-Dateizugriffe werden nicht vom Diagnoseprogramm unterbrochen. Ein pausierter Druck gilt als belegt. Medienwechsel bei aktiver Operation verriegelt den Kern bis zur kontrollierten Freigabe.

## Nachweise aus Sovol OEM (gepinnt)
Repository `Sovol3d/SV04-IDEX-3D-Printer-Mainboard-Source-code`, Commit `1867fcba75354a5c65e0631d6972dd19f1bd6cbe`.
`Marlin/src/sd/cardreader.h` hat `isPrinting`, `isPaused`, `isFileOpen`, `isMounted` und `getroot`. `Marlin/src/sd/cardreader.cpp` öffnet unter anderem Dateien in `openFileRead`, `openFileWrite` und `openJobRecoveryFile`. Es gibt dort keinen nachgewiesenen globalen SD-Lock für sämtliche Nutzer.

## Nächster sinnvoller Schritt
1. Hook-Inventar aller SD-Funktionen und direkten `SdFile`-Operationen erstellen.
2. Eine einzige tatsächliche Eigentümerverwaltung im geklonten Marlin-Quellbaum installieren; keine Hooks nur auf dem Diagnosepfad.
3. STM32F103RET6_creality Build, Test auf SD-Karte mit künstlichen Latenzen, Druckpausen und Recovery durchführen.
4. Erst nach Nachweis der vollständigen Integration Diagnose überhaupt freischalten. `M500` und automatische Wiederherstellung bleiben gesperrt.
