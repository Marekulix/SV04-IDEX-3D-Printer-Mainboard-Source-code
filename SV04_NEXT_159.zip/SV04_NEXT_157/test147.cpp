#include "eeprom_recovery_journal147.h"
#include <cassert>
#include <array>
#include <iostream>
using namespace sv04;
struct Mock:JournalMedia147 {
 std::array<Journal147,2> slots{}; bool certified=true,fail_write=false,fail_read=false,corrupt=false;
 bool certified_independent_and_atomic_slots()const override{return certified;}
 bool read_slot(unsigned n,Journal147 &out)override{if(fail_read)return false;out=slots[n];return true;}
 bool write_slot_and_sync(unsigned n,const Journal147 &j)override{if(fail_write)return false;slots[n]=j;if(corrupt)slots[n].checksum^=1;return true;}
 void provision(){Journal147 j{kJournalMagic147,kJournalVersion147,1,(uint32_t)TxState147::Empty,0,0,0,0,0};j.checksum=journal_crc147(j);slots[0]=j;}
};
BackupProof147 backup(){return {true,true,true,0xAABBAA11,4096};}
TargetProof147 target(){return {true,true,true,true,0x88997766,4096};}
int main(){int checks=0;auto ck=[&](bool x){assert(x);++checks;};
 for(int failure=0;failure<12;failure++){
  Mock m;m.provision();RecoveryJournal147 j(m);ck(j.load());ck(j.status()==RecoveryJournal147::Status::Ready);
  if(failure==0){ck(!j.prepare({},true,true,true));ck(j.prepare(backup(),true,true,true));ck(!j.request_one_write({},true));ck(j.request_one_write(target(),true));ck(j.may_write_now());ck(j.report_write_result(true));ck(!j.may_write_now());ck(j.verify_readback(true,true,true,true,target().image_crc,4096));ck(j.status()==RecoveryJournal147::Status::Verified);RecoveryJournal147 reboot(m);ck(reboot.load());ck(reboot.status()==RecoveryJournal147::Status::Verified);}
  if(failure==1){ck(j.prepare(backup(),true,true,true));RecoveryJournal147 reboot(m);ck(!reboot.load());ck(reboot.status()==RecoveryJournal147::Status::Quarantined);}
  if(failure==2){ck(j.prepare(backup(),true,true,true));ck(j.request_one_write(target(),true));RecoveryJournal147 reboot(m);ck(!reboot.load());ck(reboot.status()==RecoveryJournal147::Status::Quarantined);}
  if(failure==3){ck(j.prepare(backup(),true,true,true));ck(j.request_one_write(target(),true));ck(!j.report_write_result(false));ck(j.status()==RecoveryJournal147::Status::Quarantined);}
  if(failure==4){ck(j.prepare(backup(),true,true,true));ck(j.request_one_write(target(),true));ck(j.report_write_result(true));ck(!j.verify_readback(true,true,true,true,1,4096));ck(j.status()==RecoveryJournal147::Status::Quarantined);}
  if(failure==5){m.fail_write=true;ck(!j.prepare(backup(),true,true,true));ck(!j.may_write_now());}
  if(failure==6){m.corrupt=true;ck(!j.prepare(backup(),true,true,true));ck(!j.may_write_now());}
  if(failure==7){auto b=backup();b.matches_current_eeprom=false;ck(!j.prepare(b,true,true,true));ck(j.status()==RecoveryJournal147::Status::Ready);}
  if(failure==8){ck(j.prepare(backup(),true,true,true));auto t=target();t.g29_finished_successfully=false;ck(!j.request_one_write(t,true));ck(!j.may_write_now());}
  if(failure==9){ck(j.prepare(backup(),true,true,true));ck(j.request_one_write(target(),true));ck(j.report_write_result(true));ck(!j.verify_readback(true,false,true,true,target().image_crc,4096));}
  if(failure==10){ck(j.prepare(backup(),true,true,true));ck(j.request_one_write(target(),true));ck(j.report_write_result(true));RecoveryJournal147 reboot(m);ck(!reboot.load());}
  if(failure==11){ck(j.prepare(backup(),true,true,true));ck(!j.request_one_write(target(),false));ck(!j.may_write_now());}
 }
 {Mock m;RecoveryJournal147 j(m);ck(!j.load());ck(j.status()==RecoveryJournal147::Status::Quarantined);}
 {Mock m;m.provision();m.certified=false;RecoveryJournal147 j(m);ck(!j.load());}
 {Mock m;m.provision();m.slots[1]=m.slots[0];m.slots[1].backup_crc=1;m.slots[1].checksum=journal_crc147(m.slots[1]);RecoveryJournal147 j(m);ck(!j.load());}
 std::cout<<"PASS "<<checks<<" assertions in journal crash/recovery simulation\n";
}
