#pragma once
// SV04 NEXT 145 - build-derived EEPROM layout contract, host-side validation only.
// No EEPROM access and no write operations.
#include "eeprom_integrity144.h"
#include <cstdint>
#include <cstddef>
#include <cstring>
namespace sv04 {
struct LayoutEvidence145 {
  uint32_t magic=0; // 'S145'
  uint32_t firmware_fingerprint=0; // generated from build-specific values, not security authentication
  uint32_t capacity=0, settings_size=0;
  uint32_t grid_x=0, grid_y=0, spacing=0, origin=0, mesh=0;
  uint32_t xy_bytes=0, mesh_bytes=0;
  uint32_t settings_header_offset=0;
  uint8_t version[4]{};
  bool source_build_generated=false;
  bool flash_driver_verified=false;
};
constexpr uint32_t LAYOUT_MAGIC_145=0x35343153u;
inline bool add145(uint32_t a,uint32_t b,uint32_t& out) { if(b>UINT32_MAX-a)return false;out=a+b;return true; }
inline uint32_t fingerprint145(const LayoutEvidence145& p) {
  // Stable non-cryptographic value to detect accidentally mixing reports and firmware builds.
  uint32_t v=2166136261u;
  const uint32_t words[]={p.capacity,p.settings_size,p.grid_x,p.grid_y,p.spacing,p.origin,p.mesh,p.xy_bytes,p.mesh_bytes,p.settings_header_offset};
  for(uint32_t x:words)for(int i=0;i<4;i++){v^=(x>>(i*8))&0xffu;v*=16777619u;}
  for(uint8_t c:p.version){v^=c;v*=16777619u;}
  return v;
}
inline bool validate_layout145(const LayoutEvidence145& p, Layout144* out=nullptr) {
  if(p.magic!=LAYOUT_MAGIC_145 || !p.source_build_generated || !p.flash_driver_verified)return false;
  if(p.version[0]!='V'||p.version[1]!='8'||p.version[2]!='5'||p.version[3]!=0)return false;
  if(p.settings_header_offset!=100 || p.capacity<512 || p.settings_size<128 || p.capacity>65536)return false;
  if(p.xy_bytes!=8 || p.mesh_bytes!=16*4 || p.firmware_fingerprint!=fingerprint145(p))return false;
  uint32_t end=0, settings_end=0;
  if(!add145(p.settings_header_offset,p.settings_size,settings_end) || settings_end>p.capacity)return false;
  if(p.grid_y != p.grid_x+1 || p.spacing!=p.grid_y+1)return false;
  if(!add145(p.spacing,p.xy_bytes,end)||p.origin!=end)return false;
  if(!add145(p.origin,p.xy_bytes,end)||p.mesh!=end)return false;
  if(!add145(p.mesh,p.mesh_bytes,end)||end>settings_end)return false;
  if(p.grid_x<p.settings_header_offset+6)return false;
  if(out){
    Layout144 x;
    x.total_eeprom_capacity=p.capacity;x.settings_data_size=p.settings_size;
    x.grid_x_offset=p.grid_x;x.grid_y_offset=p.grid_y;
    x.mesh_spacing_offset=p.spacing;x.mesh_origin_offset=p.origin;
    x.mesh_offset=p.mesh;x.xy_pos_bytes=p.xy_bytes;
    x.layout_compiled_and_verified=true;x.flash_backend_certified=true;
    *out=x;
  }
  return true;
}
inline Verification144 verify_with_layout145(const uint8_t* image,size_t len,const LayoutEvidence145& ev) {
 Layout144 l;
 if(!validate_layout145(ev,&l)) {Verification144 r;r.result=Integrity144::Refused;return r;}
 return verify_eeprom144(image,len,l);
}
} // namespace sv04
