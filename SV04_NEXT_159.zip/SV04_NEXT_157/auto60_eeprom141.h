#pragma once
#include "auto60_sequence140.h"
#include <cmath>
#include <cstdint>

// SV04 NEXT 141 - OFFLINE HOST MODEL / NOT FOR FLASH.
// This class requests an OEM settings.save() operation but NEVER executes one.
// A hardware adapter must verify all observations independently, and supply an
// independently proven READ-ONLY EEPROM decoder (NOT M501). If no such decoder
// exists, save is prohibited. This is not an atomic EEPROM transaction.
namespace sv04 {

enum class Persist141 : uint8_t {
  Unarmed, Armed, WritePending, ReadbackPending, Verified,
  FailedBeforeWrite, EEPROMUncertain
};

struct PersistenceInterlocks141 {
  bool machine_idle=false;
  bool planner_synchronized=false;
  bool all_mesh_writers_locked=false;
  bool motion_stopped=false;
  bool thermal_stable=false;
  bool no_other_settings_writers=false;
  bool exact_4x4_geometry=false;
  bool verified_prior_eeprom_backup=false; // independently recoverable, not RAM snapshot
  bool read_only_decoder_available=false;
  bool user_authorized_save=false;
};

inline bool safe_to_write(const PersistenceInterlocks141& g) {
  return g.machine_idle && g.planner_synchronized && g.all_mesh_writers_locked &&
         g.motion_stopped && g.thermal_stable && g.no_other_settings_writers &&
         g.exact_4x4_geometry && g.verified_prior_eeprom_backup &&
         g.read_only_decoder_available && g.user_authorized_save;
}

class EEPROMGate141 {
 public:
  Persist141 state() const {return state_;}
  bool eeprom_may_be_modified() const {return write_started_;}
  bool eeprom_uncertain() const {return state_ == Persist141::EEPROMUncertain;}
  bool finish_verified() const {return state_ == Persist141::Verified;}
  const MeshImage& intended_mesh() const {return expected_;}

  // Capture EXACT validated RAM image. Sequence140 already cross-checked 16
  // independently observed points; do not accept earlier phases or failure.
  bool arm(const Sequence140& seq,const MeshImage& live,const PersistenceInterlocks141& g) {
    if(state_!=Persist141::Unarmed || !safe_to_write(g) ||
       !seq.active() || seq.restore_required() ||
       seq.controller.phase()!=Phase::Persist ||
       seq.controller.pending()!=Action::SaveEEPROM ||
       !seq.snapshot.protected_mesh()) return false;
    for(unsigned x=0;x<4;x++) for(unsigned y=0;y<4;y++) {
      const float v=live.z[x][y];
      const float actual=seq.controller.measurements()[y*4+x];
      if(!std::isfinite(v) || !std::isfinite(actual) ||
         std::fabs(v-actual)>0.0002f) return false;
    }
    for(unsigned i=0;i<2;i++)
      if(!std::isfinite(live.spacing[i]) || live.spacing[i]<=0 ||
         !std::isfinite(live.origin[i])) return false;
    expected_=live;
    state_=Persist141::Armed;
    return true;
  }

  // Revalidate against frozen image immediately before issuing the ONE write.
  // Returns permission to request exactly one OEM settings.save(). The storage
  // may become partial after this point, so failures are permanently uncertain.
  bool begin_write(const Sequence140& seq,const MeshImage& live,const PersistenceInterlocks141& g) {
    if(state_!=Persist141::Armed || !safe_to_write(g) ||
       seq.controller.phase()!=Phase::Persist ||
       seq.controller.pending()!=Action::SaveEEPROM ||
       !MeshTransaction::same_bytes(live,expected_)) return false;
    state_=Persist141::WritePending;
    write_started_=true;
    return true;
  }

  // Real adapter must call only after OEM settings.save() returned.
  bool acknowledge_write(Sequence140& seq,bool save_returned_success,uint32_t ms) {
    if(state_!=Persist141::WritePending) return false;
    seq.controller.ack(Action::SaveEEPROM,save_returned_success,ms);
    if(!save_returned_success || seq.controller.phase()!=Phase::Verify) {
      state_=Persist141::EEPROMUncertain;
      return false;
    }
    state_=Persist141::ReadbackPending;
    return true;
  }

  // Readback must be from independent *non-mutating* EEPROM decoder. A RAM copy,
  // M501, or the success return of M500 cannot count as successful verification.
  bool acknowledge_readback(Sequence140& seq,const MeshImage& stored,
                            bool genuine_read_only_eeprom_read,
                            bool eeprom_payload_integrity_ok,
                            bool all_settings_preserved,
                            const PersistenceInterlocks141& g,
                            uint32_t ms) {
    if(state_!=Persist141::ReadbackPending) return false;
    const bool pass = genuine_read_only_eeprom_read &&
          eeprom_payload_integrity_ok && all_settings_preserved &&
          safe_to_write(g) &&
          MeshTransaction::same_bytes(stored,expected_) &&
          seq.controller.phase()==Phase::Verify &&
          seq.controller.pending()==Action::VerifyEEPROM;
    seq.controller.ack(Action::VerifyEEPROM,pass,ms);
    state_=pass && seq.controller.phase()==Phase::Success
        ? Persist141::Verified : Persist141::EEPROMUncertain;
    return pass;
  }

  // If any safety condition is lost after the EEPROM write began, the EEPROM
  // must be treated as UNCERTAIN. No second automatic save/retry is allowed.
  void invalidate() {
    if(state_==Persist141::Unarmed || state_==Persist141::Verified) return;
    state_=write_started_ ? Persist141::EEPROMUncertain : Persist141::FailedBeforeWrite;
  }
 private:
  MeshImage expected_{};
  Persist141 state_=Persist141::Unarmed;
  bool write_started_=false;
};
} // namespace sv04
