# SV04 NEXT Stand 145 – EEPROM-Layout: echte Leseindizes statt geratener Offsets

Status: NUR QUELLCODE / HOST-TESTS. NICHT INSTALLIEREN, KEIN FLASH, KEIN M500.

## Erkenntnis

`SettingsData` in Sovol `Marlin/src/module/settings.cpp` (geprüfter Stand `1867fcba75354a5c65e0631d6972dd19f1bd6cbe`) beschreibt Reihenfolge und Feldgrößen. **Compiler-Offsets (`offsetof`) sind nicht zwangsläufig die seriellen EEPROM-Adressen**: Die Marlin-Makros schreiben jedes Feld mit dem fortlaufenden `eeprom_index`; C++-Padding zwischen `grid_max_y` und `bilinear_grid_spacing` kann die Strukturposition verschieben. Ein statisch behaupteter Mesh-Offset wäre unsicher.

## Neue Dateien

- `settings_layout145_inject.py`: instrumentiert ausschließlich eine **separat bereitgestellte, editierbare Kopie** von `Marlin/src/module/settings.cpp` im `_load()`-Pfad. Zeichnet den bestehenden `eeprom_index` vor dem Lesen von `grid_max_x`, `grid_max_y`, `bilinear_grid_spacing`, `bilinear_start` und `z_values` auf. Gibt nur bei erfolgreiche `_load()`-CRC-Prüfung die `verified_load`-Markierung. Erzeugt selbst **keinen zusätzlichen EEPROM-Lese- oder Schreibaufruf**. Kein M500/M501. Die Daten werden zunächst nur in einer C++-Variable gehalten; für einen tatsächlich auslesbaren Report wird eine später zu entwickelnde serielle Diagnoseausgabe benötigt.
- `eeprom_layout145.h`: unabhängiger Host-Prüfer für einen künftig authentisch ermittelten Layoutbericht. Checks für Version V85, EEPROM-Offset 100, 4×4 Float32-Mesh, Feldfolge und Größen, Ausdehnung des EEPROM-Bildes und Build-Fingerabdruck. Geht bei jeder Unklarheit auf *Refused*.
- `test145.cpp`: synthetische Szenarien. `test145_injection.py`: Patch-Insertion und Doppelpatch-Abwehr.

## Sicherheitsgrenzen

1. Die `verified_load`-Markierung bestätigt nur Marlins bereits erfolgte Validierung. Sie ist **kein Nachweis der korrekt geladenen physischen Flash-Kopie**, wenn der EEPROM-Treiber falsch arbeitet. Zusätzliche Hardware-/Backendprüfung bleibt erforderlich.
2. In `_load()` wird der vorhandene Lesepfad instrumentiert. Ein Firmware-Build ist **noch nicht erfolgt**. Die C++-Symbole können erst nach Build und Integrationsprüfung als kompatibel gelten.
3. `eeprom_layout145.h` verwendet einen nicht kryptografischen Fingerabdruck. Er verhindert offensichtliche Verwechslungen, authentifiziert aber nichts. Die Flags `source_build_generated` und `flash_driver_verified` dürfen niemals durch einen bloßen Host-Test automatisch als Beweis gelten.
4. Selbst korrekter Mesh-Inhalt und CRC beweisen **keine erfolgreiche physische BLTouch-Messung**.
5. `MarlinSettings::save()` / `M500` erfasst andere Einstellungen ebenfalls; Flash-Write kann unterbrochen werden. Weiterhin **keine Schreibfreigabe**.

## Verifikation

- `test145.cpp`: 169 Host-Prüfaussagen erfolgreich (synthetische Offsets; kein EEPROM-Zugriff).
- `test145_injection.py`: Patch-Smoketest und Wiederholschutz erfolgreich.
- 15 vorhandene Regressionstestprogramme aus 135–144 erfolgreich ausgeführt.
- Keine Prüfung gegen tatsächlich gebaute STM32F103-Firmware und keine physische Druckerprobe.

## Nächster Schritt

Quellcode in einer echten SV04-Marlin-Buildumgebung kompilieren, `sv04_layout145::captured` nach erfolgreicher `_load()` über einen **rein lesenden Diagnoseweg** ausgeben, mit actual `PersistentStore`-Backend und der vorliegenden V85-CRC abgleichen. Besonders Speicherlayout-Padding und fehlende `EEPROM_FINISH`-Fehlerweitergabe begutachten. Erst nach unabhängiger Hardwarevalidierung eine Speicherstrategie planen.
