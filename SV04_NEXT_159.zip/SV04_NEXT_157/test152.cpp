#include "sd_coexist152.h"
#include <cassert>
#include <cstdio>
#include <map>
using namespace sv04;
static unsigned tests=0;
#define T(x) do {++tests;if(!(x)){std::fprintf(stderr,"FAIL %d %s\n",__LINE__,#x);return 1;}}while(0)
struct Ow: SdOwnership151 {SdSnapshot151 state;bool lease=false,deny=false;unsigned acquired=0,released=0;
  SdSnapshot151 snapshot()const override{return state;}
  bool try_acquire_exclusive_read()override{++acquired;if(deny||lease)return false;lease=true;return true;}
  void release_exclusive_read()override{++released;lease=false;}
};
struct Port: SdPort150 {Ow* o;uint64_t epoch=3;std::map<unsigned,std::vector<uint8_t>> files;
  bool mounted()const override {return o->state.mounted;}
  uint64_t mount_epoch()const override{return epoch;}
  bool read_exact(unsigned i,size_t limit,std::vector<uint8_t>& v)override{
    if(!o->lease)return false;
    auto it=files.find(i);
    if(it==files.end()||it->second.size()>limit)return false;
    v=it->second;return true;
  }
};
int main(){
  Ow o;o.state.mounted=true;o.state.mount_epoch=3;o.state.media_generation=9;o.state.card_identity_verified=true;
  Port p;p.o=&o;Backup149 b{55,66,1,std::vector<uint8_t>(128,0xAB)};
  p.files[0]=encode149(b);p.files[1]=commit149(b);
  SdCoexist152 s;
  T(s.start(o.state,1000));T(s.poll(o,p,55,66,128,1000)==SdJob152::ScannedUntrusted);
  T(s.counters().scans==1);T(o.acquired==1);T(o.released==1);T(!o.lease);
  T(!SdCoexist152::permits_m500());T(!SdCoexist152::permits_sd_write());T(!SdCoexist152::permits_flash_restore());
  // busy states must be deferred with absolutely no acquire
  for(int mode=0;mode<8;++mode){
    SdCoexist152 x;auto init=o.state;T(x.start(init,2000));
    switch(mode){case 0:o.state.print_active=true;break;case 1:o.state.print_paused=true;break;
      case 2:o.state.file_open=true;break;case 3:o.state.saving=true;break;
      case 4:o.state.logging=true;break;case 5:o.state.recovery_busy=true;break;
      case 6:o.state.media_change_pending=true;break;case 7:o.state.other_io_busy=true;break;}
    auto before=o.acquired;
    T(x.poll(o,p,55,66,128,2000)==SdJob152::Deferred);T(o.acquired==before);
    T(x.counters().deferrals==1);T(x.poll(o,p,55,66,128,2100)==SdJob152::Deferred);
    o.state=init;
    T(x.poll(o,p,55,66,128,2250)==SdJob152::ScannedUntrusted);
    T(o.acquired==o.released);
  }
  // Event-driven invalidation (all known SD/PLR/media events).
  for(int i=0;i<=static_cast<int>(SdEvent152::GlobalReset);++i){
    SdCoexist152 x;T(x.start(o.state,3000));x.on_event(static_cast<SdEvent152>(i));
    T(x.state()==SdJob152::Cancelled);auto before=o.acquired;
    T(x.poll(o,p,55,66,128,3000)==SdJob152::Cancelled);T(o.acquired==before);
  }
  // Changing epochs and media identity cancels any pending request.
  for(int i=0;i<2;++i){SdCoexist152 x;T(x.start(o.state,4000));
    if(i)o.state.media_generation++;else o.state.mount_epoch++;
    T(x.poll(o,p,55,66,128,4000)==SdJob152::Cancelled);
    o.state.mount_epoch=3;o.state.media_generation=9;
  }
  // Lock contention: bounded attempt count, and no media interruption.
  {SdCoexist152 x;T(x.start(o.state,5000,2));o.deny=true;
   T(x.poll(o,p,55,66,128,5000)==SdJob152::Deferred);
   T(x.poll(o,p,55,66,128,5250)==SdJob152::Deferred);
   T(x.poll(o,p,55,66,128,5500)==SdJob152::Rejected);
   o.deny=false;T(!o.lease);}
  // Missing or damaged backup is rejected, never silently restored.
  {SdCoexist152 x;T(x.start(o.state,6000));p.files[0][0]^=7;
   T(x.poll(o,p,55,66,128,6000)==SdJob152::Rejected);
   T(!SdCoexist152::permits_flash_restore());p.files[0][0]^=7;}
  // Backwards clock and 30-second expiry must be terminal.
  {SdCoexist152 x;T(x.start(o.state,10000));T(x.poll(o,p,55,66,128,9999)==SdJob152::Expired);}
  {SdCoexist152 x;T(x.start(o.state,10000));T(x.poll(o,p,55,66,128,40001)==SdJob152::Expired);}
  // All possible starting conditions: reject untrusted session identities.
  for(int i=0;i<3;++i){SdCoexist152 x;auto bad=o.state;
    if(i==0)bad.mount_epoch=0;
    if(i==1)bad.media_generation=0;
    if(i==2)T(!x.start(bad,1000,0));else T(!x.start(bad,1000));}
  // A large matrix of simulated busy/resume decisions.
  for(unsigned i=0;i<500;++i){SdCoexist152 x;T(x.start(o.state,100000+i*100));
    auto prior=o.acquired;
    if(i%3==0)o.state.file_open=true;
    if(i%3==1)o.state.recovery_busy=true;
    if(i%3==2)o.state.print_paused=true;
    T(x.poll(o,p,55,66,128,100000+i*100)==SdJob152::Deferred);
    T(o.acquired==prior);o.state.file_open=o.state.recovery_busy=o.state.print_paused=false;
    T(x.poll(o,p,55,66,128,100250+i*100)==SdJob152::ScannedUntrusted);
    T(!o.lease);
  }
  std::printf("test152 PASS: %u assertions\n",tests);
}
