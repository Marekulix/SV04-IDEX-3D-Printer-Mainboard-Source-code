#include "sd_guarded_slice157.h"
#include <cstdio>
using namespace sv04;
struct Port: ReadPort157 {
  SdContext157 s{};bool fail=false;bool switch_during=false;bool start_print=false;
  unsigned reads=0;
  SdContext157 context()const override{return s;}
  bool read_exact(uint32_t offset,uint8_t* dst,size_t n)override{
    ++reads;
    for(size_t i=0;i<n;i++)dst[i]=static_cast<uint8_t>((offset+i)&255);
    if(switch_during)++s.media_epoch;
    if(start_print)s.printing=true;
    return !fail;
  }
};
int main(){
  int n=0;
  #define CHECK(e) do{++n;if(!(e)){fprintf(stderr,"157 fail line %d: %s\n",__LINE__,#e);return 1;}}while(0)
  Port p;p.s.mounted=true;p.s.media_epoch=7;p.s.generation=1;p.s.hardware_identity_verified=true;
  SharedMedia156 m;m.test_only_enable_diagnostics(true);
  GuardedSlice157 scan(m,p);uint8_t buf[64]{};
  CHECK(scan.tick(100,buf,64)==Slice157::Ok);CHECK(p.reads==1);CHECK(buf[0]==100);CHECK(buf[63]==163);
  CHECK(m.owner()==MediaOwner156::None);
  p.s.print_file_open=true;CHECK(scan.tick(0,buf,1)==Slice157::Deferred);CHECK(p.reads==1);
  p.s.print_file_open=false;p.s.paused=true;CHECK(scan.tick(0,buf,1)==Slice157::Deferred);
  p.s.paused=false;p.s.recovery_busy=true;CHECK(scan.tick(0,buf,1)==Slice157::Deferred);
  p.s.recovery_busy=false;p.s.logging_busy=true;CHECK(scan.tick(0,buf,1)==Slice157::Deferred);
  p.s.logging_busy=false;p.s.hardware_identity_verified=false;CHECK(scan.tick(0,buf,1)==Slice157::Deferred);
  p.s.hardware_identity_verified=true;CHECK(scan.tick(0,buf,65)==Slice157::Invalid);CHECK(scan.terminated());
  for(int scenario=0;scenario<3;scenario++){
    Port v;v.s=p.s;v.fail=(scenario==0);v.switch_during=(scenario==1);v.start_print=(scenario==2);
    SharedMedia156 g;g.test_only_enable_diagnostics(true);GuardedSlice157 x(g,v);
    uint8_t b[64];for(auto &z:b)z=0xEE;
    CHECK(x.tick(3,b,32)==Slice157::Cancelled);
    CHECK(x.terminated());CHECK(v.reads==1);CHECK(g.owner()==MediaOwner156::None);
    for(unsigned i=0;i<64;i++)CHECK(b[i]==0xEE);
    CHECK(x.tick(0,b,1)==Slice157::Cancelled);
  }
  for(int i=1;i<=64;i++){
    Port v;v.s=p.s;SharedMedia156 g;g.test_only_enable_diagnostics(true);
    GuardedSlice157 x(g,v);uint8_t b[64]{};
    CHECK(x.tick(i,b,i)==Slice157::Ok);
    CHECK(v.reads==1);CHECK(g.owner()==MediaOwner156::None);
    for(int j=0;j<i;j++)CHECK(b[j]==((i+j)&255));
  }
  CHECK(!GuardedSlice157::production_ready());CHECK(!GuardedSlice157::permits_m500());
  std::printf("SV04 NEXT 157 %d checks passed. Host only.\n",n);
}
