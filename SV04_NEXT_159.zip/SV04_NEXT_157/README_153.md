# SV04 NEXT 153: kooperativer 64-Byte-SD-Leser (HOST-PROTOTYP)

**Stand:** 2026-11-06  
**Sicherheit:** NICHT INSTALLIEREN. Keine echte Marlin-Anbindung, keine Freigabe von `M500`, SD-Schreiben oder EEPROM-Wiederherstellung.

## Tatsächlich implementiert
- `sd_incremental153.h`: Zustandsmaschine zum Lesen von 4 festen Sicherungsdateien (Abbild/Commit für Slot A und B), jeweils zweimal, in höchstens **64 Datenbytes je `poll()`**.
- `SdSlicePort153::read_slice` ist eine **Schnittstellenanforderung**, kein STM32- oder SdFat-Treiber. Ein realer Adapter muss pro Aufruf Datei öffnen, zum Offset springen, maximal 64 Byte lesen und schließen, und dabei stets dieselbe gemeinsame Exklusivsperre wie SD-Druck, Upload, Verzeichnisliste und Power-Loss-Recovery verwenden.
- Jeder `poll()` erwirbt die Exklusivsperre nur für **einen** Leseschritt; ein RAII-Objekt gibt sie auch bei Fehlern frei. Es gibt **keine** angehaltene Dateiverbindung und keine über Poll-Aufrufe gehaltene Sperre.
- Prüfung vor und nach dem Leseschritt auf Mount-Epoche, Mediengeneration, bekannte Medienidentität und Busy-Flags. Medienwechsel, ungültige Längen und widersprüchliche Kopien verwerfen das Ergebnis.
- Das Ergebnis bleibt auch bei gültigen Sicherungen `ValidUntrustedMedia` und erzeugt **keine** Schreib- oder Wiederherstellungsberechtigung.
- Maximal 30 Sekunden Laufzeit pro Diagnose. Leerlauf-/Prioritätsflags stellen den Scan zurück. Der echte Treiber darf die Druckersteuerung keinesfalls für eine ganze Datei blockieren.

## Tests
- `test153.cpp`: **490 Prüfaussagen**, **40 begrenzte Leseschritte** im Referenzlauf. Mit `g++ -std=c++17 -Wall -Wextra -Werror -fsanitize=address,undefined` lokal bestanden.
- **23** C++-Testprogramme aus 135–153 wurden auf dem Host übersetzt und ausgeführt; beide Python-Skripte `test145_injection.py`, `test146.py` bestanden.
- Es fand kein Marlin-Firmware-Build und kein physischer SD- oder Stromausfalltest statt.

## Einschränkungen
1. `SdOwnership151` muss in der echten Firmware als **gemeinsamer atomarer Lock aller SD-Verbraucher** umgesetzt werden. Ein isolierter Lock nur dieses Adapters wäre wirkungslos.
2. Der SD-Treiber darf in `read_slice` nicht intern große ununterbrechbare Operationen oder schreibende Wartungsaktionen durchführen. Das ist noch nicht nachgewiesen.
3. Die Medienkennung ist bislang simuliert, keine unabhängige Identität. `ValidUntrustedMedia` ist **nicht** vertrauenswürdige Recovery-Freigabe.
4. Dateiinhalt und die exakte Dateilänge werden über zwei Durchgänge geprüft. SD-Haltbarkeit bei Stromausfall ist **nicht** bewiesen.
5. Die Basismodule 149–152 bleiben unverändert; der neue Leser ersetzt den synchronen Scan aus 152 im Modell noch nicht vollständig. Eine Verbindungsbrücke ist als nächster Entwicklungsschritt nötig.
6. EEPROM-Abbild, Marlin-CRC, reales Mesh-Layout und T0/T1-Kollisionsfreiheit brauchen weiterhin Hardware-/Build-Nachweise.

**Nächster Schritt 154:** Den neuen `SdIncremental153`-Leser in den Koexistenz-Scheduler 152 einbinden, ohne dessen synchronen Komplettscan aufzurufen. Bis dahin weiter nur Host-Prototyp.
