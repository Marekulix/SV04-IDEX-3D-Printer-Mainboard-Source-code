# SV04 NEXT 151 – SD-Zugriffssperre (nur Host-Prototyp)
Stand: 2026-11-06 | NICHT INSTALLIEREN

## Ergebnis
- `sd_exclusive151.h`: fehlerverweigernde Lese-Freigabe auf Basis des Stand-150-Adapters.
- `test151.cpp`: 490 Prüfungen inklusive Pausendruck, geöffneter Datei, Protokollierung,
  Power-Loss-Recovery-Zugriff, Karten-/Epochwechsel, abgewiesener Sperre und falscher Datenlänge.
- Alle 20 bestehenden C++-Tests und zwei Python-Tests aus Stand 150 bestanden erneut.
- Keine echte SD-Karte, kein EEPROM, keine Motoren oder Heizung angesprochen.

## Originalquelle und nachgewiesene Zustände
Sovol3d/SV04-IDEX-3D-Printer-Mainboard-Source-code,
Commit 1867fcba75354a5c65e0631d6972dd19f1bd6cbe,
`Marlin/src/sd/cardreader.h`:
`card.isMounted()`, `card.isPrinting()`, `card.isPaused()`, `card.isFileOpen()`.
`isPaused()` kann bei geöffneter Datei true sein, auch wenn `isPrinting()` false ist.
Auch Save/Log, Power-Loss-Recovery und andere Nutzer des Speichermediums müssen berücksichtigt werden.

## Sicherheitsgrenze
Die verwendete `SdOwnership151`-Schnittstelle ist EIN VERTRAG, keine echte Marlin-Sperre.
Der Sovol-Quellstand stellt hier noch keine atomare, alle SD-Clients umfassende Lease bereit.
Eine zukünftige Integration MUSS alle SD-Dateizugriffe, Medienwechsel, SD-Druck,
Power-Loss-Recovery, Uploads und Verzeichniszugriffe über dieselbe Sperre serialisieren.
Außerdem muss die Medienidentität hardwaregestützt und vertrauenswürdig bestimmt werden.
`mount_epoch` ist keine Seriennummer der SD-Karte.

Ein Scan kann diagnostisch gültige Daten anzeigen, aber niemals EEPROM-Schreiben,
SD-Schreiben oder automatische EEPROM-Reparatur freigeben.
Stromausfallbeständigkeit, echtes `sync()`, echte Recovery- und Flash-Restore-Pfade
sind NICHT nachgewiesen. Das Verfahren eignet sich NICHT als fertiges Firmware-Patch.

## Lokaler Test
`g++ -std=c++17 -Wall -Wextra -Werror test151.cpp -o test151 && ./test151`

## Nächster Angriff 152
Echte Marlin-Koexistenzarchitektur für SDSUPPORT und Power-Loss-Recovery
analysieren; eventbasierte, nicht blockierende Diagnose bevorzugen. Kein `M500`.
