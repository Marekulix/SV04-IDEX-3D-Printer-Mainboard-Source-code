#!/usr/bin/env python3
from pathlib import Path
import tempfile, subprocess, sys
from validate_diagnostic146 import parse_report, Refused
root=Path(__file__).parent
checks=0
def check(cond):
 global checks
 checks+=1
 assert cond

def report(**over):
 fields={'protocol':1,'version':'V85','verified':1,'capacity':4096,'settings_size':800,'header_offset':100,
         'grid_x':300,'grid_y':301,'spacing':302,'origin':310,'mesh':318,'xy_bytes':8,'mesh_bytes':64}
 fields.update(over)
 return '\n'.join(['echo:SV04_LAYOUT146 BEGIN']+['echo:SV04_LAYOUT146 '+k+'='+str(v) for k,v in fields.items()]+['echo:SV04_LAYOUT146 END'])

def refused(s):
 try: parse_report(s)
 except Refused:return True
 return False
check(parse_report(report())['eeprom_write_permitted'] is False)
check(parse_report(report())['flash_driver_verified'] is False)
check(parse_report(report())['source_build_generated'] is False)
for k,v in [('verified',0),('protocol',2),('version','V84'),('capacity',200),('settings_size',5000),('header_offset',101),('grid_x',101),('grid_y',302),('spacing',304),('origin',309),('mesh',319),('xy_bytes',4),('mesh_bytes',60)]:
 check(refused(report(**{k:v})))
check(refused(report()+'\n'+report()))
check(refused(report().replace('SV04_LAYOUT146 END','')))
check(refused(report().replace('SV04_LAYOUT146 BEGIN','SV04_LAYOUT146 ERROR')))
check(refused(report().replace('SV04_LAYOUT146 mesh=318','SV04_LAYOUT146 mesh=318\nSV04_LAYOUT146 mesh=318')))
check(refused(report().replace('SV04_LAYOUT146 mesh=318','SV04_LAYOUT146 mesh=-1')))
check(refused(report().replace('SV04_LAYOUT146 mesh=318','SV04_LAYOUT146 mesh=4294967296')))
check(refused(report().replace('SV04_LAYOUT146 mesh=318','SV04_LAYOUT146 mesh=318\nSV04_LAYOUT146 foo=1')))
with tempfile.TemporaryDirectory() as td:
 p=Path(td)/'settings.cpp'; a=(root/'test145_injection.py').read_text();
 # Reuse the exact synthetically staged fixture from test145.
 import ast
 tree=ast.parse(a)
 fixture=next(x.value.value for x in tree.body if isinstance(x,ast.Assign) and any(isinstance(y,ast.Name) and y.id=='source' for y in x.targets))
 p.write_text(fixture)
 u=subprocess.run([sys.executable,str(root/'settings_layout145_inject.py'),str(p)],capture_output=True,text=True)
 check(u.returncode==0)
 v=subprocess.run([sys.executable,str(root/'settings_diagnostic146_inject.py'),str(p)],capture_output=True,text=True)
 check(v.returncode==0)
 s=p.read_text()
 check('SV04_NEXT_146_DIAGNOSTIC_BEGIN' in s)
 check('SV04_LAYOUT146 verified=' in s)
 check('defined(SV04_NEXT_LAYOUT146_DIAGNOSTICS)' in s)
 check('SERIAL_ECHO_MSG' in s)
 check('M500' not in s and 'M501' not in s)
 check('persistentStore.read_data' not in s and 'persistentStore.write_data' not in s)
 check(s.count('EEPROM_FINISH()')==1)
 check(subprocess.run([sys.executable,str(root/'settings_diagnostic146_inject.py'),str(p)],capture_output=True).returncode!=0)
 p.write_text(fixture)
 check(subprocess.run([sys.executable,str(root/'settings_diagnostic146_inject.py'),str(p)],capture_output=True).returncode!=0)
print(f'SV04 NEXT 146: {checks} independent host assertions PASS (synthetic; no firmware build)')
