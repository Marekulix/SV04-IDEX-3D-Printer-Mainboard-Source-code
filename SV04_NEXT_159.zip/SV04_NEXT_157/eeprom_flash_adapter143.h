#pragma once
// SV04 NEXT 143, HOST-TESTED REFERENCE CONTRACT. NOT FIRMWARE. NO EEPROM WRITES.
// Access to a concrete platform driver is gated by an independently verified profile.
// Entire memory image is copied in fixed-size blocks to an independent durable archive.
// NO std::vector, dynamic allocation, settings.load/save, M500/M501.
#include <cstddef>
#include <cstdint>

namespace sv04 {
constexpr size_t kBlock143 = 64;
constexpr size_t kMax143 = 65536;
constexpr uint32_t kMagic143 = 0x53563433u;

struct FlashRead143 {
  virtual ~FlashRead143() = default;
  // True only after inspecting compiled target, active #if branch and actual driver!
  virtual bool certified_flash_read_without_write() const = 0;
  virtual size_t capacity() const = 0;
  virtual bool begin_read() = 0;
  // Return true for success. Adapter must invert PersistentStore::read_data error convention.
  virtual bool read_at(size_t offset, uint8_t* dst, size_t len) = 0;
  // Return true for success. Adapter must implement backend-specific finish semantics.
  virtual bool end_read() = 0;
};
struct SeparateStorage143 {
  virtual ~SeparateStorage143() = default;
  virtual bool independent_durable_and_readable() const = 0;
  virtual bool begin_archive(size_t capacity) = 0;
  virtual bool write_block(size_t offset, const uint8_t* data, size_t len) = 0;
  virtual bool finish_archive() = 0;
  virtual bool begin_verify() = 0;
  virtual bool read_archive(size_t offset, uint8_t* dst, size_t len) = 0;
  virtual bool end_verify() = 0;
};

inline uint32_t crc_feed143(uint32_t crc, const uint8_t* p, size_t n) {
  for(size_t i=0; i<n; ++i) {
    crc ^= p[i];
    for(unsigned j=0; j<8; ++j) crc=(crc>>1) ^ (0xEDB88320u & (0u-(crc&1u)));
  }
  return crc;
}
inline bool same143(const uint8_t* a, const uint8_t* b, size_t n) {
  uint8_t diff=0; for(size_t i=0;i<n;i++)diff|=a[i]^b[i]; return diff==0;
}

enum class BackupResult143 : uint8_t { NotRun, Verified, Refused, ReadError, ArchiveError, DriftDetected };
class FullFlashBackup143 {
public:
  BackupResult143 result() const { return result_; }
  bool verified() const { return result_==BackupResult143::Verified; }
  uint32_t digest() const { return verified() ? digest_ : 0; }
  size_t size() const { return verified() ? size_ : 0; }
  bool capture(FlashRead143& flash, SeparateStorage143& store,
               bool idle, bool writers_locked, bool motion_stopped) {
    // Single-use: retry requires explicit re-creation of the backup transaction.
    if(result_!=BackupResult143::NotRun) return false;
    result_=BackupResult143::Refused;
    if(!idle || !writers_locked || !motion_stopped ||
       !flash.certified_flash_read_without_write() ||
       !store.independent_durable_and_readable()) return false;
    const size_t n=flash.capacity();
    if(n<128 || n>kMax143 || n%4!=0) return false;
    size_=n;
    if(!store.begin_archive(n)) return set_failure(BackupResult143::ArchiveError);
    if(!flash.begin_read()) return set_failure(BackupResult143::ReadError);
    uint8_t block[kBlock143]; uint32_t crc=0xFFFFFFFFu;
    for(size_t offset=0; offset<n; offset+=kBlock143) {
      const size_t len=(n-offset<kBlock143)?n-offset:kBlock143;
      if(!flash.read_at(offset,block,len)) {
        (void)flash.end_read(); return set_failure(BackupResult143::ReadError);
      }
      crc=crc_feed143(crc,block,len);
      if(!store.write_block(offset,block,len)) {
        (void)flash.end_read(); return set_failure(BackupResult143::ArchiveError);
      }
    }
    if(!flash.end_read()) return set_failure(BackupResult143::ReadError);
    if(!store.finish_archive()) return set_failure(BackupResult143::ArchiveError);
    if(!store.begin_verify()) return set_failure(BackupResult143::ArchiveError);
    if(!flash.begin_read()) {
      (void)store.end_verify();return set_failure(BackupResult143::ReadError);
    }
    uint8_t recovered[kBlock143]; uint32_t verification_crc=0xFFFFFFFFu;
    bool same=true, read_good=true, archive_good=true;
    for(size_t offset=0; offset<n; offset+=kBlock143) {
      const size_t len=(n-offset<kBlock143)?n-offset:kBlock143;
      if(!flash.read_at(offset,block,len)) {read_good=false;break;}
      if(!store.read_archive(offset,recovered,len)) {archive_good=false;break;}
      same = same && same143(block,recovered,len);
      verification_crc=crc_feed143(verification_crc,recovered,len);
    }
    const bool flash_done=flash.end_read();
    const bool archive_done=store.end_verify();
    if(!read_good || !flash_done) return set_failure(BackupResult143::ReadError);
    if(!archive_good || !archive_done) return set_failure(BackupResult143::ArchiveError);
    if(!same || verification_crc!=crc) return set_failure(BackupResult143::DriftDetected);
    result_=BackupResult143::Verified; digest_=~crc;return true;
  }
private:
  bool set_failure(BackupResult143 e) {result_=e;size_=0;digest_=0;return false;}
  BackupResult143 result_=BackupResult143::NotRun;
  size_t size_=0; uint32_t digest_=0;
};
} // namespace sv04
