#pragma once
// Contract adapter for a verified STM32F1 FLASH_EEPROM_EMULATION PersistentStore.
// Header is host-compilable; no device flash access is performed by included tests.
// IMPORTANT: do not supply backend_verified=true until target build and active
// preprocessor path prove that access_finish() cannot write after read-only calls.
#include "eeprom_flash_adapter143.h"
#include <limits>
namespace sv04 {
template<class PersistentStoreApi>
class FlashBackend143 final : public FlashRead143 {
public:
  explicit FlashBackend143(bool backend_verified):verified_(backend_verified){}
  bool certified_flash_read_without_write()const override{return verified_;}
  size_t capacity()const override{return PersistentStoreApi::capacity();}
  bool begin_read()override {return PersistentStoreApi::access_start();}
  bool end_read()override {return PersistentStoreApi::access_finish();}
  bool read_at(size_t offset,uint8_t* p,size_t len)override {
    if(offset>static_cast<size_t>(std::numeric_limits<int>::max())||
       len>static_cast<size_t>(std::numeric_limits<int>::max())-offset) return false;
    int pos=static_cast<int>(offset);uint16_t crc=0;
    // In the Marlin API, true means READ ERROR. `writing=true` copies data to dst,
    // despite its confusing name; false merely hashes without populating dst.
    return !PersistentStoreApi::read_data(pos,p,len,&crc,true) && pos==static_cast<int>(offset+len);
  }
private:
  bool verified_;
};
} // namespace sv04
