# SV04 NEXT 142 – Punkt 3: Vollständige EEPROM-Sicherung (Host-Prototyp)

**KEINE INSTALLATION. Keine echten EEPROM-Zugriffe. Kein M500, kein M501.**

## Gegen originalen Sovol-Code geprüft

Originalstand `Sovol3d/SV04-IDEX-3D-Printer-Mainboard-Source-code`, Commit `1867fcba75354a5c65e0631d6972dd19f1bd6cbe`:
- `Marlin/src/module/settings.cpp`: `MarlinSettings::save()` schreibt die Einstellungen insgesamt, nicht nur 16 Mesh-Werte. Die Datei enthält `EEPROM_VERSION "V85"` und EEPROM-CRC-Felder.
- `MarlinSettings::_load()` liest die Persistenz und kann bei nicht nur validierendem Aufruf den RAM-Zustand verändern. Darum **kein M501 als Read-only-Prüfung**.
- HAL-Backend `persistentStore.read_data()` existiert, allerdings muss das konkrete EEPROM-Backend vor Einsatz darauf überprüft werden, dass sowohl die Lese- als auch Zugriff-Start-/Ende-Aufrufe tatsächlich keine Schreib- oder Emulationsnebenwirkung besitzen.

## Implementiert

`eeprom_backup142.h` ist ein ***Host-seitiger*** Anbieter-/Speicherziel-Vertrag:

1. Quelle muss ihren Read-only-Status unabhängig belegen; Ziel muss ein **physisch unabhängiger, dauerhafter Speicher** sein. Reine RAM-Kopien sind verboten.
2. Kapazität prüfen (128 bis 65.536 Byte als Modellgrenzen, **keine Aussage zur SV04-Kapazität**).
3. Gesamtes Quellabbild zweimal auslesen, Byte für Byte vergleichen.
4. Archive mit Versionskopf, Längenfeld und zwei CRC-32-Prüfsummen erzeugen. **CRC dient der Fehlererkennung, nicht Manipulationsschutz oder Stromausfallsicherheit.**
5. Die gespeicherte Datei wieder aus dem unabhängigen Ziel lesen und vergleichen, dann Quelle ein drittes Mal lesen und auf Drift prüfen.
6. Bei jedem Fehler permanent sperren. Kein automatischer EEPROM-Schreib- oder Wiederherstellungsversuch.
7. Stand 141 bleibt zusätzlich schreibgesperrt, solange der unabhängige **Read-only-Dekoder für das vollständige gespeicherte Konfigurationslayout** fehlt.

## Getestet

- `test142.cpp`: **4171 Aussagen bestanden** (C++17, AddressSanitizer/UBSan).
- `test141.cpp`: **954 Aussagen bestanden** (AddressSanitizer/UBSan).
- Neun Regressionstests aus 135–140 lokal erneut bestanden.

## Wesentliche offene Punkte

- Konkreter STM32-EEPROM-Emulationstreiber / zugelassene lesende API; keine Seiteneffekte auch beim `access_finish()`.
- Tatsächliche Kapazität/Version/CRC und den Speicherort für eine physisch unabhängige dauerhafte Sicherung bestimmen.
- Einen schreibgeschützten Dekoder implementieren, der alle relevanten EEPROM-Konfigurationswerte, Version und Original-CRC prüft und nach dem Speichern die **unveränderten anderen Einstellungen** nachweist. Der Host-Archiv-CRC allein erfüllt das nicht.
- Verifizierter Wiederherstellungspfad nach fehlerhaftem `settings.save()`; selbst ein Backup bedeutet nicht, dass eine teilweise geschriebene Flash-Seite automatisch gerettet werden kann.
- Vollständiger STM32-Build, IDEX-/BLTouch-/Thermal-Hardwaretests und Stromausfallversuche.

**Sicherheitsentscheidung:** Der eigentliche `M500`-Schreibvorgang bleibt gesperrt. Kein Benutzer darf dieses Archiv auf dem Drucker flashen.
