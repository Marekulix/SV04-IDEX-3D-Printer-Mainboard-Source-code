#pragma once
// SV04 NEXT 149: host-only two-slot SD backup protocol model.
// NOT a Marlin filesystem implementation, NOT power-loss certified.
// No EEPROM writes, no M500, no automatic flash restoration.
#include <array>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace sv04 {
inline uint32_t crc32_149(const uint8_t* ptr, size_t n) {
  uint32_t crc=0xffffffffu;
  for(size_t j=0;j<n;++j){ crc^=ptr[j]; for(int i=0;i<8;++i) crc=(crc>>1)^((crc&1u)?0xedb88320u:0u); }
  return ~crc;
}
inline void put32_149(std::vector<uint8_t>& v, uint32_t x){for(int i=0;i<4;++i)v.push_back(uint8_t(x>>(8*i)));}
inline bool get32_149(const std::vector<uint8_t>& v,size_t pos,uint32_t& x){
  if(pos>v.size()||v.size()-pos<4) return false;
  x=0;
  for(int i=0;i<4;++i) x|=uint32_t(v[pos+i])<<(8*i);
  return true;
}
struct Backup149 { uint32_t card_id=0, device_id=0, generation=0; std::vector<uint8_t> data; };
// Fixed binary header 24 bytes: tag, card, device, generation, size, checksum.
// A separate 20-byte commit record binds tag/card/device/generation/CRC.
inline std::vector<uint8_t> encode149(const Backup149& b){
  std::vector<uint8_t> v; v.reserve(24+b.data.size());
  put32_149(v,0x39343142u);put32_149(v,b.card_id);put32_149(v,b.device_id);
  put32_149(v,b.generation);put32_149(v,uint32_t(b.data.size()));
  put32_149(v,crc32_149(b.data.data(),b.data.size()));
  v.insert(v.end(),b.data.begin(),b.data.end());return v;
}
inline std::vector<uint8_t> commit149(const Backup149& b){
  std::vector<uint8_t> v;put32_149(v,0x39343143u);put32_149(v,b.card_id);
  put32_149(v,b.device_id);put32_149(v,b.generation);
  put32_149(v,crc32_149(b.data.data(),b.data.size()));return v;
}
inline bool decode149(const std::vector<uint8_t>& image,const std::vector<uint8_t>& commit,
                      uint32_t expected_card,uint32_t expected_device,size_t expected_size,Backup149& out){
  // Fail-closed and bound size before processing external input.
  if(image.size()<24 || commit.size()!=20 || expected_size==0 || expected_size>65536 ||
     image.size()!=expected_size+24)return false;
  uint32_t tag,cid,did,gen,len,crc,ctag,ccid,cdid,cgen,ccrc;
  if(!get32_149(image,0,tag)||!get32_149(image,4,cid)||!get32_149(image,8,did)||
     !get32_149(image,12,gen)||!get32_149(image,16,len)||!get32_149(image,20,crc)||
     !get32_149(commit,0,ctag)||!get32_149(commit,4,ccid)||!get32_149(commit,8,cdid)||
     !get32_149(commit,12,cgen)||!get32_149(commit,16,ccrc))return false;
  if(tag!=0x39343142u||ctag!=0x39343143u||cid!=expected_card||did!=expected_device||
     cid==0||did==0||gen==0||len!=expected_size||ccid!=cid||cdid!=did||cgen!=gen||ccrc!=crc)return false;
  const auto calc=crc32_149(image.data()+24,expected_size);
  if(calc!=crc)return false;
  out.card_id=cid;out.device_id=did;out.generation=gen;
  out.data.assign(image.begin()+24,image.end());return true;
}
struct Slot149 { std::vector<uint8_t> image, commit; };
struct Store149 { std::array<Slot149,2> slots; };
enum class Decision149:uint8_t { NoValidBackup, UniqueBackup, AmbiguousSameGeneration };
struct Selection149 {Decision149 decision=Decision149::NoValidBackup;int slot=-1;Backup149 backup;};
inline Selection149 select149(const Store149& s,uint32_t card,uint32_t device,size_t expected_size){
  Backup149 a,b; const bool va=decode149(s.slots[0].image,s.slots[0].commit,card,device,expected_size,a);
  const bool vb=decode149(s.slots[1].image,s.slots[1].commit,card,device,expected_size,b);
  Selection149 o;
  if(!va&&!vb)return o;
  if(va&&vb&&a.generation==b.generation){
    // Even equal bytes are ambiguous: commit uniqueness must be demonstrated.
    o.decision=Decision149::AmbiguousSameGeneration;return o;
  }
  o.decision=Decision149::UniqueBackup;
  o.slot=(!vb || (va && a.generation>b.generation))?0:1;
  o.backup=o.slot==0?a:b;return o;
}
// Host-only fail injection for every non-atomic step. It does not claim SD durability.
// Never modify current selected slot; write image, verify image, write commit, verify all.
enum class Stage149:uint8_t { BeforeWrite, AfterImagePartial, AfterImageComplete, AfterCommitPartial, AfterCommitComplete, Verified };
inline bool stage_backup149(Store149& s,const Backup149& next,Stage149 cutoff,size_t nbytes=0){
  if(next.card_id==0||next.device_id==0||next.generation==0||next.data.empty()||next.data.size()>65536)return false;
  auto current=select149(s,next.card_id,next.device_id,next.data.size());
  if(current.decision==Decision149::AmbiguousSameGeneration)return false;
  if(current.decision==Decision149::UniqueBackup && next.generation<=current.backup.generation)return false;
  const int target=(current.slot==0)?1:0;
  if(cutoff==Stage149::BeforeWrite)return false;
  Slot149& slot=s.slots[target];
  const auto blob=encode149(next), com=commit149(next);
  slot.commit.clear(); // invalidate inactive slot's old commit first
  if(cutoff==Stage149::AfterImagePartial){slot.image.assign(blob.begin(),blob.begin()+std::min(nbytes,blob.size()));return false;}
  slot.image=blob;
  if(cutoff==Stage149::AfterImageComplete)return false;
  if(cutoff==Stage149::AfterCommitPartial){slot.commit.assign(com.begin(),com.begin()+std::min(nbytes,com.size()-1));return false;}
  slot.commit=com;
  if(cutoff==Stage149::AfterCommitComplete)return false;
  Backup149 check;
  if(!decode149(slot.image,slot.commit,next.card_id,next.device_id,next.data.size(),check)||check.data!=next.data)return false;
  const auto selected=select149(s,next.card_id,next.device_id,next.data.size());
  return selected.decision==Decision149::UniqueBackup && selected.slot==target && selected.backup.data==next.data;
}
inline constexpr bool sd_powerloss_durability_proven149(){return false;}
inline constexpr bool automatic_restore_allowed149(){return false;}
inline constexpr bool automatic_m500_allowed149(){return false;}
}
