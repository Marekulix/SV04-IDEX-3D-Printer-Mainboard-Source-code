#pragma once
// SV04 NEXT 151: host-only, fail-closed shared SD ownership contract.
// Not a Marlin driver. No file or EEPROM writes. Integration requires an
// atomic lease shared with ALL card users, including PLR and background logs.
#include "sd_readonly150.h"
#include <cstdint>

namespace sv04 {
struct SdSnapshot151 {
  bool mounted=false, print_active=false, print_paused=false;
  bool file_open=false, saving=false, logging=false;
  bool recovery_busy=false, media_change_pending=false;
  bool card_identity_verified=false, other_io_busy=false;
  uint64_t mount_epoch=0, media_generation=0;
};

enum class SdGate151:uint8_t {
  Clear, Unmounted, UnknownMedia, BusyPrint, BusyFile,
  BusySaving, BusyRecovery, BusyMediaChange, BusyOther,
  LeaseDenied, StateChanged, ScanRejected
};

inline SdGate151 check_sd151(const SdSnapshot151 &s) {
  if (!s.mounted) return SdGate151::Unmounted;
  if (!s.mount_epoch || !s.media_generation || !s.card_identity_verified)
    return SdGate151::UnknownMedia;
  if (s.media_change_pending) return SdGate151::BusyMediaChange;
  if (s.print_active || s.print_paused) return SdGate151::BusyPrint;
  if (s.file_open) return SdGate151::BusyFile;
  if (s.saving || s.logging) return SdGate151::BusySaving;
  if (s.recovery_busy) return SdGate151::BusyRecovery;
  if (s.other_io_busy) return SdGate151::BusyOther;
  return SdGate151::Clear;
}

struct SdOwnership151 {
  virtual ~SdOwnership151() = default;
  // Acquire must atomically exclude ALL other SD clients, including PLR,
  // directory listing, uploads, media management, and recovery file access.
  virtual bool try_acquire_exclusive_read() = 0;
  virtual void release_exclusive_read() = 0;
  virtual SdSnapshot151 snapshot() const = 0;
};

inline bool same_sd_identity151(const SdSnapshot151& a,const SdSnapshot151& b){
  return a.mount_epoch==b.mount_epoch &&
         a.media_generation==b.media_generation &&
         a.card_identity_verified==b.card_identity_verified;
}

struct SdReport151 {
  SdGate151 gate=SdGate151::Unmounted;
  SdReport150 scan{};
  bool backup_readable_for_diagnostics=false;
  bool may_write_sd=false, may_write_eeprom=false, may_restore_eeprom=false;
};

inline SdReport151 scan_exclusive151(SdOwnership151& owner, SdPort150& port,
                                    uint32_t card_id,uint32_t device_id,size_t bytes){
  SdReport151 result;
  const auto before=owner.snapshot();
  result.gate=check_sd151(before);
  if(result.gate!=SdGate151::Clear)return result;
  if(!owner.try_acquire_exclusive_read()){
    result.gate=SdGate151::LeaseDenied;return result;
  }
  // RAII guarantees release even on future added early-return paths.
  struct Lease { SdOwnership151& owner; ~Lease(){owner.release_exclusive_read();} } lease{owner};
  const auto locked=owner.snapshot();
  if(check_sd151(locked)!=SdGate151::Clear ||
     !same_sd_identity151(before,locked) ||
     !port.mounted() || port.mount_epoch()!=locked.mount_epoch){
    result.gate=SdGate151::StateChanged;return result;
  }
  result.scan=scan_sd150(port,card_id,device_id,bytes);
  const auto after=owner.snapshot();
  if(check_sd151(after)!=SdGate151::Clear ||
     !same_sd_identity151(locked,after) ||
     !port.mounted() || port.mount_epoch()!=after.mount_epoch){
    result.gate=SdGate151::StateChanged;
    result.scan=SdReport150{};
    return result;
  }
  if(result.scan.status!=SdStatus150::ValidUntrustedMedia){
    result.gate=SdGate151::ScanRejected;return result;
  }
  result.gate=SdGate151::Clear;
  result.backup_readable_for_diagnostics=true;
  return result;
}
} // namespace sv04
