#!/usr/bin/env python3
"""Repeatable host-only regression runner for SV04 NEXT 135–157."""
from pathlib import Path
import subprocess, sys, json
root=Path(__file__).resolve().parent
results=[]
for src in sorted(root.glob('test*.cpp')):
    exe=Path('/tmp') / ('sv04next157_'+src.stem)
    cc=subprocess.run(['g++','-std=c++17','-O1','-Wall','-Wextra','-Werror','-fsanitize=undefined','-fno-omit-frame-pointer',str(src),'-o',str(exe)],capture_output=True,text=True)
    if cc.returncode:
        results.append({'test':src.name,'status':'COMPILE_FAIL','detail':cc.stderr[-2000:]})
        continue
    try:
        proc=subprocess.run([str(exe)],cwd=root,capture_output=True,text=True,timeout=25)
        results.append({'test':src.name,'status':'PASS' if proc.returncode==0 else 'FAIL','detail':(proc.stdout+proc.stderr)[-500:]})
    except Exception as exc:
        results.append({'test':src.name,'status':'ERROR','detail':str(exc)})
for src in sorted(root.glob('test*.py')):
    proc=subprocess.run([sys.executable,str(src)],cwd=root,capture_output=True,text=True)
    results.append({'test':src.name,'status':'PASS' if proc.returncode==0 else 'FAIL','detail':(proc.stdout+proc.stderr)[-500:]})
report={'test_count':len(results),'pass_count':sum(x['status']=='PASS' for x in results),'results':results,'note':'HOST ONLY; no target STM32 firmware compilation or hardware validation'}
(root/'AUDIT_157_TEST_RESULTS.json').write_text(json.dumps(report,indent=2)+'\n')
print('SV04 NEXT 157 HOST: %d/%d PASS'%(report['pass_count'],report['test_count']))
for item in results:
    if item['status']!='PASS':print(item['test'],item['status'],item['detail'])
raise SystemExit(report['pass_count']!=report['test_count'])
