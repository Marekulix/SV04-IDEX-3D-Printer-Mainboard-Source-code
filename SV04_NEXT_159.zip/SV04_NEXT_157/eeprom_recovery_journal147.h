#pragma once
// SV04 NEXT 147: HOST TEST MODEL. NO FLASH WRITE / NO AUTO RESTORE.
// Durable two-slot external journal; requires genuinely independent medium and
// atomic replacement of each slot. This contract is NOT certified on SV04.
#include <cstddef>
#include <cstdint>
#include <cstring>

namespace sv04 {
constexpr uint32_t kJournalMagic147=0x534A3137u; // SJ17
constexpr uint32_t kJournalVersion147=1;

enum class TxState147 : uint32_t {
  Empty=0, BackupVerified=1, WriteIntent=2,
  WriteReported=3, Verified=4, Quarantine=5
};
struct Journal147 {
  uint32_t magic, version, generation, state;
  uint32_t backup_crc, backup_size, target_crc, target_size;
  uint32_t checksum;
};
static_assert(sizeof(Journal147)==36,"Unexpected journal packing");
inline uint32_t journal_crc147(const Journal147 &j) {
  const uint8_t *p=reinterpret_cast<const uint8_t*>(&j);
  uint32_t crc=0xFFFFFFFFu;
  for(size_t i=0;i<offsetof(Journal147,checksum);++i){
    crc^=p[i]; for(int k=0;k<8;++k) crc=(crc>>1)^(0xEDB88320u & (0u-(crc&1u)));
  }
  return ~crc;
}
inline bool valid147(const Journal147 &j) {
  if(j.magic!=kJournalMagic147 || j.version!=kJournalVersion147 || j.generation==0 ||
     j.state>static_cast<uint32_t>(TxState147::Quarantine)) return false;
  return j.checksum==journal_crc147(j);
}
struct JournalMedia147 {
  virtual ~JournalMedia147()=default;
  virtual bool certified_independent_and_atomic_slots() const=0;
  virtual bool read_slot(unsigned slot,Journal147 &out)=0;
  virtual bool write_slot_and_sync(unsigned slot,const Journal147 &data)=0;
};
struct BackupProof147 {
  bool full_image_verified=false;
  bool independent_storage_verified=false;
  bool matches_current_eeprom=false;
  uint32_t image_crc=0;
  uint32_t image_size=0;
};
struct TargetProof147 {
  bool g29_finished_successfully=false;
  bool mesh16_valid=false;
  bool crc16_valid=false;
  bool readback_is_independent=false;
  uint32_t image_crc=0;
  uint32_t image_size=0;
};
// No M500 calls here. A real integration MUST synchronize motion and lock all
// other EEPROM writers for the WHOLE transaction and handle power failure.
class RecoveryJournal147 {
public:
  enum class Status { NotLoaded, Ready, Prepared, Pending, Verified, Quarantined, MediaFailure };
  explicit RecoveryJournal147(JournalMedia147 &m):m_(m){}
  Status status() const {return status_;}
  bool load() {
    if(status_!=Status::NotLoaded || !m_.certified_independent_and_atomic_slots()) {
      status_=Status::MediaFailure;return false;
    }
    Journal147 a{},b{};
    const bool av=m_.read_slot(0,a)&&valid147(a);
    const bool bv=m_.read_slot(1,b)&&valid147(b);
    if(!av&&!bv){status_=Status::Quarantined;return false;} // Never assume blank EEPROM
    if(av&&bv&&a.generation==b.generation&&std::memcmp(&a,&b,sizeof(a))!=0){status_=Status::Quarantined;return false;}
    current_=(!bv || (av && a.generation>=b.generation))?a:b;
    slot_=(!bv || (av && a.generation>=b.generation))?0:1;
    // Any unfinished intent after reboot is unsafe; even a reported write may
    // have failed halfway through flash erase/program operation.
    switch(static_cast<TxState147>(current_.state)) {
      case TxState147::Empty: status_=Status::Ready; break;
      case TxState147::BackupVerified: status_=Status::Quarantined;break; // orphaned backup
      case TxState147::Verified: status_=Status::Verified;break;
      default:status_=Status::Quarantined;break;
    }
    return status_==Status::Ready || status_==Status::Verified;
  }
  // Initial blank journal must be provisioned OUTSIDE this workflow, after
  // confirming EEPROM integrity / external storage, never on silent startup.
  bool prepare(const BackupProof147 &proof, bool idle, bool writer_lock, bool motion_stopped) {
    if(status_!=Status::Ready || !idle || !writer_lock || !motion_stopped ||
       !proof.full_image_verified || !proof.independent_storage_verified ||
       !proof.matches_current_eeprom || proof.image_size<128 || !proof.image_crc) return false;
    current_.backup_crc=proof.image_crc;current_.backup_size=proof.image_size;
    current_.target_crc=0;current_.target_size=0;
    return advance(TxState147::BackupVerified,Status::Prepared);
  }
  // Must be called after validated G29, no pending motion, and after final RAM
  // target proof. Only successful durable intent authorizes an ATTEMPT.
  bool request_one_write(const TargetProof147 &target,bool safety_ok) {
    if(status_!=Status::Prepared || !safety_ok || !target.g29_finished_successfully ||
       !target.mesh16_valid || !target.crc16_valid || !target.readback_is_independent ||
       target.image_size!=current_.backup_size || !target.image_crc) return false;
    current_.target_crc=target.image_crc; current_.target_size=target.image_size;
    return advance(TxState147::WriteIntent,Status::Pending);
  }
  // Only one use of authorization. A write error quarantines permanently.
  bool report_write_result(bool marlin_write_succeeded) {
    if(status_!=Status::Pending || current_.state!=static_cast<uint32_t>(TxState147::WriteIntent))return false;
    if(!marlin_write_succeeded) { (void)advance(TxState147::Quarantine,Status::Quarantined); return false; }
    return advance(TxState147::WriteReported,Status::Pending);
  }
  bool verify_readback(bool readback_success,bool independent,bool version_crc_valid,
                       bool expected_mesh_equal,uint32_t actual_crc,uint32_t actual_size) {
    if(status_!=Status::Pending || current_.state!=static_cast<uint32_t>(TxState147::WriteReported))return false;
    if(!readback_success || !independent || !version_crc_valid || !expected_mesh_equal ||
       actual_crc!=current_.target_crc || actual_size!=current_.target_size){
      (void)advance(TxState147::Quarantine,Status::Quarantined);return false;
    }
    return advance(TxState147::Verified,Status::Verified);
  }
  bool may_write_now() const {return status_==Status::Pending && current_.state==static_cast<uint32_t>(TxState147::WriteIntent);}
private:
  bool advance(TxState147 state,Status next) {
    if(current_.generation==UINT32_MAX){status_=Status::Quarantined;return false;}
    Journal147 tmp=current_;tmp.magic=kJournalMagic147;tmp.version=kJournalVersion147;
    ++tmp.generation;tmp.state=static_cast<uint32_t>(state);tmp.checksum=journal_crc147(tmp);
    const unsigned target_slot=1-slot_;
    if(!m_.write_slot_and_sync(target_slot,tmp)){status_=Status::Quarantined;return false;}
    Journal147 echo{};
    if(!m_.read_slot(target_slot,echo) || std::memcmp(&echo,&tmp,sizeof(tmp))!=0){status_=Status::Quarantined;return false;}
    slot_=target_slot;current_=tmp;status_=next;return true;
  }
  JournalMedia147 &m_;Journal147 current_{};unsigned slot_=0;Status status_=Status::NotLoaded;
};
} // namespace sv04
