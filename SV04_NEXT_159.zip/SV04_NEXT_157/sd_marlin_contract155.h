#pragma once
// SV04 NEXT 155. HOST-ONLY integration contract. NO Marlin hooks installed.
// A capability manifest is NOT a hardware proof: never enable production calls
// merely because a program claims all hooks are installed.
#include "sd_cooperative154.h"
#include <cstdint>
namespace sv04 {
// Every named SD user must share one atomic ownership mechanism.
enum SdClient155 : uint32_t {
  CardReaderOps=1u<<0, PrintGcode=1u<<1, PausedJobs=1u<<2,
  RecoveryFiles=1u<<3, UploadLogging=1u<<4, DisplayBrowsing=1u<<5,
  MediaMount=1u<<6, DirectoryOps=1u<<7, EmergencyAbort=1u<<8
};
constexpr uint32_t required_hooks155 = (1u<<9)-1u;
struct MarlinEvidence155 {
  // These values may only come from a reviewed *actual* Marlin build.
  bool build_verified=false, hardware_driver_verified=false;
  bool shared_atomic_lease_verified=false, independent_sd_path_verified=false;
  bool medium_identity_hardware_verified=false;
  uint32_t hooked_clients=0;
  bool compatible() const {
    return build_verified && hardware_driver_verified && shared_atomic_lease_verified &&
      independent_sd_path_verified && medium_identity_hardware_verified &&
      (hooked_clients&required_hooks155)==required_hooks155;
  }
};
enum class IntegrationStatus155:uint8_t {Blocked,Idle,Deferred,Reading,VerifiedUntrusted,Cancelled,Rejected};
class MarlinDiagnostic155 {
  MarlinEvidence155 evidence_{};
  Cooperative154 task_{};
  IntegrationStatus155 status_=IntegrationStatus155::Blocked;
public:
  void configure(const MarlinEvidence155& evidence){
    // Never modify a running task by changing its evidence.
    task_.cancel(); evidence_=evidence;
    status_=evidence.compatible()?IntegrationStatus155::Idle:IntegrationStatus155::Blocked;
  }
  IntegrationStatus155 state() const {return status_;}
  bool start(const SdSnapshot151& s,uint64_t now,uint32_t card,uint32_t device,size_t bytes){
    if(status_!=IntegrationStatus155::Idle||!evidence_.compatible()||
       check_sd151(s)!=SdGate151::Clear||!task_.start(s,now,card,device,bytes))return false;
    status_=IntegrationStatus155::Deferred;return true;
  }
  IntegrationStatus155 poll(SdOwnership151& owner,SdSlicePort153& port,uint64_t now){
    if(status_!=IntegrationStatus155::Deferred&&status_!=IntegrationStatus155::Reading)return status_;
    if(!evidence_.compatible()){task_.cancel();status_=IntegrationStatus155::Blocked;return status_;}
    switch(task_.poll(owner,port,now)){
      case Scan154::Deferred: status_=IntegrationStatus155::Deferred;break;
      case Scan154::Running: status_=IntegrationStatus155::Reading;break;
      case Scan154::ValidUntrusted: status_=IntegrationStatus155::VerifiedUntrusted;break;
      case Scan154::Cancelled: case Scan154::Expired: status_=IntegrationStatus155::Cancelled;break;
      default: status_=IntegrationStatus155::Rejected;break;
    }
    return status_;
  }
  void event(SdEvent152 event){task_.on_event(event);
    if(status_==IntegrationStatus155::Reading||status_==IntegrationStatus155::Deferred)
      status_=IntegrationStatus155::Cancelled;
  }
  // HARD BLOCK: no EEPROM / SD write permission in this module.
  static constexpr bool may_write_eeprom(){return false;}
  static constexpr bool may_restore_eeprom(){return false;}
  static constexpr bool may_write_sd(){return false;}
};
static_assert(!MarlinDiagnostic155::may_write_eeprom()&&!MarlinDiagnostic155::may_write_sd()&&
              !MarlinDiagnostic155::may_restore_eeprom(),"No write authority");
} // namespace sv04
