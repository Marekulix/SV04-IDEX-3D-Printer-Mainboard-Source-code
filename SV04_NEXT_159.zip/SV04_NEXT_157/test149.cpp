#include "sd_backup149.h"
#include <cassert>
#include <cstdio>
#include <vector>
using namespace sv04;
static unsigned checks=0;
#define CHECK(x) do { assert(x); ++checks; } while(0)
int main(){
  const uint32_t card=0x1234abce,device=0x87654321;
  Backup149 first{card,device,1,std::vector<uint8_t>(4096,0x4a)};
  Store149 s;
  CHECK(select149(s,card,device,4096).decision==Decision149::NoValidBackup);
  CHECK(stage_backup149(s,first,Stage149::Verified));
  CHECK(select149(s,card,device,4096).slot==0);
  CHECK(!stage_backup149(s,first,Stage149::Verified)); // rollback / replay
  Backup149 second=first;second.generation=2;second.data[200]=0x52;
  for(auto stage:{Stage149::BeforeWrite,Stage149::AfterImagePartial,Stage149::AfterImageComplete,Stage149::AfterCommitPartial,Stage149::AfterCommitComplete}){
    for(size_t n=0;n<70;++n){Store149 t=s;
      CHECK(!stage_backup149(t,second,stage,n));
      auto selected=select149(t,card,device,4096);
      if(stage==Stage149::AfterCommitComplete)CHECK(selected.slot==1 && selected.backup.data==second.data);
      else CHECK(selected.slot==0 && selected.backup.data==first.data);
    }
  }
  CHECK(stage_backup149(s,second,Stage149::Verified));
  CHECK(select149(s,card,device,4096).backup.data==second.data);
  for(size_t i=0;i<s.slots[1].image.size();++i){Store149 t=s;t.slots[1].image[i]^=0x01;
    auto v=select149(t,card,device,4096);CHECK(v.decision==Decision149::UniqueBackup && v.slot==0);
  }
  for(size_t i=0;i<s.slots[1].commit.size();++i){Store149 t=s;t.slots[1].commit[i]^=0x01;
    CHECK(select149(t,card,device,4096).slot==0);
  }
  CHECK(select149(s,card+1,device,4096).decision==Decision149::NoValidBackup);
  CHECK(select149(s,card,device+1,4096).decision==Decision149::NoValidBackup);
  CHECK(select149(s,card,device,4000).decision==Decision149::NoValidBackup);
  Store149 dup=s;dup.slots[0]=dup.slots[1];CHECK(select149(dup,card,device,4096).decision==Decision149::AmbiguousSameGeneration);
  CHECK(!stage_backup149(dup,Backup149{card,device,3,std::vector<uint8_t>(4096,9)},Stage149::Verified));
  CHECK(!sd_powerloss_durability_proven149());CHECK(!automatic_restore_allowed149());CHECK(!automatic_m500_allowed149());
  // Permutations of two sequential generations, exercise rotate slot and selection.
  for(uint32_t g=3;g<120;++g){
    Backup149 next{card,device,g,std::vector<uint8_t>(4096,uint8_t(g))};
    CHECK(stage_backup149(s,next,Stage149::Verified));
    const auto best=select149(s,card,device,4096);
    CHECK(best.decision==Decision149::UniqueBackup && best.backup.generation==g);
    CHECK(best.backup.data==next.data);
  }
  std::printf("test149 PASS (%u checks)\n",checks);
}
