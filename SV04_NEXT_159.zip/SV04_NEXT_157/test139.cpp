#include "auto60_thermal_bridge.h"
#include "auto60_idex_bridge.h"
#include <cassert>
#include <cmath>
#include <iostream>
#include <limits>
using namespace sv04;
static BedTelemetry reading(float c, uint32_t t, float target=60) {
  BedTelemetry b; b.actual=c; b.target=target; b.sampled_ms=t;
  b.sensor_ok=b.heater_ok=b.firmware_thermal_ok=true; return b;
}
static Guards guards() {Guards g;g.idle=g.heaters_ok=g.axes_safe=g.tool_safe=g.probe_ready=g.snapshot_valid=true;return g;}
static void begin(Controller& c,ThermalBridge& b) {assert(c.start(guards(),0));c.ack(Action::SetBed60,true,1);b.after_setpoint_ack(c,1);}
int main(){int n=0;auto ck=[&](bool b){assert(b);++n;};
  {
    Controller c;ThermalBridge bridge;begin(c,bridge);
    for(uint32_t i=1000;i<=33000;i+=1000) {auto t=reading(i<3000?55:60,i);ck(bridge.observe(c,t,i));}
    ck(c.phase()==Phase::Home);ck(bridge.thermal.ready());ck(c.pending()==Action::HomeSafely);
  }
  {
    Controller c;ThermalBridge b;begin(c,b);auto t=reading(60,1000,55);ck(!b.observe(c,t,1000));ck(c.phase()==Phase::Fault);ck(c.needs_restore());
  }
  {
    Controller c;ThermalBridge b;begin(c,b);auto t=reading(60,1000);t.sensor_ok=false;ck(!b.observe(c,t,1000));ck(b.thermal.reason()==ThermalReason::FirmwareFault);
  }
  {
    Controller c;ThermalBridge b;begin(c,b);auto t=reading(60,1000);ck(!b.observe(c,t,5000));ck(b.thermal.reason()==ThermalReason::Stale);
  }
  {
    Controller c;ThermalBridge b;begin(c,b);auto t=reading(NAN,1000);ck(!b.observe(c,t,1000));ck(b.thermal.reason()==ThermalReason::BadReading);
  }
  {
    Controller c;ThermalBridge b;begin(c,b);auto t=reading(60,1000);ck(b.observe(c,t,1000));auto s=reading(74,2000);ck(!b.observe(c,s,2000));ck(b.thermal.reason()==ThermalReason::SensorJump);
  }
  {
    Controller c;ThermalBridge b;begin(c,b);auto t=reading(60,1000);ck(b.observe(c,t,1000));auto s=reading(60,8000);ck(!b.observe(c,s,8000));ck(b.thermal.reason()==ThermalReason::Stale);
  }
  {
    Controller c;ThermalBridge b;begin(c,b);auto t=reading(60,1000);ck(b.observe(c,t,1000));auto s=reading(56,2000);ck(b.observe(c,s,2000));ck(c.phase()==Phase::Heat);ck(!b.thermal.ready());
  }
  {
    Controller c;ThermalBridge b;begin(c,b);auto t=reading(60,1000);t.target=std::numeric_limits<float>::infinity();ck(!b.observe(c,t,1000));ck(b.thermal.reason()==ThermalReason::BadTarget);
  }
  {
    Controller c;ThermalBridge b;begin(c,b);auto t=reading(60,1000);t.firmware_thermal_ok=false;ck(!b.observe(c,t,1000));ck(b.thermal.reason()==ThermalReason::FirmwareFault);
  }
  {
    Controller c;ThermalBridge b;begin(c,b);auto t=reading(60,1000);ck(b.observe(c,t,1000));auto s=reading(60,2000);ck(b.observe(c,s,2000));auto future=reading(60,4000);ck(!b.observe(c,future,3000));ck(b.thermal.reason()==ThermalReason::Stale);
  }
  {BedThermalGuard b;b.arm(0);auto t=reading(60,721000);ck(b.update(t,721000)==ThermalReason::HeatingTimeout);ck(!b.ready());}
  std::cout<<"SV04 NEXT 139 thermal integration: "<<n<<" assertions passed\n";
}
