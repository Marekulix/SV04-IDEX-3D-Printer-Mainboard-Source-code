#include "SV04NextMesh190.hpp"
#include <cassert>
#include <cmath>
struct Grid {float a[4][4]; const float* operator[](unsigned i)const{return a[i];}};
int main(){
  Grid g={}; sv04next190::Snapshot s={};
  for(unsigned y=0;y<4;y++)for(unsigned x=0;x<4;x++)g.a[x][y]=float(y*4+x)/100.f;
  assert(sv04next190::capture(g,4,4,s));
  assert(s.complete && s.valid_mask==0xffffu);
  for(unsigned i=0;i<16;i++)assert(s.mm100[i]==int(i));
  assert(!sv04next190::physical_output_authorized(s));
  g.a[2][3]=NAN;assert(!sv04next190::capture(g,4,4,s));
  assert(s.complete && s.mm100[14]==14); // all-or-nothing, previous state unchanged
  g.a[2][3]=-1.235f;assert(sv04next190::capture(g,4,4,s));assert(s.mm100[14]==-124);
  assert(!sv04next190::capture(g,3,4,s));
  return 0;
}
