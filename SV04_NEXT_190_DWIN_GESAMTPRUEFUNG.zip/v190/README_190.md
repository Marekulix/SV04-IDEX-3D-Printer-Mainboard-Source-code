# SV04 NEXT 190 — OEM bilinear mesh capture, NO FLASH

The pinned Sovol Marlin source exposes `z_values[x][y]` through `abl.h`; the OEM `RTS_AutoBedLevelPage` callback is hooked to take a read-only 4×4 snapshot. This callback is **not** sufficient proof that G29 succeeded. Values are validated as finite, -30..+30 mm and rounded to hundredths; no serial write, EEPROM change, temperature change, or motion is initiated. HMI format and signed presentation remain unverified. No installation binary in artifacts.

GitHub jobs: original 189 Python/C++ regressions, pinned HMI record verification, and full PlatformIO cross-compile with *new* patch 190 (not the earlier inert 181 adapter); status summary always created. The new patch is applied to fresh pinned OEM checkout, never to preexisting repository files.

All 16 values are captured from the real Marlin bilinear mesh, but are **not yet delivered** to DWIN display. Hardware and reliable G29-success gating are outstanding.
