#pragma once
// SV04 NEXT 190. OEM 4x4 bilinear mesh snapshot ONLY; no automatic display writes.
#include <stdint.h>
#include <math.h>
namespace sv04next190 {
struct Snapshot {int16_t mm100[16];uint16_t valid_mask;bool complete;};
static const uint16_t kVP[16] = {0x1118,0x111A,0x111C,0x111E,0x1108,0x1114,0x1112,0x1110,0x1116,0x110A,0x110C,0x110E,0x1106,0x1104,0x1102,0x1100};
static const bool kHmiScaleVerified=false;
static const bool kDwinEmissionEnabled=false;
// Matrix layout uses z_values[x][y]; row zero represents lowest y.
template<class Grid> bool capture(const Grid& grid,unsigned nx,unsigned ny,Snapshot& out){
  Snapshot candidate={};
  if(nx!=4 || ny!=4)return false;
  for(unsigned y=0;y<4;y++)for(unsigned x=0;x<4;x++){
    const float value=grid[x][y];
    if(!isfinite(value) || value<-30.0f || value>30.0f)return false;
    const float hundredths=value*100.0f;
    const int32_t rounded=static_cast<int32_t>(hundredths>=0 ? hundredths+0.5f : hundredths-0.5f);
    const unsigned index=y*4+x;
    candidate.mm100[index]=static_cast<int16_t>(rounded);
    candidate.valid_mask |= static_cast<uint16_t>(1u<<index);
  }
  candidate.complete=(candidate.valid_mask==0xffffu);
  if(!candidate.complete)return false;
  out=candidate;return true;
}
inline bool physical_output_authorized(const Snapshot& s){return kHmiScaleVerified && kDwinEmissionEnabled && s.complete && s.valid_mask==0xffffu;}
}
