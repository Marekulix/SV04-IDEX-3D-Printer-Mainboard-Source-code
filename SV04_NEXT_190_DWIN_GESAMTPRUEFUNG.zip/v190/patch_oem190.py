#!/usr/bin/env python3
"""Patch pinned pristine Sovol LCD_RTS.cpp, refuse patching in place."""
import argparse,pathlib,hashlib,json
HEADER='#include "LCD_RTS.h"'
HOOK='void RTS_AutoBedLevelPage()\n{\n  if(waitway == 3)\n  {'
TAG='// SV04 NEXT 190: OEM bilinear mesh snapshot hook; display output DISABLED'
BLOCK="""// SV04 NEXT 190: OEM bilinear mesh snapshot hook; display output DISABLED
#if ENABLED(AUTO_BED_LEVELING_BILINEAR)
static sv04next190::Snapshot sv04next190_last_mesh = {};
static bool sv04next190_last_mesh_valid = false;
static void sv04next190_read_mesh_after_level_page() {
  // This page callback is not itself proof G29 succeeded. Snapshot data only.
  sv04next190::Snapshot next = {};
  const bool ok = sv04next190::capture(z_values, GRID_MAX_POINTS_X, GRID_MAX_POINTS_Y, next);
  sv04next190_last_mesh_valid = ok;
  if (ok) sv04next190_last_mesh = next;
  // NEVER transmit to DWIN or save EEPROM from this hook.
}
#endif
"""
def patch(s):
  if TAG in s:raise ValueError('already applied')
  if s.count(HEADER)!=1 or s.count(HOOK)!=1:raise ValueError('OEM anchor mismatch')
  for anchor in ['extern', 'RTSSHOW::RTS_SndData(void)','queue.enqueue_now_P(PSTR("G29"));','rtscheck.RTS_SndData(ExchangePageBase + 22, ExchangepageAddr);']:
    if anchor not in s:raise ValueError('OEM source mismatch '+anchor)
  s=s.replace(HEADER,HEADER+'\n#include "SV04NextMesh190.hpp"',1)
  s=s.replace(HOOK,BLOCK+'\n'+HOOK+'\n    #if ENABLED(AUTO_BED_LEVELING_BILINEAR)\n      sv04next190_read_mesh_after_level_page();\n    #endif',1)
  return s
if __name__=='__main__':
  ap=argparse.ArgumentParser();ap.add_argument('--input',required=True);ap.add_argument('--output',required=True);a=ap.parse_args()
  src=pathlib.Path(a.input);dst=pathlib.Path(a.output)
  if src.resolve()==dst.resolve():raise SystemExit('refusing in-place patch')
  before=src.read_text();after=patch(before);dst.parent.mkdir(parents=True,exist_ok=True);dst.write_text(after)
  print(json.dumps({'source_sha256':hashlib.sha256(before.encode()).hexdigest(),'patched_sha256':hashlib.sha256(after.encode()).hexdigest(),'output_enabled':False,'note':'G29 callback timing and HMI scale remain unverified'},indent=2))
