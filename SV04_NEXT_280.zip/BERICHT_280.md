# SV04 NEXT 280 – M420 C: Mesh-Korrektur ohne Teilschreibvorgänge

Basis: 279 (STM32 BUILD_EXIT=0 laut Run-279-Nachweis); 279 bleibt unverändert. Claude-G28/G29/Auto60-Dateien unverändert.

## Behobene Schwachstelle
Die OEM-Implementierung von `M420 C` normalisierte Meshwerte ohne Vorprüfung aller Ergebnisse. Außerdem initialisiert sie die Min-/Max-Suche mit den festen Grenzen +100/-100 statt mit einem realen Messwert. Bei nicht-endlichen Parametern oder arithmetischem Überlauf konnte die Normalisierung ein gültiges Raster beschädigen oder teilveränderte Werte erzeugen. Im OEM-Midrange wird außerdem `(lo_val + hi_val)` als float addiert und kann selbst bei endlichen Werten überlaufen.

## Code
`m420/apply_m420_v6.py` fügt eine ausschließlich M420.cpp betreffende Erweiterung hinzu:
- Initialisiert Min/Max aus dem ersten realen Messpunkt statt mit festen Grenzen; Midrange in `double`.
- Prüft vor dem ersten Schreiben `cval`, `zmean`, alle resultierenden 16 Meshwerte auf finite und Float-Grenzen.
- Bei Fehler: Meldung und Abbruch **ohne** Veränderung des Mesh; weder EEPROM-Schreiben noch automatische Bewegung.
- Nach erfolgreicher Vorprüfung werden alle Punkte geschrieben, sonst keiner.
- Wiederholt ausführbar, Konflikte führen zum Abbruch.

## Prüfung
`python3 m420/test_m420_v6.py`: 14 ausgeführte C++-Prüfszenarien zur Normalisierung und 8 C++-Fälle zu Min/Max außerhalb des alten Grenzbereichs am exakt übernommenen C++-Normalisierungsblock; 3 Prüfungen zur Installation/Idempotenz/Konflikterkennung. Die bisherigen V4/V5-Tests werden durch den Workflow erneut ausgeführt.

## Noch offen
Vollständiger STM32-Build 280 mit M420 V6. Hardwareabnahme. **Keine Freigabe zum Flashen.**
