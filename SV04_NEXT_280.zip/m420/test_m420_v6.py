#!/usr/bin/env python3
"""Execute exact V6 centering code in C++ host harness; patch checks."""
import importlib.util, pathlib, subprocess, tempfile
HERE=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('patch',HERE/'apply_m420_v6.py')
patch=importlib.util.module_from_spec(spec);spec.loader.exec_module(patch)

# Actual OEM centering source, with macro blocks retained verbatim.
block='''            float lo_val = 100, hi_val = -100;
          // Get the midrange plus C value. (The median may be better.)
          const float zmean = (lo_val + hi_val) / 2.0 + cval;
          #endif
          // If not very close to 0, adjust the mesh
          if (!NEAR_ZERO(zmean)) {
            set_bed_leveling_enabled(false);
            // Subtract the mean from all values
            GRID_LOOP(x, y) {
              Z_VALUES(x, y) -= zmean;
              TERN_(EXTENSIBLE_UI, ExtUI::onMeshUpdate(x, y, Z_VALUES(x, y)));
            }
            TERN_(ABL_BILINEAR_SUBDIVISION, bed_level_virt_interpolate());
          }'''
assert patch.OLD in block and patch.OLD_MUTATION in block and patch.OLD_EXTREMA in block
v6=block.replace(patch.OLD_EXTREMA,patch.NEW_EXTREMA).replace(patch.OLD,patch.NEW).replace(patch.OLD_MUTATION,patch.NEW_MUTATION)
assert patch.NEW in v6 and patch.NEW_MUTATION in v6 and patch.NEW_EXTREMA in v6
# Use exact production code for the center validation/commit; substitute
# GRID_LOOP by two nested loops and Z_VALUES by a real 4x4 array.
code = patch.NEW_MUTATION.replace('GRID_LOOP(x, y)', 'for (int x=0;x<4;++x) for (int y=0;y<4;++y)')
code=code.replace('Z_VALUES(x, y)','z_values[x][y]')
code=code.replace('TERN_(EXTENSIBLE_UI, ExtUI::onMeshUpdate(x, y, z_values[x][y]));','')
code=code.replace('TERN_(ABL_BILINEAR_SUBDIVISION, bed_level_virt_interpolate());','')
# NOTE the file uses float zmean in mean-mode, double in midrange. Testing double midrange.
cpp = '''#include <cmath>
#include <cfloat>
#include <cassert>
#include <cstdio>
#include <limits>
static float z_values[4][4];
static float cval;
static double zmean;
static int errors, disables;
static void SERIAL_ERROR_MSG(const char*) {++errors;}
static void set_bed_leveling_enabled(bool on) {assert(!on);++disables;}
#define NEAR_ZERO(x) (std::fabs(x) < 0.00001)
static void run_center() {
'''+code+'''
}
int main() {
  int checked=0;
  for (int scenario=0; scenario<14; ++scenario) {
    for (int x=0;x<4;++x)for(int y=0;y<4;++y)z_values[x][y]=float(x+y)*0.1f;
    if(scenario==1) cval=std::numeric_limits<float>::quiet_NaN();
    else if(scenario==2) cval=std::numeric_limits<float>::infinity();
    else if(scenario==3) cval=-std::numeric_limits<float>::infinity();
    else cval=scenario==4 ? 3.4e38f : float(scenario-6)*0.2f;
    if(scenario==5)z_values[3][3]=std::numeric_limits<float>::infinity();
    if(scenario==6)z_values[1][1]=std::numeric_limits<float>::quiet_NaN();
    if(scenario==7)z_values[0][0]=-std::numeric_limits<float>::max();
    if(scenario==8)z_values[0][0]=std::numeric_limits<float>::max();
    zmean=scenario==9 ? 1e300 : (scenario==10 ? -1e300 : double(cval));
    if(scenario==11)zmean=std::numeric_limits<double>::quiet_NaN();
    if(scenario==12)zmean=0.0;
    if(scenario==13)zmean=0.125;
    float original[4][4];for(int x=0;x<4;++x)for(int y=0;y<4;++y)original[x][y]=z_values[x][y];
    errors=disables=0;run_center();
    bool valid=std::isfinite(cval)&&std::isfinite(zmean);
    for(int x=0;x<4;++x)for(int y=0;y<4;++y){
      double next=double(original[x][y])-zmean;
      if(!std::isfinite(next)||std::fabs(next)>double(FLT_MAX)) valid=false;
    }
    assert(errors==!valid);
    assert(disables==(valid&&std::fabs(zmean)>=0.00001));
    if(!valid)for(int x=0;x<4;++x)for(int y=0;y<4;++y){
      assert((std::isnan(original[x][y])&&std::isnan(z_values[x][y]))||original[x][y]==z_values[x][y]);
    }
    ++checked;
  }
  printf("PASS %d executed V6 centering/rollback scenarios\\n",checked);
}
'''
with tempfile.TemporaryDirectory() as d:
    d=pathlib.Path(d);s=d/'test.cpp';s.write_text(cpp)
    subprocess.run(['g++','-std=c++11','-Wall','-Wextra','-Werror',str(s),'-o',str(d/'run')],check=True)
    subprocess.run([str(d/'run')],check=True)
    # Integration on simplified fixture retaining OEM anchors and V4/V5 markers
    f=d/'Marlin/src/gcode/bedlevel/M420.cpp';f.parent.mkdir(parents=True)
    text=patch.INCLUDE_ANCHOR+'\n// SV04 NEXT V4: guard\n// SV04 NEXT V5: guard\n'+block
    f.write_text(text)
    patch.apply(d);after=f.read_text();patch.apply(d);assert f.read_text()==after
    # A partial patch must fail without overwriting
    f.write_text(after.replace('  // SV04 NEXT V6: reject','  // modified V6: reject'))
    try:patch.apply(d)
    except RuntimeError:pass
    else:raise AssertionError('missing conflict detection')
    print('PASS V6 patch application, repeat and conflict checks')

# Execute exact production extrema initialization and double-midrange expression.
extrema=patch.NEW_EXTREMA.replace('Z_VALUES(0, 0)','z_values[0][0]')
center=patch.NEW.split('\n')[-1]
cpp2="""#include <cassert>
#include <cmath>
#include <cstdio>
static float z_values[4][4];
static float cval;
int main() {
 int tests=0;
 for (int k=0;k<8;k++) {
  float a= k%2 ? -300.0f : 300.0f;
  float b= k%2 ? -200.0f : 400.0f;
  for(int x=0;x<4;x++)for(int y=0;y<4;y++)z_values[x][y]=a;
  z_values[3][3]=b;
  cval=0;
"""+extrema+"""
  for(int x=0;x<4;x++)for(int y=0;y<4;y++) {
   const float z=z_values[x][y];
   if(z<lo_val)lo_val=z;
   if(z>hi_val)hi_val=z;
  }
"""+center+"""
  assert(std::fabs(zmean-(double(a)+double(b))*0.5)<0.01);
  ++tests;
 }
 printf("PASS %d extrema scenarios outside legacy range\\n",tests);
}
"""
with tempfile.TemporaryDirectory() as td:
    td=pathlib.Path(td); s=td/'extrema.cpp'; s.write_text(cpp2)
    subprocess.run(['g++','-std=c++11','-Wall','-Wextra','-Werror',str(s),'-o',str(td/'extrema')],check=True)
    subprocess.run([str(td/'extrema')],check=True)
