#!/usr/bin/env python3
"""SV04 NEXT 328 - Hosttests fuer die SV04-Felder in MarlinSettings (echter Quelltext, ausgeschnitten) + Patch-Pruefung.
Echt: die Textfragmente aus settings.cpp (Original 325 bzw. gepatcht 328), unveraendert ausgeschnitten.
Gestubbt: EEPROM_READ (Semantik: Wert nur schreiben, wenn !validating; Index vorruecken), SERIAL-/CONFIG-Makros (Annahme: Marlin-Standard, im Export nicht enthalten).
NICHT getestet: komplette save()/_load()/report() (Marlin-Header fehlen im Export), echte Hardware."""
import sys, os, re, subprocess, hashlib, shutil, tempfile, itertools
HERE = os.path.dirname(os.path.abspath(__file__)); E = os.path.join(HERE, 'eingang')
ORIG = open(E + '/settings_325_orig.cpp').read(); PATCH = open(E + '/settings_328_patched.cpp').read()
RES = []
def ok(name, cond, info=''):
    RES.append((name, bool(cond))); print(('PASS ' if cond else 'FAIL ') + name + (' | ' + info if info else ''))
def cut(s, a, b, incl_b=True):
    i = s.index(a); j = s.index(b, i); return s[i:j + (len(b) if incl_b else 0)]
def build(src, exe):
    c = exe + '.cpp'; open(c, 'w').write(src)
    r = subprocess.run(['g++', '-std=gnu++17', '-O1', '-Wall', '-fsanitize=address,undefined', '-o', exe, c], capture_output=True, text=True)
    if r.returncode: raise SystemExit('Build-Fehler\n' + r.stderr[:1500])
    return exe
# ---------- Fragmente (echt)
def load_frag(text):
    if 'SV04C328-BEGIN' in text: return cut(text, '      // SV04C328-BEGIN', '// SV04C328-END')
    return cut(text, '      if((dualXPrintingModeStatus != 0)', 'EEPROM_READ(active_extruder_font);')
def report_frag(text): return cut(text, '    CONFIG_ECHO_HEADING("0:Single 1:Two-color', 'SERIAL_ERROR_MSG("  T", int(active_extruder_font));' if 'SERIAL_ERROR_MSG("  T"' in text else 'SERIAL_ECHOLNPGM("  T", int(active_extruder_font));')
LOAD_H = r'''
#include <cstdio>
#include <cstdint>
#include <cstring>
static bool validating; static unsigned long pos; static uint8_t stream[2];
uint8_t dualXPrintingModeStatus, active_extruder_font;
template<class T> static void rd(T &v) { if (!validating) memcpy(&v, &stream[pos], sizeof v); pos += sizeof v; }
#define EEPROM_READ(V) rd(V)
static void frag() {
'''
LOAD_M = r'''
}
int main() { unsigned d, f, rd_, rf, v; while (scanf("%u %u %u %u %u", &d, &f, &rd_, &rf, &v) == 5) {
  stream[0] = d; stream[1] = f; pos = 0; validating = v; dualXPrintingModeStatus = rd_; active_extruder_font = rf; frag();
  printf("%u %u %lu\n", dualXPrintingModeStatus, active_extruder_font, pos); } return 0; }
'''
def load_cases():
    L = []
    for d in range(256):
        for f in range(256):
            for rd_, rf in ((0, 0), (3, 1), (200, 9)):
                for v in (0, 1): L.append((d, f, rd_, rf, v))
    return L
def load_expect(c):
    d, f, rd_, rf, v = c
    if v: return (rd_, rf, 2)
    return (d if d <= 4 else 0, f if f <= 1 else 0, 2)
def run_load(frag_text, tag):
    exe = build(LOAD_H + frag_text + LOAD_M, os.path.join(TMP, 'load_' + tag)); cases = load_cases()
    out = subprocess.run([exe], input='\n'.join(' '.join(map(str, c)) for c in cases) + '\n', capture_output=True, text=True).stdout.splitlines()
    assert len(out) == len(cases)
    bad = [(c, tuple(map(int, o.split()))) for c, o in zip(cases, out) if tuple(map(int, o.split())) != load_expect(c)]
    return len(cases), bad
REP_H = r'''
#include <cstdio>
#include <string>
static std::string OUT;
static void emit(const std::string &s) { OUT += s; }
template<class... A> static std::string cat(const char *p, A... a) { std::string s = p; int v[] = {0, (s += std::to_string(a), 0)...}; (void)v; return s; }
#define CONFIG_ECHO_START() emit("echo:")
#define CONFIG_ECHO_HEADING(S) emit(std::string("echo:") + S + "\n")
#define SERIAL_ERROR_MSG(...) emit("Error:" + cat(__VA_ARGS__) + "\n")
#define SERIAL_ECHOLNPGM(...) emit(cat(__VA_ARGS__) + "\n")
#define TERN_(A, B)
static unsigned char dualXPrintingModeStatus, active_extruder_font;
int main() { unsigned d, f; while (scanf("%u %u", &d, &f) == 2) { dualXPrintingModeStatus = d; active_extruder_font = f; OUT.clear();
'''
REP_M = r'''
  printf("%s@@\n", OUT.c_str()); } return 0; }
'''
def run_report(frag_text, tag):
    frag_text = frag_text.replace('TERN_(HAS_MULTI_LANGUAGE, gcode.M414_report(forReplay));', '')
    exe = build(REP_H + frag_text + REP_M, os.path.join(TMP, 'rep_' + tag))
    cases = [(d, f) for d in (0, 1, 2, 3, 4) for f in (0, 1)]
    out = subprocess.run([exe], input='\n'.join('%d %d' % c for c in cases) + '\n', capture_output=True, text=True).stdout.split('@@\n')[:-1]
    return cases, out
def report_ok(cases, out):
    bad = []
    for (d, f), o in zip(cases, out):
        lines = o.strip('\n').split('\n')
        want = ['echo:0:Single 1:Two-color 2:Copy 3:Mirror Dual X Printing Mode Status:', 'echo:  M605 S%d' % d, 'echo:0:extruder0 1:extruder1 active extruder font:', 'echo:  T%d' % f]
        if lines != want: bad.append(((d, f), lines))
    return bad
def order_check(text):
    """Quelltextpruefung (kein Funktionstest): Position der SV04-Felder relativ zu den Abschnitts-Ueberschriften in save() und _load() und in der Struktur."""
    seq = ['Case Light Brightness', 'Password feature', 'TOUCH_SCREEN_CALIBRATION', 'Ethernet network info', 'Buzzer', 'MKS UI controller', 'Selected LCD language']
    def anchor_after(region, token):
        i = region.find(token); 
        if i < 0: return None
        before = [(region.rfind('// ' + t, 0, i), t) for t in seq if region.rfind('// ' + t, 0, i) >= 0]
        return max(before)[1] if before else None
    sv = text.index('bool MarlinSettings::save()'); ld = text.index('bool MarlinSettings::_load()'); ld_end = text.index('bool MarlinSettings::validate()')
    save_r = text[sv:ld]; load_r = text[ld:ld_end]
    a = anchor_after(save_r, 'EEPROM_WRITE(dualXPrintingModeStatus)')
    b = anchor_after(load_r, 'EEPROM_READ(dualXPrintingModeStatus)') or anchor_after(load_r, 'EEPROM_READ(sv04_dual_mode)')
    return a, b
TMP = tempfile.mkdtemp(prefix='t328_')
print('== A  SV04-Felder in _load(): Original 325 gegen unabhaengiges Modell (echter Quelltext-Ausschnitt) ==')
n, bad_o = run_load(load_frag(ORIG), 'orig')
inv_nonval = [x for x in bad_o if x[0][4] == 0]; inv_val = [x for x in bad_o if x[0][4] == 1]
ok('A1 Original 325: Fehlbefund B1 (ungueltiger Wert aus EEPROM landet im RAM) ist reproduzierbar', len(inv_nonval) > 0, f'{len(inv_nonval)} von {n//2} Faellen weichen ab; Beispiel gespeichert d/f={inv_nonval[0][0][:2]} -> RAM {inv_nonval[0][1][:2]}' if inv_nonval else '')
ok('A2 Original 325: Validierungsdurchlauf veraendert RAM (Befund B1b)', len(inv_val) > 0, f'{len(inv_val)} Faelle; Beispiel RAM {inv_val[0][0][2:4]} -> {inv_val[0][1][:2]}' if inv_val else '')
print('== B  SV04-Felder in _load(): gepatchte 328 ==')
n, bad_p = run_load(load_frag(PATCH), 'patched')
ok('B1 gepatcht: %d Faelle (256x256 gespeicherte Werte x 3 RAM-Vorbelegungen x validating/nicht)' % n, not bad_p, '' if not bad_p else str(bad_p[:3]))
print('== C  M503-Ausgabe der SV04-Zeilen ==')
c, o = run_report(report_frag(ORIG), 'orig'); bo = report_ok(c, o)
ok('C1 Original 325: M605/T-Zeilen tragen "Error:"-Praefix (Befund B3; Annahme: Marlin-Standardmakro)', len(bo) == len(c), f'{len(bo)}/{len(c)} Zeilen-Sets abweichend; Beispiel {bo[0][1][1]}' if bo else '')
c, o = run_report(report_frag(PATCH), 'patched'); bp = report_ok(c, o)
ok('C2 gepatcht: M503 gibt 4 Zeilen exakt aus (Soll/Ist je Wert d=0..4, f=0..1: %d Kombinationen)' % len(c), not bp, '' if not bp else str(bp[:2]))
print('== D  Reihenfolge Schreiben/Lesen (Quelltextpruefung, KEIN Funktionstest) ==')
a, b = order_check(ORIG); ok('D1 Original 325: Position nach Abschnitt (save=%s, load=%s) weicht ab (Befund B2, latent)' % (a, b), a != b)
a, b = order_check(PATCH); ok('D2 gepatcht: save und _load stehen im gleichen Abschnitt (%s / %s)' % (a, b), a == b and a is not None)
# Struktur-Reihenfolge
def struct_pos(t):
    s = t[t.index('typedef struct SettingsDataStruct'):t.index('} SettingsData;')]
    return s.index('dualXPrintingModeStatus') > s.index('caselight_brightness') and s.index('dualXPrintingModeStatus') < s.index('password_is_set')
ok('D3 gepatcht: Struktur-Reihenfolge Case-Light < SV04 < Password (wie Stream)', struct_pos(PATCH)); ok('D4 Original: Struktur-Reihenfolge war anders', not struct_pos(ORIG))
print('== E  Patch-Skript ==')
AP = os.path.join(HERE, '..', '02_PATCH', 'apply_328.py')
def tree(txt): d = tempfile.mkdtemp(dir=TMP); os.makedirs(d + '/src/module'); open(d + '/src/module/settings.cpp', 'w').write(txt); return d
d = tree(ORIG); r = subprocess.run([sys.executable, '-I', AP, d], capture_output=True, text=True)
ok('E1 Patch erzeugt exakt die gelieferte gepatchte Datei', r.returncode == 0 and open(d + '/src/module/settings.cpp').read() == PATCH, r.stdout.strip())
r = subprocess.run([sys.executable, '-I', AP, d], capture_output=True, text=True); ok('E2 zweite Anwendung wird abgelehnt (Exit 3), Datei unveraendert', r.returncode == 3 and open(d + '/src/module/settings.cpp').read() == PATCH)
d = tree(ORIG + '\n// fremd\n'); r = subprocess.run([sys.executable, '-I', AP, d], capture_output=True, text=True); ok('E3 falscher Vorher-Hash -> Exit 3, nichts geschrieben', r.returncode == 3 and open(d + '/src/module/settings.cpp').read() == ORIG + '\n// fremd\n')
ok('E4 Hash der gepatchten Datei', hashlib.sha256(PATCH.encode()).hexdigest() == 'bb5043f4d6df93df6c1d030fc677ffa5478ba59d04a9fd3d548769610ab9bd66', hashlib.sha256(PATCH.encode()).hexdigest())
import difflib
dl = [l for l in difflib.unified_diff(ORIG.split('\n'), PATCH.split('\n'), lineterm='') if (l.startswith('+') or l.startswith('-')) and not l.startswith(('+++', '---'))]
ok('E5 Diff-Umfang begrenzt (nur SV04-Felder, Load-Position, 2 Report-Zeilen)', len(dl) < 60, '%d geaenderte Zeilen' % len(dl))
print('== F  Regression PersistentStore (327, unveraenderte Methodentexte) ==')
r = subprocess.run(['g++', '-std=c++17', '-O0', '-Wall', '-Wextra', '-Werror', '-fsanitize=address,undefined', E + '/persistent_store_327.cpp', '-o', TMP + '/ps327'], capture_output=True, text=True)
r2 = subprocess.run([TMP + '/ps327'], capture_output=True, text=True) if r.returncode == 0 else None
ok('F1 Backend-Harness aus Workflow 35 baut und laeuft unveraendert', r.returncode == 0 and r2.returncode == 0 and 'HOST_PASS' in r2.stdout)
print('== G  Mutanten auf dem gepatchten Fragment/Report ==')
LF = load_frag(PATCH); RF = report_frag(PATCH)
MUT = [
 ('G1 Grenze Modus 4 -> 5', 'L', '(sv04_dual_mode <= 4)', '(sv04_dual_mode <= 5)'),
 ('G2 Grenze Font 1 -> 2', 'L', '(sv04_tool_font <= 1)', '(sv04_tool_font <= 2)'),
 ('G3 validating-Schutz entfernt', 'L', 'if (!validating) {', 'if (true) {'),
 ('G4 Lesereihenfolge vertauscht', 'L', 'EEPROM_READ(sv04_dual_mode);\n        EEPROM_READ(sv04_tool_font);', 'EEPROM_READ(sv04_tool_font);\n        EEPROM_READ(sv04_dual_mode);'),
 ('G5 Rueckfall 0 -> 1 (Modus)', 'L', '(sv04_dual_mode <= 4) ? sv04_dual_mode : 0', '(sv04_dual_mode <= 4) ? sv04_dual_mode : 1'),
 ('G6 Font nicht gelesen', 'L', '        EEPROM_READ(sv04_tool_font);\n', ''),
 ('G7 Prueffehler: Font <= 1 ersetzt durch !=255', 'L', '(sv04_tool_font <= 1)', '(sv04_tool_font != 255)'),
 ('G8 Report: Modus wieder als Error', 'R', 'SERIAL_ECHOLNPGM("  M605 S"', 'SERIAL_ERROR_MSG("  M605 S"'),
 ('G9 Report: Tool-Zeile als Error', 'R', 'SERIAL_ECHOLNPGM("  T"', 'SERIAL_ERROR_MSG("  T"'),
 ('G10 Report: Modus/Tool vertauscht', 'R', 'int(dualXPrintingModeStatus)', 'int(active_extruder_font)'),
]
surv = []
for name, kind, a, b in MUT:
    src = LF if kind == 'L' else RF
    assert src.count(a) >= 1, name
    m = src.replace(a, b, 1)
    try:
        if kind == 'L': nn, bad = run_load(m, 'm'); killed = bool(bad)
        else: c, o = run_report(m, 'm'); killed = bool(report_ok(c, o))
    except SystemExit: killed = True
    ok(name + ' getoetet', killed)
fails = [n for n, c in RES if not c]
print('\nGESAMT: %d Pruefungen, %d FAIL' % (len(RES), len(fails)))
print('FLASH_ALLOWED=NO\nHARDWARE_TESTED=NO'); shutil.rmtree(TMP, ignore_errors=True)
sys.exit(1 if fails else 0)
