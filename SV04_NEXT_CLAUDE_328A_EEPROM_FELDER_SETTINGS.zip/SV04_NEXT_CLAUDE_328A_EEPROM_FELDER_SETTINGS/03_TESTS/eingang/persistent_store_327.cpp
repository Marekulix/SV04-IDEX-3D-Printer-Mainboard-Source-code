
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <cstdlib>
#include <vector>
#include <cassert>
#include <iostream>
using std::size_t;
#define E2END 4095
#define MARLIN_EEPROM_SIZE size_t(E2END + 1)
#define FLASH_EEPROM_LEVELING 0
#define ENABLED(v) (v)
#define TERN(v, y, n) n
#define TERN_(v, expr)
#define DISABLE_ISRS()
#define ENABLE_ISRS()
#define PAUSE_SERVO_OUTPUT()
#define RESUME_SERVO_OUTPUT()
struct MockEEPROM { int starts=0; void begin(){ starts++; } } EEPROM;
static std::vector<uint8_t> flash(4096, 0xFF), buffer(4096, 0xFF);
static int flushes=0;
void eeprom_buffer_fill(){ buffer=flash; }
void eeprom_buffer_flush(){ flash=buffer; flushes++; }
uint8_t eeprom_buffered_read_byte(const int pos){ assert(pos>=0 && pos<4096); return buffer.at(pos); }
void eeprom_buffered_write_byte(const int pos,const uint8_t data){ assert(pos>=0 && pos<4096); buffer.at(pos)=data; }
void crc16(uint16_t *crc, const uint8_t *data, size_t count){
  // Deterministic end-to-end checksum in the harness only; not Marlin's own settings CRC.
  for(size_t i=0;i<count;i++){*crc ^= data[i]; for(int n=0;n<8;n++) *crc = (*crc & 1) ? (*crc >> 1) ^ 0xA001 : (*crc >> 1);}
}
static bool eeprom_data_written=false;
struct PersistentStore {
  static size_t capacity();
  static bool access_start();
  static bool access_finish();
  static bool write_data(int&, const uint8_t*,size_t,uint16_t*);
  static bool read_data(int&,uint8_t*,size_t,uint16_t*,const bool writing=true);
};
size_t PersistentStore::capacity() { return MARLIN_EEPROM_SIZE; }
bool PersistentStore::access_start() {

  EEPROM.begin(); // Avoid STM32 EEPROM.h warning (do nothing)

  #if ENABLED(FLASH_EEPROM_LEVELING)

    if (current_slot == -1 || eeprom_data_written) {
      // This must be the first time since power on that we have accessed the storage, or someone
      // loaded and called write_data and never called access_finish.
      // Lets go looking for the slot that holds our configuration.
      if (eeprom_data_written) DEBUG_ECHOLNPGM("Dangling EEPROM write_data");
      uint32_t address = FLASH_ADDRESS_START;
      while (address <= FLASH_ADDRESS_END) {
        uint32_t address_value = (*(__IO uint32_t*)address);
        if (address_value != EMPTY_UINT32) {
          current_slot = (address - (FLASH_ADDRESS_START)) / (MARLIN_EEPROM_SIZE);
          break;
        }
        address += sizeof(uint32_t);
      }
      if (current_slot == -1) {
        // We didn't find anything, so we'll just initialize to empty
        for (int i = 0; i < MARLIN_EEPROM_SIZE; i++) ram_eeprom[i] = EMPTY_UINT8;
        current_slot = EEPROM_SLOTS;
      }
      else {
        // load current settings
        uint8_t *eeprom_data = (uint8_t *)SLOT_ADDRESS(current_slot);
        for (int i = 0; i < MARLIN_EEPROM_SIZE; i++) ram_eeprom[i] = eeprom_data[i];
        DEBUG_ECHOLNPGM("EEPROM loaded from slot ", current_slot, ".");
      }
      eeprom_data_written = false;
    }

  #else
    eeprom_buffer_fill();
  #endif

  return true;
}
bool PersistentStore::access_finish() {

  if (eeprom_data_written) {
    #ifdef STM32F4xx
      // MCU may come up with flash error bits which prevent some flash operations.
      // Clear flags prior to flash operations to prevent errors.
      __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_OPERR | FLASH_FLAG_WRPERR | FLASH_FLAG_PGAERR | FLASH_FLAG_PGPERR | FLASH_FLAG_PGSERR);
    #endif

    #if ENABLED(FLASH_EEPROM_LEVELING)

      HAL_StatusTypeDef status = HAL_ERROR;
      bool flash_unlocked = false;

      if (--current_slot < 0) {
        // all slots have been used, erase everything and start again

        FLASH_EraseInitTypeDef EraseInitStruct;
        uint32_t SectorError = 0;

        EraseInitStruct.TypeErase = FLASH_TYPEERASE_SECTORS;
        EraseInitStruct.VoltageRange = FLASH_VOLTAGE_RANGE_3;
        EraseInitStruct.Sector = FLASH_SECTOR;
        EraseInitStruct.NbSectors = 1;

        current_slot = EEPROM_SLOTS - 1;
        UNLOCK_FLASH();

        TERN_(HAS_PAUSE_SERVO_OUTPUT, PAUSE_SERVO_OUTPUT());
        DISABLE_ISRS();
        status = HAL_FLASHEx_Erase(&EraseInitStruct, &SectorError);
        ENABLE_ISRS();
        TERN_(HAS_PAUSE_SERVO_OUTPUT, RESUME_SERVO_OUTPUT());
        if (status != HAL_OK) {
          DEBUG_ECHOLNPGM("HAL_FLASHEx_Erase=", status);
          DEBUG_ECHOLNPGM("GetError=", HAL_FLASH_GetError());
          DEBUG_ECHOLNPGM("SectorError=", SectorError);
          LOCK_FLASH();
          return false;
        }
      }

      UNLOCK_FLASH();

      uint32_t offset = 0;
      uint32_t address = SLOT_ADDRESS(current_slot);
      uint32_t address_end = address + MARLIN_EEPROM_SIZE;
      uint32_t data = 0;

      bool success = true;

      while (address < address_end) {
        memcpy(&data, ram_eeprom + offset, sizeof(uint32_t));
        status = HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, address, data);
        if (status == HAL_OK) {
          address += sizeof(uint32_t);
          offset += sizeof(uint32_t);
        }
        else {
          DEBUG_ECHOLNPGM("HAL_FLASH_Program=", status);
          DEBUG_ECHOLNPGM("GetError=", HAL_FLASH_GetError());
          DEBUG_ECHOLNPGM("address=", address);
          success = false;
          break;
        }
      }

      LOCK_FLASH();

      if (success) {
        eeprom_data_written = false;
        DEBUG_ECHOLNPGM("EEPROM saved to slot ", current_slot, ".");
      }

      return success;

    #else
      // The following was written for the STM32F4 but may work with other MCUs as well.
      // Most STM32F4 flash does not allow reading from flash during erase operations.
      // This takes about a second on a STM32F407 with a 128kB sector used as EEPROM.
      // Interrupts during this time can have unpredictable results, such as killing Servo
      // output. Servo output still glitches with interrupts disabled, but recovers after the
      // erase.
      TERN_(HAS_PAUSE_SERVO_OUTPUT, PAUSE_SERVO_OUTPUT());
      DISABLE_ISRS();
      eeprom_buffer_flush();
      ENABLE_ISRS();
      TERN_(HAS_PAUSE_SERVO_OUTPUT, RESUME_SERVO_OUTPUT());

      eeprom_data_written = false;
    #endif
  }

  return true;
}
bool PersistentStore::write_data(int &pos, const uint8_t *value, size_t size, uint16_t *crc) {
  while (size--) {
    uint8_t v = *value;
    #if ENABLED(FLASH_EEPROM_LEVELING)
      if (v != ram_eeprom[pos]) {
        ram_eeprom[pos] = v;
        eeprom_data_written = true;
      }
    #else
      if (v != eeprom_buffered_read_byte(pos)) {
        eeprom_buffered_write_byte(pos, v);
        eeprom_data_written = true;
      }
    #endif
    crc16(crc, &v, 1);
    pos++;
    value++;
  }
  return false;
}
bool PersistentStore::read_data(int &pos, uint8_t *value, size_t size, uint16_t *crc, const bool writing/*=true*/) {
  do {
    const uint8_t c = TERN(FLASH_EEPROM_LEVELING, ram_eeprom[pos], eeprom_buffered_read_byte(pos));
    if (writing) *value = c;
    crc16(crc, &c, 1);
    pos++;
    value++;
  } while (--size);
  return false;
}

int main(){
  assert(PersistentStore::capacity()==4096);
  uint8_t original[8]={3,5,8,13,21,34,55,89};
  int p=40; uint16_t cwrite=0;
  assert(PersistentStore::access_start());
  assert(!PersistentStore::write_data(p,original,8,&cwrite)); assert(p==48);
  assert(PersistentStore::access_finish()); assert(flushes==1);
  // Simulate a controller restart: RAM contents are wiped, persistent flash survives.
  buffer.assign(4096,0x00);
  assert(PersistentStore::access_start()); int q=40;uint8_t readback[8]={0};uint16_t cread=0;
  assert(!PersistentStore::read_data(q,readback,8,&cread));
  assert(q==48 && memcmp(original,readback,8)==0 && cwrite==cread);
  assert(PersistentStore::access_finish());assert(flushes==1);
  // Repeated write of identical data must not flush flash again.
  assert(PersistentStore::access_start());p=40;cwrite=0;
  assert(!PersistentStore::write_data(p,original,8,&cwrite));
  assert(PersistentStore::access_finish());assert(flushes==1);
  // A changed setting must persist through the following simulated restart.
  original[1]=101;
  assert(PersistentStore::access_start());p=40;cwrite=0;
  assert(!PersistentStore::write_data(p,original,8,&cwrite));
  assert(PersistentStore::access_finish());assert(flushes==2);
  buffer.assign(4096,0x00);
  assert(PersistentStore::access_start());q=40;cread=0;memset(readback,0,8);
  assert(!PersistentStore::read_data(q,readback,8,&cread));
  assert(memcmp(original,readback,8)==0 && cwrite==cread);
  assert(PersistentStore::access_finish());
  // Corrupt flash: harness detects a changed payload and checksum difference.
  flash[43]^=0x01;buffer.assign(4096,0);
  assert(PersistentStore::access_start());q=40;cread=0;
  assert(!PersistentStore::read_data(q,readback,8,&cread));
  assert(memcmp(original,readback,8)!=0 && cread!=cwrite);
  assert(PersistentStore::access_finish());
  std::cout << "STM32_PERSISTENTSTORE_ORIGINAL_METHODS=HOST_PASS\\n";
  std::cout << "SIMULATED_REBOOT_READBACK=PASS\\n";
  std::cout << "SAME_DATA_NO_EXTRA_FLASH_FLUSH=PASS\\n";
  std::cout << "CHANGED_DATA_PERSISTENCE=PASS\\n";
  std::cout << "INJECTED_CORRUPTION_DETECTED_BY_HARNESS=PASS\\n";
  std::cout << "M500_M501_M503_FULL_FIRMWARE_EXECUTION=NOT_TESTED\\n";
  std::cout << "EEPROM_CRC_IN_FIRMWARE=NOT_TESTED\\n";
  std::cout << "FLASH_ALLOWED=NO\\nHARDWARE_TESTED=NO\\n";
  return 0;
}
