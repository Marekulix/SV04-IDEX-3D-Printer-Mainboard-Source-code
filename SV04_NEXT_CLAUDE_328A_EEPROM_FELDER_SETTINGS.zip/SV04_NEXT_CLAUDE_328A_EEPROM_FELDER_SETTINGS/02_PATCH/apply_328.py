#!/usr/bin/env python3
"""SV04 NEXT 328 - Patch fuer Marlin/src/module/settings.cpp (Basis: C13 + DWIN 325, SHA-256 e62c86fe...).
Aufruf: apply_328.py <Marlin-Verzeichnis>   (der Baum wird NUR veraendert, wenn Vorher-Hash und alle Anker eindeutig passen; sonst Exit 3, nichts geschrieben)
E1 Struktur: SV04-Felder hinter Case-Light verschieben (gleiche Reihenfolge wie save()/_load(), wichtig fuer _FIELD_TEST).
E2 _load(): SV04-Felder an die Schreibposition (direkt nach Case-Light) lesen; Bereichspruefung NACH dem Lesen auf lokalen Kopien; RAM nur aendern, wenn !validating.
E3 report(): M605/T-Zeilen mit SERIAL_ECHOLNPGM statt SERIAL_ERROR_MSG (kein 'Error:'-Praefix).
"""
import sys, hashlib, pathlib
PRE = 'e62c86fe73b7583486f412662c9db0f740b5dceea50734aa4c4eb02718303338'
root = pathlib.Path(sys.argv[1]); f = root / 'src/module/settings.cpp'
if not f.is_file(): print('FEHLT', f); sys.exit(3)
s = f.read_text()
h = hashlib.sha256(f.read_bytes()).hexdigest()
if h != PRE: print('FALSCHER VORHER-HASH', h, 'erwartet', PRE); sys.exit(3)
SV_STRUCT_OLD = "  //\n  // SV04 DWIN\n  //\n  uint8_t dualXPrintingModeStatus;\n  uint8_t active_extruder_font;\n  #if ENABLED(DWIN_CREALITY_LCD_ENHANCED)\n"
SV_STRUCT_NEW = "  #if ENABLED(DWIN_CREALITY_LCD_ENHANCED)\n"
CL_STRUCT_OLD = "  #if CASELIGHT_USES_BRIGHTNESS\n    uint8_t caselight_brightness;                        // M355 P\n  #endif\n"
CL_STRUCT_NEW = CL_STRUCT_OLD + "\n  //\n  // SV04 DWIN (SV04C328: Position = Schreib-/Lesereihenfolge)\n  //\n  uint8_t dualXPrintingModeStatus;\n  uint8_t active_extruder_font;\n"
LOAD_OLD = ("      if((dualXPrintingModeStatus != 0) && (dualXPrintingModeStatus != 1) && (dualXPrintingModeStatus != 2) && (dualXPrintingModeStatus != 3) && (dualXPrintingModeStatus != 4))\n"
 "      {\n        dualXPrintingModeStatus = 0;\n      }\n      EEPROM_READ(dualXPrintingModeStatus);\n\n"
 "      if((active_extruder_font != 0) && (active_extruder_font != 1))\n      {\n        active_extruder_font = 0;\n      }\n      EEPROM_READ(active_extruder_font);\n")
LOAD_CL_OLD = "      #if CASELIGHT_USES_BRIGHTNESS\n        _FIELD_TEST(caselight_brightness);\n        EEPROM_READ(caselight.brightness);\n      #endif\n"
LOAD_CL_NEW = LOAD_CL_OLD + ("\n      // SV04C328-BEGIN SV04 DWIN (gleiche Position wie in save(); Pruefung NACH dem Lesen; RAM unveraendert bei validating)\n"
 "      {\n        uint8_t sv04_dual_mode = 0, sv04_tool_font = 0;\n        EEPROM_READ(sv04_dual_mode);\n        EEPROM_READ(sv04_tool_font);\n"
 "        if (!validating) {\n          dualXPrintingModeStatus = (sv04_dual_mode <= 4) ? sv04_dual_mode : 0;\n          active_extruder_font    = (sv04_tool_font <= 1) ? sv04_tool_font : 0;\n        }\n      }\n      // SV04C328-END\n")
REP1_OLD = '    SERIAL_ERROR_MSG("  M605 S", int(dualXPrintingModeStatus));'
REP1_NEW = '    SERIAL_ECHOLNPGM("  M605 S", int(dualXPrintingModeStatus));'
REP2_OLD = '    SERIAL_ERROR_MSG("  T", int(active_extruder_font));'
REP2_NEW = '    SERIAL_ECHOLNPGM("  T", int(active_extruder_font));'
edits = [(SV_STRUCT_OLD, SV_STRUCT_NEW), (CL_STRUCT_OLD, CL_STRUCT_NEW), (LOAD_OLD, ''), (LOAD_CL_OLD, LOAD_CL_NEW), (REP1_OLD, REP1_NEW), (REP2_OLD, REP2_NEW)]
for old, new in edits:
    if s.count(old) != 1: print('ANKER NICHT EINDEUTIG (%d):' % s.count(old), old[:70].replace('\n', '|')); sys.exit(3)
for old, new in edits: s = s.replace(old, new, 1)
f.write_text(s)
print('settings.cpp: PATCHED sha256', hashlib.sha256(f.read_bytes()).hexdigest())
