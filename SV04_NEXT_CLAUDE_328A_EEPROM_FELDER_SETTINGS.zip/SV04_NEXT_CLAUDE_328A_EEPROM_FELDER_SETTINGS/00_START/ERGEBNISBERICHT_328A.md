# SV04 NEXT – Claude 328A: EEPROM-Felder, Laden/Report (Teilergebnis)

Stand 14.11.2026 · **FLASH_ALLOWED=NO · HARDWARE_TESTED=NO** · Basis C13 + DWIN 325 unverändert (nur `settings.cpp` wird in einer neuen Version 328A verändert).
Stufen: programmiert ja · host-getestet **nur Ausschnitte (siehe 2)** · STM32-gebaut **nein** (kein Lauf) · Hardware nein.

## 1. Ehrliche Lage zum Auftrag
Die vollständige Kette `M500 → save() → PersistentStore` und `M501 → load()` / `M503 → report()` konnte ich **nicht** ausführen: Der Export enthält `settings.cpp`, `settings.h`, `M500-M504.cpp`, `Configuration*.h`, aber nicht die Marlin-Header (`EEPROM_READ/WRITE`-Makros, `planner`, `serial.h` …), und der Präprozessor-Export des C13-Laufs ist leer geblieben (Ursache: **Fehler in meinem Export-Schritt** im C13-Workflow – relativer Ausgabepfad und `..`-Dateinamen, siehe `LOG.txt`: „opening output file … No such file or directory“). Ich habe deshalb nichts als „PASS“ gemeldet, was ich nur aus Quellzeilen erschlossen hätte.
Was ich stattdessen getan habe: den echten Quelltext von `settings.cpp` gelesen, SV04-spezifische Stellen gegen eigene Modelle getestet (echte Textausschnitte, Makros gestubbt) und dabei **drei belegte Fehler** gefunden und korrigiert.

## 2. Was wurde getestet (Rohlog `04_ROHLOGS/test_328.txt`, 25 Prüfungen, 0 FAIL)
| Nr | Prüfung | Art | Ergebnis |
|---|---|---|---|
| A/B | `_load()`-Ausschnitt für `dualXPrintingModeStatus` / `active_extruder_font`: alle 256×256 gespeicherten Werte × 3 RAM-Vorbelegungen × validating/nicht gegen unabhängiges Modell | **echter Textausschnitt**, `EEPROM_READ` gestubbt | Original 325: Abweichung in 196 578 von 196 608 Fällen; gepatcht 328A: 0 von 393 216 |
| C | `M503`-Zeilen der SV04-Felder, Soll/Ist je Wert (10 Kombinationen) | echter Textausschnitt, Serial-Makros nach Marlin-Standard **angenommen** | Original: `echo:Error:  M605 S0`; gepatcht: `echo:  M605 S0` |
| D | Reihenfolge Schreiben/Lesen und Struktur | **nur Quelltextprüfung** | Original: save nach „Case Light“, load nach „Selected LCD language“ |
| E | Patch-Skript: exakt das gelieferte Ergebnis, doppelte Anwendung/falscher Hash → Exit 3 | Hosttest | PASS |
| F | Regression `PersistentStore` aus Workflow 35 | unveränderter Harness, neu gebaut | PASS |
| G | 10 Mutanten (Grenzen, validating-Schutz, Reihenfolge, Report) | Hosttest | 10/10 getötet |

**Nicht getestet:** komplette `save()`/`_load()`/`report()` mit allen Feldern, Marlins eigene Versions-/Größen-/CRC-Validierung, Negativtests (leerer EEPROM, falsche Version, falsche Prüfsumme, korrupte Daten, Stromausfall beim Schreiben), echter Flash, DWIN.

## 3. Korrigierte Fehler (`01_QUELLEN/geaendert/Marlin/src/module/settings.cpp`, Patch `02_PATCH/apply_328.py`, Vorher-Hash `e62c86fe…`, Nachher `bb5043f4…`)
| Nr | Befund | Vorher | Nachher | Regressionstest |
|---|---|---|---|---|
| **B1** | `_load()`: Bereichsprüfung steht **vor** `EEPROM_READ`, prüft also den alten RAM-Wert; der gelesene EEPROM-Wert bleibt ungeprüft. Ein ungültiger gespeicherter Wert (z. B. Font 9) landet im RAM; `LCD_RTS.cpp:287` setzt dann `active_extruder = active_extruder_font` → Index außerhalb der Werkzeuge. Zusätzlich: der Prüf-Durchlauf (`validating`, auch M504 und das erste `validate()` in `load()`) verändert RAM. | Prüfung vor Lesen | Lesen in lokale Kopien, Prüfung danach, RAM nur bei `!validating` | A1/A2/B1, Mutanten G1–G7 |
| **B2** | **Latent:** `save()` schreibt die zwei SV04-Bytes direkt nach „Case Light“, `_load()` liest sie am Ende nach „Selected LCD language“. Mit der heutigen Konfiguration (kein PASSWORD_FEATURE, TOUCH_SCREEN, SOUND_MENU, Ethernet, MKS, Mehrsprachigkeit) sind beide Reihenfolgen identisch; sobald eines aktiviert wird, stimmt die CRC nie mehr und jedes Laden schlägt fehl. | verschiedene Positionen | Lesen an der Schreibposition; Strukturfelder in gleicher Reihenfolge (relevant für `_FIELD_TEST`) | D1–D4 (nur Quelltextprüfung) |
| **B3** | `report()` gibt die SV04-Zeilen mit `SERIAL_ERROR_MSG` aus. Nach Marlin-Standard erzeugt das den Präfix `Error:` – jeder M503 meldet also zwei Fehlerzeilen; Hosts mit „bei Error abbrechen“ können dadurch Druck/Start-G-Code abbrechen. | `SERIAL_ERROR_MSG` | `SERIAL_ECHOLNPGM` | C1/C2, Mutanten G8–G10 |

Die Bytes im EEPROM-Stream bleiben für die aktuelle Konfiguration identisch (Größe, Reihenfolge, Version `V85` unverändert) – bestehende gespeicherte Datensätze bleiben gültig.

## 4. Falsche Annahmen / Claude-Fehlinterpretationen
* **Mein C13-Export-Schritt war fehlerhaft** (leere `.i`/`.macros`); deshalb fehlt die Grundlage für den Echttest von `settings.cpp`. Korrektur folgt im 328-Workflow.
* Die Bezeichnung „Korruption erkannt“ im Workflow-35-Test bezog sich auf die Harness-Prüfsumme (so schon im Auftrag vermerkt); dem stimme ich zu.
* Annahmen, die nur der echte Build bestätigen kann: Marlin-Standarddefinitionen von `EEPROM_READ` (schreibt nur bei `!validating`) und `SERIAL_ERROR_MSG` („Error:“-Präfix). Der 328-Workflow soll sie per `grep` im echten Baum belegen.

## 5. Beobachtungen ohne Änderung
* `MarlinSettings::reset()` setzt `dualXPrintingModeStatus`/`active_extruder_font` nicht zurück (M502 lässt sie stehen).
* `M503` gibt den Modus als `M605 S<0..4>` aus; die Bedeutung der SV04-Zahlen (0 Single, 1 Two-color, 2 Copy, 3 Mirror) deckt sich nicht mit Marlins `M605 S` (0 Full-Control, 1 Auto-Park, 2 Duplikation, 3 Spiegel). Wer die M503-Ausgabe als G-Code wiedergibt, setzt damit evtl. einen anderen Modus. Entscheidung nötig (nicht geändert).

## 6. Offen
Echter M500/M501/M503-Durchlauf mit allen Feldern und Negativtests (braucht Präprozessor-Auszüge bzw. den kompletten Baum – nächster Workflow), STM32-Build beider Profile, EEPROM-Hardware, echter Neustart, IDEX-Abstände, BLTouch, DWIN-Bildbibliothek.

## 7. Fortschritt
Vorschlag **erst nach grünem Build beider Profile**: EEPROM-Rücklesung 60 % → 62 % (B1/B3 behoben und host-getestet; kein Funktionsnachweis der Gesamtkette). Bis dahin **82,3 % unverändert**.

## 8. Nächster Schritt
Ich brauche die YAML des Workflows, der C13 + DWIN 325 baut (Workflow 32 oder 34, Datei aus `.github/workflows`). Darauf setze ich den 328-Workflow: Patch anwenden, Tests, beide Profile bauen, **korrekter** Präprozessor-Export von `settings.cpp`, `M500-M504.cpp`, `eeprom_flash.cpp`, Makro-`grep`s – damit die Vollkette im nächsten Schritt wirklich ausgeführt werden kann.
