#!/usr/bin/env python3
"""Fuehrt den ECHTEN, vom Overlay gepatchten G29.cpp (echte Zickzack-Schleife, echter OEM-Reset des Meshs, echter Nachlauf) gegen ein Fake-Geraet AUS.
Stufe: SIMULATION (Welt = Nachbildung, KEIN Marlin-Build). Marlin-Header werden durch eine Welt ersetzt (harness/real_g29/world.h); der G29.cpp-Text selbst ist unveraendert.
Aufruf: python3 harness/run_real_g29.py [--keep]   (Exit 0 nur wenn alle Pruefungen bestehen)"""
import subprocess, sys, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path[:0] = [str(ROOT / 'tools'), str(ROOT / 'integration')]
import shim_compile_check as S
G29 = 'Marlin/src/gcode/bedlevel/abl/G29.cpp'
def build_tree(work: Path):
    S.build_trees(work)
    for p in (work / 'patched').rglob('*.h'): p.write_text('')            # echte Marlin-Header werden durch die Welt ersetzt; Overlay-Header (.hpp) bleiben
    macros = S.SHIM.read_text(encoding='utf-8').split('// --- Basistypen')[0]
    (work / 'world_all.h').write_text(macros + '\n#include <stdint.h>\ntypedef int16_t celsius_t; typedef float celsius_float_t;\nenum AxisEnum : uint8_t { X_AXIS, Y_AXIS, Z_AXIS, E_AXIS };\n#define _MIN(a, b) ((a) < (b) ? (a) : (b))\n#define ABS(x) ((x) < 0 ? -(x) : (x))\n#define SQRT(x) sqrtf(x)\n' + (ROOT / 'harness/real_g29/world.h').read_text(encoding='utf-8'), encoding='utf-8')
    return work
def build(work: Path, g29_text=None, out='real_g29'):
    f = work / 'patched' / G29
    if g29_text is not None: f.write_text(g29_text, encoding='utf-8')
    for _ in range(300):                                                    # fehlende Platzhalter-Header automatisch anlegen
        r = subprocess.run(['g++', '-std=gnu++14', '-O1', '-w', f'-I{work / "patched"}', f'-I{work / "inc"}', '-include', str(work / 'world_all.h'), *S.CFG, str(ROOT / 'harness/real_g29/driver_real.cpp'), str(f), '-o', str(work / out)], capture_output=True, text=True)
        import re
        m = re.search(r'^(\S+?):(\d+):\d+: fatal error: (.+?): No such file or directory', r.stderr, re.M)
        if not m: return r
        line = Path(m.group(1)).read_text(errors='replace').split('\n')[int(m.group(2)) - 1]
        inc = (work / 'inc' / m.group(3)) if '<' in line else (Path(m.group(1)).parent / m.group(3)); inc.parent.mkdir(parents=True, exist_ok=True); inc.write_text('')
    raise SystemExit('zu viele fehlende Header')
def main():
    work = Path(tempfile.mkdtemp()); build_tree(work); r = build(work)
    if r.returncode: print('COMPILE-FEHLER:\n' + r.stderr[:2000]); return 1
    p = subprocess.run([str(work / 'real_g29')], capture_output=True, text=True); sys.stdout.write(p.stdout); return p.returncode
if __name__ == '__main__': sys.exit(main())
