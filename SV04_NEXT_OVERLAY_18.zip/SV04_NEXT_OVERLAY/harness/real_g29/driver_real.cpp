// Ausfuehrung des ECHTEN, vom Overlay GEPATCHTEN G29.cpp (echte Zickzack-Schleife, echter OEM-Reset des Meshs, echter Nachlauf) gegen ein Fake-Geraet. Stufe: SIMULATION, KEIN Marlin-Build.
#include "Marlin/src/feature/sv04_next/SV04NextG29UReceipt.hpp"
#include "Marlin/src/feature/sv04_next/SV04NextNativeThermalGate.hpp"
#include <algorithm>
#include <cmath>
#include <cstdio>
namespace sv04next { NativeThermalGate native_thermal_gate; }
extern bool sv04_next_g29_u_active;
World w; xyze_pos_t current_position; uint8_t active_extruder = 0; DualXMode dual_x_carriage_mode = DXC_AUTO_PARK_MODE; float inactive_extruder_x = 362.0f; bed_mesh_t z_values; xy_pos_t bilinear_start, bilinear_grid_spacing; float xy_probe_feedrate_mm_s;
Temperature thermalManager; bool Planner::leveling_active = true; Planner planner; xyz_pos_t Probe::offset = {0, 25, -1.10f}; Probe probe; GCodeParser parser; RTSSHOW rtscheck;
unsigned long millis(void) { return w.now_ms; }
static float value(int ix, int iy) { return 1.0f + 0.01f * (float)(iy * 4 + ix); }
float Probe::probe_at_point(const xy_pos_t &pos, const ProbePtRaise, const uint8_t, const bool, const bool) {
  int n = w.probe_calls++; w.now_ms += 7500; w.call_pos.push_back(pos); if (w.before_probe) w.before_probe(n);
  int ix = (int)std::lround((pos.x - bilinear_start.x) / bilinear_grid_spacing.x), iy = (int)std::lround((pos.y - bilinear_start.y) / bilinear_grid_spacing.y);
  auto it = w.ovr.find(n); if (it != w.ovr.end()) return it->second; return value(ix, iy) + (n % 2 ? 0.02f : 0.0f);
}
static float OLD[4][4]; static xy_pos_t OLDS, OLDSP; static const float PROBE_OFF_Z = -1.10f;
static void visit(int k, int &x, int &y) { y = k / 4; x = (y % 2 == 0) ? 3 - (k % 4) : k % 4; }   // echte Schleife: Zickzack, Aussenschleife Y, zuerst nach links
static void reset(const char *letters = "U", bool same_grid = false) {
  w = World(); w.parser_letters = letters; for (int x = 0; x < 4; ++x) for (int y = 0; y < 4; ++y) { OLD[x][y] = 0.10f * (float)x + 0.37f * (float)y + 0.05f; z_values[x][y] = OLD[x][y]; }
  Planner::leveling_active = true; Probe::offset.z = PROBE_OFF_Z; active_extruder = 0; dual_x_carriage_mode = DXC_AUTO_PARK_MODE; inactive_extruder_x = 362.0f; sv04_next_g29_u_active = false;
  if (same_grid) { bilinear_start.set(25, 25); bilinear_grid_spacing.set(84, 84); } else { bilinear_start.set(10, 20); bilinear_grid_spacing.set(5, 6); }
  OLDS = bilinear_start; OLDSP = bilinear_grid_spacing; sv04next::g29u_receipt = sv04next::G29UReceipt();
  sv04next::native_thermal_gate.reset(); for (uint32_t t = 0; t <= 25000u; t += 500u) sv04next::native_thermal_gate.observe(t, 60.0f, 60.0f, true); w.now_ms = 25000u; current_position = {100, 100, 5, 0};
}
enum Out { SUCCESS, ROLLBACK, REFUSED, NONU };
static int fails = 0, total = 0; static bool g_skip_off = false, g_prior_active = false;
static bool mesh_is_old() { return memcmp(z_values, OLD, sizeof(OLD)) == 0; }
static bool mesh_is_new() { for (int x = 0; x < 4; ++x) for (int y = 0; y < 4; ++y) if (std::fabs(z_values[x][y] - (value(x, y) + 0.01f)) > 1e-5f) return false; return true; }
static bool grid_is_old() { return bilinear_start == OLDS && bilinear_grid_spacing == OLDSP; }
static bool display_is_old() { for (int k = 0; k < 16; ++k) { int x, y; visit(k, x, y); if (std::fabs(w.rts_vals[k] - OLD[x][y] * 1000.0f) > 1e-3f) return false; } return true; }
static void run(const char *name, Out exp) {
  ++total; GcodeSuite::G29(); const auto &r = sv04next::g29u_receipt; std::string why; auto bad = [&](const char *m) { if (why.empty()) why = m; };
  if (!g_skip_off && Probe::offset.z != PROBE_OFF_Z && exp != NONU) bad("Z-Offset veraendert"); if (sv04_next_g29_u_active != g_prior_active) bad("Lauf-Flag nicht auf den Vorwert zurueckgesetzt");
  if (exp == SUCCESS) { if (r.phase() != sv04next::G29UReceipt::Phase::RamOnlySuccess || r.completed() != 16) bad("kein RamOnlySuccess 16/16"); if (!mesh_is_new()) bad("neues Mesh nicht im RAM (echte Zickzack-Reihenfolge)"); if (w.restore_msgs) bad("Rollback trotz Erfolg"); if (!Planner::leveling_active) bad("Leveling nicht aktiv"); if (w.progress_msgs != 16) bad("Fortschritt != 16"); if (w.probe_calls != 32) bad("nicht genau 2 Antastungen je Punkt"); if (w.rts_pages != 1) bad("RTS-Seitenwechsel nicht genau einmal"); }
  if (exp == ROLLBACK) { if (!mesh_is_old()) bad("altes Mesh NICHT wiederhergestellt (nach OEM-Reset)"); if (!grid_is_old()) bad("altes Raster NICHT wiederhergestellt"); if (r.phase() == sv04next::G29UReceipt::Phase::RamOnlySuccess) bad("Erfolgsbeleg trotz Fehler"); if (w.restore_msgs != 1) bad("kein (genau ein) Rollback"); if (!Planner::leveling_active) bad("Leveling nicht wie vorher"); if (w.refresh_calls < 1) bad("refresh_bed_level nicht aufgerufen"); if (w.rts_pages != 0) bad("Erfolgsseite trotz Fehler"); if (w.rts_seen < 16 || !display_is_old()) bad("Anzeige zeigt nicht das alte Mesh in der echten Reihenfolge"); if (w.rts_icon_zero < 1) bad("Fortschrittsicon nicht zurueckgesetzt"); }
  if (exp == REFUSED) { if (!mesh_is_old() || !grid_is_old()) bad("Mesh/Raster bei Verweigerung veraendert"); if (w.probe_calls != 0) bad("Sonde trotz Verweigerung benutzt"); if (r.phase() != sv04next::G29UReceipt::Phase::Refused) bad("Beleg nicht Refused"); if (w.restore_msgs || w.reset_calls || w.levelling_toggles) bad("Eingriff trotz Verweigerung"); }
  if (exp == NONU) { if (r.phase() != sv04next::G29UReceipt::Phase::Never) bad("Beleg bei normalem G29 veraendert"); if (w.restore_msgs) bad("Rollback bei normalem G29"); }
  if (!why.empty()) { ++fails; std::printf("FAIL  %-60s %s\n", name, why.c_str()); } else std::printf("PASS  %s\n", name);
}
#define SC(name, exp, setup) do { reset(); g_skip_off = false; g_prior_active = false; setup; run(name, exp); } while (0)
#define SCG(name, exp, setup) do { reset("U", true); g_skip_off = false; g_prior_active = false; setup; run(name, exp); } while (0)
int main() {
  SC("R00 Erfolg 16/16 (OEM setzt Raster neu), echte Zickzack-Reihenfolge, 2 Antastungen je Punkt", SUCCESS, {});
  SCG("R01 Erfolg 16/16 bei unveraendertem Raster (kein OEM-Reset)", SUCCESS, {}); { reset("U", true); GcodeSuite::G29(); std::printf("%s  R01b OEM-Reset des Meshs wird bei gleichem Raster NICHT aufgerufen\n", w.reset_calls == 0 ? "PASS" : "FAIL"); ++total; if (w.reset_calls) ++fails; }
  { reset(); GcodeSuite::G29(); ++total; bool ok = w.reset_calls == 1 && bilinear_start.x == 25 && bilinear_grid_spacing.x == 84; std::printf("%s  R01c OEM-Reset des Meshs bei geaendertem Raster genau einmal, neues Raster gesetzt\n", ok ? "PASS" : "FAIL"); if (!ok) ++fails; }
  char nm[110];
  for (int k = 0; k < 16; ++k) { std::snprintf(nm, sizeof nm, "F%02d erste Antastung NaN beim %d. Punkt (Raster geaendert, Mesh war vom OEM zurueckgesetzt)", k, k + 1); SC(nm, ROLLBACK, w.ovr[2 * k] = NAN); }
  for (int k = 0; k < 16; ++k) { std::snprintf(nm, sizeof nm, "G%02d zweite Antastung NaN beim %d. Punkt", k, k + 1); SC(nm, ROLLBACK, w.ovr[2 * k + 1] = NAN); }
  for (int k = 0; k < 16; ++k) { std::snprintf(nm, sizeof nm, "H%02d Abweichung 0,07 mm beim %d. Punkt", k, k + 1); int x, y; visit(k, x, y); SC(nm, ROLLBACK, w.ovr[2 * k + 1] = value(x, y) + 0.07f); }
  for (int k : {0, 7, 15}) { std::snprintf(nm, sizeof nm, "I%02d Messhoehe 3,01 mm beim %d. Punkt", k, k + 1); SC(nm, ROLLBACK, { w.ovr[2 * k] = 3.01f; w.ovr[2 * k + 1] = 3.01f; }); }
  for (int k : {0, 5, 15}) { std::snprintf(nm, sizeof nm, "T%02d Bett 61,5 C vor Antastung beim %d. Punkt", k, k + 1); SC(nm, ROLLBACK, w.before_probe = [k](int n) { if (n == 2 * k) w.bed = 61.5f; }); }
  for (int k : {0, 9}) { std::snprintf(nm, sizeof nm, "U%02d Soll-Temperatur 65 C mitten im Lauf (Punkt %d)", k, k + 1); SC(nm, ROLLBACK, w.before_probe = [k](int n) { if (n == 2 * k) w.target = 65; }); }
  for (int k : {0, 8, 15}) { std::snprintf(nm, sizeof nm, "P%02d Druckjob startet anderswo (Punkt %d)", k, k + 1); SC(nm, ROLLBACK, w.before_probe = [k](int n) { if (n == 2 * k) w.printing = true; }); }
  for (int k : {3, 12}) { std::snprintf(nm, sizeof nm, "N%02d Not-Aus (IsStopped) beim %d. Punkt", k, k + 1); SC(nm, ROLLBACK, w.before_probe = [k](int n) { if (n == 2 * k) w.stopped = true; }); }
  for (int k : {2, 13}) { std::snprintf(nm, sizeof nm, "W%02d Werkzeugwechsel auf T1 beim %d. Punkt", k, k + 1); SC(nm, ROLLBACK, w.before_probe = [k](int n) { if (n == 2 * k) active_extruder = 1; }); }
  for (int k : {4, 11}) { std::snprintf(nm, sizeof nm, "A%02d Z-Achse verliert Vertrauen beim %d. Punkt", k, k + 1); SC(nm, ROLLBACK, w.before_probe = [k](int n) { if (n == 2 * k) w.trusted[2] = false; }); }
  for (int k : {1, 10}) { std::snprintf(nm, sizeof nm, "O%02d Probe-Offset aendert sich mitten im Lauf (Punkt %d)", k, k + 1); SC(nm, ROLLBACK, w.before_probe = [k](int n) { if (n == 2 * k) Probe::offset.z = -1.20f; }); }
  SC("D01 DXC-Modus wechselt mitten im Lauf", ROLLBACK, w.before_probe = [](int n) { if (n == 6) dual_x_carriage_mode = DXC_FULL_CONTROL_MODE; });
  SC("D02 inaktiver Schlitten X2 verlaesst 362 mitten im Lauf", ROLLBACK, w.before_probe = [](int n) { if (n == 6) inactive_extruder_x = 300.0f; });
  SC("L01 Leveling WAEHREND der Messung ausgeschaltet: der echte Nachlauf (Zeile 883) schaltet es wieder ein, Erfolg", SUCCESS, w.before_probe = [](int n) { if (n == 0) Planner::leveling_active = false; });
  SC("V01 vorab: Thermotor nicht bereit (nie 20 s beobachtet)", REFUSED, sv04next::native_thermal_gate.reset());
  for (const char *m : {"UN", "UO", "UJ", "UW", "UD", "UC", "UZ", "UE", "UH", "UL", "UR", "UB", "UF", "US", "UV", "UX", "UY", "UP", "UQ", "UT"}) { std::snprintf(nm, sizeof nm, "V02 vorab: Modifikator %c zusaetzlich zu U", m[1]); reset(m); g_skip_off = false; g_prior_active = false; run(nm, REFUSED); }
  SC("V03 vorab: Bewegung in der Warteschlange", REFUSED, w.blocks = true); SC("V04 vorab: Druck laeuft", REFUSED, w.printing = true); SC("V05 vorab: Druck pausiert", REFUSED, w.paused = true); SC("V06 vorab: Not-Aus gesetzt", REFUSED, w.stopped = true);
  SC("V07 vorab: Werkzeug T1 aktiv", REFUSED, active_extruder = 1); SC("V08 vorab: DXC-Modus nicht Auto-Park", REFUSED, dual_x_carriage_mode = DXC_FULL_CONTROL_MODE);
  for (int a = 0; a < 3; ++a) { std::snprintf(nm, sizeof nm, "V09 vorab: Achse %d nicht vertrauenswuerdig", a); SC(nm, REFUSED, w.trusted[a] = false); }
  SC("V10 vorab: X2 nicht bei 362", REFUSED, inactive_extruder_x = 300.0f); SC("V11 vorab: Bett 58 C", REFUSED, w.bed = 58.0f); SC("V12 vorab: Soll-Temperatur 0", REFUSED, w.target = 0);
  SC("V13 vorab: Probe-Offset NaN", REFUSED, { Probe::offset.z = NAN; g_skip_off = true; }); SC("V14 vorab: Wiedereintritt (Lauf aktiv)", REFUSED, { sv04_next_g29_u_active = true; g_prior_active = true; });
  struct Tr { const char *n; std::function<void()> on, off; };
  std::vector<Tr> trs = { {"Druckjob", [] { w.printing = true; }, [] { w.printing = false; }}, {"Not-Aus", [] { w.stopped = true; }, [] { w.stopped = false; }}, {"Werkzeug T1", [] { active_extruder = 1; }, [] { active_extruder = 0; }}, {"X-Vertrauen", [] { w.trusted[0] = false; }, [] { w.trusted[0] = true; }},
    {"DXC-Modus", [] { dual_x_carriage_mode = DXC_FULL_CONTROL_MODE; }, [] { dual_x_carriage_mode = DXC_AUTO_PARK_MODE; }}, {"X2 verlaesst 362", [] { inactive_extruder_x = 300.0f; }, [] { inactive_extruder_x = 362.0f; }}, {"Probe-Offset", [] { Probe::offset.z = -1.2f; }, [] { Probe::offset.z = PROBE_OFF_Z; }}, {"Soll 65 C", [] { w.target = 65; }, [] { w.target = 60; }}, {"Bett 61,5 C", [] { w.bed = 61.5f; }, [] { w.bed = 60.0f; }} };
  for (const auto &t : trs) { std::snprintf(nm, sizeof nm, "K01 kurzzeitig %s zwischen Punkt 6 und 7", t.n); SC(nm, ROLLBACK, w.before_probe = [t](int n) { if (n == 11) t.on(); if (n == 12) t.off(); }); }
  for (const auto &t : trs) { std::snprintf(nm, sizeof nm, "K02 %s erst bei der letzten Antastung", t.n); SC(nm, ROLLBACK, w.before_probe = [t](int n) { if (n == 31) t.on(); }); }
  for (int k : {0, 7, 15}) { std::snprintf(nm, sizeof nm, "K03 Bett 61,5 C nur direkt nach der Antastung (Punkt %d)", k + 1); SC(nm, ROLLBACK, { w.before_probe = [k](int n) { if (n == 2 * k + 1) w.bed = 61.5f; }; w.on_progress = [k](int p) { if (p == k) w.bed = 60.0f; }; }); }
  { reset(); GcodeSuite::G29(); ++total; bool a = mesh_is_new(); float meshA[4][4]; memcpy(meshA, z_values, sizeof(meshA)); w.probe_calls = 0; w.call_pos.clear(); w.restore_msgs = 0; w.progress_msgs = 0; w.rts_pages = 0; w.ovr.clear(); w.ovr[19] = NAN; sv04next::native_thermal_gate.reset(); for (uint32_t t = 30000; t <= 52000u; t += 500u) sv04next::native_thermal_gate.observe(t, 60.0f, 60.0f, true); w.now_ms = 52000u;
    GcodeSuite::G29(); bool b = memcmp(z_values, meshA, sizeof(meshA)) == 0 && w.restore_msgs == 1; w.probe_calls = 0; w.call_pos.clear(); w.restore_msgs = 0; w.ovr.clear(); w.progress_msgs = 0; w.rts_pages = 0; sv04next::native_thermal_gate.reset(); for (uint32_t t = 60000; t <= 82000u; t += 500u) sv04next::native_thermal_gate.observe(t, 60.0f, 60.0f, true); w.now_ms = 82000u; GcodeSuite::G29();
    bool c = sv04next::g29u_receipt.phase() == sv04next::G29UReceipt::Phase::RamOnlySuccess && w.restore_msgs == 0 && mesh_is_new(); std::printf("%s  Q01 Folge Erfolg, Fehler (Rueckfall auf das ERFOLGS-Mesh, nicht das Urmesh), Erfolg ohne Zwischen-Reset (a=%d b=%d c=%d)\n", a && b && c ? "PASS" : "FAIL", a, b, c); if (!(a && b && c)) ++fails; }
  { reset(""); w.ovr.clear(); GcodeSuite::G29(); ++total; bool ok = sv04next::g29u_receipt.phase() == sv04next::G29UReceipt::Phase::Never && w.restore_msgs == 0 && w.probe_calls == 16 && w.rts_pages == 1 && Planner::leveling_active; std::printf("%s  N01 normaler G29 (ohne U): 1 Antastung je Punkt (16), kein Beleg, kein Rollback, OEM-Seitenwechsel einmal, Leveling aktiv (Antastungen %d)\n", ok ? "PASS" : "FAIL", w.probe_calls); if (!ok) ++fails; }
  { reset(""); w.ovr[5] = NAN; GcodeSuite::G29(); ++total; bool ok = w.restore_msgs == 0 && !mesh_is_old(); std::printf("%s  N02 normaler G29 mit Sondenfehler: OEM-Verhalten bleibt (Mesh bleibt zurueckgesetzt/teilweise, KEIN Eingriff des Guards)\n", ok ? "PASS" : "FAIL"); if (!ok) ++fails; }
  std::printf("=== %d REAL-G29-Pruefungen, %d FAIL\n", total, fails); return fails ? 1 : 0;
}
