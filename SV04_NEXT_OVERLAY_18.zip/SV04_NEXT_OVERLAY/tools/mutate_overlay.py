#!/usr/bin/env python3
"""Mutationskampagne gegen die Stand-15-Sicherheitslogik des Patchers (v2 Differenzialsperre, v13/v7 Aufrufe, v14 strukturelle G28-Analyse und Audits, v16 CLI).
Pro Mutant wird EINE Datei geaendert und die Tests laufen in dieser Reihenfolge, bis einer fehlschlaegt: forms, v14, v16, real_oem. killed / SURVIVED / UNGUELTIG."""
import os, shutil, subprocess, sys, tempfile
from concurrent.futures import ThreadPoolExecutor
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..')); I = 'integration/'
V14, V13, V2, V16 = I + 'apply_native_guard_v14.py', I + 'apply_native_guard_v13.py', I + 'apply_native_guard_v2.py', I + 'apply_native_guard_v16.py'
M = [
 ('N01', V14, 'Marker-Vorpruefung entfernt', "if mk in text:raise PatchRefused(f'{name}: already contains", "if False:raise PatchRefused(f'{name}: already contains"),
 ('N02', V14, 'Topologieprobleme werden ignoriert', "    if topo['problems']:\n        raise PatchRefused('OEM G28 IDEX homeaxis topology mismatch: '", "    if False:\n        raise PatchRefused('OEM G28 IDEX homeaxis topology mismatch: '"),
 ('N03', V14, 'jeder ungepaarte T0-Aufruf wird akzeptiert (kein isPrinting()-Schutz noetig)', "elif 'isPrinting()' in o['recent']:", "elif True:"),
 ('N04', V14, 'beliebiger unklassifizierter Aufruf wird als Nicht-IDEX-Zweig akzeptiert', "if any('DUAL_X_CARRIAGE' in c and br=='else' for c,br in o['pp']):", "if True:"),
 ('N05', V14, 'X2-Fahrt bei offenem Paar wird nicht bemaengelt', "if open_ is not None:problems.append('line %d: X2 homing while the pair", "if False:problems.append('line %d: X2 homing while the pair"),
 ('N06', V14, 'nie geschlossenes Paar wird nicht bemaengelt', "if open_ is not None:problems.append('line %d: X2 homing is never followed", "if False:problems.append('line %d: X2 homing is never followed"),
 ('N07', V14, 'Obergrenze der Paare entfernt', "if len(pairs)>MAX_IDEX_PAIRS:problems.append", "if False:problems.append"),
 ('N08', V14, 'Instrumentierung mit VERALTETER Analyse (alte Zeilenindizes)', "g28=instrument_idex_pairs(g28,topo2)", "g28=instrument_idex_pairs(g28,topo)"),
 ('N09', V14, 'Pruefung "Struktur zwischen Analyse und Instrumentierung veraendert" entfernt', "    if topo2['problems'] or [(len(topo2[k])) for k in ('pairs','singles','non_idex')]!=[len(topo[k]) for k in ('pairs','singles','non_idex')]:", "    if False:"),
 ('N10', V14, 'Hakenpositions-Audit entfernt', "if hooked('2')!=topo['x2'] or hooked('1')!=topo['x1']:raise", "if False:raise"),
 ('N11', V14, 'Zaehlaudit der Haken entfernt', "if g28.count('saw_x2_homeaxis_return(')!=topo['x2'] or g28.count('saw_x1_homeaxis_return(')!=topo['x1']:", "if False:"),
 ('N12', V14, 'Audit der homeaxis-Aufrufanzahl entfernt', "if g28.count('homeaxis(X_AXIS);')!=topo['x2']*2+topo['other_homeaxis_x']:raise", "if False:raise"),
 ('N13', V14, 'Haken von oben nach unten eingefuegt (Indizes verschieben sich)', "for idx,k in sorted(todo,reverse=True):", "for idx,k in sorted(todo):"),
 ('N14', V14, 'Hakenbedingung ohne DUAL_X_CARRIAGE (weicht von der Deklaration ab)', "HOOK_GUARD='#if ENABLED(DUAL_X_CARRIAGE) && ENABLED(AUTO_BED_LEVELING_BILINEAR)", "HOOK_GUARD='#if ENABLED(AUTO_BED_LEVELING_BILINEAR)"),
 ('N15', V2, 'Differenzialsperre tut nichts mehr', "if extra > 0: raise PatchRefused", "if extra > 10**6: raise PatchRefused"),
 ('N16', V13, 'LCD_RTS-Sperre wieder als Ganztextpruefung (Fehlalarm auf OEM-Code)', "    _v2.no_new_tokens(original[RTS], rt, ('settings.save()', 'queue.enqueue_now(\"M500\")'), 'RTS automation forbidden')", "    if any(x in rt for x in ('settings.save()', 'queue.enqueue_now(\"M500\")')): raise PatchRefused('RTS automation forbidden')"),
 ('N17', V16, 'CLI sucht Header relativ zum Arbeitsverzeichnis (der Fehler aus Workflow 15)', "here = Path(__file__).resolve().parent.parent / 'include'", "here = Path('include')"),
 ('N18', V16, 'fehlende Header werden nicht gemeldet', "    if missing: raise SystemExit(", "    if False: raise SystemExit("),
]
TESTS = ['test_overlay_v14_forms.py', 'test_overlay_v14.py', 'test_overlay_v16.py', 'test_overlay_real_oem.py']
def one(item):
    mid, f, why, old, new = item; src = open(os.path.join(ROOT, f), encoding='utf-8').read()
    if src.count(old) != 1: return (mid, why, 'UNGUELTIG(%d)' % src.count(old), '')
    d = tempfile.mkdtemp()
    for sub in ('integration', 'include', 'tests'): shutil.copytree(os.path.join(ROOT, sub), os.path.join(d, sub), ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    open(os.path.join(d, f), 'w', encoding='utf-8').write(src.replace(old, new)); env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    for t in TESTS:
        try: r = subprocess.run([sys.executable, 'tests/' + t], cwd=d, capture_output=True, text=True, env=env, timeout=240)
        except subprocess.TimeoutExpired: shutil.rmtree(d, ignore_errors=True); return (mid, why, 'killed', t + ': Zeitueberschreitung')
        if r.returncode: shutil.rmtree(d, ignore_errors=True); return (mid, why, 'killed', t + ': ' + (r.stderr.strip().splitlines() or [''])[-1][:70])
    shutil.rmtree(d, ignore_errors=True); return (mid, why, 'SURVIVED', '')
with ThreadPoolExecutor(max_workers=2) as ex: res = list(ex.map(one, M))
for mid, why, st, info in res: print(f'{mid} {st:9} {why}' + (f'  <- {info}' if info else ''))
k = sum(r[2] == 'killed' for r in res); s = [r[0] for r in res if r[2] == 'SURVIVED']; bad = [r[0] for r in res if r[2].startswith('UNGUELTIG')]
print(f'--- erkannt {k}, UEBERLEBT {len(s)}: {s}, ungueltig {len(bad)} {bad} von {len(res)}')
