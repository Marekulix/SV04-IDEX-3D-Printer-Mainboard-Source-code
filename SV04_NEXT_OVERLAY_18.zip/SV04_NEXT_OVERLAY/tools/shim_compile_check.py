#!/usr/bin/env python3
"""Typ-/Syntaxpruefung des vom Overlay EINGEFUEGTEN Codes im Kontext der ECHTEN OEM-Dateien gegen eine SHIM-Umgebung (kein Marlin-Build, kein C-Nachweis).
Methode: Overlay auf die echten OEM-Dateien anwenden (nur im Speicher/Arbeitsordner); ungepatchte und gepatchte Datei mit g++ -fsyntax-only (OHNE -fpermissive) uebersetzen;
Fehler des umgebenden OEM-Codes (fehlende Marlin-Header) sind Rauschen und im Original identisch. Gewertet werden nur Fehler in EINGEFUEGTEN Zeilen, die im Original nicht
(gleicher Zeilentext, gleiche Meldung) vorkommen. Die Shim deklariert die Marlin-Namen mit den Signaturen der ECHTEN Header (tests/oem_real_headers). Selbstpruefungen:
Der eingefuegte Code muss im Praeprozessor-Ergebnis vorkommen, die Shim selbst darf keine Fehler haben, und die Gegenprobe (absichtlich eingebaute Fehler) muss gefunden werden.
Aufruf: python3 tools/shim_compile_check.py [--no-negative]"""
import argparse, difflib, re, shutil, subprocess, sys, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path[:0] = [str(ROOT / 'integration')]
import apply_native_guard_v16 as v16
SHIM = ROOT / 'tools/shim/shim.h'
AUTO60 = ('Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp', ['-DSV04_NEXT_AUTO60_ENGINE'], {'auto60_glue_tick': 2, 'Auto60Engine': 3, 'setTargetBed': 2, 'enqueue_one_P': 2})
FILES = {'Marlin/src/gcode/calibrate/G28.cpp': {'sv04next::': 5, 'sv04_g28_scope': 1, 'saw_x2_homeaxis_return': 1}, 'Marlin/src/gcode/bedlevel/abl/G29.cpp': {'sv04_mesh_guard': 3, 'g29u_receipt': 5}, 'Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp': {'sv04next::': 10, 'g29u_receipt': 1, 'native_thermal_gate': 1}}
CFG = ['-DDUAL_X_CARRIAGE', '-DAUTO_BED_LEVELING_BILINEAR', '-DRTS_AVAILABLE', '-DBLTOUCH', '-DEEPROM_SETTINGS', '-DZ_SAFE_HOMING', '-DRESTORE_LEVELING_AFTER_G28', '-DENABLE_LEVELING_FADE_HEIGHT', '-DHAS_MULTI_HOTEND',
       '-DGRID_MAX_POINTS_X=4', '-DGRID_MAX_POINTS_Y=4', '-DHAS_ABL_NOT_UBL=1', '-DHAS_BED_PROBE=1', '-DHAS_LEVELING=1', '-DHAS_HEATED_BED=1', '-DABL_USES_GRID=1', '-DHAS_PROBING_PROCEDURE=1', '-DHAS_RTS=1']


def build_trees(work: Path):
    oem = ROOT / 'tests/oem_real'; v14 = v16.v15.v14; orig = {n: (oem / n).read_text(encoding='utf-8') for n in v14.OEM_BLOBS}
    heads = [(ROOT / 'include' / n).read_text(encoding='utf-8') for n in v16.HEADERS]; out = v16.render(dict(orig), *heads)
    for tree, files in (('orig', orig), ('patched', out)):
        for n, t in files.items(): p = work / tree / n; p.parent.mkdir(parents=True, exist_ok=True); p.write_text(t, encoding='utf-8')
        shutil.copytree(ROOT / 'tests/oem_real_headers', work / tree, dirs_exist_ok=True)
    (work / 'inc').mkdir(exist_ok=True); return orig, out


def compile_file(work: Path, root: Path, rel: str, extra=()):
    f = root / rel
    for _ in range(500):
        r = subprocess.run(['g++', '-std=gnu++14', '-fsyntax-only', '-w', '-fmax-errors=0', f'-I{work / "inc"}', '-include', str(SHIM), *CFG, *extra, str(f)], capture_output=True, text=True)
        m = re.search(r'^(\S+?):(\d+):\d+: fatal error: (.+?): No such file or directory', r.stderr, re.M)
        if not m: return r.stderr
        line = Path(m.group(1)).read_text(encoding='utf-8', errors='replace').split('\n')[int(m.group(2)) - 1]
        inc = (work / 'inc' / m.group(3)) if '<' in line else (Path(m.group(1)).parent / m.group(3)); inc.parent.mkdir(parents=True, exist_ok=True); inc.write_text('')
    raise SystemExit('zu viele fehlende Header')


def errs(stderr: str, name: str, text_lines):
    out = []
    for m in re.finditer(r'^(\S+?):(\d+):\d+: error: (.*)$', stderr, re.M):
        if Path(m.group(1)).name == name:
            ln = int(m.group(2)); out.append((ln, text_lines[ln - 1].strip() if 0 < ln <= len(text_lines) else '', m.group(3)))
    return out


def inserted(orig_text: str, patched_text: str):
    a, b = orig_text.split('\n'), patched_text.split('\n'); ins = set()
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
        if tag in ('insert', 'replace'): ins.update(range(j1 + 1, j2 + 1))
    return ins


def check_file(work, rel, orig, out, root_patched='patched', extra=()):
    name = Path(rel).name; so = compile_file(work, work / 'orig', rel, extra); sp = compile_file(work, work / root_patched, rel, extra)
    bad = [l for l in (so + sp).splitlines() if 'shim.h' in l and ': error:' in l]
    if bad: raise SystemExit('SHIM SELBST FEHLERHAFT: ' + bad[0][:200])
    eo = errs(so, name, orig[rel].split('\n')); ptxt = (work / root_patched / rel).read_text(encoding='utf-8'); ep = errs(sp, name, ptxt.split('\n')); ins = inserted(orig[rel], ptxt)
    known = {(t, m) for _, t, m in eo}; new = [(l, t, m) for l, t, m in ep if l in ins and (t, m) not in known]
    for m in re.finditer(r'^(\S*sv04_next/\S+?):(\d+):\d+: error: (.*)$', sp, re.M): new.append((int(m.group(2)), Path(m.group(1)).name, m.group(3)))   # Fehler IN den Overlay-Headern
    pre = subprocess.run(['g++', '-std=gnu++14', '-E', '-P', f'-I{work / "inc"}', '-include', str(SHIM), *CFG, *extra, str(work / root_patched / rel)], capture_output=True, text=True).stdout
    return {'orig_errors': len(eo), 'patched_errors': len(ep), 'inserted_lines': len(ins), 'new_in_inserted': new, 'reached': {k: pre.count(k) for k in FILES[rel]}}


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--no-negative', action='store_true'); a = ap.parse_args(); work = Path(tempfile.mkdtemp()); orig, out = build_trees(work); rc = 0
    for rel, need in FILES.items():
        r = check_file(work, rel, orig, out); ok = not r['new_in_inserted'] and all(r['reached'][k] >= v for k, v in need.items())
        print(f"{Path(rel).name:12} Original {r['orig_errors']:3} / gepatcht {r['patched_errors']:3} Rauschfehler | eingefuegte Zeilen {r['inserted_lines']:3} | NEUE Fehler in eingefuegten Zeilen {len(r['new_in_inserted'])} | Code erreicht {r['reached']} -> {'OK' if ok else 'FEHLER'}")
        for l, t, m in r['new_in_inserted'][:8]: print(f'      Zeile {l}: {m[:140]}  [{t[:70]}]')
        rc |= (not ok)
    rel, extra, need = AUTO60; r = check_file(work, rel, orig, out, extra=extra); r['reached'].update({k: 0 for k in need}); pre = subprocess.run(['g++', '-std=gnu++14', '-E', '-P', f'-I{work / "inc"}', '-include', str(SHIM), *CFG, *extra, str(work / 'patched' / rel)], capture_output=True, text=True).stdout; r['reached'] = {k: pre.count(k) for k in need}
    ok = not r['new_in_inserted'] and all(r['reached'][k] >= v for k, v in need.items()); print(f"{'LCD_RTS+Auto60':14} Original {r['orig_errors']:3} / gepatcht {r['patched_errors']:3} Rauschfehler | NEUE Fehler in eingefuegten Zeilen/Headern {len(r['new_in_inserted'])} | Bruecke erreicht {r['reached']} -> {'OK' if ok else 'FEHLER'}")
    for l, t, m in r['new_in_inserted'][:8]: print(f'      {l}: {m[:140]}  [{t[:70]}]')
    return rc | (not ok)


if __name__ == '__main__': sys.exit(main())
