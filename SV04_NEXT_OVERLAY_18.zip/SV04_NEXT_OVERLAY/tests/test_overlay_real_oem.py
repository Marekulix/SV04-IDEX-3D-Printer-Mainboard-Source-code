"""Overlay gegen die ECHTEN OEM-Dateien (tests/oem_real/, unveraenderte Kopien aus dem Repository, Git-Blob-SHA1 geprueft).
Beweist am echten Text: strenger Trockenlauf und Anwendung gelingen, OEM-Code bleibt erhalten, Eingriffe liegen an den vorgesehenen Stellen,
CLI laeuft aus jedem Arbeitsverzeichnis, Atomaritaet. Stufe: SIMULATION/Text (kein Marlin-Build)."""
import difflib, hashlib, json, os, re, shutil, subprocess, sys, tempfile
from pathlib import Path
root = Path(__file__).resolve().parents[1]; sys.path[:0] = [str(root / 'integration')]
import apply_native_guard_v16 as v16
v15 = v16.v15; v14 = v15.v14; OEM = root / 'tests/oem_real'; names = list(v14.OEM_BLOBS)
blob = lambda b: hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
HEADS = [(root / 'include' / n).read_text(encoding='utf-8') for n in v16.HEADERS]
n_ck = [0]
def ck(c, m=''): assert c, m; n_ck[0] += 1
orig = {n: (OEM / n).read_text(encoding='utf-8') for n in names}
for n in names: ck(blob((OEM / n).read_bytes()) == v14.OEM_BLOBS[n], 'Fixture ist nicht der erwartete OEM-Stand: ' + n)
out = v16.render(dict(orig), *HEADS); ck(True)                      # 1 vollstaendige Kette auf den ECHTEN Texten
ck(out['Marlin/Configuration.h'] == orig['Marlin/Configuration.h'] and out['Marlin/src/module/probe.cpp'] == orig['Marlin/src/module/probe.cpp'], 'Configuration.h/probe.cpp veraendert')
# 2 reale G28-Topologie (strukturell, nicht per Zaehlung)
t = v14.idex_topology(orig[v14.G28]); ck(len(t['pairs']) == 2 and t['x2_lines'] == [400, 466] and t['x1_lines'] == [407, 473] and not t['problems'], t)
ck([s['line'] for s in t['singles']] == [486] and 'isPrinting' in t['singles'][0]['reason'] and len(t['non_idex']) == 1 and t['order'] == '21o211', t)
g = out[v14.G28]; ck(g.count('saw_x2_homeaxis_return(') == 2 and g.count('saw_x1_homeaxis_return(') == 2, 'Haken je Paar'); ck(g.count('homeaxis(X_AXIS);') == 6)
L = g.split('\n')
for i, l in enumerate(L):                                         # jeder Haken steht DIREKT hinter einem homeaxis(X_AXIS)-Aufruf, der zu einem Paar gehoert
    if 'saw_x2_homeaxis_return(' in l or 'saw_x1_homeaxis_return(' in l: ck('homeaxis(X_AXIS);' in L[i - 2], 'Haken nicht direkt hinter homeaxis: ' + str(i)); ck(L[i - 2].strip() == 'homeaxis(X_AXIS);')
single = [i for i, l in enumerate(L) if 'homeaxis(X_AXIS);' in l and 'card.isPrinting' in ' '.join(L[max(0, i - 6):i])]; ck(len(single) == 1 and 'saw_' not in L[single[0] + 1], 'ungepaarter T0-Aufruf unter isPrinting() darf nicht instrumentiert sein')
# 3 OEM-Erhaltung: Zeilenweiser Vergleich, nur Einfuegungen (plus zwei bekannte Ersetzungen in G29.cpp)
def line_ops(name):
    a = orig[name].split('\n'); b = out[name].split('\n'); sm = difflib.SequenceMatcher(None, a, b, autojunk=False); ops = [o for o in sm.get_opcodes() if o[0] != 'equal']; return a, b, ops
for name in (v14.G28, v14.RTS):
    a, b, ops = line_ops(name); ck(all(o[0] == 'insert' for o in ops), f'{name}: OEM-Zeile geaendert/entfernt: {[o for o in ops if o[0] != "insert"][:2]}')
a, b, ops = line_ops('Marlin/src/gcode/bedlevel/abl/G29.cpp'); rep = [o for o in ops if o[0] != 'insert']; ck(len(rep) == 2 and all(o[0] == 'replace' for o in rep), [o[0] for o in rep])
removed = sorted(a[i].strip() for o in rep for i in range(o[1], o[2]))
ck(removed == sorted(['abl.measured_z = faux ? 0.001f * random(-100, 101) : probe.probe_at_point(abl.probePos, raise_after, abl.verbose_level);', 'RTS_AutoBedLevelPage();']), removed)
G = out['Marlin/src/gcode/bedlevel/abl/G29.cpp']                    # normaler G29 bleibt: die OEM-Antastzeile steht unveraendert im else-Zweig, RTS-Seitenwechsel im Nicht-U-Pfad
ck(G.count('abl.measured_z = faux ? 0.001f * random(-100, 101) : probe.probe_at_point(abl.probePos, raise_after, abl.verbose_level);') == 1)
ck(re.search(r'else\n\s*abl\.measured_z = faux \? 0\.001f \* random\(-100, 101\) : probe\.probe_at_point\(abl\.probePos, raise_after, abl\.verbose_level\);', G) is not None, 'OEM-Antastzeile nicht als else-Zweig erhalten')
ck(re.search(r'if \(!sv04_transactional_run \|\| !isnan\(abl\.measured_z\)\)\n\s*RTS_AutoBedLevelPage\(\);', G) is not None)
# 4 Eingriffe in LCD_RTS nur im Dateikopf und am ANFANG von RTSUpdate(); keine einzige Zeile in den Tastenbehandlern (manuelle/gefuehrte Justage bleibt unberuehrt)
a, b, ops = line_ops(v14.RTS); fn = [i for i, l in enumerate(a) if re.match(r'^(void|bool|int|static)\s+\w+.*\)\s*$', l.strip()) or re.match(r'^[\w:<>\*& ]+\s+\w+::?\w*\(.*\)\s*$', l.strip())]
upd = a.index('void RTSUpdate()'); first_after = [i for i in range(upd, len(a)) if a[i].strip() == '// Check the status of card'][0]
for tag, i1, i2, j1, j2 in ops:
    ck(i1 < 80 or i1 == upd + 2 or i1 == first_after, f'Einfuegung ausserhalb der vorgesehenen Stellen bei OEM-Zeile {i1}')   # Kopf (Includes/Namensraeume) oder RTSUpdate-Anfang
ck(len(ops) == 4 or len(ops) == 3, [(o[1], o[2] - o[1], o[4] - o[3]) for o in ops])
for tok in ('settings.save()', 'queue.enqueue_now("M500")', 'enqueue_now', 'setTargetBed('): ck(out[v14.RTS].count(tok) == orig[v14.RTS].count(tok), f'Overlay fuegt {tok} in LCD_RTS ein')   # differenzielle Sperre
for tok in ('settings.save()', 'M500', 'queue.enqueue', 'setTargetBed(', 'process_subcommands_now'): ck(out['Marlin/src/gcode/bedlevel/abl/G29.cpp'].count(tok) == orig['Marlin/src/gcode/bedlevel/abl/G29.cpp'].count(tok), f'Overlay fuegt {tok} in G29 ein')
# 4b jeder Haken steht unter DERSELBEN Bedingung wie die Deklaration des Trace-Objekts (sonst Compilefehler bei anderer Konfiguration)
DECL_GUARD = '#if ENABLED(DUAL_X_CARRIAGE) && ENABLED(AUTO_BED_LEVELING_BILINEAR) && DISABLED(PROBE_MANUALLY)'
ck(all(L[i - 1].strip() == DECL_GUARD and L[i + 1].strip() == '#endif' for i, l in enumerate(L) if 'saw_x2_homeaxis_return(' in l or 'saw_x1_homeaxis_return(' in l), 'Haken-Bedingung weicht von der Deklarationsbedingung ab')
di = [i for i, l in enumerate(L) if l.strip() == 'namespace sv04next { NativeIdexHomingTrace native_idex_homing_trace; }']
ck(len(di) == 1 and L[di[0] - 2].strip() == DECL_GUARD and L[di[0] + 1].strip() == '#endif', 'Deklaration des Trace-Objekts nicht unter der erwarteten Bedingung')
# 4c Differenzielle Sperre wirkt in BEIDE Richtungen: OEM-Zeichenketten sind erlaubt, vom Overlay zusaetzlich eingefuehrte werden verweigert
import apply_native_guard_v2 as _v2
_v2.no_new_tokens('a settings.save() b', 'a settings.save() b X', ('settings.save()',), 'test'); ck(True)                      # gleiche Anzahl: erlaubt
try: _v2.no_new_tokens('a b', 'a settings.save() b', ('settings.save()',), 'test'); ck(False)
except v14.PatchRefused as e: ck('overlay adds 1x' in str(e))
try: _v2.no_new_tokens('x settings.save()', 'x settings.save() settings.save()', ('settings.save()',), 'test'); ck(False)
except v14.PatchRefused as e: ck('unmodified OEM text contains 1x' in str(e))
import apply_native_guard_v13 as v13                                                                                       # das OVERLAY fuegt selbst einen verbotenen Token ein (Einfuegetext von v13 manipuliert)
real_ro = v13.replace_one
def evil(value, before, after, name='?'):
    if name == v14.RTS and 'g28_g29_order_witness.observe' in after: after = after + '\n    settings.save();'
    return real_ro(value, before, after, name)
v13.replace_one = evil
try: v16.render(dict(orig), *HEADS); ck(False, 'Differenzialsperre hat nicht ausgeloest')
except v14.PatchRefused as e: ck('RTS automation forbidden' in str(e) and 'overlay adds 1x' in str(e) and 'OEM text contains 6x' in str(e), str(e))
finally: v13.replace_one = real_ro
v16.render(dict(orig), *HEADS); ck(True)                                                                                  # nach der Manipulation wieder fehlerfrei
# 5 Wiederholung auf gepatchtem Text wird verweigert (klare Meldung)
try: v16.render(dict(out), *HEADS); ck(False, 'zweites Anwenden haette verweigert werden muessen')
except v14.PatchRefused as e: ck('already contains SV04 NEXT marker' in str(e), str(e))
# 6 CLI aus verschiedenen Arbeitsverzeichnissen gegen echte Dateien: Trockenlauf aendert nichts, Anwendung schreibt nur die drei Dateien plus 16 Header
def fresh_root():
    d = Path(tempfile.mkdtemp())
    for n in names: p = d / n; p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes((OEM / n).read_bytes())
    return d
cli = str(root / 'integration/apply_native_guard_v16.py'); env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
for cwd in ('root', '/', 'other'):
    d = fresh_root(); before = {n: (d / n).read_bytes() for n in names}; wd = d if cwd == 'root' else (Path('/') if cwd == '/' else Path(tempfile.mkdtemp()))
    r = subprocess.run([sys.executable, cli, '--root', str(d), '--dry-run', '--diff-out', str(d / 'review.diff')], cwd=wd, capture_output=True, text=True, env=env); ck(r.returncode == 0, f'Trockenlauf cwd={cwd}: {r.stderr[-300:]}')
    ck(all((d / n).read_bytes() == before[n] for n in names) and not (d / 'Marlin/src/feature').exists() and (d / 'review.diff').is_file(), 'Trockenlauf hat geschrieben')
    r = subprocess.run([sys.executable, cli, '--root', str(d), '--evidence', str(d / 'evidence.json')], cwd=wd, capture_output=True, text=True, env=env); ck(r.returncode == 0, f'Anwendung cwd={cwd}: {r.stderr[-300:]}')
    ev = json.loads((d / 'evidence.json').read_text()); ck(set(ev['changed_sha256']) >= {v14.G28, v14.RTS, 'Marlin/src/gcode/bedlevel/abl/G29.cpp'} and ev['eeprom_write'] is False and ev['flash_approved'] is False and ev['auto60_engine_compiled_by_default'] is False)
    ck((d / 'Marlin/Configuration.h').read_bytes() == before['Marlin/Configuration.h'] and (d / 'Marlin/src/module/probe.cpp').read_bytes() == before['Marlin/src/module/probe.cpp'])
    ck(len(list((d / 'Marlin/src/feature/sv04_next').glob('*.hpp'))) == 16, 'Header fehlen'); ck((d / v14.G28).read_text() == out[v14.G28], 'CLI-Ergebnis weicht vom Render ab')
    r = subprocess.run([sys.executable, cli, '--root', str(d), '--dry-run'], cwd=wd, capture_output=True, text=True, env=env); ck(r.returncode != 0 and 'SHA mismatch' in r.stderr, 'zweite Anwendung muss an der SHA-Sperre scheitern')
# 7 fehlende Header: klare Meldung mit Pfad statt Traceback
d = fresh_root(); r = subprocess.run([sys.executable, cli, '--root', str(d), '--dry-run', '--sv04nextnativethermalgate', str(d / 'fehlt.hpp')], capture_output=True, text=True, env=env); ck(r.returncode != 0 and 'overlay header(s) not found' in r.stderr and 'fehlt.hpp' in r.stderr, r.stderr[-200:])
# 8 Atomaritaet an JEDER Schreibposition auf den echten Dateien
real_replace = os.replace; heads_paths = [root / 'include' / n for n in v16.HEADERS]; total = 3 + 16
for k in range(1, total + 1):
    d = fresh_root(); before = {str(p.relative_to(d)): p.read_bytes() for p in d.rglob('*') if p.is_file()}; cnt = [0]
    def flaky(x, y, _c=cnt, _k=k):
        _c[0] += 1
        if _c[0] == _k: raise OSError('simulierter Schreibfehler')
        return real_replace(x, y)
    os.replace = flaky
    try:
        try: v16.apply(d, heads_paths); ck(False, 'Fehler haette durchschlagen muessen')
        except OSError: pass
    finally: os.replace = real_replace
    ck({str(p.relative_to(d)): p.read_bytes() for p in d.rglob('*') if p.is_file()} == before, f'Position {k}: Wurzel nicht byte-identisch')
print(f'PASS Overlay gegen ECHTE OEM-Dateien: {n_ck[0]} Pruefungen (vollstaendige Kette, strukturelle G28-Topologie, OEM-Erhaltung, Platzierung, CLI aus 3 Arbeitsverzeichnissen, Atomaritaet an {total} Positionen); Text/Simulation, KEIN Marlin-Build')
