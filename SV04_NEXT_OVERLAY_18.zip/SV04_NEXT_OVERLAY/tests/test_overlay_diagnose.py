"""Diagnose-Werkzeug auf SYNTHETISCHEN Wurzeln (jedes Szenario als eigener Prozess). Kein echtes OEM."""
import contextlib, hashlib, io, json, os, shutil, subprocess, sys, tempfile
from pathlib import Path
root = Path(__file__).resolve().parents[1]; sys.path[:0] = [str(root / 'integration'), str(root / 'tests')]
with contextlib.redirect_stdout(io.StringIO()): import test_overlay_v14 as T
v14 = T.v14; src = dict(T.src); names = list(v14.OEM_BLOBS)
blob = lambda b: hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
n = [0]
def ck(c, m=''): assert c, m; n[0] += 1
def make_root(mod=None):
    d = Path(tempfile.mkdtemp()); shas = {}
    for nm in names:
        text = src[nm] if not mod or nm not in mod else mod[nm]; p = d / nm; p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(text.encode()); shas[nm] = blob(text.encode())
    (d / 'Marlin/src/module').mkdir(parents=True, exist_ok=True); (d / 'Marlin/src/module/temperature.h').write_text('class Temperature {\n public:\n  static void setTargetBed(const int celsius);\n  static float degBed();\n  static int degTargetBed();\n};\n')
    (d / 'Marlin/src/gcode').mkdir(parents=True, exist_ok=True); (d / 'Marlin/src/gcode/queue.h').write_text('class GCodeQueue { public: static bool enqueue_one_P(const char*); static bool has_commands_queued(); };\n')
    cfg = (mod or {}).get('Marlin/Configuration.h', src['Marlin/Configuration.h']); (d / 'Marlin/Configuration.h').write_text(cfg + '\n#define DUAL_X_CARRIAGE\n//#define PROBE_MANUALLY\n#define AUTO_BED_LEVELING_BILINEAR\n')
    (d / 'platformio.ini').write_text('[platformio]\ndefault_envs = STM32F103RET6_creality\n')
    # Configuration.h ist OEM-Datei: Inhalt behalten (Blob neu berechnen)
    shas['Marlin/Configuration.h'] = blob((d / 'Marlin/Configuration.h').read_bytes()); return d, shas
def make_overlay():
    o = Path(tempfile.mkdtemp()) / 'SV04_NEXT_OVERLAY'; shutil.copytree(root, o, ignore=shutil.ignore_patterns('__pycache__', '*.pyc', 'harness', 'ci-evidence'))
    subprocess.run([sys.executable, 'tools/make_manifest.py'], cwd=o, check=True, capture_output=True); return o
def run(rt, shas, ov):
    out = Path(tempfile.mkdtemp()); env = dict(os.environ, SV04_DIAG_OEM_BLOBS_JSON=json.dumps(shas), PYTHONDONTWRITEBYTECODE='1')
    r = subprocess.run([sys.executable, str(ov / 'tools/overlay_diagnose.py'), '--root', str(rt), '--overlay', str(ov), '--out', str(out)], capture_output=True, text=True, env=env, cwd=rt)
    assert r.returncode == 0, r.stderr[-600:]; return json.loads((out / 'diagnose.json').read_text(encoding='utf-8')), out, r.stdout
# 1 sauberer Fall
rt, shas = make_root(); ov = make_overlay(); rep, out, so = run(rt, shas, ov)
ck(rep['overlay_integrity']['ok'] is True and not rep['overlay_integrity']['modified']); ck(rep['strict_dry_run']['ok'] is True, rep['strict_dry_run']); ck(rep['anchor_failures']['count'] == 0 and rep['anchor_failures']['first_audit_exception_after_tolerant_run'] is None)
ck(rep['g28']['idex_topology']['x2'] == 2 and rep['g28']['idex_topology']['interleaved']); ck(all(o['match'] and not o['markers_present'] for o in rep['oem'].values())); ck((out / 'oem-sources/Marlin/src/gcode/calibrate/G28.cpp').is_file() and (out / 'DIAGNOSE.md').is_file() and (out / 'overlay-review.diff').is_file())
ck(rep['symbols']['setTargetBed']['header_hits'] and rep['symbols']['has_commands_queued']['files'] >= 1 and rep['symbols']['enqueue_now_P']['total'] == 0, 'Namensabgleich'); ck('DUAL_X_CARRIAGE' in rep['config_flags'] and 'AUSKOMMENTIERT' in rep['config_flags']['PROBE_MANUALLY'][0])
ck('Marlin/src/module/temperature.h' in rep['copied_headers'] and 'Marlin/src/gcode/queue.h' in rep['copied_headers'])
# der Trockenlauf darf die Wurzel nicht veraendert haben
ck(all(blob((rt / nm).read_bytes()) == shas[nm] for nm in names), 'Diagnose hat Quelltext veraendert')
# 2 bereits gepatchter G28 (Marker): klare Meldung im strengen Lauf, Marker gelistet
g = dict(src); g[v14.G28] = src[v14.G28].replace('void GcodeSuite::G28() {', 'void GcodeSuite::G28() {\n  // saw_x2_homeaxis_return( Altlast')
rt2, sh2 = make_root(g); rep2, _, _ = run(rt2, sh2, ov)
ck(rep2['strict_dry_run']['ok'] is False and 'already contains SV04 NEXT marker' in rep2['strict_dry_run']['exception']); ck('saw_x2_homeaxis_return(' in rep2['oem'][v14.G28]['markers_present'])
# 3 lokal GEAENDERTE v14 im Overlay-Ordner wird erkannt (Hashliste)
ov3 = make_overlay(); f = ov3 / 'integration/apply_native_guard_v14.py'; f.write_text(f.read_text(encoding='utf-8').replace("MAX_IDEX_PAIRS=4", "MAX_IDEX_PAIRS=9"), encoding='utf-8')
rep3, _, _ = run(rt, shas, ov3); ck(rep3['overlay_integrity']['ok'] is False and 'integration/apply_native_guard_v14.py' in rep3['overlay_integrity']['modified'])
# 4 fehlender Anker in G29: ALLE fehlenden Anker auf einmal, strenger Lauf mit Ankermeldung
gg = dict(src); gg['Marlin/src/gcode/bedlevel/abl/G29.cpp'] = src['Marlin/src/gcode/bedlevel/abl/G29.cpp'].replace('  reset_stepper_timeout();\n', '  // entfernt\n'); gg[v14.RTS] = src[v14.RTS].replace('void RTSUpdate()', 'void RTSUpdateX()')
rt4, sh4 = make_root(gg); rep4, _, _ = run(rt4, sh4, ov); ck(rep4['anchor_failures']['count'] >= 2, rep4['anchor_failures']['count']); ck(rep4['strict_dry_run']['ok'] is False and 'anchor' in rep4['strict_dry_run']['exception'])
tg = {i['target'] for i in rep4['anchor_failures']['items']}; ck(any('G29' in t for t in tg) and any('LCD_RTS' in t or 'RTS' in t for t in tg), tg)
# 5 SHA-Abweichung wird gemeldet (Trockenlauf: SHA mismatch), Diagnose laeuft trotzdem durch
sh5 = dict(shas); sh5[v14.G28] = '0' * 40; rep5, _, _ = run(rt, sh5, ov); ck(rep5['oem'][v14.G28]['match'] is False and 'SHA mismatch' in rep5['strict_dry_run']['exception'])
print(f'PASS Diagnose: {n[0]} Pruefungen (5 Szenarien, jedes als eigener Prozess; schreibt nie in den Quelltext); synthetisch, KEIN echtes OEM')
