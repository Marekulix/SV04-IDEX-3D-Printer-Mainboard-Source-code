"""Typ-/Syntaxpruefung des eingefuegten Codes im Kontext der ECHTEN OEM-Dateien (Shim mit Signaturen der echten Header). KEIN Marlin-Build, kein C-Nachweis.
Prueft: sauberer Fall (0 neue Fehler, Code erreicht den Compiler) UND Gegenprobe (absichtlich eingebaute Fehler werden gefunden)."""
import shutil, sys, tempfile
from pathlib import Path
root = Path(__file__).resolve().parents[1]; sys.path[:0] = [str(root / 'tools')]
import shim_compile_check as S
n = [0]
def ck(c, m=''): assert c, m; n[0] += 1
work = Path(tempfile.mkdtemp()); orig, out = S.build_trees(work)
for rel, need in S.FILES.items():
    r = S.check_file(work, rel, orig, out); ck(not r['new_in_inserted'], f'{rel}: {r["new_in_inserted"][:3]}'); ck(all(r['reached'][k] >= v for k, v in need.items()), f'{rel}: Code nicht erreicht {r["reached"]}')
    ck(r['orig_errors'] == r['patched_errors'] and r['inserted_lines'] > 30, f'{rel}: Rauschfehler unterscheiden sich {r["orig_errors"]} vs {r["patched_errors"]}')
rel, extra, need = S.AUTO60; r = S.check_file(work, rel, orig, out, extra=extra); ck(not r['new_in_inserted'], r['new_in_inserted'][:3])
import subprocess
pre = subprocess.run(['g++', '-std=gnu++14', '-E', '-P', f'-I{work / "inc"}', '-include', str(S.SHIM), *S.CFG, *extra, str(work / 'patched' / rel)], capture_output=True, text=True).stdout; ck(all(pre.count(k) >= v for k, v in need.items()), 'Bruecke nicht erreicht')
# Gegenprobe: absichtlich eingebaute Fehler MUESSEN gefunden werden (sonst waere ein sauberes Ergebnis wertlos)
MUT = {
 'Marlin/src/gcode/calibrate/G28.cpp': [("axis_is_trusted(X_AXIS), axis_is_trusted(Y_AXIS)", "axis_is_trusted(X_AXIS, 1), axis_is_trusted(Y_AXIS)"), ("sv04_idex_scope.finish((uint32_t)millis());", "sv04_idex_scope.finnish((uint32_t)millis());")],
 'Marlin/src/gcode/bedlevel/abl/G29.cpp': [("thermalManager.degTargetBed() != 60 ||\n                 !isfinite(probe.offset.z) ||", "thermalManager.degTargetBedX() != 60 ||\n                 !isfinite(probe.offset.z) ||"), ("sv04_mesh_guard.accept();", "sv04_mesh_guard.acceptt();")],
 'Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp': [("n.t1_x = inactive_extruder_x;", "n.t1_x = inactive_extruder_xx;"), ("(uint32_t)millis(), thermalManager.degBed(),", "(uint32_t)millis(), thermalManager.degBed(1),")]}
for rel, edits in MUT.items():
    w2 = Path(tempfile.mkdtemp()); S.build_trees(w2); p = w2 / 'patched' / rel; t = p.read_text(encoding='utf-8')
    for old, new in edits: ck(t.count(old) == 1, (rel, old[:40])); t = t.replace(old, new)
    p.write_text(t, encoding='utf-8'); r = S.check_file(w2, rel, orig, out); ck(len(r['new_in_inserted']) >= len(edits), f'{rel}: Gegenprobe fand nur {len(r["new_in_inserted"])} von {len(edits)} Fehlern')
# Gegenprobe Bruecke und Zustandsmaschine (Overlay-Header): Fehler im Header wird gemeldet
w3 = Path(tempfile.mkdtemp()); S.build_trees(w3); g = w3 / 'patched/Marlin/src/feature/sv04_next/SV04NextAuto60Glue.hpp'; t = g.read_text(encoding='utf-8'); ck('thermalManager.degTargetBed' not in t or True)
t = t.replace('o.leveling_active = planner.leveling_active;', 'o.leveling_active = planner.leveling_activee;'); ck('leveling_activee' in t); g.write_text(t, encoding='utf-8')
r = S.check_file(w3, rel := 'Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp', orig, out, extra=['-DSV04_NEXT_AUTO60_ENGINE']); ck(any('leveling_activee' in m for _, _, m in r['new_in_inserted']), 'Fehler in der Bruecke nicht gefunden')
# die Shim selbst ist fehlerfrei (sonst bricht die Pruefung ab)
ck(subprocess.run(['g++', '-std=gnu++14', '-fsyntax-only', '-include', str(S.SHIM), *S.CFG, '-x', 'c++', '/dev/null'], capture_output=True, text=True).returncode == 0, 'shim.h fehlerhaft')
print(f'PASS Shim-Typpruefung im Kontext der ECHTEN OEM-Dateien: {n[0]} Pruefungen (G28/G29/LCD_RTS und Bruecke bei gesetztem Makro: 0 neue Fehler, Code erreicht den Compiler; Gegenprobe findet alle absichtlichen Fehler); Shim, KEIN Marlin-Build')
