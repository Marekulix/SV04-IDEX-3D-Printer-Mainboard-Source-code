"""Reproduziert den gemeldeten Fehler 'G28 homing path audit incomplete' mit der ALTEN v14 (Stand 13) und prueft die neue v14 gegen viele G28-Layouts.
SYNTHETISCHE Texte (keine echte OEM-Datei); die echte Datei prueft die Diagnose (tools/overlay_diagnose.py) im CI."""
import contextlib, importlib.util, io, sys
from pathlib import Path
root = Path(__file__).resolve().parents[1]; sys.path[:0] = [str(root / 'integration'), str(root / 'tests')]
with contextlib.redirect_stdout(io.StringIO()): import test_overlay_v14 as T
import apply_native_guard_v15 as v15
v14 = T.v14; heads = [(root / 'include' / n).read_text(encoding='utf-8') for n in v15.HEADERS]
spec = importlib.util.spec_from_file_location('v14_old', root / 'tests/fixtures/apply_native_guard_v14_stand13.py'); old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
G = v14.G28; HDR = T.src[G].split('void GcodeSuite::G28() {')[0]
P2 = lambda i='    ': f'{i}active_extruder = 1;\n{i}homeaxis(X_AXIS);'; P1 = lambda i='    ': f'{i}active_extruder = 0;\n{i}homeaxis(X_AXIS);'
def g28(*blocks, tail=''):
    return HDR + "void GcodeSuite::G28() {\n  if (parser.seen_test('O')) return;\n" + '\n'.join(blocks) + '\n' + tail + "  TERN_(FULL_REPORT_TO_HOST_FEATURE, set_and_report_grblstate(M_IDLE));\n}\n"
def render(mod, text, which=None):
    src = dict(T.src); src[G] = text; fn = (which or v15).render
    return fn(src, *heads) if mod == 'new' else old.render(dict(T.src, **{G: text}), *heads[:13])
n_ck = [0]
def ck(c, m=''): assert c, m; n_ck[0] += 1
def refused(fn, *words):
    try: fn()
    except v14.PatchRefused as e: ck(all(w in str(e) for w in words), f'{words} nicht in: {e}'); return str(e)
    raise AssertionError('haette verweigert werden muessen: ' + str(words))
# --- R1 Reproduktion Ursache (a): OEM-Text enthaelt bereits einen Marker -> ALTE v14 meldet genau den gemeldeten Fehler
marked = g28(P2(), P1(), P2('      '), P1('      '), tail='  // saw_x2_homeaxis_return( bereits vorhanden\n')
refused(lambda: render('old', marked), 'G28 homing path audit incomplete')
msg = refused(lambda: render('new', marked), 'already contains SV04 NEXT marker', G); ck('nothing was modified' in msg)
# --- R2 Reproduktion Ursache (b): in der Repo-v14 wurde die erwartete Topologie auf (1,1) geaendert, die Audit-Zeile aber nicht
src_old = (root / 'tests/fixtures/apply_native_guard_v14_stand13.py').read_text(encoding='utf-8'); edited_src = src_old.replace("if (n2,n1)!=(2,2):raise", "if (n2,n1)!=(1,1):raise"); ck(edited_src != src_old)
spec2 = importlib.util.spec_from_loader('v14_edited', loader=None); edited = importlib.util.module_from_spec(spec2); exec(compile(edited_src, 'v14_edited.py', 'exec'), edited.__dict__)
one = g28(P2(), P1())
try: edited.render(dict(T.src, **{G: one}), *heads[:13]); raise AssertionError('editierte v14 haette scheitern muessen')
except v14.PatchRefused as e: ck('G28 homing path audit incomplete' in str(e), str(e))
out = render('new', one); gp = out[G]; ck(gp.count('saw_x2_homeaxis_return(') == 1 and gp.count('saw_x1_homeaxis_return(') == 1, 'neue v14: 1 Paar'); ck(v14.LAST_TOPOLOGY['x2'] == 1 and v14.LAST_TOPOLOGY['interleaved'])
# --- Layoutvarianten der NEUEN v14 (strukturelle Analyse)
for n in (1, 2, 3, 4):
    blocks = []
    for k in range(n): blocks += [P2('  ' * (k % 3 + 1)), '  // zwischen den Fahrten', P1('  ' * (k % 3 + 1)), '']
    gp = render('new', g28(*blocks))[G]; ck(gp.count('saw_x2_homeaxis_return(') == n and gp.count('saw_x1_homeaxis_return(') == n, f'{n} Paare')
    ck(gp.count('sv04_g28_scope.finish(') == 1 and gp.count('sv04_idex_scope.finish(') == 1)
refused(lambda: render('new', g28(*[P2(), P1()] * 5)), 'topology mismatch', 'more than 4')
refused(lambda: render('new', g28(P2(), P1(), P2())), 'topology mismatch', 'never followed by a T0 homing')       # X2 ohne X1
refused(lambda: render('new', g28(P1(), P2())), 'topology mismatch', 'without a preceding X2')                        # X1 ohne X2 und ohne isPrinting()-Schutz
refused(lambda: render('new', g28(P2(), P2(), P1(), P1())), 'topology mismatch', 'still open')                         # nicht verschachtelt
refused(lambda: render('new', g28('  homeaxis(X_AXIS);')), 'topology mismatch', 'is not preceded by active_extruder')  # unklassifizierter Aufruf
refused(lambda: render('new', g28('  // keine Referenzfahrt')), 'topology mismatch', 'no X2->X1 pair found')           # gar keine Fahrt
# Layout des ECHTEN Sovol-Codes: Paar, Duplikationspaar, ungepaarter T0-Aufruf NUR waehrend eines Drucks, toter Nicht-IDEX-Zweig
real_like = g28('  #if ENABLED(DUAL_X_CARRIAGE)', P2('    '), P1('    '), '  #else', '    homeaxis(X_AXIS);', '  #endif', '  if (idex_is_duplicating()) {', P2('    '), P1('    '), '  }',
                '  else if((save_dual_x_carriage_mode == 4) && card.isPrinting()){', '    // Home the 1st (left) extruder', '    active_extruder = 0;', '    homeaxis(X_AXIS);', '  }')
gp = render('new', real_like)[G]; t = v14.LAST_TOPOLOGY; ck(len(t['pairs']) == 2 and len(t['singles']) == 1 and len(t['non_idex']) == 1 and t['order'] == '21o211', t)
ck(gp.count('saw_x2_homeaxis_return(') == 2 and gp.count('saw_x1_homeaxis_return(') == 2 and gp.count('homeaxis(X_AXIS);') == 6, 'nur Paare werden instrumentiert')
ck('saw_' not in gp.split('card.isPrinting()')[1].split('}')[0], 'ungepaarter T0-Aufruf unter isPrinting() wurde instrumentiert')
unguarded = g28('  #if ENABLED(DUAL_X_CARRIAGE)', P2('    '), P1('    '), '  #endif', '  if (x) {', P1('    '), '  }')   # ungepaarter T0-Aufruf OHNE isPrinting()-Schutz: unbekannte Topologie
refused(lambda: render('new', unguarded), 'topology mismatch', 'without a preceding X2')
# Toleranzen: Leerzeilen zwischen den Zeilen, Leerzeichen am Zeilenende
tol = g28('    active_extruder = 1; \n\n    homeaxis(X_AXIS);', P1()); gp = render('new', tol)[G]; ck(gp.count('saw_x2_homeaxis_return(') == 1)
# andere OEM-Dateien mit Markern werden ebenfalls vorab gemeldet
for key in (v14.RTS, 'Marlin/src/gcode/bedlevel/abl/G29.cpp'):
    s2 = dict(T.src); s2[key] = s2[key] + '\n// sv04next::x\n'; refused(lambda: v15.render(s2, *heads), 'already contains SV04 NEXT marker', key)
# Konsistenz-Audits gezielt ausloesen: (a) Struktur zwischen Analyse und Instrumentierung veraendert, (b) Zaehlaudit bei umgangener Marker-Vorpruefung
real_topo = v14.idex_topology; calls = [0]
def drifting(text):
    t = real_topo(text); calls[0] += 1
    if calls[0] == 2: t = dict(t); t['pairs'] = t['pairs'][:-1]
    return t
v14.idex_topology = drifting
try: refused(lambda: render('new', g28(P2(), P1(), P2('      '), P1('      '))), 'structure changed between analysis and instrumentation')
finally: v14.idex_topology = real_topo
saved_markers = v14.OVERLAY_MARKERS; v14.OVERLAY_MARKERS = ()
try: refused(lambda: render('new', marked), 'G28 homing path audit incomplete', 'x2 hooks 3/2')   # Marker-Vorpruefung umgangen: das Zaehlaudit faengt den gemeldeten Fall
finally: v14.OVERLAY_MARKERS = saved_markers
# veraltete Zeilenindizes (Instrumentierung ohne Neuberechnung) muessen vom Hakenaudit gefangen werden: simuliere, indem die Instrumentierung falsche Indizes bekommt
real_inst = v14.instrument_idex_pairs
def stale(text, topo):
    t = dict(topo); t['pairs'] = [dict(p, x2_idx=p['x2_idx'] - 5, x1_idx=p['x1_idx'] - 5) for p in topo['pairs']]; return real_inst(text, t)
v14.instrument_idex_pairs = stale
try: refused(lambda: render('new', real_like), 'G28 homing path audit incomplete')
finally: v14.instrument_idex_pairs = real_inst
# Audit der homeaxis-Aufrufanzahl: eine (manipulierte) Instrumentierung, die einen Aufruf loescht, muss auffallen
def deleting(text, topo):
    out = real_inst(text, topo); i = out.rindex('homeaxis(X_AXIS);'); return out[:i] + '/* geloescht */' + out[i + len('homeaxis(X_AXIS);'):]
v14.instrument_idex_pairs = deleting
try: refused(lambda: render('new', real_like), 'G28 homing path audit incomplete', 'number of homeaxis(X_AXIS) calls changed')
finally: v14.instrument_idex_pairs = real_inst
# die Standard-Fixture bleibt (2,2)
gp = v15.render(dict(T.src), *heads)[G]; ck(gp.count('saw_x2_homeaxis_return(') == 2 and gp.count('saw_x1_homeaxis_return(') == 2)
print(f'PASS v14 Formen: {n_ck[0]} Pruefungen (beide Altursachen reproduziert; strukturelle Analyse: Layouts mit 1 bis 4 Paaren, ECHTES Sovol-Layout mit ungepaartem T0-Aufruf unter isPrinting() und totem Nicht-IDEX-Zweig, 7 Verweigerungsfaelle, 3 Konsistenz-Audits gezielt ausgeloest); synthetisch'
      + ', KEIN echtes OEM')
