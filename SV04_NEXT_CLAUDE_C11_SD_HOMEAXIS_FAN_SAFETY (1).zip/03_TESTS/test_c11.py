"""SV04 NEXT C11 - Host-Tests (KEIN STM32-Build, KEINE Hardware).
 S11xx  SD-Freeze, stiller SD-Abbruch: ECHTE Funktionskoepfe aus den gepatchten Dateien (get_sdcard_commands, GcodeSuite::M999, abortSDPrinting)
        in einem gemeinsamen Treiber, voller Zustandsraum (Stopp x SD-Zustand x S x Befehlsfolgen bis Laenge 5) gegen ein unabhaengiges Python-Modell
 N11xx  Negativkontrollen (Schalter aus = OEM/C10-Verhalten zeigt die Gefahr; echte OEM-abortSDPrinting injiziert G28XY)
 P11xx  Patch-Skript, Diff-Grenzen, Text-Anker (loop-Reihenfolge)
 X11xx  Mutanten
Aufruf: python3 test_c11.py   (g++ noetig)"""
import hashlib, itertools, shutil, subprocess, sys, tempfile, unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent; PKG = HERE.parent
IN = HERE / 'eingang'; CPP = HERE / 'cpp'; APPLY = PKG / '02_PATCHES/apply_c11.py'
GXX = ['g++', '-std=c++11', '-O1', '-Wall', '-Wextra', '-Wno-unused-function', '-Wno-unused-variable', '-Wno-unused-but-set-variable']
QR, MR, CR = 'Marlin/src/gcode/queue.cpp', 'Marlin/src/gcode/control/M999.cpp', 'Marlin/src/MarlinCore.cpp'

def sh(cmd, **kw): return subprocess.run(cmd, capture_output=True, text=True, **kw)
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def raw_tree():
    d = Path(tempfile.mkdtemp()); (d / 'Marlin/src/gcode/control').mkdir(parents=True)
    shutil.copy(IN / 'c10/queue.cpp', d / QR); shutil.copy(IN / 'c10/M999.cpp', d / MR); shutil.copy(IN / 'oem/MarlinCore.cpp', d / CR); return d

def patched_tree():
    d = raw_tree(); r = sh([sys.executable, '-I', str(APPLY), str(d)]); assert r.returncode == 0, r.stdout + r.stderr; return d

def between(t, a, b, incl_b=True):
    i = t.index(a); j = t.index(b, i); return t[i:j + (len(b) if incl_b else 0)]

def extracts(tree):
    q = (tree / QR).read_text(); m = (tree / MR).read_text(); c = (tree / CR).read_text()
    fetch = between(q, '#ifndef SV04_CLAUDE_SD_FREEZE_WHEN_STOPPED', '#endif\n') + '\n' + between(q, 'inline void GCodeQueue::get_sdcard_commands() {', '    int sd_count = 0;\n', False) + '    ++sd_reads;\n  }\n'
    m999 = between(m, '#ifndef SV04_CLAUDE_M999_SD_DISCARD', '#endif\n') + '\n' + m[m.index('void GcodeSuite::M999() {'):]
    abort_ = between(c, '  bool sv04c11_sd_abort_silent = false;', "    TERN_(PASSWORD_AFTER_SD_PRINT_ABORT, password.lock_machine());\n  }\n")
    return fetch, m999, abort_

def build(tree, defines=(), tag=''):
    d = Path(tempfile.mkdtemp()); f, m, a = extracts(tree)
    (d / 'fetch_extract.inc').write_text(f); (d / 'm999_extract.inc').write_text(m); (d / 'abort_extract.inc').write_text(a)
    r = sh(GXX + [f'-D{x}' for x in defines] + ['-I', str(d), str(CPP / 'e2e_driver.cpp'), '-o', str(d / 'e')]); assert r.returncode == 0, r.stderr[-1200:]
    return d / 'e'

# ---------------- unabhaengiges Modell ----------------
def model(stopped, sd, s, seq, freeze=True, discard=True, rehome=True, xy=True):
    st = dict(reads=0, inj='', sd=sd, abort=0, silent=0, stopped=stopped, homed=7, cleared=0, flushpend=0, flushes=0)
    for ch in seq:
        if ch == 'F':
            if freeze and st['stopped']: continue
            if st['sd'] == 1 and not st['abort']: st['reads'] += 1
        elif ch == 'M':
            was = st['stopped']; st['stopped'] = 0
            if was and rehome:
                st['homed'] = 0; st['flushpend'] = 1
                if discard and ((st['sd'] == 1 and not st['abort']) or st['sd'] == 2): st['silent'] = 1; st['abort'] = 1
            if not s: st['flushes'] += 1
        elif ch == 'L':
            if st['abort']:
                st['sd'] = 0; st['abort'] = 0; st['cleared'] += 1
                if not st['silent'] and ((st['homed'] & 3) == 3 or not xy): st['inj'] += 'G28XY;'
                st['silent'] = 0
        elif ch == 'U':
            if st['sd'] != 0: st['abort'] = 1
        elif ch == 'X': st['stopped'] = 1
        elif ch == 'H': st['homed'] = 7
        elif ch == 'N': st['homed'] = 0
        elif ch == 'Y': st['homed'] = 1
        elif ch == 'W': st['homed'] = 2
    return st

def fmt(st): return (st['reads'], st['inj'], st['sd'], st['abort'], st['silent'], st['stopped'], st['homed'], st['cleared'], st['flushpend'], st['flushes'])

def parse(line):
    kv = dict(x.split('=', 1) if '=' in x else (x, '') for x in line.split())
    return (int(kv['reads']), kv.get('inj', ''), int(kv['sd']), int(kv['abort']), int(kv['silent']), int(kv['stopped']), int(kv['homed']), int(kv['cleared']), int(kv['flushpend']), int(kv['flushes']))

SEQS = sorted(set([''.join(p) for n in range(1, 5) for p in itertools.product('FMLUXHNYW', repeat=n)] + [''.join(p) for p in itertools.product('FMLUX', repeat=5)]))
CASES = [(a, b, c, q) for a in (0, 1) for b in (0, 1, 2) for c in (0, 1) for q in SEQS]

def grid(exe, **mk):
    inp = '\n'.join(f'{a} {b} {c} {q}' for a, b, c, q in CASES) + '\n'
    out = sh([str(exe)], input=inp).stdout.splitlines(); assert len(out) == len(CASES), (len(out), len(CASES))
    bad = []
    for (a, b, c, q), line in zip(CASES, out):
        got = parse(line); exp = fmt(model(a, b, c, q, **mk))
        # flushes: Modell zaehlt nur ohne S; Treiber ebenso
        if got != exp: bad.append(((a, b, c, q), got, exp))
    return bad, dict(zip(CASES, out))

class E2E(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tree = patched_tree(); cls.exe = build(cls.tree)

    def test_S1101_full_state_space_matches_independent_model(self):
        bad, _ = grid(self.exe); self.assertEqual(bad[:3], [], f'{len(bad)} Abweichungen von {len(CASES)} Faellen')

    def run1(self, a, b, c, q): return parse(sh([str(self.exe)], input=f'{a} {b} {c} {q}\n').stdout.strip())

    def test_S1102_no_sd_line_is_read_while_stopped(self):
        r = self.run1(1, 1, 0, 'FFFFF'); self.assertEqual(r[0], 0)
        r = self.run1(0, 1, 0, 'FFFFF'); self.assertEqual(r[0], 5)  # ohne Stopp laeuft der Druck normal weiter

    def test_S1103_m999_after_stop_ends_the_sd_job_without_g28xy(self):
        for sd in (1, 2):
            for s in (0, 1):
                r = self.run1(1, sd, s, 'FMLFF'); self.assertEqual((r[1], r[2], r[0], r[3], r[4]), ('', 0, 0, 0, 0), f'sd={sd} s={s}')
                self.assertEqual(r[6], 0, 'Achsen unreferenziert (C9 bleibt)'); self.assertEqual(r[7], 1, 'abortSDPrinting genau einmal'); self.assertEqual(r[8], 1, 'C10-Queue-Flag bleibt')

    def test_S1104_m999_without_stop_never_touches_the_sd_job(self):
        for sd in (1, 2):
            r = self.run1(0, sd, 0, 'MLFF'); self.assertEqual((r[2], r[3], r[4], r[6], r[7], r[1]), (sd, 0, 0, 7, 0, ''))

    def test_S1105_m999_with_idle_sd_sets_no_abort_flag(self):
        r = self.run1(1, 0, 0, 'ML'); self.assertEqual((r[3], r[4], r[7]), (0, 0, 0))

    def test_S1106_a_later_normal_sd_abort_still_gets_the_oem_event_gcode(self):
        # nach einem stillen Abbruch darf der Merker nicht haengenbleiben: ein spaeterer Benutzerabbruch injiziert wie im OEM G28XY
        r = self.run1(1, 1, 0, 'MLUL'); self.assertEqual(r[1], '', 'kein SD-Job mehr -> U ohne Wirkung')
        r = self.run1(0, 1, 0, 'ULFF'); self.assertEqual((r[1], r[0]), ('G28XY;', 0), 'OEM-Benutzerabbruch unveraendert')
        r = self.run1(1, 1, 0, 'MLXMLUL'); self.assertEqual(r[4], 0)

    def test_S1107_abort_side_effects_unchanged_heaters_fans_timer_recovery(self):
        d = Path(tempfile.mkdtemp()); out = sh([str(self.exe)], input='1 1 0 MLL\n0 1 0 UL\n').stdout.splitlines()
        for line in out:
            kv = dict(x.split('=', 1) for x in line.split() if '=' in x); self.assertEqual((kv['heaters'], kv['fans'], kv['quick'], kv['timer'], kv['purge']), ('1', '1', '1', '1', '1'), line)

    def test_S1108_text_anchors_loop_order_and_real_call_sites(self):
        c = (self.tree / CR).read_text(); i = c.index('if (card.flag.abort_sd_printing) abortSDPrinting();'); j = c.index('queue.advance();', i); self.assertLess(i, j)
        self.assertEqual(c.count('abortSDPrinting()'), 2, 'Definition + ein Aufruf in loop()')
        self.assertIn('card.flag.abort_sd_printing', (self.tree / MR).read_text())

    def test_S1109_abort_from_unhomed_axes_never_starts_a_homing_move_but_from_homed_axes_the_oem_event_stays(self):
        self.assertEqual(self.run1(0, 1, 0, 'NUL')[1], '', 'Display/Host-Abbruch bei unreferenzierten Achsen: kein G28XY')
        self.assertEqual(self.run1(0, 1, 0, 'YUL')[1], '', 'nur X referenziert: kein G28XY'); self.assertEqual(self.run1(0, 1, 0, 'WUL')[1], '', 'nur Y referenziert: kein G28XY')
        self.assertEqual(self.run1(0, 1, 0, 'HUL')[1], 'G28XY;', 'referenziert: OEM-Verhalten')
        self.assertEqual(self.run1(0, 2, 0, 'NUL')[1], '', 'pausierter Druck, unreferenziert')

class Negative(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.tree = patched_tree()
    def one(self, exe, a, b, c, q): return parse(sh([str(exe)], input=f'{a} {b} {c} {q}\n').stdout.strip())

    def test_N1101_without_freeze_the_sd_file_keeps_being_read_in_the_stop_state(self):
        exe = build(self.tree, ['SV04_CLAUDE_SD_FREEZE_WHEN_STOPPED=0']); self.assertEqual(self.one(exe, 1, 1, 0, 'FFF')[0], 3)
        bad, _ = grid(exe, freeze=False); self.assertEqual(bad[:2], [], 'Modell mit freeze=False beschreibt den Schalter exakt')

    def test_N1102_without_sd_discard_the_old_job_continues_after_m999_and_abort_injects_g28xy(self):
        exe = build(self.tree, ['SV04_CLAUDE_M999_SD_DISCARD=0']); r = self.one(exe, 1, 1, 0, 'MLFF')
        self.assertEqual((r[0], r[2]), (2, 1), 'alter Druck laeuft nach M999 weiter')
        bad, _ = grid(exe, discard=False); self.assertEqual(bad[:2], [])

    def test_N1105_without_the_xy_condition_an_unhomed_abort_injects_g28xy_like_the_oem(self):
        exe = build(self.tree, ['SV04_CLAUDE_SD_ABORT_NEEDS_XY_HOMED=0']); self.assertEqual(self.one(exe, 0, 1, 0, 'NUL')[1], 'G28XY;')
        bad, _ = grid(exe, xy=False); self.assertEqual(bad[:2], [])

    def test_N1103_real_oem_abortSDPrinting_injects_g28xy_unconditionally(self):
        c = (IN / 'oem/MarlinCore.cpp').read_text(); a = between(c, '  inline void abortSDPrinting() {', "    TERN_(PASSWORD_AFTER_SD_PRINT_ABORT, password.lock_machine());\n  }\n")
        self.assertIn('queue.inject_P(PSTR(EVENT_GCODE_SD_ABORT));', a); self.assertNotIn('sv04c11', a)

    def test_N1104_no_sdsupport_build_compiles_the_m999_head_without_sd_code(self):
        t = (self.tree / MR).read_text(); self.assertIn('#if ENABLED(SDSUPPORT)\n  #include "../../sd/cardreader.h"', t)
        d = Path(tempfile.mkdtemp()); f, m, a = extracts(self.tree); (d / 'fetch_extract.inc').write_text(f.replace('    ++sd_reads;\n', '')); (d / 'm999_extract.inc').write_text(m); (d / 'abort_extract.inc').write_text('bool sv04c11_sd_abort_silent=false; static void abortSDPrinting(){}\n')
        r = sh(GXX + ['-DNO_SD', '-I', str(d), str(CPP / 'e2e_driver.cpp'), '-o', str(d / 'e')]); self.assertEqual(r.returncode, 0, r.stderr[-800:])

class Patch(unittest.TestCase):
    def apply(self, d): return sh([sys.executable, '-I', str(APPLY), str(d)])
    def test_P1101_idempotent_byte_stable(self):
        d = raw_tree(); self.assertEqual(self.apply(d).returncode, 0); h = [sha(d / f) for f in (QR, MR, CR)]
        r = self.apply(d); self.assertEqual(r.returncode, 0); self.assertEqual(r.stdout.count('ALREADY'), 3); self.assertEqual(h, [sha(d / f) for f in (QR, MR, CR)])
    def test_P1102_foreign_file_aborts_and_nothing_is_written(self):
        d = raw_tree(); (d / CR).write_text((d / CR).read_text() + '\n'); before = {p: sha(p) for p in d.rglob('*') if p.is_file()}
        r = self.apply(d); self.assertEqual(r.returncode, 3); self.assertEqual(before, {p: sha(p) for p in d.rglob('*') if p.is_file()})
    def test_P1103_mixed_state_aborts(self):
        d = patched_tree(); shutil.copy(IN / 'c10/M999.cpp', d / MR); r = self.apply(d); self.assertEqual(r.returncode, 3); self.assertIn('gemischt', r.stdout)
    def test_P1104_patched_but_modified_aborts(self):
        d = patched_tree(); (d / QR).write_text((d / QR).read_text() + '// x\n'); self.assertEqual(self.apply(d).returncode, 3)
    def test_P1105_c10_final_or_c9_only_tree_is_refused_where_pins_differ(self):
        d = raw_tree(); shutil.copy(IN / 'c10/gcode.cpp', d / MR); self.assertEqual(self.apply(d).returncode, 3)
    def test_P1106_diff_limits(self):
        # Jede OEM/C10-Zeile bleibt in gleicher Reihenfolge erhalten (Teilfolge); in MarlinCore.cpp entfaellt genau EINE Zeile (die Inject-Zeile, ersetzt durch die bedingte)
        d = patched_tree(); inj = '      queue.inject_P(PSTR(EVENT_GCODE_SD_ABORT));'
        for rel, src, delta, drop in ((QR, IN / 'c10/queue.cpp', 10, None), (MR, IN / 'c10/M999.cpp', 15, None), (CR, IN / 'oem/MarlinCore.cpp', 15, inj)):
            a = src.read_text().splitlines(); b = (d / rel).read_text().splitlines()
            if drop: self.assertEqual(a.count(drop), 1); a = [l for l in a if l != drop]
            it = iter(b); self.assertTrue(all(any(x == y for y in it) for x in a), f'{rel}: Zeile geloescht/umgestellt')
            self.assertEqual(len(b) - (len(a) + (1 if drop else 0)), delta, rel)
    def test_P1107_pins_and_final_hashes_are_the_documented_ones(self):
        t = APPLY.read_text()
        for h in ('5342ac2e', '7aa10ae6', '54d5b874'): self.assertIn(h, t)
        self.assertEqual(sha(IN / 'oem/MarlinCore.cpp')[:8], '54d5b874'); self.assertEqual(sha(IN / 'c10/queue.cpp')[:8], '5342ac2e'); self.assertEqual(sha(IN / 'c10/M999.cpp')[:8], '7aa10ae6')

MUT = [  # (id, Datei, alt, neu, equivalent?)
 ('X1 freeze entfernt', QR, '      if (IsStopped()) return;\n', '', False),
 ('X2 freeze invertiert', QR, 'if (IsStopped()) return;', 'if (!IsStopped()) return;', False),
 ('X3 freeze nach FETCHING-Pruefung (aequivalent)', QR, '      if (IsStopped()) return;\n    #endif\n    if (!IS_SD_FETCHING()) return;\n', '    #endif\n    if (!IS_SD_FETCHING()) return;\n    if (IsStopped()) return;\n', True),
 ('X4 stiller Merker nicht gesetzt', MR, '          sv04c11_sd_abort_silent = true;', '          ;', False),
 ('X5 Abbruchflag nicht gesetzt', MR, '          card.flag.abort_sd_printing = true;\n', '', False),
 ('X6 Pausiert nicht erfasst', MR, 'if (IS_SD_PRINTING() || IS_SD_PAUSED())', 'if (IS_SD_PRINTING())', False),
 ('X7 Druck nicht erfasst', MR, 'if (IS_SD_PRINTING() || IS_SD_PAUSED())', 'if (IS_SD_PAUSED())', False),
 ('X8 Guard entfernt', MR, 'if (IS_SD_PRINTING() || IS_SD_PAUSED())', 'if (true)', False),
 ('X10 Merker nicht zurueckgesetzt', CR, '    sv04c11_sd_abort_silent = false;\n', '', False),
 ('X11 Inject-Bedingung invertiert', CR, 'if (!sv04c11_sd_abort_silent && SV04C11_ABORT_XY_OK()) queue.inject_P', 'if (sv04c11_sd_abort_silent && SV04C11_ABORT_XY_OK()) queue.inject_P', False),
 ('X12 Inject immer', CR, 'if (!sv04c11_sd_abort_silent && SV04C11_ABORT_XY_OK()) queue.inject_P', 'queue.inject_P', False),
 ('X12b stiller Merker ignoriert', CR, 'if (!sv04c11_sd_abort_silent && SV04C11_ABORT_XY_OK()) queue.inject_P', 'if (SV04C11_ABORT_XY_OK()) queue.inject_P', False),
 ('X13 Merker nur im Inject-Zweig zurueckgesetzt (aequivalent nein: bleibt bei silent)', CR, '    sv04c11_sd_abort_silent = false;\n', '    if (!sv04c11_sd_abort_silent) sv04c11_sd_abort_silent = false;\n', False),
 ('X16 XY-Bedingung entfernt', CR, 'if (!sv04c11_sd_abort_silent && SV04C11_ABORT_XY_OK()) queue.inject_P', 'if (!sv04c11_sd_abort_silent) queue.inject_P', False),
 ('X17 nur X geprueft', CR, '(axis_was_homed(X_AXIS) && axis_was_homed(Y_AXIS))', '(axis_was_homed(X_AXIS))', False),
 ('X18 nur Y geprueft', CR, '(axis_was_homed(X_AXIS) && axis_was_homed(Y_AXIS))', '(axis_was_homed(Y_AXIS))', False),
 ('X19 XY-Schalter-Default 0', CR, '#define SV04_CLAUDE_SD_ABORT_NEEDS_XY_HOMED 1', '#define SV04_CLAUDE_SD_ABORT_NEEDS_XY_HOMED 0', False),
 ('X20 XY mit ODER', CR, '(axis_was_homed(X_AXIS) && axis_was_homed(Y_AXIS))', '(axis_was_homed(X_AXIS) || axis_was_homed(Y_AXIS))', False),
 ('X14 Freeze nur bei sd-Zaehler (Schalter-Default 0)', QR, '#define SV04_CLAUDE_SD_FREEZE_WHEN_STOPPED 1', '#define SV04_CLAUDE_SD_FREEZE_WHEN_STOPPED 0', False),
 ('X15 Discard-Default 0', MR, '#define SV04_CLAUDE_M999_SD_DISCARD 1', '#define SV04_CLAUDE_M999_SD_DISCARD 0', False),
]
class Mutants(unittest.TestCase):
    def test_X1101_every_mutant_is_killed_or_proven_equivalent(self):
        report = []
        for name, rel, old, new, equiv in MUT:
            d = patched_tree(); f = d / rel; t = f.read_text(); self.assertEqual(t.count(old), 1, name); f.write_text(t.replace(old, new))
            bad, _ = grid(build(d)); killed = bool(bad); report.append(f'{name}: {"getoetet" if killed else "ueberlebt"} ({len(bad)} Faelle)')
            self.assertEqual(killed, not equiv, '\n'.join(report))
        Path(tempfile.gettempdir(), 'c11_mutants.txt').write_text('\n'.join(report) + '\n'); print('\n'.join(report))
    def test_X1102_stop_condition_removed_is_killed(self):
        d = patched_tree(); f = d / MR; t = f.read_text(); old = '    if (sv04c9_was_stopped) {\n'; self.assertEqual(t.count(old), 1); f.write_text(t.replace(old, '    if (true) {\n'))
        bad, _ = grid(build(d)); self.assertTrue(bad)
if __name__ == '__main__': unittest.main(verbosity=1)
