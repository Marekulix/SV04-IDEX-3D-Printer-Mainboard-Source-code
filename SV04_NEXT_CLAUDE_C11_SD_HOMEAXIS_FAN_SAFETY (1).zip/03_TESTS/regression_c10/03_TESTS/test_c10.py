"""SV04 NEXT C10 - Host-Tests (KEIN STM32-Build, KEINE Hardware).
 G10xx  Stopp-Gate: Whitelist, Differentialtest gegen unabhaengiges Python-Modell, echter Kopf der gepatchten gcode.cpp,
        alle Display-Befehle aus der echten 318-LCD_RTS.cpp, Mutanten
 Q10xx  Warteschlange: echter RingBuffer + echte advance() der gepatchten queue.cpp, voller Zustandsraum, Negativkontrollen
 M10xx  echte gepatchte M999.cpp (Attrappen), Flag nur nach Stopp
 P10xx  Patch-Skript: Pins, Idempotenz, fremder/gemischter/veraenderter Stand
Aufruf: python3 test_c10.py   (g++ noetig)"""
import hashlib, itertools, os, random, re, shutil, subprocess, sys, tempfile, unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
PKG = HERE.parent
IN = HERE / 'eingang'
CPP = HERE / 'cpp'
HDR = PKG / '01_QUELLEN/neu/Marlin/src/gcode/sv04_claude_stopgate.h'
APPLY = PKG / '02_PATCHES/apply_c10.py'
GXX = ['g++', '-std=c++11', '-O1', '-Wall', '-Wextra', '-Wno-unused-function', '-Wno-unused-variable', '-Wno-unused-but-set-variable']


def sh(cmd, **kw): return subprocess.run(cmd, capture_output=True, text=True, **kw)
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def patched_tree():
    """Baum mit den drei Eingangsdateien, C10 darauf angewendet (Skript wird dabei mitgeprueft)."""
    d = Path(tempfile.mkdtemp()); (d / 'Marlin/src/gcode/control').mkdir(parents=True)
    shutil.copy(IN / '318/gcode.cpp', d / 'Marlin/src/gcode/gcode.cpp'); shutil.copy(IN / 'oem/queue.cpp', d / 'Marlin/src/gcode/queue.cpp'); shutil.copy(IN / 'c9/M999.cpp', d / 'Marlin/src/gcode/control/M999.cpp')
    r = sh([sys.executable, '-I', str(APPLY), str(d)]); assert r.returncode == 0, r.stdout + r.stderr
    return d


# ---------------- Gate: Referenzmodell (unabhaengig, Regex statt Zeichenschleife) ----------------
def ref_allowed(cmd, letter, codenum, subcode):
    m = re.match(r' *M([1-9][0-9]{0,3})( .*)?$', cmd, re.S)
    if not m or letter != 'M' or int(m.group(1)) != codenum or subcode != 0: return False
    n, rest = int(m.group(1)), (m.group(2) or '')
    if n in (999, 112, 108, 410): return True
    if n in (105, 114, 115, 119, 503): return rest.strip(' ') == ''
    if n in (104, 140):
        toks = [t for t in rest.split(' ') if t != '']
        seen = {}
        for t in toks:
            if not re.fullmatch(r'[A-Z][0-9+\-.]*', t): return False
            if t[0] in seen: return False
            seen[t[0]] = t[1:]
        allowed = 'ST' if n == 104 else 'S'
        if any(k not in allowed for k in seen): return False
        s = seen.get('S')
        if s is None or not re.fullmatch(r'[+-]?[0.]*', s) or '0' not in s or s.count('.') > 1: return False
        if 'T' in seen and not re.fullmatch(r'[0-9]{1,2}', seen['T']): return False
        return True
    return False


def build_gate(header: Path, tag=''):
    d = Path(tempfile.mkdtemp()); exe = d / 'g'
    r = sh(GXX + [f'-DSV04_GATE_HEADER="{header}"', str(CPP / 'gate_driver.cpp'), '-o', str(exe)]); assert r.returncode == 0, r.stderr[-600:]
    return exe


def gate_run(exe, items):
    inp = ''.join(f'{l}\t{c}\t{s}\t{t}\n' for (t, l, c, s) in items)
    out = sh([str(exe)], input=inp).stdout.split()
    return [x == '1' for x in out]


def parse_like_marlin(t):
    """Was der Marlin-Parser aus dem Text macht (nur fuer die Testeingaben): Buchstabe, Nummer, Unterbefehl."""
    s = t.lstrip(' ')
    if not s: return ('\0', 0, 0)
    m = re.match(r'([A-Za-z])\s*([0-9]*)(?:\.([0-9]+))?', s)
    if not m: return (s[0], 0, 0)
    return (m.group(1).upper(), int(m.group(2) or 0), int(m.group(3) or 0))


ALLOW = ['M999', 'M999 S1', 'M112', 'M108', 'M410', 'M105', 'M114', 'M115', 'M119', 'M503', 'M104 S0', 'M104 S0 T1', 'M104 T0 S0', 'M104 S0.0', 'M104 S-0', 'M140 S0', 'M140 S0.00', '  M105', 'M105  ', 'M104 S00']
DENY = ['G28', 'G28 X', 'G28 Z0', 'G29', 'G0 X10', 'G1 F600 Z3', 'G4 S1', 'G92 X0', 'T0', 'T1', 'M84', 'M18', 'M17', 'M106', 'M107', 'M106 S255', 'M104 S200', 'M104 S1', 'M104', 'M104 S', 'M140 S60', 'M140', 'M109 S0', 'M190 S0', 'M104 S0 B1', 'M104 S0 F1', 'M104 S0 S5', 'M104 S0 S0',
        'M140 S0 I1', 'M140 T0 S0', 'M105 R', 'M105 T0', 'M114 D', 'M503 S0', 'M500', 'M501', 'M502', 'M504', 'M24', 'M25', 'M600', 'M605 S1', 'M1060', 'M1060 S0', 'M420 S1', 'M290 Z0.1', 'M280 P0 S10', 'M42 P1 S1', 'M104.1 S0', 'M999.1', 'M104S0', 'M105X', 'M0105', 'M00', 'M', 'M ', '', ' ', 'G', ';M999', 'm999', 'M99999', 'M10 4', 'M 999',
        'M104 S0\tT1', 'M104 s0', 'M104 S0 t1', 'M104 S0 T123', 'M104 S0 T', 'M104 S0 T-1', 'M104 S1e0', 'M104 S0x', 'M104 S..', 'M104 S0.0.0', 'M104 S+', 'M104 S-', 'M104 SS0', 'M104 S0;M104 S200']


class Gate(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.exe = build_gate(HDR)

    def test_G1001_whitelist_and_refusals(self):
        items = [(t, *parse_like_marlin(t)) for t in ALLOW + DENY]
        res = gate_run(self.exe, items)
        for t, ok in zip(ALLOW + DENY, res):
            self.assertEqual(ok, t in ALLOW, f'{t!r}: erlaubt={ok}')

    def test_G1002_differential_against_independent_python_model(self):
        rnd = random.Random(10)
        base = ['M104', 'M140', 'M105', 'M114', 'M999', 'M84', 'G28', 'T1', 'M106', 'M503', 'M112', 'M500', 'M1060']
        pars = ['', ' S0', ' S1', ' S0 T1', ' T1 S0', ' S0.0', ' S-0', ' S+0', ' S0 B1', ' S', ' T0', ' S0 S0', ' R', ' D', '  S0', ' S00', ' S0.', ' S.0', ' S.', ' S-', ' S0-', ' S1e0', ' s0', ' X1 S0', ' S0 T12', ' S0 T123', ' S0 T-1', ' S0  T1', ' S 0']
        items = []
        for b in base:
            for p in pars:
                for pre, suf in (('', ''), (' ', ''), ('', ' '), ('', ';x')):
                    t = pre + b + p + suf; items.append((t, *parse_like_marlin(t)))
        alpha = 'MGT0123456789 .+-SXYZNTBF*;e'
        for _ in range(30000):
            t = ''.join(rnd.choice(alpha) for _ in range(rnd.randint(0, 14))); items.append((t, *parse_like_marlin(t)))
        for _ in range(8000):  # Parser und Text widersprechen sich
            t = rnd.choice(ALLOW + DENY); l, c, s = parse_like_marlin(t); items.append((t, rnd.choice('MGT'), c + rnd.choice([0, 0, 1, -1]), s + rnd.choice([0, 0, 1])))
        res = gate_run(self.exe, items); self.assertEqual(len(res), len(items))
        bad = [(it, r) for it, r in zip(items, res) if r != ref_allowed(it[0], it[1], it[2], it[3])]
        self.assertEqual(bad[:5], [], f'{len(bad)} Abweichungen von {len(items)}')
        self.assertTrue(any(res), 'Test waere leer'); self.assertTrue(sum(res) < len(res))

    def test_G1003_parser_and_text_must_agree(self):
        for t, l, c, s in [('M105', 'M', 104, 0), ('M105', 'G', 105, 0), ('M105', 'M', 105, 1), ('G28', 'M', 28, 0), ('M999', 'T', 999, 0), ('M999', 'M', 998, 0)]:
            self.assertFalse(gate_run(self.exe, [(t, l, c, s)])[0], (t, l, c, s))
        self.assertTrue(gate_run(self.exe, [('M105', 'M', 105, 0)])[0])

    def test_G1004_nothing_in_the_stop_gate_depends_on_the_header_being_c(self):
        h = HDR.read_text(); self.assertNotIn('#include', h.replace('#include <', '#includ <'), 'keine Marlin-Abhaengigkeit'); self.assertIn('SV04_CLAUDE_STOPP_GATE', h)


class GcodeHead(unittest.TestCase):
    """Der ECHTE Kopf von process_parsed_command (aus der gepatchten gcode.cpp) mit Attrappen."""
    @classmethod
    def setUpClass(cls):
        cls.tree = patched_tree(); t = (cls.tree / 'Marlin/src/gcode/gcode.cpp').read_text()
        a = t.index('void GcodeSuite::process_parsed_command(const bool no_ok/*=false*/) {'); b = t.index('  switch (parser.command_letter) {', a)
        head = t[a:b]; cls.head = head
        inc = head + '  dispatched++;\n  if (!no_ok) queue.ok_to_send();\n  SERIAL_OUT(msgDone);\n}\n'
        cls.d = Path(tempfile.mkdtemp()); (cls.d / 'head_extract.inc').write_text(inc)
        cls.exe = cls.d / 'h'
        r = sh(GXX + ['-I', str(cls.d), f'-DSV04_GATE_HEADER="{HDR}"', str(CPP / 'head_driver.cpp'), '-o', str(cls.exe)]); assert r.returncode == 0, r.stderr[-900:]

    def run_head(self, stopped, no_ok, text, now=0):
        l, c, s = parse_like_marlin(text)
        o = sh([str(self.exe), str(stopped), str(no_ok), l, str(c), str(s), str(now), text]).stdout.split()
        return dict(x.split('=') for x in o)

    def test_G1010_refused_command_never_reaches_the_dispatcher_but_still_gets_its_ok(self):
        for t in ('G28', 'T1', 'G29', 'M84', 'M104 S200', 'M24', 'M1060', 'M500'):
            r = self.run_head(1, 0, t); self.assertEqual((r['dispatched'], r['ok'], r['done']), ('0', '1', '1'), t)
            r = self.run_head(1, 1, t); self.assertEqual((r['dispatched'], r['ok'], r['done']), ('0', '0', '1'), t + ' (no_ok)')

    def test_G1011_allowed_commands_in_stopped_state_reach_the_dispatcher(self):
        for t in ('M999', 'M112', 'M105', 'M104 S0', 'M140 S0', 'M410', 'M108'):
            r = self.run_head(1, 0, t); self.assertEqual((r['dispatched'], r['msgs']), ('1', '0'), t)

    def test_G1012_gate_is_inactive_when_not_stopped(self):
        for t in ('G28', 'T1', 'G29', 'M84', 'M104 S200', 'M500', 'M24'):
            r = self.run_head(0, 0, t); self.assertEqual((r['dispatched'], r['msgs']), ('1', '0'), t)

    def test_G1013_message_is_rate_limited(self):
        self.assertEqual(self.run_head(1, 0, 'G28', 0)['msgs'], '1'); self.assertEqual(self.run_head(1, 0, 'G28', 1000)['msgs'], '1')  # eigener Prozess = neuer Zaehler
        t = self.head; self.assertIn('PENDING(sv04c10_now, sv04c10_next_msg)', t); self.assertIn('+ 2000', t)

    def test_G1014_gate_sits_before_the_dispatch_and_after_the_existing_guards(self):
        i = self.head.index('SV04 NEXT C10 (stop gate)'); self.assertGreater(i, self.head.index('STR_FLOWMETER_FAULT')); self.assertLess(i, len(self.head))

    def test_G1015_every_command_the_real_318_display_code_enqueues_is_refused_in_the_stopped_state(self):
        src = (IN / '318/LCD_RTS.cpp').read_text(); cmds = sorted(set(re.findall(r'enqueue_now_P\(PSTR\("([^"]+)"\)', src)))
        self.assertGreaterEqual(len(cmds), 20); self.assertIn('G28', cmds); self.assertIn('M24', cmds); self.assertIn('M84', cmds)
        exe = build_gate(HDR); res = gate_run(exe, [(c, *parse_like_marlin(c)) for c in cmds])
        self.assertEqual([c for c, ok in zip(cmds, res) if ok], [], 'Display-Befehle, die im Stopp durchkommen')
        allowed_in_oem = [c for c in cmds if c.startswith(('M104', 'M140'))]
        self.assertEqual(allowed_in_oem, [], 'Das Display sendet keine Heizer-AUS-Befehle: sie wuerden sonst bewusst erlaubt')


def build_queue(patched_queue_cpp: Path, defines=()):
    qh = (IN / 'oem/queue.h').read_text(); a = qh.index('struct RingBuffer {'); b = qh.index('};', a) + 2
    q = patched_queue_cpp.read_text(); fa = q.index('// SV04 NEXT C10 (queue flush): M999 aus'); fb = q.index('bool sv04c10_queue_flush_pending = false;') + len('bool sv04c10_queue_flush_pending = false;')
    aa = q.index('void GCodeQueue::advance() {'); ab = q.index('\n}\n', aa) + 3
    d = Path(tempfile.mkdtemp()); (d / 'ring_extract.inc').write_text(qh[a:b]); (d / 'flagdef_extract.inc').write_text(q[fa:fb] + '\n'); (d / 'advance_extract.inc').write_text(q[aa:ab])
    exe = d / 'q'; r = sh(GXX + ['-Wno-unused-parameter'] + [f'-D{x}' for x in defines] + ['-I', str(d), str(CPP / 'queue_driver.cpp'), '-o', str(exe)]); assert r.returncode == 0, r.stderr[-900:]
    return exe


def qrun(exe, ir, n, k, naive=0, inj=0, stopped=1, steps=None):
    # inj: 0 keine, 1 M999 injiziert, 2 injizierte Makrozeile 'M999\\nSTALE' (Rest muss verworfen werden)
    a = [str(exe), str(ir), str(n), str(k), str(naive), str(inj), str(stopped)] + ([str(steps)] if steps else [])
    o = sh(a).stdout.strip(); m = re.match(r'executed=(\S*) length=(\d+) pending=(\d) inj=(\d)', o); assert m, o
    return m.group(1).split(',') if m.group(1) else [], int(m.group(2)), int(m.group(3)), int(m.group(4))


class Queue(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tree = patched_tree(); cls.pq = cls.tree / 'Marlin/src/gcode/queue.cpp'
        cls.exe = {b: build_queue(cls.pq, [f'BUFSIZE={b}']) for b in (4, 5, 8, 16)}
        oem = Path(tempfile.mkdtemp()) / 'queue.cpp'; shutil.copy(IN / 'oem/queue.cpp', oem)
        cls.oem_text = oem.read_text()

    def test_Q1001_full_state_space_stale_commands_after_m999_are_discarded(self):
        n_runs = 0
        for b, exe in self.exe.items():
            for ir in range(b):
                for n in range(1, b + 1):
                    for k in range(n):
                        ex, ln, pend, inj = qrun(exe, ir, n, k)
                        want = [f'C{i}' if i != k else 'M999' for i in range(k + 1)]
                        self.assertEqual((ex, ln, pend, inj), (want, 0, 0, 0), (b, ir, n, k)); n_runs += 1
        self.assertGreater(n_runs, 400)

    def test_Q1002_m999_from_the_injection_path_discards_stale_ring_commands_before_any_runs(self):
        for b, exe in self.exe.items():
            for ir in range(b):
                for n in range(1, b + 1):
                    ex, ln, pend, inj = qrun(exe, ir, n, -1, inj=1)
                    self.assertEqual((ex, ln, pend), (['M999(inj)'], 0, 0), (b, ir, n))

    def test_Q1007_the_rest_of_an_injected_macro_after_m999_is_discarded_too(self):
        for b, exe in self.exe.items():
            for ir in range(b):
                for n in range(0, b + 1):
                    ex, ln, pend, inj = qrun(exe, ir, n, -1, inj=2)
                    self.assertEqual((ex, ln, pend, inj), (['M999(inj)'], 0, 0, 0), (b, ir, n))

    def test_Q1003_without_a_stop_m999_does_not_touch_the_queue(self):
        for b, exe in self.exe.items():
            ex, ln, pend, _ = qrun(exe, 1 % b, b, 0, stopped=0); self.assertEqual((ex, ln), (['M999'] + [f'C{i}' for i in range(1, b)], 0))

    def test_Q1004_negative_control_without_the_patch_the_stale_commands_run(self):
        off = build_queue(self.pq, ['BUFSIZE=4', 'SV04_CLAUDE_M999_QUEUE_FLUSH=0'])
        ex, ln, pend, _ = qrun(off, 0, 4, 1); self.assertEqual(ex, ['C0', 'M999', 'C2', 'C3'], 'OEM-Verhalten: nach M999 laufen eingereihte Befehle weiter'); self.assertEqual(pend, 1)

    def test_Q1005_negative_control_clear_inside_the_handler_underflows_the_counter(self):
        ex, ln, pend, _ = qrun(self.exe[4], 0, 4, 1, naive=1, steps=2); self.assertEqual(ln, 255, 'uint8_t-Unterlauf nach clear() im Handler: genau der Grund fuer das Flag')

    def test_Q1006_the_diff_touches_only_the_three_expected_places(self):
        a = self.oem_text.splitlines(); b = self.pq.read_text().splitlines(); self.assertEqual(len(b) - len(a), 7 + 10 + 10)
        import difflib; removed = [l for l in difflib.unified_diff(a, b, lineterm='', n=0) if l.startswith('-') and not l.startswith('---')]
        self.assertEqual(removed, [], 'C10 loescht keine OEM-Zeile in queue.cpp')


class M999(unittest.TestCase):
    STUBS = {
        'gcode/gcode.h': '#pragma once\n#include <cstdio>\n#include <string>\nextern std::string sim_log;\n#define SERIAL_ECHO_MSG(s) do { sim_log += s; sim_log += "|"; } while (0)\nstruct Parser { bool s = false; bool boolval(char) const { return s; } };\nextern Parser parser;\nstruct GcodeSuite { static void M999(); };\n',
        'lcd/marlinui.h': '#pragma once\nstruct UI { int alerts = 0; void reset_alert_level() { ++alerts; } };\nextern UI ui;\n',
        'MarlinCore.h': '#pragma once\nenum MarlinState { MF_INITIALIZING = 0, MF_STOPPED = 1, MF_KILLED = 2, MF_RUNNING = 3 };\nextern MarlinState marlin_state;\ninline bool IsStopped() { return marlin_state == MF_STOPPED; }\n',
        'gcode/queue.h': '#pragma once\nstruct Ring { int command_port() const { return 0; } };\nstruct Queue { int flushes = 0; Ring ring_buffer; void flush_and_request_resend(int) { ++flushes; } };\nextern Queue queue;\n',
        'module/motion.h': '#pragma once\nextern unsigned axis_homed, axis_trusted;\ninline void set_all_unhomed() { axis_homed = axis_trusted = 0; }\n',
    }
    MAIN = r'''#include <cstdlib>
#include <cstdio>
#include <string>
#include "gcode/gcode.h"
#include "lcd/marlinui.h"
#include "MarlinCore.h"
#include "gcode/queue.h"
#include "module/motion.h"
std::string sim_log; Parser parser; UI ui; MarlinState marlin_state = MF_RUNNING; Queue queue; unsigned axis_homed = 0, axis_trusted = 0; bool sv04c10_queue_flush_pending = false;
int main(int argc, char** argv) {
  marlin_state = (MarlinState)std::atoi(argv[1]); axis_homed = std::atoi(argv[2]); axis_trusted = std::atoi(argv[3]); parser.s = std::atoi(argv[4]) != 0;
  GcodeSuite::M999();
  std::printf("state=%d homed=%u trusted=%u flushes=%d flag=%d\n", (int)marlin_state, axis_homed, axis_trusted, queue.flushes, (int)sv04c10_queue_flush_pending);
}
'''

    @classmethod
    def build(cls, src: Path, defines=()):
        d = Path(tempfile.mkdtemp())
        for rel, txt in cls.STUBS.items(): (d / rel).parent.mkdir(parents=True, exist_ok=True); (d / rel).write_text(txt)
        (d / 'gcode/control').mkdir(parents=True, exist_ok=True); shutil.copy(src, d / 'gcode/control/M999.cpp'); (d / 'main.cpp').write_text(cls.MAIN)
        r = sh(GXX + [f'-D{x}' for x in defines] + ['-I', str(d), str(d / 'main.cpp'), str(d / 'gcode/control/M999.cpp'), '-o', str(d / 'm')]); assert r.returncode == 0, r.stderr[-700:]
        return d / 'm'

    @staticmethod
    def runbin(exe, state, homed, trusted, s=0):
        return dict(x.split('=') for x in sh([str(exe), str(state), str(homed), str(trusted), str(s)]).stdout.split())

    @classmethod
    def setUpClass(cls):
        cls.tree = patched_tree(); cls.exe = cls.build(cls.tree / 'Marlin/src/gcode/control/M999.cpp')

    def test_M1001_flag_is_set_exactly_after_a_stop_for_m999_with_and_without_s(self):
        for s in (0, 1):
            r = self.runbin(self.exe, 1, 7, 7, s); self.assertEqual((r['state'], r['homed'], r['trusted'], r['flag']), ('3', '0', '0', '1'), f'S={s}')
            r = self.runbin(self.exe, 3, 7, 7, s); self.assertEqual((r['homed'], r['trusted'], r['flag']), ('7', '7', '0'), f'laufend S={s}')

    def test_M1002_without_the_rehome_switch_the_c9_block_and_therefore_the_flag_are_off(self):
        exe = self.build(self.tree / 'Marlin/src/gcode/control/M999.cpp', ['SV04_CLAUDE_M999_REHOME_REQUIRED=0']); r = self.runbin(exe, 1, 7, 7); self.assertEqual((r['homed'], r['flag']), ('7', '0'))

    def test_M1003_c9_behaviour_is_unchanged(self):
        r = self.runbin(self.exe, 1, 7, 7); self.assertEqual((r['homed'], r['trusted']), ('0', '0')); self.assertEqual(r['flushes'], '1')  # flush_and_request_resend wie OEM
        r = self.runbin(self.exe, 1, 7, 7, 1); self.assertEqual(r['flushes'], '0')


class PatchScript(unittest.TestCase):
    def tree(self):
        d = Path(tempfile.mkdtemp()); (d / 'Marlin/src/gcode/control').mkdir(parents=True)
        shutil.copy(IN / '318/gcode.cpp', d / 'Marlin/src/gcode/gcode.cpp'); shutil.copy(IN / 'oem/queue.cpp', d / 'Marlin/src/gcode/queue.cpp'); shutil.copy(IN / 'c9/M999.cpp', d / 'Marlin/src/gcode/control/M999.cpp'); return d

    def apply(self, d): return sh([sys.executable, '-I', str(APPLY), str(d)])

    def test_P1001_apply_is_idempotent_and_byte_stable(self):
        d = self.tree(); r = self.apply(d); self.assertEqual(r.returncode, 0, r.stdout); h1 = [sha(d / f) for f in ('Marlin/src/gcode/gcode.cpp', 'Marlin/src/gcode/queue.cpp', 'Marlin/src/gcode/control/M999.cpp')]
        r = self.apply(d); self.assertEqual(r.returncode, 0); self.assertEqual(r.stdout.count('ALREADY'), 3); self.assertEqual(h1, [sha(d / f) for f in ('Marlin/src/gcode/gcode.cpp', 'Marlin/src/gcode/queue.cpp', 'Marlin/src/gcode/control/M999.cpp')])

    def test_P1002_foreign_file_aborts_and_nothing_is_written(self):
        d = self.tree(); (d / 'Marlin/src/gcode/gcode.cpp').write_text((d / 'Marlin/src/gcode/gcode.cpp').read_text() + '\n'); before = {p: sha(p) for p in d.rglob('*') if p.is_file()}
        r = self.apply(d); self.assertEqual(r.returncode, 3); self.assertEqual(before, {p: sha(p) for p in d.rglob('*') if p.is_file()}, 'nichts geschrieben, auch kein Header')

    def test_P1003_mixed_state_aborts(self):
        d = self.tree(); self.assertEqual(self.apply(d).returncode, 0); shutil.copy(IN / 'oem/queue.cpp', d / 'Marlin/src/gcode/queue.cpp'); r = self.apply(d); self.assertEqual(r.returncode, 3); self.assertIn('gemischt', r.stdout)

    def test_P1004_patched_but_modified_aborts(self):
        d = self.tree(); self.assertEqual(self.apply(d).returncode, 0); p = d / 'Marlin/src/gcode/control/M999.cpp'; p.write_text(p.read_text() + '// x\n'); r = self.apply(d); self.assertEqual(r.returncode, 3); self.assertIn('Endstand', r.stdout)

    def test_P1005_only_the_expected_files_differ_and_the_input_pins_are_the_documented_ones(self):
        pins = dict(l.split()[::-1] for l in (IN / 'EINGANG_SHA256.txt').read_text().splitlines())
        self.assertEqual(pins['318/gcode.cpp'], '12958700de094c44386c381a423966663058f62dfa7e1204d5922bcb46944a8d'); self.assertEqual(pins['oem/queue.cpp'], 'd5cdca65913adae0554b2e0f140b463d5e59d77c3161a26a129812ec1f4795ec'); self.assertEqual(pins['c9/M999.cpp'], 'cbaca8b8bca033002a39ceb0eff7a7a64799a2c99e7d1f83cb5ea6a203418654')

    def test_P1006_the_patch_deletes_no_oem_line(self):
        import difflib
        d = self.tree(); self.apply(d)
        for rel, orig in (('Marlin/src/gcode/gcode.cpp', '318/gcode.cpp'), ('Marlin/src/gcode/queue.cpp', 'oem/queue.cpp'), ('Marlin/src/gcode/control/M999.cpp', 'c9/M999.cpp')):
            a = (IN / orig).read_text().splitlines(); b = (d / rel).read_text().splitlines()
            rem = [l for l in difflib.unified_diff(a, b, lineterm='', n=0) if l.startswith('-') and not l.startswith('---')]; self.assertEqual(rem, [], rel)


# ---------------- Mutanten ----------------
GATE_MUTANTS = [
    ("if (*p != 'M' || letter != 'M') return false;", "if (*p != 'M') return false;"),
    ("if (*p != 'M' || letter != 'M') return false;", "if (letter != 'M') return false;"),
    ("if (*p < '1' || *p > '9') return false;", "if (*p < '0' || *p > '9') return false;"),
    ("if (++digits > 4) return false;", "++digits;"),
    ("if (*p == '.') return false;", "if (false) return false;"),
    ("if (*p != '\\0' && *p != ' ') return false;", "if (false) return false;"),
    ("if (n != codenum || subcode != 0) return false;", "if (subcode != 0) return false;"),
    ("if (n != codenum || subcode != 0) return false;", "if (n != codenum) return false;"),
    ("case 999: case 112: case 108: case 410:", "case 999: case 112: case 108: case 410: case 84:"),
    ("case 105: case 114: case 115: case 119: case 503:", "case 105: case 114: case 115: case 119: case 503: case 106:"),
    ("return sv04c10_only_spaces(p);", "return true;"),
    ("return sv04c10_params_ok(p, \"ST\", 'S', 'T');", "return sv04c10_params_ok(p, \"STB\", 'S', 'T');"),
    ("return sv04c10_params_ok(p, \"ST\", 'S', 'T');", "return sv04c10_params_ok(p, \"ST\", 0, 'T');"),
    ("return sv04c10_params_ok(p, \"ST\", 'S', 'T');", "return sv04c10_params_ok(p, \"ST\", 'S', 0);"),
    ("return sv04c10_params_ok(p, \"S\", 'S', 0);", "return sv04c10_params_ok(p, \"SI\", 'S', 0);"),
    ("return sv04c10_params_ok(p, \"S\", 'S', 0);", "return sv04c10_params_ok(p, \"S\", 0, 0);"),
    ("if (seen & bit) return false;", "if (false) return false;"),
    ("if (c < 'A' || c > 'Z') return false;", "if (c < 'A' || c > 'z') return false;"),
    ("if (!in_list) return false;", "if (false) return false;"),
    ("if (c == need_zero) zero_ok = sv04c10_text_is_zero(v, p);", "if (c == need_zero) zero_ok = true;"),
    ("else if (*s == '0') digit = true;", "else if (*s == '0' || *s == '1') digit = true;"),
    ("if (*s == '.') { if (dot) return false; dot = true; }", "if (*s == '.') { dot = true; }"),
    ("  return digit;\n}", "  return true;\n}"),
    ("if (n < 1 || n > 2) return false;", "if (n > 2) return false;"),
    ("if (*q < '0' || *q > '9') return false;", "if (false) return false;"),
    ("if (!((d >= '0' && d <= '9') || d == '+' || d == '-' || d == '.')) return false;", "if (false) return false;"),
    ("if (!cmd) return false;", "if (false) return false;"),
    ("  return zero_ok;\n}", "  return true;\n}"),
]


# Aequivalente Mutanten (mehrfach abgesicherte Pruefungen): sie duerfen ueberleben, MUESSEN aber auf dem ganzen Korpus gleich antworten.
EQUIV = {
    4: "'.'-Pruefung ist doppelt abgesichert: die naechste Zeile verweigert jedes Zeichen ausser Ende/Leerzeichen",
    17: "Buchstaben-Obergrenze ist doppelt abgesichert: die Liste der erlaubten Buchstaben enthaelt nur Grossbuchstaben",
    25: "Wert-Zeichenpruefung ist doppelt abgesichert: S wird durch text_is_zero, T durch die Ziffernpruefung validiert",
}


class Mutants(unittest.TestCase):
    def test_G1020_every_gate_mutant_is_killed(self):
        src = HDR.read_text(); survivors = []
        items = [(t, *parse_like_marlin(t)) for t in ALLOW + DENY]
        rnd = random.Random(7); alpha = 'MGT0123456789 .+-SXYZNTBF*;e'
        for _ in range(6000): t = ''.join(rnd.choice(alpha) for _ in range(rnd.randint(0, 12))); items.append((t, *parse_like_marlin(t)))
        for b in ('M104', 'M140', 'M105', 'M106', 'M84'):
            for p in ('', ' S0', ' S1', ' S0 T1', ' S0 B1', ' T1', ' S0 S0', ' S0.', ' s0', ' S1e0', ' SI0'): items.append((b + p, *parse_like_marlin(b + p)))
        items += [('M104 S0 T123', 'M', 104, 0), ('M105', 'M', 104, 0), ('M105', 'G', 105, 0), ('M105', 'M', 105, 1), ('M4294968295', 'M', 999, 0), ('M4294967401', 'M', 105, 0), ('\x01NULL', 'M', 105, 0)]
        want = [ref_allowed(*i) for i in items]
        # Grundlauf muss gruen sein
        d0 = Path(tempfile.mkdtemp()) / 'h.h'; d0.write_text(src); self.assertEqual(gate_run(build_gate(d0), items), want)
        for i, (old, new) in enumerate(GATE_MUTANTS):
            self.assertEqual(src.count(old), 1, f'Mutant {i}: Anker {src.count(old)}x')
            d = Path(tempfile.mkdtemp()) / 'm.h'; d.write_text(src.replace(old, new))
            try: got = gate_run(build_gate(d), items)
            except AssertionError: continue   # Mutant kompiliert nicht = erkannt
            if got == want and i not in EQUIV: survivors.append((i, old, new))
            if i in EQUIV: self.assertEqual(got, want, f'Mutant {i} muesste aequivalent sein: {EQUIV[i]}')
        self.assertEqual(survivors, [], f'ueberlebende Mutanten: {survivors}')

    def test_Q1020_queue_patch_mutants_are_killed(self):
        tree = patched_tree(); pq = tree / 'Marlin/src/gcode/queue.cpp'; src = pq.read_text()
        def grid(exe):
            out = []
            for ir in range(4):
                for n in range(1, 5):
                    for k in range(n): out.append(qrun(exe, ir, n, k))
                    out.append(qrun(exe, ir, n, -1, inj=1)); out.append(qrun(exe, ir, n, -1, inj=2))
            return out
        base = grid(build_queue(pq, ['BUFSIZE=4'])); muts = [
            ("      sv04c10_queue_flush_pending = false;\n      ring_buffer.clear();\n      injected_commands_P = nullptr;\n      injected_commands[0] = '\\0';\n    }\n  #endif\n\n  // Process immediate commands", "      sv04c10_queue_flush_pending = false;\n    }\n  #endif\n\n  // Process immediate commands"),   # Kopf: kein Leeren
            ("  ring_buffer.advance_pos(ring_buffer.index_r, -1);\n\n  // SV04 NEXT C10 (queue flush): erst NACH", "  ring_buffer.advance_pos(ring_buffer.index_r, -1);\n  if (false) {}\n\n  // SV04 NEXT C10 (queue flush): erst NACH"),
        ]
        # textuelle Mutanten fuer den Fuss (zweiter Block) und fuer das Rueckstellen der Injektion
        foot_idx = src.rindex("      ring_buffer.clear();")
        m_foot_noclear = src[:foot_idx] + "      (void)0;" + src[foot_idx + len("      ring_buffer.clear();"):]
        head_idx = src.index("      ring_buffer.clear();")
        m_head_noclear = src[:head_idx] + "      (void)0;" + src[head_idx + len("      ring_buffer.clear();"):]
        m_noinj = src.replace("      injected_commands_P = nullptr;\n", "", 1)
        m_keepflag = src.replace("      sv04c10_queue_flush_pending = false;\n", "", 1)
        survivors = []
        for name, text in (('Fuss ohne clear', m_foot_noclear), ('Kopf ohne clear', m_head_noclear), ('Kopf ohne injected_commands_P', m_noinj), ('Flag nie zurueckgesetzt (Kopf)', m_keepflag)):
            d = Path(tempfile.mkdtemp()) / 'queue.cpp'; d.write_text(text)
            try: g = grid(build_queue(d, ['BUFSIZE=4']))
            except AssertionError: continue
            if g == base: survivors.append(name)
        self.assertEqual(survivors, [], f'ueberlebende Mutanten: {survivors}')


if __name__ == '__main__':
    unittest.main(verbosity=2)
