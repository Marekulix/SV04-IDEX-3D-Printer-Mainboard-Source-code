// Echter Kopf von GcodeSuite::process_parsed_command (aus der gepatchten gcode.cpp extrahiert) mit Attrappen.
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cstdint>
#include <algorithm>
typedef uint32_t millis_t;
#define ENABLED(x) 0
#define KEEPALIVE_STATE(x) do{}while(0)
#define PENDING(now, ref) ((int32_t)((now) - (ref)) < 0)
std::string out; int ok_calls = 0, done_calls = 0, dispatched = 0; millis_t now_ms = 0;
static millis_t millis() { return now_ms; }
#define SERIAL_ECHO_MSG(s) do { out += s; out += "|"; } while (0)
#define SERIAL_OUT(x) (++done_calls)
#define msgDone 0
#define STR_PRINTER_LOCKED "locked"
#define STR_FLOWMETER_FAULT "flow"
struct Parser { const char *command_ptr; char command_letter; int codenum; int subcode; } parser;
struct Queue { void ok_to_send() { ++ok_calls; } } queue;
enum MarlinState { MF_STOPPED = 1, MF_RUNNING = 3 }; MarlinState marlin_state = MF_RUNNING;
static bool IsStopped() { return marlin_state == MF_STOPPED; }
#include SV04_GATE_HEADER
struct GcodeSuite { static void process_parsed_command(const bool no_ok = false); };
#include "head_extract.inc"
int main(int argc, char **argv) {
  // argv: stopped no_ok letter codenum subcode now_ms text
  marlin_state = std::atoi(argv[1]) ? MF_STOPPED : MF_RUNNING;
  const bool no_ok = std::atoi(argv[2]) != 0;
  parser.command_letter = argv[3][0]; parser.codenum = std::atoi(argv[4]); parser.subcode = std::atoi(argv[5]);
  now_ms = (millis_t)std::strtoul(argv[6], nullptr, 10); parser.command_ptr = argv[7];
  GcodeSuite::process_parsed_command(no_ok);
  std::printf("dispatched=%d ok=%d done=%d msgs=%d\n", dispatched, ok_calls, done_calls, (int)std::count(out.begin(), out.end(), '|'));
}
