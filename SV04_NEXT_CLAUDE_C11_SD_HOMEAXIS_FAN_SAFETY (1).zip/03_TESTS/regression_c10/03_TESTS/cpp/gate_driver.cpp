// liest Zeilen "letter<TAB>codenum<TAB>subcode<TAB>text" und schreibt je Zeile 0/1 (erlaubt im Stopp)
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include SV04_GATE_HEADER
int main() {
  char line[512];
  while (std::fgets(line, sizeof line, stdin)) {
    size_t n = std::strlen(line); while (n && (line[n-1] == '\n' || line[n-1] == '\r')) line[--n] = 0;
    char *a = line, *t1 = std::strchr(a, '\t'); if (!t1) { std::puts("?"); continue; } *t1++ = 0;
    char *t2 = std::strchr(t1, '\t'); if (!t2) { std::puts("?"); continue; } *t2++ = 0;
    char *t3 = std::strchr(t2, '\t'); if (!t3) { std::puts("?"); continue; } *t3++ = 0;
    const char *txt = (t3[0] == 1 && std::strcmp(t3 + 1, "NULL") == 0) ? nullptr : t3;   // \x01NULL = Nullzeiger
    std::puts(sv04c10_stopped_allowed(txt, a[0], std::atoi(t1), std::atoi(t2)) ? "1" : "0");
  }
}
