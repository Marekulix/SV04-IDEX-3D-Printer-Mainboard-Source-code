// Echter RingBuffer (aus queue.h) + echte advance() (aus der gepatchten queue.cpp) mit Attrappen.
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <cstdint>
#define ENABLED(x) 0
#define OPTARG(a, b)
#ifndef BUFSIZE
  #define BUFSIZE 4
#endif
#define MAX_CMD_SIZE 24
struct serial_index_t {};
#define TERN0(a, b) serial_index_t()
#define HAS_MULTI_SERIAL 0
struct GCodeQueue {
  struct CommandLine { char buffer[MAX_CMD_SIZE]; bool skip_ok; };
  #include "ring_extract.inc"
  static RingBuffer ring_buffer;
  static const char *injected_commands_P;
  static char injected_commands[64];
  static bool process_injected_command_P();
  static bool process_injected_command();
  static void advance();
};
GCodeQueue::RingBuffer GCodeQueue::ring_buffer;
const char *GCodeQueue::injected_commands_P = nullptr;
char GCodeQueue::injected_commands[64] = {0};
#include "flagdef_extract.inc"
// --- Szenario-Modell ---
static GCodeQueue queue; static std::vector<std::string> executed; static int naive = 0, inj_m999 = 0, inj_pending_stale = 0;
static bool g_stopped_m999 = true;           // M999 kam aus dem Stopp-Zustand (setzt dann das Flag wie der gepatchte M999)
struct Gcode { void process_next_command() {
  std::string c = GCodeQueue::ring_buffer.peek_next_command_string(); executed.push_back(c);
  if (c == "M999") { if (naive) GCodeQueue::ring_buffer.clear(); else if (g_stopped_m999) sv04c10_queue_flush_pending = true; }
} } gcode;
static char macro_buf[64];
bool GCodeQueue::process_injected_command_P() {
  if (inj_m999 == 2) {   // Makro "M999\nSTALE": erste Zeile jetzt, Rest bleibt in injected_commands_P stehen
    inj_m999 = 3; std::strcpy(macro_buf, "M999\nSTALE"); injected_commands_P = macro_buf;
  }
  if (inj_m999 == 3 && injected_commands_P) {
    const char *nl = std::strchr(injected_commands_P, '\n'); std::string line = nl ? std::string(injected_commands_P, nl - injected_commands_P) : std::string(injected_commands_P);
    injected_commands_P = nl ? nl + 1 : nullptr; executed.push_back(line == "M999" ? "M999(inj)" : "INJ_" + line); if (line == "M999" && g_stopped_m999) sv04c10_queue_flush_pending = true; return true;
  }
  if (inj_m999 == 1) { inj_m999 = 0; executed.push_back("M999(inj)"); if (g_stopped_m999) sv04c10_queue_flush_pending = true; return true; }
  return false;
}
bool GCodeQueue::process_injected_command() { return false; }
#include "advance_extract.inc"
int main(int argc, char **argv) {
  // argv: index_r n k naive inj g_stopped
  const int ir = std::atoi(argv[1]), n = std::atoi(argv[2]), k = std::atoi(argv[3]);
  naive = std::atoi(argv[4]); inj_m999 = std::atoi(argv[5]); g_stopped_m999 = std::atoi(argv[6]) != 0;
  auto &rb = GCodeQueue::ring_buffer; rb.clear(); rb.index_r = rb.index_w = (uint8_t)ir;
  for (int i = 0; i < n; i++) {   // n eingereihte Befehle; an Position k steht M999 (k < 0: keiner)
    std::snprintf(rb.commands[rb.index_w].buffer, MAX_CMD_SIZE, (i == k) ? "M999" : "C%d", i);
    if (++rb.index_w >= BUFSIZE) { rb.index_w = 0; }
    rb.length++;
  }
  const int steps = argc > 7 ? std::atoi(argv[7]) : 4 * BUFSIZE + 4;
  for (int guard = 0; guard < steps; guard++) { GCodeQueue::advance(); }
  std::printf("executed="); for (size_t i = 0; i < executed.size(); i++) std::printf("%s%s", i ? "," : "", executed[i].c_str());
  std::printf(" length=%u pending=%d inj=%d\n", (unsigned)rb.length, (int)sv04c10_queue_flush_pending, (int)(GCodeQueue::injected_commands_P != nullptr || GCodeQueue::injected_commands[0] != 0));
}
