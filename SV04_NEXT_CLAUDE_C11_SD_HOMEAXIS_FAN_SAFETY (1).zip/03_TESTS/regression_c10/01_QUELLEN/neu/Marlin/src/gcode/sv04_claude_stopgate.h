/**
 * SV04 NEXT C10 - Stopp-Gate (reine Entscheidungsfunktion, keine Marlin-Abhaengigkeit)
 *
 * Im Stopp-Zustand (MF_STOPPED, z. B. nach einem BLTouch-stop()) darf nur eine feste Whitelist von
 * Befehlen ausgefuehrt werden. Alles andere (G28, G29, T, Bewegungen, Heizen > 0, M84, EEPROM, M1060 ...)
 * wird verweigert. Fail-closed: bei jedem Zweifel am Text ODER bei Abweichung zwischen eigenem Lesen und
 * dem Marlin-Parser wird verweigert.
 *
 * Erlaubt (Entscheidung C10, ohne M84, ohne Luefter, weil keine Nachweise zu den Handlern vorliegen):
 *   M999, M112, M108, M410                 (beliebige Parameter)
 *   M105, M114, M115, M119, M503           (nur ohne Parameter)
 *   M104 S0 [T<n>]   M140 S0               (nur Heizer AUS, S muss numerisch 0 sein, keine weiteren Parameter)
 */
#ifndef SV04_CLAUDE_STOPGATE_H
#define SV04_CLAUDE_STOPGATE_H

#ifndef SV04_CLAUDE_STOPP_GATE
  #define SV04_CLAUDE_STOPP_GATE 1
#endif

// Wert-Text ist numerisch null: [+-]? Ziffern/ein Punkt, mindestens eine Ziffer, alle Ziffern '0'
static inline bool sv04c10_text_is_zero(const char *s, const char *e) {
  if (s < e && (*s == '+' || *s == '-')) s++;
  bool digit = false, dot = false;
  for (; s < e; s++) {
    if (*s == '.') { if (dot) return false; dot = true; }
    else if (*s == '0') digit = true;
    else return false;
  }
  return digit;
}

// Nur Leerzeichen bis Ende?
static inline bool sv04c10_only_spaces(const char *p) {
  while (*p == ' ') p++;
  return *p == '\0';
}

// Parameterliste: Token = Grossbuchstabe + Wert (Zeichen aus 0-9 + - .). Erlaubte Buchstaben in 'allowed'.
// Jeder Buchstabe hoechstens einmal. 'need_zero' (oder 0): dieser Buchstabe muss vorhanden und numerisch 0 sein.
// 'digits_only' (oder 0): dieser Buchstabe, falls vorhanden, darf nur 1-2 Ziffern haben.
static inline bool sv04c10_params_ok(const char *p, const char *allowed, char need_zero, char digits_only) {
  unsigned long seen = 0;                    // Bits A..Z
  bool zero_ok = (need_zero == 0);
  for (;;) {
    while (*p == ' ') p++;
    if (*p == '\0') break;
    const char c = *p++;
    if (c < 'A' || c > 'Z') return false;
    const unsigned long bit = 1UL << (c - 'A');
    if (seen & bit) return false;            // doppelter Buchstabe: mehrdeutig
    seen |= bit;
    bool in_list = false;
    for (const char *a = allowed; *a; a++) if (*a == c) in_list = true;
    if (!in_list) return false;
    const char *v = p;
    while (*p && *p != ' ') {
      const char d = *p;
      if (!((d >= '0' && d <= '9') || d == '+' || d == '-' || d == '.')) return false;
      p++;
    }
    if (c == need_zero) zero_ok = sv04c10_text_is_zero(v, p);
    if (c == digits_only) {
      const int n = (int)(p - v);
      if (n < 1 || n > 2) return false;
      for (const char *q = v; q < p; q++) if (*q < '0' || *q > '9') return false;
    }
  }
  return zero_ok;
}

/**
 * cmd      : Zeiger auf den Befehlstext ab Befehlsbuchstabe (parser.command_ptr)
 * letter/codenum/subcode : was der Marlin-Parser aus demselben Text gemacht hat
 * Rueckgabe true = im Stopp-Zustand erlaubt
 */
static inline bool sv04c10_stopped_allowed(const char *cmd, const char letter, const int codenum, const int subcode) {
  if (!cmd) return false;
  const char *p = cmd;
  while (*p == ' ') p++;
  if (*p != 'M' || letter != 'M') return false;       // G, T, alles ausser M: verweigert
  p++;
  if (*p < '1' || *p > '9') return false;             // fuehrende 0 / keine Ziffer: verweigert
  int n = 0, digits = 0;
  while (*p >= '0' && *p <= '9') { if (++digits > 4) return false; n = n * 10 + (*p - '0'); p++; }
  if (*p == '.') return false;                        // Unterbefehl (M104.1 ...): verweigert
  if (*p != '\0' && *p != ' ') return false;          // z. B. M104S0: verweigert
  if (n != codenum || subcode != 0) return false;     // Parser und eigenes Lesen muessen uebereinstimmen
  switch (n) {
    case 999: case 112: case 108: case 410:
      return true;
    case 105: case 114: case 115: case 119: case 503:
      return sv04c10_only_spaces(p);
    case 104:
      return sv04c10_params_ok(p, "ST", 'S', 'T');
    case 140:
      return sv04c10_params_ok(p, "S", 'S', 0);
    default:
      return false;
  }
}

#endif // SV04_CLAUDE_STOPGATE_H
