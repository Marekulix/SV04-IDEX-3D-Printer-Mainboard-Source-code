#!/usr/bin/env python3
"""SV04 NEXT C10 - drei Patches, SHA-gepinnt, idempotent, fail-closed.
Aufruf: apply_c10.py <baum>   (Baum = 318 + C9, z. B. oem_c10; 318/C9/309 bleiben unberuehrt)
 gcode.cpp : Stopp-Gate (Pin 318-Stand 12958700...)
 queue.cpp : Warteschlange nach M999-aus-Stopp verwerfen (Pin OEM d5cdca65...)
 M999.cpp  : Flag setzen (Pin C9-Stand cbaca8b8...)
Neue Datei Marlin/src/gcode/sv04_claude_stopgate.h wird aus dem Paket kopiert (Hash gepinnt).
Fremder Hash -> Abbruch Exit 3, nichts wird geschrieben (alle Pruefungen vor dem ersten Schreiben)."""
import hashlib, pathlib, sys, shutil
PIN = {
 'Marlin/src/gcode/gcode.cpp':        ('12958700de094c44386c381a423966663058f62dfa7e1204d5922bcb46944a8d', None),
 'Marlin/src/gcode/queue.cpp':        ('d5cdca65913adae0554b2e0f140b463d5e59d77c3161a26a129812ec1f4795ec', None),
 'Marlin/src/gcode/control/M999.cpp': ('cbaca8b8bca033002a39ceb0eff7a7a64799a2c99e7d1f83cb5ea6a203418654', None),
}
FINAL = {  # erwarteter Hash NACH dem Patch (Idempotenz nur bei exakt diesem Stand)
 'Marlin/src/gcode/gcode.cpp': '14b2ff31f4528a47df65b0e62c8e7064c8936c41ba0bb0cf208375e35d9bea3f',
 'Marlin/src/gcode/queue.cpp': '5342ac2eea5e90edc13b59f98740b49f1d46dbab4f41896eb9e49b67a230b747',
 'Marlin/src/gcode/control/M999.cpp': '7aa10ae6e1fc111ee2a201c0e5539ab7f1fa09105222053158a8d9ee5be28775',
}
SIG = {  # Signatur, wenn bereits gepatcht (Idempotenz)
 'Marlin/src/gcode/gcode.cpp': 'SV04 NEXT C10 (stop gate)',
 'Marlin/src/gcode/queue.cpp': 'SV04 NEXT C10 (queue flush)',
 'Marlin/src/gcode/control/M999.cpp': 'SV04 NEXT C10 (flush flag)',
}
def sha(b): return hashlib.sha256(b).hexdigest()
def fail(m, rc=3): print('C10 FAIL:', m); sys.exit(rc)

GCODE_INC_OLD = '#include "../MarlinCore.h" // for idle, kill\n'
GCODE_INC_NEW = GCODE_INC_OLD + '#include "sv04_claude_stopgate.h"   // SV04 NEXT C10 (stop gate)\n'
GCODE_ANCHOR = '  // Handle a known command or reply "unknown command"\n'
GCODE_GATE = '''  // SV04 NEXT C10 (stop gate): im Stopp-Zustand (z. B. nach BLTouch-stop()) nur Whitelist-Befehle.
  // Alles andere (G28, G29, T, Bewegung, Heizen > 0, M84, EEPROM ...) wird verweigert, auch aus Warteschlange, SD, Display und Makros.
  #if SV04_CLAUDE_STOPP_GATE
    if (IsStopped() && !sv04c10_stopped_allowed(parser.command_ptr, parser.command_letter, (int)parser.codenum, (int)parser.subcode)) {
      static millis_t sv04c10_next_msg = 0;
      const millis_t sv04c10_now = millis();
      if (!PENDING(sv04c10_now, sv04c10_next_msg)) {
        sv04c10_next_msg = sv04c10_now + 2000;
        SERIAL_ECHO_MSG("SV04 C10: STOPPED state, command refused. Restart required (M999), then re-home (G28). Allowed now: M999 M112 M108 M410, status reads, heaters OFF");
      }
      if (!no_ok) queue.ok_to_send();
      SERIAL_OUT(msgDone);
      return;
    }
  #endif

'''
Q_VAR_ANCHOR = 'char GCodeQueue::injected_commands[64]; // = { 0 }\n'
Q_VAR_NEW = Q_VAR_ANCHOR + '''
// SV04 NEXT C10 (queue flush): M999 aus dem Stopp-Zustand setzt dieses Flag. Die Warteschlange wird NICHT im
// M999-Handler geleert (Laengenzaehler-Unterlauf, siehe advance_pos), sondern in advance() ausserhalb des Handlers.
#ifndef SV04_CLAUDE_M999_QUEUE_FLUSH
  #define SV04_CLAUDE_M999_QUEUE_FLUSH 1
#endif
bool sv04c10_queue_flush_pending = false;
'''
Q_ADV_OLD = 'void GCodeQueue::advance() {\n\n  // Process immediate commands\n'
Q_ADV_NEW = '''void GCodeQueue::advance() {

  // SV04 NEXT C10 (queue flush): Flag aus M999 (z. B. Befehl kam aus dem Injektionspfad) vor jeder weiteren Ausfuehrung abarbeiten
  #if SV04_CLAUDE_M999_QUEUE_FLUSH
    if (sv04c10_queue_flush_pending) {
      sv04c10_queue_flush_pending = false;
      ring_buffer.clear();
      injected_commands_P = nullptr;
      injected_commands[0] = '\\0';
    }
  #endif

  // Process immediate commands
'''
Q_END_OLD = '  // The queue may be reset by a command handler or by code invoked by idle() within a handler\n  ring_buffer.advance_pos(ring_buffer.index_r, -1);\n}\n'
Q_END_NEW = '''  // The queue may be reset by a command handler or by code invoked by idle() within a handler
  ring_buffer.advance_pos(ring_buffer.index_r, -1);

  // SV04 NEXT C10 (queue flush): erst NACH dem Entnehmen des aktuellen Befehls (M999) leeren, sonst Unterlauf des uint8_t-Zaehlers
  #if SV04_CLAUDE_M999_QUEUE_FLUSH
    if (sv04c10_queue_flush_pending) {
      sv04c10_queue_flush_pending = false;
      ring_buffer.clear();
      injected_commands_P = nullptr;
      injected_commands[0] = '\\0';
    }
  #endif
}
'''
M_EXT_OLD = 'void GcodeSuite::M999() {\n'
M_EXT_NEW = '''// SV04 NEXT C10 (flush flag): in queue.cpp definiert
extern bool sv04c10_queue_flush_pending;

void GcodeSuite::M999() {
'''
M_SET_OLD = '      set_all_unhomed();\n'
M_SET_NEW = '      set_all_unhomed();\n      sv04c10_queue_flush_pending = true;   // SV04 NEXT C10: bereits eingereihte Befehle verwerfen (in advance(), nicht hier)\n'

def one(s, old, name):
    if s.count(old) != 1: fail(f'{name}: Anker {s.count(old)}x statt 1x')
def main():
    if len(sys.argv) != 2: fail('usage: apply_c10.py <baum>', 2)
    root = pathlib.Path(sys.argv[1]); pk = pathlib.Path(__file__).resolve().parent.parent
    hdr_src = pk / '01_QUELLEN/neu/Marlin/src/gcode/sv04_claude_stopgate.h'
    if not hdr_src.is_file(): fail('Header fehlt im Paket')
    hdr_dst = root / 'Marlin/src/gcode/sv04_claude_stopgate.h'
    texts, state = {}, {}
    for rel, (pin, _) in PIN.items():
        f = root / rel
        if not f.is_file(): fail(f'{rel} fehlt')
        b = f.read_bytes(); t = b.decode('utf-8')
        if sha(b) == FINAL[rel]: state[rel] = 'ALREADY'; texts[rel] = t; continue
        if SIG[rel] in t: fail(f'{rel}: enthaelt C10-Signatur, aber Hash {sha(b)} ist nicht der erwartete Endstand (veraendert oder gemischt)')
        if sha(b) != pin: fail(f'{rel}: fremder Hash {sha(b)} (erwartet {pin})')
        state[rel] = 'TODO'; texts[rel] = t
    if len(set(state.values())) != 1: fail('gemischter Zustand (teils gepatcht, teils nicht): ' + str(state))
    if hdr_dst.exists() and hdr_dst.read_bytes() != hdr_src.read_bytes(): fail('Zieldatei sv04_claude_stopgate.h existiert mit anderem Inhalt')
    new = {}
    for rel in PIN:
        if state[rel] == 'ALREADY': continue
        s = texts[rel]
        if rel.endswith('gcode.cpp'):
            for o in (GCODE_INC_OLD, GCODE_ANCHOR): one(s, o, rel)
            s = s.replace(GCODE_INC_OLD, GCODE_INC_NEW).replace(GCODE_ANCHOR, GCODE_GATE + GCODE_ANCHOR)
        elif rel.endswith('queue.cpp'):
            for o in (Q_VAR_ANCHOR, Q_ADV_OLD, Q_END_OLD): one(s, o, rel)
            s = s.replace(Q_VAR_ANCHOR, Q_VAR_NEW).replace(Q_ADV_OLD, Q_ADV_NEW).replace(Q_END_OLD, Q_END_NEW)
        else:
            for o in (M_EXT_OLD, M_SET_OLD): one(s, o, rel)
            s = s.replace(M_EXT_OLD, M_EXT_NEW).replace(M_SET_OLD, M_SET_NEW)
        new[rel] = s
    for rel, s in new.items():
        (root / rel).write_text(s, encoding='utf-8')
    if not hdr_dst.exists(): shutil.copyfile(hdr_src, hdr_dst)
    for rel in PIN:
        print(f'C10 {rel}: {state[rel] if state[rel]=="ALREADY" else "PATCHED"} sha256 {sha((root/rel).read_bytes())}')
    print('C10 sv04_claude_stopgate.h sha256', sha(hdr_dst.read_bytes()))
if __name__ == '__main__': main()
