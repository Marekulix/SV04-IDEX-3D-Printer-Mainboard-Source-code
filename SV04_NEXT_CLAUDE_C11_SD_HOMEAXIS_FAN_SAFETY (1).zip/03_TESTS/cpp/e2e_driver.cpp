// C11: ECHTE Funktionskoepfe aus den gepatchten Dateien (get_sdcard_commands-Kopf, GcodeSuite::M999, abortSDPrinting) mit Attrappen.
// Annahme (nicht am echten cardreader.h belegt, Datei fehlt): IS_SD_PRINTING/IS_SD_FETCHING/IS_SD_PAUSED wie im Upstream-Marlin 2.0.x.
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <string>
#include <iostream>
#define ENABLED(x) (x)
#ifndef NO_SD
  #define SDSUPPORT 1
#endif
#define POWER_LOSS_RECOVERY 1
#define EVENT_GCODE_SD_ABORT "G28XY"
#define PSTR(x) x
// Marlin-Makros (TERN_/TERN/IF_DISABLED) fuer die in dieser Konfiguration geltenden Schalter (aus Configuration*.h: NO_SD_AUTOSTART aus, SD_RESORT aus, HAS_CUTTER aus, SD_ABORT_NO_COOLDOWN aus, POWER_LOSS_RECOVERY an)
#define TERN_(K,V) _T_##K(V)
#define _T_SD_RESORT(V)
#define _T_POWER_LOSS_RECOVERY(V) V
#define _T_PASSWORD_AFTER_SD_PRINT_ABORT(V)
#define IF_DISABLED(K,V) _D_##K(V)
#define _D_NO_SD_AUTOSTART(V) V
#define _D_SD_ABORT_NO_COOLDOWN(V) V
#define TERN(K,A,B) _TE_##K(A,B)
#define _TE_HAS_CUTTER(A,B) B
std::string inj, sim_log;
enum MarlinState { MF_STOPPED = 1, MF_RUNNING = 3 }; MarlinState marlin_state = MF_RUNNING;
static bool IsStopped() { return marlin_state == MF_STOPPED; }
struct Flag { bool sdprinting = false, abort_sd_printing = false; };
struct Card { Flag flag; bool open = false, paused = false; int aborts = 0;
  void abortFilePrintNow(bool = false) { flag.sdprinting = false; flag.abort_sd_printing = false; open = false; paused = false; ++aborts; }
  void autofile_cancel() {} } card;
#define IS_SD_PRINTING() (card.flag.sdprinting && !card.flag.abort_sd_printing)
#define IS_SD_FETCHING() (!card.flag.abort_sd_printing && card.open && card.flag.sdprinting)
#define IS_SD_PAUSED()   (card.paused)
struct Ring { int command_port() const { return 0; } };
struct Queue { int cleared = 0, flushes = 0; Ring ring_buffer; void clear() { ++cleared; } void inject_P(const char *s) { inj += s; inj += ";"; } void flush_and_request_resend(int) { ++flushes; } } queue;
struct UI { void reset_alert_level() {} } ui;
struct Parser { bool s = false; bool boolval(char) const { return s; } } parser;
unsigned axis_homed = 7; static void set_all_unhomed() { axis_homed = 0; }
enum AxisEnum { X_AXIS = 0, Y_AXIS = 1, Z_AXIS = 2 }; static bool axis_was_homed(AxisEnum a) { return (axis_homed >> a) & 1; }   // wie motion.h:415 (TEST(axis_homed, axis))
bool sv04c10_queue_flush_pending = false; bool wait_for_heatup = true; int heaters_off = 0, fans_zero = 0, quickstops = 0, timer_aborts = 0, recovery_purges = 0;
static void quickstop_stepper() { ++quickstops; }
struct PJT { void abort() { ++timer_aborts; } } print_job_timer;
struct TM { void disable_all_heaters() { ++heaters_off; } void zero_fan_speeds() { ++fans_zero; } } thermalManager;
struct Rec { void purge() { ++recovery_purges; } } recovery;
#define SERIAL_ECHO_MSG(s) do { sim_log += s; } while (0)
enum { PS_NORMAL = 0 };
int sd_reads = 0;
struct GCodeQueue { static void get_sdcard_commands(); };
struct GcodeSuite { static void M999(); };
extern bool sv04c11_sd_abort_silent;   // wie im echten M999.cpp (extern), Definition kommt aus dem abortSDPrinting-Auszug
#include "fetch_extract.inc"
#include "m999_extract.inc"
#include "abort_extract.inc"
static void loop_step() { if (card.flag.abort_sd_printing) abortSDPrinting(); }  // = MarlinCore.cpp loop(): vom Test gegen den echten Text geprueft
int main() {
  int stopped, sd, s; char seq[64];
  while (std::scanf("%d %d %d %63s", &stopped, &sd, &s, seq) == 4) {
    marlin_state = stopped ? MF_STOPPED : MF_RUNNING; card = Card(); card.open = sd != 0; card.flag.sdprinting = sd == 1; card.paused = sd == 2;
    inj.clear(); sim_log.clear(); queue = Queue(); axis_homed = 7; sv04c10_queue_flush_pending = false; sv04c11_sd_abort_silent = false; sd_reads = 0; heaters_off = fans_zero = quickstops = timer_aborts = recovery_purges = 0; parser.s = s != 0;
    for (char *p = seq; *p; ++p) switch (*p) {
      case 'F': GCodeQueue::get_sdcard_commands(); break;
      case 'M': GcodeSuite::M999(); break;
      case 'L': loop_step(); break;
      case 'U': if (card.open) card.flag.abort_sd_printing = true; break;   // Abbruch vom Display/Host (setzt nur das Flag)
      case 'X': marlin_state = MF_STOPPED; break;
      case 'H': axis_homed = 7; break;   // alle Achsen referenziert
      case 'N': axis_homed = 0; break;   // alle unreferenziert
      case 'Y': axis_homed = 1; break;   // nur X referenziert
      case 'W': axis_homed = 2; break;   // nur Y referenziert
    }
    const int sdn = card.open ? (card.paused ? 2 : 1) : 0;
    std::printf("reads=%d inj=%s sd=%d abort=%d silent=%d stopped=%d homed=%u cleared=%d flushpend=%d flushes=%d heaters=%d fans=%d quick=%d timer=%d purge=%d\n", sd_reads, inj.c_str(), sdn, (int)card.flag.abort_sd_printing, (int)sv04c11_sd_abort_silent, (int)IsStopped(), axis_homed, queue.cleared, (int)sv04c10_queue_flush_pending, queue.flushes, heaters_off, fans_zero, quickstops, timer_aborts, recovery_purges);
  }
}
