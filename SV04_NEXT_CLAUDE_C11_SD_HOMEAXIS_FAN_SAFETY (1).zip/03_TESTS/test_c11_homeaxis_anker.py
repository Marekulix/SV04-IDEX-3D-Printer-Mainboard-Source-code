"""SV04 NEXT C11 AP2 - STRUKTURELLE Textanker an der echten 318-motion.cpp (homeaxis) und LCD_RTS.cpp.
ACHTUNG: Das ist KEIN Laufzeittest und KEIN Beweis fuer das Verhalten von homeaxis(). Es prueft nur Reihenfolgen im Quelltext,
auf die sich die Sicherheitsaussagen in 08_AP2_HOMEAXIS_TESTGRENZE.md stuetzen. Die echte Funktion wurde NICHT ausgefuehrt (siehe dort)."""
import re, unittest
from pathlib import Path
IN = Path(__file__).resolve().parent / 'eingang/318'
M = (IN / 'motion.cpp').read_text(); L = (IN / 'LCD_RTS.cpp').read_text()
a = M.index('  void homeaxis(const AxisEnum axis) {'); b = M.index('  } // homeaxis()', a); H = M[a:b]

class HomeaxisAnker(unittest.TestCase):
    def test_A1_probe_deploy_and_bltouch_alarm_return_before_the_first_homing_move(self):
        first = H.index('do_homing_move(')
        self.assertLess(H.index('probe.deploy()'), first); self.assertLess(H.index('if (TERN0(BLTOUCH, bltouch.deploy())) return;'), first)
    def test_A2_cold_start_cap_is_applied_before_the_fast_move(self):
        self.assertLess(H.index('sv04c_zhome_limit('), H.index('do_homing_move(axis, move_length'))
    def test_A3_reference_completion_flags_come_after_the_last_homing_move_and_after_all_early_returns(self):
        i = H.index('sv04_p1_z_completed = axis_is_trusted(Z_AXIS);'); self.assertGreater(i, H.rindex('do_homing_move('))
        self.assertEqual([m.start() for m in re.finditer(r'\breturn;', H) if m.start() > i], [])
    def test_A4_stop_paths_inside_homeaxis_are_exactly_the_documented_ones(self):
        self.assertEqual(H.count('do_homing_move('), 14); self.assertEqual(H.count('kill('), 1)   # kill nur im DETECT_BROKEN_ENDSTOP-Zweig
        self.assertIn('#if ENABLED(DETECT_BROKEN_ENDSTOP)', H)
    def test_A5_display_code_never_checks_the_stopped_state(self):
        for w in ('IsStopped', 'marlin_state', 'R_MARLIN_STOPPED', 'IsRunning'): self.assertNotIn(w, L, w)
if __name__ == '__main__': unittest.main()
