# SV04 NEXT – Claude C11: SD-Druck nach Stopp, homeaxis-Testgrenze, Lüfter, DWIN-Schnittstelle

Stand 14.11.2026 · FLASH_ALLOWED=NO · HARDWARE_TESTED=NO · 309/318/C9/C10 unverändert (C11 ist ein weiterer Overlay-Patch auf der Kopie)
Nachweisstufen strikt getrennt: **programmiert / host-getestet / STM32-gebaut / hardwarebestätigt**. C11 ist **programmiert und host-getestet**. **STM32-gebaut: noch nicht** (das beweist erst der GitHub-Lauf mit `claude_c11_stm32_no_flash.yml`). Hardwarebestätigt: nein.

## 1. Kurzfassung

| AP | Ergebnis | Stufe |
|---|---|---|
| AP1 SD nach Stopp | **Echte Softwareverbesserung, 3 Dateien.** Im Stopp werden keine SD-Zeilen mehr gelesen; `M999` aus dem Stopp beendet einen laufenden/pausierten SD-Druck ohne das `G28XY` des OEM-Abbruchs; **jeder** SD-Abbruch (auch Display/Host) startet `G28XY` nur noch, wenn X und Y referenziert sind | programmiert + host-getestet (23 Tests, 126 060 Szenarien, 19 Mutanten getötet, 1 äquivalent) |
| AP2 echte `homeaxis()` | **Nicht ausgeführt.** Testgrenze begründet (`08_AP2_HOMEAXIS_TESTGRENZE.md`), 5 strukturelle Textanker, ausdrücklich kein Laufzeitbeweis | Quelltext-Lesung |
| AP3 Lüfter | **Keine Freigabe.** `M106`/`M107`-Quellen fehlen; Befunde aus Display- und Config-Dateien, gezielter Export im Workflow vorbereitet (`09_AP3_LUEFTER.md`) | Analyse, nichts geändert |
| AP4 Regression | C10-Tests unverändert 28/28 OK; C9-Verhalten, Whitelist, Queue-Verwerfung, Meldungen bleiben | host-getestet |
| AP5 DWIN | Schnittstellendokument mit Zeilen und nötigen Prüfungen; **Befund: das Display prüft den Stopp-Zustand nirgends** (`07_DWIN_SCHNITTSTELLE/`) | Quelltext-Lesung, ChatGPT-Dateien unverändert |

## 2. AP1 im Detail

Gelesen am echten Code (OEM `MarlinCore.cpp`/`queue.cpp`, 318 `LCD_RTS.cpp`):
* `stop()` setzt nur `MF_STOPPED`; `get_sdcard_commands()` liest danach weiter Zeilen. Die Befehle werden vom C10-Gate verweigert, aber die Datei läuft bis zum Ende, und `finishSDPrinting()` setzt `marlin_state = MF_RUNNING` **ohne** `M999`. Ob diese Kette im echten Gerät greift, ist ohne `cardreader.cpp` nicht belegt (offen, `06_OFFENE_PROBLEME_C11.md`).
* `abortSDPrinting()` injiziert immer `EVENT_GCODE_SD_ABORT` = `G28XY`. Nach einem `M999` aus dem Stopp (Achsen unreferenziert, C9) wäre das eine Referenzfahrt aus einem Sicherheitsstopp heraus.

Änderungen (Diffs in `02_PATCHES/diffs/`):
1. **queue.cpp** – `get_sdcard_commands()`: `if (IsStopped()) return;` vor `IS_SD_FETCHING()`. Schalter `SV04_CLAUDE_SD_FREEZE_WHEN_STOPPED` (Standard 1). +10 Zeilen, keine OEM-Zeile gelöscht.
2. **M999.cpp** – im C9-Stopp-Block: läuft oder pausiert ein SD-Druck, wird `card.flag.abort_sd_printing` gesetzt und ein stiller Merker gesetzt. Der Abbruch selbst läuft in `loop()` ausserhalb des Handlers (OEM-Ablauf, `abortSDPrinting()` → `queue.clear()`, Heizer aus, Lüfter 0, `recovery.purge()`). Schalter `SV04_CLAUDE_M999_SD_DISCARD` (Standard 1). +15 Zeilen.
3. **MarlinCore.cpp** – `abortSDPrinting()` injiziert `G28XY` nicht, wenn der Merker gesetzt ist (M999-Pfad) **oder X/Y nicht referenziert sind** (`axis_was_homed`, auch Display-/Host-Abbruch, Schalter `SV04_CLAUDE_SD_ABORT_NEEDS_XY_HOMED`, Standard 1; schliesst O6). Bei referenzierten X/Y bleibt der OEM-Abbruch unverändert. Der Merker wird danach zurückgesetzt. +15 Zeilen, eine OEM-Zeile ersetzt (die Inject-Zeile).

Bewusste Verhaltensänderungen (Entscheidung für Marek/ChatGPT, beide per Schalter rückgängig):
* **D1** `M999` (auch `M999 S1`) aus dem Stopp beendet jetzt einen SD-Druck. Hosts, die mit `M999 S1` einen Druck „fortsetzen“, setzen ihn nicht mehr fort. Gewollt: nach einem Stopp sind die Achsen ohnehin unreferenziert (C9).
* **D3** Ein SD-Abbruch bei unreferenzierten X/Y (Display, Host, M999) startet keine Referenzfahrt mehr. Wer nach dem Abbruch referenziert haben will, sendet `G28` selbst. Per `-DSV04_CLAUDE_SD_ABORT_NEEDS_XY_HOMED=0` zurück auf OEM.
* **D2** `recovery.purge()` im Abbruch löscht die Power-Loss-Wiederherstellungsdatei. Ein durch den Stopp unterbrochener Druck ist danach **nicht** mehr über „Fortsetzen nach Stromausfall“ wiederherstellbar. Der normale Stromausfall-Pfad (`PowerContinuePrintKey`) ist nicht verändert, aber nicht neu getestet.

Tests (`03_TESTS/test_c11.py`, Logs `04_ROHLOGS/`):
* Treiber kompiliert die **echten Funktionsköpfe** aus den gepatchten Dateien (`get_sdcard_commands`-Kopf, `GcodeSuite::M999`, `abortSDPrinting`), Attrappen nur für Karte, Warteschlange, Heizer.
* Voller Zustandsraum: Stopp {0,1} × SD {leer, druckt, pausiert} × `S` {0,1} × Befehlsfolgen (alle bis Länge 4 über {Fetch, M999, Loop, Benutzerabbruch, Stopp, alles-referenziert, nichts-referenziert, nur-X, nur-Y}, dazu alle der Länge 5 ohne Referenzbefehle) = 126 060 Fälle gegen ein unabhängiges Python-Modell. 0 Abweichungen.
* Negativkontrollen: Schalter aus → Datei wird im Stopp weitergelesen bzw. alter Druck läuft nach `M999` weiter; echte OEM-`abortSDPrinting` injiziert `G28XY` bedingungslos.
* Mutanten: 20, davon 19 getötet; 1 äquivalent (Prüfung hinter `IS_SD_FETCHING()` verschoben, 0 Abweichungen auf dem gesamten Gitter, `04_ROHLOGS/mutanten_c11.txt`). Dazu 1 Zusatzmutante (Stopp-Bedingung aus M999 entfernt) getötet. Eine Mutante („nur Y geprüft“) überlebte zuerst, weil das Gitter den Zustand „nur Y referenziert“ nicht erreichte; Zustand ergänzt, jetzt getötet.
* Annahme, die das Gerät noch bestätigen muss: Semantik von `IS_SD_PRINTING/IS_SD_FETCHING/IS_SD_PAUSED` wie im Upstream-Marlin; `cardreader.h` lag nicht vor.

## 3. Regression (AP4)
Die 28 C10-Tests laufen unverändert (eingebettet in `03_TESTS/regression_c10/`): 28/28 OK. Das C10-Gate, die Whitelist, die Queue-Verwerfung und die C9-Meldung sind nicht berührt; `gcode.cpp` wird von C11 nicht angefasst. Keine EEPROM-/DWIN-Dateien geändert. G28/G29 unverändert.

## 4. Fortschrittsfelder (nur mit Nachweis)
Unverändert: IDEX+BLTouch 88 %, G28 81 %, G29+Abbruch 75 %, M420 S1 97 %, M500 EEPROM 70 %, EEPROM-Rücklesung 60 %, Gesamt 78,5 %.
Begründung: C11 schließt ein Sicherheitsloch im Stopp-/SD-Verhalten (Host-Beweis), liegt aber ausserhalb der sechs Felder (kein Teil von G28/G29/M420/EEPROM-Funktion selbst) und ist weder gebaut noch am Gerät geprüft. Ob ein Feld dadurch steigt, entscheiden Marek/ChatGPT bei der Integration. Nicht erhöht wurde etwas durch Dokumente oder das ZIP.

## 5. Was als Nächstes belegt werden muss
1. GitHub-Lauf C11 (zwei Profile, Vergleich C10 gegen C11). Erst danach „STM32-gebaut“.
2. Export-Artefakt des Laufs liefert die fehlenden Quellen (`cardreader.cpp/.h`, `M106/M107`, Lüfter-/Temperaturcode, `Configuration*.h`, `platformio.ini`) → schließt AP3 und die cardreader-Annahme.
3. DWIN-Integration durch ChatGPT nach `07_DWIN_SCHNITTSTELLE/`.
4. Der Lauf liefert zusätzlich den Präprozessor-Auszug (`SV04_C11_PRAEPROZESSOR`) – Grundlage, um die echte `homeaxis()` in C12 mit belegter Makrolage auszuführen.
