# DWIN-Schnittstelle (für ChatGPT) – nötige Statusprüfungen vor direkten Aufrufen

Grundlage: 318 `LCD_RTS.cpp` (2932 Zeilen) gelesen; **keine Datei von ChatGPT wurde geändert.** Zeilen = 318-Stand.

## Zentraler Befund
`LCD_RTS.cpp` enthält **kein** `IsStopped`, `IsRunning`, `marlin_state` oder `R_MARLIN_STOPPED` (Test A5, host-geprüft als Textsuche). Das Display kennt den Stopp-Zustand nicht. Das C10-Gate und der C11-SD-Freeze wirken nur auf den G-Code-/Warteschlangenpfad. Direkte Aufrufe des Displays umgehen sie.

## Aufrufstellen, die den Stopp umgehen
| Aktion | Stelle | Wirkung im Stopp | Nötige Prüfung vor dem Aufruf |
|---|---|---|---|
| Manuelle Achsbewegung | `RTS_line_to_current()` Z. 102 (`planner.buffer_line`) | Bewegung wird geplant, Gate nicht beteiligt | `!IsStopped()` UND Achse referenziert/vertraut (`axis_was_homed`/`axis_is_trusted`) – sonst Bewegung verweigern + Meldung „Neustart/Referenzieren nötig“ |
| SD-Druck fortsetzen/starten | `card.startOrResumeFilePrinting()` Z. 978, 1006, 1123 | **C11:** im Stopp werden keine Zeilen gelesen (Druck passiert nicht), die Anzeige kann aber „druckt“ + Timer (`print_job_timer.start()`) zeigen | `!IsStopped()`; nach `M999` gilt ein SD-Druck als beendet (D1) – Fortsetzen-Taste darf dann nicht mehr angeboten werden; Auto60/Referenzstatus prüfen |
| Heizer einschalten | `setTargetHotend/Bed` mit Zielwert > 0: Z. 1231–1280, 1354–1358, 1900, 1922, 2642–2644 | Heizt im Stopp (Preheat, Filamentwechsel, Rücksynchronisierung des Zielwerts Z. 2640 ff.) | `!IsStopped()`; Ausschalten (Ziel 0, Z. 677–681, 1186–1219) darf immer gehen |
| Lüfter | `set_fan_speed(n, 255)` Z. 878–900 | schaltet im Stopp | siehe `09_AP3_LUEFTER.md`; bis zur Klärung: Einschalten nur bei `!IsStopped()`, Ausschalten nicht für den Hotend-Lüfter solange Hotend heiss |
| Referenzieren, Tool-Wechsel, Motoren aus | `enqueue_now_P("G28…"/"T0"/"T1"/"M84"/"M605"…)` (27 Strings, u. a. Z. 1304, 1323, 1470, 1475, 1595, 1725–1764, 1984–1994, 2149–2159) | **Vom C10-Gate verweigert** (host-getestet, Test G1015) – Anzeige darf aber nicht „läuft“ zeigen | `!IsStopped()` vor dem Absenden; sonst Meldung „STOPP: erst M999“ |
| Druck abbrechen | `card.flag.abort_sd_printing = true` Z. 670, 774; dazu `queue.clear()`, `quickstop_stepper()` Z. 777, 2038 | Läuft über OEM-`abortSDPrinting()`. **C11:** `G28XY` wird nur noch eingereiht, wenn X und Y referenziert sind (kein Referenzieren aus dem Stopp/unreferenziert mehr); im Stopp verweigert das Gate es ohnehin | Abbruch darf immer gehen. Nach dem Abbruch **nicht** annehmen, dass referenziert wurde: Anzeige „Achsen nicht referenziert“ zeigen, wenn sie es nicht sind |

## Was das Display bekommen sollte (Vorschlag, von ChatGPT zu bauen)
1. Eine einzige Prüfung `sv04_display_action_allowed(action)`, die `IsStopped()` und den Referenzstatus abfragt und bei Verweigerung eine Display-Meldung zeigt. Keine Änderung an G-Code-Pfad nötig, C10/C11 bleiben die zweite Sicherung.
2. Anzeige „STOPP – M999 oder Neustart nötig“ solange `IsStopped()`; danach „Achsen nicht referenziert“ (C9).
3. Nach einem `M999`-Abbruch des SD-Druckes (D1) den Druck-Zustand des Displays zurücksetzen (`sd_printing`, `PrintFlag`, `print_job_timer`), sonst bleibt der Druck-Bildschirm stehen.

## Nicht geprüft
Das Verhalten am echten Display, die Seitenwechsel und die Zustandsvariablen (`PrintFlag`, `pause_action_flag`) wurden nicht ausgeführt. Die DWIN-HMI-Abnahme bleibt BLOCKED.
