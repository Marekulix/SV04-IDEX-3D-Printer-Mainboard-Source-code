#!/usr/bin/env python3
"""SV04 NEXT C11 (SD-Druck nach Stopp) - drei Patches, SHA-gepinnt, idempotent, fail-closed.
Aufruf: apply_c11.py <baum>   (Baum = 318 + C9 + C10; 318/C9/C10 bleiben unberuehrt, es wird auf einer Kopie gearbeitet)
 queue.cpp      : im Stopp-Zustand keine SD-Zeilen nachladen (Pin C10-Endstand 5342ac2e...)
 M999.cpp       : M999 aus dem Stopp beendet einen laufenden/pausierten SD-Druck OHNE Ereignis-G-Code (Pin C10-Endstand 7aa10ae6...)
 MarlinCore.cpp : abortSDPrinting() injiziert EVENT_GCODE_SD_ABORT nicht, wenn der Abbruch von M999 kommt (Pin OEM 54d5b874...)
Fremder Hash / gemischter Stand / gepatcht-aber-veraendert -> Abbruch Exit 3, nichts wird geschrieben."""
import hashlib, pathlib, sys
PIN = {
 'Marlin/src/gcode/queue.cpp':        '5342ac2eea5e90edc13b59f98740b49f1d46dbab4f41896eb9e49b67a230b747',
 'Marlin/src/gcode/control/M999.cpp': '7aa10ae6e1fc111ee2a201c0e5539ab7f1fa09105222053158a8d9ee5be28775',
 'Marlin/src/MarlinCore.cpp':         '54d5b874ce9b72f5e3e6da92695f0a3cbb61f827803a1d1e89802d12e55bd076',
}
FINAL = {  # erwarteter Endstand
 'Marlin/src/gcode/queue.cpp': '61f0bb9d4a838148503a65af6d8dc2d7d12c3e28429ccc8bddb93f27c67cb9f4', 'Marlin/src/gcode/control/M999.cpp': '8bf97b97ca6ec2998c173a715876dcdf449a81dbb0c636545e12f6f73b8ee16c', 'Marlin/src/MarlinCore.cpp': '2703e63179de09c33eb8a817f1f39fe834bc6304d70e555dcba957531c8adb30',
}
SIG = {'Marlin/src/gcode/queue.cpp': 'SV04 NEXT C11 (sd freeze)', 'Marlin/src/gcode/control/M999.cpp': 'SV04 NEXT C11 (sd abort)', 'Marlin/src/MarlinCore.cpp': 'SV04 NEXT C11 (silent abort)'}
def sha(b): return hashlib.sha256(b).hexdigest()
def fail(m, rc=3): print('C11 FAIL:', m); sys.exit(rc)
def one(s, old, name):
    if s.count(old) != 1: fail(f'{name}: Anker {s.count(old)}x statt 1x')

Q_MACRO_OLD = 'bool sv04c10_queue_flush_pending = false;\n'
Q_MACRO_NEW = Q_MACRO_OLD + '''
// SV04 NEXT C11 (sd freeze): Im Stopp-Zustand werden keine SD-Zeilen nachgeladen. Sonst liest Marlin die Datei weiter (die Befehle
// werden zwar verweigert), erreicht das Dateiende und finishSDPrinting() setzt marlin_state auf MF_RUNNING - ohne M999.
#ifndef SV04_CLAUDE_SD_FREEZE_WHEN_STOPPED
  #define SV04_CLAUDE_SD_FREEZE_WHEN_STOPPED 1
#endif
'''
Q_FETCH_OLD = '    if (!IS_SD_FETCHING()) return;\n'
Q_FETCH_NEW = '''    // SV04 NEXT C11 (sd freeze)
    #if SV04_CLAUDE_SD_FREEZE_WHEN_STOPPED
      if (IsStopped()) return;
    #endif
    if (!IS_SD_FETCHING()) return;
'''
M_INC_OLD = '#include "../../module/motion.h" // SV04 NEXT C9: set_all_unhomed()\n'
M_INC_NEW = M_INC_OLD + '''
// SV04 NEXT C11 (sd abort): M999 aus dem Stopp beendet einen laufenden oder pausierten SD-Druck (kein altes Druckprogramm darf weiterlaufen).
#ifndef SV04_CLAUDE_M999_SD_DISCARD
  #define SV04_CLAUDE_M999_SD_DISCARD 1
#endif
#if ENABLED(SDSUPPORT)
  #include "../../sd/cardreader.h"
  extern bool sv04c11_sd_abort_silent;   // in MarlinCore.cpp definiert
#endif
'''
M_SET_OLD = '      sv04c10_queue_flush_pending = true;   // SV04 NEXT C10: bereits eingereihte Befehle verwerfen (in advance(), nicht hier)\n'
M_SET_NEW = M_SET_OLD + '''      #if ENABLED(SDSUPPORT) && SV04_CLAUDE_M999_SD_DISCARD
        if (IS_SD_PRINTING() || IS_SD_PAUSED()) {   // SV04 NEXT C11 (sd abort): Abbruch laeuft in loop() ausserhalb des Handlers (abortSDPrinting)
          sv04c11_sd_abort_silent = true;           // ohne EVENT_GCODE_SD_ABORT (G28XY bei unreferenzierten Achsen waere selbst ein Risiko)
          card.flag.abort_sd_printing = true;
        }
      #endif
'''
C_DEF_OLD = '#if ENABLED(SDSUPPORT)\n\n  inline void abortSDPrinting() {\n'
C_DEF_NEW = '''#if ENABLED(SDSUPPORT)

  // SV04 NEXT C11 (silent abort): von M999 gesetzt, hier verbraucht
  bool sv04c11_sd_abort_silent = false;

  // SV04 NEXT C11 (abort needs homed XY): EVENT_GCODE_SD_ABORT ("G28XY") nur, wenn X und Y referenziert sind. Sonst wuerde jeder Abbruch (auch am Display/Host) aus dem
  // unreferenzierten Zustand (nach Stopp/M999, Kaltstart) eine Referenzfahrt starten. Ausschalten: -DSV04_CLAUDE_SD_ABORT_NEEDS_XY_HOMED=0 (= OEM).
  #ifndef SV04_CLAUDE_SD_ABORT_NEEDS_XY_HOMED
    #define SV04_CLAUDE_SD_ABORT_NEEDS_XY_HOMED 1
  #endif
  #if SV04_CLAUDE_SD_ABORT_NEEDS_XY_HOMED
    #define SV04C11_ABORT_XY_OK() (axis_was_homed(X_AXIS) && axis_was_homed(Y_AXIS))
  #else
    #define SV04C11_ABORT_XY_OK() true
  #endif

  inline void abortSDPrinting() {
'''
C_INJ_OLD = '''    #ifdef EVENT_GCODE_SD_ABORT
      queue.inject_P(PSTR(EVENT_GCODE_SD_ABORT));
    #endif
'''
C_INJ_NEW = '''    #ifdef EVENT_GCODE_SD_ABORT
      if (!sv04c11_sd_abort_silent && SV04C11_ABORT_XY_OK()) queue.inject_P(PSTR(EVENT_GCODE_SD_ABORT));   // SV04 NEXT C11 (silent abort)
    #endif
    sv04c11_sd_abort_silent = false;
'''
EDITS = {
 'Marlin/src/gcode/queue.cpp': [(Q_MACRO_OLD, Q_MACRO_NEW), (Q_FETCH_OLD, Q_FETCH_NEW)],
 'Marlin/src/gcode/control/M999.cpp': [(M_INC_OLD, M_INC_NEW), (M_SET_OLD, M_SET_NEW)],
 'Marlin/src/MarlinCore.cpp': [(C_DEF_OLD, C_DEF_NEW), (C_INJ_OLD, C_INJ_NEW)],
}
def main():
    if len(sys.argv) != 2: fail('usage: apply_c11.py <baum>', 2)
    root = pathlib.Path(sys.argv[1]); state, texts = {}, {}
    for rel, pin in PIN.items():
        f = root / rel
        if not f.is_file(): fail(f'{rel} fehlt')
        b = f.read_bytes(); t = b.decode('utf-8'); texts[rel] = t
        if sha(b) == FINAL[rel]: state[rel] = 'ALREADY'; continue
        if SIG[rel] in t: fail(f'{rel}: enthaelt C11-Signatur, aber Hash {sha(b)} ist nicht der erwartete Endstand (veraendert oder gemischt)')
        if sha(b) != pin: fail(f'{rel}: fremder Hash {sha(b)} (erwartet {pin})')
        state[rel] = 'TODO'
    if len(set(state.values())) != 1: fail('gemischter Zustand: ' + str(state))
    new = {}
    for rel, st in state.items():
        if st == 'ALREADY': continue
        s = texts[rel]
        for old, _ in EDITS[rel]: one(s, old, rel)
        for old, nw in EDITS[rel]: s = s.replace(old, nw)
        new[rel] = s
    for rel, s in new.items(): (root / rel).write_text(s, encoding='utf-8')
    for rel in PIN: print(f'C11 {rel}: {"ALREADY" if state[rel]=="ALREADY" else "PATCHED"} sha256 {sha((root/rel).read_bytes())}')
if __name__ == '__main__': main()
