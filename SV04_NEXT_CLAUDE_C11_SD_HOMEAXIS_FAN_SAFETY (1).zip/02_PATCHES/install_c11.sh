#!/bin/sh
# Nutzung: install_c11.sh <Baum-318+C9+C10> <neuer-Baum>   (Original bleibt unberuehrt; kopiert und patcht die Kopie, fail-closed)
set -eu
[ $# -eq 2 ] || { echo "usage: $0 <baum> <neuer-baum>"; exit 2; }
[ ! -e "$2" ] || { echo "Ziel existiert schon: $2"; exit 2; }
cp -a "$1" "$2"
python3 -I "$(dirname "$0")/apply_c11.py" "$2" || { rc=$?; rm -rf "$2"; exit $rc; }
