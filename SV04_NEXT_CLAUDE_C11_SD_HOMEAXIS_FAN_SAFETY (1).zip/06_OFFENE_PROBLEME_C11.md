# Offene Probleme nach C11 (ehrlich getrennt)

| Nr | Problem | Einstufung | Weg |
|---|---|---|---|
| O1 | Display umgeht Gate und SD-Freeze an drei Aufrufklassen (Bewegung, SD-Fortsetzen, Heizen) und schaltet Lüfter | belegt (Quelltext) | ChatGPT, siehe `07_DWIN_SCHNITTSTELLE/` |
| O2 | Semantik von `IS_SD_PRINTING/FETCHING/PAUSED` und der `finishSDPrinting`→`MF_RUNNING`-Kette nur aus Upstream-Wissen angenommen | **unverifiziert**, `cardreader.*` fehlt | Export-Artefakt des Laufs |
| O3 | Echte `homeaxis()` nicht ausgeführt | Testgrenze | Der C11-Lauf liefert den Präprozessor-Auszug (`SV04_C11_PRAEPROZESSOR`) → C12 |
| O4 | Lüfter: Zuordnung Hotend-/Bauteillüfter und `M106/M107`-Code fehlen | offen | Export-Artefakt |
| O5 | `Configuration*.h`: Herkunft unverifiziert; der Workflow prüft die Blob-Hashes nicht-fatal | offen | Workflow-Schritt „config blob check“ |
| O6 | Display-Abbruch (`abort_sd_printing`) injizierte `G28XY` auch bei unreferenzierten Achsen | **geschlossen in C11** (host-getestet): `G28XY` nur noch bei referenziertem X und Y, ohne Änderung an `LCD_RTS.cpp`. Offen nur: am Gerät ungeprüft; die Display-Anzeige nach dem Abbruch liegt bei ChatGPT | – |
| O7 | D2: `recovery.purge()` löscht die Power-Loss-Datei beim Abbruch nach Stopp | bewusst, dokumentiert | Entscheidung Marek |
| O8 | T0/T1-Kollisionsabstände, 410 mm Z, BLTouch-Realverhalten, EEPROM am Gerät, DWIN-Abnahme | weiter gesperrt (keine Maße/Hardware) | – |
| O9 | Host-Harness: `ENABLED()` vereinfacht (`#define SDSUPPORT 1`, real leer-definiert); die echte Marlin-Makrokette wird erst im STM32-Build geprüft | bekannt | GitHub-Lauf |
