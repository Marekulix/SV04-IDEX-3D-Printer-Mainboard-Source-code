# GitHub-Lauf C11 (NO FLASH)
1. `SV04_NEXT_CLAUDE_C11_SD_HOMEAXIS_FAN_SAFETY.zip` und `claude_c11_stm32_no_flash.yml` zusammen mit den bisherigen Eingabedateien (C9-ZIP, C10-ZIP, 318-Übergabe) ins Repository, Workflow unter `.github/workflows/` ablegen, manuell starten (`workflow_dispatch`).
2. Jobs: `baseline_c10` (318 → C9 → C10, baut `oem_c10`, beide Profile, führt C9/C10-Tests aus), `c11_changes` (zusätzlich C11 → `oem_c11`, C11-Tests, Regression C10, beide Profile, Quellen-Export, Config-Blob-Prüfung, Präprozessor-Auszug – beide nicht-fatal), `evaluate_builds` (nur grün bei 4/4 PASS).
3. Artefakte: `SV04_C11_BASELINE_C10_STM32_LOGS_NO_FLASH`, `SV04_C11_CHANGED_STM32_LOGS_NO_FLASH`, `SV04_C11_QUELLEN_EXPORT`, `SV04_C11_PRAEPROZESSOR`, `SV04_C11_EVALUATION`. Bitte alle fünf zurückgeben.
4. „STM32-gebaut“ gilt erst bei Exit 0 + `[SUCCESS]` + RAM/Flash-Zeilen je Profil. Das ZIP-Hash ist im Workflow fest eingetragen; das ZIP darf nicht neu gepackt werden.
