# AP3 – Lüfter `M106`/`M107`: Stand und Entscheidung

**Entscheidung: keine Freigabe, nichts geändert.** `M106.cpp`/`M107.cpp` (Marlin: `gcode/temp/M106_M107.cpp`), `thermalManager`-Lüfterteil und `cardreader` liegen nicht vor. Eine Freigabe im Stopp-Zustand wäre ohne diesen Code geraten.

## Belegt aus den vorhandenen Dateien
* C10-Whitelist erlaubt im Stopp **kein** `M106/M107` (Header `sv04_claude_stopgate.h`); beide werden verweigert (fail-closed, aus C10 host-getestet).
* `abortSDPrinting()` ruft `thermalManager.zero_fan_speeds()` (MarlinCore.cpp Z. 357, `HAS_CUTTER` aus) – Lüfter gehen bei jedem SD-Abbruch auf 0, auch beim stillen C11-Abbruch (Test S1107: `fans=1`).
* Display (318 `LCD_RTS.cpp`): Lüfter 0 und 1 werden direkt über `thermalManager.set_fan_speed(n, 0|255)` geschaltet (Z. 878–900), `zero_fan_speeds()` Z. 683, `set_fan_speed(…,0)` Z. 368–369. Das umgeht das G-Code-Gate.
* Config (**Herkunft unverifiziert**): `NUM_M106_FANS 2`, `E0_AUTO_FAN_PIN`…`E7_AUTO_FAN_PIN` = −1, `CONTROLLERFAN_SPEED_ACTIVE 255`.

## Nicht belegt (offen)
* Welcher physische Lüfter an welchem Index hängt, ob einer davon die Hotend-Kühlung (Heatbreak) ist, und ob `M106 P1`/`M107` diesen abschalten kann. Das ist die sicherheitsrelevante Frage: **Abschalten** der Hotend-Kühlung bei heissem Hotend ist gefährlich, Abschalten des Bauteillüfters nicht.
* Welche `M106`-Parameter geprüft werden müssten (`P`, `S`, `T`).

## Klassifizierung (vorläufig, bis Quellen da sind)
| Befehl im Stopp | Bewertung | Status |
|---|---|---|
| `M107` ohne Parameter | potenziell harmlos, falls alle Lüfter „aus“ unkritisch sind – wegen Heatbreak-Frage **nicht freigegeben** | gesperrt |
| `M106 S0 P<n>` | wie oben, nur für Bauteillüfter harmlos | gesperrt |
| `M106 S>0` | Einschalten wäre unkritisch, solange keine Bewegung/Heizung daran hängt – ohne Code nicht belegt | gesperrt |
| Display-Lüfterschalter | umgeht das Gate | Hinweis an ChatGPT |

## Vorbereitung
Der C11-Workflow lädt `M106_M107.cpp`, `temperature.cpp/.h` (Lüfteranteil), `cardreader.cpp/.h`, `Configuration.h`, `Configuration_adv.h`, `platformio.ini` und die Pins-Datei als Artefakt `SV04_C11_QUELLEN_EXPORT` hoch. Mit diesem Export kann C12 die Lüfterfreigabe tatsächlich belegen (z. B. nur `M107` und `M106 S0` für den Bauteillüfter-Index, falls die Hotend-Lüfter-Zuordnung geklärt ist).
