# AP2 – echte `homeaxis()` im Host-Test: Testgrenze (nichts ausgeführt)

**Ergebnis: Die echte `homeaxis()` wurde in C11 NICHT ausgeführt.** Es gibt keinen Szenarientest dafür. Ein vereinfachter Stub wäre ein Scheinbeweis und wurde bewusst nicht gebaut.

## Warum nicht
* `homeaxis()` (318 `motion.cpp` Z. 1753–2097, ca. 345 Zeilen) besteht fast vollständig aus Marlin-Makrozweigen (`HOMING_Z_WITH_PROBE`, `DUAL_X_CARRIAGE`, `HAS_EXTRA_ENDSTOPS`, `*_SENSORLESS`, `*_HOME_TO_MIN/MAX`, `BLTOUCH_SLOW_MODE` …). Welche davon gelten, entsteht in `Conditionals_post.h`/Pins-Dateien aus `Configuration*.h`. Diese Ableitungskette, die Pins-Datei und `platformio.ini` liegen nicht vor; `Configuration*.h` hat nur eine **unverifizierte** Herkunft. Eine handgebaute Makrolage könnte von dem abweichen, was der Compiler wirklich sieht.
* Die Funktion ruft `probe.deploy()`, `bltouch.deploy/stow()`, `endstops.state()`, `do_homing_move()` (selbst mit Planner/Stepper), `stepper.set_*_lock()`, `kill()`. Die Ausgänge dieser Aufrufe wären erfunden.

## Was stattdessen belegt ist (Quelltext, `test_c11_homeaxis_anker.py`, 5/5 – strukturell)
* A1 `probe.deploy()` und die BLTouch-Alarmabfrage mit `return` stehen **vor** der ersten Referenzfahrt (Z. 1783/1802).
* A2 die C5-Kaltstart-Kappe (`sv04c_zhome_limit`) wird **vor** der schnellen Fahrt angewendet (Z. 1832).
* A3 die Referenz-Abschlussflags (`sv04_p1_*_completed`, Z. 2091–2093) stehen **nach** der letzten Fahrt und nach allen frühen `return`.
* A4 im Funktionskörper steht genau ein `kill()` (nur im `DETECT_BROKEN_ENDSTOP`-Zweig).
* A5 `LCD_RTS.cpp` (318) enthält weder `IsStopped`, `IsRunning`, `marlin_state` noch `R_MARLIN_STOPPED`.
Das sind Reihenfolgen im Text, **kein** Verhaltensbeweis.

## Die zehn Szenarien – Stand
| Nr | Szenario | Stand |
|---|---|---|
| 1 | Kaltstart, Z unbekannt | C5-Kappe im Text (Z. 1832), Berechnung selbst in C5-Tests host-geprüft; `homeaxis()` nicht ausgeführt |
| 2 | BLTouch-Alarm | OEM `bltouch.cpp:101–113` → `stop()`; mit C10/C11 danach: Gate + SD-Freeze host-getestet; Ablauf in `homeaxis()` nicht ausgeführt |
| 3 | BLTouch fährt nicht aus | wie 2 (`bltouch.deploy()` liefert Fehler → `return`, Z. 1802); nicht ausgeführt |
| 4 | BLTouch fährt nicht ein | OEM `bltouch.cpp:155–156` → `stop()`; nicht ausgeführt |
| 5 | Endstop-Signal fehlt | Nur `DETECT_BROKEN_ENDSTOP` führt zu `kill()`; ob in der Config aktiv: **offen** (Config unverifiziert). Sonst läuft die Fahrt bis zur Streckengrenze |
| 6 | Z-Homing bei unbekannter Referenz | Streckenbegrenzung nur durch C5; keine Kollisionsfreigabe, 410 mm bleiben gesperrt |
| 7 | Abbruch beim Referenzieren | `M112/M410` gehören zur Whitelist (C10); Verhalten des Steppers beim Abbruch nicht ausgeführt |
| 8 | G28 nach M999 | C9 setzt „unreferenziert“, C10-Gate blockiert nur im Stopp; **host-getestet** am echten M999/Gate, `homeaxis()` selbst nicht |
| 9 | T0/T1 beim Referenzieren | `active_extruder` fliesst in die X-Richtung ein (Z. ~1778) und in die Abschlussflags; nicht ausgeführt |
| 10 | Übergabe der Referenz an Auto60 | Abschlussflags (A3) + C9-Auto60-Sperre aus C9/C10-Tests; Ende-zu-Ende nicht ausgeführt |

## Was nötig wäre
Die tatsächlich wirksamen Makros aus dem echten Build. Der C11-Workflow erzeugt sie jetzt (`pio -t compiledb`, danach `-E` und `-E -dM` mit dem echten Compiler-Aufruf für `motion.cpp`, `G28.cpp`, `bltouch.cpp`, `probe.cpp`, `endstops.cpp`, `queue.cpp`, `MarlinCore.cpp`, `M999.cpp`) und lädt sie als Artefakt `SV04_C11_PRAEPROZESSOR` hoch. Der Schritt ist nicht-fatal und **noch nicht gelaufen**; ob er funktioniert, zeigt erst der Lauf. Daraus lässt sich in C12 eine belegte Makrolage für einen `homeaxis()`-Harness ableiten.
