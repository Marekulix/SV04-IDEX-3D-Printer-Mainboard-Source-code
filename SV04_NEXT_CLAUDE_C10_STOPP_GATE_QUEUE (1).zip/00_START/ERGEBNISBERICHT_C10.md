# SV04 NEXT – Claude C10: Stopp-Gate, Warteschlange verwerfen, Berichtigung C9

Stand 13.11.2026 · Basis: 318 (unverändert) + C9 (unverändert) · **Nichts gebaut, nichts geflasht, keine Hardwarefreigabe.** C10 ist eine Overlay-Version auf C9.

> **Kurzfassung:** C10 ändert **drei** Dateien (`gcode.cpp` +Gate, `queue.cpp` +Verwerfen, `M999.cpp` +Flag) und fügt **eine** Header-Datei hinzu. Alles im Host-Test an echten Dateiauszügen belegt (28 Tests, 0 überlebende Mutanten). **Der STM32-Build steht aus**; der Workflow liegt bei. Nicht gelöst: der Display umgeht das Gate an drei Stellen (Abschnitt 4), das ist ChatGPTs Bereich.

## 1. Entscheidungen (aus „AN_CLAUDE_C10_FREIGABE_UND_BELEGSTATUS.txt“) und Umsetzung

| Entscheidung | Umsetzung | Beleg |
|---|---|---|
| AP1 Stopp-Whitelist, **M84 nicht erlaubt** | im Stopp erlaubt: `M999 M112 M108 M410`, Statuslesungen `M105 M114 M115 M119 M503` (nur ohne Parameter), Heizer AUS `M104 S0 [T<n>]`, `M140 S0`. **Alles andere verweigert** (G28, G29, T, alle Bewegungen, Heizen > 0, M84/M17/M18, EEPROM M500–M504, M24, M1060 …) | G1001–G1003, G1010–G1012, G1015 |
| Lüfter M106/M107 „nur ohne Nebenwirkungen“ | **nicht erlaubt**: die Handler `M106.cpp`/`M107.cpp` liegen nicht vor, Nebenwirkungsfreiheit ist nicht belegt | Whitelist-Test (M106/M107 in `DENY`) |
| Parser zweifelsfrei, kein Freigeben über Alias | Befehlstext wird **unabhängig** vom Marlin-Parser gelesen; Buchstabe, Nummer und Unterbefehl müssen mit dem Parser übereinstimmen, sonst verweigert. Unterbefehle (`M104.1`), fehlende Leerzeichen (`M104S0`), führende Nullen, Kleinbuchstaben, doppelte Parameter, 5+ Ziffern: verweigert | G1002 (Differentialtest, 39 508 Eingaben gegen unabhängiges Python-Modell), G1003 |
| Kein Freigeben über Queue oder Display | Das Gate sitzt in `process_parsed_command`, also auch für Warteschlange, SD, Makros und `enqueue_now_P`. **Grenze:** direkte Aufrufe ohne G-Code umgehen es (Abschnitt 4) | G1010, G1015 |
| `M999` verwirft Queue sicher | Flag in `M999` (nur aus dem Stopp-Zustand, mit und ohne `S1`), Leeren in `advance()` **nach** dem Entnehmen des Befehls; auch der Rest eines injizierten Makros wird verworfen | Q1001–Q1007 |
| Not-Aus und Heizer-AUS nicht blockieren | `M112`, `M108`, `M410`, `M104 S0`, `M140 S0` erlaubt | Whitelist-Test, G1011 |
| AP3 Display verweigert im Stopp, **Variante (a)** | Alle G-Code-Befehle, die das Display per `enqueue_now_P` sendet, werden im Stopp verweigert. **Kein** automatisches `M999`. **Nicht** in `LCD_RTS.cpp` geändert (siehe Abschnitt 4) | G1015 (alle 27 verschiedenen Befehle aus der echten 318-`LCD_RTS.cpp`) |
| AP2/5 | umgesetzt (Warteschlange, Tests, Mutanten, Workflow) | |
| **AP4 echte `homeaxis()`** | **NICHT umgesetzt**, siehe Abschnitt 6 | |
| C9-Bericht korrigieren | siehe Abschnitt 2 | |

## 2. Korrekturen am C9-Bericht (neu nachgewiesen)

1. C9 behauptete, Marlin lehne nach dem Stopp G0–G5 ab (`queue.cpp:509`). **Falsch eingeordnet:** `queue.cpp` gibt dort nur eine Meldung aus. Abgelehnt wird in einzelnen Handlern (`G0_G1.cpp:51` mit `IsRunning()`; `G5.cpp` und `G42.cpp` binden `MarlinCore.h` laut Kommentar „for IsRunning()“ ein; `MOTION_CONDITIONS` in `motion.h:431`; Quelle: `stopp_pruefungen_318.txt`, die Nutzer von `MOTION_CONDITIONS` wurden nicht einzeln gesucht). In `G28.cpp`, `T.cpp`, `gcode.cpp` und in keinem der M-Code-Handler steht nach dieser Liste eine Prüfung auf `IsRunning`/`IsStopped`; für G29 ergänzte erst C5 eine.
2. C9 nannte nur `M999 S1` als Restrisiko für eingereihte Befehle. **Auch ohne `S1`** bleibt die Warteschlange (OEM-`M999` leert nur den seriellen Puffer, `queue.cpp:274–282`). C10 schließt beides.
3. Der in C9 vorgeschlagene Ausblick „Sonde schon ausgelöst vorab prüfen“ entfällt: `bltouch.cpp:101–113` prüft den Alarm beim Ausfahren und ruft `stop()`; `homeaxis()` fährt die Sonde vorher aus (`motion.cpp:1783`).
4. `tool_change.cpp:858/1194`: Die Bewegung des Werkzeugwechsels ist an `IsRunning()` gebunden; ob sich der Werkzeugzustand im Stopp trotzdem ändert, ist nicht geprüft. Das Gate verweigert `T0/T1` im Stopp jetzt komplett.

## 3. Änderungen im Einzelnen

* `gcode.cpp` (318-Stand, Pin `12958700…`): `#include "sv04_claude_stopgate.h"` und ein Block vor dem Dispatcher. Verweigerter Befehl: Meldung (höchstens alle 2 s, `echo:`, damit Hosts nicht abbrechen), `ok` wie bei jedem Befehl, Rückkehr vor dem Dispatcher. Nicht im Stopp: **keine** Wirkung.
* `queue.cpp` (OEM-Stand, Pin `d5cdca65…`): Flag `sv04c10_queue_flush_pending`; in `advance()` am Anfang (falls `M999` über den Injektionspfad kam) und **nach** `advance_pos(index_r,-1)` (sonst Unterlauf des `uint8_t`-Zählers; Negativkontrolle Q1005 zeigt 255).
* `M999.cpp` (C9-Stand, Pin `cbaca8b8…`): setzt das Flag **innerhalb** des C9-Blocks. Ohne den C9-Schalter (`SV04_CLAUDE_M999_REHOME_REQUIRED=0`) ist auch das Verwerfen aus (Test M1002).
* neu `sv04_claude_stopgate.h`: reine Entscheidungsfunktion, keine Marlin-Abhängigkeit.
* Schalter: `SV04_CLAUDE_STOPP_GATE` (1) und `SV04_CLAUDE_M999_QUEUE_FLUSH` (1); jeweils 0 = Verhalten wie C9.
* Es wird **keine** OEM-Zeile gelöscht (Tests P1006, Q1006).

## 4. Display-Umgehungen (nur in `LCD_RTS.cpp` lösbar, ChatGPTs Bereich)

Das Gate sieht nur G-Code. Die echte 318-`LCD_RTS.cpp` ruft an diesen Stellen **direkt** auf:

| Stelle (Zeile in der 318-Datei) | Wirkung im Stopp |
|---|---|
| `RTS_line_to_current()` → `planner.buffer_line` (Z. 102) | manuelle Achsbewegung („Jog“) am Display |
| `card.startOrResumeFilePrinting()` (Z. 978, 1006, 1123) | SD-Druck am Display fortsetzen |
| `thermalManager.setTargetHotend/Bed(…)` mit Zielwert ungleich 0 (Z. 1231–1280, 1354–1358, 1900, 1922, 2642–2644) | Heizen am Display |

Vorschlag für die Schnittstelle: Vor diesen Aufrufen `if (IsStopped()) { Meldung "Neustart erforderlich"; return; }`. `IsStopped()` ist aus `MarlinCore.h` bekannt (dort bereits in `sv04_claude_auto60_marlin.inc` genutzt). Das ändert DWIN-Verhalten und ist **nicht** umgesetzt; ChatGPT entscheidet nach Schnittstellenprüfung. Bis dahin gilt: **C10 allein macht das Display im Stopp nicht vollständig sicher.**

## 5. Belege (Host-Test, kein STM32, keine Hardware)

28 Tests (Rohlog `04_ROHLOGS/test_c10.log`), alle bestanden:
* Gate: Tabelle (20 erlaubt, 78 verweigert), Differentialtest 39 508 Eingaben gegen ein unabhängiges Python-Modell, Parser-Widerspruch, **echter Kopf von `process_parsed_command`** aus der gepatchten `gcode.cpp`, alle Display-Befehle der echten 318-`LCD_RTS.cpp`.
* Warteschlange: **echter `RingBuffer`** aus `queue.h` und **echte `advance()`** aus der gepatchten `queue.cpp`; voller Zustandsraum für 4, 5, 8, 16 Pufferplätze (alle Leseposition × Füllstand × Position von `M999`) plus Injektionspfad plus Makro-Rest; Negativkontrollen (OEM: Befehle laufen weiter; Löschen im Handler: Zähler 255).
* `M999.cpp` (echte gepatchte Datei, Attrappen): Flag nur nach Stopp, mit/ohne `S1`.
* Patch-Skript: Pins, idempotent, fremder/gemischter/veränderter Stand bricht ab, nichts wird geschrieben.
* Mutanten: 28 Gate-Mutanten (davon 3 begründet äquivalent: doppelt abgesicherte Prüfungen, auf dem ganzen Korpus gleiche Antwort nachgewiesen), 4 Queue-Mutanten; **0 überlebende**.
* **Nicht** getestet: die STM32-Übersetzung, das Verhalten im echten Firmwareablauf, jede Hardware.

## 6. Nicht umgesetzt: AP4 (echte `homeaxis()`-Tests)

Die echte `homeaxis()` aus `motion.cpp` (≈ 300 Zeilen, durchsetzt mit Konfigurationsmakros, Sonde, Endstops, Planer) lässt sich nicht ehrlich mit wenigen Attrappen ausführen; ein halber Aufbau würde wieder nur ein Modell liefern. Ich habe ihn deshalb **nicht** als erledigt gemeldet. Vorschlag: eigener Auftrag mit der Konfiguration (`Configuration.h`, `Configuration_adv.h` aus dem 318-Baum) als Eingabe.

## 7. Fortschritt vorher/nachher

IDEX+BLTouch 88 % · G28 81 % · G29+Abbruch 75 % · M420 S1 97 % · M500 EEPROM 70 % · EEPROM-Rücklesung 60 % · **Gesamt 78,5 % – unverändert.** Begründung: Es liegt kein Build und kein Gerätenachweis für C10 vor; die Host-Tests belegen die Logik, nicht die Firmware.
