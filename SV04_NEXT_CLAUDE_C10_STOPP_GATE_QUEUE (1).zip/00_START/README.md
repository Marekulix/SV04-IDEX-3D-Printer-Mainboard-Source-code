# SV04 NEXT – Claude C10 (Stopp-Gate, Warteschlange verwerfen)
Lies zuerst `ERGEBNISBERICHT_C10.md`, dann `../06_RISIKEN_C10.md`.
* `01_QUELLEN/neu` – neue Header-Datei `sv04_claude_stopgate.h`; `01_QUELLEN/geaendert` – die drei geänderten Dateien (Endstand).
* `02_PATCHES/apply_c10.py` – gepinnter, idempotenter, fail-closed Patch (Aufruf: `apply_c10.py <baum>`); `diffs/` – Unterschiede.
* `03_TESTS/test_c10.py` – 28 Host-Tests (g++ nötig), `eingang/` – die gepinnten Eingangsdateien, `cpp/` – Treiber.
* `04_ROHLOGS` – echter Testlauf. `05_WORKFLOW/AUSFUEHRUNG_GITHUB.md` – GitHub-Lauf.
Keine Flash-Freigabe, keine Hardwarefreigabe. 309, 318 und C9 sind unverändert.
