# GitHub-Lauf C10 (nur Build, kein Flash)

1. Im Repository-Hauptverzeichnis liegen: `SV04_NEXT_318_GITHUB_UPLOAD_06.zip`, `SV04_NEXT_CLAUDE_C9_IDEX_BLTOUCH_G28_ABSCHLUSS.zip` (unverändert, liefert Installer, C9-Patch und Auswertung) und neu `SV04_NEXT_CLAUDE_C10_STOPP_GATE_QUEUE.zip`.
2. Workflow `claude_c10_stm32_no_flash.yml` unter `.github/workflows/` ablegen und manuell starten.
3. Der Lauf baut zwei Bäume, je beide Profile: `oem_c9` (318 + C9, Vergleichsbasis) und `oem_c10` (C9 + C10). Dazu laufen die C10-Host-Tests auf dem Runner. Die Auswertung ist rot, solange nicht alle vier Kombinationen belegt bestehen.
4. Mir schicken: `SV04_C10_EVALUATION`, `SV04_C10_BASELINE_C9_STM32_LOGS_NO_FLASH`, `SV04_C10_CHANGED_STM32_LOGS_NO_FLASH`.
Erwartung (nicht Beleg): Baseline-Größen wie im C9-Lauf (Backend 177788 B Flash, Failclosed 176540 B). Alles Weitere zeigt erst der Lauf.
