#!/usr/bin/env python3
"""Stage 81: validate REAL patched Marlin tree, no mocked verification.

Only the changed firmware translation units are audited. Return nonzero on any
missing local include, malformed git diff, or missing trace of stages 62-79.
"""
import argparse,hashlib,json,re,subprocess
from pathlib import Path

G29=Path('Marlin/src/gcode/bedlevel/abl/G29.cpp')
RTS=Path('Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp')
BASE='1867fcba75354a5c65e0631d6972dd19f1bd6cbe'
REQUIRED={G29:['SV04NEXT62 DIAG READONLY','SV04 NEXT 79'],
          RTS:['SV04NextGuard62.h','SV04NextHmiGate78.hpp','SV04NextUnified79.hpp']}

class VerificationFailure(Exception): pass

def verify(root):
    root=Path(root).resolve()
    if not (root/'platformio.ini').is_file():
        raise VerificationFailure('missing platformio.ini')
    proc=subprocess.run(['git','rev-parse','HEAD'],cwd=root,text=True,capture_output=True)
    if proc.returncode or proc.stdout.strip()!=BASE:
        raise VerificationFailure('unexpected OEM base revision')
    check=subprocess.run(['git','diff','--check'],cwd=root,text=True,capture_output=True)
    if check.returncode:
        raise VerificationFailure('git diff --check: '+(check.stdout+check.stderr).strip())
    checked=[]; includes=[]
    visited=set()
    feature=root/'Marlin/src/feature'
    def walk_local_includes(path):
        path=Path(path).resolve()
        if path in visited:return
        visited.add(path)
        try: content=path.read_text(encoding='utf-8')
        except UnicodeDecodeError as exc:
            raise VerificationFailure('non-UTF8 integrated file: '+str(path)) from exc
        for inc in re.findall(r'^\s*#include\s+"([^"\n]+)"',content,re.MULTILINE):
            target=(path.parent/inc).resolve()
            if not target.is_file() and inc.startswith('SV04Next'):
                target=(feature/inc).resolve()
            if not target.is_relative_to(root):
                raise VerificationFailure('include escapes repository: '+inc)
            if not target.is_file():
                raise VerificationFailure('missing source include: '+str(path.relative_to(root))+' -> '+inc)
            includes.append(str(target.relative_to(root)))
            if target.name.startswith('SV04Next'):
                walk_local_includes(target)
    for rel, markers in REQUIRED.items():
        f=root/rel
        if not f.is_file():raise VerificationFailure('missing firmware source: '+str(rel))
        content=f.read_text(encoding='utf-8')
        for marker in markers:
            if marker not in content:
                raise VerificationFailure('missing integration marker '+marker+' in '+str(rel))
        walk_local_includes(f)
        checked.append(str(rel))
    for special in ['Marlin/src/feature/SV04NextGuard62.h',
                    'Marlin/src/feature/SV04NextUnified79.hpp',
                    'Marlin/src/feature/SV04NextHmiGate78.hpp']:
        if not (root/special).is_file():
            raise VerificationFailure('missing added header: '+special)
    for header in sorted(feature.glob('SV04Next*.h*')):
        if header.is_file():walk_local_includes(header)
    changes=subprocess.run(['git','status','--porcelain','--untracked-files=all'],cwd=root,text=True,capture_output=True,check=True).stdout
    if not changes.strip():
        raise VerificationFailure('source checkout contains no applied changes')
    result={'stage':81,'scope':'POINT_1_MARLIN_ONLY','oem_commit':BASE,
        'diff_whitespace_clean':True,'checked_translation_units':checked,
        'resolved_relative_includes':sorted(set(includes)),
        'modified_and_added_entries':len(changes.splitlines()),
        'verification_passed':True,'stm32_build_confirmed':False}
    return result

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--out',required=True)
    a=p.parse_args()
    result=verify(a.root)
    dest=Path(a.out);dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
