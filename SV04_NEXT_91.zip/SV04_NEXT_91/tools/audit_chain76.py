#!/usr/bin/env python3
"""Static evidence audit of a fully applied SV04 NEXT 76 source tree.
Not a hardware test or a proof of binary compilation.
"""
from pathlib import Path
import argparse,hashlib,json
DWIN=Path('Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp')
G29=Path('Marlin/src/gcode/bedlevel/abl/G29.cpp')
FEATURE=Path('Marlin/src/feature')
STAGES=(62,65,66,67,68,70,72,73,74,75,76)
HEADERS=('SV04NextGuard62.h','SV04NextSafety65.hpp','SV04NextAudit66.hpp',
'SV04NextDwinContract67.hpp','SV04NextDwinRenderer68.hpp',
'SV04NextDwinPresenter70.hpp','SV04NextDwinWire72.hpp',
'SV04NextDwinBridge73.hpp','SV04NextDwinAtomic74.hpp',
'SV04NextDwinDelivery75.hpp','SV04NextIntegration76.hpp')

def audit(root):
 root=Path(root);fail=[];sha={}
 for fn in (DWIN,G29):
  p=root/fn
  if not p.is_file():fail.append('missing '+str(fn));continue
  sha[str(fn)]=hashlib.sha256(p.read_bytes()).hexdigest()
 for fn in HEADERS:
  p=root/FEATURE/fn
  if not p.is_file():fail.append('missing '+fn);continue
  sha[str(FEATURE/fn)]=hashlib.sha256(p.read_bytes()).hexdigest()
 if not (root/'platformio.ini').is_file():fail.append('platformio.ini missing')
 if (root/DWIN).is_file():
  s=(root/DWIN).read_text()
  for fn in HEADERS:
   if fn=='SV04NextDwinWire72.hpp':continue # included transitively
   if s.count('#include "../../../feature/'+fn+'"')!=1:fail.append('DWIN include count !=1: '+fn)
  if s.count('sv04next75::update(sv04_dwin70,')!=1:fail.append('expected one stage75 update')
  if s.count('sv04next73::MAPPING_CONFIRMED')!=1:fail.append('expected one HMI gate')
  if s.count('SV04 NEXT 68: render valid 4x4 OEM mesh')!=1:fail.append('DWIN original result hook mismatch')
  if s.count('sv04next70::Presenter sv04_dwin70')!=1:fail.append('presenter should be singular')
  if s.count('SV04NextIntegration76.hpp')!=1:fail.append('stage76 guard missing')
 if (root/FEATURE/'SV04NextDwinBridge73.hpp').exists():
  s=(root/FEATURE/'SV04NextDwinBridge73.hpp').read_text()
  if 'MAPPING_CONFIRMED=false' not in s or 'MAPPING_CONFIRMED=true' in s:fail.append('HMI mapping must stay locked')
 if (root/G29).is_file():
  s=(root/G29).read_text()
  if s.count('SV04NEXT62 DIAG READONLY')!=1:fail.append('G29 diagnostic marker mismatch')
  if 'SV04NEXT67 DIAG' not in s:fail.append('G29 stage67 marker missing')
 result={'pass':not fail,'failures':fail,'stages':list(STAGES),'files_sha256':sha,
         'new_hmi_pages':0,'known_vp_overlap':'0x110E','hmi_mapping_confirmed':False,
         'hardware_build_verified':False,'flash_approved':False}
 return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--report',required=True);a=p.parse_args()
 r=audit(a.root);Path(a.report).write_text(json.dumps(r,indent=2)+'\n');print('PASS' if r['pass'] else 'REFUSED: '+', '.join(r['failures']))
 raise SystemExit(0 if r['pass'] else 1)
