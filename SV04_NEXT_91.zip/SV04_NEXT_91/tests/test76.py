import unittest,subprocess,tempfile,sys
from pathlib import Path
P=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(P/'tools'))
from apply76 import apply,RTS,HDR
from audit_chain76 import audit,HEADERS,FEATURE,G29

class Integration76(unittest.TestCase):
 def fixture(self,r):
  (r/'platformio.ini').write_text('[platformio]\n')
  f=r/RTS;f.parent.mkdir(parents=True)
  f.write_text('#include "../../../feature/SV04NextDwinDelivery75.hpp"\n'
    '// SV04 NEXT 68: render valid 4x4 OEM mesh\n'
    'static sv04next70::Presenter sv04_dwin70;\n'
    'sv04next75::update(sv04_dwin70, get, [](uint16_t vp,int16_t z)->bool { rtscheck.RTS_SndData((int)z,vp); return true; }, millis(),true,sv04next73::MAPPING_CONFIRMED);\n')
  d=r/FEATURE;d.mkdir(parents=True,exist_ok=True)
  for h in HEADERS[:-1]:
   (d/h).write_text('static constexpr bool MAPPING_CONFIRMED=false;' if h=='SV04NextDwinBridge73.hpp' else '// '+h)
  g=r/G29;g.parent.mkdir(parents=True)
  g.write_text('SV04NEXT62 DIAG READONLY\nSV04NEXT67 DIAG\n')
  return f
 def test_host_cpp(self):
  with tempfile.TemporaryDirectory() as d:
   exe=Path(d)/'a'
   q=subprocess.run(['g++','-std=c++11','-Wall','-Wextra','-Werror','-pedantic',str(P/'tests/driver76.cpp'),'-o',str(exe)],capture_output=True,text=True)
   self.assertEqual(q.returncode,0,q.stderr)
   r=subprocess.run([str(exe)],capture_output=True,text=True)
   self.assertEqual(r.returncode,0,r.stderr);self.assertIn('SV04NEXT76_GATES_OK',r.stdout)
 def test_compile_time_denials(self):
  for flag in ['SV04_NEXT_AUTO60_RELEASE','SV04_NEXT_DWIN_TOUCH_RELEASE','SV04_NEXT_T1_MOTION_RELEASE','SV04_NEXT_EEPROM_RELEASE','SV04_NEXT_FLASH_RELEASE']:
   with self.subTest(flag=flag):
    r=subprocess.run(['g++','-std=c++11','-D'+flag,'-fsyntax-only',str(P/'tests/driver76.cpp')],capture_output=True,text=True)
    self.assertNotEqual(r.returncode,0)
 def test_stage76_patch_reject_duplicate(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);f=self.fixture(root)
   a=apply(root,P/'src/SV04NextIntegration76.hpp')
   self.assertFalse(a['flash_approved']);self.assertTrue((root/HDR).exists())
   self.assertIn('SV04NextIntegration76.hpp',f.read_text())
   with self.assertRaises(ValueError):apply(root,P/'src/SV04NextIntegration76.hpp')
 def test_unlocked_gate_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);f=self.fixture(root)
   (root/FEATURE/'SV04NextDwinBridge73.hpp').write_text('static constexpr bool MAPPING_CONFIRMED=true;')
   original=f.read_bytes()
   with self.assertRaises(ValueError):apply(root,P/'src/SV04NextIntegration76.hpp')
   self.assertEqual(f.read_bytes(),original)
 def test_audit_success(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);f=self.fixture(root)
   apply(root,P/'src/SV04NextIntegration76.hpp')
   s=f.read_text()
   for fn in HEADERS:
    if fn in ('SV04NextDwinWire72.hpp','SV04NextIntegration76.hpp','SV04NextDwinDelivery75.hpp'):continue
    s='#include "../../../feature/'+fn+'"\n'+s
   f.write_text(s)
   result=audit(root)
   self.assertTrue(result['pass'],result['failures'])
   self.assertFalse(result['flash_approved'])
 def test_audit_missing_include_denied(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);self.fixture(root)
   a=audit(root)
   self.assertFalse(a['pass']);self.assertTrue(a['failures'])
 def test_scripts_syntax_and_chain(self):
  for f in (P/'tools').glob('*.py'):compile(f.read_bytes(),str(f),'exec')
  self.assertIn('from apply_chain75 import run', (P/'tools/apply_chain76.py').read_text())
 def test_no_hardware_actuation(self):
  text=(P/'src/SV04NextIntegration76.hpp').read_text()
  for x in ('queue.enqueue','thermalManager','settings.save','planner.buffer','M500'):
   self.assertNotIn(x,text)
  self.assertIn('MAPPING_CONFIRMED',text)
