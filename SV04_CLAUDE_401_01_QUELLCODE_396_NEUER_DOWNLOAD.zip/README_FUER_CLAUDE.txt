SV04-NEXT: VOLLSTAENDIGE TECHNISCHE UEBERGABE AN CLAUDE
Stand: 15.11.2026 nach Workflow 62

DIESE DATEIEN SIND ECHTE GITHUB-ARTEFAKTE (KEINE LEEREN AUFTRAGSTEXTE).

DATEIEN:
QUELLCODE_396_W58.zip: Original-GitHub-Artefakt 14168924462 von Workflow 58.
  Enthaelt Marlin_396_integrated_source.tar.gz (vollstaendigen integrierten
  Marlin-Quellbaum, 2703 Tar-Eintraege), SOURCE_SHA256.txt und README.txt.
PRAEPROZESSOR_396_W58.zip: Original-GitHub-Artefakt 14169283391.
  Enthaelt *.i, *.macros, relevante C++-Quelldateien und Konfiguration.
BUILD_LOGS_396_W58.zip: Original-GitHub-Artefakt 14169372414.
  Enthaelt STM32-Build-Logs, EEPROM-Fullchain-Protokolle, Patches, Evidenz.
ROOTCAUSE_W60.zip: Original-GitHub-Artefakt 14171250471.
  Enthaelt zusammengefasste Compilerfehler und Testsuche.
TESTS_UND_LOGS_W62.zip: Original-GitHub-Artefakt 14171891043.
  Enthaelt ALLE dort archivierten W62-Testausgaben, Test-Eingabe-C++,
  die originalen und gepatchten Runner und Build-Fehler.
TESTS_DIREKT/: Aus W62 extrahierte Originalskripte + gepatchte Skripte,
  originale Fehlermeldungen und Logauszuege. WICHTIG: Originals sichern!

UNMITTELBAR BELEGTER STAND:
* W57 (390) erfolgreich: 43728584524
* W58 (396) STM32 beide Profile Build-Exit 0, Workflow rot wegen
  EEPROM-Fullchain 328B und 377: 43733170214
* W62 (400) rot: 43739607784
  377-Originalrunner wiederhergestellt; Test vor/nach 377 CXX_COMPILE FAIL.
  328B scheitert in unpatch: Muster nicht gefunden.
* W62-Pruefprotokoll: sv04_eeprom_gcode_idle in settings.cpp beim
  isolierten C++-Harness nicht deklariert (M500/M501/M502).

VERBINDLICHER CLAUDE-AUFTRAG:
1. Alle Archiv- und Inhalts-Hashes vergleichen und Quellstand identifizieren.
2. 396 Quellbaum statt 377 als massgebliche Ausgangsbasis benutzen.
3. Vorhandene 378-380 Aenderungen im integrierten 396 Source untersuchen.
4. Host-Harness der 328B- und 377-Fullchain mit korrekter, realitaetsnaher
   Symbolbindung und Testsemantik korrigieren. Keine Dummy-Idle-Freigabe.
5. 328B-unpatch an veraendertes Source-Schema anpassen, Roundtrip beweisen.
6. 377 vor/nach Patch + alle negativen und Mutationstests nachweisbar ausfuehren.
7. Erst dann 401/W63 mit unveraenderter Alt-Basis und neuen Dateinamen bauen.
8. NO FLASH. HARDWARE_TESTED=NO. Prozentwerte NICHT erfinden.

Achtung: Artefakt 14171891043 ist kein bestandener Test, sondern der
unveraenderte Fehlerbeleg! Weder 396 noch 400 ist Hardware-freigegeben.
