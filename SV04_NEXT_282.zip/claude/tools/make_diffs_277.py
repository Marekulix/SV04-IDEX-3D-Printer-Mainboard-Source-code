#!/usr/bin/env python3
"""Erzeugt die reproduzierbaren Diff-Dateien (unified) aus den ECHTEN Patchskripten: Stufe 1 (276 -> P1), Stufe 2 (OEM/P1 -> integriert) und das GESAMT-Delta gegen den unveraenderten OEM fuer G28/motion.
Aufruf: make_diffs_277.py --out DIFFS"""
import argparse
import difflib
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / '04_TESTS' / 'sim'))
import chain_tree as T  # noqa: E402

F = {'G28': 'Marlin/src/gcode/calibrate/G28.cpp', 'motion_h': 'Marlin/src/module/motion.h', 'motion_cpp': 'Marlin/src/module/motion.cpp',
     'G29': 'Marlin/src/gcode/bedlevel/abl/G29.cpp', 'LCD_RTS': 'Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp', 'gcode': 'Marlin/src/gcode/gcode.cpp'}


def udiff(a, b, rel):
    A = a.read_bytes().decode('utf-8').splitlines(True) if a and a.exists() else []
    B = b.read_bytes().decode('utf-8').splitlines(True)
    return ''.join(difflib.unified_diff(A, B, 'a/' + rel, 'b/' + rel, n=3))


def plan():
    """[(dateiname, basis_pfad, ziel_pfad, rel)] mit den echten Staenden."""
    S = T.shared()
    oem = {'G28': T.CLAUDE / '01_BASELINE/OEM_FILES' / F['G28'], 'motion_h': T.CLAUDE / '01_BASELINE/OEM_FILES' / F['motion_h'], 'motion_cpp': T.CLAUDE / '01_BASELINE/OEM_FILES' / F['motion_cpp'],
           'G29': T.OEM / 'gcode/bedlevel/abl/G29.cpp', 'LCD_RTS': T.OEM / 'lcd/e3v2/creality/LCD_RTS.cpp', 'gcode': T.OEM / 'gcode/gcode.cpp'}
    out = []
    for k in ('G28', 'motion_h', 'motion_cpp'):
        out.append((f'1_P1_{k}_276_nach_277.patch', S['t276'] / F[k], S['p1'] / F[k], F[k]))
    out.append(('2_OVERLAY_G28_P1_nach_277.patch', S['p1'] / F['G28'], S['integ'] / F['G28'], F['G28']))
    for k in ('G29', 'LCD_RTS', 'gcode'):
        out.append((f'2_OVERLAY_{k}_OEM_nach_277.patch', oem[k], S['integ'] / F[k], F[k]))
    for k in ('G28', 'motion_h', 'motion_cpp'):
        out.append((f'3_GESAMT_{k}_OEM_nach_277.patch', oem[k], S['integ'] / F[k], F[k]))
    return out


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', required=True)
    a = ap.parse_args(argv)
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    for name, base, tgt, rel in plan():
        d = udiff(base, tgt, rel)
        (out / name).write_text(d, encoding='utf-8')
        print(f'{name:<48} +{sum(1 for l in d.splitlines() if l.startswith("+") and not l.startswith("+++")):>4} -{sum(1 for l in d.splitlines() if l.startswith("-") and not l.startswith("---")):>3}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
