#!/usr/bin/env python3
"""Fuehrt die Tests aus und schreibt die Rohlogs nach LOGS (Standard 06_EVIDENCE/host): Umgebung, C++-Kerntests, Host-/Pipeline-Tests, Simulationstests (echter G28/G29/Backend), Mutationstests, Werkzeuge.
Stufen: --stages core,host,sim,mutation,tools (Standard: alle). Exit 0 nur, wenn alles Gewaehlte besteht. KEIN STM32-Build, KEINE Hardware.
Aufruf (aus dem Paket-Wurzelverzeichnis point1/): python3 claude/tools/run_all_tests_a60.py [--stages ...] [--logs DIR]"""
import argparse
import platform
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]          # .../claude


def sh(cmd, timeout=3600):
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=timeout)
    return r.returncode, r.stdout + r.stderr


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--logs', default=str(ROOT / '06_EVIDENCE' / 'host'))
    ap.add_argument('--stages', default='core,host,sim,mutation,tools')
    a = ap.parse_args(argv)
    st = set(a.stages.split(','))
    L = Path(a.logs)
    L.mkdir(parents=True, exist_ok=True)
    ok = True
    env = [f'python {platform.python_version()} ({platform.platform()})']
    for t in ('g++', 'patch', 'arm-none-eabi-gcc', 'pio', 'platformio', 'git'):
        env.append(f'{t:<20} {shutil.which(t) or "NICHT VORHANDEN"}')
    if shutil.which('g++'):
        env.append(sh(['g++', '--version'])[1].splitlines()[0])
    try:
        import yaml
        env.append(f'PyYAML {yaml.__version__}')
    except ImportError:
        env.append('PyYAML NICHT VORHANDEN')
    env += ['', 'STM32-Cross-Build: NICHT AUSGEFUEHRT in dieser Umgebung (keine ARM-Toolchain, kein PlatformIO, kein Netz); er ist Aufgabe von 277.yml', 'Hardware/Flash: NOT RUN',
            'Simulation: Host-Stubs (Thermik, Queue, EEPROM-MODELL, homeaxis()-Modell mit OEM-Reihenfolge) um die ECHTE G28.cpp/G29.cpp und woertlich extrahierte OEM-Bloecke; KEIN STM32']
    (L / '00_umgebung.txt').write_text('\n'.join(env) + '\n')
    if 'core' in st:
        exe = Path(tempfile.mkdtemp()) / 'core'
        cc = subprocess.run(['g++', '-std=c++11', '-O2', '-Wall', '-Wextra', '-Werror', '-pedantic', '-I', str(ROOT), str(ROOT / '04_TESTS/core/test_auto60_core.cpp'), '-o', str(exe)], capture_output=True, text=True)
        if cc.returncode:
            (L / '01_core_tests_cpp.txt').write_text('UEBERSETZUNG FEHLGESCHLAGEN\n' + cc.stderr); ok = False
        else:
            r = subprocess.run([str(exe)], capture_output=True, text=True)
            (L / '01_core_tests_cpp.txt').write_text(r.stdout); ok &= r.returncode == 0
    if 'host' in st:
        rc, out = sh([sys.executable, '-m', 'unittest', '-v', '04_TESTS.test_core_a60', '04_TESTS.test_pipeline_a60', '04_TESTS.test_patch_and_build_a60'])
        (L / '02_unittest_host_core_pipeline.txt').write_text(out); ok &= rc == 0
    if 'sim' in st:
        rc, out = sh([sys.executable, '-m', 'unittest', 'discover', '-s', '04_TESTS/sim', '-p', 'test_*.py', '-v'])
        (L / '03_unittest_sim.txt').write_text(out); ok &= rc == 0
    if 'mutation' in st:
        rc, out = sh([sys.executable, '-m', 'unittest', '-v', '04_TESTS.test_mutations_a60'])
        (L / '04_unittest_mutation.txt').write_text(out); ok &= rc == 0
        for src, dst in (('04_TESTS/LAST_MUTATION_REPORT_a60_core.txt', '05_mutationen_kern.txt'), ('04_TESTS/LAST_MUTATION_REPORT_a60_adapter.txt', '06_mutationen_adapter.txt'), ('04_TESTS/LAST_MUTATION_REPORT_a60_backend.txt', '07_mutationen_backend.txt')):
            if (ROOT / src).exists():
                shutil.copy(ROOT / src, L / dst)
    if 'tools' in st:
        for cmd, name in (([sys.executable, 'tools/make_inventory_a01.py', '--out', '07_AUDIT/A01_QUELLENINVENTAR.md'], '08_inventar_a01.txt'),
                          ([sys.executable, 'tools/dwin_vp_catalog.py', '--header', '01_BASELINE/OEM_FILES/Marlin/src/lcd/e3v2/creality/LCD_RTS.h', '--signatures', '01_BASELINE/FIXTURES/OEM_DWIN_16_RECORD_SIGNATURES_187_CORRECTED.json', '--out', '07_AUDIT/A13_DWIN_VP_KATALOG.json', '--md', '07_AUDIT/A13_DWIN_VP_KATALOG.md'], '09_vp_katalog_a13.txt')):
            rc, out = sh(cmd)
            (L / name).write_text(out); ok &= rc == 0
    (L / '99_ERGEBNIS.txt').write_text(('ALLE GEWAEHLTEN TESTS BESTANDEN: ' + a.stages if ok else 'FEHLER: siehe Logs') + '\n')
    print('ALLE TESTS BESTANDEN' if ok else 'FEHLER')
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
