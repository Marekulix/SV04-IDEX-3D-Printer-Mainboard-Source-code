#pragma once
// TESTWELT fuer den Auto60-Kern: bildet die Marlin-Seite ab. EEPROM-MODELL nach der ECHTEN settings.cpp-Semantik (save(): erst Platzhalter "ERR" schreiben,
// Daten, am Ende Kopf "V85"+CRC; settings.cpp:653-668,1452-1469). Alles hier ist SIMULATION, kein Marlin-Code.
#include "../../02_SOURCE/Marlin/src/feature/sv04_claude_auto60/sv04_claude_auto60_core.h"
#include <vector>
#include <string>
#include <stdio.h>
using namespace sv04c;

enum SaveMode { SAVE_OK = 0, SAVE_RETURNS_FALSE_NO_WRITE, SAVE_POWERLOSS_AFTER_ERR, SAVE_SILENT_CORRUPTION, SAVE_FAILS_ONCE_THEN_OK, SAVE_WRONG_VERSION, SAVE_ZOFF_CORRUPT };

struct Eeprom { bool header_ok; char ver[4]; MeshImage mesh; float zoff; uint32_t save_calls, byte_writes; };

struct World {
  uint32_t t;
  Precond pre; BedState bed; std::vector<float> targets;
  bool home_accept, g29_accept, idle, m420_accept, m420_applies, lev_active, lev_valid; int home_calls, g29_calls, m420_calls; uint32_t home_sid, g29_sid;
  MeshImage ram; float zoff;
  Eeprom ee; SaveMode save_mode; int save_calls, validate_calls, readback_calls; bool readback_available, datasize_ok, load_disables_leveling; int order_log; std::vector<std::string> calls;
  std::vector<DisplayEvent> disp; MeshImage backup; int rollback_calls, home_abort_calls; uint32_t home_abort_sid;
  World() { reset(); }
  void reset() {
    t = 1000; memset(&pre, 0, sizeof pre); pre.dxc_mode_ok = pre.duplication_off = pre.home_backend_available = pre.eeprom_available = true; pre.active_extruder = 0;
    bed.temp_c = 25; bed.target_c = 0; bed.sensor_ok = true; targets.clear(); home_accept = g29_accept = idle = m420_accept = m420_applies = true; lev_active = false; lev_valid = true; home_calls = g29_calls = m420_calls = 0; home_sid = g29_sid = 0;
    memset(&ram, 0, sizeof ram); ram.spacing[0] = ram.spacing[1] = 84; ram.start[0] = ram.start[1] = 25; ram.factor[0] = ram.factor[1] = 1.0f / 84; zoff = -1.10f;
    for (unsigned x = 0; x < kN; x++) for (unsigned y = 0; y < kN; y++) ram.z[x][y] = 0.31f - 0.05f * x + 0.02f * y;      // "altes" Mesh
    memset(&ee, 0, sizeof ee); memcpy(ee.ver, "V85", 4); ee.header_ok = true; ee.mesh = ram; ee.zoff = zoff;
    save_mode = SAVE_OK; save_calls = validate_calls = readback_calls = 0; readback_available = datasize_ok = true; load_disables_leveling = false; order_log = 0; calls.clear(); disp.clear(); backup = ram; rollback_calls = 0; home_abort_calls = 0; home_abort_sid = 0;
  }
  void log(const char *s) { calls.push_back(s); }
  int count(const char *s) const { int n = 0; for (auto &c : calls) if (c == s) ++n; return n; }
  bool idx(const char *a, const char *b) const { int ia = -1, ib = -1; for (size_t i = 0; i < calls.size(); i++) { if (calls[i] == a && ia < 0) ia = (int)i; if (calls[i] == b && ib < 0) ib = (int)i; } return ia >= 0 && ib >= 0 && ia < ib; }
};

// ---- Ports
static uint32_t pw_now(void *c) { return ((World *)c)->t; }
static void pw_pre(void *c, Precond &p) { p = ((World *)c)->pre; }
static void pw_bed(void *c, BedState &b) { b = ((World *)c)->bed; }
static void pw_set(void *c, float v) { World *w = (World *)c; w->targets.push_back(v); w->bed.target_c = v; w->log("bed_set"); }
static bool pw_home(void *c, uint32_t sid) { World *w = (World *)c; ++w->home_calls; w->home_sid = sid; w->log("home_request"); return w->home_accept; }
static bool pw_g29(void *c, uint32_t sid) { World *w = (World *)c; ++w->g29_calls; w->g29_sid = sid; w->backup = w->ram; w->log("g29_start"); return w->g29_accept; }
static bool pw_idle(void *c) { return ((World *)c)->idle; }
static void pw_meshread(void *c, MeshImage &m) { m = ((World *)c)->ram; }
static float pw_zoff(void *c) { return ((World *)c)->zoff; }
static bool pw_m420(void *c, uint32_t) { World *w = (World *)c; ++w->m420_calls; w->log("m420_s1"); if (!w->m420_accept) return false; if (w->m420_applies && w->lev_valid) w->lev_active = true; return true; }
static void pw_lev(void *c, bool &a, bool &v) { World *w = (World *)c; a = w->lev_active; v = w->lev_valid; }
static bool pw_validate(void *c) { World *w = (World *)c; ++w->validate_calls; w->log("eeprom_validate"); return w->ee.header_ok && memcmp(w->ee.ver, "V85", 4) == 0; }
static bool pw_save(void *c, uint32_t) {
  World *w = (World *)c; ++w->save_calls; ++w->ee.save_calls; w->log("save");
  w->ee.header_ok = false; memcpy(w->ee.ver, "ERR", 4);                       // echter Ablauf: Platzhalter zuerst
  if (w->save_mode == SAVE_RETURNS_FALSE_NO_WRITE) { return false; }
  if (w->save_mode == SAVE_POWERLOSS_AFTER_ERR) { w->ee.byte_writes += 40; return false; }     // Abbruch NACH "ERR": altes EEPROM ungueltig
  if (w->save_mode == SAVE_FAILS_ONCE_THEN_OK && w->save_calls == 1) { w->ee.byte_writes += 10; return false; }
  w->ee.mesh = w->ram; w->ee.zoff = w->zoff; w->ee.byte_writes += 800;
  if (w->save_mode == SAVE_SILENT_CORRUPTION) w->ee.mesh.z[2][1] += 0.5f;
  if (w->save_mode == SAVE_ZOFF_CORRUPT) w->ee.zoff += 0.01f;                                 // nur der Z-Offset weicht im EEPROM ab                    // Bitfehler, den save() nicht bemerkt
  memcpy(w->ee.ver, w->save_mode == SAVE_WRONG_VERSION ? "V84" : "V85", 4); w->ee.header_ok = true;     // Commit-Marker zuletzt
  return true;
}
static bool pw_readback(void *c, const MeshImage &exp, float zexp, EepromEvidence &ev) {
  World *w = (World *)c; ++w->readback_calls; w->log("readback");
  if (!w->readback_available) return false;
  ev.readback_ok = true; ev.mesh_equal = mesh_same(w->ee.mesh, exp); ev.zoff_equal = memcmp(&w->ee.zoff, &zexp, sizeof(float)) == 0;
  ev.version_ok = memcmp(w->ee.ver, "V85", 4) == 0; ev.datasize_ok = w->datasize_ok;
  w->ram = w->ee.mesh; w->zoff = w->ee.zoff;                                                   // wie settings.load(): EEPROM -> RAM
  if (w->load_disables_leveling) w->lev_active = false;                                        // wie ein Ladepfad, der die Nivellierung ausschaltet
  ev.leveling_active_after = w->lev_active;
  return true;
}
static void pw_disp(void *c, const DisplayEvent &e) { ((World *)c)->disp.push_back(e); }
static void pw_home_abort(void *c, uint32_t sid) { World *w = (World *)c; ++w->home_abort_calls; w->home_abort_sid = sid; w->log("home_abort"); }
static void pw_rollback(void *c) { World *w = (World *)c; ++w->rollback_calls; w->ram = w->backup; w->log("rollback_mesh"); }

static Ports make_ports(World &w) {
  Ports p; memset(&p, 0, sizeof p); p.ctx = &w; p.now_ms = pw_now; p.read_precond = pw_pre; p.bed_read = pw_bed; p.bed_set_target = pw_set; p.home_request = pw_home; p.g29_start = pw_g29; p.cmd_idle = pw_idle;
  p.mesh_read = pw_meshread; p.zoffset = pw_zoff; p.m420_s1 = pw_m420; p.leveling_state = pw_lev; p.eeprom_validate = pw_validate; p.save = pw_save; p.eeprom_readback = pw_readback; p.display = pw_disp; p.rollback_mesh = pw_rollback; p.home_abort = pw_home_abort; return p;
}
static Config fast_config() {
  Config c = Config::defaults(); c.stable_ms = 3000; c.heat_timeout_ms = 60000; c.stab_timeout_ms = 30000; c.home_timeout_ms = 20000; c.probe_timeout_ms = 30000; c.enable_timeout_ms = 5000; return c;
}
static HomeEvidence full_ev() { HomeEvidence e; e.x_trusted = e.y_trusted = e.z_trusted = e.dxc_mode_ok = e.duplication_off = e.idex_gate_confirmed = true; e.active_extruder = 0; return e; }

struct H {
  World w; Coordinator co;
  explicit H(const Config &c = fast_config()) : w(), co(make_ports(w), c) {}
  void tick(unsigned n = 1, uint32_t step = 500) { for (unsigned i = 0; i < n; i++) { w.t += step; co.tick(); } }
  bool until(State s, unsigned max = 400, uint32_t step = 500) { for (unsigned i = 0; i < max && co.state() != s; i++) tick(1, step); return co.state() == s; }
  Reason start() { return co.start(); }
  bool to_homing() { if (co.start() != R_START_OK) return false; w.bed.temp_c = 60.0f; return until(ST_HOMING_PENDING); }
  bool to_probing(const HomeEvidence &ev = full_ev()) { if (!to_homing()) return false; co.on_home_result(co.session(), true, ev); if (co.state() != ST_PROBING) return false; co.on_g29_begin(co.session()); return true; }
  // 16 Punkte in OEM-Reihenfolge; hook darf Wert/Index veraendern. Schreibt das RAM-Mesh wie G29 es tut.
  void feed(unsigned n = 16, float (*val)(unsigned) = nullptr) {
    const uint32_t sid = co.session();
    for (unsigned k = 0; k < n; k++) {
      const unsigned iy = k / 4, pos = k % 4, ix = (iy & 1) ? pos : (3 - pos);
      const float z = val ? val(k) : 0.012f * (float)k - 0.05f;
      w.ram.z[ix][iy] = z;
      co.on_g29_point(sid, ix, iy, w.ram.start[0] + ix * w.ram.spacing[0], w.ram.start[1] + iy * w.ram.spacing[1], z, z);
    }
  }
  void feed_range(unsigned k0, unsigned k1) {
    const uint32_t sid = co.session();
    for (unsigned k = k0; k < k1; k++) {
      const unsigned iy = k / 4, pos = k % 4, ix = (iy & 1) ? pos : (3 - pos);
      const float z = 0.012f * (float)k - 0.05f; w.ram.z[ix][iy] = z;
      co.on_g29_point(sid, ix, iy, w.ram.start[0] + ix * w.ram.spacing[0], w.ram.start[1] + iy * w.ram.spacing[1], z, z);
    }
  }
  void finish_g29(bool ok = true, bool dry = false, bool faux = false) { G29Result r; r.success = ok; r.dryrun = dry; r.faux = faux; co.on_g29_finished(co.session(), r); }
  bool to_validating() { return to_probing() && (feed(), finish_g29(), co.state() == ST_VALIDATING); }
  bool to_saved_ok() { if (!to_validating()) return false; return until(ST_SUCCESS, 40, 100); }
};
