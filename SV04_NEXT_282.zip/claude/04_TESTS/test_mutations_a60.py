"""MUTATIONSTESTS (Empfindlichkeit): gezielte Fehler in den Kern und in den Marlin-Adapter einbauen; die Tests muessen sie finden.
Kern: Mutant wird gegen die 122+ C++-Kerntests geprueft (erkannt = Testlauf scheitert oder Build bricht).
Adapter: Mutant wird in die Patchkette (apply_claude_parallel.py) + Kettensimulation eingebaut; erkannt = Verhalten in einer festen Szenarioliste weicht vom unmutierten Stand ab.
Gleichwertige Mutanten sind getrennt und begruendet. Ergebnis: tests/LAST_MUTATION_REPORT_a60.txt"""
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / '03_PATCHES'))
sys.path.insert(0, str(HERE / 'sim'))
import apply_claude_parallel as P  # noqa: E402
import build_sim_a60 as B  # noqa: E402
import chain_tree as T  # noqa: E402

CORE = Path('02_SOURCE/Marlin/src/feature/sv04_claude_auto60/sv04_claude_auto60_core.h')
INC = Path('02_SOURCE/Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc')
OEM = ROOT / '01_BASELINE' / 'OEM_FILES' / 'Marlin' / 'src'

CORE_MUTANTS = [
    ('C01 Fenstergrenze exklusiv statt inklusiv', "fabsf(b.temp_c - c_.bed_target_c) <= c_.band_c", "fabsf(b.temp_c - c_.bed_target_c) < c_.band_c"),
    ('C02 Stabilitaetszeit wird beim Verlassen des Fensters nicht zurueckgesetzt', "if (!in_band(b)) stable_since_ = 0;", "if (false) stable_since_ = 0;"),
    ('C03 Start trotz laufendem Druck erlaubt', "    if (q.printing) return R_PRE_PRINTING;\n    if (q.paused) return R_PRE_PAUSED;\n    if (q.moving)", "    if (q.paused) return R_PRE_PAUSED;\n    if (q.moving)"),
    ('C04 Z-Offset-Pruefung vor dem Speichern entfernt', "    if (fabsf(p_.zoffset(p_.ctx) - zoff0_) > c_.zoffset_tol) { fail(R_ZOFFSET_CHANGED); return; }\n    bool act", "    bool act"),
    ('C05 Mesh-Unveraendertheit vor dem Speichern entfernt', "    if (!mesh_same(ram, validated_)) { fail(R_MESH_CHANGED); return; }\n    if (fabsf(p_.zoffset", "    if (fabsf(p_.zoffset"),
    ('C06 Pruefung "Nivellierung aktiv" nach M420 entfernt', "    if (!act || !val) { fail(R_M420_NOT_ACTIVE); return; }\n    MeshImage ram; p_.mesh_read(p_.ctx, ram);\n    if (!mesh_same(ram, validated_)) { fail(R_MESH_CHANGED); return; }\n    m420_enabled_", "    MeshImage ram; p_.mesh_read(p_.ctx, ram);\n    if (!mesh_same(ram, validated_)) { fail(R_MESH_CHANGED); return; }\n    m420_enabled_"),
    ('C07 SUCCESS ohne Mesh-Gleichheit der Ruecklesung', "ev.readback_ok && ev.mesh_equal && ev.zoff_equal", "ev.readback_ok && ev.zoff_equal"),
    ('C08 SUCCESS ohne Z-Offset-Gleichheit der Ruecklesung', "ev.mesh_equal && ev.zoff_equal && ev.version_ok", "ev.mesh_equal && ev.version_ok"),
    ('C09 "Ruecklesung nicht verfuegbar" gilt nicht als Fehler', "    if (ev.validate_ok && !avail) { fail(R_VERIFY_UNAVAILABLE); return; }", "    if (ev.validate_ok && !avail) { go(ST_SUCCESS, R_VERIFIED); return; }"),
    ('C10 IDEX-Gate-Nachweis wird nicht verlangt', "(c_.require_idex_gate && !ev.idex_gate_confirmed)", "false"),
    ('C11 Trockenlauf gilt als Erfolg', "if (!r.success || r.dryrun || r.faux) { fail(R_PROBE_FAILED); return; }", "if (!r.success || r.faux) { fail(R_PROBE_FAILED); return; }"),
    ('C12 Messreihenfolge wird nicht geprueft', "else if (point_no(ix, iy) != n_) e = ME_ORDER;", "else if (false) e = ME_ORDER;"),
    ('C13 Veraltete RAM-Werte werden nicht erkannt', "      if (memcmp(&ram.z[p.ix][p.iy], &p.stored_z, sizeof(float)) != 0) return R_MESH_STALE;", "      if (false) return R_MESH_STALE;"),
    ('C14 cancel() bricht die Wiederherstellung nach dem ersten save() ab', "      case ST_SAVE_PENDING: if (!save_issued_) cancelled(R_USER_CANCEL); break;   // nach save(): nicht abbrechbar", "      case ST_SAVE_PENDING: cancelled(R_USER_CANCEL); break;"),
    ('C15 Rollback des ungepruefen Meshes entfaellt', "  void maybe_rollback() { if (", "  void maybe_rollback() { if (false && "),
    ('C16 Wiederholung des save() auch bei reinem Nivellierungsproblem', "if (why != R_VERIFY_LEVELING && save_attempts_ <= c_.max_save_retries) {", "if (save_attempts_ <= c_.max_save_retries) {"),
    ('C17 Bett-Soll wird bei Endzustaenden nicht wiederhergestellt', "  void restore_heater() { if (c_.restore_heater_on_exit && p_.bed_set_target)", "  void restore_heater() { if (false && p_.bed_set_target)"),
    ('C18 G29-Beginn-Frist entfernt', "if (st_ == ST_PROBING && !g29_begun_ && t - enter_ms_ > c_.g29_begin_grace_ms && p_.cmd_idle(p_.ctx))", "if (false)"),
    ('C19 Messpunkte ohne G29-Beginn werden uebernommen', "if (st_ != ST_PROBING || sid != sid_ || !g29_begun_) { ++stale_events_; return; }", "if (st_ != ST_PROBING || sid != sid_) { ++stale_events_; return; }"),
    ('C20 Betragsgrenze exklusiv statt inklusiv (abs_limit)', "fabsf(p.raw_z) > c.abs_limit_mm || fabsf(p.stored_z) > c.abs_limit_mm", "fabsf(p.raw_z) >= c.abs_limit_mm || fabsf(p.stored_z) >= c.abs_limit_mm"),
    ('C21 Spannweitengrenze exklusiv statt inklusiv', "if (mx - mn > c.spread_limit_mm) return R_MESH_OUTLIER;", "if (mx - mn >= c.spread_limit_mm) return R_MESH_OUTLIER;"),
    ('C22 Fremde Sitzung bei Homing-Ergebnis wird akzeptiert', "if (st_ != ST_HOMING_PENDING || sid != sid_) { ++stale_events_; return; }", "if (st_ != ST_HOMING_PENDING) { ++stale_events_; return; }"),
    ('C23 Zweiter Start waehrend des Laufs erlaubt', "    if (active()) return R_PRE_ALREADY_RUNNING;\n", ""),
    ('C24 Sitzungs-Reset beim Neustart laesst alte Ereignisse zu', "    mesh_.begin(0); mesh_.invalidate(); memset(&validated_, 0, sizeof validated_);", "    memset(&validated_, 0, sizeof validated_);"),
]
CORE_EQUIVALENT = [
    ('E-C14 Pruefung cancel_pending_ in do_save() entfernt', "if (cancel_pending_ && !save_issued_) { cancelled(R_USER_CANCEL); return; }", "if (false) { cancelled(R_USER_CANCEL); return; }",
     'Unerreichbar: cancel() setzt cancel_pending_ nur in HOMING_PENDING/PROBING/ENABLING; do_enable() verbraucht es, bevor SAVE_PENDING betreten wird. Der wirksame Schutz sitzt in cancel() (Mutant C14).'),
]

ADAPTER_MUTANTS = [
    ('A01 Nivellierung wird nach der G29 NICHT wieder ausgeschaltet (OEM-Aktivierung unvalidiert)', "ST_VALIDATING) set_bed_leveling_enabled(false);   // G29.cpp:883", "ST_VALIDATING) { }   // G29.cpp:883"),
    ('A02 Haken ohne Sperrabschnitt (Tick mitten im Haken)', "void SV04Claude_G29Complete(const uint32_t id, const bool successful, const bool dryrun, const bool faux) {\n  Sv04cSection sv04c_section;\n", "void SV04Claude_G29Complete(const uint32_t id, const bool successful, const bool dryrun, const bool faux) {\n"),
    ('A03 Rollback stellt den Nivellierungszustand nicht her', "  if (planner.leveling_active != sv04c_lev_at_begin) set_bed_leveling_enabled(sv04c_lev_at_begin);   // Zustand wie VOR dem Lauf\n", ""),
    ('A04 Rollback bei ungueltigem Auto60-Lauf entfaellt vollstaendig (vor UND nach der Meldung)', None, lambda t: _both(t, "if (!predicted_ok) sv04c_g29_apply(sv04g29::DEC_ROLLBACK);", "if (false) sv04c_g29_apply(sv04g29::DEC_ROLLBACK);", "else sv04c_g29_apply(sv04g29::DEC_ROLLBACK);", "else { }")),
    ('A04b Rollback erst NACH der Ergebnismeldung (Fehlerseite mit veralteten Zahlen)', "      if (!predicted_ok) sv04c_g29_apply(sv04g29::DEC_ROLLBACK); ", "      if (false) sv04c_g29_apply(sv04g29::DEC_ROLLBACK); "),
    ('A05 DWIN-Touch wird waehrend des Laufs nicht gesperrt', "bool SV04Claude_Auto60_Busy() { return sv04c_coord.running(); }", "bool SV04Claude_Auto60_Busy() { return false; }"),
    ('A06 Nach Abweichung der Ruecklesung bleibt das EEPROM-Mesh im RAM', "  if (!ev.mesh_equal) sv04c_mesh_restore(expected);", "  if (false) sv04c_mesh_restore(expected);"),
    ('A07 DWIN-Konflikt wird nicht als Startsperre gemeldet', "  p.dwin_busy = (waitway != 0);", "  p.dwin_busy = false;"),
    ('A08 Z-Vertrauen wird nicht aus dem Marlin-Zustand gelesen', "ev.z_trusted = axis_is_trusted(Z_AXIS);", "ev.z_trusted = true;"),
    ('A09 Laufender Druck wird nicht erkannt', "  p.printing = card.isPrinting() || PrintFlag != 0 || PoweroffContinue;", "  p.printing = false;"),
    ('A10 Vorbedingung "Backend vorhanden" entfaellt (Variante OHNE Backend)', "  p.home_backend_available = (SV04_CLAUDE_HOME_BACKEND_AVAILABLE != 0);", "  p.home_backend_available = true;", 'nobackend'),
    ('A11 Fremde G29 waehrend Auto60 wird nicht gemeldet', "    else if (sv04c_coord.running()) sv04c_coord.on_g29_begin(0);", "    else if (false) sv04c_coord.on_g29_begin(0);"),
    ('A12 Nach Seitenwechsel auf Erfolg auch bei Fehler', "      else if (sv04c_page_changed) { rtscheck.RTS_SndData(0, AUTO_BED_LEVEL_ICON_VP); rtscheck.RTS_SndData(ExchangePageBase + SV04_CLAUDE_PAGE_FAIL, ExchangepageAddr); }", "      else if (sv04c_page_changed) { rtscheck.RTS_SndData(ExchangePageBase + SV04_CLAUDE_PAGE_SUCCESS, ExchangepageAddr); }"),
]
ADAPTER_EQUIVALENT = [
    ('E1 zweite Sperre: ablehnende Huelle des Backends liefert true (Variante OHNE Backend)', "bool SV04Claude_HomeBackendRequest(const uint32_t) { return false; }                      // fail-closed: Auto60 startet nie (PRE_HOME_BACKEND_MISSING)", "bool SV04Claude_HomeBackendRequest(const uint32_t) { return true; }                       // fail-closed: Auto60 startet nie (PRE_HOME_BACKEND_MISSING)", 'nobackend',
     'Verteidigung in der Tiefe: die Vorbedingung home_backend_available=false lehnt den Start schon vorher ab, home_request() wird nie erreicht; die zweite Sperre ist nur bei Entfernen BEIDER wirksam (A10).'),
]
SIGNATURE_NOBACKEND = [('limit_s=400',), ('manual_g29=1', 'nostart=1', 'nan_at=9')]
SIGNATURE = [('old',), ('nan_at=9',), ('val_at=5', 'val=12'), ('val_at=5', 'val=45'), ('kick_after_probe=6', 'kick=40'), ('cancel_at=PROBING',), ('save=3',), ('m420_noop=1',), ('printing=1',), ('waitway=1',), ('home=noz',),
             ('manual_g29=1', 'nostart=1', 'nan_at=9'), ('foreign_g29_at_s=50', 'home_ms=60000', 'limit_s=200'), ('lev0=0', 'val_at=5', 'val=12'), ('save=1',)]
KEYS = ('RESULT', 'LOG', 'EE', 'RAM', 'HMI', 'HMIPAGE', 'HMIMULTI', 'CMDS', 'MESH', 'BUSY', 'SERIAL', 'WIREHEX')


def _both(t, a1, b1, a2, b2):
    assert t.count(a1) == 1 and t.count(a2) == 1, (t.count(a1), t.count(a2))
    return t.replace(a1, b1).replace(a2, b2)


def sig(exe, scen=None):
    out = []
    for a in (scen or SIGNATURE):
        args = [x for x in a if x != 'old']
        r = B.scenario(exe, *args)
        out.append(tuple(r.get(k, '') for k in KEYS))
    return out


def integ_with_source(source_root):
    """Integrierter Stand (276 + Stufe 1 + Overlay) mit einem ANDEREN 02_SOURCE (fuer Mutanten); die Stufen 276 und 1 werden wiederverwendet."""
    base = T.shared()
    d = Path(tempfile.mkdtemp(prefix='a60_mutint_'))
    co = T.claude_out(base['p1'], d / 'claude_out', source_root)
    full = d / 'integ'
    shutil.copytree(base['p1'], full)
    for f in co.rglob('*'):
        if f.is_file():
            t = full / f.relative_to(co)
            t.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy(f, t)
    return full


def mutated_exe(name, old, new, base_defines, work):          # base_defines bestimmt die Variante (mit/ohne Backend)
    src = Path(tempfile.mkdtemp(prefix='a60_mutsrc_'))
    shutil.copytree(ROOT / '02_SOURCE', src / '02_SOURCE')
    f = src / INC
    t = f.read_text(encoding='utf-8')
    if old is None:
        f.write_text(new(t), encoding='utf-8')            # transformierender Mutant (mehrere Stellen)
    else:
        assert t.count(old) == 1, (name, t.count(old))
        f.write_text(t.replace(old, new), encoding='utf-8')
    return B.build(integ_with_source(src / '02_SOURCE'), 'm' + str(abs(hash(name)) % 10**7), base_defines, work)


class CoreMutants(unittest.TestCase):
    def test_every_core_mutant_is_detected_by_the_cpp_tests(self):
        report, missed = [], []
        for name, old, new in CORE_MUTANTS:
            tmp = Path(tempfile.mkdtemp(prefix='a60_core_mut_'))
            shutil.copytree(ROOT / '02_SOURCE', tmp / '02_SOURCE')
            shutil.copytree(HERE / 'core', tmp / '04_TESTS' / 'core')
            h = tmp / CORE
            t = h.read_text(encoding='utf-8')
            self.assertEqual(t.count(old), 1, name)
            h.write_text(t.replace(old, new), encoding='utf-8')
            exe = tmp / 't'
            cc = subprocess.run(['g++', '-std=c++11', '-O1', '-w', str(tmp / '04_TESTS/core/test_auto60_core.cpp'), '-o', str(exe)], capture_output=True, text=True)
            if cc.returncode:
                how = 'Build bricht'
            else:
                r = subprocess.run([str(exe)], capture_output=True, text=True)
                how = ('Tests scheitern: ' + ','.join(l.split()[1] for l in r.stdout.splitlines() if l.startswith('FAIL'))[:60]) if r.returncode else None
            report.append(f'{name:<82} erkannt: {how}')
            if not how:
                missed.append(name)
        for name, old, new, why in CORE_EQUIVALENT:
            tmp = Path(tempfile.mkdtemp(prefix='a60_core_eq_'))
            shutil.copytree(ROOT / '02_SOURCE', tmp / '02_SOURCE')
            shutil.copytree(HERE / 'core', tmp / '04_TESTS' / 'core')
            h = tmp / CORE
            tx = h.read_text(encoding='utf-8')
            self.assertEqual(tx.count(old), 1, name)
            h.write_text(tx.replace(old, new), encoding='utf-8')
            exe = tmp / 't'
            subprocess.run(['g++', '-std=c++11', '-O1', '-w', str(tmp / '04_TESTS/core/test_auto60_core.cpp'), '-o', str(exe)], check=True)
            ok = subprocess.run([str(exe)], capture_output=True, text=True).returncode == 0
            report.append(f'{name:<82} gleichwertig (geprueft: alle Tests bestehen): {ok} | {why}')
            if not ok:
                missed.append(name + ' (als gleichwertig behauptet, aber Tests scheitern)')
        (HERE / 'LAST_MUTATION_REPORT_a60_core.txt').write_text('\n'.join(report) + '\n', encoding='utf-8')
        self.assertEqual(missed, [], 'UEBERLEBENDE Mutanten:\n' + '\n'.join(report))


class AdapterMutants(unittest.TestCase):
    VARIANTS = {'backend': ['SV04_CLAUDE_HOME_BACKEND_EXTERNAL=1', 'SIM_A60'], 'nobackend': ['SIM_A60', 'SV04_CLAUDE_HOME_BACKEND_AVAILABLE=0']}

    def golden(self, variant, work):
        return sig(B.build(T.shared()['integ'], 'golden_' + variant, self.VARIANTS[variant], work), SIGNATURE if variant == 'backend' else SIGNATURE_NOBACKEND)

    def test_every_adapter_mutant_changes_observable_chain_behaviour(self):
        work = Path(tempfile.mkdtemp(prefix='a60_mutwork_'))
        golden = {v: self.golden(v, work) for v in self.VARIANTS}
        report, missed = [], []
        for m in ADAPTER_MUTANTS:
            name, old, new = m[:3]
            variant = m[3] if len(m) > 3 else 'backend'
            try:
                exe = mutated_exe(name, old, new, self.VARIANTS[variant], work)
                how = 'Verhalten' if sig(exe, SIGNATURE if variant == 'backend' else SIGNATURE_NOBACKEND) != golden[variant] else None
            except RuntimeError:
                how = 'Build bricht'
            report.append(f'{name:<92} erkannt: {how}')
            if not how:
                missed.append(name)
        for name, old, new, variant, why in ADAPTER_EQUIVALENT:
            exe = mutated_exe(name, old, new, self.VARIANTS[variant], work)
            same = sig(exe, SIGNATURE_NOBACKEND) == golden[variant]
            report.append(f'{name:<92} gleichwertig (geprueft): {same} | {why}')
            if not same:
                missed.append(name + ' (als gleichwertig behauptet, aber Verhalten weicht ab)')
        (HERE / 'LAST_MUTATION_REPORT_a60_adapter.txt').write_text('\n'.join(report) + '\n', encoding='utf-8')
        self.assertEqual(missed, [], 'UEBERLEBENDE/UNSTIMMIGE Mutanten:\n' + '\n'.join(report))



# ---------------------------------------------------------------------------------- Mutanten des PRODUKTIONS-Backends (Integrationssignatur, echter G28/G29)
BACKEND_MUTANTS = [
    ('P01 Rueckmeldung nicht mehr "genau einmal" (Sperre sv04c_hb_reported entfernt)', "    if (sv04c_hb_reported) return;\n    sv04c_hb_reported = true;", "    sv04c_hb_reported = true;"),
    ('P02 Abbruch eines nur eingestellten G28 wird nicht verworfen', "static void sv04c_hb_cancel_armed() {\n    if (sv04c_hb_state == 1) {", "static void sv04c_hb_cancel_armed() {\n    if (false) {"),
    ('P03 das G28 einer verworfenen Anforderung wird nicht mehr verweigert', "    if (sv04c_hb_stale && full) { sv04c_hb_stale = false; return false; }", "    if (sv04c_hb_stale && full) { sv04c_hb_stale = false; return true; }"),
    ('P04 ein fremdes G28 waehrend der Anforderung macht sie nicht ungueltig', "      sv04c_hb_finish(false, false); sv04c_hb_state = 0; sv04c_hb_stale = true; sv04c_hb_stale_ms = (uint32_t)millis();   // ein ANDERES G28 kam zuvor", "      // (mutiert)   // ein ANDERES G28 kam zuvor"),
    ('P05 Druck zwischen Anforderung und Ausfuehrung wird nicht erkannt', "        if (sv04c_hb_printer_busy()) { sv04c_hb_finish(false, false); sv04c_hb_state = 0; return false; }", "        if (false) { sv04c_hb_finish(false, false); sv04c_hb_state = 0; return false; }"),
    ('P06 G28-Erfolg ignoriert das P1-Ergebnis "ok" (Z-/X-Fehler gelten als Homing-Erfolg)', "const bool done = allowed && r.seq != sv04c_hb_seq0 && r.completed && r.ok;", "const bool done = allowed && r.seq != sv04c_hb_seq0 && r.completed;"),
    ('P07 G29-Endskript und Zustand danach werden nicht ausgewertet', "r.endscript_ok = end_ok && axis_is_trusted(X_AXIS) && axis_is_trusted(Y_AXIS) && axis_is_trusted(Z_AXIS) && active_extruder == 0;", "r.endscript_ok = true;"),
    ('P08 Touch-Abbruch wird nie angewendet', "if (sv04c_cancel_req) { sv04c_cancel_req = false; sv04c_coord.cancel(); sv04c_hb_cancel_armed(); }", "if (false) { sv04c_cancel_req = false; sv04c_coord.cancel(); sv04c_hb_cancel_armed(); }"),
    ('P09 haengende Queue wird nicht erkannt (Zeitgrenze der Anforderung entfernt)', "if (sv04c_hb_state == 1 && now - sv04c_hb_ms > SV04_CLAUDE_HOME_BEGIN_TIMEOUT_MS)", "if (false && sv04c_hb_state == 1 && now - sv04c_hb_ms > SV04_CLAUDE_HOME_BEGIN_TIMEOUT_MS)"),
    ('P10 Verwurf durch den Koordinator erreicht das Backend nicht', "  if (sid != sv04c_hb_sid) return;\n  if (sv04c_hb_state == 1) {", "  if (true) return;\n  if (sv04c_hb_state == 1) {"),
]
INTEG_SIGNATURE = [('homed=none',), ('homed=none', 'x_early_t1=1'), ('homed=none', 'x_early_t0=1'), ('homed=none', 'stow_fail=1'), ('homed=none', 'x_t1_on_call=2'), ('homed=none', 'queue_stall=1', 'queue_release_s=80', 'tail_s=100', 'limit_s=300'),
                   ('homed=none', 'queue_stall=1', 'queue_release_s=60', 'cancel_at=HOMING_PENDING', 'tail_s=60', 'limit_s=200'), ('homed=none', 'queue_stall=1', 'queue_release_s=100', 'foreign_g28_exec_s=40', 'tail_s=120', 'limit_s=400'),
                   ('homed=none', 'queue_stall=1', 'queue_release_s=45', 'printing_at_s=40', 'tail_s=20', 'limit_s=200'), ('homed=none', 'print_after_homeaxis=2'), ('homed=none', 'kick_after_homeaxis=2', 'kick=40'), ('homed=none', 'touch_after_homeaxis=2'),
                   ('homed=none', 'touch_after_probe=6'), ('homed=none', 'cancel_after_homeaxis=2'), ('homed=none', 'nan_at=9')]
INTEG_KEYS = ('RESULT', 'LOG', 'EE', 'RAM', 'P1RESULT', 'AXES', 'HOMEAXIS', 'STALE', 'CMDS', 'HMI', 'HMIPAGE', 'SERIAL')


def isig(exe):
    return [tuple(B.scenario(exe, *a).get(k, '') for k in INTEG_KEYS) for a in INTEG_SIGNATURE]


class BackendMutants(unittest.TestCase):
    def test_every_production_backend_mutant_changes_observable_behaviour_with_the_real_g28_and_g29(self):
        work = Path(tempfile.mkdtemp(prefix='a60_bmut_'))
        golden = isig(B.build_integ(T.shared()['integ'], 'bgolden', ['SIM_P1_277'], work))
        report, missed = [], []
        for name, old, new in BACKEND_MUTANTS:
            src = Path(tempfile.mkdtemp(prefix='a60_bsrc_'))
            shutil.copytree(ROOT / '02_SOURCE', src / '02_SOURCE')
            f = src / INC
            t = f.read_text(encoding='utf-8')
            self.assertEqual(t.count(old), 1, name)
            f.write_text(t.replace(old, new), encoding='utf-8')
            try:
                exe = B.build_integ(integ_with_source(src / '02_SOURCE'), 'b' + str(abs(hash(name)) % 10**7), ['SIM_P1_277'], work)
                how = 'Verhalten' if isig(exe) != golden else None
            except RuntimeError:
                how = 'Build bricht'
            report.append(f'{name:<95} erkannt: {how}')
            if not how:
                missed.append(name)
        (HERE / 'LAST_MUTATION_REPORT_a60_backend.txt').write_text('\n'.join(report) + '\n', encoding='utf-8')
        self.assertEqual(missed, [], 'UEBERLEBENDE Mutanten:\n' + '\n'.join(report))

if __name__ == '__main__':
    unittest.main(verbosity=2)
