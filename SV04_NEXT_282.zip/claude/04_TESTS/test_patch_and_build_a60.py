"""Struktur des Workflows 277.yml (nie ausgefuehrt: NOT RUN) und seiner Eingaben. Der Workflow wird aus der Vorlage erzeugt (tools/make_workflow_277.py)."""
import hashlib
import re
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
CLAUDE = HERE.parent
PKG = CLAUDE.parent
sys.path.insert(0, str(CLAUDE / 'tools'))
import make_workflow_277 as W  # noqa: E402

OEM = CLAUDE / '01_BASELINE' / 'OEM_FILES' / 'Marlin' / 'src'
DUMMY = '0123456789abcdef' * 4


def yml_text():
    return W.TEMPLATE.replace('@@ZIP_SHA256@@', DUMMY)


def load():
    try:
        import yaml
    except ImportError:
        return None
    return yaml.safe_load(yml_text())


class Workflow(unittest.TestCase):
    def test_B01_workflow_is_valid_manual_only_read_only_and_has_the_two_jobs_and_four_profiles(self):
        d = load()
        if d is None:
            self.skipTest('PyYAML fehlt')
        self.assertIn('workflow_dispatch', d.get(True, d.get('on')))
        self.assertEqual(d['permissions'], {'contents': 'read'})
        self.assertEqual(set(d['jobs']), {'tests', 'build'})
        self.assertEqual(d['jobs']['build']['needs'], 'tests')
        prof = {m['profile']: m for m in d['jobs']['build']['strategy']['matrix']['include']}
        self.assertEqual(set(prof), {'baseline_oem', 'p1_corrections', 'integrated_backend', 'integrated_failclosed'})
        self.assertEqual([prof[p]['stage'] for p in ('baseline_oem', 'p1_corrections', 'integrated_backend', 'integrated_failclosed')], ['none', 'p1', 'integrated', 'integrated'])
        self.assertEqual(prof['integrated_failclosed']['flags'], '-DSV04_CLAUDE_HOME_BACKEND_AVAILABLE=0')
        self.assertTrue(all(prof[p]['flags'] == '' for p in ('baseline_oem', 'p1_corrections', 'integrated_backend')))

    def test_B02_build_steps_run_in_the_required_order(self):
        d = load()
        if d is None:
            self.skipTest('PyYAML fehlt')
        names = [s.get('name', s.get('uses')) for s in d['jobs']['build']['steps']]
        want = ['Verify source package', 'Clone immutable Sovol OEM', 'Verify the OEM files against the shipped reference copies', 'Apply the ChatGPT patch chain 268-276 (unchanged scripts)',
                'Apply 277 (P1 corrections and, for the integrated profiles, the Auto60 integration)', 'Assert that no test double and no foreign build flag is used', 'Install pinned PlatformIO', 'Build STM32 firmware (no upload)']
        pos = [names.index(n) for n in want]
        self.assertEqual(pos, sorted(pos))

    def test_B03_required_evidence_and_safety_markers_are_present_and_no_firmware_is_uploaded(self):
        t = yml_text()
        for need in ('git -C oem diff --check', 'platformio==6.1.18', 'FLASH_ALLOWED=NO', 'HARDWARE_TESTED=NO', 'BUILD_EXIT=$rc', 'SV04_NEXT_277.zip', '1867fcba75354a5c65e0631d6972dd19f1bd6cbe', 'sha256sum -c', 'STM32F103RET6_creality', 'PLATFORMIO_BUILD_FLAGS'):
            self.assertIn(need, t)
        self.assertEqual(re.findall(r'^\s+path: (.*)$', t, re.M), ['evidence/', 'evidence/'], 'nur Logs werden hochgeladen, nie Firmware')
        self.assertNotIn('upload', ' '.join(re.findall(r'platformio run[^\n]*', t)).lower().replace('no upload', ''))
        self.assertNotRegex(t, r'(?m)^\s*(?:-\s*)?(?:export\s+)?SV04_CLAUDE_HOME_BACKEND_EXTERNAL\s*=', 'das Test-Double-Schalter wird nie gesetzt')
        self.assertEqual(t.count('HOME_BACKEND_EXTERNAL'), 1, 'er kommt nur in der Pruefung "assert that no test double" vor')

    def test_B04_the_patch_chain_commands_are_identical_to_chatgpts_276_workflow(self):
        ref = (PKG / 'docs' / '276.yml.referenz').read_text()
        join = lambda t: re.sub(r'\\\n\s*', ' ', t)                           # Zeilenfortsetzungen zusammenziehen
        pat = re.compile(r'^\s*(python3 point1/apply_2(?:68|72|74|75|76)\.py.*)$', re.M)
        norm = lambda x: re.sub(r'\s+', ' ', re.sub(r'\s*\|\s*tee .*', '', x)).strip()
        a = [norm(m) for m in pat.findall(join(ref))]
        b = [norm(m) for m in pat.findall(join(yml_text()))]
        self.assertEqual(len(a), 5)
        self.assertEqual(a, b, 'dieselbe Kette in derselben Reihenfolge mit denselben Argumenten')

    def test_B05_shipped_oem_reference_blobs_in_the_workflow_equal_the_real_files(self):
        t = yml_text()
        for rel, name in (('gcode/calibrate/G28.cpp', 'G28'), ('module/motion.h', 'motion.h'), ('module/motion.cpp', 'motion.cpp'), ('gcode/bedlevel/abl/G29.cpp', 'G29'), ('lcd/e3v2/creality/LCD_RTS.cpp', 'LCD_RTS'), ('gcode/gcode.cpp', 'gcode')):
            b = (OEM / rel).read_bytes()
            blob = hashlib.sha1(b'blob %d\0' % len(b) + b).hexdigest()
            self.assertIn(blob, t, name)

    def test_B06_generator_refuses_an_invalid_sha_and_embeds_a_valid_one(self):
        with self.assertRaises(SystemExit):
            W.main(['--zip-sha256', 'xyz', '--out', str(Path(tempfile.mkdtemp()) / 'x.yml')])
        out = Path(tempfile.mkdtemp()) / '277.yml'
        W.main(['--zip-sha256', DUMMY, '--out', str(out)])
        self.assertIn(DUMMY + '  SV04_NEXT_277.zip', out.read_text()) if False else self.assertIn("ZIP_SHA256: '%s'" % DUMMY, out.read_text())


if __name__ == '__main__':
    unittest.main(verbosity=2)
