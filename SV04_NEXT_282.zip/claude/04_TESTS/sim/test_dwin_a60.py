"""A13-A15 DWIN: VP-Katalog gegen die ECHTE LCD_RTS.h, Frame- und Wertepruefungen gegen den ROHEN Datenstrom der ECHTEN RTS_SndData (woertlich extrahiert, Host-Simulation).
Grenze: die HMI-Binaerdateien (14ShowFile.bin/13TouchFile.bin) liegen NICHT vor: Dezimalstellen, Vorzeichenanzeige, Objekttypen und die HMI-Seite von 0x110E sind NICHT belegt."""
import json
import re
import struct
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(ROOT / 'tools'))
import test_chain_a60 as C  # noqa: E402
import dwin_vp_catalog as K  # noqa: E402

HDR = C.OEM / 'lcd/e3v2/creality/LCD_RTS.h'
OEMG29 = C.OEM / 'gcode/bedlevel/abl/G29.cpp'
ICON, PAGE_ADDR = 0x108D, 0x0084
ALLOWED = {ICON, PAGE_ADDR} | {0x1100 + 2 * k for k in range(16)}


def frames(hexstr):
    b, i, out = bytes.fromhex(hexstr), 0, []
    while i < len(b):
        assert i + 3 < len(b) + 1 and b[i] == 0x5A and b[i + 1] == 0xA5, 'Rahmenkopf bei Byte %d' % i
        ln = b[i + 2]
        assert i + 3 + ln <= len(b), 'Rahmen laenger als der Datenstrom (Byte %d)' % i
        assert b[i + 3] == 0x82, 'Befehl 0x82 (Schreiben) erwartet'
        addr = (b[i + 4] << 8) | b[i + 5]
        words = [(b[i + 6 + 2 * k] << 8) | b[i + 7 + 2 * k] for k in range((ln - 3) // 2)]
        assert (ln - 3) % 2 == 0, 'Datenlaenge muss wortweise sein'
        out.append((addr, words, bytes(b[i:i + 3 + ln])))
        i += 3 + ln
    return out


def s16(w):
    return w - 0x10000 if w & 0x8000 else w


def wire(r):
    return frames(r['WIREHEX'])


def manual(name, *a, g29=None, defines=C.BACKEND):
    return C.run(name, 'manual_g29=1', 'nostart=1', 'boot=0', *a, g29=g29, defines=defines)


class Catalog(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cat = K.build(HDR, ROOT / '01_BASELINE/FIXTURES/OEM_DWIN_16_RECORD_SIGNATURES_187_CORRECTED.json')

    def test_V01_sixteen_mesh_cells_are_unique_even_addresses_in_measurement_order_and_only_the_base_is_defined_in_the_range(self):
        vps = [c['vp'] for c in self.cat['mesh_cells']]
        self.assertEqual(vps, [hex(0x1100 + 2 * k) for k in range(16)])
        self.assertEqual([d['name'] for d in self.cat['defines_inside_mesh_range']], ['AUTO_BED_LEVEL_1POINT_VP'])
        self.assertEqual(self.cat['defines_inside_mesh_range'][0]['addr'], 0x1100)
        self.assertEqual(self.cat['duplicate_addresses'], {}, 'keine Adresse ist in LCD_RTS.h mehrfach vergeben')
        self.assertEqual(self.cat['vp_defines'], 87)

    def test_V02_receive_table_entry_in_the_mesh_range_is_only_changepagekey_0x110E(self):
        rt = self.cat['receive_table']
        self.assertEqual((rt['enum_members'], rt['addrbuf_entries_excl_terminator']), (35, 35))
        self.assertEqual(rt['entries_inside_mesh_range'], [{'index': 34, 'name': 'ChangePageKey', 'addr': '0x110e'}])
        self.assertEqual(self.cat['mesh_cells'][7]['vp'], '0x110e', 'dieselbe Adresse ist Mesh-Zelle k=7 (x=3,y=1)')
        self.assertEqual(self.cat['mesh_cells'][7]['cell_xy'], [3, 1])

    def test_V03_catalog_cell_mapping_equals_the_mapping_observed_when_the_real_g29_runs(self):
        r = manual('chain')
        order = [a for a, w, _ in wire(r) if a in {0x1100 + 2 * k for k in range(16)}]
        self.assertEqual(order, [0x1100 + 2 * k for k in range(16)], 'Schreibreihenfolge auf dem Draht')
        z = r['MESHl']
        for k, (ix, iy) in C.CELL.items():
            self.assertAlmostEqual(z[iy * 4 + ix], C.SCRIPT[k], places=3, msg='Messpunkt %d -> Zelle %s' % (k, (ix, iy)))
            self.assertEqual(self.cat['mesh_cells'][k]['cell_xy'], [ix, iy])

    def test_V04_signature_file_is_transcribed_not_verified_and_flags_stay_open(self):
        sig = self.cat['hmi_signature_file']
        self.assertTrue(sig['source'].startswith('transkribiert'))
        self.assertEqual(len(sig['records']), 16)                  # HMI-Binaerdatei: OFFEN, siehe HARDWARE_ABNAHMEPLAN


class Frames(unittest.TestCase):
    def test_V05_every_frame_in_every_scenario_is_wellformed_and_the_stream_is_fully_consumed(self):
        for args in ([], ['nan_at=9'], ['val_at=5', 'val=12'], ['val_at=5', 'val=45'], ['cancel_at=PROBING'], ['save=3'], ['kick_after_probe=6', 'kick=40']):
            r = C.run('chain', *args)
            self.assertEqual(r['HMIBAD'], '0', str(args))
            fr = wire(r)
            self.assertEqual(sum(len(f[2]) for f in fr), len(bytes.fromhex(r['WIREHEX'])), str(args) + ': kein Rest, keine Prueffelder (Protokoll: Kopf 5A A5, Laenge, 82, Adresse, Daten)')

    def test_V06_progress_icon_counts_1_to_16_and_each_icon_frame_precedes_its_cell_frame(self):
        fr = [f for f in wire(manual('chain')) if f[0] in ALLOWED - {PAGE_ADDR}]
        icons = [f[1][0] for f in fr if f[0] == ICON]
        self.assertEqual(icons, list(range(1, 17)), 'OEM-Fortschritt 1..16 (showcount)')
        for i in range(16):
            self.assertEqual((fr[2 * i][0], fr[2 * i + 1][0]), (ICON, 0x1100 + 2 * i))

    def test_V07_auto60_writes_only_icon_mesh_cells_and_page_switch_never_other_vps(self):
        for args in ([], ['nan_at=9'], ['cancel_at=PROBING'], ['val_at=5', 'val=12'], ['save=1']):
            addrs = {f[0] for f in wire(C.run('chain', *args))}
            self.assertLessEqual(addrs, ALLOWED, str(args) + ': nichts ausser Fortschritts-Icon 0x108D, den 16 Mesh-Zellen und dem Seitenwechsel 0x0084')

    def test_V08_page_done_is_shown_only_on_success_never_on_failure_or_cancel(self):
        done = bytes([0x5A, 0xA5, 0x07, 0x82, 0x00, 0x84, 0x5A, 0x01, 0x00, 0x16])
        for args, ok in (([], True), (['nan_at=9'], False), (['cancel_at=PROBING'], False), (['val_at=5', 'val=12'], False), (['save=1'], False), (['save=3'], False), (['kick_after_probe=6', 'kick=40'], False)):
            raw = bytes.fromhex(C.run('chain', *args)['WIREHEX'])
            self.assertEqual(done in raw, ok, str(args))

    def test_V09_restoring_the_display_sends_exactly_the_oem_boot_loop_bytes(self):
        r = C.run('chain', 'cancel_at=PROBING')
        raw, boot_len = bytes.fromhex(r['WIREHEX']), int(r['BOOTLEN'].split()[0]) if False else int(r['BOOTLEN'])
        boot = raw[:boot_len]
        icon0 = bytes([0x5A, 0xA5, 0x05, 0x82, 0x10, 0x8D, 0x00, 0x00]); fail = bytes([0x5A, 0xA5, 0x07, 0x82, 0x00, 0x84, 0x5A, 0x01, 0x00, 0x1C])
        self.assertEqual(boot_len, 16 * 8)
        self.assertTrue(raw.endswith(boot + icon0 + fail), 'Wiederherstellung == OEM-Bootschleife (byte-genau), danach Icon 0 und Fehlerseite')
        self.assertEqual(r['HMIl'], r['HMI0l'])


class Values(unittest.TestCase):
    VALID = [(-0.1096, -109), (0.9999, 999), (-0.0004, 0), (0.0, 0), (29.999, 29999), (-29.999, -29999), (30.0, 30000), (-30.0, -30000), (1.0, 1000), (0.001, 1)]

    def test_V10_valid_values_are_truncated_toward_zero_signed_16bit_and_identical_to_the_unmodified_oem(self):
        for val, exp in self.VALID:
            a = manual('chain', 'val_at=5', 'val=%s' % val)
            b = manual('oem', 'val_at=5', 'val=%s' % val, g29=OEMG29)
            cell = [f for f in wire(a) if f[0] == 0x110A]
            self.assertEqual(len(cell), 1)
            self.assertEqual(s16(cell[0][1][0]), exp, 'z=%s' % val)
            self.assertEqual(a['WIREHEX'], b['WIREHEX'], 'z=%s: Draht byte-identisch zum OEM' % val)
            self.assertEqual((a['HMIBAD'], a['HMIMULTI']), ('0', '0'))

    def test_V11_negative_values_are_twos_complement_words(self):
        cell = [f for f in wire(manual('chain', 'val_at=5', 'val=-0.1096')) if f[0] == 0x110A][0]
        self.assertEqual(cell[1][0], 0xFF93)
        self.assertEqual(cell[2].hex().upper(), '5AA50582110AFF93')

    def test_V12_invalid_values_never_produce_a_wrong_frame_in_the_patched_build(self):
        for val in ('30.0001', '-30.0001', '45', '-45', '70', 'inf', '-inf'):
            r = manual('chain', 'val_at=5', 'val=%s' % val)
            self.assertEqual((r['HMIBAD'], r['HMIMULTI']), ('0', '0'), val + ': nie ein 2-Wort-Rahmen')
            self.assertEqual(r['HMIl'][5], int(C.f32(C.OLD[5] * 1000)), val + ': Display zeigt nach der Ablehnung den ALTEN Wert (Wiederherstellung)')
            self.assertTrue(C.near(r['MESHl'], C.OLD), val + ': Lauf abgelehnt, altes Mesh wiederhergestellt')
            live5 = [f for f in wire(r)[:34] if f[0] == 0x110A]
            self.assertEqual(live5, [], val + ': kein Live-Rahmen fuer den ungueltigen Messpunkt')

    def test_V13_the_unmodified_oem_shows_the_defects_the_guard_prevents(self):
        r45 = manual('oem', 'val_at=5', 'val=45', g29=OEMG29)
        self.assertEqual(s16([f for f in wire(r45) if f[0] == 0x110A][0][1][0]), -20536, 'OEM: 45 mm erscheint als -20536')
        r70 = manual('oem', 'val_at=5', 'val=70', g29=OEMG29)
        self.assertEqual(r70['HMIMULTI'], '1', 'OEM: 70 mm erzeugt einen 2-Wort-Rahmen, der die Folgeadresse beschreibt')


if __name__ == '__main__':
    unittest.main(verbosity=2)
