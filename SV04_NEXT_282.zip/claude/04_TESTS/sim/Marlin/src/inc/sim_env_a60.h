#pragma once
// HOST-SIMULATION der Marlin-Umgebung fuer die ECHTE G29.cpp. Alles hier ist STUB/Simulation, nicht OEM-Code. Steuerung durch Tests ueber SimWorld W.
#include <math.h>
#include <stdint.h>
#include <map>
#include <set>
#include <string>
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include "../core/types.h"

typedef const char *PGM_P;
#define PSTR(s) (s)
#define STRINGIFY_(M) #M
#define STRINGIFY(M) STRINGIFY_(M)
#define SP_X_STR " X"
#define SP_Y_STR " Y"
#define SP_Z_STR " Z"
#define S_FMT "%s"
#define MSG_PROBING_POINT 0
#define GET_TEXT(x) ""
#define RAW_X_POSITION(x) (x)
#define RAW_Y_POSITION(y) (y)
#define RAW_Z_POSITION(z) (z)
#define MMM_TO_MMS(x) ((x) / 60.0f)
#define XY_PROBE_FEEDRATE 4000
#define X_CENTER 151
#define Y_CENTER 151
#define NOMORE(v, n) do { if ((v) > (n)) (v) = (n); } while (0)
#define NOLESS(v, n) do { if ((v) < (n)) (v) = (n); } while (0)
#ifndef constrain
  #define constrain(v, lo, hi) ((v) < (lo) ? (lo) : ((v) > (hi) ? (hi) : (v)))
#endif
#ifndef FLOOR
  #define FLOOR(x) floorf(x)
#endif
#define DEBUGGING(x) (false)
#define DEBUG_SECTION(...)
#define DEBUG_POS(...)
#define DEBUG_ECHOLNPGM(...)
#define DEBUG_ECHOPGM(...)
#define DEBUG_ECHOLNPGM_P(...)
#define DEBUG_ECHO_START()
#define SERIAL_EOL() sim_serial_eol()
#define SERIAL_ECHOLNPGM(...) sim_serial(__VA_ARGS__), sim_serial_eol()
#define SERIAL_ECHOPGM(...) sim_serial(__VA_ARGS__)
#define SERIAL_ECHOPGM_P(...) sim_serial(__VA_ARGS__)
#define SERIAL_ECHOPAIR_F(...) sim_serial(__VA_ARGS__)
#define SERIAL_ECHO_F(...) sim_serial(__VA_ARGS__)
#define SERIAL_ECHO_SP(n) sim_serial(" ")
#define SERIAL_ERROR_MSG(...) (sim_serial("ERR:"), sim_serial(__VA_ARGS__), sim_serial_eol())
#define SERIAL_ECHO_MSG(...) (sim_serial(__VA_ARGS__), sim_serial_eol())

// ---------- Welt ----------
enum ProbePtRaise : uint8_t { PROBE_PT_NONE, PROBE_PT_STOW, PROBE_PT_RAISE };
enum { M_IDLE, M_PROBE };
typedef float feedRate_t_sim;

struct SimWorld {
  // Test-Eingaben
  bool homed = true;
  std::map<char, float> params;                 // G-Code-Parameter (Buchstabe -> Wert; 1e30 = ohne Wert)
  std::vector<float> probe_script;              // Messwerte in Probenreihenfolge (NAN = BLTouch-Fehler)
  bool deploy_fail = false, stow_fail = false, bltouch_alarm = false;      // probe.deploy()/stow() bzw. bltouch.deploy() liefern true = Alarm (wie im Original)
  int x_early_t1 = 0, x_early_t0 = 0;                // homeaxis(X) kehrt frueh zurueck (T1/T0): Abschlussflag wird NICHT gesetzt
  int kill_x_t1 = 0, kill_x_t0 = 0, kill_z = 0, kill_y = 0;   // Endschalter nicht ausgeloest -> validate_homing_move() -> kill() (kehrt nie zurueck)
  int homeaxis_calls = 0, x_t1_calls = 0, x_t1_on_call = 0;
  uint32_t homeaxis_ms = 0;                          // simulierte Dauer je homeaxis()   // x_t1_on_call=N: homeaxis(X) von T1 kehrt NUR beim N-ten Aufruf frueh zurueck
  float probe_min_x = 25, probe_max_x = 277, probe_min_y = 25, probe_max_y = 277;
  bool bounds_ok = true;
  bool m420_noop = false;                              // Testschalter: Aktivierung der Nivellierung (set_bed_leveling_enabled(true)) bleibt wirkungslos
  uint32_t probe_ms = 1500; bool paused = false;       // Dauer je Messpunkt (simulierte Zeit) / SD-Pause
  // Zustand/Protokoll
  std::vector<std::string> cmds;                // Bewegungs-/Heiz-/G-Code-Aufrufe in Reihenfolge
  std::vector<std::string> serial;
  std::string serial_line;
  std::vector<uint8_t> wire;                    // Bytes, die LCD_SERIAL.write() erhalten hat
  int probe_calls = 0, eeprom_saves = 0, heat_cmds = 0, tool_changes = 0;
  std::vector<std::string> trace;               // alles in einer Zeitleiste (fuer Differenztests)
  void log(const std::string &s) { cmds.push_back(s); trace.push_back(s); }
  void reset();
};
extern SimWorld W;
extern uint8_t active_extruder;

void sim_serial_eol();
inline void sim_serial_one(const char *s) { W.serial_line += s; }
inline void sim_serial_one(int v) { W.serial_line += std::to_string(v); }
inline void sim_serial_one(unsigned v) { W.serial_line += std::to_string(v); }
inline void sim_serial_one(long v) { W.serial_line += std::to_string(v); }
inline void sim_serial_one(unsigned long v) { W.serial_line += std::to_string(v); }
inline void sim_serial_one(double v) { W.serial_line += std::to_string(v); }
inline void sim_serial() {}
template <typename T, typename... R> inline void sim_serial(T a, R... r) { sim_serial_one(a); sim_serial(r...); }

struct GcodeParser {
  bool seen(char c) const { return W.params.count(c) > 0; }
  bool seen_test(char c) const { return seen(c); }
  bool seenval(char c) const { return seen(c) && W.params.at(c) < 1e29f; }
  float value(char c) const { return seenval(c) ? W.params.at(c) : 0; }
  bool boolval(char c, bool dflt = false) const { return seen(c) ? (W.params.at(c) >= 1e29f || W.params.at(c) != 0) : dflt; }
  int intval(char c, int dflt = 0) const { return seenval(c) ? (int)W.params.at(c) : dflt; }
  uint8_t byteval(char c, uint8_t dflt = 0) const { return seenval(c) ? (uint8_t)W.params.at(c) : dflt; }
  float linearval(char c, float dflt = 0) const { return seenval(c) ? W.params.at(c) : dflt; }
  float value_linear_units() const { return 0; }
  int value_int() const { return seenval('S') ? (int)W.params.at('S') : 0; }   // Stub: liefert den S-Parameter (nur M1060 nutzt ihn)
};
extern GcodeParser parser;

extern void (*sim_idle_hook)();
struct Planner {
  bool leveling_active = false;
  bool has_blocks_queued() const { return false; }
  void synchronize() { W.log("planner.synchronize"); if (sim_idle_hook) sim_idle_hook(); }     // wie Marlin: synchronize() ruft idle()
};
extern Planner planner;

extern void sim_probe_time_hook();
struct Probe {
  xy_pos_t offset_xy = { 0, 25 };
  struct { float z = -1.10f; } offset;                // Z-Offset (Sim-Vorgabe; nicht hartkodiert verwendet, nur Startwert der Simulation)
  float min_x() const { return W.probe_min_x; }
  float max_x() const { return W.probe_max_x; }
  float min_y() const { return W.probe_min_y; }
  float max_y() const { return W.probe_max_y; }
  bool good_bounds(const xy_pos_t &, const xy_pos_t &) const { return W.bounds_ok; }
  bool deploy() { W.log("probe.deploy"); return W.deploy_fail; }
  bool stow() { W.log("probe.stow"); return W.stow_fail; }          // true = Fehler (wie im Original)
  float probe_at_point(const xy_pos_t &p, const ProbePtRaise, const uint8_t) {
    char b[64]; snprintf(b, sizeof b, "probe_at_point %.1f %.1f", (double)p.x, (double)p.y); W.log(b);
    sim_probe_time_hook();                              // Messung dauert; waehrenddessen laeuft idle() (re-entranter Auto60-Tick)
    const size_t i = (size_t)W.probe_calls++;
    return i < W.probe_script.size() ? W.probe_script[i] : NAN;
  }
  void move_z_after_probing() { W.log("probe.move_z_after_probing"); }
  void move_z_after_homing() { W.log("probe.move_z_after_homing"); }
};
extern Probe probe;

extern xy_pos_t bilinear_grid_spacing, bilinear_start;
extern xy_float_t bilinear_grid_factor;
extern xyze_pos_t current_position;
extern float xy_probe_feedrate_mm_s;
typedef int8_t sim_axes_bits_t;
void process_subcommands_now_P(PGM_P);
void remember_feedrate_scaling_off();
void restore_feedrate_and_scaling();
void sync_plan_position();
void report_current_position();
void reset_stepper_timeout();
void idle_no_sleep();
void do_z_clearance(const float);
void do_blocking_move_to_z(const float);
long random(long, long);
struct GcodeSuite { static void G28(); static void G29(); };
void extrapolate_unprobed_bed_level();
void print_bilinear_leveling_grid();
void refresh_bed_level();
bool leveling_is_valid();
void set_bed_leveling_enabled(const bool enable);
void reset_bed_level();
float bilinear_z_offset(const xy_pos_t &raw);

// Stubs fuer Dinge, die unsere Patches NICHT aufrufen duerfen: jeder Aufruf wird sichtbar protokolliert (Beweis "keine EEPROM-/M420-Wirkung").
struct SimSettings { bool save() { W.eeprom_saves++; W.log("settings.save"); return true; } };
struct SimQueue { void enqueue_now_P(PGM_P s) { W.log(std::string("enqueue:") + s); } };



// ======================= Erweiterung fuer die Auto60-Kettensimulation (Stubs; kein OEM-Code) =======================
#include <deque>
extern uint32_t sim_ms;
inline unsigned long millis() { return sim_ms; }
#define SERIAL_ECHO_START() sim_serial("echo:")
#define SERIAL_ECHO(...) sim_serial(__VA_ARGS__)
struct SimBed { float celsius = 25; int16_t target = 0; };
struct SimThermal { SimBed temp_bed; void setTargetBed(const int16_t c); };
extern SimThermal thermalManager;
struct SimCard { bool printing = false; bool isPrinting() const { return printing; } };
extern SimCard card;
extern int PrintFlag; extern bool PoweroffContinue, pause_action_flag; bool printingIsPaused();
enum DualXMode : char { DXC_FULL_CONTROL_MODE, DXC_AUTO_PARK_MODE, DXC_DUPLICATION_MODE, DXC_MIRRORED_MODE };
extern DualXMode dual_x_carriage_mode; extern bool extruder_duplication_enabled;
struct SimQueue2 { std::deque<std::string> q; bool has_commands_queued() const { return !q.empty(); } void enqueue_now_P(PGM_P s) { q.push_back(s); } };
extern SimQueue2 queue2;
#define queue queue2
struct SimSettings2 { bool save(); bool load(); bool validate(); uint16_t datasize() { return 800; } };
extern SimSettings2 settings2;
#define settings settings2
