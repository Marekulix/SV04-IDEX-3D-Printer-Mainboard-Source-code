"""Reproduzierbare Pipeline fuer ALLE Tests: fuehrt die ECHTEN Patchskripte (268, 272, 274, 275, 276 von ChatGPT, unveraendert; dann 277 Stufe 1 und Stufe 2) auf den OEM-Dateien aus.
Stand 276 = OEM + 268..276 | Stand p1 = 276 + apply_277_p1.py | Stand integ = p1 + Claude-Overlay (G29/LCD/gcode/G28-Waechter + neue Dateien)."""
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
CLAUDE = HERE.parents[1]                  # .../claude
PKG = CLAUDE.parent                       # Paketwurzel mit apply_268.py ... apply_277_p1.py
OEM = CLAUDE / '01_BASELINE' / 'OEM_FILES' / 'Marlin' / 'src'
G28 = Path('Marlin/src/gcode/calibrate/G28.cpp')
MOTION = (Path('Marlin/src/module/motion.h'), Path('Marlin/src/module/motion.cpp'))
_CACHE = {}


def _run(args, cwd=None):
    r = subprocess.run([sys.executable, *map(str, args)], cwd=str(cwd or PKG), capture_output=True, text=True)
    if r.returncode:
        raise RuntimeError(' '.join(map(str, args)) + '\n' + r.stdout + r.stderr)
    return r.stdout


def tree276(dest):
    dest = Path(dest)
    if dest.exists():
        shutil.rmtree(dest)
    for rel in (G28, *MOTION):
        (dest / rel).parent.mkdir(parents=True, exist_ok=True)
        shutil.copy(OEM.parent.parent / rel, dest / rel)
    g = dest / G28
    _run(['apply_268.py', g, '--verify-oem', '--out', str(g) + '.p']); Path(str(g) + '.p').replace(g)
    _run(['apply_272.py', g, '--out', str(g) + '.p']); Path(str(g) + '.p').replace(g)
    _run(['apply_274.py', '--root', dest])
    _run(['apply_275.py', g])
    _run(['apply_276.py', '--root', dest])
    return dest


def tree_p1(dest):
    dest = tree276(dest)
    _run(['apply_277_p1.py', '--root', dest])
    return dest


def claude_out(p1_tree, out, source_root=None):
    """Stufe 2: Overlay auf die ECHTEN OEM-Dateien (G29/LCD/gcode) und den gehaerteten G28 -> out (nur geaenderte + neue Dateien)."""
    sys.path.insert(0, str(CLAUDE / '03_PATCHES'))
    import apply_claude_parallel as P
    out = Path(out)
    if out.exists():
        shutil.rmtree(out)
    P.run(OEM / 'lcd/e3v2/creality/LCD_RTS.cpp', OEM / 'gcode/bedlevel/abl/G29.cpp', OEM / 'gcode/gcode.cpp', out, source_root or (CLAUDE / '02_SOURCE'), g28=Path(p1_tree) / G28)
    return out


def integ(dest, source_root=None):
    p1 = tree_p1(Path(dest) / 'p1')
    co = claude_out(p1, Path(dest) / 'claude_out', source_root)
    full = Path(dest) / 'integ'
    shutil.copytree(p1, full)
    for f in co.rglob('*'):
        if f.is_file():
            t = full / f.relative_to(co)
            t.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy(f, t)
    return {'p1': p1, 'claude_out': co, 'integ': full}


def shared():
    """Einmal je Prozess: {'t276': ..., 'p1': ..., 'claude_out': ..., 'integ': ...}"""
    if 'all' not in _CACHE:
        base = Path(tempfile.mkdtemp(prefix='chain_'))
        d = integ(base)
        d['t276'] = tree276(base / 't276')
        _CACHE['all'] = d
    return _CACHE['all']
