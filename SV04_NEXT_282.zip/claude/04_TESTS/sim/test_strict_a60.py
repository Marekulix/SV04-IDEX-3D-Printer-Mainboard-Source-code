"""A17/A18 (Host): strenge Uebersetzung MEINES Codes (-Wall -Wextra -Werror; OEM-/Simulationsheader als System-Header ausgenommen), Konfigurationsmatrix, keine neuen Warnungen an der ECHTEN G29.cpp,
Speicherbedarf und embedded-Disziplin. Das ist KEIN STM32-Build (BLOCKED: keine ARM-Toolchain)."""
import itertools
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(HERE))
import test_chain_a60 as C  # noqa: E402
import build_sim_a60 as B  # noqa: E402
import chain_tree as T  # noqa: E402

SIM = HERE
SRC = ROOT / '02_SOURCE'


def tree_for(defs_name):
    tr = C.tree()
    t = Path(tempfile.mkdtemp(prefix='a60_strict_'))
    shutil.copytree(SIM / 'Marlin', t / 'Marlin')
    po = tr / 'Marlin' / 'src'
    for f in po.rglob('*'):
        if f.is_file() and f.name not in ('LCD_RTS.cpp', 'gcode.cpp', 'motion.cpp', 'motion.h'):
            dst = t / 'Marlin' / 'src' / f.relative_to(po)
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy(f, dst)
    po_mod = tr / 'Marlin' / 'src' / 'module'
    subprocess.run([sys.executable, str(SIM / 'extract_p1_a60.py'), '--motion-h', str(po_mod / 'motion.h'), '--motion-cpp', str(po_mod / 'motion.cpp'), '--out', str(t / 'Marlin' / 'src' / 'inc')], check=True, capture_output=True)
    return t


def drv(t):
    d = t / 'drv'
    d.mkdir(exist_ok=True)
    shutil.copy(SIM / 'driver_chain.cpp', d / 'driver_chain.cpp')       # eigener Ordner: Quell-Includes finden die Simulationsheader NUR ueber -isystem (sonst waeren sie keine System-Header)
    return str(d / 'driver_chain.cpp')


def strict_cmd(t, defs):
    sysinc = ['-isystem', str(t), '-isystem', str(t / 'Marlin' / 'src'), '-isystem', str(SIM), '-isystem', str(SIM / 'stubs')]
    mine = ['-I', str(t / 'Marlin' / 'src' / 'lcd' / 'e3v2' / 'creality'), '-I', str(t / 'Marlin' / 'src' / 'feature' / 'sv04_claude_auto60')]
    return ['g++', '-std=gnu++14', '-fsyntax-only', '-Wall', '-Wextra', '-Werror', *sysinc, *mine, *[f'-D{d}' for d in defs]]


class Strict(unittest.TestCase):
    def test_X01_core_and_session_headers_compile_strictly_as_c11_plus_pedantic(self):
        for hdr in ('sv04_claude_auto60_core.h', 'sv04_claude_g29_session.h'):
            src = Path(tempfile.mkdtemp()) / 't.cpp'
            src.write_text('#include "%s"\nint main(){return 0;}\n' % hdr)
            r = subprocess.run(['g++', '-std=c++11', '-Wall', '-Wextra', '-Werror', '-pedantic', '-I', str(SRC / 'Marlin/src/feature/sv04_claude_auto60'), str(src), '-fsyntax-only'], capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, hdr + '\n' + r.stderr[-1500:])

    def test_X02_the_adapter_compiles_strictly_in_all_configuration_combinations(self):
        t = tree_for('strict')
        combos = list(itertools.product((0, 1), repeat=4))            # ROLLBACK, RESEND, GUARD_LIVE, BACKEND
        self.assertEqual(len(combos), 16)
        for rb, rs, gl, be in combos:
            defs = [f'SV04_CLAUDE_G29_ROLLBACK={rb}', f'SV04_CLAUDE_G29_RESEND={rs}', f'SV04_CLAUDE_G29_GUARD_LIVE={gl}', f'SV04_CLAUDE_HOME_BACKEND_AVAILABLE={be}', 'SIM_A60']
            r = subprocess.run(strict_cmd(t, defs) + [drv(t)], capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, f'ROLLBACK={rb} RESEND={rs} GUARD_LIVE={gl} BACKEND={be}\n{r.stderr[-1800:]}')

    def test_X03_auto60_disabled_compiles_strictly_and_keeps_the_g29_hooks(self):
        t = tree_for('strict')
        r = subprocess.run(strict_cmd(t, ['SIM_A60', 'SV04_CLAUDE_AUTO60_ENABLE=0']) + [drv(t)], capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stderr[-1800:])

    def test_X04_the_patch_adds_no_compiler_warnings_to_the_real_g29(self):
        t = tree_for('warn')
        counts = {}
        for name, data in (('base', (C.OEM / 'gcode/bedlevel/abl/G29.cpp').read_bytes()), ('patched', (C.tree() / 'Marlin/src/gcode/bedlevel/abl/G29.cpp').read_bytes())):
            g = t / 'Marlin' / 'src' / 'gcode' / 'bedlevel' / 'abl' / f'G29_{name}.cpp'
            g.write_bytes(data)
            r = subprocess.run(['g++', '-std=gnu++14', '-fsyntax-only', '-Wall', '-Wextra', '-isystem', str(t), '-I', str(t / 'Marlin' / 'src'), '-isystem', str(SIM), '-isystem', str(SIM / 'stubs'), '-DSV04_CLAUDE_HOME_BACKEND_AVAILABLE=1', '-DSIM_A60', str(g)], capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, r.stderr[-1000:])
            counts[name] = len([l for l in r.stderr.splitlines() if 'G29' in l and 'warning' in l])
        self.assertLessEqual(counts['patched'], counts['base'], f'neue Warnungen durch den Patch: {counts}')

    def test_X07_the_277_changes_add_no_compiler_warnings_to_the_real_g28(self):
        """G28.cpp wird MIT den extrahierten P1-Bloecken uebersetzt (Stand 276 und Stand integriert); Warnungen in G28.cpp werden gezaehlt."""
        counts = {}
        for name, root, defs in (('t276', T.shared()['t276'], []), ('integ', T.shared()['integ'], ['SIM_P1_277'])):
            t = Path(tempfile.mkdtemp(prefix='a60_g28warn_'))
            shutil.copytree(SIM / 'Marlin', t / 'Marlin')
            for f in (root / 'Marlin' / 'src').rglob('*'):
                if f.is_file() and f.name not in ('LCD_RTS.cpp', 'gcode.cpp', 'motion.cpp', 'motion.h'):
                    d = t / 'Marlin' / 'src' / f.relative_to(root / 'Marlin' / 'src')
                    d.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy(f, d)
            subprocess.run([sys.executable, str(SIM / 'extract_p1_a60.py'), '--motion-h', str(root / 'Marlin/src/module/motion.h'), '--motion-cpp', str(root / 'Marlin/src/module/motion.cpp'), '--out', str(t / 'Marlin/src/inc')], check=True, capture_output=True)
            g = t / 'Marlin' / 'src' / 'gcode' / 'calibrate' / 'G28.cpp'
            r = subprocess.run(['g++', '-std=gnu++14', '-fsyntax-only', '-Wall', '-Wextra', '-isystem', str(t), '-I', str(t / 'Marlin' / 'src'), '-I', str(t / 'Marlin/src/lcd/e3v2/creality'), '-I', str(t / 'Marlin/src/feature/sv04_claude_auto60'), '-isystem', str(SIM), '-isystem', str(SIM / 'stubs'), *[f'-D{x}' for x in defs], str(g)], capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, r.stderr[-1500:])
            counts[name] = len([l for l in r.stderr.splitlines() if 'G28.cpp' in l and 'warning' in l])
        self.assertLessEqual(counts['integ'], counts['t276'], f'neue Warnungen: {counts}')

    def test_X05_my_sources_use_no_heap_exceptions_rtti_stl_or_printf(self):
        for f in (SRC / 'Marlin/src/feature/sv04_claude_auto60/sv04_claude_auto60_core.h', SRC / 'Marlin/src/feature/sv04_claude_auto60/sv04_claude_g29_session.h', SRC / 'Marlin/src/lcd/e3v2/creality/sv04_claude_auto60_marlin.inc', SRC / 'Marlin/src/lcd/e3v2/creality/sv04_claude_hooks.h'):
            code = re.sub(r'//[^\n]*', '', re.sub(r'/\*.*?\*/', '', f.read_text(), flags=re.S))
            code = re.sub(r'"(?:\\.|[^"\\])*"', '""', code)
            for tok in (r'\bmalloc\b', r'\bnew\b', r'\bdelete\b', r'\bthrow\b', r'\btry\b', r'\bcatch\b', r'std::', r'\bprintf\b', r'\bvector\s*<', r'\bString\b', r'dynamic_cast', r'typeid', r'\bvirtual\b'):
                self.assertIsNone(re.search(tok, code), f'{f.name}: {tok}')

    def test_X06_static_ram_of_the_coordinator_and_session_is_small(self):
        src = Path(tempfile.mkdtemp()) / 't.cpp'
        src.write_text('#include "sv04_claude_auto60_core.h"\n#include "sv04_claude_g29_session.h"\n#include <stdio.h>\nint main(){printf("%u %u %u %u\\n",(unsigned)sizeof(sv04c::Coordinator),(unsigned)sizeof(sv04c::MeshSession),(unsigned)sizeof(sv04g29::Session),(unsigned)sizeof(sv04c::Config));}\n')
        exe = src.parent / 't'
        subprocess.run(['g++', '-std=c++11', '-I', str(SRC / 'Marlin/src/feature/sv04_claude_auto60'), str(src), '-o', str(exe)], check=True)
        coord, mesh, sess, cfg = map(int, subprocess.run([str(exe)], capture_output=True, text=True).stdout.split())
        print('SIZEOF (Host, 64-bit; auf dem 32-Bit-STM32 kleiner): Coordinator=%d MeshSession=%d g29::Session=%d Config=%d' % (coord, mesh, sess, cfg))
        self.assertLessEqual(coord, 2048)
        self.assertLessEqual(coord + sess, 2560, 'statischer RAM beider Objekte (Host-Groesse, obere Schranke)')


if __name__ == '__main__':
    unittest.main(verbosity=2)
