// KETTENSIMULATION: bedient den ECHTEN Auto60-Adapter + Koordinator + die ECHTE gepatchte G29.cpp + echte RTS_SndData. Auto60 wird NUR ueber M1060 und die Queue bedient.
#include "Marlin/src/inc/MarlinConfig.h"
#include "Marlin/src/feature/bedlevel/abl/abl.h"
#include "Marlin/src/lcd/e3v2/creality/LCD_RTS.h"
#include "sim_hmi_a60.h"
#include "sv04_claude_hooks.h"
#include "sv04_claude_auto60_core.h"
#include "sv04_claude_g29_session.h"
void sim_oem_boot_mesh_send();
extern RTSSHOW rtscheck; extern char waitway; extern void (*sim_idle_hook)();
extern int sim_save_mode; extern bool sim_readback_unavailable; void sim_ee_init_from_ram();
struct Ee2 { bool header_ok; char ver[4]; float z[4][4]; float sp[2], st[2], fa[2]; float zoff; bool lev; unsigned saves, bytes, loads, validates; };
extern Ee2 g_ee;
#include "sv04_claude_auto60_marlin.inc"          // GENAU die Datei, die in LCD_RTS.cpp eingebunden wird
#if SV04_CLAUDE_AUTO60_ENABLE && ENABLED(EEPROM_SETTINGS)
  #define A60_STATE_NAME() sv04c::state_name(sv04c_coord.state())
  #define A60_TERMINAL() sv04c_coord.terminal()
  #define A60_REPORT() { sv04c::TransitionRec r; printf("RESULT state=%s reason=%s sid=%u\n", sv04c::state_name(sv04c_coord.state()), sv04c::reason_name(sv04c_coord.reason()), sv04c_coord.session()); printf("LOG"); for (int i = (int)sv04c_coord.log_count() - 1; i >= 0; i--) if (sv04c_coord.log_at((unsigned)i, r)) printf(" %s>%s(%s)", sv04c::state_name(r.from), sv04c::state_name(r.to), sv04c::reason_name(r.why)); printf("\n"); }
#else
  #define A60_STATE_NAME() "IDLE"
  #define A60_TERMINAL() false
  #define A60_REPORT() { printf("RESULT state=IDLE reason=NONE sid=0\nLOG\n"); }
#endif
#include <map>
#include <algorithm>
#include <string.h>

static std::map<std::string, std::string> opt;
static std::string gs(const char *k, const char *d) { auto i = opt.find(k); return i == opt.end() ? d : i->second; }
static int gi(const char *k, int d) { auto i = opt.find(k); return i == opt.end() ? d : atoi(i->second.c_str()); }
static float gf(const char *k, float d) { auto i = opt.find(k); return i == opt.end() ? d : (float)atof(i->second.c_str()); }
#ifdef SV04_CLAUDE_HOME_BACKEND_EXTERNAL     // NUR Host-Test: externes Test-Double statt des Produktions-Backends
static uint32_t home_due = 0, home_sid_p = 0; static bool home_pending = false; static std::string home_mode = "ok";
bool SV04Claude_HomeBackendRequest(const uint32_t sid) { W.log("home_request sid=" + std::to_string(sid)); if (home_mode == "reject") return false; home_pending = true; home_sid_p = sid; home_due = sim_ms + (uint32_t)gi("home_ms", 4000); return true; }
static void service_home() {
  if (!home_pending || sim_ms < home_due || home_mode == "never") return;
  home_pending = false;
  if (home_mode == "wrongext") active_extruder = 1;
  if (home_mode == "noz") set_axis_untrusted(Z_AXIS);
  if (home_mode == "zoffs") probe.offset.z += 0.05f;
  SV04Claude_Auto60_HomeResult(home_sid_p, home_mode != "fail", home_mode != "nogate");
}
#else
static std::string home_mode = "ok"; static void service_home() {}
#endif
static void run_queue() {
  while (!queue2.q.empty()) {
    const std::string c = queue2.q.front(); queue2.q.pop_front();
    if (c == "G29") { W.log("exec G29"); GcodeSuite::G29(); } else W.log("exec " + c);
  }
}
static void bed_model() {
  const float tgt = (float)thermalManager.temp_bed.target; const std::string m = gs("heat", "normal");
  if (m == "nan") { thermalManager.temp_bed.celsius = NAN; return; }
  if (m == "stuck") return;
  if (tgt > 0) thermalManager.temp_bed.celsius += (tgt - thermalManager.temp_bed.celsius) * 0.08f; else thermalManager.temp_bed.celsius += (25 - thermalManager.temp_bed.celsius) * 0.02f;
}
static bool kicked = false;
static void tick_all() {      // = idle() -> RTSUpdate() -> Tick; laeuft auch WAEHREND der G29 (re-entrant, durch die Sperre im Adapter geschuetzt)
  if (gi("kick_after_probe", -1) >= 0 && !kicked && W.probe_calls >= gi("kick_after_probe", 0)) { thermalManager.temp_bed.celsius = gf("kick", 40); kicked = true; }
  SV04Claude_Auto60_Tick();
}
static void cmd(const char *s, float p) { W.params.clear(); W.params['S'] = p; (void)s; SV04Claude_Auto60_Gcode(); }

int main(int argc, char **argv) {
  for (int i = 1; i < argc; i++) { std::string a = argv[i]; size_t e = a.find('='); if (e == std::string::npos) opt[a] = "1"; else opt[a.substr(0, e)] = a.substr(e + 1); }
  W.reset(); axis_homed = axis_trusted = 7; sim_ms = 100000; sim_idle_hook = tick_all; home_mode = gs("home", "ok");
  planner.leveling_active = gi("lev0", 1) != 0;
  for (int x = 0; x < 4; x++) for (int y = 0; y < 4; y++) z_values[x][y] = 0.31f - 0.05f * x + 0.02f * y;   // "altes" Mesh (EEPROM + RAM)
  bilinear_grid_spacing.set(84, 84); bilinear_start.set(25, 25); bilinear_grid_factor = bilinear_grid_spacing.reciprocal();
  probe.offset.z = gf("zoff", -1.10f); thermalManager.temp_bed.celsius = gf("bed0", 25); thermalManager.temp_bed.target = (int16_t)gi("target0", 0);
  sim_ee_init_from_ram(); const Ee2 ee0 = g_ee; const float z0 = probe.offset.z; sim_save_mode = gi("save", 0); sim_readback_unavailable = gi("noreadback", 0) != 0;
  W.m420_noop = gi("m420_noop", 0) != 0; W.probe_ms = (uint32_t)gi("probe_ms", 1500); W.homed = true; card.printing = gi("printing", 0) != 0; W.paused = gi("paused", 0) != 0; if (gi("ext1", 0)) active_extruder = 1; if (gi("dupl", 0)) extruder_duplication_enabled = true; if (gi("waitway", 0)) waitway = 3;
  if (gi("boot", 1)) sim_oem_boot_mesh_send();      // Display zeigt nach dem Boot das (EEPROM-)Mesh: OEM-Bootschleife (LCD_RTS.cpp:311-337)
  const std::vector<unsigned char> boot_wire = W.wire; bool busy_seen = false, double_done = false;
  for (int k = 0; k < 16; k++) W.probe_script.push_back(0.012f * (k - 8) + 0.0031f * k);
  if (gi("val_at", -1) >= 0) W.probe_script[(size_t)gi("val_at", 0)] = gf("val", 0);
  if (gi("nan_at", -1) >= 0) W.probe_script.resize((size_t)gi("nan_at", 0));
  const std::string cancel_at = gs("cancel_at", ""); bool cancelled = false; const uint32_t limit = (uint32_t)gi("limit_s", 4000) * 1000;
  W.params.clear(); W.params['S'] = 1; if (gi("nostart", 0) == 0 && gi("manual_g29", 0) == 0) SV04Claude_Auto60_Gcode();     // M1060 S1
  if (gi("manual_g29", 0)) queue2.enqueue_now_P("G29");                                                                  // normale Anwender-G29 ohne Auto60
  const uint32_t t0 = sim_ms; bool changed_target = false;
  while (sim_ms - t0 < limit) {
    sim_ms += 100; bed_model(); service_home();
    if (gi("retarget_s", 0) && !changed_target && sim_ms - t0 > (uint32_t)gi("retarget_s", 0) * 1000) { thermalManager.temp_bed.target = 55; changed_target = true; }
    if (gi("bed_kick_at_s", 0) && sim_ms - t0 > (uint32_t)gi("bed_kick_at_s", 0) * 1000) thermalManager.temp_bed.celsius = gf("bed_kick", 40);
    if (!cancel_at.empty() && !cancelled && std::string(A60_STATE_NAME()) == cancel_at) { cmd("M1060", 0); cancelled = true; }
    SV04Claude_Auto60_Tick(); if (SV04Claude_Auto60_Busy()) busy_seen = true;
    if (gi("double_start", 0) && !double_done && sim_ms - t0 > (uint32_t)gi("double_start", 0) * 1000) { double_done = true; W.params.clear(); W.params['S'] = 1; SV04Claude_Auto60_Gcode(); }
    if (gi("foreign_g29_at_s", 0) && sim_ms - t0 > (uint32_t)gi("foreign_g29_at_s", 0) * 1000 && !queue2.has_commands_queued()) { queue2.enqueue_now_P("G29"); opt["foreign_g29_at_s"] = "0"; }
    run_queue();
    if (A60_TERMINAL() && (sim_ms - t0) > 200) break;
  }
  VirtualHmiA60 hmi0; hmi0.feed(boot_wire); VirtualHmiA60 hmi; hmi.feed(W.wire);
  A60_REPORT();
  printf("EE saves=%u bytes=%u header_ok=%d ver=%s loads=%u validates=%u mesh_changed=%d zoff_changed=%d\n", g_ee.saves, g_ee.bytes, g_ee.header_ok ? 1 : 0, g_ee.ver, g_ee.loads, g_ee.validates, memcmp(g_ee.z, ee0.z, sizeof g_ee.z) != 0, memcmp(&g_ee.zoff, &ee0.zoff, 4) != 0);
  printf("RAM zoff_unchanged=%d leveling=%d bed_target=%d\n", memcmp(&probe.offset.z, &z0, 4) == 0, planner.leveling_active ? 1 : 0, (int)thermalManager.temp_bed.target);
  printf("MESH"); for (int y = 0; y < 4; y++) for (int x = 0; x < 4; x++) printf(" %.4f", (double)z_values[x][y]); printf("\n");
  printf("EEMESH"); for (int y = 0; y < 4; y++) for (int x = 0; x < 4; x++) printf(" %.4f", (double)g_ee.z[x][y]); printf("\nEEZOFF %.4f\nRAMZOFF %.4f\nGEOM %.4f %.4f %.6f\n", (double)g_ee.zoff, (double)probe.offset.z, (double)bilinear_grid_spacing.x, (double)bilinear_start.x, (double)bilinear_grid_factor.x);
  printf("WIREHEX "); for (unsigned char b : W.wire) printf("%02X", b); printf("\nBOOTLEN %zu\n", boot_wire.size());
  printf("HMI0"); for (unsigned k = 0; k < 16; k++) printf(" %d", hmi0.cell(k)); printf("\n");
  printf("BUSY seen=%d after=%d\n", busy_seen ? 1 : 0, SV04Claude_Auto60_Busy() ? 1 : 0);
  printf("HMI"); for (unsigned k = 0; k < 16; k++) printf(" %d", hmi.cell(k)); printf("\nHMIPAGE %d\nHMIBAD %d\nHMIMULTI %d\nHMICELLWRITES %zu\n", hmi.page, hmi.bad, hmi.multiword, hmi.cell_writes.size());
  printf("COUNTS probe=%d m420=%d settings_save=%d\n", W.probe_calls, (int)std::count(W.cmds.begin(), W.cmds.end(), std::string("set_bed_leveling_enabled(true)")), (int)g_ee.saves);
  printf("CMDS"); for (auto &c : W.cmds) printf(" %s;", c.c_str()); printf("\nSERIAL"); for (auto &s : W.serial) printf(" [%s]", s.c_str()); printf("\n");
  return 0;
}

void sim_dump_and_exit(const char *) { printf("RESULT state=KILLED reason=kill\n"); exit(0); }
