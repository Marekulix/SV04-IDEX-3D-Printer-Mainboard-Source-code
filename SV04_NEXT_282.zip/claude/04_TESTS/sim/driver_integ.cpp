// KETTENSIMULATION: bedient den ECHTEN Auto60-Adapter + Koordinator + die ECHTE gepatchte G29.cpp + echte RTS_SndData. Auto60 wird NUR ueber M1060 und die Queue bedient.
#include "Marlin/src/inc/MarlinConfig.h"
#include "Marlin/src/feature/bedlevel/abl/abl.h"
#include "Marlin/src/lcd/e3v2/creality/LCD_RTS.h"
#include "sim_hmi_a60.h"
#include "sv04_claude_hooks.h"
#include "sv04_claude_auto60_core.h"
#include "sv04_claude_g29_session.h"
void sim_oem_boot_mesh_send();
extern RTSSHOW rtscheck; extern char waitway; extern void (*sim_idle_hook)();
extern int sim_save_mode; extern bool sim_readback_unavailable; void sim_ee_init_from_ram();
struct Ee2 { bool header_ok; char ver[4]; float z[4][4]; float sp[2], st[2], fa[2]; float zoff; bool lev; unsigned saves, bytes, loads, validates; };
extern Ee2 g_ee;
#include "sv04_claude_auto60_marlin.inc"          // GENAU die Datei, die in LCD_RTS.cpp eingebunden wird
#if SV04_CLAUDE_AUTO60_ENABLE && ENABLED(EEPROM_SETTINGS)
  #define A60_STATE_NAME() sv04c::state_name(sv04c_coord.state())
  #define A60_TERMINAL() sv04c_coord.terminal()
  #define A60_REPORT() { sv04c::TransitionRec r; printf("RESULT state=%s reason=%s sid=%u\n", sv04c::state_name(sv04c_coord.state()), sv04c::reason_name(sv04c_coord.reason()), sv04c_coord.session()); printf("LOG"); for (int i = (int)sv04c_coord.log_count() - 1; i >= 0; i--) if (sv04c_coord.log_at((unsigned)i, r)) printf(" %s>%s(%s)", sv04c::state_name(r.from), sv04c::state_name(r.to), sv04c::reason_name(r.why)); printf("\n"); }
#else
  #define A60_STATE_NAME() "IDLE"
  #define A60_TERMINAL() false
  #define A60_REPORT() { printf("RESULT state=IDLE reason=NONE sid=0\nLOG\n"); }
#endif
#include <map>
#include <algorithm>
#include <string.h>

static std::map<std::string, std::string> opt;
static std::string gs(const char *k, const char *d) { auto i = opt.find(k); return i == opt.end() ? d : i->second; }
static int gi(const char *k, int d) { auto i = opt.find(k); return i == opt.end() ? d : atoi(i->second.c_str()); }
static float gf(const char *k, float d) { auto i = opt.find(k); return i == opt.end() ? d : (float)atof(i->second.c_str()); }
static linear_axis_bits_t bits(const std::string &t) { linear_axis_bits_t b = 0; if (t == "all") return 7; for (char c : t) { if (c == 'X') b |= 1; if (c == 'Y') b |= 2; if (c == 'Z') b |= 4; } return b; }
static bool queue_stalled() { return gi("queue_stall", 0) && sim_ms < (uint32_t)(100000 + gi("queue_release_s", 100000) * 1000); }   // die Queue haengt bis queue_release_s nach dem Start
static void run_queue() {
  while (!queue2.q.empty()) {
    if (queue_stalled()) return;
    const std::string c = queue2.q.front(); queue2.q.pop_front();
    if (c == "G29") { W.log("exec G29"); W.params.clear(); GcodeSuite::G29(); }
    else if (c == "G28 X Y Z") { W.log("exec G28 X Y Z"); W.params.clear(); W.params['X'] = W.params['Y'] = W.params['Z'] = 1e30f; GcodeSuite::G28(); W.params.clear(); }
    else if (c == "G28") { W.log("exec G28"); W.params.clear(); GcodeSuite::G28(); }
    else if (c == "G28 X") { W.log("exec G28 X"); W.params.clear(); W.params['X'] = 1e30f; GcodeSuite::G28(); W.params.clear(); }
    else W.log("exec " + c);
  }
}
static void bed_model() {
  const float tgt = (float)thermalManager.temp_bed.target; const std::string m = gs("heat", "normal");
  if (m == "nan") { thermalManager.temp_bed.celsius = NAN; return; }
  if (m == "stuck") return;
  if (tgt > 0) thermalManager.temp_bed.celsius += (tgt - thermalManager.temp_bed.celsius) * 0.08f; else thermalManager.temp_bed.celsius += (25 - thermalManager.temp_bed.celsius) * 0.02f;
}
static bool kicked = false;
static uint32_t term_ms = 0; static bool again_done = false;
static bool touch_probe_done = false;
static bool touch_done = false, cancel_done = false, print_done = false, kick28_done = false;
static void tick_all() {
  if (gi("touch_after_probe", 0) && !touch_probe_done && W.probe_calls >= gi("touch_after_probe", 0)) { SV04Claude_Auto60_TouchCancel(); touch_probe_done = true; }   // Touch WAEHREND der laufenden G29 (idle() -> RTSUpdate)
  if (gi("touch_after_homeaxis", 0) && !touch_done && W.homeaxis_calls >= gi("touch_after_homeaxis", 0)) { SV04Claude_Auto60_TouchCancel(); touch_done = true; }
  if (gi("cancel_after_homeaxis", 0) && !cancel_done && W.homeaxis_calls >= gi("cancel_after_homeaxis", 0)) { W.params.clear(); W.params['S'] = 0; SV04Claude_Auto60_Gcode(); cancel_done = true; }
  if (gi("print_after_homeaxis", 0) && !print_done && W.homeaxis_calls >= gi("print_after_homeaxis", 0)) { card.printing = true; print_done = true; }
  if (gi("kick_after_homeaxis", 0) && !kick28_done && W.homeaxis_calls >= gi("kick_after_homeaxis", 0)) { thermalManager.temp_bed.celsius = gf("kick", 40); kick28_done = true; }      // = idle() -> RTSUpdate() -> Tick; laeuft auch WAEHREND der G29 (re-entrant, durch die Sperre im Adapter geschuetzt)
  if (gi("kick_after_probe", -1) >= 0 && !kicked && W.probe_calls >= gi("kick_after_probe", 0)) { thermalManager.temp_bed.celsius = gf("kick", 40); kicked = true; }
  SV04Claude_Auto60_Tick();
}
static void cmd(const char *s, float p) { W.params.clear(); W.params['S'] = p; (void)s; SV04Claude_Auto60_Gcode(); }

extern void (*sim_run_g28_hook)(const std::string &);
static void run_g28_from_script(const std::string &g) {      // G29-Endskript "G28 XY": derselbe echte G28
  std::map<char, float> keep = W.params; W.params.clear();
  for (size_t i = 3; i < g.size(); i++) if (g[i] >= 'A' && g[i] <= 'Z') W.params[g[i]] = 1e30f;
  GcodeSuite::G28(); W.params = keep;
}
int main(int argc, char **argv) {
  for (int i = 1; i < argc; i++) { std::string a = argv[i]; size_t e = a.find('='); if (e == std::string::npos) opt[a] = "1"; else opt[a.substr(0, e)] = a.substr(e + 1); }
  W.reset(); axis_homed = bits(gs("homed", "all")); axis_trusted = axis_homed; sim_ms = 100000; sim_idle_hook = tick_all; sim_run_g28_hook = run_g28_from_script;
  planner.leveling_active = gi("lev0", 1) != 0;
  for (int x = 0; x < 4; x++) for (int y = 0; y < 4; y++) z_values[x][y] = 0.31f - 0.05f * x + 0.02f * y;   // "altes" Mesh (EEPROM + RAM)
  bilinear_grid_spacing.set(84, 84); bilinear_start.set(25, 25); bilinear_grid_factor = bilinear_grid_spacing.reciprocal();
  probe.offset.z = gf("zoff", -1.10f); thermalManager.temp_bed.celsius = gf("bed0", 25); thermalManager.temp_bed.target = (int16_t)gi("target0", 0);
  sim_ee_init_from_ram(); const Ee2 ee0 = g_ee; const float z0 = probe.offset.z; sim_save_mode = gi("save", 0); sim_readback_unavailable = gi("noreadback", 0) != 0;
  W.m420_noop = gi("m420_noop", 0) != 0; dual_x_carriage_mode = (DualXMode)gi("mode", 1); extruder_duplication_enabled = gi("dupl", dual_x_carriage_mode >= 2 ? 1 : 0) != 0; sim_hotend_offset_x1 = gf("hotend_x1", 188.0f);
  W.deploy_fail = gi("deploy_fail", 0); W.stow_fail = gi("stow_fail", 0); W.bltouch_alarm = gi("bltouch_alarm", 0); W.x_early_t1 = gi("x_early_t1", 0); W.x_early_t0 = gi("x_early_t0", 0); W.kill_x_t1 = gi("kill_x_t1", 0); W.kill_x_t0 = gi("kill_x_t0", 0); W.kill_z = gi("kill_z", 0); W.kill_y = gi("kill_y", 0); W.homeaxis_ms = (uint32_t)gi("homeaxis_ms", 4000); W.x_t1_on_call = gi("x_t1_on_call", 0);
  W.probe_ms = (uint32_t)gi("probe_ms", 1500); W.homed = true; card.printing = gi("printing", 0) != 0; W.paused = gi("paused", 0) != 0; if (gi("ext1", 0)) active_extruder = 1; if (gi("dupl", 0)) extruder_duplication_enabled = true; if (gi("waitway", 0)) waitway = 3;
  if (gi("boot", 1)) sim_oem_boot_mesh_send();      // Display zeigt nach dem Boot das (EEPROM-)Mesh: OEM-Bootschleife (LCD_RTS.cpp:311-337)
  const std::vector<unsigned char> boot_wire = W.wire; bool busy_seen = false, double_done = false;
  for (int k = 0; k < 16; k++) W.probe_script.push_back(0.012f * (k - 8) + 0.0031f * k);
  if (gi("val_at", -1) >= 0) W.probe_script[(size_t)gi("val_at", 0)] = gf("val", 0);
  if (gi("nan_at", -1) >= 0) W.probe_script.resize((size_t)gi("nan_at", 0));
  const std::string cancel_at = gs("cancel_at", ""), touch_at = gs("touch_at", ""); bool cancelled = false, touched = false, foreign28 = false, foreign_exec = false; const uint32_t limit = (uint32_t)gi("limit_s", 4000) * 1000;
  if (gi("manual_g28", 0)) queue2.enqueue_now_P("G28");
  W.params.clear(); W.params['S'] = 1; if (gi("nostart", 0) == 0 && gi("manual_g29", 0) == 0 && gi("manual_g28", 0) == 0) SV04Claude_Auto60_Gcode();     // M1060 S1
  if (gi("manual_g29", 0)) queue2.enqueue_now_P("G29");                                                                  // normale Anwender-G29 ohne Auto60
  const uint32_t t0 = sim_ms; bool changed_target = false;
  while (sim_ms - t0 < limit) {
    sim_ms += 100; bed_model();
    if (gi("retarget_s", 0) && !changed_target && sim_ms - t0 > (uint32_t)gi("retarget_s", 0) * 1000) { thermalManager.temp_bed.target = 55; changed_target = true; }
    if (gi("bed_kick_at_s", 0) && sim_ms - t0 > (uint32_t)gi("bed_kick_at_s", 0) * 1000) thermalManager.temp_bed.celsius = gf("bed_kick", 40);
    if (!touch_at.empty() && !touched && std::string(A60_STATE_NAME()) == touch_at) { SV04Claude_Auto60_TouchCancel(); touched = true; }
    if (gi("request_again_s", 0) && !again_done && sim_ms - t0 > (uint32_t)gi("request_again_s", 0) * 1000) {       // direkter Zweitaufruf des Backends (Zulassungspruefung)
      again_done = true;
      #if SV04_CLAUDE_AUTO60_ENABLE && ENABLED(EEPROM_SETTINGS)
        printf("REQAGAIN same=%d zero=%d wrong=%d\n", SV04Claude_HomeBackendRequest(sv04c_coord.session()) ? 1 : 0, SV04Claude_HomeBackendRequest(0) ? 1 : 0, SV04Claude_HomeBackendRequest(sv04c_coord.session() + 5) ? 1 : 0);
      #endif
    }
    if (gi("printing_at_s", 0) && sim_ms - t0 > (uint32_t)gi("printing_at_s", 0) * 1000) card.printing = true;
    if (gi("foreign_g28_exec_s", 0) && !foreign_exec && sim_ms - t0 > (uint32_t)gi("foreign_g28_exec_s", 0) * 1000) { foreign_exec = true; W.log("exec G28 X (Anwender)"); std::map<char, float> keep = W.params; W.params.clear(); W.params['X'] = 1e30f; GcodeSuite::G28(); W.params = keep; }
    if (gi("foreign_g28_at_s", 0) && sim_ms - t0 > (uint32_t)gi("foreign_g28_at_s", 0) * 1000 && !queue2.has_commands_queued() && !foreign28) { queue2.enqueue_now_P("G28 X"); foreign28 = true; }
    if (!cancel_at.empty() && !cancelled && std::string(A60_STATE_NAME()) == cancel_at) { cmd("M1060", 0); cancelled = true; }
    SV04Claude_Auto60_Tick(); if (SV04Claude_Auto60_Busy()) busy_seen = true;
    if (gi("double_start", 0) && !double_done && sim_ms - t0 > (uint32_t)gi("double_start", 0) * 1000) { double_done = true; W.params.clear(); W.params['S'] = 1; SV04Claude_Auto60_Gcode(); }
    if (gi("foreign_g29_at_s", 0) && sim_ms - t0 > (uint32_t)gi("foreign_g29_at_s", 0) * 1000 && !queue2.has_commands_queued()) { queue2.enqueue_now_P("G29"); opt["foreign_g29_at_s"] = "0"; }
    run_queue();
    if (A60_TERMINAL() && (sim_ms - t0) > 200) { if (!term_ms) term_ms = sim_ms; if (sim_ms - term_ms >= (uint32_t)gi("tail_s", 0) * 1000) break; }   // tail_s: nach dem Endzustand weiterlaufen (spaete Queue-Freigabe)
  }
  VirtualHmiA60 hmi0; hmi0.feed(boot_wire); VirtualHmiA60 hmi; hmi.feed(W.wire);
  A60_REPORT();
  printf("EE saves=%u bytes=%u header_ok=%d ver=%s loads=%u validates=%u mesh_changed=%d zoff_changed=%d\n", g_ee.saves, g_ee.bytes, g_ee.header_ok ? 1 : 0, g_ee.ver, g_ee.loads, g_ee.validates, memcmp(g_ee.z, ee0.z, sizeof g_ee.z) != 0, memcmp(&g_ee.zoff, &ee0.zoff, 4) != 0);
  printf("RAM zoff_unchanged=%d leveling=%d bed_target=%d\n", memcmp(&probe.offset.z, &z0, 4) == 0, planner.leveling_active ? 1 : 0, (int)thermalManager.temp_bed.target);
  printf("MESH"); for (int y = 0; y < 4; y++) for (int x = 0; x < 4; x++) printf(" %.4f", (double)z_values[x][y]); printf("\n");
  printf("EEMESH"); for (int y = 0; y < 4; y++) for (int x = 0; x < 4; x++) printf(" %.4f", (double)g_ee.z[x][y]); printf("\nEEZOFF %.4f\nRAMZOFF %.4f\nGEOM %.4f %.4f %.6f\n", (double)g_ee.zoff, (double)probe.offset.z, (double)bilinear_grid_spacing.x, (double)bilinear_start.x, (double)bilinear_grid_factor.x);
  printf("WIREHEX "); for (unsigned char b : W.wire) printf("%02X", b); printf("\nBOOTLEN %zu\n", boot_wire.size());
  printf("P1RESULT seq=%u completed=%d ok=%d t1_ok=%d t0_ok=%d z_ok=%d\n", sv04_p1_g28_result.seq, sv04_p1_g28_result.completed, sv04_p1_g28_result.ok, sv04_p1_g28_result.t1_ok, sv04_p1_g28_result.t0_ok, sv04_p1_g28_result.z_ok);
  printf("AXES homed=%d trusted=%d active_ext=%d dupl=%d mode=%d\n", (int)axis_homed, (int)axis_trusted, (int)active_extruder, extruder_duplication_enabled ? 1 : 0, (int)dual_x_carriage_mode);
  printf("HOMEAXIS count=%d\n", W.homeaxis_calls);
  #if SV04_CLAUDE_AUTO60_ENABLE && ENABLED(EEPROM_SETTINGS)
  printf("STALE %u\n", sv04c_coord.stale_events());
  #else
  printf("STALE 0\n");
  #endif
  printf("HMI0"); for (unsigned k = 0; k < 16; k++) printf(" %d", hmi0.cell(k)); printf("\n");
  printf("BUSY seen=%d after=%d\n", busy_seen ? 1 : 0, SV04Claude_Auto60_Busy() ? 1 : 0);
  printf("HMI"); for (unsigned k = 0; k < 16; k++) printf(" %d", hmi.cell(k)); printf("\nHMIPAGE %d\nHMIBAD %d\nHMIMULTI %d\nHMICELLWRITES %zu\n", hmi.page, hmi.bad, hmi.multiword, hmi.cell_writes.size());
  printf("COUNTS probe=%d m420=%d settings_save=%d\n", W.probe_calls, (int)std::count(W.cmds.begin(), W.cmds.end(), std::string("set_bed_leveling_enabled(true)")), (int)g_ee.saves);
  printf("CMDS"); for (auto &c : W.cmds) printf(" %s;", c.c_str()); printf("\nSERIAL"); for (auto &s : W.serial) printf(" [%s]", s.c_str()); printf("\n");
  return 0;
}

void sim_dump_and_exit(const char *) { printf("RESULT state=KILLED reason=kill\n"); exit(0); }
