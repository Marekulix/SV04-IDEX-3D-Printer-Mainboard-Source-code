// KETTENSIMULATION: Welt fuer Auto60 (Stubs/Modelle, kein OEM-Code). Das EEPROM-MODELL folgt der ECHTEN settings.cpp-Semantik:
// save(): zuerst Platzhalter "ERR" (settings.cpp:653-668), Daten, am Ende Kopf "V85"+CRC (1452-1469); load(): validate() ... sonst reset() auf Standardwerte (settings.cpp load()).
#include "Marlin/src/inc/MarlinConfig.h"
#include "Marlin/src/feature/bedlevel/abl/abl.h"
#include <string.h>
SimThermal thermalManager; SimCard card; int PrintFlag = 0; bool PoweroffContinue = false, pause_action_flag = false;
DualXMode dual_x_carriage_mode = DXC_AUTO_PARK_MODE; bool extruder_duplication_enabled = false;
bool printingIsPaused() { return W.paused; }
SimQueue2 queue2; SimSettings2 settings2;
void SimThermal::setTargetBed(const int16_t c) { temp_bed.target = c; W.log("bed_target " + std::to_string(c)); }

enum { SM_OK = 0, SM_RETURN_FALSE, SM_POWERLOSS_AFTER_ERR, SM_CORRUPT, SM_FAIL_ONCE };
struct Ee { bool header_ok = true; char ver[4] = {'V', '8', '5', 0}; float z[4][4]; float sp[2], st[2], fa[2]; float zoff = 0; bool lev = false; unsigned saves = 0, bytes = 0, loads = 0, validates = 0; };
Ee g_ee; int sim_save_mode = SM_OK; int sim_save_calls = 0; bool sim_readback_unavailable = false;
static void ee_from_ram() {
  for (int x = 0; x < 4; x++) for (int y = 0; y < 4; y++) g_ee.z[x][y] = z_values[x][y];
  g_ee.sp[0] = bilinear_grid_spacing.x; g_ee.sp[1] = bilinear_grid_spacing.y; g_ee.st[0] = bilinear_start.x; g_ee.st[1] = bilinear_start.y; g_ee.fa[0] = bilinear_grid_factor.x; g_ee.fa[1] = bilinear_grid_factor.y;
  g_ee.zoff = probe.offset.z; g_ee.lev = planner.leveling_active;
}
void sim_ee_init_from_ram() { ee_from_ram(); g_ee.header_ok = true; memcpy(g_ee.ver, "V85", 4); }
bool SimSettings2::validate() { ++g_ee.validates; W.log("eeprom_validate"); return g_ee.header_ok && memcmp(g_ee.ver, "V85", 4) == 0; }
bool SimSettings2::save() {
  ++g_ee.saves; ++sim_save_calls; W.log("settings.save"); W.eeprom_saves++;
  g_ee.header_ok = false; memcpy(g_ee.ver, "ERR", 4);                          // Platzhalter zuerst
  if (sim_save_mode == SM_RETURN_FALSE) return false;
  if (sim_save_mode == SM_POWERLOSS_AFTER_ERR) { g_ee.bytes += 40; return false; }
  if (sim_save_mode == SM_FAIL_ONCE && sim_save_calls == 1) { g_ee.bytes += 10; return false; }
  ee_from_ram(); g_ee.bytes += 800;
  if (sim_save_mode == SM_CORRUPT) g_ee.z[2][1] += 0.5f;
  memcpy(g_ee.ver, "V85", 4); g_ee.header_ok = true;                           // Commit-Marker zuletzt
  if (sim_idle_hook) sim_idle_hook();                                           // safe_delay() in der echten HAL ruft idle()
  return true;
}
bool SimSettings2::load() {
  ++g_ee.loads; W.log("settings.load");
  if (sim_readback_unavailable) return false;
  if (!validate()) { reset_bed_level(); probe.offset.z = 0; return false; }     // echtes load(): reset() auf Standardwerte
  for (int x = 0; x < 4; x++) for (int y = 0; y < 4; y++) z_values[x][y] = g_ee.z[x][y];
  bilinear_grid_spacing.x = g_ee.sp[0]; bilinear_grid_spacing.y = g_ee.sp[1]; bilinear_start.x = g_ee.st[0]; bilinear_start.y = g_ee.st[1]; bilinear_grid_factor.x = g_ee.fa[0]; bilinear_grid_factor.y = g_ee.fa[1];
  probe.offset.z = g_ee.zoff;
  set_bed_leveling_enabled(false); if (g_ee.lev) set_bed_leveling_enabled(true);   // postprocess(): gespeicherter Nivellierungszustand
  return true;
}
