# SV04 NEXT 277 – Start hier

**Nicht flashbar.** Kein STM32-Build in dieser Umgebung möglich, keine Hardware geprüft. Alles „getestet“ ist Host-Simulation um die echte `G28.cpp`/`G29.cpp`.

1. Lesen: `docs/ERGEBNISBERICHT_277.md` (5 Kategorien) · `docs/ANALYSE_276_BEFUNDE.md` (6 Fehler in 276) · `docs/OFFEN_UND_BLOCKIERT_277.md` (Entscheidungen bei Ihnen).
2. GitHub-Lauf: `docs/GITHUB_UPLOAD_ANLEITUNG.md` (2 Dateien: `277.yml` + dieses ZIP).
3. Selbst prüfen: `python3 claude/tools/verify_manifest.py .` (im Paketwurzelverzeichnis) · Tests: `python3 claude/tools/run_all_tests_a60.py` (alles) oder `--stages core,host,sim` (ca. 1 Minute).
4. Patch anwenden: `python3 apply_277.py --root <OEM-Baum mit 268–276> --profile p1|integrated`.
5. Hardware: erst nach grünem Build, `docs/HARDWARE_ABNAHME_277.md`.
