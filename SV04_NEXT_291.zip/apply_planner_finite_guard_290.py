#!/usr/bin/env python3
"""Apply finite-coordinate guard after integrated SV04 NEXT 289 to planner.cpp only."""
import argparse,hashlib
from pathlib import Path

GUARD_LINE = '''  // SV04 NEXT 290: Validate Cartesian move before modifiers / leveling.
  if (!isfinite(cart.x) || !isfinite(cart.y) || !isfinite(cart.z)
      || !isfinite(cart.e) || !isfinite(fr_mm_s)) {
    SERIAL_ERROR_MSG("SV04: non-finite Cartesian move");
    kill(PSTR("Invalid motion coordinates"), nullptr, true);
    return false;
  }

'''
GUARD_SEGMENT = '''  // SV04 NEXT 290: Final validation before float-to-step conversion.
  // Also protects direct segment callers and modifier-generated NaN/Inf.
  if (!isfinite(abce.a) || !isfinite(abce.b) || !isfinite(abce.c)
      || !isfinite(abce.e) || !isfinite(fr_mm_s)) {
    SERIAL_ERROR_MSG("SV04: non-finite planner segment");
    kill(PSTR("Invalid motion coordinates"), nullptr, true);
    return false;
  }

'''
SIGN_LINE='bool Planner::buffer_line(const xyze_pos_t &cart,'
SIGN_SEGMENT='bool Planner::buffer_segment(const abce_pos_t &abce'
ANCHOR_LINE='  // SV04 NEXT 288: refuse further queued motion if an active bilinear mesh'
ANCHOR_SEGMENT='  // If we are cleaning, do not accept queuing of movements'

def transform(src):
    # The OEM comment ANCHOR_SEGMENT is also present in an unrelated
    # function. Limit anchor searches to the function they belong to.
    if src.count(SIGN_LINE)!=1 or src.count(SIGN_SEGMENT)!=1 or src.count(ANCHOR_LINE)!=1:
        raise ValueError('Expected planner function definitions / V288 guard not unique')
    seg_start=src.index(SIGN_SEGMENT)
    line_start=src.index(SIGN_LINE)
    if seg_start>=line_start:
        raise ValueError('Unexpected planner function order')
    # Anchors must be inside their OWN function, not elsewhere in planner.cpp.
    seg_region=src[seg_start:line_start]
    line_region=src[line_start:]
    if seg_region.count(ANCHOR_SEGMENT)!=1 or line_region.count(ANCHOR_LINE)!=1:
        raise ValueError('Planner anchors missing or repeated inside target functions')
    if GUARD_LINE.strip() in src and GUARD_SEGMENT.strip() in src:
        return src,False
    if 'SV04 NEXT 290:' in src:
        raise ValueError('Conflicting or partial V290 patch')
    # Place each guard immediately before its actual function-local anchor.
    # Operate from right to left to keep earlier offsets stable.
    segments=((seg_start,seg_region.index(ANCHOR_SEGMENT)+seg_start,GUARD_SEGMENT),
              (line_start,line_region.index(ANCHOR_LINE)+line_start,GUARD_LINE))
    if any(anch<=start for start,anch,_ in segments):
        raise ValueError('Anchor occurs before planner function body')
    for _,position,guard in sorted(segments,key=lambda x:x[1],reverse=True):
        src=src[:position]+guard+src[position:]
    return src,True

def main():
    parser=argparse.ArgumentParser();parser.add_argument('oem_root',type=Path);args=parser.parse_args()
    path=args.oem_root/'Marlin/src/module/planner.cpp'
    content=path.read_text(encoding='utf-8')
    patched,changed=transform(content)
    if changed:path.write_text(patched,encoding='utf-8')
    print('PATCHED' if changed else 'ALREADY_APPLIED',path)
    print('SHA256',hashlib.sha256(patched.encode()).hexdigest())
if __name__=='__main__':main()
