SV04 NEXT 290 - finite movement input guards for planner.cpp

Apply on TOP of successfully built SV04 NEXT 289 (OEM pinned commit + integrator 287 + guard 288).
Only planner.cpp touched; no edits to Claude G29/EEPROM/DWIN.
Files: apply_planner_finite_guard_290.py, test_planner_finite_guard_290.py
Expected: local 64 C++ cases / 7 patch regression checks.
GitHub flow produces logs for two STM32 profiles, never flashes or releases binaries.
Important: All software/emergency stop claims require hardware validation.
