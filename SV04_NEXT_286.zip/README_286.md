# SV04 NEXT 286: G29-Abbruch zwischen Messpunkten

Ausgang: unveränderte, erfolgreich gebaute SV04 NEXT 285.

Änderungen:
- Auto60-Touch-Abbruch zwischen den G29-Punktfahrten und nach `probe_at_point()` prüfen.
- Noch nicht gespeicherten Messwert verwerfen und Messschleife verlassen.
- OEM `probe.stow()` und vorhandenen G29-RAM-Rollback weiter ausführen.
- `Z_PROBE_END_SCRIPT` (`G28 XY`) NUR nach diesem erkannten Auto60-Abbruch auslassen.
- Gewöhnliche G29 außerhalb Auto60 bleiben unverändert.
- Kein EEPROM- oder M500-Code geändert.

Tests: `python3 g29/test_g29_cancel.py` kompiliert und führt die echte neue C++-Abfrage mit Host-Stubs aus und instrumentiert die OEM-277-G29-Datei.

Verwendung: `python3 integrate_286.py oem --logs evidence/integration`

Diese Änderung ist softwareseitig getestet, aber ein echter STM32-Gesamtbuild und Tests am Drucker bleiben bis zum GitHub-Run offen. Insbesondere ist die Abbruchlatenz durch die Dauer des gerade laufenden BLTouch-Probes begrenzt. Kein Flashen.
