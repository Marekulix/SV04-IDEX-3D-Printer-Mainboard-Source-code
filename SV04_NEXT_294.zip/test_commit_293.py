#!/usr/bin/env python3
"""Compile and run the real patched sv04c_ee_commit function with instrumented EEPROM stubs."""
from pathlib import Path
import subprocess, tempfile
SRC=Path(__file__).with_name('POST_293_REFERENCE.inc').read_text()
needle='static bool sv04c_ee_commit(void *, uint32_t, bool verified) {'
start=SRC.index(needle)
i=SRC.index('{', start); depth=0; end=None
for j in range(i,len(SRC)):
    if SRC[j]=='{': depth+=1
    if SRC[j]=='}':
        depth-=1
        if depth==0: end=j+1;break
assert end is not None
fn=SRC[start:end]
assert 'CM_CLEAR_FAILED' in fn and 'sv04c_ee_boot_blocked = true;' in fn
pre=r'''#include <cstdint>
#include <iostream>
namespace sv04c {namespace ee {
 enum Commit { CM_OK, CM_ROLLED_BACK, CM_ROLLBACK_FAILED, CM_CLEAR_FAILED };
 enum PrimaryState {PR_VALID, PR_CRC_BAD};
 struct Store {};
 struct Block {unsigned start; unsigned len;};
 struct ShadowPlan {unsigned data;};
 struct DiffSummary {int other;};
 static Commit configured = CM_OK;
 static PrimaryState primary = PR_VALID;
 inline Commit commit_transaction(Store, ShadowPlan, Block, bool) {return configured;}
 struct PrimaryInfo {PrimaryState st;};
 inline PrimaryInfo primary_info(Store, Block) { return PrimaryInfo{primary};}
 inline bool diff_regions(Store,unsigned,unsigned,unsigned,unsigned,bool,DiffSummary&) {return false;}
}}
static bool access_ok=true;
struct Sv04cEeAccess {bool ok; Sv04cEeAccess():ok(access_ok) {}};
static sv04c::ee::Store sv04c_ee_store(){return {};}
static sv04c::ee::Block sv04c_ee_block(){return {100,500};}
static sv04c::ee::ShadowPlan sv04c_ee_plan{800};
static uint8_t sv04c_ee_journal=1, sv04c_ee_last_commit=0;
static bool sv04c_ee_boot_blocked=false,sv04c_ee_mesh_found=false;
static unsigned sv04c_ee_mesh_at=0,sv04c_ee_other=0,sv04c_ee_unprotected_saves=0;
static void sv04c_ee_msg(const char*) {}
#define SERIAL_ECHO_START() ((void)0)
#define SERIAL_ECHOPGM(...) ((void)0)
#define SERIAL_ECHO(...) ((void)0)
#define SERIAL_ECHOLNPGM(...) ((void)0)
'''
post=r'''
int main(){
 int n=0;
 for (int status=0;status<4;status++) for(int verified=0;verified<2;verified++)
 for(int valid=0;valid<2;valid++) for(int access=0;access<2;access++) {
  sv04c::ee::configured=(sv04c::ee::Commit)status;
  sv04c::ee::primary=valid?sv04c::ee::PR_VALID:sv04c::ee::PR_CRC_BAD;
  access_ok=access; sv04c_ee_journal=1; sv04c_ee_boot_blocked=false;sv04c_ee_last_commit=0;
  bool result=sv04c_ee_commit(nullptr,0,verified);
  bool expected=access && status!=sv04c::ee::CM_ROLLBACK_FAILED && status!=sv04c::ee::CM_CLEAR_FAILED && (verified || valid);
  if(result!=expected || sv04c_ee_journal!=(expected?0:1) || sv04c_ee_boot_blocked==expected) {
   std::cerr<<"FAIL status="<<status<<" verified="<<verified<<" valid="<<valid<<" access="<<access
   <<" result="<<result<<" expected="<<expected<<" journal="<<(int)sv04c_ee_journal<<" blocked="<<sv04c_ee_boot_blocked<<"\n"; return 1;
  }
  ++n;
 }
 // Test unprotected branch: distinguish journal=2 and journal=3, including failure
 for(int journal=0;journal<4;journal++) if(journal!=1)for(int verified=0;verified<2;verified++) {
  sv04c_ee_journal=journal;sv04c_ee_boot_blocked=false;
  bool result=sv04c_ee_commit(nullptr,0,verified);
  if(result!=bool(verified) || sv04c_ee_boot_blocked) return 2;
  ++n;
 }
 std::cout<<"REAL_COMMIT_CPP_CASES="<<n<<" PASS\n";
}'''
with tempfile.TemporaryDirectory() as d:
    src=Path(d)/'test.cpp';bin=Path(d)/'test';src.write_text(pre+'\n'+fn+'\n'+post)
    run=subprocess.run(['g++','-std=c++11','-Wall','-Wextra','-Werror','-Wno-unused-parameter',str(src),'-o',str(bin)],capture_output=True,text=True)
    if run.returncode: print(run.stderr);raise SystemExit(run.returncode)
    out=subprocess.run([str(bin)],capture_output=True,text=True)
    print(out.stdout,end='');print(out.stderr,end='')
    if out.returncode:raise SystemExit(out.returncode)
