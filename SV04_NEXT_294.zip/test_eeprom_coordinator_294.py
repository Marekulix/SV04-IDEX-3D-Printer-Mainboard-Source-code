#!/usr/bin/env python3
"""Compile the actual patched Auto60 Coordinator with its full host test world."""
from pathlib import Path
import tempfile,subprocess,sys
here=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory() as td:
    exe=Path(td)/'core_test'
    cmd=['g++','-std=c++11','-O2','-Wall','-Wextra','-Werror','-pedantic','-I',str(here),str(here/'test_auto60_core.cpp'),'-o',str(exe)]
    p=subprocess.run(cmd,capture_output=True,text=True)
    if p.returncode: print(p.stderr);sys.exit(p.returncode)
    r=subprocess.run([str(exe)],capture_output=True,text=True)
    print(r.stdout[-4800:]); print(r.stderr)
    if r.returncode:sys.exit(r.returncode)
    for id in ['L94','L95','L96']:
        if 'PASS '+id+' ' not in r.stdout:sys.exit('missing test '+id)
