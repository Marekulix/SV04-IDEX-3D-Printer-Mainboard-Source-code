#!/usr/bin/env python3
import tempfile
from pathlib import Path
from importlib.machinery import SourceFileLoader
root=Path(__file__).parent
p292=SourceFileLoader('patch292',str(root/'apply_eeprom_policy_292.py')).load_module()
p293=SourceFileLoader('patch293',str(root/'apply_eeprom_commit_guard_293.py')).load_module()
# Real 284/285 source adapter, before our 292 addition
source=(root/'BASELINE_AUTO60_285.inc').read_text()
c=0
with tempfile.TemporaryDirectory() as d:
    target=Path(d)/p293.TARGET
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(source)
    initial=target.read_text()
    a,applied=p292.apply(initial);assert applied;c+=1
    target.write_text(a)
    b,applied=p293.apply(target.read_text());assert applied;c+=1
    target.write_text(b)
    again,applied=p293.apply(target.read_text());assert not applied and again==b;c+=1
    after292again,applied=p292.apply(b);assert not applied and after292again==b;c+=1
    # Validate every necessary branch now present.
    for tok in ['CM_CLEAR_FAILED','sv04c_ee_boot_blocked = true;','sv04c_ee_journal = 0;  // only after complete journal close','SV04_CLAUDE_EEPROM_REQUIRE_JOURNAL 1']:
        assert tok in b;c+=1
    # Unknown upstream change must be rejected, not overwritten.
    foreign=a.replace('if (r == sv04c::ee::CM_ROLLBACK_FAILED)', 'if (r == sv04c::ee::CM_ROLLBACK_FAILED || extra_flag)',1)
    try: p293.apply(foreign)
    except ValueError: c+=1
    else: raise AssertionError('Conflict not detected')
    # Cannot apply 293 without 292.
    try:p293.apply(source)
    except ValueError:c+=1
    else:raise AssertionError('Prerequisite missing not detected')
print('PATCH_CHAIN_CASES='+str(c)+' PASS')
