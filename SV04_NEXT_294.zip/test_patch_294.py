#!/usr/bin/env python3
import sys,tempfile,importlib.util
from pathlib import Path
p=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('patch294',p/'apply_eeprom_coordinator_294.py'); mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
original=(p/'sv04_claude_auto60_core.h').read_text()
assert original.count(mod.MARK)==1
pristine=original.replace(mod.NEW,mod.OLD)
assert mod.OLD in pristine
result,changed=mod.apply(pristine)
assert changed and result==original
assert mod.apply(original)==(original,False)
try:mod.apply(pristine.replace(mod.OLD,'//corrupt'))
except ValueError:pass
else:raise AssertionError('failed to detect unknown source')
print('294 patch/replay/conflict tests: 4/4 PASS')
