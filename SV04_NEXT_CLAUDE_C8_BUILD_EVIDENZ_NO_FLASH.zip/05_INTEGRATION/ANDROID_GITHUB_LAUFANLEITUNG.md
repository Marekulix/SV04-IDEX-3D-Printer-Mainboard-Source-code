# Android-/GitHub-Laufanleitung (C8) – nicht von mir ausgeführt

Sie brauchen nur den Browser Ihres Tablets (GitHub-Webseite, am besten „Desktop-Ansicht“). Es wird **nichts geflasht**.

## Welche Route?
* **Route A (Original):** nur, wenn Sie die **exakte** Datei `SV04_NEXT_287.zip` (SHA-256 beginnt mit `2126fa98`) haben. Nicht umbenennen, nichts anderes unter diesem Namen hochladen.
* **Route B (ohne 287):** braucht nur zwei Dateien. Das Ergebnis trägt das Etikett `ROUTE_B` und ist **nicht** der ursprüngliche 309-Weg.

## Dateien im Repository-Stamm
| Route | Datei | Hinweis |
|---|---|---|
| A + B | `SV04_NEXT_318_GESAMTINTEGRATION_UND_C6_UEBERGABE_NO_FLASH.zip` | SHA-256 beginnt `b474d80a` |
| A + B | `SV04_NEXT_CLAUDE_C8_BUILD_EVIDENZ_NO_FLASH.zip` | das C8-Paket (Hash steht im Workflow) |
| nur A | `SV04_NEXT_287.zip`, `SV04_NEXT_289.zip`, `SV04_NEXT_291.zip`, `SV04_NEXT_294.zip`, `SV04_NEXT_295.zip`, `A 309.zip` | exakte Namen (bei `A 309.zip` mit Leerzeichen) |

## Schritte
1. Repository öffnen → **Add file → Upload files** → die ZIPs der Tabelle auswählen → **Commit changes**.
2. **Add file → Create new file**, Dateiname eingeben (mit Schrägstrichen, GitHub legt die Ordner an): `.github/workflows/claude_c8_route_b_patch_no_flash.yml` (bzw. `…route_a_original_no_flash.yml`), den **kompletten Inhalt** der gleichnamigen Datei einfügen → **Commit**.
3. Reiter **Actions** → den Workflow links wählen → **Run workflow**.
4. Route A: Der Job `preflight_inputs` läuft zuerst und nennt **jede** fehlende/falsche Datei (`MISSING`, `BAD_HASH`, `BAD_ZIP`); bei Fehlern wird nicht gebaut. Das ist gewollt.
5. Nach dem Lauf: Seite des Laufs öffnen → ganz unten **Artifacts** → alle herunterladen und mir geben.

## Erwartete Artefakte (Route B; bei A heißt der Präfix `SV04_C8A_`)
* `SV04_C8B_CONTROL_309_ORIGINAL_STM32_LOGS_NO_FLASH`
* `SV04_C8B_MODIFIED_318_STM32_LOGS_NO_FLASH`
* `SV04_C8B_EVALUATION` (enthält `EVALUATION.md`: eine Zeile je Baum und Profil mit PASS/FAIL/INCOMPLETE/MISSING, RAM/Flash, erste Compilerfehler)

In jedem Build-Artefakt je Profil (`integrated_backend`, `integrated_failclosed`): `build.log`, `result.txt` (mit `BUILD_EXIT=`), `errors.txt`, `warnings.txt`, `ram_flash.txt`, `framework_packages.txt`; dazu die Beleg-Dateien der Vorbereitung (`route_b_309_pins.txt`, `integrate_318_strict.txt`, `diff_309_vs_318.txt` …).

## Lesen des Ergebnisses
Der Auswertungsjob ist **grün nur, wenn alle vier Kombinationen** (309-Kontrolle und 318-Kopie, je beide Profile) belegt `PASS` sind (Exit 0 **und** PlatformIO-`[SUCCESS]` **und** RAM-/Flash-Zeilen). Alles andere ist rot. Laufzeit: unbekannt (Timeout 240 Minuten je Job).

## Wenn etwas fehlschlägt
Geben Sie mir die Artefakte. Ich repariere den **ersten** echten Compilerfehler auf einer **neuen Kopie** (309, 315, 318 bleiben unberührt) und liefere Patch, Diff, Gründe, Tests und Hashes.
