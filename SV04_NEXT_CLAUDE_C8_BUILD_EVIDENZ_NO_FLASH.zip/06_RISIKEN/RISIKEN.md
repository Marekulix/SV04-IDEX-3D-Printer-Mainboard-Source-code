# Offene Risiken

* **Kein Build ausgeführt**, Compilerfehler unbekannt; meine Simulation übersetzt `motion.cpp`, `tool_change.cpp`, `G29.cpp` nicht als Ganzes.
* **Originalroute blockiert** (`SV04_NEXT_287.zip` fehlt); Route B ist ein anderer, nur offline geprobter Weg.
* Z-Homing aus unbekannter Position (410 mm nicht als sicher belegt), T0/T1-Kollisionsabstände, BLTouch-Ausfall, EEPROM-Journal/Stromausfall am Gerät, DWIN-HMI: alle **NICHT FREIGEGEBEN / nicht geprüft**.
