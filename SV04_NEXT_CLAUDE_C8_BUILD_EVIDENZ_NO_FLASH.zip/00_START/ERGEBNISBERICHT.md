# SV04 NEXT – Claude C8: Build-Blocker – Ergebnisbericht

Stand 13.11.2026 · Baseline 309 und 318 unverändert · **C8 ist ein Claude-Arbeitstitel.**

> **Kurzfassung:** Der Blocker `SV04_NEXT_287.zip` (SHA-256 `2126fa98…a599`) ist für die **Originalroute BLOCKED**: Die Datei lässt sich aus keinem mir vorliegenden Archiv rekonstruieren (Logs `40`, `41`). Ich habe nichts umbenannt und keine Prüfsumme umgangen. Zusätzlich liefere ich **Route B**, die die 309 ohne diese Datei aus dem aufgezeichneten `combined_308.patch` reproduziert (offline geprobt, ausdrücklich ein **anderer Weg**). **GitHub ist von hier nicht erreichbar, es wurde kein Build ausgeführt**: keine Logs, keine Exitcodes, keine RAM-/Flash-Werte, keine Compilerfehler, keine Fixes. Nichts geflasht, keine Hardwarefreigabe.

## Angriff A – Eingaben

**A.1 Wofür wird 287 gebraucht?** `SV04_NEXT_287.zip` wird in das Verzeichnis `point1` entpackt. Daraus verwendet der Workflow `point1/integrate_286.py` (der Schritt, der aus dem OEM-Commit die 309-Basis erzeugt), `point1/test_integration_281.py`, `point1/test_integration_285.py` und `point1/g29/test_g29_cancel.py`. Die 309 entsteht dann über `integrate_286.py` → Planner-Guards 288/290 (aus 289/291) → `integrate_308.py` (aus `A 309.zip`). **Ohne 287 kann Route A die 309 nicht erzeugen.**

**A.2 Lässt sich das Original rekonstruieren? Nein.**
* Suche nach der exakten SHA-256 in **84323 losen Dateien, 1110 Archiven (rekursiv) und 95616 Archivmitgliedern: kein Treffer** (Log `40`).
* Die Schlüsselmitglieder `integrate_286.py`, `test_integration_285.py` und `g29/test_g29_cancel.py` kommen in **keinem** Archiv vor (Log `41`); `test_integration_281.py` existiert in genau einer Fassung.
* Das einzige Archiv mit „287“ im Namen ist `SV04_NEXT_287_GEMEINSAME_ENTWICKLUNG_UEBERGABE.zip` (SHA-256 `c2068285…`, 1 015 919 Bytes): eine **andere Datei** mit anderem Inhalt (Übergabe mit Belegen, Claude-Dateien, Logs, `SV04_NEXT_285.zip`). Sie ist kein Ersatz und wird **nicht** umbenannt.
* Ein ZIP mit exakt dieser Prüfsumme könnte ich auch nicht nachbauen (Bytes und Zeitstempel sind nicht reproduzierbar).

**Minimal benötigte Eingabe für Route A:** genau die Datei `SV04_NEXT_287.zip` mit der obigen SHA-256. Sie hat den 309-Build auf GitHub ermöglicht und müsste in Ihrem Repository liegen (oder in dem Upload, mit dem Sie sie damals hinzugefügt haben).

**A.3 Alle übrigen Eingaben** (Log `42`, `verify_inputs_c8.py`: Dateiname, SHA-256, ZIP-Integrität **und** die vom Workflow referenzierten Mitglieder):

| Eingabe | Status |
|---|---|
| `SV04_NEXT_287.zip` | **MISSING** (nicht auffindbar) |
| `SV04_NEXT_289.zip` | OK, enthält `apply_planner_guard_288.py` |
| `SV04_NEXT_291.zip` | OK, enthält `apply_planner_finite_guard_290.py` |
| `SV04_NEXT_294.zip` | OK (18 Mitglieder) |
| `SV04_NEXT_295.zip` | OK (1 Mitglied) |
| `A 309.zip` | OK (55 Mitglieder), enthält `integrate_308.py` |
| `SV04_NEXT_318_GESAMTINTEGRATION_UND_C6_UEBERGABE_NO_FLASH.zip` | OK |
| `SV04_NEXT_CLAUDE_C7_BUILD_KORREKTUR_NO_FLASH.zip` | OK |

## Route B (neu): 309 ohne die 287-Datei
Der Workflow `claude_c8_route_b_patch_no_flash.yml` reproduziert die 309 aus `c318/combined_308.patch` (SHA-256 fest eingetragen) per `git apply` auf dem festgelegten OEM-Commit und prüft **elf Dateihashes** (3 OEM-Dateien, 8 `sv04_claude_*`-Dateien). Danach laufen unverändert der strikte 318-Installer und beide Build-Jobs. Eingaben: nur die 318-Übergabe und das C8-Paket.

**Offline-Probe mit dem echten Skripttext (Log `43`, 6 von 6 bestanden):** Reproduktion und 11 Pins; strikter Installer; der reproduzierte 318-Baum ist **byte-identisch** zu meinem 318-Baum aus C6 (2 478 Dateien); manipulierte Datei → Pinprüfung scheitert; falscher oder veränderter Patch → Abbruch ohne jede Änderung.

**Grenzen von Route B (wichtig):**
* Das ist **nicht** der Weg, auf dem die 309 ursprünglich gebaut wurde. Alle Ergebnisse tragen deshalb das Etikett `ROUTE_B…` (in `result.txt`) und dürfen nicht als „Originalbuild der 309“ bezeichnet werden.
* Unabhängige Hashes (aus ChatGPTs Baseline) gibt es nur für die elf gepinnten Dateien. Für die übrigen sieben vom Patch geänderten Dateien (`G28.cpp`, `gcode.cpp`, `LCD_RTS.cpp`, `motion.h`, `bedlevel.cpp`, `M420.cpp`, `planner.cpp`, `T.cpp`) gilt die Gleichheit nur, **soweit der Patch den damals gebauten Baum vollständig abbildet** (das kann ich ohne den Originalweg nicht unabhängig belegen).
* Die 309-Kontrolle in Route B ist also eine **Kontrolle der aus dem Patch reproduzierten 309**.

## Angriff B – GitHub Actions
**BLOCKED:** kein Zugriff auf GitHub (Log `38`). Es wurde **kein** Workflow gestartet. Präzise Android-Laufanleitung mit Dateiliste und erwarteten Artefakten: `05_INTEGRATION/ANDROID_GITHUB_LAUFANLEITUNG.md`. Route A hat zusätzlich einen **Preflight-Job**, der jede fehlende oder falsche Eingabe einzeln benennt, bevor gebaut wird; beide Routen enden mit dem Auswertungsjob aus C7 (rot, solange nicht alle vier Kombinationen belegt PASS sind).

## Angriff C – Compilerfehler
**Nicht anwendbar:** keine Logs, daher kein „erster echter Compilerfehler“; es wurde **nichts** an Firmware oder OEM verändert. Sobald Logs vorliegen, gilt der Ablauf aus der Anleitung (erster Fehler, neue Kopie, eigener Patch, erneuter Build, nur belegter Erfolg ist `PASS`).

## NEU / KORRIGIERT / FALSCH / OFFEN

**NEU:** Befund, wofür 287 gebraucht wird; erschöpfender Nachweis, dass das Original nicht rekonstruierbar ist; `verify_inputs_c8.py` (inkl. Strukturprüfung); Route A mit Preflight; Route B; `dryrun_route_b_c8.py`; Tests `W801`–`W804`, `I801`–`I804`.

**KORRIGIERT:** In C7 stand „`SV04_NEXT_287.zip` nicht prüfbar“; jetzt erklärt: Es ist die Quelle des Installers `integrate_286.py` und nirgends vorhanden. Der Workflow-Generator brach bei verändertem Quell-Workflow mit einem Traceback ab; er verweigert jetzt sauber (Exit 2, Test `W804`).

**FALSCH (meine Fehler dieser Runde):** Mein erstes Generatorgerüst enthielt einen Platzhalter-Hash und teilte nach Schritten statt nach Jobs; verworfen, bevor es benutzt wurde. Im Test `W801` war die Einrückung falsch gezählt. Im Probewerkzeug war die Zählung (12 statt 11) falsch und fehlte `pipefail`, sodass ein erwarteter Fehler verdeckt wurde; beides korrigiert und mit negativen Fällen belegt.

**OFFEN:** Originalroute (287 fehlt); alle vier STM32-Builds (nicht ausgeführt); Compilerfehler unbekannt; die unter „Weitere Risiken“ genannten Punkte.

## Weitere bekannte Risiken (Stand, nichts davon freigegeben)
* **Z-Homing aus unbekannter Position / 410 mm:** Auto60 gesperrt, manuelles G28 nicht; 410 mm sind eine Konfigurationsannahme, **kein Beleg** für Kollisionsfreiheit.
* **T0/T1-Kollisionsabstände:** unbekannt, keine neue Sperre.
* **BLTouch-Ausfall am Gerät:** nicht geprüft.
* **EEPROM-Journal, deaktivierter Schutz:** Im Host-Test `E20` wird „Schutz beim Speichern = KEINER, WARNUNG: kein Platz für das Undo-Journal“ seriell gemeldet, der Schutzmodus gilt also nicht als stromausfallsicher; **wie die DWIN-Anzeige das darstellt, ist nicht geprüft**, ebenso kein echter Stromausfall am Gerät.
* **DWIN-HMI-Projekt/Bildbibliothek und reale Anzeigen:** fehlen; Adressen statisch belegt, Anzeige BLOCKED.

## Fortschritt (unverändert)
| Nr | Funktion | Stand |
|---|---|---|
| 1 | IDEX + BLTouch | 88 % |
| 2 | G28 Homing | 81 % |
| 3 | G29 + Abbruch | 75 % |
| 4–6 | (Funktionsnamen liegen mir nicht vor) | 97 % / 70 % / 60 % |

Keine funktionale Weiterentwicklung belegt, daher alle Werte unverändert (Werte 3–6 aus meinen zuletzt belegten Unterlagen; ob Sie sie geändert haben, weiß ich nicht).

## Tests (Rohlogs in `04_ROHLOGS/`)
Kern 159/159 · EEPROM-Kern 33/33 · Host 55/55 · Simulation 240/240 · Mutationen 0 Überlebende (G29-Abbruch 13 · Betrieb 9 · Adapter 13 · Backend 10 · Koordinator 19 · EEPROM-Adapter 11 · Bedlevel 6 · Kern 24 · EEPROM-Kern 17; Quellen unverändert) · ChatGPTs 315-Tests gegen den 317-Adapter bestanden (Negativkontrollen gegen 314 BLOCKED). Neu in C8 zählen nur `W801`–`W804`, `I801`–`I804` und die Probe `43`; alles andere sind alte, weiterhin bestandene Tests. Host-Simulation und echte Firmware-/Hardwaretests bleiben strikt getrennt: es gibt keine Firmware- oder Hardwaretests.
