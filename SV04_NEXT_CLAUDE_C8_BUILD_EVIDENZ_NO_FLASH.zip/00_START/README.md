# SV04 NEXT – Claude C8: Build-Blocker – Start hier

**Kein Build ausgeführt (GitHub nicht erreichbar). `SV04_NEXT_287.zip` nicht vorhanden → Originalroute BLOCKED. Keine Firmware verändert, nichts geflasht, keine Hardwarefreigabe.**

* `00_START/ERGEBNISBERICHT.md` – Blocker, Eingaben, Route B, NEU/KORRIGIERT/FALSCH/OFFEN
* `00_START/VERGLEICH_C7_C8.md`
* `02_PATCHES/` – Workflow-Generator C8, Eingabeprüfung, Probewerkzeug, gehärteter Installer, Auswertung, Patchskripte, Diffs
* `03_TESTS/` – alle Tests; **`run_tests.py` im Wurzelverzeichnis ist der Einstieg**
* `04_ROHLOGS/` – `40`/`41` Suche nach 287, `42` Eingabeprüfung, `43` Probe Route B, `38` GitHub BLOCKED
* `05_INTEGRATION/ANDROID_GITHUB_LAUFANLEITUNG.md` – Dateiliste, Schritte, erwartete Artefakte
* `06_RISIKEN/RISIKEN.md`

Separat: `claude_c8_route_a_original_no_flash.yml`, `claude_c8_route_b_patch_no_flash.yml`. Prüfen: `python3 run_tests.py` (python3, g++, patch, git, PyYAML; ca. 4 Minuten).
