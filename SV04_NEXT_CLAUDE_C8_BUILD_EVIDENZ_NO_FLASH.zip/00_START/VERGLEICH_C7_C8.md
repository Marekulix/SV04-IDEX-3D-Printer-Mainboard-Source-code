# Vergleich C7 → C8 (Hashvergleich gegen die ausgelieferte C7-ZIP)

**Firmware-/OEM-Quellen (`claude/02_SOURCE`): 0 Änderungen.** C8 ändert keine Firmware- und keine OEM-Quelldatei (kein Build, keine Logs).

**Geändert:**
* `claude/tools/run_all_tests_a60.py`

**Neu:**
* `claude/04_TESTS/test_workflow_c8.py`
* `claude/docs_c7/claude_c7_stm32_no_flash.yml`
* `claude/tools/dryrun_route_b_c8.py`
* `claude/tools/make_workflow_c8.py`
* `claude/tools/verify_inputs_c8.py`
* `run_tests.py`

**Entfernt:**
* (keine)
