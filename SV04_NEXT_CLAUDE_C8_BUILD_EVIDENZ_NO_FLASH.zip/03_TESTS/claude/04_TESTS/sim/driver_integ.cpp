// KETTENSIMULATION: bedient den ECHTEN Auto60-Adapter + Koordinator + die ECHTE gepatchte G29.cpp + echte RTS_SndData. Auto60 wird NUR ueber M1060 und die Queue bedient.
#include "Marlin/src/inc/MarlinConfig.h"
#include "Marlin/src/feature/bedlevel/abl/abl.h"
#include "Marlin/src/lcd/e3v2/creality/LCD_RTS.h"
#include "sim_hmi_a60.h"
#include "sv04_claude_hooks.h"
#include "sv04_claude_auto60_core.h"
#include "sv04_claude_g29_session.h"
void sim_oem_boot_mesh_send();
extern RTSSHOW rtscheck; extern char waitway; extern void (*sim_idle_hook)();
extern int sim_save_mode; extern bool sim_readback_unavailable; void sim_ee_init_from_ram();
extern const char *sim_ee_out_path; extern uint8_t sim_other_a[300], sim_other_b[320]; bool sim_ee_load_image(const char *); void sim_ee_save_image(const char *); void sim_ee_set_faults(long long, long long); uint32_t sim_ee_changed(); uint8_t *sim_ee_bytes(); void sim_ee_set_unreadable(bool); void sim_ee_refresh();
struct Ee2 { bool header_ok; char ver[4]; float z[4][4]; float sp[2], st[2], fa[2]; float zoff; bool lev; unsigned saves, bytes, loads, validates; };
extern Ee2 g_ee;
#include "sv04_claude_auto60_marlin.inc"          // GENAU die Datei, die in LCD_RTS.cpp eingebunden wird
#if SV04_CLAUDE_AUTO60_ENABLE && ENABLED(EEPROM_SETTINGS)
  #define A60_STATE_NAME() sv04c::state_name(sv04c_coord.state())
  #define A60_TERMINAL() sv04c_coord.terminal()
  #define A60_REPORT() { sv04c::TransitionRec r; printf("RESULT state=%s reason=%s sid=%u\n", sv04c::state_name(sv04c_coord.state()), sv04c::reason_name(sv04c_coord.reason()), sv04c_coord.session()); printf("LOG"); for (int i = (int)sv04c_coord.log_count() - 1; i >= 0; i--) if (sv04c_coord.log_at((unsigned)i, r)) printf(" %s>%s(%s)", sv04c::state_name(r.from), sv04c::state_name(r.to), sv04c::reason_name(r.why)); printf("\n"); }
#else
  #define A60_STATE_NAME() "IDLE"
  #define A60_TERMINAL() false
  #define A60_REPORT() { printf("RESULT state=IDLE reason=NONE sid=0\nLOG\n"); }
#endif
#include <map>
#include <algorithm>
#include <string.h>

static std::map<std::string, std::string> opt;
static bool gi_boot_only_done = false;
static std::string gs(const char *k, const char *d) { auto i = opt.find(k); return i == opt.end() ? d : i->second; }
static int gi(const char *k, int d) { auto i = opt.find(k); return i == opt.end() ? d : atoi(i->second.c_str()); }
static float gf(const char *k, float d) { auto i = opt.find(k); return i == opt.end() ? d : (float)atof(i->second.c_str()); }
static linear_axis_bits_t bits(const std::string &t) { linear_axis_bits_t b = 0; if (t == "all") return 7; for (char c : t) { if (c == 'X') b |= 1; if (c == 'Y') b |= 2; if (c == 'Z') b |= 4; } return b; }
static bool queue_stalled() { return gi("queue_stall", 0) && sim_ms < (uint32_t)(100000 + gi("queue_release_s", 100000) * 1000); }   // die Queue haengt bis queue_release_s nach dem Start
static void run_queue() {
  while (!queue2.q.empty()) {
    if (queue_stalled()) return;
    const std::string c = queue2.q.front(); queue2.q.pop_front();
    if (c == "G29") { W.log("exec G29"); W.params.clear(); GcodeSuite::G29(); }
    else if (c == "G28 X Y Z") { W.log("exec G28 X Y Z"); W.params.clear(); W.params['X'] = W.params['Y'] = W.params['Z'] = 1e30f; GcodeSuite::G28(); W.params.clear(); }
    else if (c == "G28") { W.log("exec G28"); W.params.clear(); GcodeSuite::G28(); }
    else if (c == "G28 X") { W.log("exec G28 X"); W.params.clear(); W.params['X'] = 1e30f; GcodeSuite::G28(); W.params.clear(); }
    else W.log("exec " + c);
  }
}
static void bed_model() {
  const float tgt = (float)thermalManager.temp_bed.target; const std::string m = gs("heat", "normal");
  if (m == "nan") { thermalManager.temp_bed.celsius = NAN; return; }
  if (m == "stuck") return;
  if (tgt > 0) thermalManager.temp_bed.celsius += (tgt - thermalManager.temp_bed.celsius) * 0.08f; else thermalManager.temp_bed.celsius += (25 - thermalManager.temp_bed.celsius) * 0.02f;
}
static bool kicked = false;
static uint32_t term_ms = 0; static bool again_done = false, rerun_done = false;
static bool touch_probe_done = false;
static bool touch_done = false, cancel_done = false, print_done = false, kick28_done = false;
static void touch_event() { if (gi("rx_touch", 0) || gi("no_idle_rts", 0)) W.rx_frames++; else SV04Claude_Auto60_TouchCancel(); }
static void touch_probe_event() { for (int i = 0; i < gi("touch_probe_burst", 1); i++) touch_event(); }   // rx_touch/no_idle_rts: der Touch kommt als RAHMEN aus der Leitung (nicht als direkter Aufruf)
static void rts_receive() { while (rtscheck.RTS_RecData() > 0) rtscheck.RTS_HandleData(); }                 // Empfangsschleife am Ende von RTSUpdate()
static bool g29s_done = false, in_probe_done = false, nan_move_done = false, stop_done = false;
static void tick_all() {
  if (gi("stop_at_probe", 0) && !stop_done && W.in_probe && W.probe_calls >= gi("stop_at_probe", 0)) { stop_done = true; sim_stop(); }      // C4: Marlin stop() (z. B. BLTouch-Alarm) mitten in der G29
  if (gi("nan_move", 0) && !nan_move_done && W.in_probe && W.probe_calls >= gi("nan_move", 0)) { nan_move_done = true; do_blocking_move_to_z(NAN); }      // Positivkontrolle des Finite-Guards
  #if SV04_CLAUDE_AUTO60_ENABLE && ENABLED(EEPROM_SETTINGS)
  if (gi("touch_g29_start", 0) && !g29s_done && sv04c_coord.state() == sv04c::ST_PROBING && W.probe_calls == 0) { touch_event(); g29s_done = true; }     // Touch UNMITTELBAR nach dem G29-Beginn (vor der ersten Messung)
  #endif
  if (gi("touch_in_probe", 0) && !in_probe_done && W.in_probe && W.probe_calls == gi("touch_in_probe", 0) - 1) { touch_probe_event(); in_probe_done = true; }      // Touch WAEHREND der Messung k (vor der Uebernahme des Werts)
  if (gi("touch_after_probe", 0) && !touch_probe_done && W.probe_calls >= gi("touch_after_probe", 0)) { touch_probe_event(); touch_probe_done = true; }   // Touch WAEHREND der laufenden G29 (idle() -> RTSUpdate)
  if (gi("touch_after_homeaxis", 0) && !touch_done && W.homeaxis_calls >= gi("touch_after_homeaxis", 0)) { for (int i = 0; i < gi("touch_burst", 1); i++) touch_event(); touch_done = true; }
  if (gi("cancel_after_homeaxis", 0) && !cancel_done && W.homeaxis_calls >= gi("cancel_after_homeaxis", 0)) { W.params.clear(); W.params['S'] = 0; SV04Claude_Auto60_Gcode(); cancel_done = true; }
  if (gi("print_after_homeaxis", 0) && !print_done && W.homeaxis_calls >= gi("print_after_homeaxis", 0)) { card.printing = true; print_done = true; }
  if (gi("kick_after_homeaxis", 0) && !kick28_done && W.homeaxis_calls >= gi("kick_after_homeaxis", 0)) { thermalManager.temp_bed.celsius = gf("kick", 40); kick28_done = true; }      // = idle() -> RTSUpdate() -> Tick; laeuft auch WAEHREND der G29 (re-entrant, durch die Sperre im Adapter geschuetzt)
  if (gi("kick_after_probe", -1) >= 0 && !kicked && W.probe_calls >= gi("kick_after_probe", 0)) { thermalManager.temp_bed.celsius = gf("kick", 40); kicked = true; }
  if (gi("no_idle_rts", 0) == 0) { rts_receive(); SV04Claude_Auto60_Tick(); }       // no_idle_rts=1: idle() ruft RTSUpdate() NICHT auf (nur die Hauptschleife und der Abbruchtest der G29 lesen den Puffer)
}
static void cmd(const char *s, float p) { W.params.clear(); W.params['S'] = p; (void)s; SV04Claude_Auto60_Gcode(); }

extern void (*sim_run_g28_hook)(const std::string &);
static void run_g28_from_script(const std::string &g) {      // G29-Endskript "G28 XY": derselbe echte G28
  std::map<char, float> keep = W.params; W.params.clear();
  for (size_t i = 3; i < g.size(); i++) if (g[i] >= 'A' && g[i] <= 'Z') W.params[g[i]] = 1e30f;
  GcodeSuite::G28(); W.params = keep;
}
int main(int argc, char **argv) {
  for (int i = 1; i < argc; i++) { std::string a = argv[i]; size_t e = a.find('='); if (e == std::string::npos) opt[a] = "1"; else opt[a.substr(0, e)] = a.substr(e + 1); }
  W.reset(); axis_homed = bits(gs("homed", "all")); axis_trusted = axis_homed; sim_ms = 100000; sim_idle_hook = tick_all; sim_run_g28_hook = run_g28_from_script;
  planner.leveling_active = gi("lev0", 1) != 0;
  if (gi("stopped0", 0)) sim_stopped = true;                                  // C5: Marlin ist von Anfang an im Stopp-Zustand
  for (int x = 0; x < 4; x++) for (int y = 0; y < 4; y++) z_values[x][y] = 0.31f - 0.05f * x + 0.02f * y;   // "altes" Mesh (EEPROM + RAM)
  bilinear_grid_spacing.set(84, 84); bilinear_start.set(25, 25); bilinear_grid_factor = bilinear_grid_spacing.reciprocal();
  if (gi("old_nan", 0)) z_values[2][1] = NAN;                                   // Test: altes Mesh mit gueltigem Raster, aber EINEM NaN-Punkt (teilweise gemessen)
  if (gi("old_zero_spacing", 0)) { bilinear_grid_spacing.set(0, 0); bilinear_grid_factor.set(0, 0); }   // Test: altes Mesh mit endlichen Werten, aber Raster 0
  probe.offset.z = gf("zoff", -1.10f); thermalManager.temp_bed.celsius = gf("bed0", 25); thermalManager.temp_bed.target = (int16_t)gi("target0", 0);
  sim_ee_out_path = gs("ee_out", "").empty() ? nullptr : strdup(gs("ee_out", "").c_str());
  sim_ee_init_from_ram();
  if (!gs("ee_in", "").empty()) { if (!sim_ee_load_image(gs("ee_in", "").c_str())) { printf("RESULT state=ERROR reason=ee_in\n"); return 3; } 
    { void (*const hook)() = sim_idle_hook; sim_idle_hook = nullptr; planner.leveling_active = false;     // Marlin-BOOT: load() laeuft im setup(), OHNE Display-Schleife (kein RTSUpdate/Auto60-Tick) und mit ausgeschalteter Nivellierung
      settings2.load(); sim_idle_hook = hook; planner.leveling_active = gi("lev0", 0) != 0; }          // nach einem Neustart ist die Nivellierung AUS (Flag wird fuer Bilinear nicht gespeichert)
    W.cmds.clear(); }   // NEUSTART mit dem Abbild
  if (gi("other_dirty", 0)) sim_other_a[7] ^= 0x5A;                       // eine ungespeicherte Aenderung einer anderen Einstellung (z. B. M92) im RAM
  const Ee2 ee0 = g_ee; const float z0 = probe.offset.z; sim_save_mode = gi("save", 0); sim_readback_unavailable = gi("noreadback", 0) != 0;
  sim_ee_set_faults(gi("ee_cut_at", -1), gi("ee_fail_at", -1)); sim_ee_set_unreadable(gi("ee_unreadable", 0) != 0);
  const std::vector<unsigned char> ee_before(sim_ee_bytes(), sim_ee_bytes() + 2048);
  W.m420_noop = gi("m420_noop", 0) != 0; dual_x_carriage_mode = (DualXMode)gi("mode", 1); extruder_duplication_enabled = gi("dupl", dual_x_carriage_mode >= 2 ? 1 : 0) != 0; sim_hotend_offset_x1 = gf("hotend_x1", 188.0f);
  W.deploy_fail = gi("deploy_fail", 0); W.stow_fail = gi("stow_fail", 0); W.bltouch_alarm = gi("bltouch_alarm", 0); W.x_early_t1 = gi("x_early_t1", 0); W.x_early_t0 = gi("x_early_t0", 0); W.kill_x_t1 = gi("kill_x_t1", 0); W.kill_x_t0 = gi("kill_x_t0", 0); W.kill_z = gi("kill_z", 0); W.kill_y = gi("kill_y", 0); W.homeaxis_ms = (uint32_t)gi("homeaxis_ms", 4000); W.x_t1_on_call = gi("x_t1_on_call", 0);
  W.probe_ms = (uint32_t)gi("probe_ms", 1500); W.homed = true; card.printing = gi("printing", 0) != 0; W.paused = gi("paused", 0) != 0; if (gi("ext1", 0)) active_extruder = 1; if (gi("dupl", 0)) extruder_duplication_enabled = true; if (gi("waitway", 0)) waitway = 3;
  if (gi("boot", 1)) sim_oem_boot_mesh_send();      // Display zeigt nach dem Boot das (EEPROM-)Mesh: OEM-Bootschleife (LCD_RTS.cpp:311-337)
  const std::vector<unsigned char> boot_wire = W.wire; bool busy_seen = false, double_done = false;
  for (int k = 0; k < 16; k++) W.probe_script.push_back(0.012f * (k - 8) + 0.0031f * k);
  if (gi("val_at", -1) >= 0) W.probe_script[(size_t)gi("val_at", 0)] = gf("val", 0);
  if (gi("nan_at", -1) >= 0) W.probe_script.resize((size_t)gi("nan_at", 0));
  const std::string cancel_at = gs("cancel_at", ""), touch_at = gs("touch_at", ""); bool cancelled = false, touched = false, foreign28 = false, foreign_exec = false; const uint32_t limit = (uint32_t)gi("limit_s", 4000) * 1000;
  if (gi("manual_g28", 0)) queue2.enqueue_now_P("G28");
  if (gi("boot_only", 0)) {                                                    // nur der Neustart: erster Tick (Startwiederherstellung), dann M1060 S2/S3 ausgeben
    SV04Claude_Auto60_Tick();
    {                                                                              // Item 5: die lesenden Befehle aendern weder RAM-Mesh, Z-Offset, Nivellierung noch den Fahrzustand
      const bool lev_b = planner.leveling_active; const xyze_pos_t pos_b = current_position; const float zo_b = probe.offset.z; const xyz_pos_t po_b = probe.offset;
      float z_b[GRID_MAX_POINTS_X][GRID_MAX_POINTS_Y]; memcpy(z_b, z_values, sizeof z_b); const xy_pos_t sp_b = bilinear_grid_spacing, st_b = bilinear_start; const size_t cmds_b = W.cmds.size();
      W.params.clear(); W.params['S'] = 2; SV04Claude_Auto60_Gcode(); W.params['S'] = 3; SV04Claude_Auto60_Gcode();
      const bool mesh_same = memcmp(z_b, z_values, sizeof z_b) == 0 && memcmp(&sp_b, &bilinear_grid_spacing, sizeof sp_b) == 0 && memcmp(&st_b, &bilinear_start, sizeof st_b) == 0;
      bool moved = false; for (size_t i = cmds_b; i < W.cmds.size(); i++) if (W.cmds[i].find("homeaxis") != std::string::npos || W.cmds[i].find("do_blocking_move") != std::string::npos || W.cmds[i].find("buffer_line") != std::string::npos) moved = true;
      printf("S2S3_UNCHANGED lev=%d pos=%d mesh=%d zoff=%d offset=%d no_motion=%d\n", lev_b == planner.leveling_active ? 1 : 0, memcmp(&pos_b, &current_position, sizeof pos_b) == 0 ? 1 : 0, mesh_same ? 1 : 0, zo_b == probe.offset.z ? 1 : 0, memcmp(&po_b, &probe.offset, sizeof po_b) == 0 ? 1 : 0, moved ? 0 : 1);
    }
    gi_boot_only_done = true;
  }
  if (gi("touch_idle", 0)) SV04Claude_Auto60_TouchCancel();
  if (gi("rx_idle", 0)) W.rx_frames += gi("rx_idle", 0);                         // DWIN-Rahmen VOR dem Start (kein Lauf aktiv): normale Tastenbehandlung, nie ein Abbruch                      // Touch, solange KEIN Lauf aktiv ist (darf spaeter keinen Lauf abbrechen)
  W.params.clear(); W.params['S'] = 1; if (!gi_boot_only_done && gi("nostart", 0) == 0 && gi("manual_g29", 0) == 0 && gi("manual_g28", 0) == 0) SV04Claude_Auto60_Gcode();     // M1060 S1
  if (gi("manual_g29", 0)) queue2.enqueue_now_P("G29");                                                                  // normale Anwender-G29 ohne Auto60
  const uint32_t t0 = sim_ms; bool changed_target = false;
  while (sim_ms - t0 < limit) {
    sim_ms += 100; bed_model();
    if (gi("retarget_s", 0) && !changed_target && sim_ms - t0 > (uint32_t)gi("retarget_s", 0) * 1000) { thermalManager.temp_bed.target = 55; changed_target = true; }
    if (gi("bed_kick_at_s", 0) && sim_ms - t0 > (uint32_t)gi("bed_kick_at_s", 0) * 1000) thermalManager.temp_bed.celsius = gf("bed_kick", 40);
    if (!touch_at.empty() && !touched && std::string(A60_STATE_NAME()) == touch_at) { SV04Claude_Auto60_TouchCancel(); touched = true; }
    if (gi("request_again_s", 0) && !again_done && sim_ms - t0 > (uint32_t)gi("request_again_s", 0) * 1000) {       // direkter Zweitaufruf des Backends (Zulassungspruefung)
      again_done = true;
      #if SV04_CLAUDE_AUTO60_ENABLE && ENABLED(EEPROM_SETTINGS)
        printf("REQAGAIN same=%d zero=%d wrong=%d\n", SV04Claude_HomeBackendRequest(sv04c_coord.session()) ? 1 : 0, SV04Claude_HomeBackendRequest(0) ? 1 : 0, SV04Claude_HomeBackendRequest(sv04c_coord.session() + 5) ? 1 : 0);
      #endif
    }
    if (gi("printing_at_s", 0) && sim_ms - t0 > (uint32_t)gi("printing_at_s", 0) * 1000) card.printing = true;
    if (gi("foreign_g28_exec_s", 0) && !foreign_exec && sim_ms - t0 > (uint32_t)gi("foreign_g28_exec_s", 0) * 1000) { foreign_exec = true; W.log("exec G28 X (Anwender)"); std::map<char, float> keep = W.params; W.params.clear(); W.params['X'] = 1e30f; GcodeSuite::G28(); W.params = keep; }
    if (gi("foreign_g28_at_s", 0) && sim_ms - t0 > (uint32_t)gi("foreign_g28_at_s", 0) * 1000 && !queue2.has_commands_queued() && !foreign28) { queue2.enqueue_now_P("G28 X"); foreign28 = true; }
    if (!cancel_at.empty() && !cancelled && std::string(A60_STATE_NAME()) == cancel_at) { cmd("M1060", 0); cancelled = true; }
    rts_receive(); SV04Claude_Auto60_Tick(); if (SV04Claude_Auto60_Busy()) busy_seen = true;
    if (gi("double_start", 0) && !double_done && sim_ms - t0 > (uint32_t)gi("double_start", 0) * 1000) { double_done = true; W.params.clear(); W.params['S'] = 1; SV04Claude_Auto60_Gcode(); }
    if (gi("foreign_g29_at_s", 0) && sim_ms - t0 > (uint32_t)gi("foreign_g29_at_s", 0) * 1000 && !queue2.has_commands_queued()) { queue2.enqueue_now_P("G29"); opt["foreign_g29_at_s"] = "0"; }
    run_queue();
    #if SV04_CLAUDE_AUTO60_ENABLE && ENABLED(EEPROM_SETTINGS)
    if (A60_TERMINAL() && (sim_ms - t0) > 200 && gi("rerun", 0) && !rerun_done) {          // zweiter Lauf direkt nach dem ersten
      rerun_done = true; printf("RESULT1 state=%s reason=%s\n", sv04c::state_name(sv04c_coord.state()), sv04c::reason_name(sv04c_coord.reason()));
      if (gi("m999", 0)) sim_stopped = false;                                              // C4: M999 (Neustart nach stop()) vor dem zweiten Lauf
      if (gi("m999", 0) == 2) { W.bltouch_alarm = false; W.deploy_fail = false; W.stow_fail = false; }      // C4: Sensor repariert
      if (gi("touch_late", 0)) SV04Claude_Auto60_TouchCancel();                              // Touch NACH dem Ende des ersten Laufs
      W.probe_calls = 0;                                                                    // das Messskript beginnt von vorn (gleiche Messwerte = bitgleiches Mesh)
      W.params.clear(); W.params['S'] = 1; SV04Claude_Auto60_Gcode(); term_ms = 0; continue;
    }
    #endif
    if (A60_TERMINAL() && (sim_ms - t0) > 200) { if (!term_ms) term_ms = sim_ms; if (sim_ms - term_ms >= (uint32_t)gi("tail_s", 0) * 1000) break; }   // tail_s: nach dem Endzustand weiterlaufen (spaete Queue-Freigabe)
  }
  VirtualHmiA60 hmi0; hmi0.feed(boot_wire); VirtualHmiA60 hmi; hmi.feed(W.wire);
  sim_ee_refresh();
  A60_REPORT();
  printf("EE saves=%u bytes=%u header_ok=%d ver=%s loads=%u validates=%u mesh_changed=%d zoff_changed=%d\n", g_ee.saves, g_ee.bytes, g_ee.header_ok ? 1 : 0, [&] { static char v[5]; for (int i = 0; i < 4; i++) v[i] = (g_ee.ver[i] >= 32 && g_ee.ver[i] < 127) ? g_ee.ver[i] : '?'; v[4] = 0; return (const char *)v; }(), g_ee.loads, g_ee.validates, memcmp(g_ee.z, ee0.z, sizeof g_ee.z) != 0, memcmp(&g_ee.zoff, &ee0.zoff, 4) != 0);
  printf("RAM zoff_unchanged=%d leveling=%d bed_target=%d\n", memcmp(&probe.offset.z, &z0, 4) == 0, planner.leveling_active ? 1 : 0, (int)thermalManager.temp_bed.target);
  printf("MESH"); for (int y = 0; y < 4; y++) for (int x = 0; x < 4; x++) printf(" %.4f", (double)z_values[x][y]); printf("\n");
  printf("EEMESH"); for (int y = 0; y < 4; y++) for (int x = 0; x < 4; x++) printf(" %.4f", (double)g_ee.z[x][y]); printf("\nEEZOFF %.4f\nRAMZOFF %.4f\nGEOM %.4f %.4f %.6f\n", (double)g_ee.zoff, (double)probe.offset.z, (double)bilinear_grid_spacing.x, (double)bilinear_start.x, (double)bilinear_grid_factor.x);
  #if SV04_CLAUDE_AUTO60_ENABLE && ENABLED(EEPROM_SETTINGS)
  { const sv04c::ee::Store st = sv04c_ee_store(); const sv04c::ee::Block bl = sv04c_ee_block(); const sv04c::ee::PrimaryInfo pi = sv04c::ee::primary_info(st, bl); const sv04c::ee::ShadowPlan sp = sv04c::ee::shadow_plan(st, bl); sv04c::ee::ShadowInfo si; memset(&si, 0, sizeof si);
    if (sp.ok) sv04c::ee::shadow_info(st, sp, bl, true, si);
    printf("EERAW primary=%d journal_room=%d journal_present=%d journal_inflight=%d journal_data_ok=%d boot_res=%d boot_primary=%d journal_state=%d last_commit=%d other=%u skipped=%d changed=%u\n", (int)pi.st, sp.ok ? 1 : 0, si.present ? 1 : 0, si.inflight ? 1 : 0, si.data_ok ? 1 : 0, (int)sv04c_ee_boot_res, (int)sv04c_ee_boot_primary, (int)sv04c_ee_journal, (int)sv04c_ee_last_commit, (unsigned)sv04c_ee_other, sv04c_coord.save_skipped() ? 1 : 0, sim_ee_changed());
    printf("EEBYTES_CHANGED_VS_START %u\n", [&] { unsigned n = 0; for (int i = 0; i < 2048; i++) if (ee_before[i] != sim_ee_bytes()[i]) ++n; return n; }());
    printf("EEMAINEQ %d\n", [&] { for (int i = 0; i < bl.len; i++) if (ee_before[bl.start + i] != sim_ee_bytes()[bl.start + i]) return 0; return 1; }());
  }
  #endif
  if (sim_ee_out_path) sim_ee_save_image(sim_ee_out_path);
  printf("RX polled=%d pending=%d\n", W.rx_polled, W.rx_frames);
  printf("WIREHEX "); for (unsigned char b : W.wire) printf("%02X", b); printf("\nBOOTLEN %zu\n", boot_wire.size());
  printf("P1RESULT seq=%u completed=%d ok=%d t1_ok=%d t0_ok=%d z_ok=%d\n", sv04_p1_g28_result.seq, sv04_p1_g28_result.completed, sv04_p1_g28_result.ok, sv04_p1_g28_result.t1_ok, sv04_p1_g28_result.t0_ok, sv04_p1_g28_result.z_ok);
  printf("AXES homed=%d trusted=%d active_ext=%d dupl=%d mode=%d\n", (int)axis_homed, (int)axis_trusted, (int)active_extruder, extruder_duplication_enabled ? 1 : 0, (int)dual_x_carriage_mode);
  printf("HOMEAXIS count=%d\n", W.homeaxis_calls);
  #if SV04_CLAUDE_AUTO60_ENABLE && ENABLED(EEPROM_SETTINGS)
  printf("STALE %u\n", sv04c_coord.stale_events());
  #else
  printf("STALE 0\n");
  #endif
  printf("HMI0"); for (unsigned k = 0; k < 16; k++) printf(" %d", hmi0.cell(k)); printf("\n");
  printf("BUSY seen=%d after=%d\n", busy_seen ? 1 : 0, SV04Claude_Auto60_Busy() ? 1 : 0);
  printf("HMI"); for (unsigned k = 0; k < 16; k++) printf(" %d", hmi.cell(k)); printf("\nHMIPAGE %d\nHMIBAD %d\nHMIMULTI %d\nHMICELLWRITES %zu\n", hmi.page, hmi.bad, hmi.multiword, hmi.cell_writes.size());
  printf("COUNTS probe=%d m420=%d settings_save=%d\n", W.probe_calls, (int)std::count(W.cmds.begin(), W.cmds.end(), std::string("set_bed_leveling_enabled(true)")), (int)g_ee.saves);
  if (gi("s3_end", 0)) { W.params.clear(); W.params['S'] = 3; SV04Claude_Auto60_Gcode(); }       // M1060 S3 am Ende (Schutzstatus, Zaehler)
  printf("CMDS"); for (auto &c : W.cmds) printf(" %s;", c.c_str()); printf("\nSERIAL"); for (auto &s : W.serial) printf(" [%s]", s.c_str()); printf("\n");
  return 0;
}

void sim_dump_and_exit(const char *) { printf("RESULT state=KILLED reason=kill\n"); exit(0); }
