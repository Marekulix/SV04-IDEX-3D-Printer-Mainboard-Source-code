#!/usr/bin/env python3
"""Static audit of a DWIN mapping file. Never sends UART or builds touch binaries.

Input JSON shape: {"oem_vps":[int or '0xHEX'], "new_vps":[...], "touch_bindings":[{"name":"...","vp":"0x...","hardware_verified":bool}]}.
"""
import argparse,json
from pathlib import Path

def num(v):
    if type(v) is int:return v
    if isinstance(v,str):return int(v,0)
    raise ValueError('invalid VP')

def audit(document):
    errors=[];old=set();new=set()
    for v in document.get('oem_vps',[]):
        n=num(v)
        if n in old: errors.append('duplicate_oem_vp:'+hex(n))
        old.add(n)
    for v in document.get('new_vps',[]):
        n=num(v)
        if n in new:errors.append('duplicate_new_vp:'+hex(n))
        if n in old:errors.append('oem_vp_collision:'+hex(n))
        new.add(n)
    touches=document.get('touch_bindings',[])
    for e in touches:
        n=num(e['vp'])
        if n not in new:errors.append('touch_vp_not_declared:'+hex(n))
        if e.get('hardware_verified') is not True:errors.append('touch_hardware_not_verified:'+str(e.get('name','unnamed')))
    # Collisions and hardware verification are necessary, not sufficient for HMI release.
    return {'errors':errors,'new_vp_count':len(new),'touch_count':len(touches),
            'offline_contract_ok':not errors,'display_release':False,'flash_approved':False}

def main():
    p=argparse.ArgumentParser();p.add_argument('mapping');p.add_argument('--out',default='');a=p.parse_args()
    result=audit(json.loads(Path(a.mapping).read_text()))
    print(json.dumps(result,indent=2));
    if a.out: Path(a.out).write_text(json.dumps(result,indent=2)+'\n')
    return 0 if not result['errors'] else 2
if __name__=='__main__':raise SystemExit(main())
