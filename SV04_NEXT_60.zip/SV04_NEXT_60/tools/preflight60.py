#!/usr/bin/env python3
"""SV04 NEXT 60 deterministic source preflight, does not command printer.

Only verifies presence and risk markers. This is not a physical safety proof.
"""
import argparse
import hashlib
import json
from pathlib import Path

REQUIRED = [
 'platformio.ini', 'Marlin/Configuration.h', 'Marlin/Configuration_adv.h',
 'Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp',
]

def file_sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()

def scan(base: Path, environment: str | None = None):
    root = base.resolve()
    report = {'root':str(root),'source_present':{},'sha256':{},'checks':{},'environment':environment,'ready_for_stm32_build':False,'flash_approved':False}
    for rel in REQUIRED:
        f = root / rel
        exists = f.is_file() and f.resolve().is_relative_to(root)
        report['source_present'][rel] = exists
        if exists: report['sha256'][rel]=file_sha(f)
    ini = root/'platformio.ini'
    if ini.is_file():
        ini_content = ini.read_text(encoding='utf-8',errors='replace')
        if environment:
            import re
            report['checks']['environment_present'] = bool(re.search(r'^\s*\[env:'+re.escape(environment)+r'\]\s*$',ini_content,re.M))
        else:report['checks']['environment_present']=False
    else: report['checks']['environment_present']=False
    conf = root/'Marlin/Configuration.h'
    if conf.is_file():
        data=conf.read_text(encoding='utf-8',errors='replace')
        # Only check indicative macros; comments and conditionals are not evaluated.
        for m in ['BLTOUCH','AUTO_BED_LEVELING_BILINEAR','GRID_MAX_POINTS_X']:
            report['checks']['seen_'+m]=m in data
    report['ready_for_stm32_build'] = (all(report['source_present'].values()) and report['checks'].get('environment_present',False))
    return report

def main():
    p=argparse.ArgumentParser();p.add_argument('--base',default='firmware');p.add_argument('--env',default='');p.add_argument('--output',default='SV04_NEXT_60/proof/preflight60.json');a=p.parse_args()
    result=scan(Path(a.base),a.env)
    out=Path(a.output);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({'ready_for_stm32_build':result['ready_for_stm32_build'],'missing':[k for k,v in result['source_present'].items() if not v],'environment_present':result['checks']['environment_present'],'flash_approved':False}))
    return 0 if result['ready_for_stm32_build'] else 2
if __name__=='__main__':raise SystemExit(main())
