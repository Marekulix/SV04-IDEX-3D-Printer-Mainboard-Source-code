# SV04 NEXT 60 – überprüfbare Übergabe

Quelle: Berichte zum Stand 30, 51–53 sowie Arbeitsstand 59. Der erwähnte Stand 57 (G29 U Q P0…P4) kann ohne dessen vollständige OEM-/Overlay-Quellen nicht rekonstruiert oder verifiziert werden.

## Sechs angeforderte Themen und Realität

1. **Marlin-Firmware:** Host-C++-Gates prüfbar; Quellenstand 57 fehlt hier. STM32-Build nicht behauptet.
2. **DWIN:** Offline-VP-Konflikte und Hardware-Verifikationsvorgaben prüfbar. Keine echten DWIN-Show-/Touch-Binaries, da Originalprojekt des eingebauten Displays fehlt.
3. **T1-Kollision:** Ein konservatives Mathematikmodell existiert. Reale X-Limits, Parkabstände, Carriage-Hüllkurven und BLTouch-/T0-/T1-Konfiguration müssen am Gerät bestätigt werden.
4. **Auto60:** Nur Offline-Modell mit Start im Idle/T0, M190 S60, Stabilisierung, G28, 4×4 G29, Prüfung 16/16, M420 S1 und erst danach M500. Im realen Gerät nicht aktiviert; keine automatische Z-Offset-Änderung.
5. **EEPROM:** Modell sichert gegen vorzeitiges Schreiben; für Fehlerpfade ohne M500 schützt das bestehende EEPROM. Hardware-Recovery und M420 V/M503-Verifikation fehlen.
6. **GitHub:** `60.yml` baut in einer separaten ubuntu-24.04 CI mit PlatformIO, aber nur mit vollständigem, geprüftem OEM-Quellbaum und exakt dokumentierter Env. Das Paket ist Android-tauglich über Upload ZIP + YAML.

### Freigabegrenzen

- Hosttests beweisen weder physische Druckersicherheit noch korrekte Integration in OEM-Marlin.
- Ein grüner STM32-Job beweist Compiler-Erfolg, **keine** sichere Druckermechanik oder Display-Kompatibilität.
- Flashrelease, Auto60-Touchstart und EEPROM-Recovery bleiben gesperrt.
- Verwende Firmware aus noch unvalidierten Builds nicht für Hardwareversuche.

### Prüfprotokoll

Lokale Tests liegen in `ci_verify60.sh`; SHA256SUMS enthält alle Artefakte außer der Manifestdatei selbst. Build- und Hardwareprüfungen erst anhand der GitHub-Artefakte beziehungsweise der Maschine beurteilen.
