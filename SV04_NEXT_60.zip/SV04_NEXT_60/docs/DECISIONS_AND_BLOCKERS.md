# SV04 NEXT 59 – verbindliche Festlegungen und tatsächliche Abnahme

## Gerät
Sovol SV04 IDEX, Creality V5.2.1, Marlin V1.1.0, 2 Extruder, BLTouch, Z-Offset derzeit -1,10 mm. Kein Windows-PC beim Nutzer, Android-Tablet + GitHub Actions.

## Sicherheitsablauf – bisheriger Beschluss
Nur Idle und sichere Werkzeuglage, Bett 60 °C und Temperaturstabilisierung; abgesichertes G28, vorhandenes 4×4 G29 mit vollständiger Messung, Mesh validieren, M420 S1 aktivieren; M500 **nur nach vollständigem Erfolg**; gespeicherte Daten mit M420 V/M503 überprüfen. Vorherigen EEPROM-Mesh bei fehlgeschlagenem G29 nicht überschreiben. Notabbruch. Keine automatische Z-Offset-Änderung. Nicht mit geführter manueller Ausrichtung mischen. Fortschritt 1–16, farbige Karte und klarer Status im DWIN erst nach echter HMI-Quellen- und VP-Bindungsprüfung.

## Stand vor 59
Quellenbericht 51–53: 39,50 % Gesamtfortschritt; Marlin-Diagnosebibliothek, DWIN-Projekt-Quellen und G29 U Q lesend, Testhost grün; NICHT auf Gerät gebaut/geflasht. Neuester hier genannter Stand 57: Diagnose G29 U Q P0..P4, ursprünglicher Overlay nicht im aktuellen Container gefunden. Stand 58 war ausschließlich Offline-Mesh-Prüfung. Verschiedene DWIN-Projekte sind nicht automatisch kompatibel. Geräte-Touch-Atlas mehrdeutig.

## In 59 tatsächlich erstellt
- Reiner Python-State-Machine-Dry-Run: M190 S60, G28, G29, M420 S1, M500 mit expliziten Zwischengates und negativer Freigabe.
- IDEx-Rechenmodell mit Gehäusebreiten und Abständen: nur Mathematik, keine reale Kollisionsfreigabe.
- C++11-Sicherheitsschalter: RELEASE-Makros schlagen beim Kompilieren fehl, Motor/Heiz/EEPROM vollständig gesperrt.
- Readonly-DWIN VP-Konfliktprüfung: keine echten Touchadressen und keine DWIN-Binärdatei.
- GitHub Actions Workflow mit Host-Gates und explizitem STM32-Job, der bei fehlenden OEM-Quellen ROT ist. Ein grüner Host-Job ist KEIN STM32-Build.

## Nicht erledigte Freigaben – kein Täuschen durch grüne Unit-Tests
1. Stand-57-Original-Overlay und OEM-Marlin-Quellstand fehlen; deshalb keine echte Marlin-Integration und kein kompiliertes flashfähiges Image.
2. Original-DWIN-Projekt des eingebauten Displays und Touch/VP-Ground-Truth fehlen; keine neue Auto60-Taste und kein farbiges Display-Binary.
3. Reale T1-Park-/X-Limits, Werkzeugbreiten, Homing-Positionen, BLTouch-Offsets, Kollisionsabstände und Temperaturverhalten sind nicht unabhängig gemessen; keine mechanische Freigabe.
4. 60-°C-Ablauf kann nicht ohne tatsächlich identifizierte G29-Response-/EEPROM-Gates auf das Gerät angewendet werden.
5. Kein verbundener GitHub-Repo-Zugriff; Workflow nicht gestartet. Keine Binary und keine Geräteverifikation.

## Expliziter Sicherheitsstatus
**NICHT FLASHEN.** Dieses Paket enthält keine aktualisierte Firmware, keine ausführbaren Druckerbefehle und keine DWIN-Flashboardware. Es gibt Code, Tests und CI-Gerüst; kein erfolgreich geprüfter integrierter Release.
