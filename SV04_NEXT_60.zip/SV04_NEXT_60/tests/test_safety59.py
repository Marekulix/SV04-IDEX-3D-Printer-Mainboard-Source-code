import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from sv04_safety import BedMeshGate,ReleaseEvidence,IdexClearance,Stage
E=ReleaseEvidence(oem_source_sha256='abc',stm32_build_passed=True,display_hmi_matches_installed=True,touch_vp_verified=True,t1_clearance_verified=True,bltouch_verified=True,thermal_verified=True,recovery_verified=True,operator_authorized=True)

def ready():
 g=BedMeshGate(release=E);assert g.begin(0);return g

def progress():
 g=ready();assert g.propose(0)=='M190 S60';g.ack('heat_done',10,temp_c=60)
 assert g.propose(39) is None;assert g.propose(40)=='G28'
 g.ack('home_done',43,all_axes_homed=True,probe_safe=True)
 assert g.propose(44)=='G29'
 for x in range(4):
  for y in range(4):g.ack('mesh_point',50+x*4+y,x=x,y=y,z_mm=0.1)
 g.ack('probe_done',67,g29_success=True)
 return g
class TestSV04(unittest.TestCase):
 def test_default_reject(self):self.assertFalse(BedMeshGate().begin(0))
 def test_no_flash(self):self.assertFalse(BedMeshGate().snapshot()['can_flash'])
 def test_bad_tool(self):self.assertFalse(BedMeshGate(release=E,active_tool=1).begin(0))
 def test_not_idle(self):self.assertFalse(BedMeshGate(release=E,idle=False).begin(0))
 def test_estop(self):self.assertFalse(BedMeshGate(release=E,emergency_stop=True).begin(0))
 def test_temp(self):
  g=ready();g.propose(0);g.ack('heat_done',20,temp_c=55);self.assertEqual(g.stage,Stage.FAILED)
 def test_stabilization(self):
  g=ready();g.propose(0);g.ack('heat_done',20,temp_c=60);self.assertIsNone(g.propose(49));self.assertEqual(g.propose(50),'G28')
 def test_homing_refusal(self):
  g=ready();g.propose(0);g.ack('heat_done',20,temp_c=60);g.propose(50);g.ack('home_done',51,all_axes_homed=False,probe_safe=True);self.assertEqual(g.stage,Stage.FAILED)
 def test_16_points(self):
  g=progress();self.assertEqual(len(g.readings),16);self.assertEqual(g.propose(70),'M420 S1')
 def test_duplicate(self):
  g=progress();g.ack('mesh_point',68,x=0,y=0,z_mm=0.1);self.assertEqual(g.stage,Stage.FAILED)
 def test_never_save_without_enable_ack(self):
  g=progress();g.propose(70);self.assertIsNone(g.propose(71));self.assertEqual(g.stage,Stage.FAILED)
 def test_save_after_enable_only(self):
  g=progress();g.propose(70);g.ack('leveling_enabled',70,enabled=True);self.assertEqual(g.propose(71),'M500');self.assertFalse(g.saved_in_eeprom)
 def test_success_with_verify(self):
  g=progress();g.propose(70);g.ack('leveling_enabled',70,enabled=True);g.propose(71);g.ack('eeprom_saved',72,m500_success=True);g.ack('mesh_verified',73,m420_v_matches=True,m503_matches=True,eeprom_save_confirmed=True);self.assertEqual(g.stage,Stage.COMPLETE)
 def test_save_failure(self):
  g=progress();g.propose(70);g.ack('leveling_enabled',70,enabled=True);g.propose(71);g.ack('eeprom_saved',72,m500_success=False);self.assertEqual(g.stage,Stage.FAILED)
 def test_no_fake_verify(self):
  g=progress();g.propose(70);g.ack('leveling_enabled',70,enabled=True);g.propose(71);g.ack('mesh_verified',72,m420_v_matches=True,m503_matches=True,eeprom_save_confirmed=True);self.assertEqual(g.stage,Stage.FAILED)
 def test_abort(self):
  g=progress();g.abort();self.assertIsNone(g.propose(70));self.assertEqual(g.stage,Stage.ABORTED)
 def test_collision(self):
  c=IdexClearance(0,250,100,300,50,50,10);self.assertTrue(c.candidate_is_safe(80,150));self.assertFalse(c.candidate_is_safe(100,130))
 def test_bounds(self):
  c=IdexClearance(0,250,100,300,50,50,10);self.assertFalse(c.candidate_is_safe(-1,200))
 def test_invalid(self):
  c=IdexClearance(0,250,100,300,50,50,10);self.assertFalse(c.candidate_is_safe(float('nan'),200))
 def test_t1_displacement_not_hardware_proof(self):self.assertFalse(BedMeshGate().release.t1_clearance_verified)
if __name__=='__main__':unittest.main()
