import importlib.util, tempfile, unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('pf60',Path(__file__).parents[1]/'tools/preflight60.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class TestSourcePreflight(unittest.TestCase):
    def test_missing_blocked(self):
        with tempfile.TemporaryDirectory() as d:
            r=m.scan(Path(d),'sovol');self.assertFalse(r['ready_for_stm32_build']);self.assertFalse(r['flash_approved'])
    def test_partial_blocked(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);(p/'platformio.ini').write_text('[env:sovol]\n')
            r=m.scan(p,'sovol');self.assertFalse(r['ready_for_stm32_build'])
    def test_complete_source_ready_only(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)
            for rel in m.REQUIRED:
                f=p/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_text('[env:sovol]\n' if rel=='platformio.ini' else '// marker')
            r=m.scan(p,'sovol');self.assertTrue(r['ready_for_stm32_build']);self.assertFalse(r['flash_approved']);self.assertIn('Marlin/Configuration.h',r['sha256'])
    def test_wrong_env_blocked(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)
            for rel in m.REQUIRED:
                f=p/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_text('[env:correct]\n' if rel=='platformio.ini' else '')
            self.assertFalse(m.scan(p,'wrong')['ready_for_stm32_build'])
    def test_env_in_comment_not_accepted(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)
            for rel in m.REQUIRED:
                f=p/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(';[env:fake]\n' if rel=='platformio.ini' else '')
            self.assertFalse(m.scan(p,'fake')['ready_for_stm32_build'])
if __name__=='__main__':unittest.main()
