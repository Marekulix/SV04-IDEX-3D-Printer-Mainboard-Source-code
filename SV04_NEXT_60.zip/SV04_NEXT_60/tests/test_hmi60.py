import importlib.util,unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('hmi60',Path(__file__).parents[1]/'tools/audit_hmi60.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class HmiAudit(unittest.TestCase):
    def test_overlap_fails(self):self.assertFalse(m.audit({'oem_vps':['0x1000'],'new_vps':['0x1000']})['offline_contract_ok'])
    def test_unverified_touch_fails(self):self.assertFalse(m.audit({'new_vps':[2],'touch_bindings':[{'name':'start','vp':2}]})['offline_contract_ok'])
    def test_unlisted_touch_fails(self):self.assertFalse(m.audit({'new_vps':[2],'touch_bindings':[{'name':'start','vp':3,'hardware_verified':True}]})['offline_contract_ok'])
    def test_verified_still_not_release(self):
        r=m.audit({'oem_vps':[1],'new_vps':[2],'touch_bindings':[{'name':'start','vp':2,'hardware_verified':True}]})
        self.assertTrue(r['offline_contract_ok']);self.assertFalse(r['display_release'])
    def test_duplicate_rejected(self):self.assertFalse(m.audit({'new_vps':[2,2]})['offline_contract_ok'])
if __name__=='__main__':unittest.main()
