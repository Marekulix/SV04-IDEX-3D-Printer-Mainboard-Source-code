import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from dwin_contract59 import VpSlot,audit_slots
class TouchContractTests(unittest.TestCase):
 def test_safe(self):self.assertTrue(audit_slots([VpSlot('one',0x1000,1),VpSlot('two',0x1002,1)])['schema_valid'])
 def test_overlap(self):self.assertFalse(audit_slots([VpSlot('one',0x1000,2),VpSlot('two',0x1002,1)])['schema_valid'])
 def test_write_rejected(self):self.assertFalse(audit_slots([VpSlot('touch',0x1000,1,'write')])['schema_valid'])
 def test_no_auto60_release(self):self.assertFalse(audit_slots([])['auto60_touch_release'])
 def test_no_binding_guess(self):self.assertFalse(audit_slots([VpSlot('diag',0x1000,1)])['binding_verified'])
 def test_invalid_width(self):self.assertFalse(audit_slots([VpSlot('diag',0x1000,0)])['schema_valid'])
 def test_invalid_address(self):self.assertFalse(audit_slots([VpSlot('diag',-1,1)])['schema_valid'])
 def test_overflow(self):self.assertFalse(audit_slots([VpSlot('diag',65535,2)])['schema_valid'])
