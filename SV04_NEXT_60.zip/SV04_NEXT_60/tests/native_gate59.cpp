#include "SV04NextSafeGate59.hpp"
#include <cassert>
int main(){
  sv04next59::Gate gate;
  assert(!gate.may_save() && !gate.may_move() && !gate.may_heat());
  for(unsigned y=0;y<4;y++)for(unsigned x=0;x<4;x++)assert(gate.mesh.add(x,y,0.1f));
  assert(gate.mesh.complete());
  assert(!gate.mesh.add(1,1,0.0f));
  assert(!gate.may_save());
  return 0;
}
