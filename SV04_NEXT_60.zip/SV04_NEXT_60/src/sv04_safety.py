"""Host-side SV04 NEXT 59, pure dry-run contract. NEVER connects to a printer.

Commands are *proposed*, NEVER transmitted. Enabling movement requires separate
OEM source, build, HMI, mechanical clearance and recovery hardware proofs.
"""
from dataclasses import dataclass, field
from enum import Enum
import math

class Stage(Enum):
    BLOCKED='blocked'; READY='ready'; HEAT='heat'; STABILIZE='stabilize'; HOME='home'
    PROBE='probe'; VALIDATE='validate'; ENABLE='enable'; SAVE='save'
    VERIFY='verify'; COMPLETE='complete'; FAILED='failed'; ABORTED='aborted'

@dataclass(frozen=True)
class ReleaseEvidence:
    oem_source_sha256: str = ''
    stm32_build_passed: bool = False
    display_hmi_matches_installed: bool = False
    touch_vp_verified: bool = False
    t1_clearance_verified: bool = False
    bltouch_verified: bool = False
    thermal_verified: bool = False
    recovery_verified: bool = False
    operator_authorized: bool = False

    def missing(self):
        keys = ('oem_source_sha256','stm32_build_passed','display_hmi_matches_installed',
                'touch_vp_verified','t1_clearance_verified','bltouch_verified',
                'thermal_verified','recovery_verified','operator_authorized')
        return [k for k in keys if not getattr(self,k)]

@dataclass
class BedMeshGate:
    """Deterministic watchdog-backed state machine, NO device I/O or flash release."""
    stage: Stage=Stage.BLOCKED
    readings: dict=field(default_factory=dict)
    emitted: list=field(default_factory=list)
    errors: list=field(default_factory=list)
    z_offset_mm: float=-1.10
    saved_in_eeprom: bool=False
    leveling_acknowledged: bool=False
    save_acknowledged: bool=False
    last_stage_s: float=0.0
    deadline_s: float=0.0
    release: ReleaseEvidence=field(default_factory=ReleaseEvidence)
    active_tool: int=0
    idle: bool=True
    printer_homed: bool=False
    bed_temp_c: float|None=None
    emergency_stop: bool=False

    # Deliberate release gate: this reference is simulation-only.
    def begin(self, now_s:float):
        self._valid_clock(now_s)
        if self.stage is not Stage.BLOCKED: raise ValueError('already_started')
        if self.release.missing():
            self.errors.append('release_evidence_missing:'+','.join(self.release.missing()))
            return False
        if not self.idle or self.active_tool!=0 or self.emergency_stop:
            self.errors.append('idle_tool_or_estop_check_failed');return False
        if not (-4.0<=self.z_offset_mm<=0.0):
            self.errors.append('z_offset_out_of_review_bounds');return False
        self.stage=Stage.READY; self.last_stage_s=now_s;return True

    def _valid_clock(self,now_s):
        if not isinstance(now_s,(int,float)) or isinstance(now_s,bool) or not math.isfinite(now_s):raise ValueError('invalid_clock')
        if now_s<self.last_stage_s:raise ValueError('clock_reversed')

    def propose(self, now_s:float):
        """Return ONLY a proposed next command; never send it."""
        self._valid_clock(now_s)
        if self.stage in (Stage.FAILED, Stage.ABORTED, Stage.COMPLETE, Stage.BLOCKED):return None
        if self.stage is Stage.STABILIZE and now_s>self.deadline_s:
            self.fail("stabilization_timeout");return None
        if self.release.missing() or self.emergency_stop or not self.idle or self.active_tool != 0:
            self.fail('unsafe_precondition');return None
        if self.stage is Stage.READY:
            self._set(Stage.HEAT,now_s,600);return 'M190 S60'
        if self.stage is Stage.STABILIZE and now_s-self.last_stage_s>=30:
            self._set(Stage.HOME,now_s,120);return 'G28'
        if self.stage is Stage.PROBE:
            # G29 after explicit completion of G28; OEM actual 4x4 config MUST be proved.
            self._set(Stage.VALIDATE,now_s,900);return 'G29'
        if self.stage is Stage.ENABLE:
            self._set(Stage.SAVE,now_s,30);return 'M420 S1'
        if self.stage is Stage.SAVE:
            if not self.leveling_acknowledged:
                self.fail("m420_not_acknowledged");return None
            if len(self.readings)!=16 or self.errors:
                self.fail('mesh_incomplete_before_m500');return None
            self._set(Stage.VERIFY,now_s,30);return 'M500'
        return None

    def ack(self, kind:str, now_s:float, **data):
        self._valid_clock(now_s)
        if self.stage in (Stage.FAILED,Stage.ABORTED,Stage.COMPLETE,Stage.BLOCKED):return
        if self.emergency_stop:
            self.abort();return
        if self.stage in (Stage.HEAT,Stage.HOME,Stage.VALIDATE,Stage.SAVE,Stage.VERIFY) and now_s>self.deadline_s:
            self.fail('timeout_'+self.stage.value);return
        if kind=='heat_done' and self.stage is Stage.HEAT:
            temp=data.get('temp_c')
            if not isinstance(temp,(int,float)) or not math.isfinite(temp) or not (59.5<=temp<=60.5):
                self.fail('temperature_outside_stability_window');return
            self.bed_temp_c=float(temp);self._set(Stage.STABILIZE,now_s,90)
        elif kind=='home_done' and self.stage is Stage.HOME:
            if data.get('all_axes_homed') is not True or data.get('probe_safe') is not True:
                self.fail('homing_not_verified');return
            self.printer_homed=True;self._set(Stage.PROBE,now_s,120)
        elif kind=='mesh_point' and self.stage is Stage.VALIDATE:
            x,y,z=data.get('x'),data.get('y'),data.get('z_mm')
            if not all(type(v) is int for v in (x,y)) or not 0<=x<4 or not 0<=y<4 or (x,y) in self.readings:
                self.fail('duplicate_or_invalid_grid_index');return
            if type(z) not in (int,float) or not math.isfinite(z) or abs(z)>2.0:
                self.fail('invalid_probe_value');return
            self.readings[(x,y)]=float(z)
        elif kind=='probe_done' and self.stage is Stage.VALIDATE:
            if data.get('g29_success') is not True or len(self.readings)!=16:
                self.fail('probe_failed_or_mesh_missing');return
            # Validate 4x4 complete, not just 16 values.
            if set(self.readings)!={(x,y) for x in range(4) for y in range(4)}:
                self.fail('mesh_index_holes');return
            self._set(Stage.ENABLE,now_s,30)
        elif kind=='leveling_enabled' and self.stage is Stage.SAVE:
            if data.get('enabled') is not True:self.fail('m420_enable_failed')
            else:self.leveling_acknowledged=True
        elif kind=='eeprom_saved' and self.stage is Stage.VERIFY:
            if data.get('m500_success') is not True:
                self.fail('m500_outcome_unknown');return
            # Saved is not verified yet: M420 V/M503 compare must be acknowledged.
            self.saved_in_eeprom=False
            self.save_acknowledged=True
        elif kind=='mesh_verified' and self.stage is Stage.VERIFY:
            if self.save_acknowledged and data.get('m420_v_matches') is True and data.get('m503_matches') is True and data.get('eeprom_save_confirmed') is True:
                self.saved_in_eeprom=True;self.stage=Stage.COMPLETE
            else:self.fail('post_save_verification_failed')
        else: self.fail('unexpected_ack_'+str(kind))

    def _set(self,stage,now_s,timeout_s):
        self.stage=stage;self.last_stage_s=now_s;self.deadline_s=now_s+timeout_s
    def fail(self,reason):
        self.errors.append(reason);self.stage=Stage.FAILED
    def abort(self):
        self.emergency_stop=True;self.stage=Stage.ABORTED
    def snapshot(self):
        return {'stage':self.stage.value,'points':len(self.readings),'errors':self.errors[:],
                'saved_in_eeprom':self.saved_in_eeprom,'can_flash':False,
                'z_offset_unchanged':self.z_offset_mm==-1.10,
                'missing_evidence':self.release.missing()}

@dataclass(frozen=True)
class IdexClearance:
    """Host geometry cross-check, NOT real-world crash proof."""
    x1_min:float; x1_max:float; x2_min:float; x2_max:float
    carriage1_width:float; carriage2_width:float; minimum_gap:float
    def candidate_is_safe(self,x1,x2):
        vals=(self.x1_min,self.x1_max,self.x2_min,self.x2_max,
              self.carriage1_width,self.carriage2_width,self.minimum_gap,x1,x2)
        if not all(type(v) in (int,float) and math.isfinite(v) for v in vals):return False
        if self.carriage1_width<=0 or self.carriage2_width<=0 or self.minimum_gap<0:return False
        if not (self.x1_min<=x1<=self.x1_max and self.x2_min<=x2<=self.x2_max):return False
        return (x2-self.carriage2_width/2)-(x1+self.carriage1_width/2)>=self.minimum_gap
