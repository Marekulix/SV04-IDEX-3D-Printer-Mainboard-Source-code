#!/usr/bin/env python3
"""SV04 NEXT 58: offline-only diagnostic safety gate. Does not talk to hardware.
Input is a MANUALLY normalized JSON export, not a claim about native G29 U Q text syntax.
"""
import argparse, json, hashlib, math, pathlib, sys

FORBIDDEN = ('flash_release','auto60_touch','hmi_verified','actuator_enabled','eeprom_write_enabled')
REQUIRED = ('firmware','stage','readonly','flash_release','auto60_touch','hmi_verified','actuator_enabled','eeprom_write_enabled','mesh')

def audit(doc):
    errors=[]; warnings=[]
    if not isinstance(doc,dict):return {'ok':False,'errors':['root_not_object'],'warnings':[]}
    for field in REQUIRED:
        if field not in doc: errors.append('missing_'+field)
    if doc.get('firmware')!='SV04NEXT_FIRMWARE':errors.append('unknown_firmware')
    if not isinstance(doc.get('stage'),int) or isinstance(doc.get('stage'),bool) or doc['stage']<52: errors.append('stage_below_diagnostic_baseline')
    if doc.get('readonly') is not True: errors.append('not_readonly')
    for field in FORBIDDEN:
        if doc.get(field) is not False:errors.append('unsafe_or_unknown_'+field)
    mesh=doc.get('mesh')
    if not isinstance(mesh,list) or len(mesh)!=16:
        errors.append('mesh_not_16'); mesh=[]
    points={}
    for index,record in enumerate(mesh):
        if not isinstance(record,dict):errors.append('bad_mesh_record_'+str(index));continue
        x,y,z=record.get('x'),record.get('y'),record.get('z_mm')
        if not all(isinstance(v,int) and not isinstance(v,bool) for v in (x,y)) or not (0<=x<4 and 0<=y<4):
            errors.append('invalid_mesh_index_'+str(index));continue
        if (x,y) in points:errors.append('duplicate_mesh_point_'+str(index))
        if not isinstance(z,(int,float)) or isinstance(z,bool) or not math.isfinite(z): errors.append('invalid_z_'+str(index));continue
        if abs(z)>2.0:warnings.append('large_z_'+str(index))
        points[x,y]=z
    if mesh and len(points)!=16:errors.append('incomplete_mesh_coordinates')
    if doc.get('source') not in ('offline_export','test_fixture'):errors.append('unverified_source')
    if doc.get('device_verified') is True:errors.append('device_verification_not_possible_offline')
    if doc.get('mesh_saved') is True:errors.append('eeprom_success_not_verifiable_offline')
    return {'ok':not errors,'errors':errors,'warnings':warnings,'point_count':len(points),'operational_release':False,'can_flash':False}

def main():
    p=argparse.ArgumentParser(description='Offline review of SV04 NEXT read-only 4x4 mesh diagnostics; NEVER flash authorization')
    p.add_argument('input',type=pathlib.Path);p.add_argument('--output',type=pathlib.Path)
    a=p.parse_args()
    raw=a.input.read_bytes()
    try: doc=json.loads(raw)
    except (ValueError, UnicodeDecodeError) as exc:
        print('invalid JSON:',exc,file=sys.stderr);return 2
    result=audit(doc);result['input_sha256']=hashlib.sha256(raw).hexdigest()
    body=json.dumps(result,indent=2,ensure_ascii=False)
    if a.output:a.output.write_text(body+'\n',encoding='utf-8')
    print(body)
    return 0 if result['ok'] else 1
if __name__=='__main__':raise SystemExit(main())
