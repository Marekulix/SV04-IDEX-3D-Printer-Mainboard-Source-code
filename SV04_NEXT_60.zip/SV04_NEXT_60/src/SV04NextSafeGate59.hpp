#pragma once
// SV04 NEXT: compile-time safety gates, C++11, independent of Marlin.
// This header does NOT replace real safety verification or OEM integration.
#if defined(SV04_NEXT_AUTO60_RELEASE) || defined(SV04_NEXT_DWIN_TOUCH_RELEASE) || defined(SV04_NEXT_T1_MOTION_RELEASE) || defined(SV04_NEXT_EEPROM_RELEASE)
  #error "SV04 NEXT 59 is diagnostic-only; release flags forbidden without hardware evidence"
#endif
namespace sv04next59 {
enum State { Blocked, Ready, Heating, Stable, Homing, Probing, Validating, Enabling, Saving, Verifying, Complete, Fault };
struct Mesh {
  bool seen[16];
  float z[16];
  unsigned count;
  Mesh():seen(),z(),count(0){}
  bool add(unsigned x,unsigned y,float value) {
    if (x >= 4 || y >= 4 || value != value || value < -2.0f || value > 2.0f) return false;
    const unsigned i=y*4+x;
    if (seen[i]) return false;
    seen[i]=true;z[i]=value;++count;return true;
  }
  bool complete() const {
    if (count != 16) return false;
    for (unsigned i=0;i<16;i++) if (!seen[i])return false;
    return true;
  }
};
struct Gate {
  State state;
  Mesh mesh;
  bool readonly;
  bool eeprom_authorized;
  Gate():state(Blocked),readonly(true),eeprom_authorized(false){}
  bool may_save() const {return false;} // unconditional until OEM + hardware release review
  bool may_move() const {return false;}
  bool may_heat() const {return false;}
};
}
