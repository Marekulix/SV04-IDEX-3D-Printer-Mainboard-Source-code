"""DWIN read-only layout validation. DOES NOT infer actual device VP addresses.
Real installed DWIN source and touch captures are required for any bindings.
"""
from dataclasses import dataclass

@dataclass(frozen=True)
class VpSlot:
    label:str
    vp:int
    words:int
    access:str='read'

def audit_slots(slots, installed_hmi_hash='', touch_evidence=False):
    errors=[];occupied={}
    for s in slots:
        if not s.label or not isinstance(s.vp,int) or isinstance(s.vp,bool) or s.vp<0 or s.vp>65535:
            errors.append('invalid_address');continue
        if type(s.words) is not int or s.words<1 or s.words>256:
            errors.append('invalid_width:'+s.label);continue
        if s.access!='read':errors.append('writes_not_authorized:'+s.label)
        for address in range(s.vp,s.vp+s.words*2,2):
            if address>65535:errors.append('vp_overflow:'+s.label);continue
            if address in occupied:errors.append(f'vp_overlap:{occupied[address]}:{s.label}:{address}')
            else:occupied[address]=s.label
    return {'schema_valid':not errors,'errors':errors,'vp_count':len(occupied),
            'binding_verified':bool(installed_hmi_hash and touch_evidence and not errors),
            'touch_release':False,'auto60_touch_release':False}
