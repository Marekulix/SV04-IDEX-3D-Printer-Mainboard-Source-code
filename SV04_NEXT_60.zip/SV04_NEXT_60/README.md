# SV04 NEXT Stand 60 – Android/GitHub Prüf- und Buildpaket

**Nicht flashen.** Dieses Paket liefert die Host-Sicherheitsprüfungen und einen strikten GitHub-Buildpfad. Es ist **kein** fertiges Marlin-/DWIN-Firmwareoverlay, weil der vollständige Stand-57-Quellstand in dieser Sitzung nicht verfügbar ist.

## Wie bisher vom Android-Tablet

1. `SV04_NEXT_60.zip` in das **Root** des bestehenden SV04-NEXT-GitHub-Repositories hochladen (nicht entpacken).
2. `60.yml` in `.github/workflows/` hochladen (Dateiname exakt `60.yml`).
3. GitHub → Actions → **60 - SV04 NEXT source audit and STM32 build - NO FLASH** → Run workflow.
4. `sv04next60-host-evidence` und `sv04next60-stm32-evidence` aus dem Workflow prüfen. Keine Binärdatei flashen.

Wenn die geprüften originalen Marlin-Dateien noch nicht im Repository unter `firmware/` liegen, wird der STM32-Job absichtlich ROT und benennt die fehlenden Voraussetzungen. Es wird niemals ein Board-Environment geraten. Die Datei `firmware/SV04_NEXT_STM32_ENV.txt` muss den exakten, **aus dem Originalprojekt bestätigten** Namen enthalten.

## Technischer Umfang

- Sicherheits- und Trockenlauf-Zustandsautomat aus Stand 59; keine reale USB-/Druckerkommunikation.
- 4×4-Validierung, 60 °C Temperaturfenster, T0/Idle-Start, M190/G28/G29/M420/M500 als **Vorschläge**, EEPROM-Schutz im Modell.
- IDEX-Abstandsprüfmodell, keine echte T1-Kollisionsfreigabe.
- Strikter DWIN-VP-Adressen-/Touch-Konfliktaudit; keine Display-Binärdatei.
- C++11-Freigabesperren, negativ getestete RELEASE-Makros.
- Dokumentierter OEM-Quellen-/PlatformIO-Check; SHA-256 des verfügbaren Quellkerns im Report.
- Vollständiger STM32 PlatformIO-Buildversuch, **nur wenn** die realen Quellen und Environment-Angaben im Repository vorliegen. Keine Firmware wird hochgeladen oder geflasht.

**Bestätigter Fortschrittskatalog: 39,50 %.** Der lokale Entwicklungsfortschritt ändert die historische Gesamtzahl nicht ohne native Build-/Hardwareabnahme.
