#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m unittest discover -s tests -v
c++ -std=c++11 -Wall -Wextra -Werror -Isrc tests/native_gate59.cpp -o /tmp/sv04next59_native_gate
/tmp/sv04next59_native_gate
for FLAG in SV04_NEXT_AUTO60_RELEASE SV04_NEXT_DWIN_TOUCH_RELEASE SV04_NEXT_T1_MOTION_RELEASE SV04_NEXT_EEPROM_RELEASE; do
  if c++ -std=c++11 -Isrc "-D${FLAG}=1" tests/native_gate59.cpp -o /tmp/sv04next59_should_not_build 2>/tmp/sv04next59_forbidden.log; then
    echo "ERROR: release gate $FLAG compiled unexpectedly" >&2; exit 1
  fi
done
echo 'SV04 NEXT 59: HOST SAFETY CHECK PASS (NOT A FLASH RELEASE)'
