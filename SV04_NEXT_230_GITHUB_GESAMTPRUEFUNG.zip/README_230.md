# SV04 NEXT 230 – GITHUB-PRUEFPAKET (NICHT INSTALLIERBAR)

Inhalt: die UNVERAENDERTEN Claude-Entwicklungsdateien 194–196 und die Anzeige-/M420-Pruefbausteine 228.
Keine Zusammenfuehrung mit dem UI-Strang 197–227, kein behaupteter Gesamtsystem-Nachweis.
Der GitHub-Workflow prueft: SHA, Claude-Hosttests, Anzeige-/M420-Hosttests, originale OEM-Hashes,
Baseline-STM32-Build und isolierten gepatchten STM32-Build mit sicherheitskritischen Claude-Flags AUS.
Keine Firmware-Binardatei wird als Artefakt hochgeladen. Kein Flash, kein EEPROM, keine Motortests.
Wenn das Projekt/Sovol-Commit die erwarteten Quell-Hashes nicht hat, muss der Build FEHLSCHLAGEN.
GITHUB: ZIP im Repository-Wurzelverzeichnis, 230.yml nach .github/workflows/; Actions 230 starten.

Die Claude-Patchdateien sind NICHT zur Installation freigegeben.
