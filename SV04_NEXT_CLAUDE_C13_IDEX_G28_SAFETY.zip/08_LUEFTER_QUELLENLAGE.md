# AP4 – Lüftersteuerung, Quellenlage
* **Ausgänge:** `FAN_PIN PB14` (Lüfter 0), `FAN1_PIN PB12` (Lüfter 1), `FAN_COUNT 2`, `FAN_INVERTING false`, `FAN_SOFT_PWM` aktiv. **Keine** Automatik: `E0…E7_AUTO_FAN_PIN −1`, `CONTROLLER_FAN_PIN −1` (keine temperaturabhängigen Lüfter in Marlin).
* **Steuerung:** `M106/M107` und direkte Display-Aufrufe → `thermalManager.set_fan_speed()`. Soft-PWM läuft in `Temperature::isr`.
* **Heizer aus ≠ Lüfter aus:** `disable_all_heaters()` und `stop()` ändern `fan_speed[]` nicht (echter `temperature.cpp`/`MarlinCore.cpp`). `set_fans_paused` wirkt nur mit `PROBING_FANS_OFF`/`ADVANCED_PAUSE_FANS_PAUSE` (hier nicht belegt).
* **Stopp (C10–C12):** `M106` EIN erlaubt (C12), `M107`, `S0` verweigert. `M999` ändert keine Lüfter.
* **kill()/M112 (neu C13):** `minkill()` ruft `cli()`; danach läuft die Soft-PWM nicht mehr, die Pins stehen im letzten Zustand. C13 setzt FAN/FAN1 nach `cli()` auf EIN.
* **Offen:** welche Last an PB14/PB12 hängt (Hotend-Kühlkörper oder Bauteil), ob ein Lüfter hart verdrahtet ist; Display-Direktzugriffe (ChatGPT).
