# SV04 NEXT – Claude C13: IDEX-/Bewegungsfreigabe, Z-Analyse, Lüfter bei kill()

Stand 14.11.2026 · FLASH_ALLOWED=NO · HARDWARE_TESTED=NO · 309/318/C9/C10/C11/C12 unverändert (C13 ist ein weiterer Overlay mit 4 Dateien)
**Stufen:** programmiert ja · host-getestet ja (47 Tests) · **STM32-gebaut: noch nicht** (erst der GitHub-Lauf mit `claude_c13_stm32_no_flash.yml`) · hardwarebestätigt: nein.

## A. Welche Softwarefunktionen wurden tatsächlich verbessert?
1. **Keine G0/G1-Bewegung mehr aus unbekannter Position** (`Configuration.h`: `NO_MOTION_BEFORE_HOMING` aktiv). Vorher (belegt im C11-Makroauszug: Makro nicht definiert): nach Kaltstart, nach `M999` (C9 setzt alles unreferenziert) und nach abgebrochenem Homing ließ `G1 X/Y/Z` Fahrten **ohne jede Softwaregrenze** zu, weil `apply_motion_limits()` Grenzen nur für referenzierte Achsen anwendet. Jetzt wird die Fahrt verweigert („Home … first“), wenn eine der Achsen im Befehl nicht referenziert ist. Reine E-Moves bleiben erlaubt. `HOME_AFTER_DEACTIVATE` bleibt bewusst aus (Stepper-Timeout 120 s würde in Heizphasen den Druck referenzlos machen).
2. **IDEX-Abstandswächter** (`motion.cpp` + neuer Header `sv04_claude_idex_guard.h`): Der aktive Schlitten darf der von Marlin **geführten Parkposition** des anderen nicht näher kommen als der Mindestabstand (Auto-Park: `x_home_pos(anderes Werkzeug)`; Full-Control: `inactive_extruder_x`). Vorher gab es nur feste Grenzen (T0 −62…302, T1 0…362), die nur gelten, wenn der andere Schlitten wirklich an seiner Referenzposition steht. Gilt auch bei `M211 S0`. Unbekannte/unplausible Parkposition ⇒ X gesperrt. In der Standard-Parkposition (T1 362, T0 −62) und bei Softwaregrenzen an ist das Ergebnis **identisch** zum OEM (Test: alle 2 300 Ziele).
3. **Lüfter bei `kill()`** (`MarlinCore.cpp`): `cli()` stoppt die Soft-PWM der Lüfter (`FAN_SOFT_PWM`), die Ausgänge blieben im Zufallszustand. Jetzt werden FAN/FAN1 nach `cli()` und nach „Heizer aus“ fest auf EIN gesetzt (Schalter `SV04_CLAUDE_KILL_FANS_ON`, 0 = alt).

## B. Welche Sicherheitslücken wurden geschlossen?
| Nr | Lücke (aus echtem Code belegt) | Schließung | Beleg |
|---|---|---|---|
| L1 | G1 ohne Referenz: keine Softwaregrenzen, beliebige X/Y/Z-Fahrt (Kaltstart, nach M999, nach Homing-Abbruch, nach Stepper-aus + Handverschieben ist damit **nicht** gelöst, siehe D) | `NO_MOTION_BEFORE_HOMING` | Test gegen die echte G0/G1-Bedingung + echtes `homing_needed_error`: 128 Zustände, Baseline zeigt die Lücke, Mutanten getötet |
| L2 | X-Grenzen unabhängig von der geführten Parkposition des anderen Schlittens | Abstandswächter in `apply_motion_limits()` | echte gepatchte Funktion, 147 456 Zustände gegen unabhängiges Modell; echter Header 8 100 Fälle |
| L3 | Lüfterausgänge nach `kill()` eingefroren | Ausgänge fest EIN | echter gepatchter `minkill`-Text, 16 Kombinationen, Reihenfolge CLI → Heizer aus → Lüfter |

## C. Welche Tests wurden wirklich ausgeführt? (Rohlogs in `04_ROHLOGS/`)
* `test_c13.py`: **47 Tests OK** (Installer 10, Wächter-Header 4, echte gepatchte Funktion 9, NO_MOTION 4, kill-Lüfter 5, 12 Pflichtfälle 12, Mutanten 3). Mutanten: Header 16/16, Hook 11/11, Gate+kill 11/11 getötet (Compilefehler zählen als getötet).
* Regression unverändert: C10 28/28, C11 23/23 + 5/5, C12 Lüfter 14/14, C12 homeaxis 14/14.
* **Testgrenze:** Funktionstexte stammen aus dem Präprozessor-Auszug (echt) bzw. dem gepatchten Quelltext, übersetzt mit einem kleinen Bedingungs-Präprozessor und den Makrowerten des echten Builds; Mitspieler (Planner, Achsenflags, `x_home_pos`-Eingaben) sind gestubbt. Nicht ausgeführt: der echte Marlin-Build mit diesen Änderungen (GitHub), Stepper, BLTouch, Endschalter.

## D. Welche Probleme sind weiterhin offen?
* **F1 – Konfigurationsbefund (Entscheidung nötig):** `HOTEND_OFFSET_X {0, 188}`. Marlin nimmt diesen Wert als Heimposition von T1 (`x_home_pos(1)` = 188, sonst 362). Bei Standard-EEPROM parkt T1 laut Buchführung bei X=188, während OEM T0 bis 302 fahren lässt. Mit C13 wird T0 dann auf 188−60 = **128 mm** begrenzt (Test `default_config_hotend_offset_188`). Ob 188 gewollt/überschrieben ist (M218 T1 X…, EEPROM), ist aus den Quellen nicht entscheidbar.
* **F2 – Mindestabstand ungemessen:** Standard 60 mm (T0) / 62 mm (T1) = Abstand der OEM-Softwaregrenzen. Das Creality-Display rechnet in beide Richtungen mit 62 (`LCD_RTS.cpp`, X-Jog). Echte Werte nur am Gerät (`-DSV04_IDEX_GAP_T0_MM=…`).
* **F3 – Display umgeht alles:** `RTS_line_to_current()` → `planner.buffer_line()` direkt; weder NO_MOTION noch Wächter wirken. Das Display führt eigene Positionsvariablen `current_position_x0_axis/x1_axis` (nur in G28 auf 362/−62 gesetzt) und prüft nicht auf referenziert. (ChatGPT, siehe 05_INTEGRATION.)
* **F4 – Handverschieben nach Stepper-aus:** Ohne `HOME_AFTER_DEACTIVATE` bleibt „referenziert“ erhalten, auch wenn Schlitten bei abgeschalteten Motoren bewegt wurden. Vorschlag D6.
* **F5 – Z/410 mm:** siehe `07_Z_ACHSE_410MM_ANALYSE.md` (keine neue Z-Grenze erfunden).
* **F6 – Lüfterlast:** was an PB14/PB12 hängt, ist ungeklärt; `M107`/`S0` im Stopp bleiben gesperrt.
* Weiter: reale T0/T1-Kollisionsabstände, BLTouch/Endschalter/`kill()` am Gerät, Power-Loss-Resume bei aktivem NO_MOTION (nicht geprüft: `recovery.cpp` liegt nicht vor; Export im C13-Lauf nachholbar).

## Entscheidungen für Marek
* **D5:** T1-Heimposition 188 (Konfig) oder 362? Was liefert `M503` (Zeile `M218 T1 X…`) auf dem Drucker? Davon hängt der T0-Bereich ab.
* **D6:** `HOME_AFTER_DEACTIVATE` (neu referenzieren nach Stepper-aus) gewünscht? Preis: Stepper-Timeout während Heizphasen würde den Druck stoppen, falls nicht gleichzeitig der Timeout/ M84-Verhalten angepasst wird.
* **D7:** Mindestabstand T0: 60 (OEM-Config) oder 62 (Display-Regel)?
* D1–D4 aus C11/C12 gelten weiter.

## E. Fortschrittswerte (Vorschlag, erst nach grünem GitHub-Build wirksam)
| Nr | Funktion | bisher | Vorschlag | Begründung |
|---|---|---:|---:|---|
| 1 | IDEX + BLTouch | 88 % | **90 %** | neuer, getesteter Abstandswächter + Bewegungsfreigabe (L1, L2); Abnahme am Gerät fehlt |
| 2 | G28 Homing | 84 % | 84 % | keine neue Homing-Logik |
| 3–6 | G29 / M420 / M500 / EEPROM | 75 / 97 / 70 / 60 % | unverändert | nicht Gegenstand |
| | **Gesamt** | 79,0 % | **79,3 %** | (90+84+75+97+70+60)/6 |
Dokumentation, ZIPs und Pins zählen nicht; der Zuwachs hängt an L1/L2.

## F. Was benötigt ChatGPT für die Integration?
Siehe `05_INTEGRATION_CHATGPT_C13.md`. Kurz: Reihenfolge 318 → C9 → C10 → C11 → C12 → C13; C13 berührt `LCD_RTS.cpp` nicht (319 ist unabhängig). Offen auf Display-Seite: Referenz-/Wächterprüfung im X/Y/Z-Jog, eigene x0/x1-Variablen, `set_fan_speed`/Heizer-Bypass.

FLASH_ALLOWED=NO · HARDWARE_TESTED=NO
