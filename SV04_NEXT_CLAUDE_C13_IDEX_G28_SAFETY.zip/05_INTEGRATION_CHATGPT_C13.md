# Übergabe C13 an ChatGPT (DWIN 319)
1. **Reihenfolge:** 318 → C9 → C10 → C11 → C12 → **C13** (`apply_c13.py <baum>`, fail-closed, Exit 3 bei fremdem/gemischtem/verändertem Stand). 319 ändert nur `LCD_RTS.cpp` (Pin 318: `0d8ef04d…`); C13 ändert `Configuration.h`, `motion.cpp`, `MarlinCore.cpp` und legt `module/sv04_claude_idex_guard.h` an. Keine Dateiüberschneidung.
2. **Neue Schnittstelle für das Display (nicht von mir angewendet):** `#include "../../../module/sv04_claude_idex_guard.h"` (Pfad je nach Datei) und im X-Jog vor `RTS_line_to_current(X_AXIS)`:
   `current_position.x = sv04c13_idex_x(current_position.x, <alte X-Position>, active_extruder != 0, sv04c13_idex_parked_x(dual_x_carriage_mode == DXC_FULL_CONTROL_MODE, inactive_extruder_x, x_home_pos(active_extruder ? 0 : 1)), 60.0f, 62.0f, -62.0f, 362.0f);`
   Und vorher `if (!axis_was_homed(X_AXIS) || !axis_is_trusted(X_AXIS)) return;` – das Display prüft heute nirgends auf „referenziert“.
3. **Befunde im Display (LCD_RTS.cpp, 319):** X-Jog nutzt eigene Variablen `current_position_x0_axis/x1_axis` (nur in `home_z_safely()` auf 362/−62 gesetzt) mit festem Abstand 62; Y/Z-Jog ohne Referenzprüfung; alle gehen über `planner.buffer_line` am G-Code-Pfad vorbei, also auch an `NO_MOTION_BEFORE_HOMING` und am Wächter.
4. **Zusammenspiel mit 319:** `IsStopped()`-Sperre in `RTS_line_to_current` bleibt richtig und ergänzt C13.
5. **Nicht ändern:** `Configuration.h` (C13 setzt nur `NO_MOTION_BEFORE_HOMING`).
