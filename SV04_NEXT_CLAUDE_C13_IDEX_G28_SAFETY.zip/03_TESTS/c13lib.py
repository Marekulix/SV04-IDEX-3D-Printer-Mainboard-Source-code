#!/usr/bin/env python3
"""Gemeinsame Hilfen der C13-Tests: Quellen laden, Funktionen aus dem PATCHEN Quelltext ziehen, Harnesse bauen, Modelle."""
import os, re, subprocess, sys, tempfile, shutil, hashlib, pathlib, itertools, math
HERE = pathlib.Path(__file__).resolve().parent
PKG = HERE.parent
GEA = PKG / '01_QUELLEN' / 'geaendert' / 'Marlin'
EIN = HERE / 'eingang'
sys.path.insert(0, str(HERE))
from mini_pp import pp
def read(p): return pathlib.Path(p).read_text()
def macros():
    V = {}
    for l in read(EIN / 'real_macros_c13.txt').split('\n'):
        m = re.match(r'#define (\w+)(?:\s+(.*))?$', l)
        if m:
            v = (m.group(2) or '').strip()
            V[m.group(1)] = int(v) if re.fullmatch(r'-?\d+', v) else 1
    V['HAS_Y_AXIS'] = 1; V['HAS_Z_AXIS'] = 1; V['LINEAR_AXES'] = 3; V['IS_KINEMATIC'] = 0
    return V
def func_text(src, header_re):
    L = src.split('\n')
    i = next(k for k, l in enumerate(L) if re.search(header_re, l))
    depth, seen, out = 0, False, []
    for j in range(i, len(L)):
        out.append(L[j])
        c = re.sub(r'//.*', '', L[j])
        if not c.strip().startswith('#'):
            for ch in c:
                if ch == '{': depth += 1; seen = True
                elif ch == '}': depth -= 1
        if seen and depth == 0: return '\n'.join(out)
    raise RuntimeError('Klammern')
def gxx(srcfile, exe, inc=(), defs=()):
    cmd = ['g++', '-std=gnu++11', '-O1', '-w', '-o', str(exe), str(srcfile)] + ['-I' + str(i) for i in inc] + ['-D' + d for d in defs]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode: raise RuntimeError('Compile fehlgeschlagen:\n' + r.stderr[-3000:])
def run_exe(exe, lines):
    r = subprocess.run([str(exe)], input='\n'.join(lines) + '\n', capture_output=True, text=True, timeout=300)
    if r.returncode: raise RuntimeError('Lauf fehlgeschlagen rc=%d: %s' % (r.returncode, r.stderr[-500:]))
    return r.stdout.split('\n')[:-1]
def nanf(s):
    return float('nan') if s == 'nan' else float(s)
def fmt(x):
    if x != x: return 'nan'
    if x == float('inf'): return 'inf'
    if x == float('-inf'): return '-inf'
    return repr(float(x))
# ---------------- Modelle (unabhaengig von der C++-Implementierung) ----------------
def model_guard(target, cur, t1, park, g0, g1, lo, hi):
    if target != target: return cur
    if park != park or park < lo or park > hi: return cur
    if not t1:
        lim = park - g0
        return min(target, lim)
    lim = park + g1
    return max(target, lim)
def model_limits(p, guard=True):
    """p: dict xh yh zh xt act mode inact hoff soft smin smax tx ty tz cx -> (x,y,z). Reihenfolge wie im Patch: erst Waechter, dann Softwaregrenzen."""
    x, y, z = p['tx'], p['ty'], p['tz']
    if guard and p['xh'] and p['xt'] and p['mode'] < 2:      # DXC-Modus 0/1 (nicht Duplikation/Spiegel)
        home1 = p['hoff'] if p['hoff'] > 0 else 362.0
        park = p['inact'] if p['mode'] == 0 else (home1 if p['act'] == 0 else -62.0)
        x = model_guard(x, p['cx'], p['act'] != 0, park, 60.0, 62.0, -62.0, 362.0)
    if p['soft']:
        if p['xh']: x = min(max(x, p['smin']), p['smax'])
        if p['yh']: y = min(max(y, 0.0), 302.0)
        if p['zh']: z = min(max(z, 0.0), 400.0)
    return (x, y, z)
