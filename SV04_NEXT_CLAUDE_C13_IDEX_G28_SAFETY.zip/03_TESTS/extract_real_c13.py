#!/usr/bin/env python3
"""Zieht die ECHTEN, praeprozessierten Funktionen x_home_pos, axes_should_home, homing_needed_error und (OEM, unveraendert) apply_motion_limits
aus module_motion.cpp.i (GitHub-Lauf C11, SV04_C11_PRAEPROZESSOR) nach eingang/real_c13.inc. Nutzung: extract_real_c13.py <module_motion.cpp.i> <ausgabe.inc>"""
import re, sys, hashlib
def body(lines, start):
    depth, out, seen = 0, [], False
    for i in range(start, len(lines)):
        l = lines[i]
        if l.startswith('# '): continue
        out.append(l)
        for ch in l:
            if ch == '{': depth += 1; seen = True
            elif ch == '}': depth -= 1
        if seen and depth == 0: return '\n'.join(out)
    raise SystemExit('Klammern nicht geschlossen')
def find(lines, pat):
    hits = [i for i, l in enumerate(lines) if re.search(pat, l)]
    if not hits: raise SystemExit('nicht gefunden: ' + pat)
    return hits[-1]
L = open(sys.argv[1], errors='replace').read().split('\n')
parts = [body(L, find(L, r'^\s*float x_home_pos\(const uint8_t extruder\) \{')),
         body(L, find(L, r'^\s*linear_axis_bits_t axes_should_home\(linear_axis_bits_t axis_bits ?\) \{')),
         body(L, find(L, r'^\s*bool homing_needed_error\(linear_axis_bits_t axis_bits ?\) \{')),
         body(L, find(L, r'^\s*void apply_motion_limits\(xyz_pos_t &target\) \{'))]
txt = '// Automatisch extrahiert aus dem Praeprozessor-Auszug des GitHub-Laufs C11. NICHT von Hand aendern.\n' + '\n'.join(parts) + '\n'
open(sys.argv[2], 'w').write(txt); print('geschrieben', sys.argv[2], len(txt), 'Bytes, sha256', hashlib.sha256(txt.encode()).hexdigest())
