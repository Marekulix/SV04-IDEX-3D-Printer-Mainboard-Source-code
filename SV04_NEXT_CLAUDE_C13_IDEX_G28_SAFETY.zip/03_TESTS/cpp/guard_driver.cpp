// Treiber fuer den ECHTEN Header sv04_claude_idex_guard.h. Eingabe je Zeile: target current t1 inactive gap0 gap1 lo hi ; Ausgabe: Ergebnis
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include "sv04_claude_idex_guard.h"
int main() {
  char a[64], b[64], d[64], e[64], f[64], g[64], h[64]; int t1;
  while (scanf("%63s %63s %d %63s %63s %63s %63s %63s", a, b, &t1, d, e, f, g, h) == 8) {
    float r = sv04c13_idex_x(strtof(a, 0), strtof(b, 0), t1 != 0, strtof(d, 0), strtof(e, 0), strtof(f, 0), strtof(g, 0), strtof(h, 0));
    if (r != r) printf("nan\n"); else printf("%.4f\n", r);
  }
  return 0;
}
