#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <cstring>
#include <cmath>
typedef uint16_t linear_axis_bits_t;
enum AxisEnum { X_AXIS, Y_AXIS, Z_AXIS };
enum DualXMode { DXC_FULL_CONTROL_MODE, DXC_AUTO_PARK_MODE, DXC_DUPLICATION_MODE, DXC_MIRRORED_MODE };
struct xyz_pos_t { float x, y, z; };
struct { bool _enabled; xyz_pos_t min, max; } soft_endstop;
struct { float x; } hotend_offset[2];
xyz_pos_t current_position; uint8_t active_extruder; DualXMode dual_x_carriage_mode; float inactive_extruder_x;
linear_axis_bits_t axis_homed, axis_trusted;
inline bool axis_was_homed(const AxisEnum a) { return (axis_homed >> a) & 1; }
inline bool axis_is_trusted(const AxisEnum a) { return (axis_trusted >> a) & 1; }
inline bool idex_is_duplicating() { return dual_x_carriage_mode >= DXC_DUPLICATION_MODE; }   // wie motion.h (echter Auszug, Zeile 71636)
template<class V, class N> static inline void NOLESS(V& v, const N n) { if (v < n) v = n; }
template<class V, class N> static inline void NOMORE(V& v, const N n) { if (v > n) v = n; }
#define X2_MAX_POS 362
#define X_MAX_POS 302
#define X2_MIN_POS 0
#define X_MIN_POS (-62)
#define X1_MIN_POS X_MIN_POS
