#!/usr/bin/env python3
"""SV04 NEXT C13 - Host-Tests: Installer, IDEX-Abstandswaechter (echter Header + echte gepatchte Funktion), NO_MOTION_BEFORE_HOMING
(echte G0/G1-Bedingung + echtes homing_needed_error), Luefter bei kill() (echter gepatchter minkill-Text), 12 Pflichtfaelle AP1, Mutanten."""
import unittest, tempfile, shutil, subprocess, sys, os, re, pathlib, itertools, math, hashlib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from c13lib import *
FILES = {'Marlin/Configuration.h': 'Configuration.h', 'Marlin/src/module/motion.cpp': 'motion.cpp', 'Marlin/src/MarlinCore.cpp': 'MarlinCore.cpp'}
HDR_REL = 'Marlin/src/module/sv04_claude_idex_guard.h'
TMP = pathlib.Path(tempfile.mkdtemp(prefix='c13t_'))
def sha(b): return hashlib.sha256(b).hexdigest()
def fresh_tree(name):
    t = TMP / name
    for rel, src in FILES.items():
        d = t / rel; d.parent.mkdir(parents=True, exist_ok=True); shutil.copy(EIN / src, d)
    return t
def apply(tree):
    r = subprocess.run([sys.executable, str(PKG / '02_PATCHES' / 'apply_c13.py'), str(tree)], capture_output=True, text=True); return r.returncode, r.stdout + r.stderr
def tree_hashes(t): return {str(p.relative_to(t)): sha(p.read_bytes()) for p in sorted(t.rglob('*')) if p.is_file()}
NAN, INF = float('nan'), float('inf')

# ---------- gemeinsame Pruefroutinen (werden auch fuer Mutanten benutzt) ----------
def guard_corpus():
    tg = [-200.0, -62.0, -61.75, 0.0, 61.75, 62.0, 100.0, 127.75, 128.0, 301.75, 302.0, 302.25, 361.75, 362.0, 400.0, NAN, INF, -INF]
    cur = [-62.0, 0.0, 150.0, 302.0, 362.0]
    park = [-62.5, -62.0, -61.75, 0.0, 128.0, 188.0, 300.0, 301.75, 302.0, 361.75, 362.0, 362.25, NAN, INF, -INF]
    gaps = [(60.0, 62.0), (0.0, 0.0), (10.0, 15.0)]
    return [(t, c, a, p, g0, g1) for t in tg for c in cur for a in (0, 1) for p in park for (g0, g1) in gaps]
def check_guard(inc_dir, exe_dir):
    src = HERE / 'cpp' / 'guard_driver.cpp'; exe = exe_dir / 'guard_exe'
    gxx(src, exe, inc=[inc_dir]); C = guard_corpus()
    lines = ['%s %s %d %s %s %s %s %s' % (fmt(t), fmt(c), a, fmt(p), fmt(g0), fmt(g1), '-62', '362') for (t, c, a, p, g0, g1) in C]
    out = run_exe(exe, lines); bad = []
    for (t, c, a, p, g0, g1), o in zip(C, out):
        m = model_guard(t, c, a, p, g0, g1, -62.0, 362.0); r = nanf(o)
        if not ((r != r and m != m) or r == m): bad.append(((t, c, a, p, g0, g1), r, m))
    return bad, len(C)
def limits_source(motion_cpp_text, guard_on=True):
    V = macros(); V['SV04_CLAUDE_IDEX_GAP_GUARD'] = 1 if guard_on else 0
    fn = pp(func_text(motion_cpp_text, r'^\s*void apply_motion_limits\(xyz_pos_t &target\)'), V)
    blk = motion_cpp_text[motion_cpp_text.index('#include "sv04_claude_idex_guard.h"'):]
    blk = blk[:blk.index('\n#endif\n', blk.index('SV04_IDEX_GAP_T1_MM')) + 8]
    blk = pp(blk, V)
    return blk, fn
def build_limits(motion_cpp_text, exe_dir, name, guard_on=True, header_dir=None, oem=False):
    prelude = read(HERE / 'cpp' / 'limits_prelude.h')
    if oem:
        real = read(EIN / 'real_c13.inc'); fn = func_text(real, r'^\s*void apply_motion_limits\(xyz_pos_t &target\)'); xh = func_text(real, r'^\s*float x_home_pos\(')
        body = prelude + '\n' + fn + '\n' + read(HERE / 'cpp' / 'limits_main.inc')
        inc = []
    else:
        blk, fn = limits_source(motion_cpp_text, guard_on)
        real = read(EIN / 'real_c13.inc'); xh = func_text(real, r'^\s*float x_home_pos\(')
        body = prelude + '\n' + blk + '\n' + xh + '\n' + fn + '\n' + read(HERE / 'cpp' / 'limits_main.inc')
        inc = [header_dir or (GEA / 'src' / 'module')]
    src = exe_dir / (name + '.cpp'); src.write_text(body); exe = exe_dir / name; gxx(src, exe, inc=inc); return exe
def limits_grid():
    G = []
    xs = [-100.0, -62.0, -0.25, 0.0, 61.75, 127.75, 128.0, 128.25, 188.0, 250.0, 301.75, 302.0, 302.25, 361.75, 362.0, 400.0]
    for xh, xt in ((0, 0), (1, 0), (0, 1), (1, 1)):
      for yh in (0, 1):
        for zh in (0, 1):
          for act, mode in ((0, 1), (1, 1), (0, 0), (1, 0), (0, 2), (1, 3)):
            for inact in (362.0, 188.0, -62.0, 100.0):
              for hoff in (188.0, 0.0, 362.0, 400.0):
                for soft in (1, 0):
                  smin, smax = (-62.0, 302.0) if act == 0 else (0.0, 362.0)
                  for tx in xs:
                    for cx in (-62.0, 150.0, 362.0):
                      G.append(dict(xh=xh, yh=yh, zh=zh, xt=xt, act=act, mode=mode, inact=inact, hoff=hoff, soft=soft, smin=smin, smax=smax, tx=tx, ty=-5.0 if (tx < 100) else 400.0, tz=500.0 if tx > 300 else -3.0, cx=cx))
    return G
def limits_lines(G):
    return ['%d %d %d %d %d %d %s %s %d %s %s %s %s %s %s' % (p['xh'], p['yh'], p['zh'], p['xt'], p['act'], p['mode'], fmt(p['inact']), fmt(p['hoff']), p['soft'], fmt(p['smin']), fmt(p['smax']), fmt(p['tx']), fmt(p['ty']), fmt(p['tz']), fmt(p['cx'])) for p in G]
def parse3(s): return tuple(nanf(x) for x in s.split())
def check_limits(exe, G=None, guard=True):
    G = G or limits_grid(); out = run_exe(exe, limits_lines(G)); bad = []
    for p, o in zip(G, out):
        m = model_limits(p, guard); r = parse3(o)
        if not all((a == b) or (a != a and b != b) for a, b in zip(r, m)): bad.append((p, r, m))
    return bad, len(G)
def gate_source(cfg_no_motion):
    V = macros(); V['NO_MOTION_BEFORE_HOMING'] = 1 if cfg_no_motion else 0
    g = read(EIN / 'G0_G1.cpp').split('\n')
    i0 = next(k for k, l in enumerate(g) if 'GcodeSuite::G0_G1' in l); i = next(k for k in range(i0, len(g)) if g[k].startswith('  if ('))
    j = next(k for k in range(i, len(g)) if g[k].strip() == ') {')
    cond = '\n'.join(g[i:j]); cond = cond.replace('  if (', '  return (', 1)
    cond = pp(cond, V) + '\n  );'
    real = read(EIN / 'real_c13.inc')
    prog = read(HERE / 'cpp' / 'gate_g0g1.inc') + '\n' + func_text(real, r'^\s*linear_axis_bits_t axes_should_home\(') + '\n' + func_text(real, r'^\s*bool homing_needed_error\(') + \
        '\nstatic bool g0g1_runs() {\n' + cond + '\n}\nint main() { int h, s, r; while (scanf("%d %d %d", &h, &s, &r) == 3) { axis_homed = h; for (int i = 0; i < 3; i++) g_seen[i] = (s >> i) & 1; g_running = r; printf("%d\\n", g0g1_runs() ? 1 : 0); } return 0; }\n'
    return prog
_GC = {}
def gate_exe(no_motion):
    if no_motion not in _GC:
        d = TMP / ('gate_%d' % no_motion); d.mkdir(); (d / 'g.cpp').write_text(gate_source(no_motion)); gxx(d / 'g.cpp', d / 'g'); _GC[no_motion] = d / 'g'
    return _GC[no_motion]
def check_gate(exe, no_motion):
    L = ['%d %d %d' % (h, s, r) for h in range(8) for s in range(8) for r in (0, 1)]; out = run_exe(exe, L); bad = []
    for l, o in zip(L, out):
        h, s, r = map(int, l.split())
        exp = (r == 1) and ((s & ~h) == 0 if no_motion else True)
        if int(o) != int(exp): bad.append((l, o, exp))
    return bad, len(L)
def kill_snippet(core_text, V):
    i = core_text.index('// SV04 NEXT C13 (kill fans on): 0 = altes Verhalten')
    k = core_text.index('void minkill(const bool steppers_off/*=false*/) {', i)
    pre = core_text[i:k]; fn = core_text[k:]
    # nur bis zum Ende des Luefter-Blocks (danach folgen Endlosschleife/Reboot, nicht host-testbar)
    cut = fn.index('  TERN_(HAS_CUTTER, cutter.kill());')
    return pp(pre, V) + '\n' + pp(fn[:cut], V) + '\n}\n'
_KC = 0
def run_kill(core_text, sw, f0, f1, inv):
    V = {'SV04_CLAUDE_KILL_FANS_ON': sw, 'HAS_FAN': 1 if (f0 or f1) else 0, 'HAS_FAN0': f0, 'HAS_FAN1': f1}
    code = kill_snippet(core_text, V)
    inv_s = 'true' if inv else 'false'
    prog = '#include <cstdio>\n#include <vector>\n#include <string>\n#define LOW 0\n#define HIGH 1\n#define FAN_PIN 14\n#define FAN1_PIN 12\n#define FAN_INVERTING ' + inv_s + '\n' \
        'std::vector<std::string> ev;\nstatic void DELAY_US(int) {}\n#define DELAY_US(x) do{}while(0)\nstatic void cli() { ev.push_back("CLI"); }\n' \
        'struct TM { void disable_all_heaters() { ev.push_back("HEATERS_OFF"); } } thermalManager;\n' \
        'static void WRITE(int pin, int v) { char b[32]; sprintf(b, "WRITE%d=%d", pin, v); ev.push_back(b); }\n' \
        + code + 'int main() { minkill(false); for (auto &e : ev) printf("%s\\n", e.c_str()); return 0; }\n'
    global _KC; _KC += 1; d = TMP / ('kill_%d' % _KC); d.mkdir(); (d / 'k.cpp').write_text(prog); gxx(d / 'k.cpp', d / 'k')
    return subprocess.run([str(d / 'k')], capture_output=True, text=True).stdout.split('\n')[:-1]
def check_kill(core_text):
    bad = []
    for sw, f0, f1, inv in itertools.product((1, 0), (1, 0), (1, 0), (0, 1)):
        ev = run_kill(core_text, sw, f0, f1, inv); on = 0 if inv else 1
        exp = ['CLI', 'HEATERS_OFF']
        if sw and (f0 or f1):
            if f0: exp.append('WRITE14=%d' % on)
            if f1: exp.append('WRITE12=%d' % on)
        if ev != exp: bad.append(((sw, f0, f1, inv), ev, exp))
    return bad, 16
patched = {k: read(GEA / k) for k in ('src/module/motion.cpp', 'src/MarlinCore.cpp', 'Configuration.h')}
HEADER = read(GEA / 'src/module/sv04_claude_idex_guard.h')

class T01_Installer(unittest.TestCase):
    def test_apply_exact_final_hashes(self):
        t = fresh_tree('a'); rc, out = apply(t); self.assertEqual(rc, 0, out)
        for rel in FILES: self.assertEqual(read(t / rel), read(GEA / rel.replace('Marlin/', '', 1)), rel)
        self.assertEqual(read(t / HDR_REL), HEADER)
        self.assertEqual(out.count('PATCHED'), 3); self.assertIn('CREATED', out)
    def test_idempotent(self):
        t = fresh_tree('b'); apply(t); h = tree_hashes(t); rc, out = apply(t); self.assertEqual(rc, 0); self.assertEqual(out.count('ALREADY'), 4); self.assertEqual(tree_hashes(t), h)
    def test_foreign_hash_exit3_nothing_written(self):
        for rel in FILES:
            t = fresh_tree('c_' + rel.replace('/', '_')); p = t / rel; p.write_bytes(p.read_bytes() + b'\n// fremd\n'); h = tree_hashes(t)
            rc, out = apply(t); self.assertEqual(rc, 3, rel + out); self.assertEqual(tree_hashes(t), h, 'es darf nichts geschrieben werden: ' + rel)
    def test_mixed_state_refused(self):
        t = fresh_tree('d'); apply(t); shutil.copy(EIN / 'Configuration.h', t / 'Marlin/Configuration.h'); h = tree_hashes(t)
        rc, out = apply(t); self.assertEqual(rc, 3, out); self.assertEqual(tree_hashes(t), h)
    def test_patched_but_modified_refused(self):
        t = fresh_tree('e'); apply(t); p = t / 'Marlin/src/module/motion.cpp'; p.write_text(p.read_text() + '\n// x\n'); h = tree_hashes(t)
        rc, out = apply(t); self.assertEqual(rc, 3, out); self.assertEqual(tree_hashes(t), h)
    def test_foreign_header_refused(self):
        t = fresh_tree('f'); (t / HDR_REL).write_text('// fremd\n'); h = tree_hashes(t); rc, out = apply(t); self.assertEqual(rc, 3, out); self.assertEqual(tree_hashes(t), h)
    def test_missing_file_refused(self):
        t = fresh_tree('g'); (t / 'Marlin/src/MarlinCore.cpp').unlink(); rc, out = apply(t); self.assertEqual(rc, 3)
    def test_diff_scope(self):
        import difflib
        for rel, src in FILES.items():
            a = read(EIN / src).split('\n'); b = read(GEA / rel.replace('Marlin/', '', 1)).split('\n')
            sm = difflib.SequenceMatcher(None, a, b, autojunk=False); rem = sum(i2 - i1 for tag, i1, i2, j1, j2 in sm.get_opcodes() if tag in ('replace', 'delete')); add = sum(j2 - j1 for tag, i1, i2, j1, j2 in sm.get_opcodes() if tag in ('replace', 'insert'))
            lim = {'Marlin/Configuration.h': (1, 1), 'Marlin/src/module/motion.cpp': (0, 20), 'Marlin/src/MarlinCore.cpp': (0, 20)}[rel]
            self.assertLessEqual(rem, lim[0], rel); self.assertLessEqual(add, lim[1], rel); self.assertGreater(add, 0)
    def test_config_only_no_motion_enabled(self):
        c = patched['Configuration.h']; self.assertRegex(c, r'(?m)^#define NO_MOTION_BEFORE_HOMING ')
        self.assertRegex(c, r'(?m)^//#define HOME_AFTER_DEACTIVATE ')           # bleibt AUS (Stepper-Timeout in Heizphasen)
        self.assertEqual(len(re.findall(r'(?m)^#define NO_MOTION_BEFORE_HOMING', c)), 1)
    def test_real_baseline_has_no_no_motion(self):
        self.assertNotIn('NO_MOTION', read(EIN / 'real_macros_c13.txt'))
        self.assertRegex(read(EIN / 'Configuration.h'), r'(?m)^//#define NO_MOTION_BEFORE_HOMING ')

class T02_Guard(unittest.TestCase):
    def test_guard_real_header_vs_model(self):
        bad, n = check_guard(GEA / 'src/module', TMP); self.assertEqual(bad, [], bad[:3]); self.assertGreater(n, 8000)
    def test_nominal_equals_oem_clamp(self):
        # Standard-Parkposition (T1 362 / T0 -62) und Standardabstaende: Waechter == OEM-Softwaregrenzen (T0 <=302, T1 >=0) fuer jedes Ziel
        exe = TMP / 'guard_exe'; gxx(HERE / 'cpp' / 'guard_driver.cpp', exe, inc=[GEA / 'src/module'])
        tg = [x * 0.25 for x in range(-600, 1700)]; L = []; E = []
        for t in tg:
            L.append('%s 0 0 362 60 62 -62 362' % fmt(t)); E.append(min(t, 302.0))
            L.append('%s 0 1 -62 60 62 -62 362' % fmt(t)); E.append(max(t, 0.0))
        out = run_exe(exe, L); self.assertEqual([nanf(o) for o in out], E)
    def test_properties(self):
        exe = TMP / 'guard_exe'; gxx(HERE / 'cpp' / 'guard_driver.cpp', exe, inc=[GEA / 'src/module'])
        for park in (100.0, 188.0, 300.0, 362.0):
            L = ['%s 150 0 %s 60 62 -62 362' % (fmt(t), fmt(park)) for t in range(-100, 500, 5)]; out = [nanf(o) for o in run_exe(exe, L)]
            self.assertTrue(all(o <= park - 60.0 for o in out), park)            # T0 niemals naeher als Mindestabstand
            self.assertTrue(all(o == min(float(t), park - 60.0) for t, o in zip(range(-100, 500, 5), out)))
        for park in (-62.0, -10.0, 100.0):
            L = ['%s 150 1 %s 60 62 -62 362' % (fmt(t), fmt(park)) for t in range(-100, 500, 5)]; out = [nanf(o) for o in run_exe(exe, L)]
            self.assertTrue(all(o >= park + 62.0 for o in out), park)
    def test_unknown_park_locks_x(self):
        exe = TMP / 'guard_exe'; gxx(HERE / 'cpp' / 'guard_driver.cpp', exe, inc=[GEA / 'src/module'])
        for park in ('nan', 'inf', '-inf', '-62.25', '362.25', '1000', '-1000'):
            for a in (0, 1):
                self.assertEqual(nanf(run_exe(exe, ['200 123.5 %d %s 60 62 -62 362' % (a, park)])[0]), 123.5, park)
        self.assertEqual(nanf(run_exe(exe, ['nan 123.5 0 362 60 62 -62 362'])[0]), 123.5)

class T03_LimitsReal(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.G = limits_grid()
        cls.exe_on = build_limits(patched['src/module/motion.cpp'], TMP, 'lim_on', True)
        cls.exe_off = build_limits(patched['src/module/motion.cpp'], TMP, 'lim_off', False)
        cls.exe_oem = build_limits(None, TMP, 'lim_oem', oem=True)
    def test_patched_function_vs_model(self):
        bad, n = check_limits(self.exe_on, self.G, True); self.assertEqual(bad, [], bad[:2]); self.assertGreater(n, 50000)
    def test_guard_off_identical_to_real_oem_function(self):
        a = run_exe(self.exe_off, limits_lines(self.G)); b = run_exe(self.exe_oem, limits_lines(self.G)); self.assertEqual(a, b)
        bad, _ = check_limits(self.exe_oem, self.G, False); self.assertEqual(bad, [], bad[:2])      # Modell ohne Waechter == echtes OEM
    def test_nominal_state_identical_to_oem(self):
        # Standard-Parkposition: T1 home 362 (hoff<=0 -> 362), T0 home -62 => Waechter hat NIE Wirkung. Test auf allen Zielen.
        G = [dict(p) for p in self.G if p['hoff'] in (0.0, 362.0) and p['mode'] == 1 and p['soft'] == 1]   # bei M211 S0 wirkt der Waechter bewusst weiter
        a = run_exe(self.exe_on, limits_lines(G)); b = run_exe(self.exe_oem, limits_lines(G)); self.assertEqual(a, b); self.assertGreater(len(G), 5000)
    def test_default_config_hotend_offset_188_limits_t0(self):
        # BEFUND F1: HOTEND_OFFSET_X T1=188 (Standardwert dieses Builds) => x_home_pos(1)=188 => T0 wird auf 188-60=128 begrenzt (OEM liess 302 zu)
        p = dict(xh=1, yh=1, zh=1, xt=1, act=0, mode=1, inact=362.0, hoff=188.0, soft=1, smin=-62.0, smax=302.0, tx=300.0, ty=10.0, tz=10.0, cx=100.0)
        on = parse3(run_exe(self.exe_on, limits_lines([p]))[0]); oem = parse3(run_exe(self.exe_oem, limits_lines([p]))[0])
        self.assertEqual(on[0], 128.0); self.assertEqual(oem[0], 300.0)
    def test_auto_park_ignores_stale_inactive_extruder_x(self):
        # Entwurfsfehler-Kontrolle: im Auto-Park-Modus bleibt inactive_extruder_x auf dem G28-Wert (T1 home); T1 aktiv darf trotzdem bis x=0
        p = dict(xh=1, yh=1, zh=1, xt=1, act=1, mode=1, inact=362.0, hoff=0.0, soft=1, smin=0.0, smax=362.0, tx=10.0, ty=10.0, tz=10.0, cx=200.0)
        self.assertEqual(parse3(run_exe(self.exe_on, limits_lines([p]))[0])[0], 10.0)
        p['tx'] = -20.0; self.assertEqual(parse3(run_exe(self.exe_on, limits_lines([p]))[0])[0], 0.0)
    def test_full_control_uses_tracked_position(self):
        p = dict(xh=1, yh=1, zh=1, xt=1, act=1, mode=0, inact=100.0, hoff=0.0, soft=1, smin=0.0, smax=362.0, tx=120.0, ty=10.0, tz=10.0, cx=300.0)
        self.assertEqual(parse3(run_exe(self.exe_on, limits_lines([p]))[0])[0], 162.0)     # 100 + 62
    def test_guard_independent_of_m211(self):
        p = dict(xh=1, yh=1, zh=1, xt=1, act=0, mode=1, inact=362.0, hoff=250.0, soft=0, smin=-62.0, smax=302.0, tx=300.0, ty=10.0, tz=10.0, cx=100.0)
        self.assertEqual(parse3(run_exe(self.exe_on, limits_lines([p]))[0])[0], 190.0)      # 250-60, obwohl Softwaregrenzen aus (M211 S0)
    def test_not_trusted_or_unhomed_no_guard(self):
        for xh, xt in ((0, 0), (1, 0), (0, 1)):
            p = dict(xh=xh, yh=1, zh=1, xt=xt, act=0, mode=1, inact=362.0, hoff=188.0, soft=1, smin=-62.0, smax=302.0, tx=300.0, ty=10.0, tz=10.0, cx=100.0)
            self.assertEqual(parse3(run_exe(self.exe_on, limits_lines([p]))[0]), parse3(run_exe(self.exe_oem, limits_lines([p]))[0]))
    def test_duplication_mirrored_skipped(self):
        for mode in (2, 3):
            p = dict(xh=1, yh=1, zh=1, xt=1, act=0, mode=mode, inact=362.0, hoff=188.0, soft=1, smin=-62.0, smax=302.0, tx=300.0, ty=10.0, tz=10.0, cx=100.0)
            self.assertEqual(parse3(run_exe(self.exe_on, limits_lines([p]))[0])[0], 300.0)

class T04_NoMotion(unittest.TestCase):
    def test_gate_with_no_motion_before_homing(self):
        bad, n = check_gate(gate_exe(1), True); self.assertEqual(bad, [], bad[:3]); self.assertEqual(n, 128)
    def test_gate_baseline_shows_the_hole(self):
        bad, n = check_gate(gate_exe(0), False); self.assertEqual(bad, [])
        self.assertEqual(run_exe(gate_exe(0), ['0 7 1']), ['1'])         # Baseline (C12): nichts referenziert, G1 X Y Z laeuft trotzdem
        self.assertEqual(run_exe(gate_exe(1), ['0 7 1']), ['0'])
    def test_extruder_only_moves_allowed_unhomed(self):
        self.assertEqual(run_exe(gate_exe(1), ['0 0 1']), ['1'])      # G1 E.. ohne Achsen
    def test_homing_needed_error_is_real_text(self):
        real = read(EIN / 'real_c13.inc'); self.assertIn('axes_should_home', real); self.assertIn('Language_en::MSG_HOME_FIRST', real)

class T05_KillFans(unittest.TestCase):
    def test_events_all_combinations(self):
        bad, n = check_kill(patched['src/MarlinCore.cpp']); self.assertEqual(bad, [], bad[:3])
    def test_order_after_cli_and_heaters(self):
        ev = run_kill(patched['src/MarlinCore.cpp'], 1, 1, 1, 0); self.assertEqual(ev, ['CLI', 'HEATERS_OFF', 'WRITE14=1', 'WRITE12=1'])
    def test_switch_off_is_old_behaviour(self):
        self.assertEqual(run_kill(patched['src/MarlinCore.cpp'], 0, 1, 1, 0), ['CLI', 'HEATERS_OFF'])
    def test_real_macros(self):
        m = read(EIN / 'real_macros_c13.txt')
        for k in ('#define FAN_INVERTING false', '#define FAN_PIN PB14', '#define FAN1_PIN PB12', '#define FAN_SOFT_PWM', '#define HAS_FAN0 1', '#define HAS_FAN1 1'): self.assertIn(k, m)
    def test_original_minkill_unchanged_otherwise(self):
        o = read(EIN / 'MarlinCore.cpp'); n = patched['src/MarlinCore.cpp']
        a = func_text(o, r'^void minkill\('); b = func_text(n, r'^void minkill\(')
        s0 = b.index('\n  // SV04 NEXT C13 (kill fans on): cli()'); s1 = b.index('\n  #endif\n', s0) + len('\n  #endif\n') - 1; b2 = b[:s0] + b[s1:]
        strip = lambda x: re.sub(r'\n\s*\n', '\n', x); self.assertEqual(strip(a), strip(b2))

class T06_Pflichtfaelle(unittest.TestCase):
    """AP1: 12 Pflichtfaelle. Ergebnis je Fall: darf eine X/Y/Z-Fahrt per G-Code (G0/G1) beginnen und welches X-Ziel wird freigegeben?"""
    @classmethod
    def setUpClass(cls):
        cls.lim = build_limits(patched['src/module/motion.cpp'], TMP, 'pf_lim', True)
        cls.gate = gate_exe(1)
    def move(self, homed_bits, trusted, act, mode, inact, hoff, tx, cx, seen=1):
        ok = run_exe(self.gate, ['%d %d 1' % (homed_bits, seen)])[0] == '1'
        if not ok: return None
        smin, smax = (-62.0, 302.0) if act == 0 else (0.0, 362.0)
        p = dict(xh=homed_bits & 1, yh=(homed_bits >> 1) & 1, zh=(homed_bits >> 2) & 1, xt=trusted, act=act, mode=mode, inact=inact, hoff=hoff, soft=1, smin=smin, smax=smax, tx=tx, ty=10.0, tz=10.0, cx=cx)
        return parse3(run_exe(self.lim, limits_lines([p]))[0])[0]
    def test_01_t0_active_t1_parked(self): self.assertEqual(self.move(7, 1, 0, 1, 362.0, 0.0, 300.0, 100.0), 300.0); self.assertEqual(self.move(7, 1, 0, 1, 362.0, 0.0, 320.0, 100.0), 302.0)
    def test_02_t1_active_t0_parked(self): self.assertEqual(self.move(7, 1, 1, 1, 362.0, 0.0, 10.0, 200.0), 10.0); self.assertEqual(self.move(7, 1, 1, 1, 362.0, 0.0, -30.0, 200.0), 0.0)
    def test_03_t0_to_t1_geometry_after_change(self): self.assertEqual(self.move(7, 1, 1, 1, 362.0, 0.0, 5.0, 362.0), 5.0)          # T1 aktiv, T0 bei -62 geparkt
    def test_04_t1_to_t0_geometry_after_change(self): self.assertEqual(self.move(7, 1, 0, 1, 362.0, 0.0, 250.0, -62.0), 250.0)       # T0 aktiv, T1 bei 362 geparkt
    def test_05_unknown_position_of_a_carriage(self):
        self.assertIsNone(self.move(0b110, 0, 0, 1, 362.0, 0.0, 50.0, 100.0))        # X nicht referenziert -> G1 X verweigert
        self.assertEqual(self.move(7, 1, 0, 0, float('nan'), 0.0, 50.0, 100.0), 100.0)  # FULL_CONTROL: gefuehrte Parkposition unbekannt -> X gesperrt (Ziel = aktuelle Position)
    def test_06_restart_after_m999(self): self.assertIsNone(self.move(0, 0, 0, 1, 362.0, 0.0, 50.0, 100.0)); self.assertIsNone(self.move(0, 0, 0, 1, 362.0, 0.0, 50.0, 100.0, seen=4))   # C9: alles unreferenziert (auch Z)
    def test_07_cold_start(self): self.assertIsNone(self.move(0, 0, 0, 1, 362.0, 0.0, 50.0, 0.0)); self.assertIsNone(self.move(0, 0, 0, 1, 362.0, 0.0, 50.0, 0.0, seen=2))
    def test_08_move_during_toolchange_documented(self):
        # G-Code laeuft strikt nacheinander (T<n> ist synchron, planner.synchronize()); parallele G-Code-Bewegung gibt es nicht. Display-Direktbewegung: nicht abgedeckt (ChatGPT, 319).
        self.assertTrue(True)
    def test_09_move_after_aborted_homing(self):
        # C12-Test (homeaxis, echter Code): Abbruch vor set_axis_is_at_home() laesst homed/trusted unveraendert (hier: ungesetzt) -> G1 verweigert
        self.assertIsNone(self.move(0, 0, 0, 1, 362.0, 0.0, 50.0, 100.0)); self.assertIsNone(self.move(0b011, 1, 0, 1, 362.0, 0.0, 50.0, 100.0, seen=4))    # X/Y homed, Z nicht -> G1 Z verweigert
    def test_10_resume_after_stop(self): self.assertIsNone(self.move(0, 0, 1, 1, 362.0, 0.0, 50.0, 100.0))          # nach M999 (C9): unreferenziert
    def test_11_display_move_not_covered(self): self.assertTrue(True)       # RTS_line_to_current -> planner direkt; ausserhalb von G0/G1 und apply_motion_limits (ChatGPT/319)
    def test_12_move_after_sd_abort(self):
        # SD-Abbruch (C11) behaelt die Referenz; Waechter bleibt aktiv: T0 aktiv, T1 laut Konfig bei 188 geparkt -> 128
        self.assertEqual(self.move(7, 1, 0, 1, 362.0, 188.0, 300.0, 100.0), 128.0)

# ---------------- Mutanten ----------------
def mutate(text, old, new, count=1):
    assert text.count(old) >= 1, old; return text.replace(old, new, count)
class T07_Mutanten(unittest.TestCase):
    def test_header_mutants_killed(self):
        M = [('lock->pass target (kein fail-closed)', 'if (!(inactive_x == inactive_x) || inactive_x < lo_abs || inactive_x > hi_abs) return current_x;', 'if (!(inactive_x == inactive_x) || inactive_x < lo_abs || inactive_x > hi_abs) return target_x;'),
             ('NaN-Ziel nicht gesperrt', '  if (!(target_x == target_x)) return current_x;', ''),
             ('lo falsch (<=)', 'inactive_x < lo_abs ||', 'inactive_x <= lo_abs ||'),
             ('hi falsch (>=)', 'inactive_x > hi_abs)', 'inactive_x >= hi_abs)'),
             ('T0: gap vergessen', 'const float lim = inactive_x - gap_t0;', 'const float lim = inactive_x;'),
             ('T1: gap vergessen', 'const float lim = inactive_x + gap_t1;', 'const float lim = inactive_x;'),
             ('T0 Vorzeichen', 'inactive_x - gap_t0', 'inactive_x + gap_t0'),
             ('T1 Vorzeichen', 'inactive_x + gap_t1', 'inactive_x - gap_t1'),
             ('T0 vertauscht mit T1-Gap', 'inactive_x - gap_t0', 'inactive_x - gap_t1'),
             ('T1 vertauscht mit T0-Gap', 'inactive_x + gap_t1', 'inactive_x + gap_t0'),
             ('T0: Vergleich umgedreht', 'return target_x > lim ? lim : target_x;', 'return target_x < lim ? lim : target_x;'),
             ('T1: Vergleich umgedreht', 'return target_x < lim ? lim : target_x;\n}', 'return target_x > lim ? lim : target_x;\n}'),
             ('aktiv invertiert', 'if (!active_is_t1) {', 'if (active_is_t1) {'),
             ('parked_x: immer inactive', 'return full_control ? inactive_x : other_home_x;', 'return inactive_x;'),
             ('parked_x: immer home', 'return full_control ? inactive_x : other_home_x;', 'return other_home_x;'),
             ('parked_x: Modus invertiert', 'return full_control ? inactive_x : other_home_x;', 'return full_control ? other_home_x : inactive_x;')]
        killed = 0; survived = []
        for i, (name, old, new) in enumerate(M):
            d = TMP / ('mh%d' % i); d.mkdir(); (d / 'sv04_claude_idex_guard.h').write_text(mutate(HEADER, old, new))
            try:
                bad, _ = check_guard(d, d)
                # parked_x wird vom Guard-Treiber nicht ausgefuehrt -> ueber die echte Funktion pruefen
                if not bad and 'parked' in name:
                    exe = build_limits(patched['src/module/motion.cpp'], d, 'lim_m', True, header_dir=d); bad, _ = check_limits(exe)
            except RuntimeError as e: bad = ['compile']
            if bad: killed += 1
            else: survived.append(name)
        (PKG / '04_ROHLOGS' / 'mutanten_c13_header.txt').write_text('Mutanten Header: %d, getoetet: %d, ueberlebt: %s\n' % (len(M), killed, survived))
        self.assertEqual(survived, [], survived)
    def test_hook_mutants_killed(self):
        base = patched['src/module/motion.cpp']
        M = [('trusted nicht geprueft', 'axis_was_homed(X_AXIS) && axis_is_trusted(X_AXIS) && !idex_is_duplicating()', 'axis_was_homed(X_AXIS) && !idex_is_duplicating()'),
             ('homed nicht geprueft', 'axis_was_homed(X_AXIS) && axis_is_trusted(X_AXIS) && !idex_is_duplicating()', 'axis_is_trusted(X_AXIS) && !idex_is_duplicating()'),
             ('Duplikation nicht ausgenommen', 'axis_was_homed(X_AXIS) && axis_is_trusted(X_AXIS) && !idex_is_duplicating()', 'axis_was_homed(X_AXIS) && axis_is_trusted(X_AXIS)'),
             ('aktiv: Extruder-Index invertiert', 'active_extruder != 0,', 'active_extruder == 0,'),
             ('Modus FULL_CONTROL invertiert', 'dual_x_carriage_mode == DXC_FULL_CONTROL_MODE', 'dual_x_carriage_mode != DXC_FULL_CONTROL_MODE'),
             ('Entwurfsfehler: immer inactive_extruder_x', 'sv04c13_idex_parked_x(dual_x_carriage_mode == DXC_FULL_CONTROL_MODE, inactive_extruder_x, x_home_pos(active_extruder ? 0 : 1))', 'inactive_extruder_x'),
             ('Park-Werkzeug falsch (eigenes statt anderes)', 'x_home_pos(active_extruder ? 0 : 1)', 'x_home_pos(active_extruder ? 1 : 0)'),
             ('Gap T0/T1 vertauscht', 'float(SV04_IDEX_GAP_T0_MM), float(SV04_IDEX_GAP_T1_MM)', 'float(SV04_IDEX_GAP_T1_MM), float(SV04_IDEX_GAP_T0_MM)'),
             ('Waechter hinter M211-Rueckkehr', None, None),
             ('aktuelle Position nicht benutzt', 'target.x, current_position.x, active_extruder', 'target.x, target.x, active_extruder'),
             ('Waechter schreibt Y', 'target.x = sv04c13_idex_x(', 'target.y = sv04c13_idex_x(')]
        killed = 0; survived = []
        for i, (name, old, new) in enumerate(M):
            if old is None:       # Waechter nach "if (!soft_endstop._enabled) return;" verschieben
                blk_start = base.index('    // SV04 NEXT C13 (idex gap guard): unabhaengig'); blk_end = base.index('    #endif\n', blk_start) + len('    #endif\n\n')
                blk = base[blk_start:blk_end]; txt = base.replace(blk, '', 1).replace('    if (!soft_endstop._enabled) return;\n', '    if (!soft_endstop._enabled) return;\n' + blk, 1)
            else: txt = mutate(base, old, new)
            try:
                exe = build_limits(txt, TMP, 'mhk%d' % i, True); bad, _ = check_limits(exe)
            except RuntimeError: bad = ['compile']
            if bad: killed += 1
            else: survived.append(name)
        (PKG / '04_ROHLOGS' / 'mutanten_c13_hook.txt').write_text('Mutanten Hook: %d, getoetet: %d, ueberlebt: %s\n' % (len(M), killed, survived))
        self.assertEqual(survived, [], survived)
    def test_gate_and_kill_mutants_killed(self):
        # (a) Gate: Bedingung verfaelscht
        survived = []; n = 0
        G0 = read(EIN / 'G0_G1.cpp')
        for name, old, new in [('seen Y ignoriert', "(parser.seen_test('Y') ? _BV(Y_AXIS) : 0)", '0'), ('seen Z ignoriert', "(parser.seen_test('Z') ? _BV(Z_AXIS) : 0)", '0'), ('seen X ignoriert', "(parser.seen_test('X') ? _BV(X_AXIS) : 0)", '0'), ('Negation fehlt', '&& !homing_needed_error(', '&& homing_needed_error('), ('IsRunning entfernt', 'if (IsRunning()', 'if (true')]:
            n += 1; d = TMP / ('mg%d' % n); d.mkdir(); src = gate_source(True)
            # Mutation am extrahierten Gate-Text: statt Datei zu veraendern, Quelle der Bedingung patchen
            m = G0.replace(old, new, 1); assert m != G0, name
            tmpdir = d / 'e'; tmpdir.mkdir(); (tmpdir / 'G0_G1.cpp').write_text(m)
            import c13lib; saved = c13lib.EIN
            globals()['EIN'] = tmpdir
            try:
                for f in ('real_c13.inc',): shutil.copy(saved / f, tmpdir / f)
                (d / 'g.cpp').write_text(gate_source(True)); gxx(d / 'g.cpp', d / 'g'); bad, _ = check_gate(d / 'g', True)
            except RuntimeError: bad = ['compile']
            finally: globals()['EIN'] = saved
            if not bad: survived.append(name)
        # (b) kill: Reihenfolge/Polaritaet/Schalter
        core = patched['src/MarlinCore.cpp']
        for name, old, new in [('Fan nur FAN0', '    #if HAS_FAN1\n      WRITE(FAN1_PIN, (FAN_INVERTING) ? LOW : HIGH);\n    #endif\n', ''), ('Polaritaet falsch', 'WRITE(FAN_PIN, (FAN_INVERTING) ? LOW : HIGH)', 'WRITE(FAN_PIN, (FAN_INVERTING) ? HIGH : LOW)'), ('Fan1 Polaritaet falsch', 'WRITE(FAN1_PIN, (FAN_INVERTING) ? LOW : HIGH)', 'WRITE(FAN1_PIN, LOW)'),
                               ('Schalter ignoriert', '#if SV04_CLAUDE_KILL_FANS_ON && HAS_FAN', '#if HAS_FAN'), ('Fan vor cli', '  cli(); // Stop interrupts\n', '  WRITE(FAN_PIN, HIGH);\n  cli(); // Stop interrupts\n'), ('Fan statt Heizer-Aus', '  // Reiterate heaters off\n  thermalManager.disable_all_heaters();\n', '  // Reiterate heaters off\n')]:
            n += 1; txt = mutate(core, old, new)
            try: bad, _ = check_kill(txt)
            except RuntimeError: bad = ['compile']
            if not bad: survived.append('kill: ' + name)
        (PKG / '04_ROHLOGS' / 'mutanten_c13_gate_kill.txt').write_text('Mutanten Gate/Kill: %d, ueberlebt: %s\n' % (n, survived))
        self.assertEqual(survived, [], survived)

if __name__ == '__main__':
    try: unittest.main(verbosity=2)
    finally: shutil.rmtree(TMP, ignore_errors=True)
