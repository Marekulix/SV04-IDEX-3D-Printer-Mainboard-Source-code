#!/usr/bin/env python3
"""Minimaler Bedingungs-Praeprozessor fuer die Testharnesse (nur #if/#elif/#else/#endif/#ifdef/#ifndef; #define/#include/Rest bleibt).
Werte kommen aus einem Dict (V); unbekannte Namen = 0. ENABLED(x)/DISABLED(x) nach Marlin-Art. Zweck: Marlin-Quelltext einer EINZELNEN Funktion
mit den im Build belegten Makrowerten (aus dem .macros-Auszug des GitHub-Laufs) in reines C++ zu uebersetzen, ohne Handarbeit am Funktionstext."""
import re
KW = {'and', 'or', 'not', 'True', 'False'}
def _ev(expr, V):
    e = re.sub(r'//.*', '', expr)
    e = re.sub(r'\bdefined\s*\(\s*(\w+)\s*\)', lambda m: '1' if m.group(1) in V else '0', e)
    e = re.sub(r'\bENABLED\s*\(\s*(\w+)\s*\)', lambda m: '1' if V.get(m.group(1), 0) else '0', e)
    e = re.sub(r'\bDISABLED\s*\(\s*(\w+)\s*\)', lambda m: '0' if V.get(m.group(1), 0) else '1', e)
    def both(m): return '(%s and %s)' % (m.group(1), m.group(2))
    e = re.sub(r'\bBOTH\s*\(\s*(\w+)\s*,\s*(\w+)\s*\)', lambda m: '(%d and %d)' % (bool(V.get(m.group(1), 0)), bool(V.get(m.group(2), 0))), e)
    e = re.sub(r'\bEITHER\s*\(\s*(\w+)\s*,\s*(\w+)\s*\)', lambda m: '(%d or %d)' % (bool(V.get(m.group(1), 0)), bool(V.get(m.group(2), 0))), e)
    e = e.replace('&&', ' and ').replace('||', ' or ')
    e = re.sub(r'!(?!=)', ' not ', e)
    e = re.sub(r'\b[A-Za-z_]\w*\b', lambda m: m.group(0) if m.group(0) in KW else str(V.get(m.group(0), 0)), e)
    return bool(eval(e, {'__builtins__': {}}, {}))
def pp(text, V):
    out = []; stack = []   # (active_parent, taken, active)
    for line in text.split('\n'):
        s = line.strip()
        m = re.match(r'#\s*(if|ifdef|ifndef|elif|else|endif)\b(.*)', s)
        if not m: 
            if all(a for _, _, a in stack): out.append(line)
            continue
        d, rest = m.group(1), m.group(2).strip()
        par = all(a for _, _, a in stack)
        if d == 'if': c = _ev(rest, V); stack.append((par, c, par and c))
        elif d == 'ifdef': c = rest in V; stack.append((par, c, par and c))
        elif d == 'ifndef': c = rest not in V; stack.append((par, c, par and c))
        elif d == 'elif':
            p, taken, _ = stack.pop(); c = (not taken) and _ev(rest, V); stack.append((p, taken or c, p and c))
        elif d == 'else':
            p, taken, _ = stack.pop(); stack.append((p, True, p and not taken))
        elif d == 'endif': stack.pop()
    assert not stack, 'unbalanced #if'
    return '\n'.join(out)
