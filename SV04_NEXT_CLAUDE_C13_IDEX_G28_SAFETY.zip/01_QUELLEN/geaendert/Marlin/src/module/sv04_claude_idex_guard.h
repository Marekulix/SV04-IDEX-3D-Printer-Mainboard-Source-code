/**
 * SV04 NEXT C13 - IDEX-Abstandswaechter (reine Logik, ohne Marlin-Abhaengigkeit, host-testbar)
 *
 * Zweck: Der aktive X-Schlitten darf nie naeher an den GEPARKTEN Schlitten heranfahren, als ein Mindestabstand erlaubt.
 * OEM-Marlin begrenzt X nur durch FESTE Softwaregrenzen (T0: -62..302, T1: 0..362). Diese sind nur dann kollisionssicher,
 * wenn der andere Schlitten wirklich an seiner Referenzposition steht. Hier wird stattdessen die von Marlin GEFUEHRTE
 * Parkposition (inactive_extruder_x) verwendet.
 *
 * Mindestabstaende (Abstand der X-Koordinaten der beiden Schlitten):
 *   NICHT gemessen. Standard = der Abstand, den die OEM-Konfiguration an den eigenen Softwaregrenzen selbst zulaesst:
 *     T0 aktiv: X2_MAX_POS - X_MAX_POS  = 362 - 302 = 60 mm
 *     T1 aktiv: X2_MIN_POS - X1_MIN_POS =   0 - (-62) = 62 mm
 *   Bei der Standard-Parkposition (T1 362, T0 -62) ist der Waechter daher identisch mit den OEM-Grenzen.
 *   Er wirkt nur, wenn die gefuehrte Parkposition naeher am aktiven Schlitten liegt. Echte Mindestabstaende koennen nur
 *   am Geraet gemessen werden und sind per -DSV04_IDEX_GAP_T0_MM / -DSV04_IDEX_GAP_T1_MM zu setzen.
 *
 * Welche Position gilt als "geparkt"?
 *   DXC_AUTO_PARK_MODE (Standard dieser Konfiguration): Marlin faehrt den abgewaehlten Schlitten an x_home_pos(Werkzeug) und fuehrt
 *     inactive_extruder_x NICHT nach (es bleibt der Wert aus G28, = Heimposition des 2. Schlittens). Geparkt = x_home_pos(anderes Werkzeug).
 *   DXC_FULL_CONTROL_MODE: Marlin fuehrt inactive_extruder_x beim Werkzeugwechsel nach. Geparkt = inactive_extruder_x.
 *
 * Fail-closed: ist die gefuehrte Parkposition keine Zahl oder ausserhalb [lo_abs, hi_abs], wird KEINE X-Bewegung freigegeben
 * (Ziel = aktuelle Position).
 */
#pragma once

#ifndef SV04_CLAUDE_IDEX_GAP_GUARD
  #define SV04_CLAUDE_IDEX_GAP_GUARD 1
#endif

static inline float sv04c13_idex_parked_x(const bool full_control, const float inactive_x, const float other_home_x) {
  return full_control ? inactive_x : other_home_x;
}

static inline float sv04c13_idex_x(const float target_x, const float current_x, const bool active_is_t1,
                                   const float inactive_x, const float gap_t0, const float gap_t1,
                                   const float lo_abs, const float hi_abs) {
  if (!(target_x == target_x)) return current_x;                                    // Ziel keine Zahl: sperren
  if (!(inactive_x == inactive_x) || inactive_x < lo_abs || inactive_x > hi_abs) return current_x;  // unbekannt/unplausibel: sperren
  if (!active_is_t1) {                                    // T0 aktiv, T1 geparkt rechts: T0 darf nicht weiter als (T1 - gap_t0)
    const float lim = inactive_x - gap_t0;
    return target_x > lim ? lim : target_x;
  }
  const float lim = inactive_x + gap_t1;                  // T1 aktiv, T0 geparkt links: T1 darf nicht weiter links als (T0 + gap_t1)
  return target_x < lim ? lim : target_x;
}
