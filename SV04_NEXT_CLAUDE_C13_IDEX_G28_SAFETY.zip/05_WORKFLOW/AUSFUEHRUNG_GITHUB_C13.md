# GitHub-Lauf C13 (NO FLASH)
1. Ins Repository (Wurzel): `SV04_NEXT_CLAUDE_C13_IDEX_G28_SAFETY.zip` (auch mit Android-Zusatz „ (1)“ – der Workflow findet Dateien über Namenspräfix **und** SHA-256, nicht über den exakten Namen), `claude_c13_stm32_no_flash.yml` nach `.github/workflows/`. Die älteren Eingaben (318, C9, C10, C11, C12) liegen schon dort. Manuell starten.
2. Jobs: `baseline_c12` (318 → C9 → C10 → C11 → C12, baut `oem_c12`), `c13_changes` (zusätzlich C13 → `oem_c13`, C13-Tests, beide Profile, bei Erfolg Firmware-Export), `evaluate_builds` (grün nur bei 4/4 PASS, RAM/Flash-Vergleich).
3. Artefakte zurückgeben: `SV04_C13_BASELINE_C12_STM32_LOGS_NO_FLASH`, `SV04_C13_CHANGED_STM32_LOGS_NO_FLASH`, `SV04_C13_EVALUATION`, bei Erfolg `SV04_C13_COMPILED_BINARIES_NO_FLASH_APPROVAL` (nicht zur Installation freigegeben).
4. „STM32-gebaut“ gilt erst bei Exit 0 + `[SUCCESS]` + RAM/Flash je Profil. ZIP-Hashes sind im Workflow eingetragen; nicht neu packen.
