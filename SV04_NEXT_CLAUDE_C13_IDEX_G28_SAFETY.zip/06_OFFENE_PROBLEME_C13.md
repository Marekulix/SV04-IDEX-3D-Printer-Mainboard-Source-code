# Offene Probleme nach C13
| Nr | Problem | Einstufung | Weg |
|---|---|---|---|
| F1 | T1-Heimposition 188 laut `HOTEND_OFFSET_X`; T0 wird damit auf 128 begrenzt | belegt (Quelltext), Bedeutung am Gerät offen | D5: M503/EEPROM prüfen |
| F2 | Mindestabstände 60/62 ungemessen | nur am Gerät | `-DSV04_IDEX_GAP_T0_MM/T1_MM` |
| F3 | Display umgeht G-Code-Schutz, eigene x0/x1-Variablen | belegt | ChatGPT (05_INTEGRATION) |
| F4 | Referenz bleibt nach Stepper-aus + Handverschieben erhalten | belegt (`HOME_AFTER_DEACTIVATE` aus) | D6 |
| F5 | 400/410-mm-Freigabe | nur Messung | 07_Z_ACHSE |
| F6 | Lüfterlast PB14/PB12 | nur Aufbau | Marek |
| F7 | Power-Loss-Resume mit NO_MOTION nicht getestet | unbelegt | Quelle `recovery.cpp` exportieren oder am Gerät |
| F8 | Build-Nachweis C13 | fehlt bis GitHub-Lauf | Workflow |
