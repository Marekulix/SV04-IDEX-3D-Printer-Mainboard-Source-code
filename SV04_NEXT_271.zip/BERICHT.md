# SV04 NEXT 268 – Punkt 1 IDEX + BLTouch

## Implementierte Änderung
Verändert ausschließlich die OEM-Datei `Marlin/src/gcode/calibrate/G28.cpp` des festgelegten Sovol-Commits `1867fcba75354a5c65e0631d6972dd19f1bd6cbe`.

- Pro G28 wird ein neues lokales Flag für T1-X-Homing angelegt (anfänglich `false`).
- Erst nach dem T1-Aufruf `homeaxis(X_AXIS)` wird es anhand der Firmware-Endpositions- und Vertrauensinformationen gesetzt.
- Vor `home_z_safely` muss dieses Flag, T0, kein Duplizierbetrieb, X-Vertrauen und eine plausible T1-Position vorliegen.
- Ein `G28 Z` ohne erneutes T1-Homing in derselben Ausführung wird bewusst abgewiesen. Das ist eine Kompatibilitätseinschränkung!
- Nach abgewiesenem oder nicht vertrauenswürdigem Z-Homing findet der Probe-Nachlauf nicht statt.
- Kein EEPROM-Schreiben, keine Änderung an G29 oder M420.

## Nachweise
16 lokale Python-Tests bestanden. Dies sind Patch- und Quelltexttests, keine Maschinen-/Motor-Tests.
GitHub-Actions-Workflow enthalten, **noch nicht ausgeführt**. Der vollständige STM32-Build ist **nicht nachgewiesen**.

## Risiken und offene Punkte
- T1-Homing-Endlage wird aus Firmwaredaten abgeleitet. Unabhängige physische Prüfung fehlt.
- Wenn ein Endschalter defekt ist, kann die Firmwarelage falsch sein.
- Der OEM-Quellstand muss im Workflow SHA-korrekt vorliegen; sonst bricht der Patch ab.
- Hardwareversuche nur mit geeigneten Sicherheitsvorkehrungen, vorerst **nicht flashen**.

## Fortschritt
Punkt 1 bleibt bei 35 % bis zur erfolgreich nachgewiesenen Integration / STM32-Build. Restliche Punkte bleiben unverändert.
