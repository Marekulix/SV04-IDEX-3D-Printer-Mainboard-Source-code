SV04 NEXT 271 - PUNKT 1: IDEX + BLTouch
Nur diese 2 Dateien in GitHub hochladen:
1. 271.yml nach .github/workflows/271.yml
2. SV04_NEXT_271.zip ins Repository-Hauptverzeichnis
Workflow unter Actions starten: '271 - SV04 P1 IDEX BLTouch STM32 - NO FLASH'

Die eigentlichen Patch-Dateien stammen aus Stand 268, welcher weiterhin
die getestete Ausgangsbasis fuer diesen Build-Versuch ist.
Es wird keine Firmware veroeffentlicht oder geflasht.
