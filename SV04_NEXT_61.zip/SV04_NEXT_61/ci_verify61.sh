#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m unittest discover -s tests -p 'test_*.py' -v
python3 - <<'PY'
import pathlib,zipfile
p=pathlib.Path('REFERENCE_ONLY_60.zip')
assert p.is_file() and zipfile.ZipFile(p).testzip() is None
print('STAND60_REFERENCE_ARCHIVE: OK (not integrated)')
PY
printf 'SV04 NEXT 61 HOST PASS - FLASH APPROVED: NO\n'
