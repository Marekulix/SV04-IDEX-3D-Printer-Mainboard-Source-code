#!/usr/bin/env python3
"""SV04 NEXT 61: audited OEM source discovery; no source edits and no flashing."""
import argparse, hashlib, json, pathlib, re, subprocess
REQUIRED=('platformio.ini','Marlin/Configuration.h','Marlin/Configuration_adv.h','Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp')
OEM_COMMIT='1867fcba75354a5c65e0631d6972dd19f1bd6cbe'
ENV='STM32F103RET6_creality'

def valid_root(p):
    return p.is_dir() and all((p / x).is_file() for x in REQUIRED)

def roots(base):
    base=pathlib.Path(base)
    choices=[base,base/'firmware',base/'MarlinFirmware',base/'source',base/'sv04',base/'SV04-IDEX-3D-Printer-Mainboard-Source-code']
    return [x for x in choices if valid_root(x)]

def determine(base):
    candidates=roots(base)
    if len(candidates)>1:
        raise ValueError('multiple source roots: '+', '.join(map(str,candidates)))
    return candidates[0] if candidates else None

def audit(root):
    root=pathlib.Path(root)
    if not valid_root(root):raise ValueError('required OEM files missing')
    ini=(root/'platformio.ini').read_text(encoding='utf-8',errors='replace')
    if not re.search(r'^\s*default_envs\s*=\s*STM32F103RET6_creality\s*$',ini,re.M):
        raise ValueError('unrecognized PlatformIO default board environment')
    paths={str(x):hashlib.sha256((root/x).read_bytes()).hexdigest() for x in REQUIRED}
    return {'source_root':str(root),'files_sha256':paths,'environment':ENV,'flash_approved':False}

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--out',required=True)
    a=p.parse_args(); report=audit(a.root)
    pathlib.Path(a.out).write_text(json.dumps(report,indent=2)+'\n')
    print('SV04NEXT61_SOURCE_AUDIT_OK env='+ENV+' root='+str(a.root)+' FLASH_APPROVED=NO')
if __name__=='__main__':main()
