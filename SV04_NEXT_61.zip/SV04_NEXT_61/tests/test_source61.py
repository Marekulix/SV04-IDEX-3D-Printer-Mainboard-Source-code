import pathlib, tempfile, unittest, sys
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'tools'))
from source61 import audit, determine, valid_root, REQUIRED
class TestDiscovery(unittest.TestCase):
 def fixture(self,where):
  for f in REQUIRED:
   p=where/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('[platformio]\ndefault_envs = STM32F103RET6_creality\n' if f=='platformio.ini' else '// placeholder\n')
 def test_root(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d);self.fixture(p);self.assertEqual(determine(p),p);self.assertEqual(audit(p)['environment'],'STM32F103RET6_creality')
 def test_firmware_subdir(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d);self.fixture(p/'firmware');self.assertEqual(determine(p),p/'firmware')
 def test_missing(self):
  with tempfile.TemporaryDirectory() as d:self.assertIsNone(determine(d))
 def test_ambiguity(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d);self.fixture(p);self.fixture(p/'firmware');
   with self.assertRaises(ValueError):determine(p)
 def test_wrong_environment(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d);self.fixture(p);(p/'platformio.ini').write_text('[platformio]\ndefault_envs = megaatmega2560\n')
   with self.assertRaises(ValueError):audit(p)
 def test_no_flash(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d);self.fixture(p);self.assertFalse(audit(p)['flash_approved'])
if __name__=='__main__':unittest.main()
