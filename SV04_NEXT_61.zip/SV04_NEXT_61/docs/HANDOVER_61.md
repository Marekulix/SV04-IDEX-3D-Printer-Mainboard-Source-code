# SV04 NEXT 61 – offizieller Quellbaum & STM32-Baseline

## Befund Stand 60
Das Actions-Archiv `sv04next60-stm32-evidence.zip` enthält **kein Kompilierprotokoll**. `preflight60.json` zeigt, dass `firmware/` keine der vier erforderlichen Quelldateien enthält. Die Sperre über `firmware/SV04_NEXT_STM32_ENV.txt` hat daher vor dem Build ausgelöst. Die Host-Evidenz enthielt lediglich das Upload-Ergebnis. Das ist **keine gescheiterte Firmwarekompilierung**.

## Maßnahme Stand 61
Workflow 61 erkennt vollständige Quellbäume am Repository-Root oder in bekannten Unterverzeichnissen. Falls nicht vorhanden, klont er **nur zur Referenzkompilierung** das offizielle Sovol-Repository, gepinnt auf `1867fcba75354a5c65e0631d6972dd19f1bd6cbe`. Verifizierter offizieller Default-Environment-Eintrag: `STM32F103RET6_creality`. Das offizielle Sovol-Repo liefert die Marlin-Hauptplatinen-Quellen, nicht das DWIN-Displayprojekt.

**WICHTIG:** Auch bei einem grünen CI-Build ist dies nur ein OEM-Baseline-Build, KEIN angewendeter SV04-NEXT-Stand 57/60, KEINE AUTO60-Aktivierung, KEIN FLASH. Stand 57 liegt in dieser Umgebung nicht als vollständiges Quell-Overlay vor. Die früheren Hosttests von 60 bleiben ein eigenständiger, nicht integrierter Prüfstand.

## GitHub Upload vom Android-Tablet
1. `SV04_NEXT_61.zip` ins Repository-Hauptverzeichnis.
2. `61.yml` nach `.github/workflows/61.yml`.
3. Actions > `61 - SV04 NEXT source discovery and pinned Sovol baseline build - NO FLASH` > Run workflow.
4. Ergebnisarchive `sv04next61-host-evidence` und `sv04next61-stm32-evidence` zurückgeben. Bei Buildfehler sind die Logs das eigentliche Diagnosematerial.

## Grenzen
- Kein eingebauter T1-Kollisionsschutz, Auto60-Knopf oder M500-Automatik; alles weiterhin fail-closed.
- Kein Display-Hardwaretest, kein Drucker-Flash und kein mechanischer Kollisionsnachweis.
- Der dokumentierte Gesamtfortschritt beträgt unverändert **39,50 %**, solange keine validierten Integrationsnachweise vorliegen.
