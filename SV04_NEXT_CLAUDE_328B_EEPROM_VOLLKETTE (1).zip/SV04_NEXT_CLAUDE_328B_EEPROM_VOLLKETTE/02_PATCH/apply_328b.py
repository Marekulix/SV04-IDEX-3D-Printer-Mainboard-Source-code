#!/usr/bin/env python3
"""SV04C328B: save(): Erfolgsmeldung 'Settings Stored (..)' erst NACH size_error-Pruefung und nur bei Erfolg.
Strikte Hash-Pruefung: Eingang = settings.cpp nach 328A (bb5043f4...)."""
import sys, hashlib
P = sys.argv[1]
IN = 'bb5043f4d6df93df6c1d030fc677ffa5478ba59d04a9fd3d548769610ab9bd66'
s = open(P, 'rb').read()
if hashlib.sha256(s).hexdigest() != IN: sys.exit('FEHLER: settings.cpp nicht im Zustand 328A (Hash)')
t = s.decode()
old = '''      // Report storage size
      DEBUG_ECHO_MSG("Settings Stored (", eeprom_size, " bytes; crc ", (uint32_t)final_crc, ")");

      eeprom_error |= size_error(eeprom_size);
'''
new = '''      // SV04C328B-BEGIN: Erfolgsmeldung nur nach bestandener Groessenpruefung (kein 'Settings Stored' bei Schreibfehler)
      eeprom_error |= size_error(eeprom_size);

      // Report storage size
      if (!eeprom_error) DEBUG_ECHO_MSG("Settings Stored (", eeprom_size, " bytes; crc ", (uint32_t)final_crc, ")");
      // SV04C328B-END
'''
assert t.count(old) == 1, 'Muster nicht eindeutig'
open(P, 'w').write(t.replace(old, new)); print('OK', hashlib.sha256(open(P,'rb').read()).hexdigest())
