# SV04 NEXT – Claude 328B: EEPROM-Vollkette M500 → M501 → M503

**FLASH_ALLOWED=NO · HARDWARE_TESTED=NO.** Nichts davon ist auf Hardware bestätigt. STM32-Build: **noch nicht gelaufen** (erst nach grünem GitHub-Lauf behaupten).

## Status-Trennung
| Stufe | Inhalt |
|---|---|
| programmiert | 328B-Patch `settings.cpp` (nur `save()`-Reihenfolge der Erfolgsmeldung) |
| host-getestet | 33 Tests × echte Funktionen (siehe unten), 6 Mutanten, Vorher/Nachher |
| STM32-gebaut | **NEIN – offen bis GitHub-Lauf mit `claude_328b_stm32_fullchain_no_flash.yml`** |
| hardware-bestätigt | **NEIN** |

## Methode (neu gegenüber 327/Workflow 35)
Die **echte** `settings.cpp.i` (328A-Export, Präprozessor-Auszug), das **echte** `PersistentStore` aus `eeprom_bl24cxx.cpp.i` und die **echten** Rümpfe `M500`–`M503` werden zusammen als 32-Bit-Freestanding-Programm (g++ -m32, wie STM32-Layout) nativ ausgeführt. Nur Kollaborateure sind Stubs/Modelle (Planner, I²C-EEPROM-Modell mit Fehlerinjektion, Serial-Capture, `crc16`, `reset_hotend_offsets`).

## Neu belegte Befunde
1. **Aktives Backend = `IIC_BL24CXX_EEPROM`** (externes I²C-EEPROM, 2048 Byte, `EEPROM_OFFSET` 100, Version `V85`). `FLASH_EEPROM_EMULATION` ist nicht definiert; `eeprom_flash`/`eeprom_wired` enthalten kein `PersistentStore`. **Korrigierte Annahme:** Workflow 35 testete die Flash-Emulation – das war nicht das aktive Backend.
2. **M500→Reset(M502)→M501** stellt alle geprüften Felder exakt wieder her (Schritte, Feedrates, Beschleunigungen, Offsets, Probe-Offset, Hotend-Offset T1, SV04 Modus/Font). `datasize` = 742 Byte (+100 Offset ≪ 2048); kein Zugriff außerhalb 2048.
3. **M503** gibt `M605 S<n>` und `T<n>` ohne `Error:`-Präfix aus (normal und `S0`/replay-Variante geprüft); Werte entsprechen den geladenen.
4. **Negativfälle werden abgelehnt, Standardwerte geladen:** leerer EEPROM (0xFF), falsche Version, falsche CRC, Einzelbitfehler in **jedem** Nutzdatenbyte (1472 Fälle), Bitfehler in Versionsbytes 0–2 und CRC, Layoutfehler mit passender CRC (nur Größenprüfung greift: N5b).
5. **SV04-Werte 0…255** (Modus >4 → 0, Font >1 → 0) über echtes `save()`+`load()`: 256/256 korrekt, übrige Felder unverändert.
6. **`validate()` hat keine RAM-Seiteneffekte** (auch bei Modus 200/Font 9 im RAM).
7. **Stromausfall** nach jedem der 52 Byte-Schreibpunkte von M500 (Alt→Neu): nie gemischte Werte; Abbruch vor erstem Schreiben → alte Daten, vollständig → neue Daten, sonst abgelehnt (50 Punkte). `save()==true` nur wenn danach `load()` exakt die neuen Werte liefert.
8. **Defektes Byte** (Nutzdaten oder Version): `save()` liefert false, `load()` lehnt ab.
9. **Schreibzähler:** identisches zweites M500 schreibt 6 Byte (Version „ERR“→„V85“), Abbild unverändert; ein geänderter Wert: 9 Schreibvorgänge. (Beobachtung, kein Fehler.)

## Reproduzierter Fehler und Fix (F13)
`save()` meldete `Settings Stored (… bytes; crc …)` **bevor** `size_error()` geprüft wurde. Bei Schreibfehler (defektes Byte → Layoutverschiebung) kam false zurück, aber die Erfolgsmeldung stand schon im Log. Vorher-Test D2b = **FAIL**, nach Patch **PASS**. Fix: `size_error` zuerst, Meldung nur bei Erfolg (`apply_328b.py`, Eingangs-Hash `bb5043f4…` → `b4478678…`, 6 Zeilen Diff). Reichweite: nur Logausgabe, kein Verhaltensunterschied im Datenpfad.

## Eigene Fehlinterpretationen / Korrekturen
- Erste Testläufe zeigten 9 FAILs: **Testfehler, kein Marlin-Fehler** – `reset_hotend_offsets` war im Harness ein reiner Zähler-Stub (jetzt Modell der echten Funktion mit `HOTEND_OFFSET_X {0,188}`); das 4. Versionsbyte wird von Marlin gar nicht geprüft (`strncmp(...,3)`, Test N4c dokumentiert das); Abbruch-Test P3 prüfte zuerst fälschlich den Rückgabewert bei echtem Stromausfall.
- Mutationstest MUT2 überlebte zunächst → Testlücke (Größenfehler wurde immer schon durch CRC erkannt). Behoben durch N5b (CRC passend zum Layoutfehler).

## Mutationstest
6 von 6 Mutanten getötet (CRC-Prüfung, Größenprüfung, SV04-Modus-Clamp, Font-Clamp, Versionsprüfung entfernt; 328B-Fix zurückgenommen).

## Zählung
Vorher (328A-Stand): 32 PASS / 1 FAIL (D2b). Nachher (328B): **33 PASS / 0 FAIL**. Mutanten 6/6. Lokal ausgeführt, noch nicht in GitHub.

## Offen / nicht belegt / Einschränkungen
- **`crc16` ist nachgebaut** (CRC-CCITT 0x1021); `libs/crc16.cpp` war nicht im Export. Der Workflow exportiert es jetzt und prüft Äquivalenz (`check_crc16.py`, 8000 Fälle). Bis dahin: „CRC-Verhalten nur gegen Modell bewiesen“. Marlins echte CRC-Prüfung (`working_crc != stored_crc`) läuft real; die Harness-CRC wurde nur zum Fälschen gültiger Images genutzt (N5b nutzt die echte `working_crc`).
- `_report`-Funktionen von M92/M145/M200/… sind Zähler-Stubs: **M503-Text dieser Blöcke nicht real geprüft**; real geprüft sind SV04-Zeilen, Header/Replay-Logik soweit in `settings.cpp`.
- Stromausfall = Byte-Granularität des Modells; **kein** Test echter I²C-ACK/Timing-/Brown-out-Effekte (NICHT GETESTET).
- **Nicht angefasst:** `EEPROM_WRITE` ignoriert Rückgabewert von `write_data` (wird durch `size_error` am Ende aufgefangen, Tests D1–D4 bestätigen Fail-closed-Verhalten); `reset()` setzt die SV04-Felder nicht zurück (M3b, Beobachtung – Entscheidung offen).
- Header wird auch bei fehlgeschlagenem Layout als gültig (V85+CRC) geschrieben; `load()` lehnt zuverlässig ab (D3/P1).
- Echtes Backend-Verhalten bei Chip-Fehlern, Flash-Abstürzen, UI/DWIN-Pfade und LCD_RTS: nicht Teil dieses Laufs.

## Fortschritt (Vorschlag, nicht automatisch erhöht)
EEPROM-Rücklesung 70 → ca. 85 %, M500 80 → ca. 88 % – **erst nach grünem GitHub-Lauf übernehmen**, nicht hardware-bestätigt.

## Nächste Schritte
1. `claude_328b_stm32_fullchain_no_flash.yml` im Repo-Stamm starten (benötigt weiterhin die 328A-ZIP mit Hash `313b095b…`; die 328B-Testdateien sind in der YAML eingebettet und per SHA-256 geprüft).
2. Bei Grün: Artefakte `SV04_328B_INTEGRATED_BINARIES_NO_FLASH_APPROVAL`, `SV04_328B_EEPROM_SOURCE_EXPORT_DIAGNOSTIC`, `SV04_C13_DWIN325_CHANGED_STM32_LOGS_NO_FLASH` (enthält `fullchain328b/`) und `SV04_C13_DWIN325_EVALUATION` sichern.
3. Offene Entscheidungen D5–D8 sowie `reset()`/SV04-Felder klären. DWIN 329 wurde nicht berührt; `LCD_RTS.cpp` unverändert.
