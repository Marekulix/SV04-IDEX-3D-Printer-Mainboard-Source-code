# 328B EEPROM-Vollkette
- `00_START/ERGEBNISBERICHT_328B.md` – Bericht
- `01_QUELLEN/geaendert/…/settings.cpp` – Stand nach 328B (sha256 b4478678…)
- `02_PATCH/` – `apply_328b.py` (strikte Hashes), `settings_328a_to_328b.diff`
- `03_TESTS/` – Harness (`fullchain.py`, `stubs.inc`, `drv.inc`), Orchestrator `test_328b.py`, `check_crc16.py`, Eingang = echter 328A-Export
- `04_ROHLOGS/` – Rohausgaben Vorher/Nachher/Mutanten
Lauf: `03_TESTS/run_lokal.sh` (Linux, g++ mit -m32). FLASH_ALLOWED=NO, HARDWARE_TESTED=NO.
