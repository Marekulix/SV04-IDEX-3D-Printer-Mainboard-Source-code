#!/usr/bin/env python3
"""Baut und fuehrt die ECHTE settings.cpp-Kette aus (Praeprozessor-Auszug des 328A-Laufs): 32-Bit, freistehend, ohne libc."""
import sys, os, re, subprocess, hashlib
HERE = os.path.dirname(os.path.abspath(__file__))
def brace_block(s, start):
    i = s.index('{', start); d = 0
    for j in range(i, len(s)):
        if s[j] == '{': d += 1
        elif s[j] == '}':
            d -= 1
            if d == 0: return s[start:j + 1]
    raise ValueError
def extract_backend(bl_i):
    s = open(bl_i, errors='replace').read(); a = s.index('size_t PersistentStore::capacity()')
    rd = s.index('bool PersistentStore::read_data', a); end = s.index('{', rd); blk = brace_block(s, rd)
    return s[a:rd + len(blk) - len(blk)] + blk
def extract_m500(m_i):
    s = open(m_i, errors='replace').read(); out = []
    for name in ('M500', 'M501', 'M502', 'M503'):
        out.append(brace_block(s, s.index('void GcodeSuite::%s()' % name)))
    return '\n'.join(out)
def build(settings_i, bl_i, m_i, driver, exe, extra_flags=()):
    src = open(settings_i, errors='replace').read()
    # Nur Testzugriff: M500..M503 sind im echten Code private Klassenmember; fuer den Harness oeffentlich machen (keine Logikaenderung)
    assert src.count('static int eeprom_index;') == 1
    src = src.replace('static int eeprom_index;', 'public: static int eeprom_index;', 1)  # nur Testzugriff (working_crc/eeprom_index lesen)
    for n in ('M500','M501','M502','M503'):
        assert src.count('static void %s();' % n) == 1
        src = src.replace('static void %s();' % n, 'public: static void %s();' % n)
    parts = [src, '\n// ===== HARNESS =====\n', open(os.path.join(HERE, 'stubs.inc')).read(),
             '\n// ===== echtes PersistentStore (bl24cxx, aktives Backend) aus Praeprozessor-Auszug =====\nvoid eeprom_init(); void eeprom_write_byte(uint8_t*, unsigned char); uint8_t eeprom_read_byte(uint8_t*);\n', extract_backend(bl_i),
             '\n// ===== echte M500-M503 aus M500-M504.cpp.i =====\nGCodeParser parser;\n', extract_m500(m_i), '\n// ===== Treiber =====\n', open(driver).read(),
             '\nasm(".globl _start\\n_start:\\n call harness_main\\n mov %eax,%ebx\\n mov $1,%eax\\n int $0x80\\n");\n']
    c = exe + '.cpp'; open(c, 'w').write(''.join(parts))
    r = subprocess.run(['g++', '-m32', '-std=gnu++14', '-fpermissive', '-w', '-O0', '-fno-exceptions', '-fno-rtti', '-fno-stack-protector', '-ffreestanding', '-fno-builtin', '-fno-pic', '-fno-pie', '-nostdlib', '-static', '-Wl,-m,elf_i386,--no-warn-rwx-segments', '-o', exe, c] + list(extra_flags), capture_output=True, text=True)
    return r
if __name__ == '__main__':
    P = sys.argv[1]; r = build(P + '/Marlin_src_module_settings.cpp.i', P + '/Marlin_src_HAL_STM32_eeprom_bl24cxx.cpp.i', P + '/Marlin_src_gcode_eeprom_M500_M504.cpp.i', sys.argv[2], sys.argv[3])
    print(r.stdout[-3000:]); print(r.stderr[:6000]); sys.exit(r.returncode)
