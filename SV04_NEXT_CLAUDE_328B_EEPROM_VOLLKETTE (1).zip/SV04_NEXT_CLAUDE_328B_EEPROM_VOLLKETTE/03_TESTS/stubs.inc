// ===== SV04 328B Harness: Stubs/Modelle um das ECHTE settings.cpp.i (Build-Praeprozessor-Auszug, 328A-Lauf 43637341831) =====
// Alles oberhalb dieser Zeile ist der echte Quelltext. Alles darunter ist Harness: Laufzeit, I2C-EEPROM-Modell, Stubs fuer andere Uebersetzungseinheiten.
extern "C" {
void *memcpy(void *d, const void *s, unsigned n) { unsigned char *a = (unsigned char *)d; const unsigned char *b = (const unsigned char *)s; while (n--) *a++ = *b++; return d; }
void *memset(void *d, int c, unsigned n) { unsigned char *a = (unsigned char *)d; while (n--) *a++ = (unsigned char)c; return d; }
int memcmp(const void *x, const void *y, unsigned n) { const unsigned char *a = (const unsigned char *)x, *b = (const unsigned char *)y; while (n--) { if (*a != *b) return *a - *b; ++a; ++b; } return 0; }
int strncmp(const char *a, const char *b, unsigned n) { while (n--) { if (*a != *b) return (unsigned char)*a - (unsigned char)*b; if (!*a) return 0; ++a; ++b; } return 0; }
unsigned strlen(const char *s) { unsigned n = 0; while (s[n]) ++n; return n; }
void __cxa_pure_virtual() { for (;;) {} }
}
static void sys_write(const char *p, int n) { int r; asm volatile("int $0x80" : "=a"(r) : "a"(4), "b"(1), "c"(p), "d"(n) : "memory"); }
static void sys_exit(int c) { asm volatile("int $0x80" : : "a"(1), "b"(c)); for (;;) {} }
// ---- Ausgabe-Capture (alles, was der echte Code seriell ausgibt)
static char OUTB[65536]; static unsigned OUTN;
static void out_char(char c) { if (OUTN < sizeof(OUTB) - 1) OUTB[OUTN++] = c; OUTB[OUTN] = 0; }
static void out_str(const char *s) { while (*s) out_char(*s++); }
static void out_clear() { OUTN = 0; OUTB[0] = 0; }
// ---- Serial: MSerial1 (echtes Objekt, Schreibweg ueber HardwareSerial::write -> Capture)
HardwareSerial::HardwareSerial(void *, HalfDuplexMode_t) {}
int HardwareSerial::available(void) { return 0; }
int HardwareSerial::peek(void) { return -1; }
int HardwareSerial::read(void) { return -1; }
void HardwareSerial::flush(void) {}
size_t HardwareSerial::write(uint8_t c) { out_char((char)c); return 1; }
void MarlinSerial::begin(unsigned long, uint8_t) {}
MSerialT MSerial1(false, (void *)0, (usart_rx_callback_t)0);
const char SP_Z_STR[] = " Z";
void serialprintPGM(const char *s) { out_str(s); }
void serial_echo_start() { out_str("echo:"); }
void serial_error_start() { out_str("Error:"); }
// ---- Nachbauten aus Marlin-Standard (gcode.cpp nicht im Export): Report-Hilfen
void GcodeSuite::report_echo_start(const bool forReplay) { if (!forReplay) serial_echo_start(); }
void GcodeSuite::report_heading(const bool forReplay, const char *const pstr, const bool eol) { if (forReplay) return; if (pstr) { serial_echo_start(); out_str("; "); out_str(pstr); } if (eol) out_char('\n'); }
void GcodeSuite::say_units() { out_str("[stub:say_units]"); }
// ---- andere Uebersetzungseinheiten: Aufrufe nur zaehlen (NICHT ausgefuehrt!)
static unsigned STUBCALLS[64]; static const char *STUBNAMES[64]; static unsigned NSTUB;
static void stub_hit(const char *n) { for (unsigned i = 0; i < NSTUB; ++i) if (STUBNAMES[i] == n) { ++STUBCALLS[i]; return; } STUBNAMES[NSTUB] = n; STUBCALLS[NSTUB++] = 1; }
#define STUBM(sig, name) sig { stub_hit(name); }
STUBM(void GcodeSuite::M92_report(const bool, const int8_t), "M92_report")
STUBM(void GcodeSuite::M145_report(const bool), "M145_report")
STUBM(void GcodeSuite::M200_report(const bool), "M200_report")
STUBM(void GcodeSuite::M201_report(const bool), "M201_report")
STUBM(void GcodeSuite::M203_report(const bool), "M203_report")
STUBM(void GcodeSuite::M204_report(const bool), "M204_report")
STUBM(void GcodeSuite::M205_report(const bool), "M205_report")
STUBM(void GcodeSuite::M206_report(const bool), "M206_report")
STUBM(void GcodeSuite::M217_report(const bool), "M217_report")
STUBM(void GcodeSuite::M218_report(const bool), "M218_report")
STUBM(void GcodeSuite::M256_report(const bool), "M256_report")
STUBM(void GcodeSuite::M301_report(const bool, const int8_t), "M301_report")
STUBM(void GcodeSuite::M304_report(const bool), "M304_report")
STUBM(void GcodeSuite::M413_report(const bool), "M413_report")
STUBM(void GcodeSuite::M420_report(const bool), "M420_report")
STUBM(void GcodeSuite::M422_report(const bool), "M422_report")
STUBM(void GcodeSuite::M851_report(const bool), "M851_report")
static unsigned CALLS_reset_bed_level, CALLS_postprocess_parts, ALERTS, ALERT_LAST = 255;
void reset_bed_level() { stub_hit("reset_bed_level"); }
bool leveling_is_valid() { return false; }
void refresh_bed_level() { stub_hit("refresh_bed_level"); }
void set_z_fade_height(const float, const bool) { stub_hit("set_z_fade_height"); }
void reset_hotend_offsets() { stub_hit("reset_hotend_offsets"); hotend_offset[1].x = 188.0f; hotend_offset[1].y = 0; hotend_offset[1].z = 0; } // MODELL der echten Funktion (nicht im Export): HOTEND_OFFSET_X {0,188}, Y/Z 0
void reset_stepper_drivers() { stub_hit("reset_stepper_drivers"); }
void report_current_position() { stub_hit("report_current_position"); }
void update_workspace_offset(const AxisEnum) { stub_hit("update_workspace_offset"); }
void set_bed_leveling_enabled(const bool) { stub_hit("set_bed_leveling_enabled"); }
void update_software_endstops(const AxisEnum, const uint8_t, const uint8_t) { stub_hit("update_software_endstops"); }
void ZStepperAlign::reset_to_default() { stub_hit("ZStepperAlign::reset_to_default"); }
void PrintJobRecovery::enable(const bool onoff) { enabled = onoff; }
void Planner::refresh_positioning() { stub_hit("Planner::refresh_positioning"); }
void Planner::reset_acceleration_rates() { stub_hit("Planner::reset_acceleration_rates"); }
void Planner::calculate_volumetric_multipliers() { stub_hit("Planner::calculate_volumetric_multipliers"); }
void Endstops::enable_globally(const bool) { stub_hit("Endstops::enable_globally"); }
void MarlinUI::eeprom_alert(const uint8_t id) { ++ALERTS; ALERT_LAST = id; }
void MarlinUI::set_status_P(const char *, const int8_t) {}
void MarlinUI::set_brightness(const uint8_t) {}
// ---- Datenobjekte anderer Einheiten (nullinitialisiert; Typen aus dem echten Quelltext)
bool GCodeParser::volumetric_enabled;
decltype(Temperature::temp_hotend) Temperature::temp_hotend;
decltype(Temperature::temp_bed) Temperature::temp_bed;
decltype(ZStepperAlign::xy) ZStepperAlign::xy;
bool PrintJobRecovery::enabled;
decltype(Probe::offset) Probe::offset;
decltype(BLTouch::last_written_mode) BLTouch::last_written_mode;
decltype(Planner::skew_factor) Planner::skew_factor;
decltype(Planner::filament_size) Planner::filament_size;
decltype(Planner::z_fade_height) Planner::z_fade_height;
decltype(Planner::max_jerk) Planner::max_jerk;
decltype(Planner::settings) Planner::settings;
decltype(MarlinUI::brightness) MarlinUI::brightness;
decltype(MarlinUI::material_preset) MarlinUI::material_preset;
uint8_t active_extruder_font, dualXPrintingModeStatus;
decltype(bilinear_grid_spacing) bilinear_grid_spacing;
decltype(bilinear_start) bilinear_start;
decltype(current_position) current_position;
decltype(home_offset) home_offset;
decltype(hotend_offset) hotend_offset;
decltype(marlin_state) marlin_state;
decltype(toolchange_settings) toolchange_settings;
decltype(z_values) z_values;
// ---- crc16: Marlin-Standard (CRC-CCITT 0x1021, Startwert wie Aufrufer) NACHGEBAUT, libs/crc16.cpp nicht im Export
void crc16(uint16_t *crc, const void *const data, uint16_t cnt) {
  const uint8_t *ptr = (const uint8_t *)data;
  while (cnt--) { *crc = (uint16_t)(*crc ^ (uint16_t)(((uint16_t)*ptr++) << 8)); for (uint8_t i = 0; i < 8; i++) *crc = (uint16_t)((*crc & 0x8000) ? ((uint16_t)(*crc << 1) ^ 0x1021) : (*crc << 1)); }
}
// ---- I2C-EEPROM-Modell (BL24CXX, 2 KB = MARLIN_EEPROM_SIZE): Byte-Schreiben mit Fehlerinjektion
static uint8_t EEP[2048]; static unsigned EEP_WRITES, EEP_OOB, EEP_READS; static long CUT_AFTER = -1; static int STUCK_ADDR = -1; static uint8_t STUCK_VAL; static unsigned MAXADDR;
void eeprom_init() {}
uint8_t eeprom_read_byte(uint8_t *p) { unsigned a = (unsigned)(uintptr_t)p; ++EEP_READS; if (a >= sizeof(EEP)) { ++EEP_OOB; return 0xFF; } if (a > MAXADDR) MAXADDR = a; return EEP[a]; }
void eeprom_write_byte(uint8_t *p, unsigned char v) {
  unsigned a = (unsigned)(uintptr_t)p; if (a >= sizeof(EEP)) { ++EEP_OOB; return; } if (a > MAXADDR) MAXADDR = a;
  ++EEP_WRITES;
  if (CUT_AFTER >= 0 && (long)(EEP_WRITES) > CUT_AFTER) return;           // Stromausfall: ab hier kommt nichts mehr im Speicher an
  if (STUCK_ADDR == (int)a) { EEP[a] = STUCK_VAL; return; }                // defektes Byte
  EEP[a] = v;
}
void delay(uint32_t) {} void safe_delay(millis_t) {}
size_t Print::write(const uint8_t *b, size_t n) { size_t k = 0; while (n--) k += write(*b++); return k; }
size_t Stream::readBytes(char *, size_t) { return 0; }
size_t Stream::readBytesUntil(char, char *, size_t) { return 0; }
decltype(GCodeParser::codebits) GCodeParser::codebits; decltype(GCodeParser::param) GCodeParser::param;
decltype(GCodeParser::command_ptr) GCodeParser::command_ptr; decltype(GCodeParser::value_ptr) GCodeParser::value_ptr;
extern "C" long strtol(const char *, char **, int) { return 0; }
extern "C" { extern void (*__init_array_start[])(); extern void (*__init_array_end[])(); }
static void run_ctors() { for (void (**f)() = __init_array_start; f < __init_array_end; ++f) (*f)(); }
