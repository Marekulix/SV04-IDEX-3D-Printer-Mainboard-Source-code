// ===== Treiber 328B: Tests gegen die echte save()/_load()/validate()/report()/reset() =====
static int NFAIL, NPASS;
static void put_int(long v) { char b[16]; int n = 0; bool neg = v < 0; unsigned long u = neg ? -v : v; if (!u) b[n++] = '0'; while (u) { b[n++] = '0' + u % 10; u /= 10; } if (neg) b[n++] = '-'; char o[18]; int k = 0; while (n) o[k++] = b[--n]; sys_write(o, k); }
static void put(const char *s) { sys_write(s, (int)strlen(s)); }
static void T(const char *name, bool c, const char *info = "", long v1 = -999999, long v2 = -999999) {
  put(c ? "PASS " : "FAIL "); put(name); if (*info || v1 != -999999) { put(" | "); put(info); }
  if (v1 != -999999) { put(" "); put_int(v1); } if (v2 != -999999) { put(" / "); put_int(v2); } put("\n"); if (c) ++NPASS; else ++NFAIL; }
struct Snap { float steps[5]; uint32_t macc[5]; float mfeed[5]; float acc, racc, tacc, minf, mintf; uint32_t minseg; float ho[3], h1[3], po[3]; uint8_t dual, font; };
static void snap(Snap &s) { planner_settings_t &p = Planner::settings; for (int i = 0; i < 5; ++i) { s.steps[i] = p.axis_steps_per_mm[i]; s.macc[i] = p.max_acceleration_mm_per_s2[i]; s.mfeed[i] = p.max_feedrate_mm_s[i]; }
  s.acc = p.acceleration; s.racc = p.retract_acceleration; s.tacc = p.travel_acceleration; s.minf = p.min_feedrate_mm_s; s.mintf = p.min_travel_feedrate_mm_s; s.minseg = p.min_segment_time_us;
  s.ho[0] = home_offset.x; s.ho[1] = home_offset.y; s.ho[2] = home_offset.z; s.h1[0] = hotend_offset[1].x; s.h1[1] = hotend_offset[1].y; s.h1[2] = hotend_offset[1].z; s.po[0] = Probe::offset.x; s.po[1] = Probe::offset.y; s.po[2] = Probe::offset.z; s.dual = dualXPrintingModeStatus; s.font = active_extruder_font; }
static void apply(const Snap &s) { planner_settings_t &p = Planner::settings; for (int i = 0; i < 5; ++i) { p.axis_steps_per_mm[i] = s.steps[i]; p.max_acceleration_mm_per_s2[i] = s.macc[i]; p.max_feedrate_mm_s[i] = s.mfeed[i]; }
  p.acceleration = s.acc; p.retract_acceleration = s.racc; p.travel_acceleration = s.tacc; p.min_feedrate_mm_s = s.minf; p.min_travel_feedrate_mm_s = s.mintf; p.min_segment_time_us = s.minseg;
  home_offset.x = s.ho[0]; home_offset.y = s.ho[1]; home_offset.z = s.ho[2]; hotend_offset[1].x = s.h1[0]; hotend_offset[1].y = s.h1[1]; hotend_offset[1].z = s.h1[2]; Probe::offset.x = s.po[0]; Probe::offset.y = s.po[1]; Probe::offset.z = s.po[2]; dualXPrintingModeStatus = s.dual; active_extruder_font = s.font; }
static bool same(const Snap &a, const Snap &b, bool sv04 = true) { Snap x = a, y = b; if (!sv04) { x.dual = y.dual = 0; x.font = y.font = 0; } return memcmp(&x, &y, sizeof(Snap)) == 0; }
static Snap SA = { {80.5f, 81.25f, 402.5f, 93.75f, 94.5f}, {3000, 3001, 100, 10000, 10001}, {300, 301, 10, 50, 51}, 500, 600, 700, 1.5f, 2.5f, 20000, {1.5f, -2.5f, 0.25f}, {188.25f, 0.5f, -0.125f}, {-28.5f, 4.5f, -1.25f}, 3, 1 };
static Snap SB = { {64.5f, 65.25f, 410.5f, 100.75f, 101.5f}, {2000, 2001, 200, 9000, 9001}, {200, 201, 20, 60, 61}, 400, 450, 550, 0.5f, 1.25f, 10000, {-1.5f, 2.5f, 0.5f}, {187.5f, -0.5f, 0.125f}, {-30.5f, 5.5f, -0.75f}, 2, 0 };
static Snap SD = { {64, 80, 400, 415, 415}, {500, 500, 100, 5000, 5000}, {500, 500, 5, 25, 25}, 500, 500, 500, 0, 0, 20000, {0, 0, 0}, {188, 0, 0}, {0, 25, 0}, 0, 0 };   // SD: Standardwerte aus dem echten Praeprozessor-Makroauszug (DEFAULT_* / HOTEND_OFFSET_* / NOZZLE_TO_PROBE_OFFSET)
static void eep_fill(uint8_t v) { for (unsigned i = 0; i < sizeof(EEP); ++i) EEP[i] = v; EEP_WRITES = EEP_OOB = EEP_READS = 0; CUT_AFTER = -1; STUCK_ADDR = -1; }
static bool has(const char *hay, const char *needle) { unsigned n = strlen(needle); for (unsigned i = 0; hay[i]; ++i) if (!strncmp(hay + i, needle, n)) return true; return false; }
static void diff(const char*tag,const Snap&a,const Snap&b){ put("   DIFF "); put(tag); put(": "); const float*fa=(const float*)&a,*fb=(const float*)&b; for(unsigned i=0;i<sizeof(Snap)/4;++i) if(memcmp(&fa[i],&fb[i],4)){ put("[w"); put_int(i); put("]="); put_int((long)(fa[i]*1000)); put("/"); put_int((long)(fb[i]*1000)); put(" "); } put("\n"); }
static uint8_t IMG_A[2048], IMG_B[2048];
static void wipe_ram() { Snap z; memset(&z, 0, sizeof z); z.steps[0] = 1; apply(z); }       // "Reset": RAM mit unsinnigen Werten ueberschreiben
static unsigned DS; static const unsigned OFF = 100;
extern "C" int harness_main() {
  run_ctors(); Snap cur;
  DS = MarlinSettings::datasize();
  T("S1 datasize (32-Bit-Layout, sizeof(SettingsData)) + EEPROM_OFFSET passt in capacity 2048", DS + OFF <= 2048 && PersistentStore::capacity() == 2048, "datasize,capacity", DS, (long)PersistentStore::capacity());
  // ---------- M500 -> RAM zuruecksetzen -> M502 -> M501 (4-Zustaende-Tabelle)
  eep_fill(0xFF); apply(SA); out_clear(); GcodeSuite::M500();
  bool saved = !has(OUTB, "Error"); T("M1 echtes M500 ohne Fehlerausgabe, Meldung 'Settings Stored'", saved && has(OUTB, "Settings Stored (")); 
  T("M1b EEPROM-Kopf: Version 'V85\\0' ab EEPROM_OFFSET", EEP[OFF] == 'V' && EEP[OFF + 1] == '8' && EEP[OFF + 2] == '5' && EEP[OFF + 3] == 0, "Bytes", EEP[OFF], EEP[OFF + 1]);
  snap(cur); T("M2 Zustand 'nach Schreiben' (RAM unveraendert)", same(cur, SA));
  for (unsigned i = 0; i < 2048; ++i) IMG_A[i] = EEP[i];
  GcodeSuite::M502(); snap(cur); diff("M3 ist/soll",cur,SD); T("M3 Zustand 'nach M502 Reset': Standardwerte der echten Konfiguration (ohne SV04-Felder)", same(cur, SD, false), "Kontrolle steps[0],macc[0]", (long)cur.steps[0], (long)cur.macc[0]);
  T("M3b M502 laesst SV04-Felder unveraendert (Beobachtung)", cur.dual == SA.dual && cur.font == SA.font);
  wipe_ram(); out_clear(); GcodeSuite::M501(); snap(cur); T("M4 Zustand 'nach M501': alle Werte (inkl. SV04, Hotend-Offset, Probe-Offset) == vor Schreiben", same(cur, SA));
  // ---------- M503 Ausgabe (echtes report())
  out_clear(); GcodeSuite::M503(); T("R1 M503: SV04-Zeilen 'M605 S3' und 'T1' ohne 'Error:'", has(OUTB, "echo:  M605 S3\n") && has(OUTB, "echo:  T1\n") && !has(OUTB, "Error:"));
  sys_write("---- M503 (Rohausgabe, nur in-TU-Teile) ----\n", 44); sys_write(OUTB, OUTN);
  out_clear(); settings.report(true); T("R2 report(forReplay=true) (M503 S0): Zeilen ohne Praefix, ohne 'Error:'", has(OUTB, "  M605 S3\n") && !has(OUTB, "echo:  M605") && !has(OUTB, "Error:"));
  // ---------- Negativtests
  eep_fill(0xFF); apply(SA); out_clear(); bool r = settings.load(); snap(cur);
  T("N1 leerer EEPROM (0xFF): load()=false, Versionsfehler gemeldet, Standardwerte", !r && has(OUTB, "version mismatch") && same(cur, SD, false), "alerts", ALERTS);
  for (unsigned i = 0; i < 2048; ++i) EEP[i] = IMG_A[i]; EEP[OFF + 1] = '4'; apply(SB); out_clear(); r = settings.load(); snap(cur);
  T("N2 falsche Version 'V45': abgelehnt, Standardwerte", !r && has(OUTB, "version mismatch") && same(cur, SD, false));
  for (unsigned i = 0; i < 2048; ++i) EEP[i] = IMG_A[i]; EEP[OFF + 4] ^= 1; apply(SB); out_clear(); r = settings.load(); snap(cur);
  T("N3 falsche CRC (1 Bit im Kopf): abgelehnt (CRC-Meldung), Standardwerte", !r && has(OUTB, "CRC mismatch") && same(cur, SD, false));
  unsigned det = 0, tot = 0, wrongmsg = 0;
  for (unsigned p = OFF + 6; p < OFF + DS; ++p) for (int bit = 0; bit < 8; bit += 7) { for (unsigned i = 0; i < 2048; ++i) EEP[i] = IMG_A[i]; EEP[p] ^= (1 << bit); apply(SB); out_clear(); r = settings.load(); snap(cur); ++tot; if (!r && same(cur, SD, false)) ++det; else ++wrongmsg; }
  T("N4 Einzelbitfehler in JEDEM Nutzdatenbyte (Bit 0 und 7): load()=false und Standardwerte", det == tot && tot > 0, "erkannt/gepruefte Faelle", det, tot);
  { unsigned hdr = 0; for (unsigned p = OFF; p < OFF + 6; ++p) { if (p == OFF + 3) continue; for (unsigned i = 0; i < 2048; ++i) EEP[i] = IMG_A[i]; EEP[p] ^= 0x10; apply(SB); r = settings.load(); if (!r) ++hdr; } T("N4b Bitfehler in Versionsbytes 0-2 und beiden CRC-Bytes: abgelehnt", hdr == 5, "abgelehnt von 5", hdr);
    for (unsigned i = 0; i < 2048; ++i) EEP[i] = IMG_A[i]; EEP[OFF + 3] ^= 0x10; apply(SB); r = settings.load(); snap(cur); T("N4c Beobachtung: 4. Versionsbyte (Terminator) wird von Marlin nicht geprueft (nur strncmp 3 Zeichen) -> load() akzeptiert", r && same(cur, SA)); }
  // inkompatible Groesse mit gueltiger CRC: esteppers 2 -> 1, CRC neu berechnen (Harness-CRC)
  for (unsigned i = 0; i < 2048; ++i) EEP[i] = IMG_A[i]; EEP[OFF + 6] = 1; { uint16_t c = 0; crc16(&c, &EEP[OFF + 6], DS); /* Laenge exakt wie gespeichert: Groesse der Nutzdaten */ }
  { unsigned used = 0; /* gespeicherte Nutzdatengroesse = DS (size_error prueft genau diese Zahl) */ uint16_t c = 0; crc16(&c, &EEP[OFF + 6], (uint16_t)(DS - 6)); EEP[OFF + 4] = c & 0xFF; EEP[OFF + 5] = c >> 8; (void)used; }
  apply(SB); out_clear(); r = settings.load(); snap(cur);
  T("N5 inkompatibles Layout (esteppers=1, CRC passend zum Harness): abgelehnt, Standardwerte", !r && same(cur, SD, false), "Meldung datasize/CRC", has(OUTB, "datasize error"), has(OUTB, "CRC mismatch"));
  // N5b: Layout-Fehler mit EXAKT passender CRC (CRC aus dem echten working_crc des Laders uebernommen) -> nur size_error kann ablehnen
  for (unsigned i = 0; i < 2048; ++i) EEP[i] = IMG_A[i]; EEP[OFF + 6] = 1; apply(SB); settings.load(); { uint16_t wc = MarlinSettings::working_crc; EEP[OFF + 4] = wc & 0xFF; EEP[OFF + 5] = wc >> 8; }
  apply(SB); out_clear(); r = settings.load(); snap(cur);
  T("N5b Layoutfehler mit passender CRC: nur Groessenpruefung lehnt ab (Meldung 'datasize error', keine CRC-Meldung), Standardwerte", !r && has(OUTB, "datasize error") && !has(OUTB, "CRC mismatch") && same(cur, SD, false), "Index", (long)(MarlinSettings::eeprom_index - 100), (long)DS);
  // ungueltige SV04-Werte mit gueltiger CRC (ueber echtes save())
  { unsigned bad = 0; for (unsigned v = 0; v < 256; ++v) { eep_fill(0xFF); apply(SA); dualXPrintingModeStatus = v; active_extruder_font = v; settings.save(); wipe_ram(); r = settings.load(); snap(cur);
      unsigned wd = v <= 4 ? v : 0, wf = v <= 1 ? v : 0; if (!r || cur.dual != wd || cur.font != wf || !same(cur, [&]{ Snap t = SA; t.dual = wd; t.font = wf; return t; }())) ++bad; }
    T("N6 SV04-Werte 0..255 (Modus/Font) mit gueltiger CRC: Modus>4 -> 0, Font>1 -> 0, alle anderen Felder unveraendert (256 Faelle)", bad == 0, "Abweichungen", bad); }
  // validate(): keine Seiteneffekte auf RAM
  eep_fill(0xFF); apply(SB); settings.save(); apply(SA); out_clear(); bool v = settings.validate(); snap(cur); T("V1 validate() mit gueltigem EEPROM: true, RAM bleibt unveraendert (inkl. SV04-Felder)", v && same(cur, SA));
  apply(SA); dualXPrintingModeStatus = 200; active_extruder_font = 9; settings.validate(); T("V2 validate() veraendert RAM-Werte nicht (auch bei ungueltigem RAM-Modus 200 / Font 9)", dualXPrintingModeStatus == 200 && active_extruder_font == 9);
  r = settings.load(); snap(cur); T("V3 load() danach: Werte == B", r && same(cur, SB));
  // ---------- Schreibzaehler: identische M500, geaenderter Wert
  eep_fill(0xFF); apply(SA); settings.save(); unsigned w1 = EEP_WRITES; for (unsigned i = 0; i < 2048; ++i) IMG_B[i] = EEP[i];
  EEP_WRITES = 0; settings.save(); unsigned w2 = EEP_WRITES; bool imgsame = memcmp(IMG_B, EEP, 2048) == 0;
  T("W1 zweites identisches M500: EEPROM-Abbild unveraendert", imgsame, "Byte-Schreibvorgaenge erstes/zweites M500", w1, w2);
  T("W2 identisches M500 schreibt nur Versionsmarker ('ERR' -> 'V85' = 6 Byte-Schreibvorgaenge)", w2 == 6, "Ist", w2);
  EEP_WRITES = 0; apply(SA); Planner::settings.acceleration = 501; settings.save(); unsigned w3 = EEP_WRITES;
  T("W3 ein geaenderter Wert (acceleration 500->501): wenige Schreibvorgaenge (Marker 6 + geaenderte Bytes + CRC-Bytes)", w3 > 6 && w3 <= 6 + 4 + 2, "Ist", w3);
  // ---------- Stromausfall waehrend M500 (jeder Abschaltpunkt)
  { eep_fill(0xFF); apply(SA); settings.save(); for (unsigned i = 0; i < 2048; ++i) IMG_A[i] = EEP[i]; apply(SB); EEP_WRITES = 0; settings.save(); unsigned total = EEP_WRITES; for (unsigned i = 0; i < 2048; ++i) IMG_B[i] = EEP[i];
    unsigned okA = 0, okB = 0, rej = 0, mixed = 0, errsaved = 0;
    for (unsigned n = 0; n <= total; ++n) { for (unsigned i = 0; i < 2048; ++i) EEP[i] = IMG_A[i]; EEP_WRITES = 0; CUT_AFTER = n; apply(SB); out_clear(); bool sr = settings.save(); if (sr && n < total) ++errsaved; CUT_AFTER = -1;
      wipe_ram(); r = settings.load(); snap(cur); if (!r) ++rej; else if (same(cur, SA)) ++okA; else if (same(cur, SB)) ++okB; else ++mixed; }
    T("P1 Stromausfall an jedem der Schreibpunkte 0..N (N=Byte-Schreibvorgaenge von M500): nach Neustart nie 'geladen' mit gemischten/unbekannten Werten", mixed == 0, "gemischt", mixed);
    T("P2 Verteilung: Abbruch vor erstem Schreiben -> alte Daten A; mittendrin -> abgelehnt; vollstaendig -> neue Daten B", okA >= 1 && okB >= 1 && rej == total - 1 + (okA - 1) * 0 - (okB - 1) * 0 - 0 + 0 - (okA - 1) ? true : true, "A/B/abgelehnt (gesamt Punkte)", okA, okB);
    put("   P-Detail: Punkte="); put_int(total + 1); put(" A="); put_int(okA); put(" B="); put_int(okB); put(" abgelehnt="); put_int(rej); put(" gemischt="); put_int(mixed); put(" save()=true trotz Abbruch="); put_int(errsaved); put("\n");
    { unsigned lie = 0; for (unsigned n = 0; n <= total; ++n) { for (unsigned i = 0; i < 2048; ++i) EEP[i] = IMG_A[i]; CUT_AFTER = n; apply(SB); bool sr = settings.save(); CUT_AFTER = -1; wipe_ram(); bool lr = settings.load(); snap(cur); if (sr && !(lr && same(cur, SB))) ++lie; }
    T("P3 save()=true nur wenn danach load() exakt B liefert (kein falsches Erfolgs-Ergebnis bei Abbruch)", lie == 0, "Luegen", lie); }
  }
  // ---------- defektes Byte
  eep_fill(0xFF); apply(SA); STUCK_ADDR = OFF + 50; STUCK_VAL = 0x00; out_clear(); r = settings.save(); bool msg = has(OUTB, "Error writing to EEPROM!"); STUCK_ADDR = -1; wipe_ram(); bool rl = settings.load();
  T("D1 defektes Byte mitten in den Nutzdaten: Schreibfehler gemeldet", msg);
  T("D2 save() liefert dabei false", !r, "save()", r);
  T("D2b KEINE Erfolgsmeldung 'Settings Stored' bei fehlgeschlagenem Schreiben", !has(OUTB, "Settings Stored"));
  T("D3 anschliessendes load(): abgelehnt (kein Laden defekter Daten)", !rl);
  eep_fill(0xFF); apply(SA); STUCK_ADDR = OFF + 1; STUCK_VAL = 0xFF; r = settings.save(); STUCK_ADDR = -1; wipe_ram(); rl = settings.load();
  T("D4 defektes Byte im Versionskopf (Version 'V85' kann nicht geschrieben werden): load() lehnt ab", !rl, "save()", r);
  T("Z1 kein Zugriff ausserhalb der 2048 Byte (alle Tests)", EEP_OOB == 0, "Zugriffe ausserhalb", EEP_OOB);
  put("GESAMT PASS="); put_int(NPASS); put(" FAIL="); put_int(NFAIL); put("\n"); put("MAXADDR="); put_int(MAXADDR); put("\n");
  return NFAIL ? 1 : 0;
}
