#!/usr/bin/env python3
"""Aequivalenzpruefung: echtes libs/crc16.cpp (Praeprozessor-Auszug) gegen das im Harness nachgebaute crc16 (CRC-CCITT 0x1021).
Aufruf: check_crc16.py <crc16.cpp.i> <arbeitsverzeichnis>"""
import os, re, subprocess, sys
src, w = sys.argv[1], sys.argv[2]; os.makedirs(w, exist_ok=True)
text = open(src, errors='replace').read()
assert re.search(r'\bcrc16\s*\(', text), 'keine crc16-Funktion im Auszug'
open(os.path.join(w, 'real_crc16.cpp'), 'w').write(text)
open(os.path.join(w, 'cmp.cpp'), 'w').write(r'''
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
void crc16(uint16_t *crc, const void *const data, uint16_t cnt);
static void model_crc16(uint16_t *crc, const void *const data, uint16_t cnt) {
  const uint8_t *ptr = (const uint8_t *)data;
  while (cnt--) { *crc = (uint16_t)(*crc ^ (uint16_t)(((uint16_t)*ptr++) << 8)); for (uint8_t i = 0; i < 8; i++) *crc = (uint16_t)((*crc & 0x8000) ? ((uint16_t)(*crc << 1) ^ 0x1021) : (*crc << 1)); }
}
int main() { srand(12345); unsigned bad = 0, n = 0; static uint8_t buf[2100];
  for (int t = 0; t < 4000; ++t) { unsigned len = t < 2100 ? t : rand() % 2100; for (unsigned i = 0; i < len; ++i) buf[i] = rand(); uint16_t s = (t % 3 == 0) ? 0 : (uint16_t)rand();
    uint16_t a = s, b = s; crc16(&a, buf, len); model_crc16(&b, buf, len); ++n; if (a != b) ++bad;
    // inkrementell (Marlin ruft crc16 stueckweise auf)
    uint16_t c = s, d = s; unsigned h = len / 2; crc16(&c, buf, h); crc16(&c, buf + h, len - h); model_crc16(&d, buf, len); ++n; if (c != d) ++bad; }
  printf("CRC16_EQUIV faelle=%u abweichungen=%u\n", n, bad); return bad ? 1 : 0; }
''')
r = subprocess.run(['g++', '-fpermissive', '-w', '-O0', '-o', os.path.join(w, 'cmp'), os.path.join(w, 'cmp.cpp'), os.path.join(w, 'real_crc16.cpp')], capture_output=True, text=True)
if r.returncode: print(r.stderr[:3000]); print('CRC16_EQUIV BUILD_FEHLER'); sys.exit(2)
p = subprocess.run([os.path.join(w, 'cmp')], capture_output=True, text=True); print(p.stdout.strip()); sys.exit(p.returncode)
