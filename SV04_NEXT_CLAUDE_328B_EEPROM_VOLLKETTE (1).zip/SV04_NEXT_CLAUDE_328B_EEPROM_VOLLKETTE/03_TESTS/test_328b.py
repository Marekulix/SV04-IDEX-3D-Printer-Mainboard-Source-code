#!/usr/bin/env python3
"""SV04C328B Voll-Ketten-Test: echte settings.cpp.i (328A-Export) + echtes bl24cxx-PersistentStore + echte M500-M503, 32-Bit nativ.
Aufruf: test_328b.py <pre-Verzeichnis> <Ausgabeverzeichnis>"""
import os, re, sys, shutil, subprocess
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fullchain
H = os.path.dirname(os.path.abspath(__file__)); PRE = sys.argv[1]; OUT = sys.argv[2]; REAL = len(sys.argv) > 3 and sys.argv[3] == '--real328b'; os.makedirs(OUT, exist_ok=True)
SET = 'Marlin_src_module_settings.cpp.i'; BL = 'Marlin_src_HAL_STM32_eeprom_bl24cxx.cpp.i'; MM = 'Marlin_src_gcode_eeprom_M500_M504.cpp.i'
base = open(os.path.join(PRE, SET), errors='replace').read()
def patch328b(t):
    m = re.search(r'(      do\{ serial_echo_start\(\); do\{ serial_echopair_PGM\(\("Settings Stored \("\).*?\}while\(0\); \}while\(0\);)\n\n\n?(      eeprom_error \|= size_error\(eeprom_size\);)', t, re.S)
    assert m, '328B-Muster nicht gefunden'
    return t[:m.start()] + m.group(2) + '\n      if (!eeprom_error) ' + m.group(1).lstrip() + t[m.end():]
def mut(t, a, b):
    assert t.count(a) >= 1, 'Mutationsmuster fehlt: ' + a; return t.replace(a, b, 1)
def unpatch328b(t):
    m = re.search(r'(      eeprom_error \|= size_error\(eeprom_size\);)\n      if \(!eeprom_error\) (do\{ serial_echo_start\(\); do\{ serial_echopair_PGM\(\("Settings Stored \(".*?\}while\(0\); \}while\(0\);)', t, re.S)
    assert m, 'unpatch: Muster nicht gefunden'
    return t[:m.start()] + '      ' + m.group(2) + '\n\n' + m.group(1) + t[m.end():]
if REAL:   # Workflow-Modus: der echte .i stammt aus dem bereits mit 328B gepatchten Baum; Vorher-Variante = Rueckwandlung
    real = base; base = unpatch328b(real); assert patch328b(base) == real, 'Rundlauf unpatch/patch ungleich echter .i'
variants = [('A_328A_vor_Patch', base), ('B_328B_nach_Patch', patch328b(base))]
mutants = [('MUT1_CRC_Pruefung_entfernt', 'working_crc != stored_crc', '0'),
           ('MUT2_Groessenpruefung_in_load_entfernt', 'eeprom_error = size_error(eeprom_index - (100));', 'eeprom_error = false;'),
           ('MUT3_SV04_Modus_Clamp_entfernt', '(sv04_dual_mode <= 4) ? sv04_dual_mode : 0', 'sv04_dual_mode'),
           ('MUT4_SV04_Font_Clamp_entfernt', '(sv04_tool_font <= 1) ? sv04_tool_font : 0', 'sv04_tool_font'),
           ('MUT5_Versionspruefung_entfernt', 'strncmp(version, stored_ver, 3) != 0', 'false'),
           ('MUT6_Erfolgsmeldung_wieder_vor_size_error', None, None)]
def run(name, text):
    d = os.path.join(OUT, name); os.makedirs(d, exist_ok=True)
    for f in (BL, MM): shutil.copy(os.path.join(PRE, f), d)
    open(os.path.join(d, SET), 'w').write(text)
    exe = os.path.join(d, 'run'); r = fullchain.build(os.path.join(d, SET), os.path.join(d, BL), os.path.join(d, MM), os.path.join(H, 'drv.inc'), exe)
    if r.returncode: open(os.path.join(d, 'build_error.txt'), 'w').write(r.stderr); return None
    p = subprocess.run([exe], capture_output=True, text=True, errors='replace'); open(os.path.join(d, 'raw.txt'), 'w').write(p.stdout)
    res = {}
    for l in p.stdout.splitlines():
        m = re.match(r'(PASS|FAIL) (\S+)', l)
        if m: res[m.group(2)] = m.group(1)
    return res
sumry = []
for n, t in variants:
    r = run(n, t); sumry.append((n, r)); print(n, 'PASS=%d FAIL=%d' % (sum(v == 'PASS' for v in r.values()), sum(v == 'FAIL' for v in r.values())), [k for k, v in r.items() if v == 'FAIL'])
after = variants[1][1]; killed = 0
for n, a, b in mutants:
    t = patch328b(base) if a is None else mut(after, a, b)
    if a is None: t = base          # MUT6: Zustand vor dem 328B-Patch
    r = run(n, t); f = [k for k, v in (r or {}).items() if v == 'FAIL'] if r else ['BUILD']
    # MUT6 gilt als 'getoetet', wenn D2b faellt; die anderen, wenn irgendein Test faellt
    if f: killed += 1
    print(n, 'getoetet' if f else 'ueberlebt', f)
print('MUTANTEN getoetet %d von %d' % (killed, len(mutants)))
a, b = sumry[0][1], sumry[1][1]
ok = all(v == 'PASS' for v in b.values()) and a.get('D2b') == 'FAIL' and all(v == 'PASS' for k, v in a.items() if k != 'D2b')
print('ERGEBNIS', 'OK' if ok and killed == len(mutants) else 'NICHT OK'); sys.exit(0 if ok and killed == len(mutants) else 1)
