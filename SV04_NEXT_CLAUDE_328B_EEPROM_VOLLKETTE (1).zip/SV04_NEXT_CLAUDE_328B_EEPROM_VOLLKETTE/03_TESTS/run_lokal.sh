#!/bin/sh
# Lokaler Lauf (Linux, g++ mit -m32-Unterstuetzung): python3 -I test_328b.py eingang_pre_328a ausgabe
cd "$(dirname "$0")" && python3 -I test_328b.py eingang_pre_328a ../04_ROHLOGS/lauf
