SV04 NEXT 295 – GITHUB BUILD RETRY, SINGLE JOB, NO FLASH

This is a workflow packaging revision, NOT a new firmware code revision.
The workflow uses these files already in the repository root:
  SV04_NEXT_287.zip
  SV04_NEXT_289.zip
  SV04_NEXT_291.zip
  SV04_NEXT_294.zip

Firmware changes: exactly those of 294 (base 291 + EEPROM patches 292/293/294).
Change vs 294: one runner job instead of matrix, with backend and failclosed
built sequentially, and failure evidence retained. This avoids the GitHub Actions
matrix scheduler path that showed a generic 'Startup failure' in run 4309651970.
It does NOT prove the generic GitHub startup issue is fixed.

DO NOT FLASH. DO NOT USE THIS AS INSTALLABLE FIRMWARE.
Successful host checks/compilation must be verified in run logs.
