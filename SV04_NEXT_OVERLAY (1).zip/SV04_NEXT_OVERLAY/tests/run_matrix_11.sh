#!/usr/bin/env bash
# Alle C++-Tests unter Bedingungen, die run_all_local.sh nicht abdeckt (GCC). Exit 1 bei jedem Fehler.
cd "$(dirname "$0")/.."
rc=0
run() { flags="$1"; label="$2"; ok=0; bad=""
  for f in tests/test_*.cpp; do n=$(basename "$f" .cpp)
    if g++ -std=c++11 $flags "$f" -o "/tmp/mx11_$n" 2>/dev/null && timeout 120 "/tmp/mx11_$n" >/dev/null 2>&1; then ok=$((ok+1)); else bad="$bad $n"; fi
  done
  echo "[$label] bestanden $ok, Fehler:${bad:- keine}"; [ -z "$bad" ] || rc=1; }
run "-std=gnu++14 -Os -fno-exceptions -fno-rtti -fsingle-precision-constant" "Marlin-nah gnu++14 -Os"
run "-std=c++17 -O2" "C++17 -O2"
run "-O1 -g -fsanitize=address,undefined -fno-sanitize-recover=all" "GCC ASan+UBSan"
echo "HINWEIS: -ffast-math wird bewusst NUR für die NATIVEN Header geprüft (tests/test_fastmath_native_guard.cpp). Die Host-Modelle (Auto60Safety, MeshJournal, Orchestrator, ...) verwenden isfinite() und sind NICHT fast-math-sicher; sie werden nicht in Marlin eingebaut."
exit $rc
