#include "../include/SV04NextFaultTrace.hpp"
#include <cassert>
#include <cstdio>
using namespace sv04next;
static unsigned checks=0;
#define CHECK(X) do{++checks;assert(X);}while(0)
int main(){
  for(uint32_t k=1;k<=1800;++k){
    FaultTrace trace;FaultTrace::Row row;
    CHECK(!trace.record(k,0,FaultTrace::Event::Start,0,0));
    CHECK(!trace.begin(0,0));CHECK(trace.begin(k,0xFFFFFFF0u));
    CHECK(trace.size()==1);CHECK(!trace.begin(k,0));
    CHECK(!trace.record(k+1,0,FaultTrace::Event::Cancel,0,0));
    CHECK(!trace.record(k,0,FaultTrace::Event::ProbePoint,16,0));
    for(uint32_t j=1;j<=100;++j)
      CHECK(trace.record(k,(uint32_t)(0xFFFFFFF0u+j*100),FaultTrace::Event::ProbePoint,(uint8_t)(j%16u),(uint16_t)j));
    CHECK(trace.size()==32);
    for(uint8_t i=0;i<32;++i){
      CHECK(trace.latest(i,row));CHECK(row.run==k);
      CHECK(row.code==100u-i);CHECK(row.point==((100u-i)%16u));
    }
    CHECK(!trace.latest(32,row));
    CHECK(!trace.eeprom_writes());CHECK(!trace.heater_commands());
    CHECK(trace.begin(k+1,25000)); // a fresh run always resets its chronology
    CHECK(trace.size()==1);CHECK(trace.latest(0,row));CHECK(row.run==k+1);
    CHECK(!trace.record(k,25001,FaultTrace::Event::Cancel,0,0));
  }
  std::printf("FAULT TRACE HOST PASS checks=%u; RAM_ONLY no EEPROM\n",checks);
}
