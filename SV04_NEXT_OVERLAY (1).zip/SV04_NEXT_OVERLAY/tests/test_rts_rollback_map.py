#!/usr/bin/env python3
"""Validate existing RTS 4x4 serpentine mesh address ordering and rollback telemetry."""
from pathlib import Path
s=(Path(__file__).resolve().parents[1]/'integration/apply_native_guard_v2.py').read_text()
assert 'AUTO_BED_LEVEL_1POINT_VP + (index++) * 2' in s
assert 'zig = false' in s
pairs=[]
zig=False
for y in range(4):
    for x in (range(4) if zig else range(3,-1,-1)):
        pairs.append((x,y))
    zig=not zig
assert len(pairs)==16 and len(set(pairs))==16
assert pairs[0]==(3,0) and pairs[-1]==(3,3)
addresses=[0x1100 + 2*i for i in range(16)]
assert addresses[0]==0x1100 and addresses[-1]==0x111E
assert len(set(addresses))==16
print('SV04 NEXT original RTS mesh-field order PASS 16 distinct coordinates and 16 original VP addresses')
