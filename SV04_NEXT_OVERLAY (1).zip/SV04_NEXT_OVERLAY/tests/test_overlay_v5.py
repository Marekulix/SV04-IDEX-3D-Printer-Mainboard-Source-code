#!/usr/bin/env python3
"""Verify native G29 U guard is strictly opt-in and OEM paths are untouched."""
from pathlib import Path
import sys, tempfile
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'integration'))
import apply_native_guard_v5 as v5

cf='// one other value\n//#define MULTIPLE_PROBING 2\n'
probe='''Probe probe;
#elif TOTAL_PROBING == 2
    const float z2 = current_position.z;

    if (DEBUGGING(LEVELING))'''
g='''#include "../../../module/probe.h"
#define G29_RETURN(b) return TERN_(G29_RETRY_AND_RECOVER, b)
G29_TYPE GcodeSuite::G29() {
  reset_stepper_timeout();
  for (int i=0; i<16; i++) {
          abl.measured_z = faux ? 0.001f * random(-100, 101) : probe.probe_at_point(abl.probePos, raise_after, abl.verbose_level);
            const float z = abl.measured_z + abl.Z_offset;
            z_values[abl.meshCount.x][abl.meshCount.y] = z;
            TERN_(EXTENSIBLE_UI, ExtUI::onMeshUpdate(abl.meshCount, z));
  }
  #if ENABLED(RTS_AVAILABLE)
    RTS_AutoBedLevelPage();
  #endif
  report_current_position();

  TERN_(FULL_REPORT_TO_HOST_FEATURE, set_and_report_grblstate(M_IDLE));

  G29_RETURN(isnan(abl.measured_z));
}'''
rt='''#include "../../../module/probe.h"
#if ENABLED(RTS_AVAILABLE)

#define CHECKFILEMENT true
void RTSUpdate()
{
  EachMomentUpdate();
}'''
source={'Marlin/Configuration.h':cf,
'Marlin/src/module/probe.cpp':probe,
'Marlin/src/gcode/bedlevel/abl/G29.cpp':g,
'Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp':rt}
header=(root/'include/SV04NextNativeThermalGate.hpp').read_text()
changed=v5.render(source,header)
checks=0
def ck(value,msg):
 global checks
 assert value,msg
 checks+=1
ck(changed['Marlin/Configuration.h']==cf,'global probe config mutated')
ck(changed['Marlin/src/module/probe.cpp']==probe,'OEM probe mutated')
G=changed['Marlin/src/gcode/bedlevel/abl/G29.cpp']
R=changed['Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp']
ck('G29U REFUSED: bed not stable for 20s' in G,'stable entry guard')
ck('native_thermal_gate.ready' in G,'native observation used')
ck('const float first_z = probe.probe_at_point(' in G,'first actual probe')
ck('const float second_z = probe.probe_at_point(' in G,'second actual probe')
ck('const float first_z =' in G and 'PROBE_PT_RAISE' in G,'first pass raises')
ck('sv04_transactional_run && !faux' in G,'opt-in only')
ck('ABS(first_z - second_z) > 0.06f' in G,'discrepancy check')
ck('ABS(z) > 3.0f' in G,'out-of-range check')
ck('G29U REFUSED: modifiers not allowed' in G,'G29 modifiers refused')
for letter in v5.FORBIDDEN_G29_MODIFIERS:
 ck(f"parser.seen_test('{letter}')" in G,'unsafe modifier '+letter)
ck('RTSUpdate()' in R and 'native_thermal_gate.observe(' in R,'native RTS hook')
ck(R.count('native_thermal_gate.observe(')==1,'duplicate native tracker')
ck('settings.save()' not in G,'eeprom write inserted')
ck('setTargetBed(' not in G,'heater command inserted')
ck('queue.enqueue' not in G,'G29 movement queued')
ck('M500' not in G,'M500 inserted')
ck(G.count('SV04 NEXT G29U PROGRESS')==1,'progress retained')
ck('if (!sv04_transactional_run || !isnan(abl.measured_z))' in G,'false DWIN success')
ck('probe.offset.z = old_probe_offset' in G,'rollback offset')
ck('SV04 NEXT: original RAM mesh restored' in G,'rollback mesh')
ck(changed[v5.PATCH_TARGET]==header,'native header emitted')
try:v5.render(changed,header)
except v5.PatchRefused:ck(True,'double apply rejected')
else:raise AssertionError('double patch allowed')
with tempfile.TemporaryDirectory() as temp:
 p=Path(temp)
 for file,content in source.items():
  f=p/file;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(content)
 original_sha=dict(v5.OEM_BLOBS)
 try:
  v5.OEM_BLOBS.clear()
  for file in source:v5.OEM_BLOBS[file]=v5.git_blob_sha((p/file).read_bytes())
  v5.apply(p,root/'include/SV04NextNativeThermalGate.hpp',p/'evidence.json')
  ck((p/'evidence.json').exists(),'evidence generated')
  for file,data in changed.items():ck((p/file).read_text()==data,'emitted '+file)
  original={(p/file):(p/file).read_bytes() for file in source}
  try:v5.apply(p,root/'include/SV04NextNativeThermalGate.hpp')
  except v5.PatchRefused:ck(True,'repeat refused')
  else:raise AssertionError('repeat accepted')
  for file,bytes_content in original.items():ck(file.read_bytes()==bytes_content,'no accidental modifications')
 finally:
  v5.OEM_BLOBS.clear();v5.OEM_BLOBS.update(original_sha)
print('SV04 NEXT native v5 fixture PASS checks=',checks)
