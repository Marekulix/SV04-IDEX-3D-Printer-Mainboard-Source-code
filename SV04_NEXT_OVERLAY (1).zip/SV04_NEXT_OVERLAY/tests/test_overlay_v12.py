from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(root/'integration'),str(root/'tests')]
import apply_native_guard_v12 as v12
import test_overlay_v8 as base
src=dict(base.src)
files=['SV04NextNativeThermalGate.hpp','SV04NextVisitProof.hpp',
 'SV04NextG29UReceipt.hpp','SV04NextNativeReadiness.hpp',
 'SV04NextT1EndstopObserver.hpp','SV04NextNativeEventTimeline.hpp',
 'SV04NextNativeStatusPacket.hpp','SV04NextMeshMapPacket.hpp']
a=[(root/'include'/x).read_text() for x in files]
out=v12.render(src,*a)
rt=out[v12.RTS]
assert rt.count('mesh_map_packet.capture(')==1
assert rt.count('native_status_packet.capture(')==1
assert rt.count('native_event_timeline.observe(')==1
assert rt.count('MeshMapPacket mesh_map_packet;')==1
assert out[v12.TARGET]==a[-1]
for x in ('Marlin/Configuration.h','Marlin/src/module/probe.cpp'):
 assert out[x]==src[x]
for needle,wrong in [('bool allows_eeprom()const{return false;}','bool allows_eeprom()const{return true;}'),
 ('bool allows_motion()const{return false;}','bool allows_motion()const{return true;}'),
 ('found==16 && r.point_mask()==0xFFFFu','found<16'),
 ('// SV04 NEXT 7: 4x4 probe value snapshot','// unknown')]:
 try:v12.render(src,*a[:-1],a[-1].replace(needle,wrong))
 except v12.PatchRefused:pass
 else:raise AssertionError('unsafe native map header not rejected')
try:v12.render(out,*a)
except v12.PatchRefused:pass
else:raise AssertionError('double native map hook accepted')
print('PASS v12 mesh telemetry overlay guarded, no motion/EEPROM/HMI')
