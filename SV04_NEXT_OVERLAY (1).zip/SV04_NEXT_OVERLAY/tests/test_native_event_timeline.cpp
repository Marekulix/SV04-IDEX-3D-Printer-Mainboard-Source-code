#include "../include/SV04NextNativeEventTimeline.hpp"
#include <cassert>
#include <cstdio>
#include <stdint.h>
using namespace sv04next;
static uint32_t checks=0;
#define CHECK(x) do{++checks;assert(x);}while(0)
static NativeReadiness::View valid(uint32_t id,uint8_t n,uint16_t mask,G29UReceipt::Phase phase){
  NativeReadiness::View v;
  v.observed=true;v.g29_run_id=id;v.measured=n;v.valid_mask=mask;
  v.receipt_phase=phase;v.ram_mesh_16_of_16=(phase==G29UReceipt::Phase::RamOnlySuccess && n==16 && mask==0xFFFF);
  return v;
}
int main(){
  typedef NativeEventTimeline T;
  T t; T1EndstopObserver e;
  CHECK(!t.allows_motion());CHECK(!t.allows_heating());CHECK(!t.allows_eeprom());
  CHECK(t.view().quality==T::Quality::Never);
  t.observe(0,valid(0,0,0,G29UReceipt::Phase::Never),e);
  CHECK(t.view().quality==T::Quality::Fresh);
  t.observe(100,valid(1,0,0,G29UReceipt::Phase::Running),e);
  CHECK(t.view().event==T::Event::NewRun);
  for(unsigned i=0;i<16;i++){
    e.observe(200+i*100,true,i>2); // can observe electrical signal without any physical claim
    const uint16_t mask=(uint16_t)((1u<<(i+1))-1u);
    t.observe(200+i*100,valid(1,(uint8_t)(i+1),mask,G29UReceipt::Phase::Running),e);
    CHECK(t.view().quality==T::Quality::Fresh);
    CHECK(t.view().event==T::Event::PointAdvanced);
    CHECK(t.view().count==i+1);
    CHECK(!t.view().receipt_16_ram);
    CHECK(!t.view().physical_t1_proven);
  }
  t.observe(2000,valid(1,16,0xFFFF,G29UReceipt::Phase::RamOnlySuccess),e);
  CHECK(t.view().event==T::Event::RamOnlyComplete);
  CHECK(t.view().receipt_16_ram);
  CHECK(!t.view().hardware_approved);
  t.observe(2100,valid(1,16,0xFFFF,G29UReceipt::Phase::RamOnlySuccess),e);
  CHECK(t.view().event==T::Event::None);
  // Simulate G29 receipt reinitialization (e.g., firmware restart).
  {
    T reset;
    reset.observe(1000,valid(1,16,0xFFFF,G29UReceipt::Phase::RamOnlySuccess),e);
    CHECK(reset.view().receipt_16_ram);
    reset.observe(1100,valid(0,0,0,G29UReceipt::Phase::Never),e);
    CHECK(reset.view().quality==T::Quality::SourceMissing);
    CHECK(!reset.view().receipt_16_ram);
    reset.observe(1200,valid(1,0,0,G29UReceipt::Phase::Running),e);
    CHECK(reset.view().quality==T::Quality::SourceMissing);
    reset.observe(1300,valid(2,0,0,G29UReceipt::Phase::Running),e);
    CHECK(reset.view().quality==T::Quality::Fresh);
  }
  t.observe(2200,valid(1,16,0xFFFF,G29UReceipt::Phase::Running),e);
  CHECK(t.view().quality==T::Quality::CorruptReceipt);
  CHECK(!t.view().receipt_16_ram);
  t.observe(2300,valid(1,16,0xFFFF,G29UReceipt::Phase::RamOnlySuccess),e);
  CHECK(t.view().quality==T::Quality::CorruptReceipt); // same run cannot self heal
  t.observe(2400,valid(2,0,0,G29UReceipt::Phase::Running),e);
  CHECK(t.view().quality==T::Quality::Fresh);
  CHECK(t.view().event==T::Event::NewRun);
  t.observe(3000,valid(2,3,0x0007,G29UReceipt::Phase::Running),e);
  CHECK(t.view().event==T::Event::PointAdvanced);
  t.observe(3100,valid(2,3,0x0003,G29UReceipt::Phase::Running),e);
  CHECK(t.view().quality==T::Quality::CorruptReceipt);
  t.observe(3200,valid(2,3,0x0007,G29UReceipt::Phase::Running),e);
  CHECK(t.view().quality==T::Quality::CorruptReceipt);
  t.observe(3500,valid(3,0,0,G29UReceipt::Phase::Running),e);
  CHECK(t.view().quality==T::Quality::Fresh);
  t.observe(7001,valid(3,0,0,G29UReceipt::Phase::Running),e);
  CHECK(t.view().quality==T::Quality::Gap);
  t.observe(7002,valid(3,16,0xFFFF,G29UReceipt::Phase::RamOnlySuccess),e);
  CHECK(t.view().quality==T::Quality::Gap);
  CHECK(!t.view().receipt_16_ram);
  t.observe(7100,valid(4,0,0,G29UReceipt::Phase::Running),e);
  CHECK(t.view().quality==T::Quality::Fresh);
  t.observe(7200,valid(4,0,0,G29UReceipt::Phase::Failed),e);
  CHECK(t.view().event==T::Event::RunFailed);
  t.observe(7300,valid(4,0,0,G29UReceipt::Phase::Failed),e);
  CHECK(t.view().event==T::Event::None);
  t.observe(7400,valid(4,1,1,G29UReceipt::Phase::Running),e);
  CHECK(t.view().quality==T::Quality::CorruptReceipt);
  t.observe(8000,valid(5,0,0,G29UReceipt::Phase::Refused),e);
  CHECK(t.view().quality==T::Quality::Fresh);
  CHECK(t.view().event==T::Event::RunRefused);
  t.observe(7900,valid(5,0,0,G29UReceipt::Phase::Refused),e);
  CHECK(t.view().quality==T::Quality::ClockBackwards);
  t.observe(9000,valid(5,0,0,G29UReceipt::Phase::Refused),e);
  CHECK(t.view().quality==T::Quality::ClockBackwards);
  t.observe(9050,valid(6,0,0,G29UReceipt::Phase::Running),e);
  CHECK(t.view().quality==T::Quality::Fresh);
  t.observe(9200,valid(6,2,1,G29UReceipt::Phase::Running),e);
  CHECK(t.view().quality==T::Quality::CorruptReceipt);
  t.observe(9300,valid(7,0,0,G29UReceipt::Phase::Running),e);
  CHECK(t.view().quality==T::Quality::Fresh);
  auto missing=valid(7,0,0,G29UReceipt::Phase::Running);missing.observed=false;
  t.observe(9400,missing,e);
  CHECK(t.view().quality==T::Quality::SourceMissing);
  t.observe(9500,valid(7,0,0,G29UReceipt::Phase::Running),e);
  CHECK(t.view().quality==T::Quality::SourceMissing);
  t.observe(9600,valid(8,0,0,G29UReceipt::Phase::Running),e);
  CHECK(t.view().quality==T::Quality::Fresh);
  CHECK(!t.view().automatic_sequence_allowed);
  CHECK(!t.view().eeprom_allowed);
  // 65,536 masks: count must agree with popcount, but NEVER authorize motion.
  uint32_t timestamp=9700;
  for(uint32_t m=0;m<65536;++m){
    T local;
    uint8_t cnt=0;for(uint16_t b=0;b<16;++b)cnt=(uint8_t)(cnt+((m>>b)&1));
    local.observe(timestamp,valid((uint32_t)(m+1),cnt,(uint16_t)m,G29UReceipt::Phase::Running),e);
    CHECK(local.view().quality==T::Quality::Fresh);
    CHECK(local.view().count==cnt);
    CHECK(!local.view().receipt_16_ram);
    CHECK(!local.view().automatic_sequence_allowed);
    CHECK(!local.view().hardware_approved);
    ++timestamp;
  }
  // Modulo-2^32 millis() rollover is valid forward time.
  T wrap;
  wrap.observe(0xFFFFFFE0u,valid(1,0,0,G29UReceipt::Phase::Running),e);
  wrap.observe(0x00000020u,valid(1,1,1,G29UReceipt::Phase::Running),e);
  CHECK(wrap.view().quality==T::Quality::Fresh);
  std::printf("NATIVE EVENT TIMELINE PASS checks=%u (read only)\n",checks);
}
