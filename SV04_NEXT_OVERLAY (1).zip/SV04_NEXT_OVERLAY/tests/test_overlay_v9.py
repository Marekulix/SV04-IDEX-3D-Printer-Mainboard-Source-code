from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'integration'),str(ROOT/'tests')]
import apply_native_guard_v9 as v9
import test_overlay_v8 as v8tests
source=dict(v8tests.src)
header=lambda n: (ROOT/'include'/n).read_text()
a=[header(n) for n in ('SV04NextNativeThermalGate.hpp','SV04NextVisitProof.hpp',
                        'SV04NextG29UReceipt.hpp','SV04NextNativeReadiness.hpp',
                        'SV04NextT1EndstopObserver.hpp')]
result=v9.render(source,*a)
rts=result[v9.RTS]
assert result['Marlin/Configuration.h']==source['Marlin/Configuration.h']
assert result['Marlin/src/module/probe.cpp']==source['Marlin/src/module/probe.cpp']
assert rts.count('t1_endstop_observer.observe(')==2
assert 'READ(X_MAX_PIN) != X_MAX_ENDSTOP_INVERTING' in rts
assert '#if PIN_EXISTS(X_MAX)' in rts
assert 'n.physical_t1_park_witness = false;' in rts
assert 'n.probe_stow_witness = false;' in rts
assert 'settings.save()' not in rts[rts.index('void RTSUpdate()'):rts.index('void RTSUpdate()')+3800]
for bad in (a[-1].replace('allow_motion() const { return false;', 'allow_motion() const { return true;'),
            a[-1].replace('physical_t1_park_proven() const { return false;', 'physical_t1_park_proven() const { return true;')):
    try: v9.render(source,*a[:-1],bad)
    except v9.PatchRefused: pass
    else: raise AssertionError('unsafe sensor patch accepted')
try: v9.render(result,*a)
except v9.PatchRefused: pass
else: raise AssertionError('duplicate patch accepted')
print('SV04 NEXT v9 native sensor overlay fixture PASS')
