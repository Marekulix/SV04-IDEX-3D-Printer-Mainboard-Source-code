from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(root/'integration'),str(root/'tests')]
import apply_native_guard_v13 as v13
import test_overlay_v8 as base
orig=dict(base.src)
orig[v13.G28]='''#include "../../inc/MarlinConfig.h"
#include "../gcode.h"
#include "../../module/stepper.h"
#include "../../module/endstops.h"
#include "../../core/debug_out.h"
void GcodeSuite::G28() {
  if (parser.seen_test('O')) return;
  homeaxis(X_AXIS);
  TERN_(FULL_REPORT_TO_HOST_FEATURE, set_and_report_grblstate(M_IDLE));
}
'''
names=['SV04NextNativeThermalGate.hpp','SV04NextVisitProof.hpp','SV04NextG29UReceipt.hpp',
       'SV04NextNativeReadiness.hpp','SV04NextT1EndstopObserver.hpp',
       'SV04NextNativeEventTimeline.hpp','SV04NextNativeStatusPacket.hpp',
       'SV04NextMeshMapPacket.hpp','SV04NextG28PassiveReceipt.hpp',
       'SV04NextG28G29OrderWitness.hpp']
args=[(root/'include'/file).read_text() for file in names]
out=v13.render(orig,*args)
g=out[v13.G28];rt=out[v13.RTS]
assert g.count('sv04_g28_scope.finish(')==1
assert g.count('::Scope sv04_g28_scope(')==1
assert g.find('sv04_g28_scope')<g.find("parser.seen_test('O')")
assert g.find('sv04_g28_scope.finish(')>g.find('homeaxis(X_AXIS);')
assert rt.count('g28_g29_order_witness.observe(')==1
assert out[v13.HEADER_G28]==args[-2] and out[v13.HEADER_ORDER]==args[-1]
assert out['Marlin/Configuration.h']==orig['Marlin/Configuration.h']
assert out['Marlin/src/module/probe.cpp']==orig['Marlin/src/module/probe.cpp']
for term in ('settings.save(', 'queue.enqueue', 'setTargetBed(', 'process_subcommands_now'):
    assert term not in g and term not in out[v13.HEADER_G28]+out[v13.HEADER_ORDER]
# Verify strict safety guard refuses mutated header.
for idx,replace in [(-2,'bool allows_eeprom()const{return true;}'),
                    (-1,'bool allows_motion()const{return true;}')]:
    mod=list(args)
    old='bool allows_eeprom()const{return false;}' if idx==-2 else 'bool allows_motion()const{return false;}'
    mod[idx]=mod[idx].replace(old,replace)
    try:v13.render(orig,*mod)
    except v13.PatchRefused:pass
    else:raise AssertionError('unsafe header accepted')
try:v13.render(out,*args)
except v13.PatchRefused:pass
else:raise AssertionError('duplicate patch accepted')
# Negative: accidental missing anchor must not silently apply.
mutated=dict(orig);mutated[v13.G28]=mutated[v13.G28].replace('void GcodeSuite::G28() {','void GcodeSuite::G28(uint8_t) {')
try:v13.render(mutated,*args)
except v13.PatchRefused:pass
else:raise AssertionError('changed upstream G28 silently accepted')
print('PASS v13 guarded passive G28/G29 overlay (fixture); native STM32 compile not performed')
