// Stand 11: Negativtests, die die ÜBERLEBENDEN Mutanten der Mutationskampagne erschlagen und die Plausibilitäts-/Drift-Änderungen absichern.
// Jede Prüfung erzwingt den jeweiligen Ablehnungsgrund POSITIV (kein leerer Implikationstest).
#include "../include/SV04NextG29UReceipt.hpp"
#include "../include/SV04NextNativeThermalGate.hpp"
#include "../include/SV04NextT1EndstopObserver.hpp"
#include "../include/SV04NextNativeIdexEvidence.hpp"
#include "../include/SV04NextMeshJournal.hpp"
#include <cstdio>
#include <cstdlib>
#include <cstring>
using namespace sv04next;
static unsigned checks = 0;
#define CK(x) do { if (!(x)) { std::fprintf(stderr, "FAILED %s:%d %s\n", __FILE__, __LINE__, #x); std::abort(); } ++checks; } while (0)

static void g29() {
  { G29UReceipt r; r.begin(); CK(r.point(0, 0, 3.0f)); CK(!r.point(1, 0, 3.01f)); CK(r.phase() == G29UReceipt::Phase::Failed); CK(r.failure() == G29UReceipt::Failure::Sample); CK(r.pixel(1) == G29UReceipt::Pixel::Problem); }
  { G29UReceipt r; r.begin(); CK(!r.point(0, 0, -3.01f)); CK(r.failure() == G29UReceipt::Failure::Sample); }
  { G29UReceipt r; r.begin(); CK(!r.point(0, 0, 1.0e30f)); CK(r.phase() == G29UReceipt::Phase::Failed); }
  { G29UReceipt r; r.begin(); for (uint8_t y = 0; y < 4; ++y) for (uint8_t x = 0; x < 4; ++x) CK(r.point(x, y, ((x + y) & 1) ? 3.0f : -3.0f)); CK(r.finish_ram_only()); CK(r.phase() == G29UReceipt::Phase::RamOnlySuccess); }
  { G29UReceipt r; r.begin(); for (uint8_t y = 0; y < 4; ++y) for (uint8_t x = 0; x < 4; ++x) r.point(x, y, 25.0f); CK(r.phase() == G29UReceipt::Phase::Failed); CK(!r.finish_ram_only()); }  // 25 mm schiefes Bett ist kein Erfolg
  { G29UReceipt r; r.begin(); CK(r.point(1, 2, 0.1f)); CK(!r.point(1, 2, 0.2f)); CK(r.failure() == G29UReceipt::Failure::Duplicate); CK(r.pixel(9) == G29UReceipt::Pixel::Problem); }   // Duplikat markiert den Pixel
  { G29UReceipt r; r.begin(); r.refuse(); unsigned char *p = reinterpret_cast<unsigned char *>(&r); size_t off = sizeof(r);
    for (size_t i = 0; i + 4 <= sizeof(r); i += 4) { uint32_t v; std::memcpy(&v, p + i, 4); if (v == r.sequence()) { off = i; break; } }
    CK(off < sizeof(r)); const uint32_t maxv = 0xFFFFFFFFu; std::memcpy(p + off, &maxv, 4); CK(r.sequence() == 0xFFFFFFFFu);
    CK(r.begin()); CK(r.sequence() == 1u); }   // Überlauf liefert nie die Sequenz 0 ("kein Lauf")
}
static void thermal() {
  struct S { static bool steady(float bed, float target, bool idle, uint32_t secs) { NativeThermalGate g; for (uint32_t t = 0; t <= secs * 1000u; t += 500u) g.observe(t, bed, target, idle); return g.ready(secs * 1000u); } };
  CK(S::steady(60.0f, 60.0f, true, 25));      // Kontrolle: stabil
  CK(!S::steady(60.0f, 65.0f, true, 25)); CK(!S::steady(60.0f, 70.0f, true, 25)); CK(!S::steady(60.0f, 59.99f, true, 25)); CK(!S::steady(60.0f, 0.0f, true, 25));   // Soll genau 60
  CK(!S::steady(60.0f, 60.0f, false, 25));    // Maschine nicht im Leerlauf
  // Temperaturfenster selbst (unabhängig von der Drift-Prüfung): konstant ausserhalb 59..61 C nie bereit, auf den Grenzen bereit
  CK(S::steady(61.0f, 60.0f, true, 25)); CK(S::steady(59.0f, 60.0f, true, 25)); CK(!S::steady(61.01f, 60.0f, true, 25)); CK(!S::steady(58.99f, 60.0f, true, 25)); CK(!S::steady(61.5f, 60.0f, true, 25)); CK(!S::steady(58.5f, 60.0f, true, 25)); CK(!S::steady(70.0f, 60.0f, true, 25)); CK(!S::steady(20.0f, 60.0f, true, 25));
  { NativeThermalGate g; bool ever = false; for (uint32_t t = 0; t <= 40000u; t += 500u) { g.observe(t, 61.0f - 2.0f * (float)t / 40000.0f, 60.0f, true); ever = ever || g.ready(t); } CK(!ever); }   // fällt dauernd durch das Fenster
  { NativeThermalGate g; bool ever = false; for (uint32_t t = 0; t <= 40000u; t += 500u) { g.observe(t, 59.0f + 2.0f * (float)t / 40000.0f, 60.0f, true); ever = ever || g.ready(t); } CK(!ever); }  // steigt dauernd durch das Fenster
  { NativeThermalGate g; uint32_t first = 0; for (uint32_t t = 0; t <= 40000u; t += 500u) { g.observe(t, 60.0f - 0.5f * (float)t / 40000.0f, 60.0f, true); if (!first && g.ready(t)) first = t; } CK(first == 20000u); }   // sehr langsame Drift (0,0125 C/s) bleibt zulässig
}
static void endstop() {
  { T1EndstopObserver o; o.observe(0, true, false); CK(o.state() == T1EndstopObserver::State::ReleaseDebounce); o.observe(60, true, true); CK(o.state() == T1EndstopObserver::State::WaitingForRelease);
    o.observe(120, true, false); o.observe(150, true, false); CK(o.release_epochs() == 0u); CK(o.state() == T1EndstopObserver::State::ReleaseDebounce); }   // Störimpuls beim Loslassen startet die Entprellung neu
}
static void g28_trace_evidence() {
  { G28PassiveReceipt g; g.begin(1); g.finish(2, true, true, true, true); CK(!g.physical_t1_proven()); CK(!g.allows_motion()); CK(!g.allows_heating()); CK(!g.allows_eeprom()); }
  { NativeIdexHomingTrace t; t.begin(10, 1); t.saw_x2_homeaxis_return(11, 0); CK(t.view().state == NativeIdexHomingTrace::State::Invalid); CK(t.view().reason == NativeIdexHomingTrace::Reason::WrongTool); }
  { NativeIdexHomingTrace t; t.begin(10, 1); t.saw_x2_homeaxis_return(11, 1); t.saw_x2_homeaxis_return(12, 1); CK(t.view().state == NativeIdexHomingTrace::State::Invalid); CK(t.view().reason == NativeIdexHomingTrace::Reason::WrongOrder); }
  { NativeIdexHomingTrace t; t.begin(10, 1); for (int i = 0; i < 2; ++i) { t.saw_x2_homeaxis_return(11 + i, 1); t.saw_x1_homeaxis_return(12 + i, 0); } CK(t.view().state == NativeIdexHomingTrace::State::Active);
    t.saw_x2_homeaxis_return(20, 1); CK(t.view().state == NativeIdexHomingTrace::State::Invalid); CK(t.view().reason == NativeIdexHomingTrace::Reason::DuplicateX2); }
  struct E { static NativeIdexEvidence::Reason run(bool z_trusted, uint32_t now) {
      G28PassiveReceipt r; NativeIdexHomingTrace t; NativeIdexEvidence a; T1CorrelationAudit::Result sw; G28G29OrderWitness::Frame order;
      r.begin(10); t.begin(10, r.view().sequence); t.saw_x2_homeaxis_return(11, 1); t.saw_x1_homeaxis_return(12, 0); t.finish(14); r.finish(14, true, true, z_trusted, true);
      sw.homing_sequence = r.view().sequence; sw.electrical_correlation = true; order.g28_sequence = r.view().sequence; order.quality = G28G29OrderWitness::Quality::OrderObserved; order.ram_only_g29_16 = true;
      a.observe(now, r.view(), t.view(), sw, order); CK(!a.view().t1_physically_parked); return a.view().reason; } };
  CK(E::run(false, 20) == NativeIdexEvidence::Reason::G28Untrusted);                                          // untrusted G28 wird abgelehnt
  CK(E::run(true, 14u + NativeIdexEvidence::MaxAgeMs + 1u) == NativeIdexEvidence::Reason::Stale);             // veraltet
  CK(E::run(true, 14u + NativeIdexEvidence::MaxAgeMs) == NativeIdexEvidence::Reason::ElectricalOnly);          // Grenze: noch frisch
}
static void journal() {
  { MeshJournal j; CK(!j.finished(true, true, true, true, true, 0.0f)); CK(j.stage() == MeshJournal::Stage::Failed); CK(!j.allow_eeprom_write()); }   // frisches Journal darf nie validiert werden
  float existing[16], actual[16], dest[16], off = 0.0f; bool lev = false; for (int i = 0; i < 16; ++i) existing[i] = 0.5f + 0.1f * (float)i;
  { MeshJournal j; CK(j.begin(existing, -1.10f, true, true, true)); for (uint8_t i = 0; i < 16; ++i) { CK(j.sample(i, 0.01f * (float)i, 60.0f, true, true)); CK(j.sample(i, 0.01f * (float)i + 0.01f, 60.0f, true, true)); }
    CK(j.finished(true, true, true, true, true, -1.10f)); CK(j.allow_eeprom_write()); CK(j.begin_save()); CK(j.save_result(true)); for (uint8_t i = 0; i < 16; ++i) actual[i] = j.candidate(i);
    CK(j.verified_from_eeprom(true, actual, -1.10f)); CK(j.stage() == MeshJournal::Stage::Done); CK(!j.restore_old_ram_mesh(dest, &off, &lev)); }   // nach dem Commit kein Rollback mehr
  { MeshJournal j; CK(j.begin(existing, -1.10f, true, true, true)); CK(!j.sample(3, 0.1f, 60.0f, true, true)); CK(j.stage() == MeshJournal::Stage::Failed); CK(j.restore_old_ram_mesh(dest, &off, &lev)); CK(std::memcmp(dest, existing, sizeof(existing)) == 0); CK(off == -1.10f); CK(lev); }
}
int main() { g29(); thermal(); endstop(); g28_trace_evidence(); journal(); std::printf("SV04 NEXT audit-11 negative tests PASS checks=%u\n", checks); return 0; }
