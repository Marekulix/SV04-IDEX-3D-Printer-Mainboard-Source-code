from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(root/'integration'),str(root/'tests')]
import apply_native_guard_v14 as v14
import test_overlay_v8 as base
src=dict(base.src)
src[v14.G28]='''#include "../../inc/MarlinConfig.h"
#include "../gcode.h"
#include "../../module/stepper.h"
#include "../../module/endstops.h"
#include "../../core/debug_out.h"
void GcodeSuite::G28() {
  if (parser.seen_test('O')) return;
  if (true) {
        active_extruder = 1;
        homeaxis(X_AXIS);
        active_extruder = 0;
        homeaxis(X_AXIS);
  }
  if (true) {
      active_extruder = 1;
      homeaxis(X_AXIS);
      active_extruder = 0;
      homeaxis(X_AXIS);
  }
  TERN_(FULL_REPORT_TO_HOST_FEATURE, set_and_report_grblstate(M_IDLE));
}
'''
args=[(root/'include'/name).read_text() for name in v14.HEADERS]
result=v14.render(src,*args)
g=result[v14.G28];rt=result[v14.RTS]
assert g.count('saw_x2_homeaxis_return(')==2
assert g.count('saw_x1_homeaxis_return(')==2
assert g.count('sv04_idex_scope.finish(')==1
assert g.index('::Scope sv04_idex_scope')<g.index("parser.seen_test('O')")
assert g.index('sv04_idex_scope.finish(')<g.index('sv04_g28_scope.finish(')
assert rt.count('t1_correlation_audit.observe(')==1
assert rt.count('native_idex_evidence.observe(')==1
assert result['Marlin/Configuration.h']==src['Marlin/Configuration.h']
assert result['Marlin/src/module/probe.cpp']==src['Marlin/src/module/probe.cpp']
for forbidden in ('settings.save()', 'queue.enqueue', 'setTargetBed(', 'M500'):
  assert forbidden not in g and forbidden not in rt
for mutation in ('active_extruder = 1;', 'active_extruder = 0;', 'homeaxis(X_AXIS);'):
  changed=dict(src);changed[v14.G28]=changed[v14.G28].replace(mutation,'// changed',1)
  try:v14.render(changed,*args)
  except v14.PatchRefused:pass
  else:raise AssertionError('G28 topology drift accepted: '+mutation)
for idx,text_old,text_new in [(-3,'bool allows_motion()const{return false;}', 'bool allows_motion()const{return true;}'),
                              (-1,'bool permits_eeprom()const{return false;}', 'bool permits_eeprom()const{return true;}')]:
  altered=list(args);altered[idx]=altered[idx].replace(text_old,text_new)
  try:v14.render(src,*altered)
  except v14.PatchRefused:pass
  else:raise AssertionError('unsafe contract accepted')
try:v14.render(result,*args)
except v14.PatchRefused:pass
else:raise AssertionError('duplicate overlay accepted')
print('PASS v14 G28 native X2/X1 topology and RTS observer hooks; firmware build NOT run')
