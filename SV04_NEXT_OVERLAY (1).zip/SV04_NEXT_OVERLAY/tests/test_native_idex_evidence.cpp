#include "../include/SV04NextNativeIdexEvidence.hpp"
#include <cassert>
#include <iostream>
using namespace sv04next;
int main(){
  unsigned checks=0;
  for(unsigned bits=0;bits<65536u;bits++){
    G28PassiveReceipt r;
    NativeIdexHomingTrace t;
    NativeIdexEvidence audit;
    T1CorrelationAudit::Result sw;
    G28G29OrderWitness::Frame order;
    r.begin(10);
    t.begin(10,r.view().sequence);
    const bool x2=(bits&1u)!=0,x1=(bits&2u)!=0;
    if(x2)t.saw_x2_homeaxis_return(11,(bits&4u)?0:1);
    if(x1)t.saw_x1_homeaxis_return(12,(bits&8u)?1:0);
    if(bits&16u){r.early_return();t.early_return();}
    else {t.finish(14);r.finish(14,(bits&32u)!=0,(bits&64u)!=0,(bits&128u)!=0,(bits&256u)!=0);}
    sw.homing_sequence=r.view().sequence;
    sw.electrical_correlation=(bits&512u)!=0;
    order.g28_sequence=r.view().sequence;
    order.quality=G28G29OrderWitness::Quality::OrderObserved;
    order.ram_only_g29_16=true;
    audit.observe((bits&1024u)?200000u:20u,r.view(),t.view(),sw,order);
    const auto &v=audit.view();
    assert(!v.t1_physically_parked&&!v.allow_motion&&!v.allow_heat&&!v.allow_eeprom);++checks;
    assert(!audit.physical_t1_park_proven()&&!audit.permits_motion()&&
      !audit.permits_heating()&&!audit.permits_eeprom());++checks;
    if(v.reason==NativeIdexEvidence::Reason::ElectricalOnly){
      assert(v.both_x_homeaxis_returned && v.g28_xyz_trusted && v.electrical_correlated);++checks;
    }
    if(bits&16u){assert(v.reason==NativeIdexEvidence::Reason::EarlyReturn);++checks;}
    if(v.reason==NativeIdexEvidence::Reason::Stale){assert(!v.electrical_correlated);++checks;}
  }
  G28PassiveReceipt r;NativeIdexHomingTrace t;NativeIdexEvidence a;
  T1CorrelationAudit::Result sw;G28G29OrderWitness::Frame order;
  r.begin(100);r.finish(200,true,true,true,true);
  t.begin(100,99);t.saw_x2_homeaxis_return(110,1);t.saw_x1_homeaxis_return(120,0);t.finish(200);
  a.observe(201,r.view(),t.view(),sw,order);
  assert(a.view().reason==NativeIdexEvidence::Reason::WrongSequence);
  std::cout<<"PASS native IDEx combined diagnostic checks="<<checks+1<<"; all permissions denied\n";
}
