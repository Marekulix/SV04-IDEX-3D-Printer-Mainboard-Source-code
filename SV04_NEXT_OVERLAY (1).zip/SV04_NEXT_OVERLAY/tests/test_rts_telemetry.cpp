#include "../include/SV04NextRtsTelemetry.hpp"
#include "../include/SV04NextDwinView.hpp"
#include <cassert>
#include <initializer_list>
#include <cmath>
#include <cstdio>
using namespace sv04next;
int main(){
  int n=0;
  for(unsigned i=0;i<16;i++){
    assert(RtsTelemetry::mesh_vp(i)==0x1100+2*i);n++;
    assert(RtsTelemetry::mesh_vp(i)==DwinView::rts_value_address(i));n++;
    assert(RtsTelemetry::valid_progress(i));n++;
    int16_t value=0;
    assert(RtsTelemetry::encode_mesh_mm(.01f*i,value));n++;
    assert(value==int(i*10));n++;
    assert(DwinView::y_at(i)==i/4);n++;
  }
  assert(RtsTelemetry::mesh_vp(16)==0);n++;
  assert(RtsTelemetry::mesh_vp(255)==0);n++;
  assert(!RtsTelemetry::valid_progress(17));n++;
  for(float v:{-3.f,0.f,3.f}){int16_t result=0;assert(RtsTelemetry::encode_mesh_mm(v,result));n++;}
  for(float v:{NAN,INFINITY,-3.1f,3.1f}){int16_t result=0;assert(!RtsTelemetry::encode_mesh_mm(v,result));n++;}
  for(float v:{NAN,INFINITY,-1.f,116.f}){uint16_t result=0;assert(!RtsTelemetry::encode_bed_c(v,result));n++;}
  assert(RtsTelemetry::progress_vp==0x108D);n++;
  assert(RtsTelemetry::bed_actual_vp==0x103C);n++;
  std::printf("SV04_NEXT_RTS_TELEMETRY PASS checks=%d no_hmi_mutation\n",n);
}
