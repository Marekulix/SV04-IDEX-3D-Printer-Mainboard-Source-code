#include "../include/SV04NextNativeIdexHomingTrace.hpp"
#include <cassert>
#include <iostream>
using sv04next::NativeIdexHomingTrace;
using T=NativeIdexHomingTrace;
int main(){
  unsigned long checks=0;
  for(unsigned flags=0;flags<65536u;flags++){
    T trace;
    {
      T::Scope scope(trace,10,1);
      assert(trace.view().state==T::State::Active);++checks;
      if(flags&1u)trace.saw_x2_homeaxis_return(11,(flags&2u)?0:1);
      if(flags&4u)trace.saw_x1_homeaxis_return(12,(flags&8u)?1:0);
      if(flags&16u)trace.saw_x2_homeaxis_return(13,(flags&32u)?0:1);
      if(flags&64u)trace.saw_x1_homeaxis_return(14,(flags&128u)?1:0);
      if(flags&256u)trace.saw_x1_homeaxis_return(15,0);
      if(flags&512u)trace.saw_x2_homeaxis_return(16,1);
      if(flags&1024u)trace.saw_x1_homeaxis_return(17,0);
      if(flags&2048u)trace.saw_x2_homeaxis_return(18,1);
      if(!(flags&4096u))scope.finish(19);
    }
    const auto &v=trace.view();
    assert(v.g28_sequence==1);++checks;
    assert(v.state!=T::State::Active);++checks;
    assert(!v.physical_t1_park_proven&&!v.allow_motion&&!v.allow_eeprom);++checks;
    assert(!trace.physical_t1_park_proven()&&!trace.allows_motion()&&!trace.allows_eeprom());++checks;
    if(v.state==T::State::EndObserved && v.both_x_homeaxis_returned){
      assert(v.reason==T::Reason::None && v.x2_returns==v.x1_returns && v.x1_returns>0);++checks;
    }
  }
  T t;
  {T::Scope s(t,100,1);t.saw_x2_homeaxis_return(101,1);t.saw_x1_homeaxis_return(102,0);s.finish(105);}
  assert(t.view().both_x_homeaxis_returned && t.view().x2_returns==1);
  {T::Scope s(t,200,2);t.saw_x2_homeaxis_return(201,1);t.saw_x1_homeaxis_return(202,0);
   t.saw_x2_homeaxis_return(203,1);t.saw_x1_homeaxis_return(204,0);s.finish(205);}
  assert(t.view().both_x_homeaxis_returned && t.view().x1_returns==2);
  {T::Scope s(t,300,3);t.saw_x2_homeaxis_return(301,1);s.finish(302);}
  assert(t.view().state==T::State::EndObserved && !t.view().both_x_homeaxis_returned);
  {T::Scope s(t,400,4);t.saw_x2_homeaxis_return(401,1);}
  assert(t.view().state==T::State::ReturnedEarly);
  {T::Scope s(t,0xFFFFFFFEu,5);t.saw_x2_homeaxis_return(0,1);t.saw_x1_homeaxis_return(1,0);s.finish(2);}
  assert(t.view().both_x_homeaxis_returned);
  {T::Scope s(t,0,6);t.saw_x2_homeaxis_return(600001u,1);s.finish(600002u);}
  assert(t.view().state==T::State::Invalid);
  std::cout<<"PASS native G28 X2/X1 path trace checks="<<checks+8<<"; NOT park proof\n";
}
