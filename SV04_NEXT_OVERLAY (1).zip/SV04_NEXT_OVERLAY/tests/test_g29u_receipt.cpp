#include "../include/SV04NextG29UReceipt.hpp"
#include <assert.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
using sv04next::G29UReceipt;
static unsigned checks=0;
#define CK(x) do {assert((x));++checks;} while(0)

int main() {
  G29UReceipt s;
  CK(s.phase()==G29UReceipt::Phase::Never);
  CK(s.completed()==0 && s.point_mask()==0);
  CK(!s.eeprom_authorized() && !s.hardware_verified());
  CK(!s.finish_ram_only());
  CK(!s.point(0,0,0.f));
  CK(s.begin());
  uint32_t run=s.sequence();
  CK(run!=0 && s.phase()==G29UReceipt::Phase::Running);
  CK(!s.begin() && s.sequence()==run);
  CK(!s.point(4,0,0.01f));
  CK(s.phase()==G29UReceipt::Phase::Failed && s.failure()==G29UReceipt::Failure::PointIndex);
  CK(s.begin() && s.sequence()!=run);
  CK(!s.point(0,4,0.01f));
  CK(s.begin());
  CK(!s.point(1,1,NAN));
  CK(s.phase()==G29UReceipt::Phase::Failed && s.pixel(5)==G29UReceipt::Pixel::Problem);
  CK(s.begin());
  CK(!s.point(1,1,INFINITY));
  CK(s.begin());
  CK(s.point(0,0,-0.1f));
  CK(!s.point(0,0,0.1f));
  CK(s.failure()==G29UReceipt::Failure::Duplicate);
  CK(!s.finish_ram_only());
  CK(s.begin());
  CK(s.point(0,0,0.01f));
  CK(!s.finish_ram_only());
  CK(s.failure()==G29UReceipt::Failure::Incomplete);
  CK(s.begin());
  CK(!s.refuse(G29UReceipt::Failure::Busy));
  CK(s.phase()==G29UReceipt::Phase::Refused && s.failure()==G29UReceipt::Failure::Busy);
  CK(s.begin());
  CK(!s.fail(G29UReceipt::Failure::Temperature));
  CK(s.phase()==G29UReceipt::Phase::Failed && s.failure()==G29UReceipt::Failure::Temperature);
  // A partial/aborted run must NEVER preserve a success indication.
  for (uint8_t fail_at=0;fail_at<16;++fail_at) {
    CK(s.begin());
    for(uint8_t i=0;i<fail_at;++i) CK(s.point(i%4,i/4,0.001f*i));
    CK(!s.fail());
    CK(s.phase()==G29UReceipt::Phase::Failed);
    CK(!s.finish_ram_only());
  }
  // Every cyclic permutation of all sixteen positions must finish only on 16/16.
  for(int order=0;order<16;++order){
    CK(s.begin());
    uint32_t this_run=s.sequence();
    for(int i=0;i<16;++i){
      uint8_t p=(uint8_t)((i+order)&15);
      CK(s.point(p%4,p/4,(float)(p-8)*0.1f));
      CK(s.completed()==i+1);
      CK(s.pixel(p)==G29UReceipt::Pixel::Recorded);
      CK(s.sequence()==this_run);
      CK(s.phase()==G29UReceipt::Phase::Running);
      CK(!s.eeprom_authorized());
    }
    CK(s.point_mask()==0xFFFFu);
    for(uint8_t i=0;i<16;++i) CK(isfinite(s.value(i)));
    CK(s.finish_ram_only());
    CK(s.phase()==G29UReceipt::Phase::RamOnlySuccess);
    CK(!s.eeprom_authorized() && !s.hardware_verified());
    CK(!s.finish_ram_only());
    CK(!s.point(0,0,0.f));
  }
  // RAII must finalize even a return from deep inside G29. Nested requests
  // cannot overwrite an active result or its sequence.
  CK(s.begin());
  run=s.sequence();
  {
    G29UReceipt::Scope duplicate(true,s);
    CK(!duplicate.armed());
    CK(s.sequence()==run);
  }
  CK(s.phase()==G29UReceipt::Phase::Running);
  CK(!s.fail());
  {
    G29UReceipt::Scope scope(true,s);
    CK(scope.armed());
    CK(s.point(1,3,0.2f));
  }
  CK(s.phase()==G29UReceipt::Phase::Failed);
  CK(s.failure()==G29UReceipt::Failure::EarlyReturn);
  {G29UReceipt::Scope scope(false,s);CK(!scope.armed());}
  CK(s.phase()==G29UReceipt::Phase::Failed);
  CK(s.pixel(16)==G29UReceipt::Pixel::Problem);
  CK(isnan(s.value(16)));
  printf("SV04 NEXT G29 U native receipt tests PASS checks=%u\n",checks);
}
