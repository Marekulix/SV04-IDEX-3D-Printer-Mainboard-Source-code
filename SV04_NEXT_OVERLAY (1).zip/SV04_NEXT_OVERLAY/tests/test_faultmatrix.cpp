#include "../include/SV04NextAuto60Orchestrator.hpp"
#include <cstdio>
#include <cmath>
#include <cstring>
using namespace sv04next;
#define EXPECT(x) do{ if(!(x)){std::fprintf(stderr,"FAIL LINE %d: %s\n",__LINE__,#x);return 1;}++n;}while(0)
int main(){
  int n=0;
  using O=Auto60Orchestrator;
  O::Snapshot b={};b.z_offset=-1.10f;b.leveling_enabled=true;
  b.start_x=14;b.start_y=22;b.spacing_x=69;b.spacing_y=68;
  for(int i=0;i<16;i++)b.mesh[i]=(i%7)*.01f;
  // Heat interrupted by individual hazards: never progress to motion.
  for(unsigned i=0;i<16;i++){
    O x;Auto60Inputs v;EXPECT(x.start(10,v,b)==O::Action::SetBedTo60);
    v.target_c=60;v.bed_c=60;EXPECT(x.tick(20,v)==O::Action::None);
    switch(i){
      case 0:v.printing=true;break;case 1:v.heater_healthy=false;break;
      case 2:v.bltouch_healthy=false;break;case 3:v.estop_clear=false;break;
      case 4:v.tool0_selected=false;break;case 5:v.tool1_park_verified=false;break;
      case 6:v.bed_c=NAN;break;case 7:v.bed_c=INFINITY;break;
      case 8:v.bed_c=-5.f;break;case 9:v.bed_c=120.f;break;
      case 10:v.z_offset=-1.20f;break;case 11:v.z_offset=NAN;break;
      case 12:v.target_c=30;break;case 13:v.motion_idle=false;break;
      case 14:v.queue_empty=false;break;case 15:v.probe_stowed=false;break;
    }
    auto act=x.tick(20020,v);
    // Wrong target pauses heating. Other active hazards must fail-closed.
    if(i==12)EXPECT(act==O::Action::StopAndRestoreOldRamMesh);
    else if(i==13 || i==14 || i==15)EXPECT(act==O::Action::StopAndRestoreOldRamMesh || act==O::Action::None);
    else EXPECT(act==O::Action::StopAndRestoreOldRamMesh);
    EXPECT(!x.eeprom_save_permitted());
    if(x.phase()==O::Phase::Failed){const O::Snapshot *s=nullptr;
      EXPECT(x.snapshot(s));EXPECT(memcmp(s,&b,sizeof(b))==0);}
  }
  // Low temperature at homing / back-to-back offset change before G29.
  for(unsigned fault=0;fault<6;fault++){
    O x; Auto60Inputs v;EXPECT(x.start(1,v,b)==O::Action::SetBedTo60);
    v.target_c=v.bed_c=60;EXPECT(x.tick(2,v)==O::Action::None);
    EXPECT(x.tick(20002,v)==O::Action::RequestG28);
    v.homed_xyz=true;
    switch(fault){case 0:v.tool1_park_verified=false;break;
      case 1:v.bed_c=54;break;case 2:v.target_c=55;break;
      case 3:v.z_offset=-.9f;break;case 4:v.queue_empty=false;break;
      case 5:v.probe_stowed=false;break;}
    EXPECT(x.homing_done(true,v)==O::Action::StopAndRestoreOldRamMesh);
    EXPECT(!x.eeprom_save_permitted());
  }
  // Idle interface may not accept another 'start' mid sequence.
  {O x;Auto60Inputs v;EXPECT(x.start(1,v,b)==O::Action::SetBedTo60);
   EXPECT(x.start(2,v,b)==O::Action::None);EXPECT(x.phase()==O::Phase::Heating);}
  std::printf("SV04_NEXT_AUTO60_FAULTMATRIX PASS checks=%d eeprom=blocked\n",n);
}
