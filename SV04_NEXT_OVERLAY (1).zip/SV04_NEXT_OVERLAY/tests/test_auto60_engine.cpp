// Host-Simulation der Zustandsmaschine Auto60Engine gegen eine simulierte Maschine (echte Beleg-Klassen und echter Thermotor).
// Stufe: SIMULATION. Prueft Invarianten bei JEDEM Schritt, gezielte Fehler, Stoerungen zu jedem Zeitpunkt und Zufallskombinationen.
#include "../include/SV04NextAuto60Engine.hpp"
#include "../include/SV04NextNativeThermalGate.hpp"
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <deque>
#include <string>
using namespace sv04next;
using E = Auto60Engine; using St = E::State; using Rs = E::Reason; using Ac = E::Action;
enum G28M { G28Ok, G28Early, G28Untrusted, G28Never, G28Slow, G28Tool1 }; enum G29M { G29Ok, G29Refuse, G29FailAt, G29Never, G29Slow }; enum EepM { EepMatch, EepMismatch, EepSaveFail, EepNever };
struct Ev { uint32_t t; int kind; };   // t: ms nach Start; kind: 0 Druck, 1 Stopp, 2 Abbruch, 3 Quittung, 4 Fremd-Soll 55, 5 Sensor-NaN 3 s, 6 Werkzeug T1, 7 Offset aendern, 8 Leveling aus, 9 Strom weg
struct F {
  float rate = 0.5f; bool ignore_set = false; bool overshoot = false; uint32_t qdelay = 500, g28_ms = 20000, g29_pt_ms = 15000; G28M g28 = G28Ok; G29M g29 = G29Ok; int fail_at = 5; bool leveling_after = true;
  bool commit_supported = true; EepM eep = EepMatch; bool auto_commit = false; bool confirm = false; bool stale_g28 = false; uint32_t clock0 = 100000; bool release = true; std::deque<Ev> ev; uint32_t stall_from = 0, stall_ms = 0; bool enq_fail_home = false, enq_fail_measure = false, busy_start = false, printing_start = false, tool1_start = false, stale_g29 = false;
};
struct Run { bool foreign = false; St st = St::Idle; Rs rs = Rs::None; G29UReceipt::Failure mf = G29UReceipt::Failure::None; bool may = false; int commits = 0, saves = 0, viol = 0; bool heater_off = true, released = false, rolled_back = false, mesh_new = false; uint32_t sim_ms = 0, states_seen = 0; std::string v; uint32_t entered[16] = {0}; };
static uint32_t lcg(uint32_t &s) { s = s * 1664525u + 1013904223u; return s >> 8; }
static Run run(const F &f0, E::Config cfg = E::Config(), uint32_t max_ms = 3u * 3600u * 1000u) {
  F f = f0; cfg.auto_commit = f.auto_commit; E eng(cfg); Run r; NativeThermalGate gate; G28PassiveReceipt g28; G29UReceipt g29;
  uint32_t now = f.clock0, noise = 12345u; float bed = 25.0f, target = 0.0f, offset = -1.10f; bool printing = false, stopped = false, tool0 = true, xyz = false, leveling = true;
  int saves = 0; E::Eeprom eep = E::Eeprom::Unknown; uint32_t eep_due = 0; bool eep_pending = false;
  struct Q { int cmd; uint32_t due; }; std::deque<Q> q; uint32_t busy_until = 0; bool busy_set = false; if (f.busy_start) { q.push_back({0, f.clock0 + 5000u}); } int running = 0; uint32_t run_end = 0, next_pt = 0; int pt = 0; bool nan_set = false; uint32_t nan_until = 0; bool rolled = false, mesh_new = false;
  if (f.stale_g29) { g29.begin(); for (int i = 0; i < 16; ++i) g29.point((uint8_t)(i % 4), (uint8_t)(i / 4), 0.1f); g29.finish_ram_only(); }
  if (f.printing_start) printing = true;
  if (f.tool1_start) tool0 = false;
  if (f.stale_g28) { g28.begin(now - 5000); g28.finish(now - 4000, true, true, true, true); xyz = true; }
  const uint32_t start = now + 1000; bool started = false, started_once = false, power_lost = false, g29_ok = false, home_ok = false, locked = false; uint32_t power_t = 0, quiet_since = 0, quiet2 = 0, g28_seq_at_home = 0, pend_enter = 0; bool pend_seen = false;
  auto viol = [&](const char *m) { ++r.viol; if (r.v.empty()) r.v = m; };
  const uint32_t TICK = 200;
  for (uint32_t t = 0; t < max_ms; t += TICK) {
    now += TICK;
    float tgt = target; if (tgt > 0.0f) { float d = tgt - bed, st = f.rate * ((float)TICK / 1000.0f); bed += (d > 0 ? (d < st ? d : st) : (d > -st ? d : -st)); } else bed += (25.0f - bed) * 0.002f;
    float nz = ((float)(lcg(noise) % 1000) / 1000.0f - 0.5f) * 0.3f, bm = (tgt > 0.0f && std::fabs(bed - tgt) < 1.0f) ? bed + nz : bed; if (f.overshoot && tgt == 60.0f && bed > 59.5f) bm = 66.0f;
    bool nan_now = nan_set && (int32_t)(nan_until - now) > 0; if (nan_now) bm = NAN;
    gate.observe(now, bm, tgt, !printing && !stopped);
    bool abort_p = false, ack_p = false;
    while (started && !f.ev.empty() && (uint32_t)(now - start) >= f.ev.front().t) {
      Ev e = f.ev.front(); f.ev.pop_front();
      switch (e.kind) { case 0: printing = true; break; case 1: stopped = true; break; case 2: abort_p = true; break; case 3: ack_p = true; break; case 4: target = 55.0f; r.foreign = true; break; case 5: nan_set = true; nan_until = now + 3000; break; case 6: tool0 = false; break; case 7: offset = -1.2f; break; case 8: leveling = false; break;
        case 10: busy_until = now + 30000u; busy_set = true; break;
        case 9: eng = E(cfg); q.clear(); running = 0; g28 = G28PassiveReceipt(); g29 = G29UReceipt(); gate.reset(); target = 0.0f; xyz = false; started = false; power_lost = true; power_t = now; locked = false; f.ev.clear(); break; }
    }
    tgt = target;
    if (running == 0 && !q.empty() && (int32_t)(now - q.front().due) >= 0) {
      Q c = q.front(); q.pop_front(); if (c.cmd == 0) { running = 3; run_end = now + 5000u; }
      if (c.cmd == 1 && f.g28 != G28Never && g28.begin(now)) { running = 1; run_end = now + (f.g28 == G28Slow ? 4000000u : f.g28 == G28Early ? 3000u : f.g28_ms); }
      if (c.cmd == 2 && f.g29 != G29Never && g29.begin()) { running = 2; pt = 0; next_pt = now + (f.g29 == G29Slow ? 4000000u : f.g29_pt_ms);
        bool ok = !stopped && !printing && tool0 && xyz && tgt == 60.0f && NativeThermalGate::live_sample_safe(bm, tgt) && gate.ready(now) && f.g29 != G29Refuse; if (!ok) { g29.refuse(G29UReceipt::Failure::Preconditions); running = 0; } }
    }
    if (running == 3 && (int32_t)(now - run_end) >= 0) running = 0;
    if (running == 1 && (int32_t)(now - run_end) >= 0) { if (f.g28 == G28Early) { g28.early_return(); xyz = false; } else { bool tr = f.g28 != G28Untrusted; g28.finish(now, tr, tr, tr, f.g28 != G28Tool1); xyz = tr; } running = 0; }
    if (running == 2 && (int32_t)(now - next_pt) >= 0) {
      bool bad = stopped || printing || !tool0 || tgt != 60.0f || !NativeThermalGate::live_sample_safe(bm, tgt) || offset != -1.10f;
      if (bad) { g29.fail(G29UReceipt::Failure::Temperature); rolled = true; running = 0; }
      else if (f.g29 == G29FailAt && pt == f.fail_at) { g29.fail(G29UReceipt::Failure::RunFailed); rolled = true; running = 0; }
      else { g29.point((uint8_t)(pt % 4), (uint8_t)(pt / 4), 0.05f * (float)pt - 0.3f); ++pt; next_pt = now + f.g29_pt_ms; if (pt == 16) { if (g29.finish_ram_only()) { g29_ok = true; mesh_new = true; } running = 0; } }
    }
    if (eep_pending && (int32_t)(now - eep_due) >= 0) { eep_pending = false; eep = f.eep == EepMatch ? E::Eeprom::ReadbackMatch : f.eep == EepMismatch ? E::Eeprom::ReadbackMismatch : E::Eeprom::SaveFailed; }
    if (!started_once && now >= start) { started_once = started = true; if (!eng.request_start()) viol("Start abgelehnt"); }
    E::Obs o; o.now_ms = now; o.bed_c = bm; o.bed_target_c = tgt; o.probe_offset_z = offset; o.stopped = stopped; o.printing = printing; o.paused = false; o.motion_queued = running != 0; o.queue_busy = !q.empty() || (busy_set && (int32_t)(busy_until - now) > 0); o.tool0 = tool0; o.dual_auto_park = true; o.xyz_trusted = xyz;
    o.leveling_active = leveling && (f.leveling_after || !mesh_new); o.thermal_ready = gate.ready(now); o.thermal_safe = NativeThermalGate::live_sample_safe(bm, tgt);
    const G28PassiveReceipt::View &gv = g28.view(); o.g28_seq = gv.sequence; o.g28_ended_ms = gv.ended_ms; o.g28_phase = gv.phase; o.g28_trusted = gv.xyz_trusted; o.g28_tool0 = gv.tool0;
    o.g29_seq = g29.sequence(); o.g29_phase = g29.phase(); o.g29_failure = g29.failure(); o.g29_completed = g29.completed(); o.user_abort = abort_p; o.user_ack = ack_p; o.eeprom_commit_supported = f.commit_supported; o.eeprom = eep;
    St sb = eng.state(); bool term = sb == St::Done || sb == St::DoneRamOnly || sb == St::AbortLocked;
    if (f.confirm && sb == St::CommitPending) { if (!pend_seen) { pend_seen = true; pend_enter = now; } if ((uint32_t)(now - pend_enter) >= 2000u) o.user_ack = true; }
    if (term && f.release && running == 0 && q.empty()) { if (!quiet_since) quiet_since = now; if ((uint32_t)(now - quiet_since) >= 3000u) o.user_ack = true; } else if (!term) quiet_since = 0;
    bool had = g29.phase() == G29UReceipt::Phase::RamOnlySuccess; St before = eng.state(); bool stalled = f.stall_ms && started && (uint32_t)(now - start) >= f.stall_from && (uint32_t)(now - start) < f.stall_from + f.stall_ms; Ac a = stalled ? Ac::None : eng.tick(o); St after = eng.state();
    if (after != before && !r.entered[(uint32_t)after]) r.entered[(uint32_t)after] = (now - start) | 1u;
    if (a != Ac::None && before == St::Idle) viol("Aktion im Zustand Idle");
    if (locked && (a == Ac::SetBed60 || a == Ac::Home || a == Ac::Measure || a == Ac::Commit)) viol("Aktion nach ABORT_LOCKED");
    if (a != Ac::None && started && (uint32_t)after > 14) {}
    switch (a) {
      case Ac::SetBed60: if (before != St::Precheck) viol("SetBed60 ausserhalb Precheck"); if (printing || stopped || !q.empty() || running) viol("SetBed60 bei nicht ruhiger Maschine"); if (!f.ignore_set) target = 60.0f; break;
      case Ac::SetBedOff: target = 0.0f; break;
      case Ac::Home: if (before != St::TempStable) viol("Home ausserhalb TempStable"); if (running || !q.empty() || o.queue_busy) viol("Home bei laufender Bewegung/Warteschlange"); if (!o.thermal_ready || tgt != 60.0f) viol("Home ohne stabile 60 C"); home_ok = true; g28_seq_at_home = gv.sequence; if (f.enq_fail_home) eng.notify_action_failed(); else q.push_back({1, now + f.qdelay}); break;
      case Ac::Measure: if (before != St::VerifyHome) viol("Measure ausserhalb VerifyHome"); if (running || !q.empty()) viol("Measure bei laufender Bewegung"); if (!home_ok || gv.sequence == g28_seq_at_home || gv.phase != G28PassiveReceipt::Phase::EndObservedTrusted) viol("Measure ohne NEUEN vertrauenswuerdigen G28-Beleg"); if (!o.thermal_ready || tgt != 60.0f) viol("Measure ohne stabile 60 C"); if (f.enq_fail_measure) eng.notify_action_failed(); else q.push_back({2, now + f.qdelay}); break;
      case Ac::Commit: if (before != St::CommitPending) viol("Commit ausserhalb CommitPending"); if (!had || !g29_ok) viol("Commit ohne RamOnlySuccess"); if (!f.commit_supported) viol("Commit trotz fehlender Unterstuetzung"); if (!(f.auto_commit || o.user_ack)) viol("Commit ohne Bestaetigung"); if (saves >= 1) viol("zweiter Commit"); ++saves; eep_pending = f.eep != EepNever; eep_due = now + 1500u; break;
      case Ac::None: break;
    }
    if (after == St::AbortLocked) locked = true;
    if (after == St::Idle) locked = false;
    if (after == St::Idle && before != St::Idle && started && (running || !q.empty())) viol("Freigabe bei laufender Maschine");
    if (saves > 1) viol("mehr als ein EEPROM-Schreibvorgang");
    if (saves == 1 && !g29_ok) viol("EEPROM ohne Erfolg geschrieben");
    r.sim_ms = t + TICK; bool t2 = after == St::Done || after == St::DoneRamOnly || after == St::AbortLocked;
    if (power_lost) { if ((uint32_t)(now - power_t) > 3000u) { r.released = true; break; } continue; }
    if (started && after == St::Idle && before != St::Idle) { r.released = true; break; }
    if (started && after == St::Idle && (uint32_t)(now - start) > 5000u) { viol("Maschine blieb nach Start in Idle"); break; }
    if (!f.release && t2 && running == 0 && q.empty()) { if (!quiet2) quiet2 = now; if ((uint32_t)(now - quiet2) > 5000u) break; } else quiet2 = 0;
  }
  r.st = eng.state(); r.rs = eng.reason(); r.commits = eng.view().commits; r.saves = saves; r.heater_off = (target == 0.0f); r.rolled_back = rolled; r.mesh_new = mesh_new; r.mf = eng.view().mesh_failure; r.may = eng.view().eeprom_may_have_changed; return r;
}
static int fails = 0, total = 0; static int cov[16][24];
static void check(const char *name, const Run &r, bool cond, const char *why = "") { ++total; if (r.viol || !cond) { ++fails; std::printf("FAIL  %-62s %s%s st=%d rs=%d saves=%d %s\n", name, r.viol ? "INVARIANTE: " : "", r.viol ? r.v.c_str() : why, (int)r.st, (int)r.rs, r.saves, r.released ? "" : "(nicht freigegeben)"); } else std::printf("PASS  %s\n", name); }
#define EXPECT(name, f, STATE, REASON, SAVES) do { Run r_ = run(f); check(name, r_, r_.st == STATE && r_.rs == REASON && r_.saves == SAVES, "unerwarteter Endzustand"); } while (0)
static F base() { F f; return f; }
int main() {
  { F f = base(); f.auto_commit = true; Run r = run(f); check("A01 Erfolg mit auto_commit: Done, 1 Commit, Rueckkehr in Idle, Heizung aus", r, r.st == St::Idle && r.saves == 1 && r.commits == 1 && r.heater_off && r.mesh_new && r.released, "Ablauf"); }
  { F f = base(); f.confirm = true; f.release = false; Run r = run(f); check("A02 Erfolg mit Quittung: Done, 1 Commit, kein offener EEPROM-Verdacht", r, r.st == St::Done && r.saves == 1 && r.heater_off && !r.may, "Ablauf"); }
  { F f = base(); f.release = false; Run r = run(f); check("A03 Erfolg ohne Quittung: DoneRamOnly (nicht bestaetigt), 0 Schreibvorgaenge", r, r.st == St::DoneRamOnly && r.rs == Rs::CommitNotConfirmed && r.saves == 0 && r.heater_off, "Ablauf"); }
  { F f = base(); f.commit_supported = false; f.auto_commit = true; f.release = false; Run r = run(f); check("A04 Commit nicht unterstuetzt: DoneRamOnly, 0 Schreibvorgaenge trotz auto_commit", r, r.st == St::DoneRamOnly && r.rs == Rs::CommitNotAvailable && r.saves == 0, "Ablauf"); }
  { F f = base(); f.auto_commit = true; f.eep = EepMismatch; f.release = false; Run r = run(f); check("A05 Readback weicht ab: ABORT_LOCKED, EEPROM moeglicherweise veraendert", r, r.st == St::AbortLocked && r.rs == Rs::ReadbackMismatch && r.saves == 1 && r.may, "Ablauf"); }
  { F f = base(); f.auto_commit = true; f.eep = EepSaveFail; f.release = false; Run r = run(f); check("A06 Speichern fehlgeschlagen: ABORT_LOCKED", r, r.st == St::AbortLocked && r.rs == Rs::ReadbackMismatch && r.saves == 1, "Ablauf"); }
  { F f = base(); f.auto_commit = true; f.eep = EepNever; f.release = false; Run r = run(f); check("A07 Readback kommt nie: ABORT_LOCKED CommitTimeout", r, r.st == St::AbortLocked && r.rs == Rs::CommitTimeout && r.saves == 1 && r.may, "Ablauf"); }
  { F f = base(); f.rate = 0.0f; f.release = false; Run r = run(f); check("B01 Bett heizt nie: HeatTimeout, Heizung aus", r, r.st == St::AbortLocked && r.rs == Rs::HeatTimeout && r.heater_off && r.saves == 0, "Ablauf"); }
  { F f = base(); f.ignore_set = true; f.release = false; Run r = run(f); check("B02 Soll wird nicht uebernommen: HeatTargetNotApplied (Annahme != Wirkung)", r, r.st == St::AbortLocked && r.rs == Rs::HeatTargetNotApplied, "Ablauf"); }
  { F f = base(); f.overshoot = true; f.release = false; Run r = run(f); check("B03 Messwert 66 C: TempOvershoot, Heizung aus", r, r.st == St::AbortLocked && r.rs == Rs::TempOvershoot && r.heater_off, "Ablauf"); }
  { F f = base(); f.ev = {{20000, 5}}; f.release = false; Run r = run(f); check("B04 Sensor liefert NaN: ObservationInvalid", r, r.st == St::AbortLocked && r.rs == Rs::ObservationInvalid && r.heater_off, "Ablauf"); }
  { F f = base(); f.ev = {{30000, 4}}; f.release = false; Run r = run(f); check("B05 Fremder aendert Soll auf 55: ExternalActivity", r, r.st == St::AbortLocked && r.rs == Rs::ExternalActivity && r.heater_off, "Ablauf"); }
  { F f = base(); f.ev = {{10000, 0}}; f.release = false; Run r = run(f); check("C01 Druck startet waehrend Heizen: ExternalActivity", r, r.st == St::AbortLocked && r.rs == Rs::ExternalActivity && r.heater_off, "Ablauf"); }
  { F f = base(); f.ev = {{10000, 1}}; f.release = false; Run r = run(f); check("C02 Not-Aus waehrend Heizen: Stopped", r, r.st == St::AbortLocked && r.rs == Rs::Stopped, "Ablauf"); }
  { F f = base(); f.g28 = G28Early; f.release = false; Run r = run(f); check("D01 G28 kehrt frueh zurueck: HomeFailed, kein Measure", r, r.st == St::AbortLocked && r.rs == Rs::HomeFailed && r.entered[(int)St::MeasureG29] == 0, "Ablauf"); }
  { F f = base(); f.g28 = G28Untrusted; f.release = false; Run r = run(f); check("D02 G28 ohne Vertrauen: HomeFailed", r, r.st == St::AbortLocked && r.rs == Rs::HomeFailed, "Ablauf"); }
  { F f = base(); f.g28 = G28Never; f.release = false; Run r = run(f); check("D03 G28 wird nie ausgefuehrt: HomeTimeout", r, r.st == St::AbortLocked && r.rs == Rs::HomeTimeout && r.entered[(int)St::MeasureG29] == 0, "Ablauf"); }
  { F f = base(); f.g28 = G28Never; f.stale_g28 = true; f.release = false; Run r = run(f); check("D04 ALTER vertrauenswuerdiger G28-Beleg vorhanden, neuer G28 laeuft nie: HomeTimeout (kein Altbeleg)", r, r.st == St::AbortLocked && r.rs == Rs::HomeTimeout && r.entered[(int)St::MeasureG29] == 0, "Altbeleg wurde akzeptiert"); }
  { F f = base(); f.g28 = G28Slow; f.release = false; Run r = run(f); check("D05 G28 dauert endlos: HomeTimeout", r, r.st == St::AbortLocked && r.rs == Rs::HomeTimeout, "Ablauf"); }
  { F f = base(); f.g29 = G29Refuse; f.release = false; Run r = run(f); check("E01 G29 U verweigert: MeshFailed(Preconditions), nichts gespeichert", r, r.st == St::AbortLocked && r.rs == Rs::MeshFailed && r.mf == G29UReceipt::Failure::Preconditions && r.saves == 0, "Ablauf"); }
  for (int k = 0; k < 16; ++k) { char nm[96]; std::snprintf(nm, sizeof nm, "E02 G29 U bricht an Punkt %d ab: MeshFailed, Rollback, nichts gespeichert", k); F f = base(); f.g29 = G29FailAt; f.fail_at = k; f.auto_commit = true; f.release = false; Run r = run(f); check(nm, r, r.st == St::AbortLocked && r.rs == Rs::MeshFailed && r.rolled_back && r.saves == 0 && r.heater_off, "Ablauf"); }
  { F f = base(); f.g29 = G29Never; f.release = false; Run r = run(f); check("E03 G29 U wird nie ausgefuehrt: MeasureTimeout", r, r.st == St::AbortLocked && r.rs == Rs::MeasureTimeout && r.saves == 0, "Ablauf"); }
  { F f = base(); f.g29 = G29Slow; f.release = false; Run r = run(f); check("E04 G29 U dauert endlos: MeasureTimeout", r, r.st == St::AbortLocked && r.rs == Rs::MeasureTimeout, "Ablauf"); }
  { F f = base(); f.leveling_after = false; f.auto_commit = true; f.release = false; Run r = run(f); check("E05 Leveling nach Erfolg nicht aktiv: LevelingInactive, nichts gespeichert", r, r.st == St::AbortLocked && r.rs == Rs::LevelingInactive && r.saves == 0, "Ablauf"); }
  { F f = base(); f.ev = {{60000, 7}}; f.auto_commit = true; f.release = false; Run r = run(f); check("E06 Z-Offset aendert sich VOR der Messung: OffsetChanged, nichts gespeichert", r, r.st == St::AbortLocked && r.saves == 0 && r.rs == Rs::OffsetChanged, "Ablauf"); }
  { F f = base(); f.ev = {{200000, 6}}; f.auto_commit = true; f.release = false; Run r = run(f); check("E07 Werkzeugwechsel waehrend der Messung: abgebrochen, Rollback, nichts gespeichert", r, r.st == St::AbortLocked && r.saves == 0 && r.rolled_back, "Ablauf"); }
  { F f = base(); f.enq_fail_home = true; f.release = false; Run r = run(f); check("D08 G28 konnte nicht eingereiht werden: ActionFailed, Heizung aus, kein Measure", r, r.st == St::AbortLocked && r.rs == Rs::ActionFailed && r.heater_off && r.entered[(int)St::MeasureG29] == 0, "Ablauf"); }
  { F f = base(); f.enq_fail_measure = true; f.release = false; Run r = run(f); check("E09 G29 U konnte nicht eingereiht werden: ActionFailed, Heizung aus, nichts gespeichert", r, r.st == St::AbortLocked && r.rs == Rs::ActionFailed && r.heater_off && r.saves == 0, "Ablauf"); }
  { F f = base(); f.g28 = G28Tool1; f.release = false; Run r = run(f); check("D06 G28 endet mit aktivem Werkzeug T1: HomeFailed", r, r.st == St::AbortLocked && r.rs == Rs::HomeFailed, "Ablauf"); }
  { F f = base(); f.stall_from = 100000; f.stall_ms = 140000; f.release = false; Run r = run(f); check("D07 Tick bleibt 140 s aus (Ende des G28 verpasst): HomeStale", r, r.st == St::AbortLocked && r.rs == Rs::HomeStale && r.entered[(int)St::MeasureG29] == 0, "Ablauf"); }
  { F f = base(); f.g29 = G29Never; f.stale_g29 = true; f.release = false; Run r = run(f); check("E08 ALTER G29-Erfolgsbeleg vorhanden, neuer G29 laeuft nie: MeasureTimeout (kein Altbeleg)", r, r.st == St::AbortLocked && r.rs == Rs::MeasureTimeout && r.saves == 0, "Altbeleg wurde akzeptiert"); }
  { F f = base(); f.busy_start = true; f.release = false; Run r = run(f); check("H01 Warteschlange beim Start belegt: NotIdle, Heizung wird nie eingeschaltet", r, r.st == St::AbortLocked && r.rs == Rs::NotIdle && r.heater_off && r.entered[(int)St::Heat60] == 0, "Ablauf"); }
  { F f = base(); f.printing_start = true; f.release = false; Run r = run(f); check("H02 Druck laeuft beim Start: NotIdle, Heizung wird nie eingeschaltet", r, r.st == St::AbortLocked && r.rs == Rs::NotIdle && r.heater_off && r.entered[(int)St::Heat60] == 0, "Ablauf"); }
  { F f = base(); f.tool1_start = true; f.release = false; Run r = run(f); check("H03 Werkzeug T1 aktiv beim Start: Precondition, Heizung wird NIE eingeschaltet", r, r.st == St::AbortLocked && r.rs == Rs::Precondition && r.heater_off && r.entered[(int)St::Heat60] == 0, "Ablauf"); }
  { F f = base(); f.ev = {{95000, 10}}; f.release = false; f.auto_commit = true; Run r = run(f); check("H04 Fremdbefehl belegt die Maschine genau beim G28-Start: nie zwei Befehle gleichzeitig", r, r.st == St::Done || r.st == St::Idle || r.st == St::AbortLocked, "Ablauf"); }
  { F f = base(); f.clock0 = 0xFFFFFFFFu - 30000u; f.auto_commit = true; Run r = run(f); check("F01 Zeitzaehler laeuft mitten im Ablauf ueber (32 Bit): Ablauf bleibt korrekt", r, r.st == St::Idle && r.saves == 1 && r.commits == 1, "Ueberlauf"); }
  { F f = base(); f.ev = {{200000, 2}, {201000, 3}}; f.auto_commit = true; Run r = run(f); check("F02 Abbruch UND Quittung mitten in G29: Rollback, Freigabe erst bei ruhiger Maschine, Heizung aus", r, r.st == St::Idle && r.rolled_back && r.saves == 0 && r.heater_off && r.released, "Ablauf"); }
  { E eng; E::Obs o; o.now_ms = 1; o.bed_c = 25.0f; o.bed_target_c = 0.0f; o.probe_offset_z = -1.1f; o.stopped = false; o.printing = false; o.motion_queued = false; o.queue_busy = false; o.tool0 = true; o.dual_auto_park = true; bool a = eng.request_start(), b = eng.request_start(); (void)eng.tick(o); Run r; check("F03 zweiter Start wird abgelehnt und beeinflusst den Lauf nicht", r, a && !b && eng.view().duplicate_starts == 1 && eng.state() != St::Idle && eng.state() != St::AbortLocked, "Doppelstart"); }
  { E eng; E::Obs o; Run r; Ac a = eng.tick(o); check("F04 ohne request_start() gibt die Maschine nie eine Aktion aus", r, a == Ac::None && eng.state() == St::Idle && !eng.allow_motion(), "Idle"); }
  // Zeitliche Durchlaeufe: jede Stoerung zu JEDEM Zeitpunkt des Ablaufs (alle 7 s ueber 9 Minuten)
  struct Sw { const char *n; int kind; }; Sw sw[] = {{"Benutzerabbruch", 2}, {"Not-Aus", 1}, {"Druckstart", 0}, {"Fremd-Soll", 4}, {"Sensor-NaN", 5}, {"Werkzeug T1", 6}, {"Offset", 7}, {"Leveling aus", 8}, {"Stromausfall", 9}, {"Fremdbefehl 30 s", 10}};
  for (const Sw &s : sw) { int n = 0, bad = 0; Run worst; for (uint32_t t = 0; t < 540000u; t += 7000u) { for (int ac = 0; ac < 2; ++ac) { F f = base(); f.auto_commit = ac == 1; f.ev = {{t, s.kind}}; Run r = run(f); ++n; if (r.viol || r.saves > 1 || !(r.released || r.st == St::Done || r.st == St::DoneRamOnly || r.st == St::AbortLocked) || (r.saves == 1 && !r.mesh_new)) { ++bad; worst = r; } } } char nm[96]; std::snprintf(nm, sizeof nm, "G %s zu %d Zeitpunkten (je 2 Commit-Einstellungen): Invarianten, Abschluss, EEPROM", s.n, n); check(nm, worst, bad == 0, "Verletzung"); }
  { int n = 0, bad = 0; Run worst; for (uint32_t seed = 1; seed <= 20000u; ++seed) { uint32_t s = seed * 2654435761u; F f; f.rate = (lcg(s) % 4 == 0) ? 0.0f : 0.2f + (float)(lcg(s) % 100) / 100.0f; f.ignore_set = lcg(s) % 12 == 0; f.overshoot = lcg(s) % 15 == 0; f.qdelay = 100 + lcg(s) % 3000; f.g28 = (G28M)(lcg(s) % 5 == 0 ? lcg(s) % 5 : 0); f.g29 = (G29M)(lcg(s) % 5 == 0 ? lcg(s) % 5 : 0); f.fail_at = (int)(lcg(s) % 16);
      f.leveling_after = lcg(s) % 10 != 0; f.commit_supported = lcg(s) % 5 != 0; f.eep = (EepM)(lcg(s) % 6 == 0 ? lcg(s) % 4 : 0); f.auto_commit = lcg(s) % 2; f.confirm = lcg(s) % 2; f.stale_g28 = lcg(s) % 4 == 0; f.clock0 = lcg(s) % 3 == 0 ? 0xFFFFFFFFu - lcg(s) % 400000u : 100000u + lcg(s) % 1000000u; f.release = lcg(s) % 3 != 0; f.g28_ms = 3000 + lcg(s) % 60000; f.g29_pt_ms = 2000 + lcg(s) % 30000;
      int ne = (int)(lcg(s) % 4); uint32_t tt = 0; for (int i = 0; i < ne; ++i) { tt += lcg(s) % 200000u; f.ev.push_back({tt, (int)(lcg(s) % 10)}); }
      E::Config c; if (lcg(s) % 5 == 0) { c.heat_timeout_ms = 30000u + lcg(s) % 100000u; c.home_timeout_ms = 10000u + lcg(s) % 60000u; c.measure_timeout_ms = 30000u + lcg(s) % 200000u; }
      Run r = run(f, c, 2u * 3600u * 1000u); ++n; if ((int)r.st < 16 && (int)r.rs < 24) ++cov[(int)r.st][(int)r.rs]; if (r.saves == 1) ++cov[15][23]; bool term = r.st == St::Done || r.st == St::DoneRamOnly || r.st == St::AbortLocked || r.st == St::Idle; if (r.viol || r.saves > 1 || !term || (r.saves == 1 && !r.mesh_new) || (r.st == St::Idle && !r.heater_off && !r.foreign)) { ++bad; if (!worst.viol && bad == 1) worst = r; if (bad == 1) std::printf("      erste Verletzung bei Seed %u: viol='%s' st=%d rs=%d saves=%d heater_off=%d mesh_new=%d released=%d sim=%u ms | g28=%d g29=%d rate=%.2f ignore=%d stale=%d release=%d events=%d\n", seed, r.v.c_str(), (int)r.st, (int)r.rs, r.saves, r.heater_off, r.mesh_new, r.released, r.sim_ms, (int)f.g28, (int)f.g29, f.rate, f.ignore_set, f.stale_g28, f.release, ne); } }
    char nm[96]; std::snprintf(nm, sizeof nm, "Z Zufallskombinationen aus Fehlern und Ereignissen: %d Laeufe", n); Run z; check(nm, z, bad == 0, "Verletzung"); }
  { int reasons = 0, seen_done = cov[(int)St::Done][0] + cov[(int)St::Idle][0], commits = cov[15][23]; for (int k = 1; k < 22; ++k) if (cov[(int)St::AbortLocked][k] + cov[(int)St::DoneRamOnly][k]) ++reasons; std::printf("      Abdeckung Zufallslaeufe: %d verschiedene Abbruch-/Endgruende, Laeufe mit sauberem Ende %d, Laeufe mit 1 EEPROM-Schreibvorgang %d\n", reasons, seen_done, commits); Run cv; check("Z2 Abdeckung: Zufallslaeufe erreichen viele Endgruende, sauberes Ende und Commit", cv, reasons >= 14 && seen_done > 100 && commits > 100, "Zufallslaeufe laufen zu einseitig"); }
  std::printf("=== %d Pruefungen, %d FAIL\n", total, fails); return fails ? 1 : 0;
}
