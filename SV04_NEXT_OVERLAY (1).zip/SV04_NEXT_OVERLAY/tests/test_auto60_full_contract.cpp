// Model-only dry runs combining time, ownership, homing provenance, G29 receipt,
// RAM mesh integrity and fail-closed future DWIN frame.  NO HARDWARE I/O.
#include "../include/SV04NextOperationLedger.hpp"
#include "../include/SV04NextThermalWitness.hpp"
#include "../include/SV04NextHomingWitness.hpp"
#include "../include/SV04NextG29UReceipt.hpp"
#include "../include/SV04NextReceiptBinder.hpp"
#include "../include/SV04NextMeshIntegrity.hpp"
#include "../include/SV04NextDwinStatusContract.hpp"
#include <cassert>
#include <cstdio>
using namespace sv04next;
static int checks=0;
#define CHECK(X) do{++checks;assert(X);}while(0)
static MeshIntegrity::Mesh original(){
  MeshIntegrity::Mesh s;
  s.z_offset=-1.10f;s.origin_x=s.origin_y=25.f;s.pitch_x=s.pitch_y=80.f;
  for(int j=0;j<16;++j)s.z[j]=(float)j*.004f;
  return s;
}
int main(){
 using O=OperationLedger;using T=ThermalWitness;using H=HomingWitness;
 using R=G29UReceipt;using B=ReceiptBinder;using M=MeshIntegrity;using D=DwinStatusContract;
 for(uint32_t run=1;run<=128;++run){
   O ops;T heater;H homing;R receipt;B binder;M mesh;
   auto stored=original();CHECK(mesh.capture(run,stored));
   O::Live live;live.t1_physically_witnessed=true;live.target_is_60=true;
   O::Ticket t1,t2,t3;
   CHECK(ops.issue(run,O::Step::Heat60,1000,live,t1));
   CHECK(ops.accepted(t1,1100,true,live));
   T::Reading hs;CHECK(heater.begin(run,1100,hs));
   for(uint32_t time=2100;time<=121100;time+=1000){
     hs.actual=25.f+34.f*(float)(time-1100u)/120000.f;
     CHECK(heater.observe(run,time,hs));CHECK(ops.poll(time,live));
   }
   hs.actual=60.f;
   for(uint32_t time=122100;time<=143100;time+=1000){
     CHECK(heater.observe(run,time,hs));CHECK(ops.poll(time,live));
   }
   CHECK(heater.ready(run,143100));live.bed_60_stable=true;
   CHECK(ops.finished(t1,144000,true,live));CHECK(ops.consume(t1));
   CHECK(ops.issue(run,O::Step::HomeXYZ,145000,live,t2));
   CHECK(ops.accepted(t2,145100,true,live));
   H::Native h;h.t1_physical_witness=true;h.bed_60_stable=true;h.homing_epoch=run*2;
   CHECK(homing.begin(run,t2.id,145100,h));
   h.homing_epoch++;h.xyz_homed=true;
   CHECK(homing.finish(run,t2.id,147000,true,h));
   live.xyz_homed_after_command=homing.verified(run,t2.id);
   CHECK(ops.finished(t2,147000,true,live));CHECK(ops.consume(t2));
   CHECK(ops.issue(run,O::Step::ProbeG29U,147100,live,t3));
   CHECK(ops.accepted(t3,147200,true,live));
   CHECK(binder.prepare(run,receipt.sequence()));CHECK(receipt.begin());
   B::Live proof;proof.t1_witness=true;proof.bed_stable_60=true;proof.probe_stowed=true;
   CHECK(binder.observe(run,receipt,proof));
   auto candidate=stored;
   D::Reading reading;reading.active_run=reading.controller_run=reading.receipt_run=run;
   reading.t1_park_proven=reading.probe_stowed=reading.offset_unchanged=reading.temperature_good=true;
   reading.requested=D::Status::Measuring;reading.bed=reading.target=60.f;
   for(uint8_t p=0;p<16;++p){
     const float z=(float)p*.015f;
     CHECK(receipt.point((uint8_t)(p%4),(uint8_t)(p/4),z));
     CHECK(binder.observe(run,receipt,proof));
     reading.mask=receipt.point_mask();reading.z[p]=z;
     auto frame=D::make(reading);
     CHECK(frame.percent<100 || !frame.ram_16_verified);
     CHECK(!frame.ram_16_verified);CHECK(!frame.eeprom_saved);
     candidate.z[p]=z;
   }
   CHECK(receipt.finish_ram_only());CHECK(binder.observe(run,receipt,proof));
   CHECK(binder.ram_complete());
   CHECK(mesh.check_candidate(run,candidate));
   live.native_g29_current_run_complete=binder.ram_complete();
   CHECK(ops.finished(t3,160000,true,live));CHECK(ops.consume(t3));CHECK(ops.finished_ram_only());
   reading.receipt_is_current=reading.controller_ram_complete=true;
   reading.requested=D::Status::RamVerified;
   auto result=D::make(reading);
   CHECK(result.ram_16_verified);CHECK(result.percent==100);CHECK(result.count==16);
   CHECK(!result.eeprom_saved);
   // Independent model: verify an exact RAM rollback on aborted workflow.
   CHECK(mesh.check_restored(run,stored));CHECK(mesh.rollback_verified());
   CHECK(!mesh.enables_eeprom());CHECK(!ops.permits_eeprom());CHECK(!heater.approves_eeprom());
   // Disown any single proof => the UI must refuse green success.
   reading.receipt_run=run+1;
   result=D::make(reading);CHECK(!result.ram_16_verified);CHECK(result.percent<100);
 }
 // Safety adversarial sequences: a heater target change and a missing T1 proof.
 for(uint32_t k=1;k<=256;++k){
  O ops;O::Live s;s.target_is_60=true;s.t1_physically_witnessed=true;
  O::Ticket t;CHECK(ops.issue(k,O::Step::Heat60,0,s,t));
  CHECK(ops.accepted(t,1,true,s));
  if(k%2)s.target_is_60=false;else s.t1_physically_witnessed=false;
  CHECK(!ops.poll(100,s));CHECK(ops.phase()==O::Phase::Locked);
  CHECK(!ops.finished_ram_only());CHECK(!ops.permits_eeprom());
 }
 std::printf("AUTO60 COMPLETE MODEL PASS checks=%d; 128 complete sequences, 256 fault runs; FLASH=0\n",checks);
}
