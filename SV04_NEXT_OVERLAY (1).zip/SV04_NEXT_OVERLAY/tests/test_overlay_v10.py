"""Test v10 patch against the stable OEM fixture and refuse unsafe overlays."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'integration'),str(ROOT/'tests')]
import apply_native_guard_v10 as v10
import test_overlay_v8 as base
src=dict(base.src)
header=lambda x:(ROOT/'include'/x).read_text(encoding='utf-8')
args=[header(x) for x in ('SV04NextNativeThermalGate.hpp','SV04NextVisitProof.hpp',
 'SV04NextG29UReceipt.hpp','SV04NextNativeReadiness.hpp',
 'SV04NextT1EndstopObserver.hpp','SV04NextNativeEventTimeline.hpp')]
out=v10.render(src,*args)
rts=out[v10.RTS]
assert rts.count('native_event_timeline.observe(')==1
assert 'native_readiness.view(), sv04next::t1_endstop_observer' in rts
assert rts.count('native_readiness.observe(')==1
assert rts.count('t1_endstop_observer.observe(')==2
assert rts.count('NativeEventTimeline native_event_timeline;')==1
assert out[v10.TARGET]==args[-1]
assert out['Marlin/Configuration.h']==src['Marlin/Configuration.h']
assert out['Marlin/src/module/probe.cpp']==src['Marlin/src/module/probe.cpp']
assert 'n.physical_t1_park_witness = false;' in rts
assert 'n.probe_stow_witness = false;' in rts
for broken in [
 args[-1].replace('bool allows_motion()const{return false;}','bool allows_motion()const{return true;}'),
 args[-1].replace('frame_.hardware_approved=false;', 'frame_.hardware_approved=true;'),
 args[-1].replace('frame_.physical_t1_proven=false;', 'frame_.physical_t1_proven=true;'),
 args[-1].replace('// SV04 NEXT - native passive event timeline.','// UNKNOWN: HAL')]:
 try:v10.render(src,*args[:-1],broken)
 except v10.PatchRefused:pass
 else:raise AssertionError('dangerous overlay accepted')
try:v10.render(out,*args)
except v10.PatchRefused:pass
else:raise AssertionError('duplicate injection permitted')
print('v10 NativeEventTimeline patch fixture PASS 16+ guards; STM32 build pending')
