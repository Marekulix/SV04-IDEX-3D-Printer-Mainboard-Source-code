#include "../include/SV04NextAbortQuarantine.hpp"
#include <cassert>
#include <cstdio>
using namespace sv04next;
static unsigned checks=0;
#define CHECK(X) do{++checks;assert(X);}while(0)
static AbortQuarantine::Sample safe(){
  AbortQuarantine::Sample s;
  s.valid=true;s.planner_idle=true;s.queue_empty=true;s.movement_idle=true;
  s.probe_stowed=true;s.bed_target_zero=true;s.heater_command_idle=true;
  s.offset_unchanged=true;s.prior_mesh_restored=true;s.t1_physical_park_verified=true;
  return s;
}
static void quiet(AbortQuarantine &q,AbortQuarantine::Token t,uint32_t begin){
  auto s=safe();
  for(uint32_t i=0;i<=20;++i){CHECK(q.sample(t,begin+i*250u,s));}
  CHECK(q.state()==AbortQuarantine::State::StableQuiet);
}
int main(){
  for(uint32_t k=1;k<=1700;++k){
    AbortQuarantine q;
    auto s=safe();
    const uint32_t start=(k%3==0)?0xFFFFF800u:1000u+k;
    CHECK(!q.attach_run(0));CHECK(q.attach_run(k));CHECK(!q.attach_run(k));
    CHECK(!q.abort(0,start,AbortQuarantine::Cause::UserCancel).valid());
    CHECK(!q.abort(k,start,AbortQuarantine::Cause::None).valid());
    auto t=q.abort(k,start,AbortQuarantine::Cause::UserCancel);
    CHECK(t.valid());CHECK(q.blocked());CHECK(!q.stop_has_physically_occurred());
    CHECK(!q.abort(k,start,AbortQuarantine::Cause::UserCancel).valid());
    CHECK(!q.operator_ack(t,start,true));
    auto wrong=t;wrong.run++;CHECK(!q.sample(wrong,start,s));
    quiet(q,t,start);
    CHECK(!q.operator_ack(t,start+5000u,false));
    CHECK(q.operator_ack(t,start+5000u,true));
    CHECK(q.state()==AbortQuarantine::State::OperatorConfirmed);
    CHECK(!q.accepts_old_callback(k));
    CHECK(!q.permits_automatic_restart());CHECK(!q.permits_motion());
    CHECK(!q.permits_heating());CHECK(!q.permits_eeprom());
    CHECK(q.retire(t,start+5000u));CHECK(q.recovery_recorded());
    CHECK(!q.sample(t,start+5250u,s));CHECK(!q.retire(t,start+5250u));
  }
  for(unsigned flag=0;flag<13;++flag){
    AbortQuarantine q;CHECK(q.attach_run(7));auto t=q.abort(7,100,AbortQuarantine::Cause::SensorFault);
    auto s=safe();
    switch(flag){
      case 0:s.valid=false;break;
      case 1:s.printer_stopped=true;break;
      case 2:s.printing=true;break;
      case 3:s.paused=true;break;
      case 4:s.planner_idle=false;break;
      case 5:s.queue_empty=false;break;
      case 6:s.movement_idle=false;break;
      case 7:s.probe_stowed=false;break;
      case 8:s.bed_target_zero=false;break;
      case 9:s.heater_command_idle=false;break;
      case 10:s.offset_unchanged=false;break;
      case 11:s.prior_mesh_restored=false;break;
      case 12:s.t1_physical_park_verified=false;break;
    }
    CHECK(!q.sample(t,100,s));CHECK(q.state()==AbortQuarantine::State::Quarantined);
    CHECK(!q.operator_ack(t,100,true));
    CHECK(q.sample(t,200,safe()));CHECK(q.state()==AbortQuarantine::State::Quarantined);
    CHECK(!q.retire(t,300));
  }
  {AbortQuarantine q;CHECK(q.attach_run(22));auto t=q.abort(22,0,AbortQuarantine::Cause::Unknown);
    CHECK(q.sample(t,0,safe()));CHECK(!q.sample(t,1001,safe()));
    CHECK(q.state()==AbortQuarantine::State::Quarantined);
    CHECK(q.sample(t,1250,safe()));CHECK(q.sample(t,6250,safe())==false);
    CHECK(!q.operator_ack(t,6250,true));
  }
  {AbortQuarantine q;CHECK(q.attach_run(22));auto t=q.abort(22,0,AbortQuarantine::Cause::Unknown);
    quiet(q,t,0);
    CHECK(!q.operator_ack(t,6501,true)); // stale since last reading at 5000
    CHECK(q.sample(t,5100,safe()));CHECK(q.operator_ack(t,5100,true));
    auto s=safe();s.bed_target_zero=false;
    CHECK(!q.sample(t,5350,s));
    CHECK(!q.retire(t,5350));
    quiet(q,t,6000);
    CHECK(q.operator_ack(t,11000,true));
    CHECK(q.retire(t,11000));
  }
  std::printf("ABORT QUARANTINE HOST PASS checks=%u; PHYSICAL_STOP=0 AUTO_RESTART=0 M500=0\n",checks);
}
