#include "../include/SV04NextNativeStatusPacket.hpp"
#include <cassert>
#include <cstdio>
#include <cstring>
#include <initializer_list>
using namespace sv04next;
static unsigned checks=0;
#define CHECK(v) do{++checks;assert(v);}while(0)
typedef NativeEventTimeline::Quality Quality;
typedef NativeStatusPacket::Display D;
typedef NativeStatusPacket::Reason R;
static NativeReadiness::View native(uint32_t now,uint32_t run,uint8_t n,
            uint16_t mask,G29UReceipt::Phase p){
  NativeReadiness::View v;
  v.observed=true;v.last_sample_ms=now;v.g29_run_id=run;
  v.measured=n;v.valid_mask=mask;v.receipt_phase=p;
  v.ram_mesh_16_of_16=(p==G29UReceipt::Phase::RamOnlySuccess && n==16 && mask==0xFFFFu);
  v.gate=NativeReadiness::Gate::NoPhysicalT1Witness;
  return v;
}
static NativeEventTimeline::Frame event(uint32_t now,uint32_t run,uint8_t n,
         uint16_t mask,Quality q=Quality::Fresh,bool success=false){
  NativeEventTimeline::Frame t;
  t.quality=q;t.run=run;t.count=n;t.mask=mask;t.observed_ms=now;
  t.receipt_16_ram=success;t.observations=20;t.electrical_edges=3;
  return t;
}
static uint16_t decode16(const uint8_t *b,unsigned off){return (uint16_t)(b[off]|((uint16_t)b[off+1]<<8));}
int main(){
  NativeStatusPacket pkt;T1EndstopObserver sensor;
  CHECK(!pkt.permits_eeprom());CHECK(!pkt.permits_motion());CHECK(!pkt.permits_heating());
  CHECK(!pkt.is_physical_park_verified());
  const uint32_t now=10000;
  auto v=native(now,0,0,0,G29UReceipt::Phase::Never);
  auto t=event(now,0,0,0);
  pkt.capture(now,v,t,sensor);
  CHECK(pkt.display()==D::Idle);CHECK(pkt.reason()==R::None);
  CHECK(NativeStatusPacket::verify(pkt.bytes(),32));
  CHECK(pkt.bytes()[0]=='S');CHECK(pkt.bytes()[1]=='7');
  CHECK(pkt.bytes()[2]==1);CHECK(pkt.bytes()[3]==32);
  CHECK(pkt.bytes()[22]==4);CHECK(pkt.bytes()[23]==0);
  CHECK(decode16(pkt.bytes(),28)==3);
  CHECK(decode16(pkt.bytes(),30)==NativeStatusPacket::crc16(pkt.bytes(),30));
  v=native(now,1,3,7,G29UReceipt::Phase::Running);t=event(now,1,3,7);
  pkt.capture(now,v,t,sensor);
  CHECK(pkt.display()==D::Measuring);CHECK(pkt.reason()==R::None);
  CHECK(pkt.bytes()[14]==3);CHECK(decode16(pkt.bytes(),12)==7);
  CHECK(pkt.bytes()[22]==4);CHECK(pkt.bytes()[20]==2);
  v=native(now,1,16,0xFFFF,G29UReceipt::Phase::RamOnlySuccess);
  t=event(now,1,16,0xFFFF,Quality::Fresh,true);
  pkt.capture(now,v,t,sensor);
  CHECK(pkt.display()==D::RamComplete);CHECK(pkt.bytes()[22]==5);
  CHECK(!pkt.permits_eeprom());
  t.receipt_16_ram=false;pkt.capture(now,v,t,sensor);
  CHECK(pkt.display()==D::Invalid);CHECK(pkt.reason()==R::InvalidProgress);
  t.receipt_16_ram=true;
  for(Quality q:{Quality::Never,Quality::SourceMissing,Quality::Gap,
                 Quality::ClockBackwards,Quality::CorruptReceipt}){
    t.quality=q;pkt.capture(now,v,t,sensor);
    CHECK(pkt.display()==D::Invalid);
    CHECK((pkt.bytes()[22]&1u)==0u);
  }
  t.quality=Quality::Fresh;
  v.last_sample_ms=now-251;pkt.capture(now,v,t,sensor);
  CHECK(pkt.reason()==R::Stale);CHECK(pkt.display()==D::Invalid);
  v.last_sample_ms=now;t.observed_ms=now-251;pkt.capture(now,v,t,sensor);
  CHECK(pkt.reason()==R::Stale);CHECK(pkt.display()==D::Invalid);
  t.observed_ms=now;
  v.g29_run_id=2;pkt.capture(now,v,t,sensor);
  CHECK(pkt.reason()==R::CrossRun);CHECK(pkt.display()==D::Invalid);
  v.g29_run_id=1;v.valid_mask=0x7FFF;
  pkt.capture(now,v,t,sensor);CHECK(pkt.reason()==R::CrossRun);
  v.valid_mask=0xFFFF;
  pkt.capture(now,v,t,sensor);CHECK(pkt.display()==D::RamComplete);
  v.observed=false;pkt.capture(now,v,t,sensor);
  CHECK(pkt.reason()==R::NotObserved);v.observed=true;
  for(G29UReceipt::Phase p:{G29UReceipt::Phase::Failed,G29UReceipt::Phase::Refused}){
    v.receipt_phase=p;pkt.capture(now,v,t,sensor);
    CHECK(pkt.display()==(p==G29UReceipt::Phase::Failed?D::Failed:D::Refused));
  }
  v.receipt_phase=G29UReceipt::Phase::RamOnlySuccess;
  // All masks, including 0xFFFF: a mismatched count may never yield green.
  for(uint32_t m=0;m<65536u;++m){
    v.valid_mask=(uint16_t)m;t.mask=(uint16_t)m;
    v.measured=t.count=16;
    v.ram_mesh_16_of_16=true;t.receipt_16_ram=true;
    pkt.capture(now,v,t,sensor);
    CHECK(NativeStatusPacket::verify(pkt.bytes(),32));
    CHECK(pkt.display()==(m==65535u?D::RamComplete:D::Invalid));
    CHECK(!pkt.permits_motion());
    CHECK(!pkt.permits_eeprom());
  }
  // Corruption: every changed payload byte must fail CRC, even on reserved.
  v.valid_mask=t.mask=0xFFFF;
  pkt.capture(now,v,t,sensor);
  for(unsigned i=0;i<32;++i){
    uint8_t copy[32];std::memcpy(copy,pkt.bytes(),32);
    copy[i]^=0x01u;
    CHECK(!NativeStatusPacket::verify(copy,32));
  }
  CHECK(!NativeStatusPacket::verify(nullptr,32));
  CHECK(!NativeStatusPacket::verify(pkt.bytes(),31));
  // A plausible CRC alone must not bless contradictory semantics.
  uint8_t forged[32];std::memcpy(forged,pkt.bytes(),32);
  forged[20]=(uint8_t)D::Measuring; // claims measuring while success flag remains set
  const uint16_t forged_crc=NativeStatusPacket::crc16(forged,30);
  forged[30]=(uint8_t)forged_crc;forged[31]=(uint8_t)(forged_crc>>8);
  CHECK(!NativeStatusPacket::verify(forged,32));
  // no premature freshness loss across the uint32 uptime rollover
  v=native(0xFFFFFFF0u,2,0,0,G29UReceipt::Phase::Running);
  t=event(0xFFFFFFF0u,2,0,0);
  pkt.capture(0x00000020u,v,t,sensor);
  CHECK(pkt.display()==D::Measuring);
  // Unknown uptime or reversed samples beyond half range cannot look fresh.
  pkt.capture(0xFFFFFFE0u,native(0x20,2,0,0,G29UReceipt::Phase::Running),
              event(0x20,2,0,0),sensor);
  CHECK(pkt.display()==D::Invalid);
  printf("NATIVE STATUS SNAPSHOT PASS checks=%u (RAM ONLY, NO DWIN, NO ACTUATION)\n",checks);
}
