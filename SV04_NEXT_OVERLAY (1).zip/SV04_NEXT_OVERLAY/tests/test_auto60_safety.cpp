#include "../include/SV04NextAuto60Safety.hpp"
#include <cassert>
#include <cmath>
#include <iostream>
#include <limits>

using A = sv04next::Auto60Safety;
static unsigned checks = 0;
#define CHECK(x) do { assert(x); ++checks; } while (0)

static A ready_to_probe() {
  A a;
  CHECK(a.start(true,true,true,true,true));
  CHECK(a.temperature(60.0f,55,30));
  CHECK(a.begin_homing());
  CHECK(a.homing_finished(true,true,true));
  CHECK(a.begin_mesh(true,true,true));
  return a;
}

static A complete_mesh() {
  A a = ready_to_probe();
  for (unsigned i=0; i<A::kPoints; ++i) {
    CHECK(a.probe_sample(static_cast<uint8_t>(i), 0.100f+i*0.001f,true,true));
    CHECK(a.probe_sample(static_cast<uint8_t>(i), 0.102f+i*0.001f,true,true));
  }
  CHECK(a.completed_points()==16);
  CHECK(a.completed_samples()==0);
  CHECK(a.mesh_finished(true,true,true,true,true,true));
  return a;
}

int main() {
  {
    A a;
    CHECK(!a.allow_m500());
    CHECK(!a.start(false,true,true,true,true));
    CHECK(a.fault()==A::Fault::UnsafeStart);
    CHECK(!a.allow_m500());
  }
  for(unsigned missing=0; missing<5; ++missing) {
    A a;
    bool flags[5] = {true,true,true,true,true}; flags[missing]=false;
    CHECK(!a.start(flags[0], flags[1], flags[2], flags[3], flags[4]));
    CHECK(a.state()==A::State::Failed);
  }
  {
    A a; CHECK(a.start(true,true,true,true,true));
    CHECK(!a.temperature(std::numeric_limits<float>::quiet_NaN(), 20, 0));
    CHECK(a.fault()==A::Fault::InvalidTemperature);
  }
  {
    A a; CHECK(a.start(true,true,true,true,true));
    CHECK(!a.temperature(65,20,0));
  }
  {
    A a; CHECK(a.start(true,true,true,true,true));
    CHECK(!a.temperature(58,1201,0));
    CHECK(a.fault()==A::Fault::HeaterTimeout);
  }
  {
    A a; CHECK(a.start(true,true,true,true,true));
    CHECK(a.temperature(60,30,29));
    CHECK(a.state()==A::State::Heating);
    CHECK(a.temperature(60,31,30));
    CHECK(a.state()==A::State::ReadyForHoming);
    CHECK(!a.allow_m500());
  }
  {
    A a; CHECK(a.start(true,true,true,true,true));
    CHECK(a.temperature(60,40,30)); CHECK(a.begin_homing());
    CHECK(!a.homing_finished(true,false,true));
    CHECK(a.fault()==A::Fault::HomingFailed);
  }
  {
    A a = ready_to_probe(); CHECK(a.completed_points()==0);
    CHECK(a.rollback_ram_mesh_required());
    CHECK(!a.allow_m500());
    CHECK(!a.probe_sample(1,0,true,true));
    CHECK(a.fault()==A::Fault::ProbeOutOfOrder);
    CHECK(a.rollback_ram_mesh_required());
  }
  {
    A a = ready_to_probe();
    CHECK(!a.probe_sample(0,4.0f,true,true));
    CHECK(a.fault()==A::Fault::ProbeRange);
  }
  {
    A a = ready_to_probe();
    CHECK(!a.probe_sample(0,0.0f,false,true));
    CHECK(a.fault()==A::Fault::ProbeFailed);
  }
  {
    A a = ready_to_probe();
    CHECK(a.probe_sample(0,0.0f,true,true));
    CHECK(!a.probe_sample(0,0.2f,true,true));
    CHECK(a.fault()==A::Fault::ProbeDisagreement);
    CHECK(!a.allow_m500());
  }
  {
    A a = ready_to_probe();
    CHECK(a.probe_sample(0,0.1f,true,true));
    CHECK(a.completed_samples()==1);
    CHECK(!a.mesh_finished(true,true,true,true,true,true));
    CHECK(a.fault()==A::Fault::MeshIncomplete);
  }
  {
    A a = ready_to_probe();
    for (unsigned i=0; i<A::kPoints; ++i) {
      CHECK(a.probe_sample(static_cast<uint8_t>(i), 0.10f, true, true));
      CHECK(a.probe_sample(static_cast<uint8_t>(i), 0.10f, true, true));
    }
    CHECK(!a.probe_sample(16, 0.10f, true, true)); // no out-of-bounds point[16]
    CHECK(a.fault()==A::Fault::ProbeOutOfOrder);
    CHECK(!a.allow_m500());
  }
  {
    A a = complete_mesh();
    CHECK(a.allow_m500());
    CHECK(std::fabs(a.point_z(0)-0.101f)<0.0001f);
    CHECK(!std::isfinite(a.point_z(16)));
    CHECK(a.begin_persist());
    CHECK(!a.allow_m500());
    CHECK(a.eeprom_may_have_changed());
    CHECK(a.persist_returned(true));
    CHECK(a.verify_saved(true));
    CHECK(a.state()==A::State::Complete);
    CHECK(!a.rollback_ram_mesh_required());
    CHECK(!a.eeprom_may_have_changed());
  }
  {
    A a = complete_mesh();
    CHECK(a.begin_persist());
    CHECK(!a.persist_returned(false));
    CHECK(a.fault()==A::Fault::PersistFailed);
    CHECK(a.eeprom_may_have_changed());
    CHECK(a.rollback_ram_mesh_required());
  }
  {
    A a = complete_mesh();
    CHECK(a.begin_persist());
    CHECK(a.persist_returned(true));
    CHECK(!a.verify_saved(false));
    CHECK(a.fault()==A::Fault::EepromVerificationFailed);
    CHECK(a.eeprom_may_have_changed());
    CHECK(a.rollback_ram_mesh_required());
  }
  {
    A a = complete_mesh();
    a.cancel();
    CHECK(a.state()==A::State::Cancelled);
    CHECK(!a.allow_m500());
    CHECK(a.rollback_ram_mesh_required());
    CHECK(!a.begin_persist());
  }
  {
    A a = ready_to_probe();
    a.cancel();
    CHECK(a.state()==A::State::Cancelled);
    CHECK(!a.allow_m500());
  }
  std::cout << "SV04 NEXT 10.27: " << checks << " host safety assertions PASS. No hardware calls. NICHT FLASHEN.\n";
}
