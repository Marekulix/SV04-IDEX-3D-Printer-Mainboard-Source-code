#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 tests/test_overlay_v14.py
python3 tests/test_overlay_v15.py
for opt in 0 2; do
  for name in audit11_negative; do
    g++ -std=c++11 -O"${opt}" -Wall -Wextra -Werror -pedantic "tests/test_${name}.cpp" -o "/tmp/sv04-11-${name}-${opt}"
    "/tmp/sv04-11-${name}-${opt}"
  done
done
g++ -std=c++11 -O1 -g -fsanitize=address,undefined -fno-sanitize-recover=all -Wall -Wextra -Werror -pedantic tests/test_audit11_negative.cpp -o /tmp/sv04-11-neg-asan
/tmp/sv04-11-neg-asan
for fl in "-O0" "-O2 -ffast-math" "-O2 -ffinite-math-only -fno-math-errno"; do
  g++ -std=c++11 $fl -Wall -Wextra -Werror -pedantic tests/test_fastmath_native_guard.cpp -o /tmp/sv04-11-fm
  /tmp/sv04-11-fm
done
echo 'BLOCK 11 FOCUSED REGRESSION PASS (host only; STM32 build NOT run)'
