#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 harness/run_harness.py
if python3 -c "import yaml" 2>/dev/null; then python3 ci/test_workflows.py; else echo "NOT_RUN: PyYAML fehlt"; fi
echo 'BLOCK 12 PASS (Host-Simulation; Marlin-Build NOT run)'
