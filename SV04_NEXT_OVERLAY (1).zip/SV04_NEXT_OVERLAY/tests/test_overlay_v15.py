"""apply_native_guard_v15.apply() wird hier TATSÄCHLICH ausgeführt (die Tests v7 bis v14 haben apply() nie aufgerufen).
Synthetische OEM-Wurzel aus den Fixtures der Lieferung (KEIN echtes OEM); OEM_BLOBS werden auf deren Hashes gesetzt."""
import contextlib, hashlib, io, os, sys, tempfile
from pathlib import Path
root = Path(__file__).resolve().parents[1]; sys.path[:0] = [str(root / 'integration'), str(root / 'tests')]
with contextlib.redirect_stdout(io.StringIO()): import test_overlay_v14 as T
import apply_native_guard_v15 as v15
v14 = T.v14; src = dict(T.src); names = list(v14.OEM_BLOBS); HEAD = [root / 'include' / n for n in v15.HEADERS]
blob = lambda b: hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
def make(tf=lambda n, t: t.encode('utf-8')):
    d = Path(tempfile.mkdtemp()); shas = {}
    for n in names: p = d / n; p.parent.mkdir(parents=True, exist_ok=True); b = tf(n, src[n]); p.write_bytes(b); shas[n] = blob(b)
    v14.OEM_BLOBS = shas; return d
def tree(d): return {str(p.relative_to(d)): p.read_bytes() for p in sorted(d.rglob('*')) if p.is_file()}
def refuses(fn, *words):
    try: fn()
    except v15.PatchRefused as e:
        assert all(w in str(e) for w in words), (words, str(e)); return str(e)
    raise AssertionError('Patch hätte verweigert werden müssen: ' + str(words))
n_checks = 0
def ck(c, msg=''):
    global n_checks
    assert c, msg; n_checks += 1
# 1 Normalfall
d = make(); before = tree(d); rep = v15.apply(d, HEAD, d / 'ev.json'); after = tree(d)
changed = sorted(k for k in before if before[k] != after.get(k)); ck(len(changed) == 3, changed); ck(all(before[n] == after[n] for n in ('Marlin/Configuration.h', 'Marlin/src/module/probe.cpp')))
new = sorted(k for k in after if k not in before and k.endswith('.hpp')); ck(len(new) == 14, len(new)); ck('Marlin/src/feature/sv04_next/SV04NextSafeFloat.hpp' in new)
ck(rep['automatic_motion'] is False and rep['eeprom_write'] is False and rep['flash_approved'] is False and rep['stm32_build'] is False); ck(not any(k.startswith('.sv04tmp') or '.sv04tmp-' in k for k in after), 'Temp-Reste')
ck(not [k for k in after if '.sv04tmp-' in k])
# 2 erneutes Anwenden und SHA-Abweichung
refuses(lambda: v15.apply(d, HEAD), 'SHA mismatch')
d2 = make(); (d2 / names[2]).write_bytes((d2 / names[2]).read_bytes() + b'\n// Drift\n'); b2 = tree(d2); refuses(lambda: v15.apply(d2, HEAD), 'SHA mismatch'); ck(tree(d2) == b2)
# 3 dry-run schreibt nichts, diff-out zeigt genau die drei OEM-Dateien
d3 = make(); b3 = tree(d3); r3 = v15.apply(d3, HEAD, d3 / 'never.json', dry_run=True, diff_out=d3 / 'review.diff'); a3 = tree(d3); ck(r3['dry_run'] is True and 'review.diff' in a3 and 'never.json' not in a3)
ck({k for k in a3 if k not in b3} == {'review.diff'}); dtext = a3['review.diff'].decode(); ck(dtext.count('\n+++ b/') + (1 if dtext.startswith('--- a/') else 0) >= 3 and 'Configuration.h' not in dtext and 'probe.cpp' not in dtext)
# 4 Kodierung und Zeilenenden: klare Meldung, nichts verändert
d4 = make(lambda n, t: (t + '\n// ' + '注释').encode('gbk') if n.endswith('LCD_RTS.cpp') else t.encode('utf-8')); b4 = tree(d4); m = refuses(lambda: v15.apply(d4, HEAD), 'LCD_RTS.cpp', 'UTF-8'); ck(tree(d4) == b4)
d5 = make(lambda n, t: t.replace('\n', '\r\n').encode('utf-8')); b5 = tree(d5); refuses(lambda: v15.apply(d5, HEAD), 'CRLF'); ck(tree(d5) == b5)
# 5 Atomarität: Fehler an JEDER Position der Ersetzungsfolge -> Wurzel byte-identisch, keine Temp-Reste
real_replace = os.replace; total = 17   # 3 OEM-Dateien + 14 Header
for k in range(1, total + 1):
    dk = make(); bk = tree(dk); cnt = {'n': 0}
    def flaky(a, b, _c=cnt):
        _c['n'] += 1
        if _c['n'] == k: raise OSError('Fehler beim Ersetzen Nr. %d (simuliert)' % k)
        return real_replace(a, b)
    os.replace = flaky
    try: v15.apply(dk, HEAD, dk / 'ev.json'); raise AssertionError('kein Fehler bei k=%d' % k)
    except OSError: pass
    finally: os.replace = real_replace
    ak = tree(dk); ck(ak == bk, 'k=%d: Wurzel nicht zurückgesetzt: %s' % (k, sorted(set(ak) ^ set(bk))[:3]))
v14.OEM_BLOBS = {n: blob(bk[n]) for n in names}; v15.apply(dk, HEAD); ck(True)   # nach dem Rollback ist ein sauberer Neuversuch möglich
# 6 Vertragsprüfungen der Header
args = [p.read_text(encoding='utf-8') for p in HEAD]
bad = list(args); bad[-1] = bad[-1].replace('!= 0xFFu', '!= 0xFEu') if False else bad[-1].replace('return ((bits >> 23) & 0xFFu) != 0xFFu;', 'return true; // 0xFFu memcpy float_is_finite'); d6 = make(); orig6 = {n: (d6 / n).read_text() for n in names}
# (die Vertragsprüfung ist textbasiert; hier prüfen wir die zusätzlichen Schutzregeln der native-Header)
re_isf = list(args); idx = v15.HEADERS.index('SV04NextG29UReceipt.hpp'); re_isf[idx] = re_isf[idx].replace('float_is_finite(z)', 'isfinite(z)'); refuses(lambda: v15.render(orig6, *re_isf), 'isfinite')
refuses(lambda: v15.render(orig6, *args[:13]), '14 headers')
d7 = make(); (d7 / 'Marlin/src/feature/sv04_next').mkdir(parents=True); (d7 / 'Marlin/src/feature/sv04_next/SV04NextSafeFloat.hpp').write_text('x'); b7 = tree(d7); refuses(lambda: v15.apply(d7, HEAD), 'already exists'); ck(tree(d7) == b7)
print('PASS v15 apply() atomic + dry-run + encoding/CRLF refusal + rollback at every position; checks=%d; firmware build NOT run' % n_checks)
