// Standalone host model of G29 U scope + rollback semantics. NOT Marlin firmware.
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <cstdio>

static uint32_t checks=0;
static void check(bool value) { assert(value); ++checks; }
struct Model {
  float z[4][4];
  float start[2], spacing[2];
  float z_offset;
  bool enabled;
  bool diagnostic_active;
  uint32_t eeprom_writes;
};
struct ScopedMode {
  Model& m;
  bool previous;
  ScopedMode(Model&v):m(v),previous(v.diagnostic_active){m.diagnostic_active=true;}
  ~ScopedMode(){m.diagnostic_active=previous;}
};
struct Transaction {
  Model& target;
  float oldz[4][4], old_start[2], old_spacing[2];
  float zoffset;
  bool prev_enabled, active;
  explicit Transaction(Model&v):target(v),zoffset(v.z_offset),prev_enabled(v.enabled),active(true) {
    memcpy(oldz,v.z,sizeof oldz);memcpy(old_start,v.start,sizeof old_start);
    memcpy(old_spacing,v.spacing,sizeof old_spacing);
  }
  void revert(){
    if (!active) return;
    active=false;
    target.enabled=false;
    memcpy(target.z,oldz,sizeof oldz);
    memcpy(target.start,old_start,sizeof old_start);
    memcpy(target.spacing,old_spacing,sizeof old_spacing);
    target.enabled=prev_enabled;
  }
  void accept(){active=false;}
  ~Transaction(){revert();}
};
static Model make_model(bool leveling){
  Model m={};
  for(int i=0;i<4;++i)for(int j=0;j<4;++j)m.z[i][j]=(i*4+j)*0.01f;
  m.start[0]=25.f;m.start[1]=25.f;
  m.spacing[0]=84.f;m.spacing[1]=84.f;
  m.z_offset=-1.10f;
  m.enabled=leveling; m.diagnostic_active=false;
  return m;
}
// Simulate success, early failures after 0..16 points, offset interference,
// nonfinite/unstable measurements, and the scoped mode reset on return.
static bool simulate(Model&m, int fail_at, bool bad_offset, bool nonfinite, bool bad_pair){
  if(m.diagnostic_active)return false;
  ScopedMode scoped(m);
  Transaction tx(m);
  m.enabled=false;
  m.start[0]=28.f;m.spacing[1]=79.f;
  int complete=0;
  for (int i=0;i<16;++i){
    if(i==fail_at)return false;
    float fast=0.12f+i*.01f, slow=fast+.015f;
    if(nonfinite && i==7)fast=NAN;
    if(bad_pair && i==7)slow+=.10f;
    if(!std::isfinite(fast)||!std::isfinite(slow)||fabsf(fast-slow)>0.06f)return false;
    m.z[i/4][i%4]=(.4f*fast+.6f*slow);
    ++complete;
  }
  if(bad_offset)m.z_offset=-1.11f;
  if(!std::isfinite(m.z_offset)||fabsf(m.z_offset-tx.zoffset)>0.00001f||complete!=16)return false;
  m.enabled=true;
  tx.accept();
  return true;
}
int main(){
 for(int level=0;level<2;++level){
   for(int fail=0;fail<16;++fail){
      Model m=make_model(level!=0), original=m;
      bool ok=simulate(m,fail,false,false,false);
      check(!ok);check(!m.diagnostic_active);
      check(m.enabled==original.enabled);
      check(memcmp(m.z,original.z,sizeof m.z)==0);
      check(memcmp(m.start,original.start,sizeof m.start)==0);
      check(memcmp(m.spacing,original.spacing,sizeof m.spacing)==0);
      check(m.z_offset==original.z_offset);check(m.eeprom_writes==0);
   }
   for(int scenario=0;scenario<3;++scenario){
     Model m=make_model(level!=0), original=m;
     check(!simulate(m,-1,scenario==0,scenario==1,scenario==2));
     check(memcmp(m.z,original.z,sizeof m.z)==0);
     check(memcmp(m.start,original.start,sizeof m.start)==0);
     check(memcmp(m.spacing,original.spacing,sizeof m.spacing)==0);
     check(m.enabled==original.enabled);
     check(m.eeprom_writes==0);
     check(!m.diagnostic_active);
   }
   Model m=make_model(level!=0), old=m;
   check(simulate(m,-1,false,false,false));
   check(!m.diagnostic_active);
   check(m.enabled);
   check(memcmp(m.z,old.z,sizeof m.z)!=0);
   check(m.eeprom_writes==0);
   m.diagnostic_active=true;
   Model before=m;
   check(!simulate(m,-1,false,false,false));
   check(memcmp(&m,&before,sizeof m)==0);
 }
 printf("SV04 NEXT G29 U ROLLBACK MODEL PASS: %u checks; no firmware compiled\n",checks);
}
