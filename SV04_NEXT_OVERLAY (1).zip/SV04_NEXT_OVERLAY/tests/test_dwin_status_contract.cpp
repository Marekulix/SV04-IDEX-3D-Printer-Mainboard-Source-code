#include "../include/SV04NextDwinStatusContract.hpp"
#include <cassert>
#include <cstdio>
#include <limits>
using namespace sv04next;
static int checks=0;
#define CHECK(X) do{++checks;assert(X);}while(0)
int main(){using D=DwinStatusContract;
 for(uint32_t k=0;k<65536u;++k){
  D::Reading r;r.active_run=10;r.controller_run=10;r.receipt_run=10;
  r.receipt_is_current=r.controller_ram_complete=r.t1_park_proven=true;
  r.probe_stowed=r.offset_unchanged=r.temperature_good=true;
  r.requested=D::Status::RamVerified;r.mask=(uint16_t)k;
  for(int i=0;i<16;++i)r.z[i]=(float)i*.01f;
  auto x=D::make(r);
  CHECK(x.ram_16_verified==(k==65535u));
  CHECK(x.percent==(k==65535u?100:((__builtin_popcount(k)*100)/16>99?99:__builtin_popcount(k)*100/16)));
  CHECK(!x.eeprom_saved);
  if(k!=65535u)CHECK(x.status==D::Status::Interlock);
  if(k==65535u)for(int i=0;i<16;++i)CHECK(x.cells[i]==D::Shade::Validated);
 }
 for(int n=0;n<7;++n){
  D::Reading r;r.active_run=r.controller_run=r.receipt_run=1;
  r.requested=D::Status::RamVerified;r.mask=0xFFFFu;
  r.receipt_is_current=r.controller_ram_complete=r.t1_park_proven=true;
  r.probe_stowed=r.offset_unchanged=r.temperature_good=true;
  switch(n){case 0:r.receipt_run=2;break;case 1:r.t1_park_proven=false;break;
   case 2:r.probe_stowed=false;break;case 3:r.offset_unchanged=false;break;
   case 4:r.temperature_good=false;break;case 5:r.z[5]=std::numeric_limits<float>::quiet_NaN();break;
   default:r.receipt_is_current=false;break;}
  auto x=D::make(r);CHECK(!x.ram_16_verified);CHECK(x.percent<100);
 }
 CHECK(D::german(D::Status::Measuring)!=nullptr);
 CHECK(!D::writes_hmi());CHECK(!D::commands_motion());CHECK(!D::auto_saves());
 std::printf("DWIN-STATUS PASS checks=%d; no VP writes, no false green\n",checks);
}
