"""v8 host-based source patch assertions against v7 exact synthetic fixtures."""
from __future__ import annotations
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'integration'),str(ROOT/'tests')]
import apply_native_guard_v8 as v8
import test_overlay_v6 as f
checks=0
def ck(value,what):
 global checks
 assert value,what
 checks+=1
src=dict(f.source)
thermal=(ROOT/'include/SV04NextNativeThermalGate.hpp').read_text()
visit=(ROOT/'include/SV04NextVisitProof.hpp').read_text()
receipt=(ROOT/'include/SV04NextG29UReceipt.hpp').read_text()
native=(ROOT/'include/SV04NextNativeReadiness.hpp').read_text()
out=v8.render(src,thermal,visit,receipt,native)
rts=out[v8.RTS]
g='Marlin/src/gcode/bedlevel/abl/G29.cpp'
ck(out['Marlin/Configuration.h']==src['Marlin/Configuration.h'],'original config')
ck(out['Marlin/src/module/probe.cpp']==src['Marlin/src/module/probe.cpp'],'original probe')
ck(out[v8.NATIVE_TARGET]==native,'header copied')
ck('NativeReadiness native_readiness' in rts,'native singleton')
ck('native_readiness.observe((uint32_t)millis(), n, sv04next::g29u_receipt)' in rts,'wired to OEM RTS loop')
ck('n.physical_t1_park_witness = false' in rts,'no invented park proof')
ck('n.probe_stow_witness = false' in rts,'no invented probe proof')
ck('n.printing = printJobOngoing() || printingIsPaused()' in rts,'paused jobs considered')
ck('n.motion_queued = planner.has_blocks_queued()' in rts,'native planner state')
ck('n.xyz_trusted = axis_is_trusted(X_AXIS)' in rts,'native trust bits')
ck('n.t1_x = inactive_extruder_x;' in rts,'software T1 X')
ck('n.bed_c = thermalManager.degBed()' in rts,'real bed temp')
ck('n.probe_offset_z = probe.offset.z' in rts,'real offset read-only')
ck('setTargetBed(' not in rts[rts.index('void RTSUpdate()'):rts.index('void RTSUpdate()')+2100],'no heater control at hook')
ck('settings.save()' not in out[g] and 'M500' not in out[g],'G29 unchanged persist invariant')
ck('g29u_receipt.finish_ram_only()' in out[g],'receipt lifecycle preserved')
ck('SV04NextNativeReadiness.hpp' in rts,'native header included')
ck(rts.count('native_readiness.observe(')==1,'exactly once hook')
for bad in (native.replace('allow_eeprom_save() const { return false;', 'allow_eeprom_save() const { return true;'),
            native.replace('physical_t1_park_witness = false;','physical_t1_park_witness = true;')):
 try: v8.render(src,thermal,visit,receipt,bad)
 except v8.PatchRefused: ck(True,'unsafe implementation rejected')
 else:raise AssertionError('unsafe implementation accepted')
try:v8.render(out,thermal,visit,receipt,native)
except v8.PatchRefused:ck(True,'double patch forbidden')
else: raise AssertionError('double patch accepted')
print('v8 overlay native source checks PASS',checks)
