#include "../include/SV04NextSequencedController.hpp"
#include <cstdio>
#include <cassert>
#include <cstring>
#include <limits>
using C=sv04next::SequencedController;
static unsigned checks=0;
#define CK(x) do { ++checks; if(!(x)){std::fprintf(stderr,"FAILED %s:%d %s\n",__FILE__,__LINE__,#x);std::abort();} }while(0)
#include <cstdlib>
static C::Inputs facts(){
  C::Inputs v; v.t1_homed=true;v.t1_park_physically_confirmed=true;
  v.auto_park_mode=true;v.probe_stowed=true;v.t0_active=true;
  v.zoffset=-1.10f;return v;
}
static C::MeshSnapshot mesh(){
  C::MeshSnapshot m;
  for(int i=0;i<16;++i)m.z[i]=0.031f*i;
  m.zoffset=-1.10f;m.origin_x=25.f;m.origin_y=25.f;
  m.pitch_x=84.f;m.pitch_y=84.f;m.leveling_enabled=true;return m;
}
struct Fixture {
  C c; C::Inputs v=facts(); uint32_t token=0;
  Fixture(){CK(c.load_snapshot(mesh())); auto cmd=c.start(1000u,v);
    CK(cmd.action==C::Action::Heat60);token=cmd.token;CK(token!=0);}
  void heat(){
    v.setpoint=60.f;
    auto cmd=c.acknowledge_heat(token,1001,true,v);
    CK(cmd.action==C::Action::None);CK(c.state()==C::State::Heating);
    v.bed=60.f;
    CK(c.poll(1002,v).action==C::Action::None);
  }
  void homing(){heat();auto cmd=c.poll(21003,v);
    CK(cmd.action==C::Action::HomeXYZ);
    CK(c.state()==C::State::Homing);
  }
  void probing(){homing();v.xyz_homed=true;
    auto cmd=c.homing_complete(token,21100,true,v);
    CK(cmd.action==C::Action::ProbeG29U);
    CK(c.state()==C::State::Probing);
  }
  void measured(unsigned n=16){for(unsigned i=0;i<n;++i){
    CK(c.probe_sample(token,(uint8_t)i,0.11f*i,0.11f*i+.01f,v,21101u+i));
  }}
  C::Request quiesce(){
    C::Request q=c.quiesced(token,v);
    CK(q.action==C::Action::RestoreOldRam);
    CK(c.state()==C::State::RestoringRam);
    return q;
  }
};
int main(){
  // 10.73: Snapshot capture and strict 4x4 geometry
  { C c; C::MeshSnapshot m=mesh();m.pitch_x=0;CK(!c.load_snapshot(m));m=mesh();CK(c.load_snapshot(m)); }
  // 10.74: Heat command exactly once, explicit acknowledgement
  { Fixture f;CK(f.c.poll(1003,f.v).action==C::Action::None);f.heat();CK(f.c.poll(1004,f.v).action==C::Action::None); }
  // 10.75: Print/pause/motion preflight denial
  for(int n=0;n<6;++n){ C c; auto v=facts();
    if(n==0)v.print_active=true;
    if(n==1)v.print_paused=true;
    if(n==2)v.motion_active=true;
    if(n==3)v.queued_gcode=true;
    if(n==4)v.marlin_stopped=true;
    if(n==5)v.probe_stowed=false;
    CK(c.load_snapshot(mesh()));CK(c.start(4,v).action==C::Action::None);
    CK(c.state()==C::State::Failed);
  }
  // 10.76: Ack timeout and decline
  { Fixture f;auto req=f.c.poll(31005,f.v);CK(req.action==C::Action::RequestSafeStop);CK(f.c.error()==C::Error::HeatAckTimeout); }
  { Fixture f;CK(f.c.acknowledge_heat(f.token,1010,false,f.v).action==C::Action::RequestSafeStop); }
  // 10.77: Stable bed requires unbroken 20-second window
  { Fixture f;f.heat();f.v.bed=58.0f;CK(f.c.poll(19000,f.v).action==C::Action::None);
    f.v.bed=60.f;CK(f.c.poll(19500,f.v).action==C::Action::None);
    CK(f.c.poll(39501,f.v).action==C::Action::HomeXYZ);
  }
  // 10.78: Heater timeout 12 minutes
  { Fixture f;f.v.setpoint=60;CK(f.c.acknowledge_heat(f.token,1010,true,f.v).action==C::Action::None);
    CK(f.c.poll(722000,f.v).action==C::Action::RequestSafeStop);
    CK(f.c.error()==C::Error::HeatTimeout);
  }
  // 10.79: Confirm homing and reject stale finish
  { Fixture f;f.homing();CK(f.c.homing_complete(f.token+1,21200,true,f.v).action==C::Action::None);
    CK(f.c.homing_complete(f.token,21200,false,f.v).action==C::Action::RequestSafeStop);
  }
  // 10.80: T1 physically-parked external fact never inferred from x-position
  { C c;auto v=facts();v.t1_park_physically_confirmed=false;CK(c.load_snapshot(mesh()));
    CK(c.start(5,v).action==C::Action::None);
    CK(c.error()==C::Error::UnsafeT1);CK(!c.has_verified_physical_park());
  }
  // 10.81: user cancel suppresses subsequent callbacks
  { Fixture f;f.probing();CK(f.c.cancel(f.token).action==C::Action::RequestSafeStop);
    CK(!f.c.probe_sample(f.token,0,0,0,f.v,21102));CK(f.c.error()==C::Error::UserCancel);
  }
  // 10.82: BLTouch fault forces stop
  { Fixture f;f.probing();f.v.bltouch_healthy=false;
    CK(!f.c.probe_sample(f.token,0,0,0,f.v,21102));CK(f.c.state()==C::State::Quiescing);
  }
  // 10.83: Strict 0-15 sample index and no 17th sample
  { Fixture f;f.probing();CK(!f.c.probe_sample(f.token,1,0,0,f.v,21102));CK(f.c.error()==C::Error::SampleOrder); }
  { Fixture f;f.probing();f.measured();CK(!f.c.probe_sample(f.token,16,0,0,f.v,21102));CK(f.c.error()==C::Error::SampleOrder); }
  // 10.84: Diff >0.06, NaN, Inf, large magnitude
  for(int n=0;n<4;++n){Fixture f;f.probing();
    float fast=n==0?0.0f:n==1?NAN:n==2?INFINITY:3.1f;
    float slow=n==0?0.061f:0.0f;
    CK(!f.c.probe_sample(f.token,0,fast,slow,f.v,21102));
    CK(f.c.state()==C::State::Quiescing);
  }
  // 10.85: Offset is immutable, even just before G28
  { Fixture f;f.heat();f.v.zoffset=-1.09f;
    CK(f.c.poll(2000,f.v).action==C::Action::RequestSafeStop);
    CK(f.c.error()==C::Error::ZOffsetChanged);
  }
  // 10.86: Mesh exact rollback including geometry and NaN bytes
  { Fixture f;f.probing();CK(f.c.cancel(f.token).action==C::Action::RequestSafeStop);
    f.quiesce();C::MeshSnapshot out{};CK(f.c.original_for_rollback(f.token,out));
    auto expected=mesh();CK(std::memcmp(out.z,expected.z,sizeof(out.z))==0);
    CK(out.zoffset==expected.zoffset && out.origin_x==expected.origin_x &&
       out.origin_y==expected.origin_y && out.pitch_x==expected.pitch_x &&
       out.pitch_y==expected.pitch_y && out.leveling_enabled==expected.leveling_enabled);
    CK(f.c.restored(f.token,true));CK(f.c.state()==C::State::Cancelled);
  }
  // 10.87: No automatic M500 anywhere, even after success
  { Fixture f;f.probing();f.measured();float out[16];
    for(unsigned i=0;i<16;++i)out[i]=f.c.candidate(i);
    auto req=f.c.probing_complete(f.token,true,out,true,f.v,21104);
    CK(req.action==C::Action::FinishedRamOnly);CK(!f.c.allow_eeprom_write());
    CK(f.c.state()==C::State::FinishedRam);
  }
  // 10.88: Incorrect live mesh or missing sample -> rollback
  { Fixture f;f.probing();f.measured();float out[16];
    for(unsigned i=0;i<16;++i)out[i]=f.c.candidate(i);
    out[6]+=0.25f;
    CK(f.c.probing_complete(f.token,true,out,true,f.v,21104).action==C::Action::RequestSafeStop);
    CK(f.c.error()==C::Error::MeshMismatch);
  }
  // 10.89: Display progress count exactly 16, candidate colours
  { Fixture f;f.probing();f.measured();CK(f.c.display().measured==16);
    for(unsigned i=0;i<16;++i)CK(f.c.display().point[i]==C::Pixel::Valid);
    CK(f.c.display().bed_x10==600);
  }
  // 10.90: RAM rollback NEVER while motion, queued code or probe deployed
  { Fixture f;f.probing();CK(f.c.cancel(f.token).action==C::Action::RequestSafeStop);
    f.v.motion_active=true;CK(f.c.quiesced(f.token,f.v).action==C::Action::None);
    f.v.motion_active=false;f.v.queued_gcode=true;
    CK(f.c.quiesced(f.token,f.v).action==C::Action::None);
    f.v.queued_gcode=false;f.v.probe_stowed=false;
    CK(f.c.quiesced(f.token,f.v).action==C::Action::None);
    f.v.probe_stowed=true;f.quiesce();
  }
  // Race: abort arriving on the same callback as G28 completion / G29 completion
  { Fixture f;f.homing();f.v.abort_requested=true;f.v.xyz_homed=true;
    CK(f.c.homing_complete(f.token,21005,true,f.v).action==C::Action::RequestSafeStop);
    CK(f.c.error()==C::Error::UserCancel);
  }
  { Fixture f;f.probing();f.measured();float out[16];
    for(unsigned i=0;i<16;++i)out[i]=f.c.candidate(i);
    f.v.abort_requested=true;
    CK(f.c.probing_complete(f.token,true,out,true,f.v,21104).action==C::Action::RequestSafeStop);
    CK(f.c.error()==C::Error::UserCancel);
  }
  { Fixture f;f.probing();f.v.abort_requested=true;
    CK(!f.c.probe_sample(f.token,0,0.f,0.f,f.v,21102));
    CK(f.c.error()==C::Error::UserCancel);
  }
  // Race: no intermediate tick between deadline and delayed acknowledgement
  { Fixture f;f.v.setpoint=60.f;
    CK(f.c.acknowledge_heat(f.token,31002,true,f.v).action==C::Action::RequestSafeStop);
    CK(f.c.error()==C::Error::HeatAckTimeout);
  }
  { Fixture f;f.homing();f.v.xyz_homed=true;
    CK(f.c.homing_complete(f.token,201004,true,f.v).action==C::Action::RequestSafeStop);
    CK(f.c.error()==C::Error::HomeTimeout);
  }
  // User pause / Marlin STOP must not authorize rollback while native engine is unsafe
  for(int e=0;e<2;++e) {Fixture f;f.probing();f.c.cancel(f.token);
    if(e==0) f.v.print_paused=true;else f.v.marlin_stopped=true;
    CK(f.c.quiesced(f.token,f.v).action==C::Action::None);
    CK(f.c.state()==C::State::Quiescing);
  }
  // 10.91: stale tokens fail after explicit terminal reset
  { Fixture f;f.probing();auto old=f.token;
    CK(f.c.cancel(old).action==C::Action::RequestSafeStop);f.quiesce();
    CK(f.c.restored(old,true));CK(f.c.reset_for_new_run(f.v));
    CK(f.c.token()!=old);
    CK(!f.c.load_snapshot(C::MeshSnapshot{})); // zero/invalid geometry
    CK(f.c.load_snapshot(mesh()));
    CK(f.c.start(30000,f.v).action==C::Action::Heat60);
    CK(f.c.cancel(old).action==C::Action::None);
  }
  // 10.92: Exhaustively inject faults at each of 16 points
  for(int fail_at=0;fail_at<16;++fail_at){Fixture f;f.probing();
    f.measured((unsigned)fail_at);
    CK(!f.c.probe_sample(f.token,(uint8_t)fail_at,0.f,0.11f,f.v,21102));
    CK(f.c.error()==C::Error::ProbeSpread);
    CK(f.c.display().measured==(unsigned)fail_at);
    f.quiesce();C::MeshSnapshot original{};
    CK(f.c.original_for_rollback(f.token,original));
    CK(f.c.restored(f.token,true));
  }
  // timers 32-bit wrap boundary
  { C c;auto v=facts();CK(c.load_snapshot(mesh()));
    auto req=c.start(0xFFFFFF00u,v);CK(req.action==C::Action::Heat60);
    v.setpoint=60;CK(c.acknowledge_heat(req.token,0xFFFFFF05u,true,v).action==C::Action::None);
    v.bed=60;CK(c.poll(0xFFFFFF10u,v).action==C::Action::None);
    CK(c.poll(21000u,v).action==C::Action::HomeXYZ);
  }
  // Home and probe timeouts
  { Fixture f;f.homing();CK(f.c.poll(201004,f.v).action==C::Action::RequestSafeStop);
    CK(f.c.error()==C::Error::HomeTimeout);
  }
  { Fixture f;f.probing();CK(f.c.poll(922000,f.v).action==C::Action::RequestSafeStop);
    CK(f.c.error()==C::Error::ProbeTimeout);
  }
  // Timeout must also be checked inside asynchronous probe callbacks,
  // even when no regular poll() occurs while a probe motion is blocking.
  { Fixture f;f.probing();
    CK(!f.c.probe_sample(f.token,0,0.f,0.f,f.v,921101u));
    CK(f.c.error()==C::Error::ProbeTimeout);
  }
  { Fixture f;f.probing();f.measured();float out[16];
    for(unsigned i=0;i<16;++i)out[i]=f.c.candidate(i);
    CK(f.c.probing_complete(f.token,true,out,true,f.v,921101u).action==C::Action::RequestSafeStop);
    CK(f.c.error()==C::Error::ProbeTimeout);
  }
  // A wildly implausible display temperature must not overwrite last
  // validated telemetry. Invalid sensor data independently triggers failure.
  { Fixture f;f.heat();f.v.bed=NAN;
    CK(f.c.poll(1004,f.v).action==C::Action::RequestSafeStop);
    CK(f.c.error()==C::Error::Heater);
  }
  // External state change during last-point commit has to invalidate success.
  for(int fault=0;fault<5;++fault){Fixture f;f.probing();f.measured();float out[16];
    for(unsigned i=0;i<16;++i)out[i]=f.c.candidate(i);
    if(fault==0)f.v.print_active=true;
    if(fault==1)f.v.t1_park_physically_confirmed=false;
    if(fault==2)f.v.zoffset+=0.5f;
    if(fault==3)f.v.bed=56.f;
    if(fault==4)f.v.probe_stowed=false;
    CK(f.c.probing_complete(f.token,true,out,true,f.v,21105u).action==C::Action::RequestSafeStop);
    CK(f.c.state()==C::State::Quiescing);
  }
  // Rollback failure never reports success
  { Fixture f;f.probing();CK(f.c.cancel(f.token).action==C::Action::RequestSafeStop);
    f.quiesce();CK(!f.c.restored(f.token,false));CK(f.c.state()==C::State::Failed);
    CK(f.c.error()==C::Error::RestoreFailed);
  }
  std::printf("SV04 NEXT 10.73-10.92: %u sequenced-controller checks PASS; HOST ONLY\n",checks);
}
