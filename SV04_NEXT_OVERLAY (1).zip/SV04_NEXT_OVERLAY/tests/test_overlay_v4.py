#!/usr/bin/env python3
"""Structural tests for new native safety guards, with an intentionally minimal fixture."""
from pathlib import Path
import sys,tempfile
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'integration'))
import apply_native_guard_v4 as v4
count=0
def ck(a,msg='failed'):
 global count
 assert a,msg
 count+=1
cf='''#define GRID_MAX_POINTS_X 4\n//#define MULTIPLE_PROBING 2\n'''
probe='''Probe probe;
#elif TOTAL_PROBING == 2
    const float z2 = current_position.z;

    if (DEBUGGING(LEVELING))
'''
g='''#include "../../../module/probe.h"
#define G29_RETURN(b) return TERN_(G29_RETRY_AND_RECOVER, b)
G29_TYPE GcodeSuite::G29() {
  reset_stepper_timeout();
  for (int i=0; i<16; i++) {
          abl.measured_z = faux ? 0.001f * random(-100, 101) : probe.probe_at_point(abl.probePos, raise_after, abl.verbose_level);
            z_values[abl.meshCount.x][abl.meshCount.y] = z;
            TERN_(EXTENSIBLE_UI, ExtUI::onMeshUpdate(abl.meshCount, z));
  }
  #if ENABLED(RTS_AVAILABLE)
    RTS_AutoBedLevelPage();
  #endif
  report_current_position();

  TERN_(FULL_REPORT_TO_HOST_FEATURE, set_and_report_grblstate(M_IDLE));

  G29_RETURN(isnan(abl.measured_z));
}'''
source=dict(zip(v4.OEM_BLOBS,[cf,probe,g]));out=v4.render(source)
modified=out['Marlin/src/gcode/bedlevel/abl/G29.cpp']
ck('SV04 NEXT G29U PROGRESS ' in modified,'lost progress')
ck('SV04 NEXT G29U REFUSED' in modified,'lost preflight')
ck('SV04 NEXT G29U ABORT' in modified,'lost abort')
ck('SV04 NEXT: original RAM mesh restored' in modified,'lost restore')
ck('probe.offset.z = old_probe_offset' in modified,'lost offset restore')
ck('sv04_mesh_guard.accept();' in modified,'lost candidate accept')
ck('if (!sv04_transactional_run || !isnan(abl.measured_z))' in modified,'false HMI success possible')
for symbol in ['active_extruder != 0','dual_x_carriage_mode != DXC_AUTO_PARK_MODE',
               '!axis_is_trusted(X_AXIS)','!axis_is_trusted(Y_AXIS)','!axis_is_trusted(Z_AXIS)',
               '!isfinite(inactive_extruder_x)','ABS(inactive_extruder_x-X2_MAX_POS) > 1.0f']:
 ck(symbol in modified,'missing recheck '+symbol)
 ck(modified.replace(' ', '').count(symbol.replace(' ', ''))>=2,'missing preflight/final guard '+symbol)
ck('setTargetBed(' not in modified,'unexpected heater control')
ck('settings.save(' not in modified,'unexpected EEPROM write')
ck('queue.enqueue' not in modified,'unexpected queued motion')
ck(out['Marlin/Configuration.h'].count('#define MULTIPLE_PROBING 2')==1,'double-probe config drift')
ck('if (sv04_next_g29_u_active &&' in out['Marlin/src/module/probe.cpp'],'lost guarded double probe')
try:v4.render(out)
except v4.PatchRefused:ck(True)
else:raise AssertionError('double application did not refuse')
with tempfile.TemporaryDirectory() as td:
 p=Path(td);saved=dict(v4.OEM_BLOBS)
 try:
  v4.OEM_BLOBS.clear()
  for name,data in source.items():
   f=p/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(data)
   v4.OEM_BLOBS[name]=v4.previous.git_blob_sha(f.read_bytes())
  info=v4.apply(p,p/'proof.json');ck(info['automatic_eeprom_save_enabled'] is False)
  ck(info['physical_t1_park_verified'] is False)
  ck(info['new_dwin_hmi_binary'] is False)
  for name,data in out.items():ck((p/name).read_text()==data,'render mismatch')
  before={name:(p/name).read_bytes() for name in source}
  try:v4.apply(p,p/'second.json')
  except v4.PatchRefused:ck(True)
  else:raise AssertionError('changed OEM accepted')
  ck(not (p/'second.json').exists())
  for name in source:ck((p/name).read_bytes()==before[name],'rollback atomicity')
 finally:v4.OEM_BLOBS.clear();v4.OEM_BLOBS.update(saved)
print(f'SV04 NEXT 1053-1072 native safety fixture PASS {count} checks; native build pending')
