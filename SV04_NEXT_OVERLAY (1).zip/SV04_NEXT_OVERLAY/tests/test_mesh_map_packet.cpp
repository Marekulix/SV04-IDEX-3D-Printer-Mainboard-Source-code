#include "../include/SV04NextMeshMapPacket.hpp"
#include <cassert>
#include <cstdio>
#include <cstring>
#include <cmath>
using namespace sv04next;
static unsigned checks=0;
#define CHECK(v) do{++checks;assert(v);}while(0)
static uint16_t u16(const uint8_t *p,unsigned i){return (uint16_t)(p[i]|((uint16_t)p[i+1]<<8));}
int main(){
  G29UReceipt receipt;
  NativeStatusPacket status;
  MeshMapPacket mesh;
  NativeEventTimeline::Frame timeline;
  T1EndstopObserver sensor;
  const uint32_t now=2000;
  NativeReadiness::View view;
  view.observed=true;view.last_sample_ms=now;
  view.gate=NativeReadiness::Gate::NoPhysicalT1Witness;
  timeline.quality=NativeEventTimeline::Quality::Fresh;
  timeline.observed_ms=now;
  view.receipt_phase=receipt.phase();
  status.capture(now,view,timeline,sensor);
  mesh.capture(receipt,timeline,status);
  CHECK(mesh.state()==MeshMapPacket::MapState::Empty);
  CHECK(MeshMapPacket::verify(mesh.bytes(),48));
  CHECK(!mesh.allows_motion());CHECK(!mesh.allows_heating());CHECK(!mesh.allows_eeprom());
  CHECK(receipt.begin());
  timeline.run=view.g29_run_id=receipt.sequence();
  for(unsigned i=0;i<16;++i){
    CHECK(receipt.point((uint8_t)(i%4),(uint8_t)(i/4),(float)((int)i-8)*0.005f));
    timeline.mask=view.valid_mask=receipt.point_mask();
    timeline.count=view.measured=receipt.completed();
    view.receipt_phase=receipt.phase();
    status.capture(now,view,timeline,sensor);
    mesh.capture(receipt,timeline,status);
    CHECK(mesh.state()==MeshMapPacket::MapState::InProgress);
    CHECK(MeshMapPacket::verify(mesh.bytes(),48));
    CHECK((int16_t)u16(mesh.bytes(),12+2*i)==(int)i*5-40);
    for(unsigned j=i+1;j<16;++j)
      CHECK((int16_t)u16(mesh.bytes(),12+2*j)==MeshMapPacket::Missing);
  }
  CHECK(receipt.finish_ram_only());
  timeline.receipt_16_ram=true;
  view.ram_mesh_16_of_16=true;view.receipt_phase=receipt.phase();
  status.capture(now,view,timeline,sensor);
  mesh.capture(receipt,timeline,status);
  CHECK(mesh.state()==MeshMapPacket::MapState::RamComplete);
  CHECK(mesh.bytes()[44]==2);CHECK(mesh.bytes()[45]==0);
  CHECK(u16(mesh.bytes(),8)==0xFFFFu);
  for(unsigned i=0;i<16;++i)CHECK((int16_t)u16(mesh.bytes(),12+2*i)==(int)i*5-40);
  CHECK(MeshMapPacket::verify(mesh.bytes(),48));
  // A stale status packet MUST NOT produce a green map, even with 16 probe values.
  view.last_sample_ms=now-300;
  status.capture(now,view,timeline,sensor);
  mesh.capture(receipt,timeline,status);
  CHECK(mesh.state()==MeshMapPacket::MapState::Invalid);
  view.last_sample_ms=now;status.capture(now,view,timeline,sensor);
  timeline.run=receipt.sequence()+1;
  mesh.capture(receipt,timeline,status);
  CHECK(mesh.state()==MeshMapPacket::MapState::Invalid);
  timeline.run=receipt.sequence();
  mesh.capture(receipt,timeline,status);
  CHECK(mesh.state()==MeshMapPacket::MapState::RamComplete);
  for(unsigned i=0;i<48;++i){
    uint8_t corrupted[48];std::memcpy(corrupted,mesh.bytes(),48);
    corrupted[i]^=0x01u;
    CHECK(!MeshMapPacket::verify(corrupted,48));
  }
  CHECK(!MeshMapPacket::verify(nullptr,48));
  CHECK(!MeshMapPacket::verify(mesh.bytes(),47));
  uint8_t forged[48];std::memcpy(forged,mesh.bytes(),48);
  forged[10]=15u; // forged 15/16 result marked complete (with recalculated CRC)
  const uint16_t fakecrc=NativeStatusPacket::crc16(forged,46);
  forged[46]=(uint8_t)fakecrc;forged[47]=(uint8_t)(fakecrc>>8);
  CHECK(!MeshMapPacket::verify(forged,48));
  // Probe refused and failed never color a completed map green.
  G29UReceipt failed;
  CHECK(failed.begin()); CHECK(!failed.refuse());
  timeline.run=failed.sequence();timeline.mask=0;timeline.count=0;timeline.receipt_16_ram=false;
  view.g29_run_id=failed.sequence();view.valid_mask=0;view.measured=0;
  view.receipt_phase=failed.phase();view.ram_mesh_16_of_16=false;
  status.capture(now,view,timeline,sensor);
  mesh.capture(failed,timeline,status);
  CHECK(mesh.state()!=MeshMapPacket::MapState::RamComplete);
  std::printf("MESH MAP 4x4 TELEMETRY PASS checks=%u, NO EEPROM\n",checks);
}
