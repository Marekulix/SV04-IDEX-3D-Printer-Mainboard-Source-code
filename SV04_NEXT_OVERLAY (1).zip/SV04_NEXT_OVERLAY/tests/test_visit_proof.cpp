#include <cstdint>
#include <iostream>
#include <cassert>
#include "../include/SV04NextVisitProof.hpp"
int main(){
  size_t n=0;
  for(int rotation=0;rotation<16;++rotation){
    sv04next::VisitProof proof;
    assert(!proof.complete()); ++n;
    for(int i=0;i<16;++i){
      const int index=(i+rotation)%16;
      assert(proof.record(index%4,index/4));++n;
      assert(proof.count()==i+1);++n;
      if(i<15) {assert(!proof.complete());++n;}
    }
    assert(proof.complete()); ++n;
    for(int x=0;x<4;++x)for(int y=0;y<4;++y){assert(!proof.record(x,y));++n;}
    for(int i=4;i<256;++i){assert(!proof.record(i,0));++n;assert(!proof.record(0,i));++n;}
    assert(proof.mask()==0xffffu);++n;
  }
  for(int missing=0;missing<16;++missing){
    sv04next::VisitProof p;
    for(int i=0;i<16;++i)if(i!=missing){assert(p.record(i%4,i/4));++n;}
    assert(!p.complete());++n;
  }
  std::cout<<"SV04 NEXT UNIQUE 4x4 coverage PASS checks="<<n<<"\n";
}
