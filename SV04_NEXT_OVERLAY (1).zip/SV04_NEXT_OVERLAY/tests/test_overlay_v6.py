"""v6 fixture integration and fail-closed source checks. Not a Marlin build."""
from __future__ import annotations
from pathlib import Path
import importlib.util, sys, tempfile
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'integration'))
sys.path.insert(0,str(ROOT/'tests'))
import apply_native_guard_v6 as v6
import test_overlay_v5 as fixture  # also verifies existing v5 regression
TH=(ROOT/'include/SV04NextNativeThermalGate.hpp').read_text()
VI=(ROOT/'include/SV04NextVisitProof.hpp').read_text()
source=dict(fixture.source)
source['Marlin/src/gcode/bedlevel/abl/G29.cpp']=source['Marlin/src/gcode/bedlevel/abl/G29.cpp'].replace(
    '          abl.measured_z = faux ? 0.001f * random(-100, 101) : probe.probe_at_point',
    '          // Avoid probing outside the round or hexagonal area\n'
    '          if (TERN0(IS_KINEMATIC, !probe.can_reach(abl.probePos))) continue;\n'
    '          abl.measured_z = faux ? 0.001f * random(-100, 101) : probe.probe_at_point',1)
new=v6.render(source,TH,VI)
G=new['Marlin/src/gcode/bedlevel/abl/G29.cpp']
checks=0
def ck(condition,msg):
 global checks
 assert condition,msg
 checks+=1
ck(new['Marlin/Configuration.h']==source['Marlin/Configuration.h'],'OEM configuration changed')
ck(new['Marlin/src/module/probe.cpp']==source['Marlin/src/module/probe.cpp'],'OEM probe.cpp changed')
ck('sv04next::VisitProof sv04_visit_proof;' in G,'coverage object')
ck('!sv04_visit_proof.record(abl.meshCount.x, abl.meshCount.y)' in G,'unique point validation')
ck('sv04_visit_proof.complete()' in G,'final full 16 point coverage validation')
ck('SV04 NEXT G29U ABORT: repeated/out-of-grid point' in G,'duplicates are an error')
ck('SV04 NEXT G29U ABORT: heat changed during probe' in G,'thermal state after double probe')
ck('!sv04next::NativeThermalGate::live_sample_safe(' in G,'direct thermal read after probing')
ck(G.count('native_thermal_gate.ready((uint32_t)millis())')==1,'20 seconds only at entry')
ck('native_thermal_gate.ready((uint32_t)millis())' in G.split('const float first_z')[0],'start gate before probing')
ck('queue.enqueue' not in G and 'setTargetBed(' not in G,'no actuator commands')
ck('M500' not in G and 'settings.save(' not in G,'EEPROM write not authorized')
ck(new[v6.VISIT_TARGET]==VI,'native visited header included')
ck(new[v6.THERMAL_TARGET]==TH,'thermal header included')
ck(G.count('probe.probe_at_point(abl.probePos, PROBE_PT_RAISE')==1,'scoped first actual probe')
ck(G.count('probe.probe_at_point(abl.probePos, raise_after')==2,'native OEM and scoped second probe')
ck('probe.offset.z = old_probe_offset;' in G,'offset recovery')
ck('sv04_mesh_guard.revert();' in G,'mesh recovery')
ck('SV04 NEXT G29U PROGRESS' in G,'16 progress native')
ck('RTS_AutoBedLevelPage();' in G,'OEM screen retained')
try:
 v6.render(new,TH,VI)
except v6.PatchRefused: ck(True,'double patch fails closed')
else:raise AssertionError('v6 double patch accepted')
for bad in [TH.replace('static bool live_sample_safe','static bool forbidden_safe'),TH.replace('20s','21s')]:
 try: v6.render(source,bad,VI)
 except v6.PatchRefused: ck(True,'changed thermal rejected')
 else:
  if 'static bool live_sample_safe' not in bad:raise AssertionError('bad thermal permitted')
for bad in ['untrusted header',VI.replace('SV04 NEXT 11.13-11.32','OTHER')]:
 try:v6.render(source,TH,bad)
 except v6.PatchRefused:ck(True,'untrusted visit header rejected')
 else:raise AssertionError('untrusted header permitted')
# A failed source integrity check must leave all files byte-identical.
with tempfile.TemporaryDirectory() as tmp:
 root=Path(tmp)
 for name,content in source.items():
  file=root/name;file.parent.mkdir(parents=True,exist_ok=True);file.write_text(content)
 bad_shas=dict(v6.OEM_BLOBS)
 try:
  v6.OEM_BLOBS.clear()
  v6.OEM_BLOBS.update({k:v6.previous.git_blob_sha(v.encode()) for k,v in source.items()})
  (root/'Marlin/Configuration.h').write_text('drifted')
  try:v6.apply(root,ROOT/'include/SV04NextNativeThermalGate.hpp',ROOT/'include/SV04NextVisitProof.hpp')
  except v6.PatchRefused:ck(True,'tamper failure')
  else:raise AssertionError('tamper accepted')
  (root/'Marlin/Configuration.h').write_text(source['Marlin/Configuration.h'])
  proof=v6.apply(root,ROOT/'include/SV04NextNativeThermalGate.hpp',ROOT/'include/SV04NextVisitProof.hpp',root/'proof.json')
  ck(proof['m500_enabled'] is False,'no m500')
  ck(proof['native_stm32_build_passed'] is False,'not claiming native build')
  ck((root/'proof.json').exists(),'evidence emitted')
  ck((root/v6.VISIT_TARGET).exists(),'header emitted')
  for k,v in source.items():
   if k in ['Marlin/Configuration.h','Marlin/src/module/probe.cpp']:
    ck((root/k).read_text()==v,'OEM normal path invariant')
  ck((root/'Marlin/src/gcode/bedlevel/abl/G29.cpp').read_text()==G,'Marlin generated output matches fixture')
 finally:
  v6.OEM_BLOBS.clear();v6.OEM_BLOBS.update(bad_shas)
print('SV04 NEXT experimental v6 fixture PASS checks=',checks)
