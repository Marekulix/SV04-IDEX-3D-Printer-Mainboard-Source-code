// Simulated, no Marlin functions called. Exercises run ownership and UI result
// together so a finished G29 from another run cannot complete Auto60.
#include "../include/SV04NextSequencedController.hpp"
#include "../include/SV04NextCommandHandshake.hpp"
#include "../include/SV04NextReceiptBinder.hpp"
#include "../include/SV04NextAuto60ViewModel.hpp"
#include <cassert>
#include <cstdio>
using namespace sv04next;
static int checks=0;
#define CHECK(x) do{++checks;assert(x);}while(0)
static SequencedController::Inputs ready(){
  SequencedController::Inputs x;
  x.t1_homed=true;x.t1_park_physically_confirmed=true;x.auto_park_mode=true;
  x.bed=25.f;x.setpoint=0.f;
  return x;
}
int main(){
  using S=SequencedController;using H=CommandHandshake;using B=ReceiptBinder;
  for(int rep=0;rep<96;rep++){
    S c;S::MeshSnapshot snap;for(int i=0;i<16;++i)snap.z[i]=(float)i*.001f;
    snap.pitch_x=snap.pitch_y=50.f;snap.zoffset=-1.10f;
    CHECK(c.load_snapshot(snap));
    auto v=ready();
    auto r=c.start(1000u,v);CHECK(r.action==S::Action::Heat60);CHECK(r.token!=0);
    const uint32_t token=r.token;
    H h;H::Live hw;hw.physical_t1_verified=true;hw.bed_stable_60=true;
    hw.xyz_homed=true;hw.g29_ram_16_success=true;
    H::Ticket ticket;
    CHECK(h.issue(token,H::Step::Heat60,1000u,hw,ticket));
    CHECK(h.confirm(ticket,true,1050u,hw));CHECK(h.consume(ticket));
    v.bed=60.f;v.setpoint=60.f;
    r=c.acknowledge_heat(token,1100u,true,v);CHECK(r.action==S::Action::None);
    r=c.poll(21000u,v);CHECK(r.action==S::Action::None);
    r=c.poll(41001u,v);CHECK(r.action==S::Action::HomeXYZ);
    CHECK(h.issue(token,H::Step::HomeXYZ,41001u,hw,ticket));
    CHECK(h.confirm(ticket,true,41500u,hw));CHECK(h.consume(ticket));
    v.xyz_homed=true;
    r=c.homing_complete(token,41500u,true,v);CHECK(r.action==S::Action::ProbeG29U);
    CHECK(h.issue(token,H::Step::ProbeG29U,41500u,hw,ticket));
    G29UReceipt native;B binder;
    CHECK(binder.prepare(token,native.sequence()));CHECK(native.begin());
    B::Live rc;rc.t1_witness=true;rc.bed_stable_60=true;rc.probe_stowed=true;
    CHECK(binder.observe(token,native,rc));
    float mesh[16];
    for(uint8_t i=0;i<16;++i){
      mesh[i]=(float)((rep+i)%12)*.01f;
      CHECK(c.probe_sample(token,i,mesh[i],mesh[i],v,42000u+i*50u));
      CHECK(native.point(i%4,i/4,mesh[i]));
      CHECK(binder.observe(token,native,rc));
      auto screen=Auto60ViewModel::make(c,native,binder,true);
      CHECK(!screen.ram_only_16_of_16);CHECK(screen.percent<100);
    }
    CHECK(native.finish_ram_only());CHECK(binder.observe(token,native,rc));
    r=c.probing_complete(token,true,mesh,true,v,43000u);
    CHECK(r.action==S::Action::FinishedRamOnly);
    hw.g29_ram_16_success=binder.ram_complete();
    CHECK(h.confirm(ticket,true,43000u,hw));CHECK(h.consume(ticket));
    CHECK(h.ram_only_success());
    auto frame=Auto60ViewModel::make(c,native,binder,true);
    CHECK(frame.ram_only_16_of_16);CHECK(frame.percent==100);CHECK(frame.measured==16);
    CHECK(!frame.eeprom_saved);CHECK(!c.allow_eeprom_write());CHECK(!h.can_write_eeprom());
    frame=Auto60ViewModel::make(c,native,binder,false);
    CHECK(!frame.ram_only_16_of_16);CHECK(frame.percent<100);
  }
  // A previously successful native receipt cannot approve a new run.
  {G29UReceipt r;B b;CHECK(r.begin());
    for(int i=0;i<16;++i)CHECK(r.point(i%4,i/4,0.f));
    CHECK(r.finish_ram_only());CHECK(b.prepare(9,0));B::Live live;live.t1_witness=true;live.bed_stable_60=true;
    live.probe_stowed=true;CHECK(!b.observe(9,r,live));CHECK(!b.ram_complete());}
  // A stale ACK from an earlier run cannot accept a newer operation.
  {H h;H::Live v;v.physical_t1_verified=true;v.bed_stable_60=true;
    H::Ticket t;CHECK(h.issue(4,H::Step::Heat60,0,v,t));h.revoke();
    CHECK(h.reset_after_quiescence(5,v));H::Ticket t2;
    CHECK(h.issue(5,H::Step::Heat60,4,v,t2));CHECK(!h.confirm(t,true,5,v));
    CHECK(h.confirm(t2,true,5,v));CHECK(!h.can_write_eeprom());}
  std::printf("AUTO60 END-TO-END HOST SIMULATION PASS checks=%d; PHYSICAL ACTIONS 0\n",checks);
}
