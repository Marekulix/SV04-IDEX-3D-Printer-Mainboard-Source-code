#include <cassert>
#include <cmath>
#include <cstdint>
#include <iostream>
#include "../include/SV04NextNativeThermalGate.hpp"
namespace sv04next { NativeThermalGate native_thermal_gate; }
int main() {
  sv04next::NativeThermalGate t;
  int checks=0;
  auto ck=[&](bool yes){if(!yes){std::cerr<<"FAILED CHECK "<<checks+1<<"\n";std::abort();}++checks;};
  ck(!t.ready(0));
  t.observe(100,60,60,true);ck(!t.ready(100));ck(!t.ready(20100));
  for (uint32_t ms=2100;ms<=20100;ms+=2000) {
    t.observe(ms,60.25f,60,true);
    ck(t.ready(ms)==(ms>=20100));
  }
  ck(t.ready(20500));ck(!t.ready(25101));
  t.observe(27000,60,60,true);ck(!t.ready(27000));
  for(uint32_t i=1;i<=15;++i){t.observe(27000+2000*i,59.8f,60,true);ck(t.ready(27000+2000*i)==(i>=10));}
  t.observe(60000,61.01f,60,true);ck(!t.ready(60000));
  for(int target=0;target<70;++target){t.observe(61000+target,60,(float)target,true);ck(!t.ready(61000+target));}
  t.observe(62000,NAN,60,true);ck(!t.ready(62000));
  t.observe(63000,INFINITY,60,true);ck(!t.ready(63000));
  t.observe(64000,60,60,false);ck(!t.ready(64000));
  // UINT32 wraparound continuity: elapsed computed by unsigned subtraction.
  uint32_t base=UINT32_MAX-9999u;
  t.observe(base,60,60,true);ck(!t.ready(base));
  for(uint32_t i=1;i<=10;++i){
    uint32_t now=base+2000*i;
    t.observe(now,60,60,true);
    ck(t.ready(now)==(i>=10));
  }
  // Large idle gaps may not count as stable heat.
  t.reset();t.observe(0,60,60,true);t.observe(20001,60,60,true);ck(!t.ready(20001));
  // Sweep every possible 2s observation with one 3+ degree transient in step k.
  for(unsigned k=0;k<16;k++){
    t.reset();
    for(unsigned i=0;i<25;i++){
      float temp=i==k?56.f:60.f;
      t.observe(2000u*i,temp,60,true);
      ck(t.ready(2000u*i) == ((i>=10u && i<k) || i>=k+11u));
    }
  }
  std::cout<<"SV04 NEXT native thermal 20s gate PASS checks="<<checks<<"\n";
}
