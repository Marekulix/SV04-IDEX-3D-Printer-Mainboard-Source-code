#include "../include/SV04Next20PhaseContract.hpp"
#include <assert.h>
#include <stdio.h>
#include <limits>
#include <string.h>
using namespace sv04next;
static unsigned checks=0;
#define CK(x) do { assert((x));++checks; } while(0)
using C=TwentyPhaseContract;
static C::Original old_mesh() {
 C::Original o{};
 for(unsigned i=0;i<16;i++)o.z[i]=float(i)/200;
 o.offset=-1.10f;o.origin_x=25;o.origin_y=25;o.step_x=83;o.step_y=83;o.enabled=true;
 return o;
}
static MachineFacts ok() {MachineFacts m; m.x2_homed=true; m.x2_physically_parked=true; m.auto_park=true;return m;}
static void advance(C& c,MachineFacts &m){
 CK(c.capture(old_mesh()));
 CK(c.begin(5,m)==C::Command::RequestHeat60);
 m.bed_target=60;m.bed=60;
 CK(c.update(30,m)==C::Command::None);
 CK(c.update(20031,m)==C::Command::RequestG28);
 m.xyz_homed=true;
 CK(c.homed(m)==C::Command::RequestG29U);
}
static void test_1053_source_model(){C c; CK(c.state()==C::State::Idle);CK(!c.allow_eeprom_write());}
static void test_1054_idle(){C c;MachineFacts m=ok();CK(c.capture(old_mesh()));m.printing=true;CK(c.begin(0,m)==C::Command::None);CK(c.error()==C::Error::Busy);}
static void test_1055_park(){C c;MachineFacts m=ok();CK(c.capture(old_mesh()));m.x2_physically_parked=false;CK(c.begin(0,m)==C::Command::None);CK(c.error()==C::Error::Park);}
static void test_1056_thermal(){C c;MachineFacts m=ok();advance(c,m);m.thermal_fault=true;CK(c.update(21000,m)==C::Command::RestoreRam);CK(c.error()==C::Error::Unsafe);}
static void test_1057_stability(){C c;MachineFacts m=ok();CK(c.capture(old_mesh()));CK(c.begin(0,m)==C::Command::RequestHeat60);m.bed_target=60;m.bed=60;CK(c.update(1,m)==C::Command::None);m.bed=58;CK(c.update(15000,m)==C::Command::None);m.bed=60;CK(c.update(15001,m)==C::Command::None);CK(c.update(20001,m)==C::Command::None);CK(c.update(35002,m)==C::Command::RequestG28);}
static void test_1058_timeout(){C c;MachineFacts m=ok();CK(c.capture(old_mesh()));CK(c.begin(0,m)==C::Command::RequestHeat60);CK(c.update(720001,m)==C::Command::RestoreRam);CK(c.error()==C::Error::HeatingTimeout);}
static void test_1059_home_once(){C c;MachineFacts m=ok();advance(c,m);CK(c.homed(m)==C::Command::None);CK(c.state()==C::State::Probe);}
static void test_1060_home_check(){C c;MachineFacts m=ok();CK(c.capture(old_mesh()));CK(c.begin(0,m)==C::Command::RequestHeat60);m.bed=60;m.bed_target=60;CK(c.update(1,m)==C::Command::None);CK(c.update(20002,m)==C::Command::RequestG28);CK(c.homed(m)==C::Command::RestoreRam);CK(c.error()==C::Error::Homing);}
static void test_1061_grid(){C c;MachineFacts m=ok();advance(c,m);for(unsigned i=0;i<16;i++)CK(c.measure(i,.1f,.1f,m));CK(c.completed()==16);CK(!c.measure(16,.1f,.1f,m));CK(c.error()==C::Error::Order);}
static void test_1062_dual(){C c;MachineFacts m=ok();advance(c,m);CK(c.measure(0,.1f,.12f,m));CK(fabsf(c.candidate(0)-.112f)<.00001f);}
static void test_1063_diff(){C c;MachineFacts m=ok();advance(c,m);CK(!c.measure(0,.1f,.17f,m));CK(c.error()==C::Error::Spread);CK(c.display().colors[0]==C::Color::Disagreement);}
static void test_1064_nan(){C c;MachineFacts m=ok();advance(c,m);CK(!c.measure(0,std::numeric_limits<float>::quiet_NaN(),.1f,m));CK(c.error()==C::Error::Sample);}
static void test_1065_mid_temp(){C c;MachineFacts m=ok();advance(c,m);m.bed=58.0f;CK(!c.measure(0,0,0,m));CK(c.error()==C::Error::Temperature);}
static void test_1066_cancel(){C c;MachineFacts m=ok();advance(c,m);CK(c.cancel());CK(c.state()==C::State::Cancelled);CK(!c.allow_eeprom_write());}
static void test_1067_snapshot_nan(){C c;auto o=old_mesh();o.z[2]=std::numeric_limits<float>::quiet_NaN();CK(c.capture(o));MachineFacts m=ok();CK(c.begin(0,m)==C::Command::RequestHeat60);C::Original r{};CK(c.restore(r));CK(memcmp(&r,&o,sizeof(o))==0);}
static void test_1068_restore(){C c;MachineFacts m=ok();advance(c,m);m.abort_request=true;CK(c.update(30000,m)==C::Command::RestoreRam);auto t=C::Original{};CK(c.restore(t));CK(t.step_x==83);CK(t.origin_y==25);}
static void test_1069_offset(){C c;MachineFacts m=ok();advance(c,m);m.z_offset=-1.09f;CK(!c.measure(0,0,0,m));CK(c.error()==C::Error::Offset);}
static void test_1070_no_save(){C c;MachineFacts m=ok();advance(c,m);for(unsigned i=0;i<16;++i) CK(c.measure(i,.01f*i,.01f*i,m));float values[16];for(int i=0;i<16;++i)values[i]=c.candidate(i);CK(c.finish(values,m,true,true));CK(c.state()==C::State::Validated);CK(!c.allow_eeprom_write());}
static void test_1071_verify(){C c;MachineFacts m=ok();advance(c,m);float v[16];for(unsigned i=0;i<16;++i){CK(c.measure(i,0,0,m));v[i]=0;}CK(c.finish(v,m,true,true));CK(c.verify_readback(v,-1.10f));v[6]=.1f;CK(!c.verify_readback(v,-1.10f));CK(!c.verify_readback(v,-1.11f));}
static void test_1072_dwin(){C c;MachineFacts m=ok();advance(c,m);for(unsigned i=0;i<16;i++){CK(c.measure(i,.01f*i,.01f*i,m));CK(c.display().completed==i+1);CK(c.display().colors[i]==C::Color::Accepted);}CK(c.display().colors[15]==C::Color::Accepted);CK(c.display().bed10==600);CK(c.display().target10==600);}
static void stress_each_fault(){
 for(int index=0;index<16;index++){
  C c;MachineFacts m=ok();advance(c,m);
  for(int i=0;i<index;i++)CK(c.measure(i,.03f,.03f,m));
  CK(!c.measure(index,.0f,.5f,m));CK(c.state()==C::State::Failed);CK(!c.allow_eeprom_write());
  C::Original restored{};CK(c.restore(restored));CK(restored.offset==-1.10f);
 }
 for(int index=0;index<16;index++){
  C c;MachineFacts m=ok();advance(c,m);
  for(int i=0;i<index;i++)CK(c.measure(i,.03f,.03f,m));
  m.bed=58.f;CK(!c.measure(index,.03f,.03f,m));CK(c.state()==C::State::Failed);
 }
}
int main(){
 test_1053_source_model();test_1054_idle();test_1055_park();test_1056_thermal();
 test_1057_stability();test_1058_timeout();test_1059_home_once();test_1060_home_check();
 test_1061_grid();test_1062_dual();test_1063_diff();test_1064_nan();
 test_1065_mid_temp();test_1066_cancel();test_1067_snapshot_nan();test_1068_restore();
 test_1069_offset();test_1070_no_save();test_1071_verify();test_1072_dwin();stress_each_fault();
 printf("SV04 NEXT 1053-1072 20-phase contract PASS assertions=%u, EEPROM=BLOCKED, NO FLASH\n",checks);
}
