#include "../include/SV04NextThermalWitness.hpp"
#include <cassert>
#include <cstdio>
#include <limits>
using namespace sv04next;
static int checks=0;
#define CHECK(X) do{++checks;assert(X);}while(0)
int main(){using T=ThermalWitness;
  for(uint32_t run=1;run<=500;++run){
    T x;T::Reading s;uint32_t origin=run==1?0xFFFFFF00u:100u;
    CHECK(x.begin(run,origin,s));CHECK(!x.ready(run,origin));
    for(uint32_t t=1000;t<=60000;t+=1000){
      s.actual=25.f+float(t)*30.f/60000.f;
      CHECK(x.observe(run,origin+t,s));CHECK(!x.ready(run,origin+t));
    }
    s.actual=60.f;
    CHECK(x.observe(run,origin+61000u,s));
    for(uint32_t t=62000;t<=80000;t+=1000){CHECK(x.observe(run,origin+t,s));CHECK(!x.ready(run,origin+t));}
    CHECK(x.observe(run,origin+81000u,s));CHECK(x.ready(run,origin+81000u));
    CHECK(!x.ready(run+1,origin+81000u));
    CHECK(!x.ready(run,origin+85001u));
    s.actual=57.5f;CHECK(x.observe(run,origin+82000u,s));CHECK(!x.ready(run,origin+82000u));
    s.actual=60.f;CHECK(x.observe(run,origin+83000u,s));CHECK(!x.ready(run,origin+83000u));
    CHECK(!x.issues_gcode());CHECK(!x.approves_eeprom());
  }
  for(uint32_t run=1;run<=800;++run){
    T x;T::Reading s;
    CHECK(x.begin(run,100u,s));
    switch(run%8){
      case 0:s.valid=false;break;
      case 1:s.actual=std::numeric_limits<float>::quiet_NaN();break;
      case 2:s.actual=66.f;break;
      case 3:s.target=58.f;break;
      case 4:s.heater_ok=false;break;
      case 5:s.printing=true;break;
      case 6:s.stopped=true;break;
      default:break;
    }
    CHECK(!x.observe(run,run%8==7?4101u:200u,s));
    CHECK(x.phase()==T::Phase::Fault);CHECK(!x.ready(run,500u));
  }
  {T x;T::Reading s;CHECK(x.begin(1,0,s));
    CHECK(!x.observe(2,100,s));CHECK(x.phase()==T::Phase::Heating);
    CHECK(!x.observe(1,900001u,s));CHECK(x.error()==T::Error::SampleGap || x.error()==T::Error::HeatTimeout);
  }
  { // Continuous but too-slow heating hits the global 12min limit.
    T x;T::Reading s;CHECK(x.begin(1,0,s));
    for(uint32_t t=1000;t<=T::MaxHeatMs;t+=1000)CHECK(x.observe(1,t,s));
    CHECK(!x.observe(1,T::MaxHeatMs+1000u,s));
    CHECK(x.error()==T::Error::HeatTimeout);
  }
  std::printf("THERMAL-WITNESS PASS checks=%d; 20s continuous / NO M190\n",checks);
}
