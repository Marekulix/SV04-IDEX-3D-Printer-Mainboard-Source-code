#!/usr/bin/env python3
"""Host-only injection and refusal tests; not an OEM firmware compile."""
import sys, tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'integration'))
import apply_native_guard_v2 as patch

checks=0
def check(cond,reason='check failed'):
    global checks
    assert cond,reason
    checks+=1

conf='''#define GRID_MAX_POINTS_X 4
//#define MULTIPLE_PROBING 2
'''
probe='''#include "../inc/MarlinConfig.h"
#if HAS_BED_PROBE
Probe probe;
float Probe::run_z_probe() {
  #elif TOTAL_PROBING == 2
    const float z2 = current_position.z;

    if (DEBUGGING(LEVELING)) DEBUG_ECHOLNPGM("probe");
}
'''
g29='''#include "../../../inc/MarlinConfig.h"
#if HAS_ABL_NOT_UBL
#define G29_RETURN(b) return TERN_(G29_RETRY_AND_RECOVER, b)
G29_TYPE GcodeSuite::G29() {
  reset_stepper_timeout();
  if (something) G29_RETURN(false);
  if (other) G29_RETURN(true);
  for (int i=0; i<16; i++) {
            z_values[abl.meshCount.x][abl.meshCount.y] = z;
            TERN_(EXTENSIBLE_UI, ExtUI::onMeshUpdate(abl.meshCount, z));
  }
  #if ENABLED(RTS_AVAILABLE)
    RTS_AutoBedLevelPage();
  #endif
  report_current_position();

  TERN_(FULL_REPORT_TO_HOST_FEATURE, set_and_report_grblstate(M_IDLE));

  G29_RETURN(isnan(abl.measured_z));
}
#endif
'''
keys=list(patch.OEM_BLOBS)
base=dict(zip(keys,[conf,probe,g29]))
out=patch.render(base)
check(len(out)==3)
check('sv04_next_g29_u_active = false' in out[keys[2]])
check('extern bool sv04_next_g29_u_active' in out[keys[1]])
check('if (sv04_next_g29_u_active &&' in out[keys[1]])
check('const bool sv04_transactional_run = parser.seen_test(\'U\');' in out[keys[2]])
check('sv04_next_g29_u_active = prior' in out[keys[2]])
check('reentrant G29 U refused' in out[keys[2]])
check('G29 U requires tool T0' in out[keys[2]])
check('sv04_mesh_guard.revert();' in out[keys[2]])
check('sv04_mesh_guard.accept();' in out[keys[2]])
check('GRID_MAX_POINTS_X == 4 && GRID_MAX_POINTS_Y == 4' in out[keys[2]])
check('sv04_measured_points == 16' in out[keys[2]])
check('memcpy(z_values, old_values, sizeof(old_values));' in out[keys[2]])
check('old_start(bilinear_start), old_spacing(bilinear_grid_spacing)' in out[keys[2]])
check('RTS_AutoBedLevelPage()' in out[keys[2]])
check('settings.save()' not in out[keys[2]])
check('M500' not in out[keys[2]])
check('queue.enqueue' not in out[keys[2]])
# Existing OEM probe unchanged when sv04_next_g29_u_active == false.
check('if (sv04_next_g29_u_active &&' in out[keys[1]])
check(out[keys[0]].count('#define MULTIPLE_PROBING 2')==1)
# The native G29 U requirement of an explicit T0 means no unsafe automatic T0 tool change.
check(out[keys[2]].index('G29 U requires tool T0') < out[keys[2]].index('if (something)'))
# Original G29 invocation remains intact (no automatic UI start).
check('G28' not in out[keys[2]])
for filename in keys:
    mut=dict(base)
    if filename.endswith('Configuration.h'):
        mut[filename]=mut[filename].replace('MULTIPLE_PROBING 2','MULTIPLE_PROBING 3')
    elif filename.endswith('probe.cpp'):
        mut[filename]=mut[filename].replace('const float z2 = current_position.z;', 'const float z2 = current_position.y;')
    else:
        mut[filename]=mut[filename].replace('reset_stepper_timeout();','reset_fast_timeout();')
    try: patch.render(mut)
    except patch.PatchRefused: check(True)
    else: raise AssertionError('unexpected unguarded patch: '+filename)
try:patch.render(out)
except patch.PatchRefused:check(True)
else:raise AssertionError('idempotence / second apply should refuse')
# No mutations on SHA / anchor errors (simulated in a disposable fixture).
with tempfile.TemporaryDirectory() as d:
    path=Path(d)
    original_hashes=dict(patch.OEM_BLOBS)
    try:
        patch.OEM_BLOBS.clear()
        for k,v in base.items():
            f=path/k;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(v)
            patch.OEM_BLOBS[k]=patch.git_blob_sha(f.read_bytes())
        evidence=path/'evidence.json'
        info=patch.apply(path,evidence)
        check(evidence.exists())
        check(info['flash_approved'] is False)
        check(info['m500_automated'] is False)
        for k,v in out.items():check((path/k).read_text()==v)
        check(not (path/'Marlin'/'UNEXPECTED').exists())
        # A repeated call must leave the first (already patched) bytes intact.
        frozen={k:(path/k).read_bytes() for k in keys}
        try: patch.apply(path,path/'no_should_not_exist.json')
        except patch.PatchRefused: check(True)
        else: raise AssertionError('SHA gate failed')
        check(not (path/'no_should_not_exist.json').exists())
        for k in keys:check((path/k).read_bytes()==frozen[k])
        # A single mutated input must block all outputs, before writing anything.
        for k,v in base.items():(path/k).write_text(v)
        (path/keys[1]).write_text(base[keys[1]]+'// unexpected edit\n')
        frozen={k:(path/k).read_bytes() for k in keys}
        try: patch.apply(path,path/'broken.json')
        except patch.PatchRefused: check(True)
        else: raise AssertionError('SHA gate accepted altered file')
        check(not (path/'broken.json').exists())
        for k in keys:check((path/k).read_bytes()==frozen[k])
    finally:
        patch.OEM_BLOBS.clear();patch.OEM_BLOBS.update(original_hashes)
print('SV04 NEXT G29 U V2 PATCH FIXTURE PASS: {} assertions; native compile pending'.format(checks))
