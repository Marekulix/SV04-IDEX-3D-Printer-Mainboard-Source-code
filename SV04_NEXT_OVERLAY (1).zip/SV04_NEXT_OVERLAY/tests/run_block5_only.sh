#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 tests/test_block5_contract.py
for opt in 0 2; do
  for name in operation_ledger abort_quarantine fault_trace abort_supervisor auto60_full_contract; do
    g++ -std=c++11 -O"$opt" -Wall -Wextra -Werror -pedantic "tests/test_${name}.cpp" -o "/tmp/sv04-5-${name}-${opt}"
    "/tmp/sv04-5-${name}-${opt}"
  done
done
for name in operation_ledger abort_quarantine fault_trace abort_supervisor auto60_full_contract; do
  g++ -std=c++11 -O1 -g -fsanitize=undefined -fno-sanitize-recover=all -Wall -Wextra -Werror -pedantic "tests/test_${name}.cpp" -o "/tmp/sv04-5-${name}-ubsan"
  "/tmp/sv04-5-${name}-ubsan"
done
for name in abort_quarantine fault_trace abort_supervisor; do
  clang++ -std=c++11 -O2 -fsanitize=address,undefined -fno-sanitize-recover=all -Wall -Wextra -Werror -pedantic "tests/test_${name}.cpp" -o "/tmp/sv04-5-${name}-clang"
  "/tmp/sv04-5-${name}-clang"
done
echo 'BLOCK 5 VERIFIED HOST C++11 WITH GCC & CLANG. NOT FLASHABLE.'
