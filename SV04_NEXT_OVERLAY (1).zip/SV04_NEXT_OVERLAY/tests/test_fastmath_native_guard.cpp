// Muss mit -ffast-math (bzw. -ffinite-math-only) übersetzt und ausgeführt werden: die NATIVEN Header dürfen NaN/Inf auch dann nicht akzeptieren.
// NaN/Inf werden aus Bitmustern erzeugt (nicht aus dem NAN-Makro), weil der Compiler unter fast-math Gleitkommavergleiche beliebig umformen darf.
#include "../include/SV04NextG29UReceipt.hpp"
#include "../include/SV04NextNativeThermalGate.hpp"
#include "../include/SV04NextNativeReadiness.hpp"
#include <cstdio>
#include <cstdlib>
#include <cstring>
using namespace sv04next;
static unsigned checks = 0;
#define CK(x) do { if (!(x)) { std::fprintf(stderr, "FAILED %s:%d %s\n", __FILE__, __LINE__, #x); std::abort(); } ++checks; } while (0)
static float bits(uint32_t b) { float f; std::memcpy(&f, &b, 4); return f; }
int main() {
  const float nan_v = bits(0x7FC00000u), pinf = bits(0x7F800000u), ninf = bits(0xFF800000u), snan = bits(0x7F800001u);
  CK(!float_is_finite(nan_v)); CK(!float_is_finite(pinf)); CK(!float_is_finite(ninf)); CK(!float_is_finite(snan)); CK(float_is_finite(0.0f)); CK(float_is_finite(-3.0f)); CK(float_is_finite(bits(0x00000001u))); CK(float_is_finite(bits(0x7F7FFFFFu)));
  const float bad[] = {nan_v, pinf, ninf, snan};
  for (unsigned i = 0; i < 4; ++i) { G29UReceipt r; r.begin(); CK(!r.point(0, 0, bad[i])); CK(r.phase() == G29UReceipt::Phase::Failed); CK(r.failure() == G29UReceipt::Failure::Sample); CK(r.pixel(0) == G29UReceipt::Pixel::Problem); }
  { G29UReceipt r; r.begin(); CK(!r.point(0, 0, 3.01f)); }
  for (unsigned i = 0; i < 4; ++i) { NativeThermalGate g; for (uint32_t t = 0; t <= 25000u; t += 500u) g.observe(t, bad[i], 60.0f, true); CK(!g.ready(25000u)); NativeThermalGate h; for (uint32_t t = 0; t <= 25000u; t += 500u) h.observe(t, 60.0f, bad[i], true); CK(!h.ready(25000u)); CK(!NativeThermalGate::live_sample_safe(bad[i], 60.0f)); CK(!NativeThermalGate::live_sample_safe(60.0f, bad[i])); }
  for (unsigned i = 0; i < 4; ++i) {
    NativeReadiness::Live s; s.tool0 = true; s.dual_auto_park = true; s.xyz_trusted = true; s.t1_x = 362.0f; s.t1_home_x = 362.0f; s.bed_c = 60.0f; s.bed_set_c = 60.0f; s.probe_offset_z = -1.1f;
    CK(NativeReadiness::evaluate(s) == NativeReadiness::Gate::NoPhysicalT1Witness);                       // Kontrolle: erreicht das Ende der Kette
    NativeReadiness::Live a = s; a.t1_x = bad[i]; CK(NativeReadiness::evaluate(a) == NativeReadiness::Gate::X2SoftwarePosition);
    NativeReadiness::Live b = s; b.bed_c = bad[i]; CK(NativeReadiness::evaluate(b) == NativeReadiness::Gate::Temperature);
    NativeReadiness::Live c = s; c.bed_set_c = bad[i]; CK(NativeReadiness::evaluate(c) == NativeReadiness::Gate::Temperature);
    NativeReadiness::Live d = s; d.probe_offset_z = bad[i]; CK(NativeReadiness::evaluate(d) == NativeReadiness::Gate::OffsetInvalid);
  }
  std::printf("SV04 NEXT fast-math native NaN/Inf guard PASS checks=%u\n", checks); return 0;
}
