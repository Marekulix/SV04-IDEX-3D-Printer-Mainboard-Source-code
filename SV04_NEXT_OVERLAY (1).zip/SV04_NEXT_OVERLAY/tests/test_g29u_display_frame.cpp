#include "../include/SV04NextG29UDisplayFrame.hpp"
#include <assert.h>
#include <stdio.h>
#include <math.h>
using sv04next::G29UReceipt;
using sv04next::G29UDisplayFrame;
using sv04next::DwinView;
static unsigned checks=0;
#define CK(x) do {assert((x));++checks;} while(0)
int main(){
 G29UReceipt r;
 CK(G29UDisplayFrame::percent(r)==0);
 CK(!G29UDisplayFrame::success(r));
 CK(!G29UDisplayFrame::EEPROM_verified(r));
 for(unsigned i=0;i<16;++i) CK(G29UDisplayFrame::pixel(r,i%4,i/4)==DwinView::Color::Gray);
 CK(r.begin());
 for(unsigned i=0;i<15;++i){
  CK(r.point(i%4,i/4,0.0f));
  CK(!G29UDisplayFrame::success(r));
  CK(G29UDisplayFrame::pixel(r,i%4,i/4)==DwinView::Color::Yellow);
  CK(!G29UDisplayFrame::EEPROM_verified(r));
 }
 CK(G29UDisplayFrame::percent(r)==93);
 CK(!r.finish_ram_only());
 CK(!G29UDisplayFrame::success(r));
 CK(!G29UDisplayFrame::EEPROM_verified(r));
 CK(r.begin());
 for(unsigned i=0;i<16;++i){
  CK(r.point(i%4,i/4,0.2f));
  CK(G29UDisplayFrame::pixel(r,i%4,i/4)==DwinView::Color::Yellow);
 }
 CK(G29UDisplayFrame::percent(r)==100);
 CK(!G29UDisplayFrame::success(r)); // 16/16 alone is NOT success
 CK(r.finish_ram_only());
 CK(G29UDisplayFrame::success(r));
 CK(fabsf(G29UDisplayFrame::reference(r)-0.2f)<0.00001f);
 for(unsigned i=0;i<16;++i)CK(G29UDisplayFrame::pixel(r,i%4,i/4)==DwinView::Color::Green);
 CK(G29UDisplayFrame::pixel(r,4,3)==DwinView::Color::Gray);
 CK(G29UDisplayFrame::pixel(r,0,4)==DwinView::Color::Gray);
 CK(!G29UDisplayFrame::EEPROM_verified(r));
 // Failure does not create a misleading green success mesh.
 for(unsigned fail_at=0;fail_at<16;++fail_at){
  CK(r.begin());
  for(unsigned i=0;i<fail_at;++i){
   CK(r.point(i%4,i/4,-0.12f));
   CK(G29UDisplayFrame::pixel(r,i%4,i/4)==DwinView::Color::Yellow);
  }
  CK(!r.fail());
  CK(!G29UDisplayFrame::success(r));
  CK(!G29UDisplayFrame::EEPROM_verified(r));
  for(unsigned i=0;i<16;++i) CK(G29UDisplayFrame::pixel(r,i%4,i/4)!=DwinView::Color::Green);
 }
 printf("SV04 NEXT G29U display frame host tests PASS checks=%u\n",checks);
}
