#include "../include/SV04NextG28PassiveReceipt.hpp"
#include <cassert>
#include <iostream>
int main(){
  using R=sv04next::G28PassiveReceipt;
  unsigned checks=0;
  for(unsigned t=0;t<65536;t++){
    R r;
    { R::Scope s(r,t); assert(r.view().phase==R::Phase::Entered);++checks;
      assert(r.view().sequence==1);++checks;
      assert(!r.allows_motion()&&!r.allows_heating()&&!r.allows_eeprom());++checks;
      if((t&1)==0)s.finish(t+17,(t&2)!=0,(t&4)!=0,(t&8)!=0,(t&16)!=0);
    }
    const auto &v=r.view();
    if(t&1)assert(v.phase==R::Phase::ReturnedEarly);
    else assert(v.phase==R::Phase::EndObservedTrusted || v.phase==R::Phase::EndObservedUntrusted);
    ++checks;
    assert(!v.physically_parked_t1&&!v.auto_start_allowed&&!v.eeprom_allowed);++checks;
  }
  R r;
  assert(r.begin(0xFFFFFFFEu));
  assert(r.finish(2u,true,true,true,true)); // natural millis wrap
  assert(r.view().phase==R::Phase::EndObservedTrusted);
  assert(r.begin(100));
  assert(!r.begin(101)); // cannot re-enter and overwrite an active G28
  assert(!r.finish(700102,true,true,true,true)); // implausible duration
  assert(r.view().phase==R::Phase::ClockInvalid);
  assert(r.begin(120));r.early_return();
  assert(r.view().phase==R::Phase::ReturnedEarly);
  std::cout<<"PASS G28 passive receipt checks="<<checks+7<<"; no command or physical witness\n";
}
