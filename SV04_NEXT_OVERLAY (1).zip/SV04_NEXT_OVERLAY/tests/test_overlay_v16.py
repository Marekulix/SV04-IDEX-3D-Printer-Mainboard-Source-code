"""apply_native_guard_v16.apply() wird hier TATSAECHLICH ausgefuehrt (synthetische OEM-Wurzel aus den Fixtures; KEIN echtes OEM). Prueft den Sicherheitsvertrag des Patchers."""
import contextlib, hashlib, io, os, re, sys, tempfile
from pathlib import Path
root = Path(__file__).resolve().parents[1]; sys.path[:0] = [str(root / 'integration'), str(root / 'tests')]
with contextlib.redirect_stdout(io.StringIO()): import test_overlay_v14 as T
import apply_native_guard_v16 as v16, apply_native_guard_v15 as v15
v14 = T.v14; src = dict(T.src); names = list(v14.OEM_BLOBS); HEAD = [root / 'include' / n for n in v16.HEADERS]
blob = lambda b: hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
def make():
    d = Path(tempfile.mkdtemp()); shas = {}
    for n in names: p = d / n; p.parent.mkdir(parents=True, exist_ok=True); b = src[n].encode('utf-8'); p.write_bytes(b); shas[n] = blob(b)
    v14.OEM_BLOBS = shas; return d
def tree(d): return {str(p.relative_to(d)): p.read_bytes() for p in sorted(d.rglob('*')) if p.is_file()}
def refuses(fn, *words):
    try: fn()
    except v16.PatchRefused as e:
        assert all(w in str(e) for w in words), (words, str(e)); return str(e)
    raise AssertionError('Patch haette verweigert werden muessen: ' + str(words))
n_checks = 0
def ck(c, msg=''):
    global n_checks
    assert c, msg; n_checks += 1
texts = [h.read_text(encoding='utf-8') for h in HEAD]; eng, glue = texts[-2], texts[-1]
# 1 Normalfall
d = make(); before = tree(d); rep = v16.apply(d, HEAD, d / 'ev.json'); after = tree(d)
changed = sorted(k for k in before if before[k] != after.get(k)); ck(len(changed) == 3 and all(n in changed for n in (v14.G28, v14.RTS, 'Marlin/src/gcode/bedlevel/abl/G29.cpp')), changed)
ck(all(before[n] == after[n] for n in ('Marlin/Configuration.h', 'Marlin/src/module/probe.cpp')), 'Configuration.h/probe.cpp veraendert')
new = sorted(k for k in after if k not in before and k.endswith('.hpp')); ck(len(new) == 16, len(new)); ck(after['Marlin/src/feature/sv04_next/SV04NextAuto60Engine.hpp'].decode() == eng and after['Marlin/src/feature/sv04_next/SV04NextAuto60Glue.hpp'].decode() == glue)
ck(rep['block'] == 13 and rep['auto60_engine_compiled_by_default'] is False and rep['auto60_start_trigger_present'] is False and rep['auto60_eeprom_wired'] is False and rep['eeprom_write'] is False and rep['flash_approved'] is False)
rts = after[v14.RTS].decode(); lines = rts.splitlines(); ti = [i for i, l in enumerate(lines) if 'auto60_glue_tick()' in l]; ck(len(ti) == 1 and lines[ti[0] - 2].strip() == '#if defined(SV04_NEXT_AUTO60_ENGINE)' and lines[ti[0] + 1].strip() == '#endif', 'tick nicht unter Makro')
ck('namespace sv04next { Auto60Engine auto60_engine; }' in rts and rts.index('#if defined(SV04_NEXT_AUTO60_ENGINE)') < rts.index('Auto60Engine auto60_engine'), 'Instanz nicht unter Makro')
ck(rts.count('SV04NextAuto60Glue.hpp') == 1)
for n in (v14.G28, v14.RTS, 'Marlin/src/gcode/bedlevel/abl/G29.cpp', 'Marlin/src/module/probe.cpp', 'Marlin/Configuration.h'):
    t = after[n].decode(); ck('auto60_request_start' not in t, 'Start-Ausloeser in ' + n); ck(not re.search(r'^\s*#\s*define\s+SV04_NEXT_AUTO60_ENGINE', t, re.M), 'Makro gesetzt in ' + n)
ck(not [k for k in after if '.sv04tmp-' in k])
# 2 erneutes Anwenden: SHA-Abweichung, nichts veraendert
b2 = tree(d); refuses(lambda: v16.apply(d, HEAD), 'SHA mismatch'); ck(tree(d) == b2)
# 3 dry-run
d3 = make(); b3 = tree(d3); r3 = v16.apply(d3, HEAD, d3 / 'never.json', dry_run=True, diff_out=d3 / 'review.diff'); a3 = tree(d3); ck(r3['dry_run'] is True and {k for k in a3 if k not in b3} == {'review.diff'})
dt = a3['review.diff'].decode(); ck('auto60_glue_tick' in dt and 'Auto60Glue.hpp' in dt and 'Configuration.h' not in dt)
# 4 Atomaritaet an JEDER Position
real_replace = os.replace; total = 19
for k in range(1, total + 1):
    dk = make(); bk = tree(dk); cnt = [0]
    def flaky(a, b, _c=cnt, _k=k):
        _c[0] += 1
        if _c[0] == _k: raise OSError('simulierter Schreibfehler')
        return real_replace(a, b)
    os.replace = flaky
    try:
        try: v16.apply(dk, HEAD); raise AssertionError('Fehler haette durchschlagen muessen')
        except OSError: pass
    finally: os.replace = real_replace
    ck(tree(dk) == bk, f'Position {k}: Wurzel nicht byte-identisch')
# 5 Verweigerungen des Sicherheitsvertrags
def with_hdr(idx, fn):
    t = list(HEAD); tmp = Path(tempfile.mkdtemp()) / HEAD[idx].name; tmp.write_text(fn(texts[idx]), encoding='utf-8'); t[idx] = tmp; return t
def bad(idx, fn, *words):
    dd = make(); b = tree(dd); refuses(lambda: v16.apply(dd, with_hdr(idx, fn)), *words); ck(tree(dd) == b, 'Wurzel veraendert trotz Verweigerung')
bad(-2, lambda t: t.replace('bool allow_motion() const { return false; }', 'bool allow_motion() const { return true; }'), 'safety contract')
bad(-2, lambda t: t + '\n// settings.save();\n', 'forbidden token')
bad(-2, lambda t: t.replace('// SV04 NEXT 13: EINE auslieferbare', '// fremd: EINE auslieferbare'), 'provenance')
bad(-2, lambda t: t.replace('SetBed60, SetBedOff, Home, Measure, Commit };', 'SetBed60, SetBedOff, Home, Measure, Commit, Reset };'), 'safety contract')
bad(-1, lambda t: t.replace('SV04_NEXT_ENQUEUE("G29 U")', 'SV04_NEXT_ENQUEUE("G29 U S")'), 'only G28 and G29 U')
bad(-1, lambda t: t.replace('SV04_NEXT_SET_BED_TARGET(60); break;', 'SV04_NEXT_SET_BED_TARGET(70); break;'), 'only 60 and 0')
bad(-1, lambda t: t.replace('o.eeprom_commit_supported = false;', 'o.eeprom_commit_supported = true;'), 'eeprom_commit_supported')
bad(-1, lambda t: t.replace('case Auto60Engine::Action::Commit: auto60_engine.notify_action_failed(); break;', 'case Auto60Engine::Action::Commit: SV04_NEXT_ENQUEUE("G28"); break;'), 'Commit action must abort')
bad(-1, lambda t: t.replace('  if (auto60_in_tick()) return;', '  // kein Schutz'), 're-entrancy')
bad(-1, lambda t: t.replace('#endif // SV04_NEXT_AUTO60_ENGINE', '#endif'), 'entirely under')
bad(-1, lambda t: t.replace('namespace sv04next {', 'namespace sv04next { /* M500 */ int x_m500 = 0; const char *p = "M500";', 1), 'forbidden token')
bad(-1, lambda t: t.replace('// SV04 NEXT 13: Marlin-Bruecke', '// Fremd'), 'provenance')
# 6 Falsche Kopfzahl
refuses(lambda: v16.render(src, *texts[:-1]), '16 headers')
print(f'PASS v16: {n_checks} Pruefungen (apply() tatsaechlich ausgefuehrt, Atomaritaet an 19 Positionen, 12 Verweigerungen); synthetisches OEM, KEIN Marlin-Build')
