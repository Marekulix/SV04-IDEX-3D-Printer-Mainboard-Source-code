#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 tests/test_overlay_v14.py
for opt in 0 2; do
  for name in native_idex_homing_trace native_idex_evidence; do
    g++ -std=c++11 -O"${opt}" -Wall -Wextra -Werror -pedantic "tests/test_${name}.cpp" -o "/tmp/sv04-10-${name}-${opt}"
    "/tmp/sv04-10-${name}-${opt}"
  done
done
for name in native_idex_homing_trace native_idex_evidence; do
  g++ -std=c++11 -O1 -g -fsanitize=undefined -fno-sanitize-recover=all -Wall -Wextra -Werror -pedantic "tests/test_${name}.cpp" -o "/tmp/sv04-10-${name}-ubsan"
  "/tmp/sv04-10-${name}-ubsan"
done
if command -v clang++ >/dev/null; then
  for name in native_idex_homing_trace native_idex_evidence; do
    clang++ -std=c++11 -O1 -g -fsanitize=address,undefined -fno-sanitize-recover=all -Wall -Wextra -Werror -pedantic "tests/test_${name}.cpp" -o "/tmp/sv04-10-${name}-clang"
    "/tmp/sv04-10-${name}-clang"
  done
fi
echo 'BLOCK 10 FULL FOCUSED REGRESSION PASS'
