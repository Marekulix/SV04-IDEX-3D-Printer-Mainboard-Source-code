#include "../include/SV04NextAuto60ViewModel.hpp"
#include <cassert>
#include <cstdio>
using namespace sv04next;
static int checks=0;
#define CHECK(x) do{++checks;assert(x);}while(0)
int main(){
  using V=Auto60ViewModel; using R=G29UReceipt;using B=ReceiptBinder;
  SequencedController controller;R receipt;B binder;
  auto view=V::make(controller,receipt,binder,false);
  CHECK(view.screen==V::Screen::Idle);CHECK(!view.ram_only_16_of_16);
  CHECK(!view.eeprom_saved);CHECK(!view.touch_button_integrated);
  CHECK(!V::writes_dwin_vp());CHECK(!V::saves_eeprom());CHECK(!V::controls_heaters());
  CHECK(receipt.begin());CHECK(binder.prepare(99,0));
  B::Live live;live.t1_witness=true;live.bed_stable_60=true;live.probe_stowed=true;
  CHECK(binder.observe(99,receipt,live));
  for(uint8_t i=0;i<16;i++){
    CHECK(receipt.point(i%4,i/4,(float)i*.01f));
    CHECK(binder.observe(99,receipt,live));
    view=V::make(controller,receipt,binder,true);
    CHECK(!view.ram_only_16_of_16);CHECK(view.percent<100);
    // Since controller has never accepted/verified this run, its display may
    // not show 16/16 success and may not render any green cells.
    for(int j=0;j<16;++j)CHECK(view.cell[j].color!=DwinView::Color::Green);
  }
  CHECK(receipt.finish_ram_only());CHECK(binder.observe(99,receipt,live));
  CHECK(binder.ram_complete());
  view=V::make(controller,receipt,binder,true);
  CHECK(!view.ram_only_16_of_16);CHECK(view.percent<100);
  // No independent T1 witness means no verified UI success.
  view=V::make(controller,receipt,binder,false);
  CHECK(!view.physical_park_verified);CHECK(!view.ram_only_16_of_16);
  // A rejected binder cannot change a failed terminal frame to green.
  binder.revoke();view=V::make(controller,receipt,binder,true);
  CHECK(!view.ram_only_16_of_16);
  for(auto c:view.cell)CHECK(c.color!=DwinView::Color::Green);
  std::printf("AUTO60 VIEW MODEL PASS checks=%d; NO DWIN HMI MUTATION\n",checks);
}
