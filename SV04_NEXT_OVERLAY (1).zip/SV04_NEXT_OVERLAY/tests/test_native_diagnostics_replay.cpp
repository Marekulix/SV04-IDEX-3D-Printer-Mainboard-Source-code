// Joint read-only replay: native receipt -> timeline -> status -> 4x4 heights.
#include "../include/SV04NextMeshMapPacket.hpp"
#include <cassert>
#include <cstdio>
using namespace sv04next;
static unsigned checks=0;
#define CHECK(x) do{++checks;assert(x);}while(0)
int main(){
  G29UReceipt receipt;
  NativeEventTimeline timeline;
  NativeReadiness readiness;
  NativeStatusPacket status;
  MeshMapPacket mesh;
  T1EndstopObserver sensor;
  NativeReadiness::Live live;
  live.physical_t1_park_witness=false;
  live.probe_stow_witness=false;
  uint32_t now=10;
  auto update=[&](){
    readiness.observe(now,live,receipt);
    timeline.observe(now,readiness.view(),sensor);
    status.capture(now,readiness.view(),timeline.view(),sensor);
    mesh.capture(receipt,timeline.view(),status);
    CHECK(!status.permits_heating() && !status.permits_motion() && !status.permits_eeprom());
    CHECK(!mesh.allows_heating() && !mesh.allows_motion() && !mesh.allows_eeprom());
    CHECK(!readiness.allow_automatic_g29());
    CHECK(NativeStatusPacket::verify(status.bytes(),32));
    CHECK(MeshMapPacket::verify(mesh.bytes(),48));
  };
  update();CHECK(status.display()==NativeStatusPacket::Display::Idle);
  CHECK(mesh.state()==MeshMapPacket::MapState::Empty);
  CHECK(receipt.begin());
  now+=100;update();
  CHECK(status.display()==NativeStatusPacket::Display::Measuring);
  CHECK(mesh.state()==MeshMapPacket::MapState::InProgress);
  for(unsigned i=0;i<16;++i){
    CHECK(receipt.point((uint8_t)(i%4),(uint8_t)(i/4),0.2f + 0.0125f*i));
    now+=100;update();
    CHECK(status.display()==NativeStatusPacket::Display::Measuring);
    CHECK(mesh.state()==MeshMapPacket::MapState::InProgress);
    CHECK(mesh.bytes()[10]==i+1);
    CHECK((mesh.bytes()[44]&2u)==0u); // no green completion during 16 samples
  }
  CHECK(receipt.finish_ram_only());
  now+=100;update();
  CHECK(status.display()==NativeStatusPacket::Display::RamComplete);
  CHECK(mesh.state()==MeshMapPacket::MapState::RamComplete);
  CHECK((status.bytes()[22]&1u)==1u);
  // Run completed; no false further "new completion" event.
  now+=100;update();
  CHECK(timeline.view().event==NativeEventTimeline::Event::None);
  // A gap invalidates both outputs, never inheriting a green RAM mesh.
  now+=NativeEventTimeline::MaxGapMs+1;update();
  CHECK(timeline.view().quality==NativeEventTimeline::Quality::Gap);
  CHECK(status.display()==NativeStatusPacket::Display::Invalid);
  CHECK(mesh.state()==MeshMapPacket::MapState::Invalid);
  now+=50;update();
  CHECK(status.display()==NativeStatusPacket::Display::Invalid);
  // A new manual G29 U run is observed, but never starts an automatic action.
  CHECK(receipt.begin());now+=100;update();
  CHECK(status.display()==NativeStatusPacket::Display::Measuring);
  CHECK(mesh.state()==MeshMapPacket::MapState::InProgress);
  CHECK(!status.permits_motion());
  CHECK(!receipt.refuse(G29UReceipt::Failure::Preconditions));
  now+=100;update();
  CHECK(status.display()==NativeStatusPacket::Display::Refused);
  CHECK(mesh.state()==MeshMapPacket::MapState::Invalid);
  // source / firmware restart simulation; returned live receipt never green.
  G29UReceipt empty;
  readiness.observe(now+100,live,empty);
  timeline.observe(now+100,readiness.view(),sensor);
  status.capture(now+100,readiness.view(),timeline.view(),sensor);
  mesh.capture(empty,timeline.view(),status);
  CHECK(status.display()==NativeStatusPacket::Display::Invalid);
  CHECK(mesh.state()!=MeshMapPacket::MapState::RamComplete);
  printf("INTEGRATED NATIVE DIAG REPLAY PASS checks=%u (read only, no flash)\n",checks);
}
