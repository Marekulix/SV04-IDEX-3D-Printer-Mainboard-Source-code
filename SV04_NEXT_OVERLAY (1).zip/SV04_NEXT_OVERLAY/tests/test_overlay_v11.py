"""Offline source fixture and dangerous-header rejection for v11."""
from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(root/'integration'),str(root/'tests')]
import apply_native_guard_v11 as patch
import test_overlay_v8 as fixture
src=dict(fixture.src)
files=('SV04NextNativeThermalGate.hpp','SV04NextVisitProof.hpp',
 'SV04NextG29UReceipt.hpp','SV04NextNativeReadiness.hpp',
 'SV04NextT1EndstopObserver.hpp','SV04NextNativeEventTimeline.hpp',
 'SV04NextNativeStatusPacket.hpp')
a=[(root/'include'/x).read_text() for x in files]
res=patch.render(src,*a)
rt=res[patch.RTS]
assert rt.count('native_status_packet.capture(')==1
assert rt.count('NativeStatusPacket native_status_packet;')==1
assert rt.count('native_event_timeline.observe(')==1
assert rt.count('native_readiness.observe(')==1
assert rt.count('t1_endstop_observer.observe(')==2
assert res[patch.TARGET]==a[-1]
assert res['Marlin/Configuration.h']==src['Marlin/Configuration.h']
assert res['Marlin/src/module/probe.cpp']==src['Marlin/src/module/probe.cpp']
assert 'n.physical_t1_park_witness = false;' in rt
assert 'n.probe_stow_witness = false;' in rt
for fragment,replacement in (
 ('bool permits_motion()const{return false;}','bool permits_motion()const{return true;}'),
 ('bool permits_heating()const{return false;}','bool permits_heating()const{return true;}'),
 ('bool permits_eeprom()const{return false;}','bool permits_eeprom()const{return true;}'),
 ('bool is_physical_park_verified()const{return false;}',
  'bool is_physical_park_verified()const{return true;}'),
 ('// SV04 NEXT 7: RAM-ONLY, versioned 32-byte diagnostic snapshot.', '// untrusted'),
 ('data_[23] reserved 0','changed permission flag')):
    try: patch.render(src,*a[:-1],a[-1].replace(fragment,replacement))
    except patch.PatchRefused: pass
    else: raise AssertionError('Unsafe status header was accepted: '+fragment)
try:patch.render(res,*a)
except patch.PatchRefused:pass
else:raise AssertionError('Double patch wrongly accepted')
assert "sendData" not in rt[rt.index('native_status_packet.capture('):rt.index('native_status_packet.capture(')+200]
print('PASS v11 guarded native status packet overlay, no DWIN/EEPROM/actuation')
