#include "../include/SV04NextAbortSupervisor.hpp"
#include <cassert>
#include <cstdio>
using namespace sv04next;
static unsigned checks=0;
#define CHECK(X) do{++checks;assert(X);}while(0)
static AbortQuarantine::Sample quiet(){
  AbortQuarantine::Sample s;
  s.valid=true;s.planner_idle=true;s.queue_empty=true;s.movement_idle=true;
  s.probe_stowed=true;s.bed_target_zero=true;s.heater_command_idle=true;
  s.offset_unchanged=true;s.prior_mesh_restored=true;s.t1_physical_park_verified=true;
  return s;
}
int main(){
  for(uint32_t run=1;run<=1100;++run){
    AbortSupervisor g;
    CHECK(!g.attach(0,0));CHECK(g.attach(run,0));CHECK(!g.attach(run,0));
    OperationLedger ledger;OperationLedger::Ticket t;OperationLedger::Live s;
    s.t1_physically_witnessed=true;s.target_is_60=true;
    CHECK(ledger.issue(run,OperationLedger::Step::Heat60,100,s,t));
    CHECK(g.observe_ledger(run,100,ledger));
    CHECK(!g.observe_ledger(run+1,100,ledger));
    if(run%2==0){
      ledger.abort();
      CHECK(!g.observe_ledger(run,200,ledger));
      CHECK(g.barrier().cause()==AbortQuarantine::Cause::PlannerFault);
    }else{
      auto incident=g.abort(run,200,AbortQuarantine::Cause::UserCancel,42);
      CHECK(incident.valid());CHECK(g.barrier().cause()==AbortQuarantine::Cause::UserCancel);
    }
    CHECK(g.phase()==AbortSupervisor::Phase::Aborted);
    CHECK(!g.observe_ledger(run,300,ledger));
    CHECK(!g.abort(run,300,AbortQuarantine::Cause::SensorFault).valid());
    CHECK(!g.acknowledge(run,300,true));
    CHECK(!g.close(run,300));
    auto sample=quiet();
    for(uint32_t i=0;i<=20;++i){CHECK(g.sample(run,400+250*i,sample));}
    CHECK(g.barrier().state()==AbortQuarantine::State::StableQuiet);
    CHECK(!g.acknowledge(run,5400,false));CHECK(g.acknowledge(run,5400,true));
    CHECK(g.close(run,5400));CHECK(g.phase()==AbortSupervisor::Phase::Closed);
    CHECK(!g.authorizes_gcode());CHECK(!g.authorizes_eeprom());
    CHECK(!g.authorizes_auto_restart());
    CHECK(!g.sample(run,5401,sample));
    FaultTrace::Row row;CHECK(g.trace().latest(0,row));
    CHECK(row.event==FaultTrace::Event::RecoveryClosed);
    CHECK(g.trace().size()>=5);
  }
  std::printf("ABORT SUPERVISOR HOST PASS checks=%u, AUTO_ACTUATION=0\n",checks);
}
