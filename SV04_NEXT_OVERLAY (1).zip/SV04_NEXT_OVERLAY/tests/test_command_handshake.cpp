#include "../include/SV04NextCommandHandshake.hpp"
#include <cassert>
#include <cstdio>
using namespace sv04next;
static int checks=0;
#define CHECK(x) do {++checks;assert(x);}while(0)
int main(){
  using H=CommandHandshake;
  H::Live safe;safe.physical_t1_verified=true;safe.bed_stable_60=true;safe.xyz_homed=true;
  safe.g29_ram_16_success=true;
  H::Live unknown=safe;unknown.physical_t1_verified=false;
  H h;H::Ticket a,b;
  CHECK(!h.issue(0,H::Step::Heat60,0,safe,a));
  CHECK(!h.issue(1,H::Step::Heat60,0,unknown,a));
  CHECK(!h.issue(1,H::Step::HomeXYZ,0,safe,a));
  CHECK(!h.issue(1,H::Step::ProbeG29U,0,safe,a));
  CHECK(!h.issue(1,H::Step::RestoreRAM,0,unknown,a)); // no unverified rollback
  // Restart with a fresh run: test the real one-command-at-a-time order.
  CHECK(h.reset_after_quiescence(2,safe));
  CHECK(h.issue(2,H::Step::Heat60,100,safe,a));
  CHECK(a.valid());CHECK(a.run==2);CHECK(h.pending().dispatch==a.dispatch);
  CHECK(!h.issue(2,H::Step::Heat60,100,safe,b));
  H::Ticket wrong=a; wrong.dispatch++;
  CHECK(!h.confirm(wrong,true,110,safe));
  CHECK(!h.confirm(a,true,30101,safe)); // timeout locks; no late retry
  CHECK(h.state()==H::State::Locked);CHECK(!h.confirm(a,true,30102,safe));
  CHECK(!h.reset_after_quiescence(2,safe));
  CHECK(h.reset_after_quiescence(3,safe));
  CHECK(h.issue(3,H::Step::Heat60,0xFFFFFFFAu,safe,a));
  CHECK(h.poll(4));CHECK(h.confirm(a,true,5,safe)); // uint32 wrap
  CHECK(!h.confirm(a,true,5,safe));
  CHECK(!h.issue(3,H::Step::HomeXYZ,6,safe,b)); // ACK not consumed
  CHECK(h.consume(a));CHECK(!h.consume(a));
  CHECK(!h.issue(4,H::Step::HomeXYZ,6,safe,b));
  CHECK(h.issue(3,H::Step::HomeXYZ,6,safe,b));
  CHECK(!h.confirm(a,true,9,safe));
  CHECK(h.confirm(b,true,10,safe));CHECK(h.consume(b));
  H::Ticket c;
  CHECK(h.issue(3,H::Step::ProbeG29U,11,safe,c));
  H::Live missing=safe;missing.g29_ram_16_success=false;
  CHECK(!h.confirm(c,true,12,missing));CHECK(h.state()==H::State::Locked);
  CHECK(!h.ram_only_success());
  CHECK(h.reset_after_quiescence(4,safe));
  H::Ticket t;
  CHECK(h.issue(4,H::Step::Heat60,100,safe,t));CHECK(h.confirm(t,true,101,safe));CHECK(h.consume(t));
  CHECK(h.issue(4,H::Step::HomeXYZ,102,safe,t));CHECK(h.confirm(t,true,103,safe));CHECK(h.consume(t));
  CHECK(h.issue(4,H::Step::ProbeG29U,104,safe,t));CHECK(h.confirm(t,true,105,safe));CHECK(h.consume(t));
  CHECK(h.ram_only_success());
  CHECK(!h.issue(4,H::Step::Heat60,106,safe,t));
  CHECK(!h.issue(4,H::Step::ProbeG29U,106,safe,t));
  CHECK(!h.can_write_eeprom());CHECK(!h.hardware_approved());CHECK(!h.native_actuators_connected());
  // Reset MUST be denied when the transport is not quiescent.
  h.revoke();H::Live busy=safe;busy.planner_idle=false;
  CHECK(!h.reset_after_quiescence(5,busy));
  busy=safe;busy.queue_empty=false;CHECK(!h.reset_after_quiescence(5,busy));
  busy=safe;busy.probe_stowed=false;CHECK(!h.reset_after_quiescence(5,busy));
  CHECK(h.reset_after_quiescence(5,safe));
  // Test each individual hard safety gate for the first physical action.
  for(int i=0;i<12;++i){
    H q;auto v=safe;
    switch(i){case 0:v.printer_stopped=true;break;case 1:v.printing=true;break;
      case 2:v.paused=true;break;case 3:v.planner_idle=false;break;
      case 4:v.queue_empty=false;break;case 5:v.t0_active=false;break;
      case 6:v.physical_t1_verified=false;break;case 7:v.auto_park=false;break;
      case 8:v.bltouch_healthy=false;break;case 9:v.heater_healthy=false;break;
      case 10:v.offset_unchanged=false;break;case 11:v.probe_stowed=false;break;}
    H::Ticket x;CHECK(!q.issue(42,H::Step::Heat60,0,v,x));CHECK(!x.valid());
  }
  // ACK cannot bypass the postcondition even if the request was accepted.
  for(int i=0;i<8;++i){
    H q;H::Ticket x;CHECK(q.issue(42,H::Step::Heat60,0,safe,x));
    auto v=safe;switch(i){case 0:v.printer_stopped=true;break;case 1:v.printing=true;break;
      case 2:v.paused=true;break;case 3:v.t0_active=false;break;
      case 4:v.physical_t1_verified=false;break;case 5:v.auto_park=false;break;
      case 6:v.offset_unchanged=false;break;case 7:v.bed_stable_60=false;break;}
    CHECK(!q.confirm(x,true,1,v));CHECK(q.state()==H::State::Locked);
  }
  // No successful fake ACK can complete a G29 U without its 16/16 receipt.
  for(unsigned i=0;i<5000;++i){
    H q;H::Ticket x;auto v=safe;
    CHECK(q.issue(42,H::Step::Heat60,i,v,x));CHECK(q.confirm(x,true,i+1,v));CHECK(q.consume(x));
    CHECK(q.issue(42,H::Step::HomeXYZ,i+2,v,x));CHECK(q.confirm(x,true,i+3,v));CHECK(q.consume(x));
    CHECK(q.issue(42,H::Step::ProbeG29U,i+4,v,x));
    v.g29_ram_16_success=false;CHECK(!q.confirm(x,true,i+5,v));
    CHECK(!q.ram_only_success());CHECK(!q.can_write_eeprom());
  }
  std::printf("COMMAND-HANDSHAKE PASS checks=%d EEPROM=0 MOTOR=0\n",checks);
}
