#include "../include/SV04NextHomingWitness.hpp"
#include <cassert>
#include <cstdio>
using namespace sv04next;
static int checks=0;
#define CHECK(X) do{++checks;assert(X);}while(0)
int main(){using H=HomingWitness;
 for(uint32_t i=1;i<=1200;++i){
  H h;H::Native s;s.t1_physical_witness=true;s.bed_60_stable=true;s.homing_epoch=i;
  CHECK(h.begin(i,i+300,100,s));
  CHECK(!h.verified(i,i+300));
  auto done=s;done.homing_epoch=i+1;done.xyz_homed=true;
  CHECK(h.finish(i,i+300,200,true,done));CHECK(h.verified(i,i+300));
  CHECK(!h.verified(i+1,i+300));CHECK(!h.physically_parked_t1());CHECK(!h.starts_g28());
  CHECK(!h.finish(i,i+300,300,true,done));
 }
 for(uint32_t i=1;i<=800;++i){
  H h;H::Native s;s.t1_physical_witness=true;s.bed_60_stable=true;s.homing_epoch=10;
  CHECK(h.begin(i,20,100,s));
  auto done=s;done.homing_epoch=11;done.xyz_homed=true;
  switch(i%8){
    case 0:done.homing_epoch=10;break;
    case 1:done.xyz_homed=false;break;
    case 2:done.movement=true;break;
    case 3:done.queue_pending=true;break;
    case 4:done.t1_physical_witness=false;break;
    case 5:done.bed_60_stable=false;break;
    case 6:done.offset_unchanged=false;break;
    default:done.probe_stowed=false;break;
  }
  CHECK(!h.finish(i,20,200,true,done));CHECK(h.phase()==H::Phase::Rejected);
 }
 {H h;H::Native s;s.t1_physical_witness=true;s.bed_60_stable=true;
  CHECK(h.begin(3,4,0xFFFFFFF0u,s));s.homing_epoch++;
  s.xyz_homed=true;CHECK(h.finish(3,4,0x00000020u,true,s));
 }
 std::printf("HOMING-WITNESS PASS checks=%d; fresh event required, T1 NOT PROVEN\n",checks);
}
