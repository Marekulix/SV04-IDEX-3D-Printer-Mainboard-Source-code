#!/usr/bin/env bash
# Mutationskampagnen (dauern zusammen etwa 2 bis 3 Minuten): erzeugter G29-Code, Zustandsmaschine, Marlin-Bruecke.
set -uo pipefail
cd "$(dirname "$0")/.."
python3 harness/mutate_g29.py | tail -1
python3 tools/mutate_engine.py | tail -1
python3 harness/mutate_glue.py | tail -1
