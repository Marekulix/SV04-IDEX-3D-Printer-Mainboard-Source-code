#!/usr/bin/env python3
from pathlib import Path
base=Path(__file__).resolve().parents[1]
ledger=(base/'include/SV04NextOperationLedger.hpp').read_text()
fence=(base/'include/SV04NextAbortQuarantine.hpp').read_text()
supervisor=(base/'include/SV04NextAbortSupervisor.hpp').read_text()
trace=(base/'include/SV04NextFaultTrace.hpp').read_text()
assert 'bool restart(uint32_t, const Live &){ return false; }' in ledger
assert 'restart_supervised' in ledger and 'q.recovery_recorded()' in ledger
assert 'q.token().run!=owner_' in ledger
assert 'StableQuietMs=5000' in fence
assert 'MaxSampleGapMs=1000' in fence
assert 's.prior_mesh_restored && s.t1_physical_park_verified' in fence
assert 'bool permits_automatic_restart()const{return false;}' in fence
assert 'bool permits_motion()const{return false;}' in fence
assert 'bool permits_heating()const{return false;}' in fence
assert 'bool permits_eeprom()const{return false;}' in fence
assert 'bool stop_has_physically_occurred()const{return false;}' in fence
assert 'bool authorizes_gcode()const{return false;}' in supervisor
assert 'bool authorizes_eeprom()const{return false;}' in supervisor
assert 'static constexpr uint8_t Capacity=32;' in trace
print('OFFLINE BLOCK 5 SOURCE CONTRACT PASS; no actuation, no M500, no Github')
