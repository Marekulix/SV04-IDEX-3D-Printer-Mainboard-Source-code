#include "../include/SV04NextG28G29OrderWitness.hpp"
#include <cassert>
#include <iostream>
int main(){
 using R=sv04next::G28PassiveReceipt;
 using G=sv04next::G29UReceipt;
 using W=sv04next::G28G29OrderWitness;
 unsigned n=0;
 for(unsigned mask=0;mask<65536;mask++){
   R r;G g;W w;
   w.observe(0,r.view(),g);
   assert(w.view().quality==W::Quality::AwaitG28);++n;
   assert(r.begin(10));
   const bool xt=(mask&1)!=0,yt=(mask&2)!=0,zt=(mask&4)!=0;
   r.finish(15,xt,yt,zt,true);
   w.observe(16,r.view(),g);
   assert(w.view().quality==(xt&&yt&&zt?W::Quality::AwaitG29:W::Quality::G28NotTrusted));++n;
   g.begin();
   w.observe(20,r.view(),g);
   assert(!w.view().ram_only_g29_16 && !w.allows_eeprom() && !w.allows_motion());++n;
   for(unsigned i=0;i<16;i++)assert(g.point(i%4,i/4,float(i)*0.01f));
   assert(g.finish_ram_only());
   w.observe(30,r.view(),g);
   if(xt&&yt&&zt){
      assert(w.view().quality==W::Quality::OrderObserved);
      assert(w.view().ram_only_g29_16);
   } else {
      assert(!w.view().ram_only_g29_16);
      assert(w.view().quality==W::Quality::G28NotTrusted);
   }n+=2;
 }
 R r;G g;W w;
 r.begin(5);r.early_return();w.observe(6,r.view(),g);
 assert(w.view().quality==W::Quality::G28Interrupted);++n;
 r.begin(10);r.finish(12,true,true,true,true);w.observe(12,r.view(),g);
 g.begin();w.observe(130000,r.view(),g);
 assert(w.view().quality==W::Quality::Stale);++n;
 // An old G29 success prior to G28 cannot be linked to subsequent G28.
 R r2;G g2;W w2;g2.begin();for(int i=0;i<16;i++)g2.point(i%4,i/4,i);
 g2.finish_ram_only();r2.begin(1);r2.finish(10,true,true,true,true);
 w2.observe(11,r2.view(),g2);
 assert(!w2.view().ram_only_g29_16);++n;
 std::cout<<"PASS passive G28/G29 order checks="<<n<<"; no start permissions\n";
}
