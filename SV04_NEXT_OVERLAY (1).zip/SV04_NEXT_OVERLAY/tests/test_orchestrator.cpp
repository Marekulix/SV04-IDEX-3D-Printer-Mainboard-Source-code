#include "../include/SV04NextAuto60Orchestrator.hpp"
#include <cassert>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <cstdint>
using namespace sv04next;
static int checks=0;
#define CHECK(x) do { if (!(x)) { std::fprintf(stderr,"FAILED %s:%d %s\n",__FILE__,__LINE__,#x); return 1; } ++checks; } while(0)
using O=Auto60Orchestrator;
static O::Snapshot old_mesh(){ O::Snapshot x={};for(int i=0;i<16;i++)x.mesh[i]=i*.01f; x.z_offset=-1.10f; x.leveling_enabled=true;return x; }
static Auto60Inputs input(){return Auto60Inputs{};}
static int go_to_probe(O &o, Auto60Inputs &v,uint32_t t=1000){
  O::Snapshot old=old_mesh();
  CHECK(o.start(t,v,old)==O::Action::SetBedTo60);
  v.target_c=60; v.bed_c=60;
  CHECK(o.tick(t+100,v)==O::Action::None);
  CHECK(o.tick(t+19999,v)==O::Action::None);
  CHECK(o.tick(t+20100,v)==O::Action::RequestG28);
  v.homed_xyz=true;
  CHECK(o.homing_done(true,v)==O::Action::RequestG29U);
  return 0;
}
static int finished(O &o,Auto60Inputs &v){
  float measured[16];
  for(unsigned i=0;i<16;i++){
    const float fast=(float)i*.01f, slow=fast+.01f;
    CHECK(o.measurement(i,fast,slow,v));
    measured[i]=(fast*2.f+slow*3.f)*.2f;
  }
  CHECK(o.finished_points()==16);
  CHECK(o.probe_done(true,v,measured)==O::Action::FinishedRamOnly);
  CHECK(o.phase()==O::Phase::Review);
  CHECK(!o.eeprom_save_permitted());
  CHECK(o.cancel()==O::Action::None);
  return 0;
}
int main(){
  // Normal success (RAM-only), still never allow EEPROM.
  { O o; Auto60Inputs v=input(); CHECK(go_to_probe(o,v)==0);CHECK(finished(o,v)==0); }
  // Start preflight: prohibit queued motion, active print, both IDEX hazards, bad probe, etc.
  for(int fault=0;fault<12;fault++){
    O o; Auto60Inputs v=input();
    switch(fault){case 0:v.printing=true;break;case 1:v.motion_idle=false;break;
      case 2:v.queue_empty=false;break;case 3:v.tool0_selected=false;break;
      case 4:v.tool1_park_verified=false;break;case 5:v.heater_healthy=false;break;
      case 6:v.bltouch_healthy=false;break;case 7:v.estop_clear=false;break;
      case 8:v.probe_stowed=false;break;case 9:v.bed_c=NAN;break;
      case 10:v.bed_c=130;break;case 11:v.z_offset=-1.12f;break;}
    auto old=old_mesh();CHECK(o.start(1,v,old)==O::Action::None);
    CHECK(o.phase()==O::Phase::Failed); CHECK(!o.eeprom_save_permitted());
  }
  // Heating: temperature stable continuously; never accept the wrong target.
  { O o; auto v=input();auto old=old_mesh();CHECK(o.start(10,v,old)==O::Action::SetBedTo60);
    v.bed_c=60;v.target_c=50;CHECK(o.tick(20,v)==O::Action::None);
    v.target_c=60;CHECK(o.tick(30,v)==O::Action::None);
    v.bed_c=58;CHECK(o.tick(10000,v)==O::Action::None);
    v.bed_c=60;CHECK(o.tick(12000,v)==O::Action::None);
    CHECK(o.tick(31999,v)==O::Action::None);
    CHECK(o.tick(32000,v)==O::Action::RequestG28);
  }
  { O o;auto v=input();auto old=old_mesh();CHECK(o.start(0,v,old)==O::Action::SetBedTo60);
    v.target_c=60;v.bed_c=59.5f;
    CHECK(o.tick(O::heat_timeout_ms+1u,v)==O::Action::StopAndRestoreOldRamMesh);
    CHECK(o.fault()==O::Fault::HeatTimeout);CHECK(!o.eeprom_save_permitted());
  }
  // Every physical probe point is tested against disagreement, NaN and bad bed temperature.
  for(unsigned bad=0;bad<16;bad++){
    for(int defect=0;defect<4;defect++){
      O o;auto v=input();CHECK(go_to_probe(o,v)==0);
      for(unsigned i=0;i<=bad;i++){
        float a=.01f*i,b=a+.01f;
        if(i==bad){if(defect==0)b+=.2f;if(defect==1)b=NAN;
                    if(defect==2){v.bed_c=63.f;}if(defect==3)a=4.f;}
        const bool accepted=o.measurement(i,a,b,v);
        CHECK(accepted==(i<bad));
      }
      CHECK(o.phase()==O::Phase::Failed);CHECK(o.finished_points()==bad);
      CHECK(!o.eeprom_save_permitted());
      const O::Snapshot *p=nullptr;CHECK(o.snapshot(p));CHECK(p->z_offset==-1.1f);
    }
  }
  // Mesh failure, incomplete grid, invalid reports; no fallthrough after failure.
  for(int mode=0;mode<5;mode++){
    O o;auto v=input();CHECK(go_to_probe(o,v)==0);
    float values[16];for(int i=0;i<16;i++){
      CHECK(o.measurement(i,.01f*i,.01f*i+.01f,v));
      values[i]=o.candidate(i);
    }
    if(mode==0)values[15]+=0.003f;
    if(mode==1)values[7]=NAN;
    if(mode==2)v.z_offset=-1.15f;
    if(mode==3)v.probe_stowed=false;
    CHECK(o.probe_done(mode!=4,v,values)==O::Action::StopAndRestoreOldRamMesh);
    CHECK(o.phase()==O::Phase::Failed);CHECK(!o.eeprom_save_permitted());
  }
  // Cancel during every stage. Review cannot be cancelled to mutate EEPROM.
  for(int stage=0;stage<3;stage++){
    O o;auto v=input();auto old=old_mesh();
    CHECK(o.start(1,v,old)==O::Action::SetBedTo60);
    if(stage>=1){v.bed_c=60;v.target_c=60;CHECK(o.tick(2,v)==O::Action::None);
      CHECK(o.tick(20002,v)==O::Action::RequestG28);}
    if(stage==2){v.homed_xyz=true;CHECK(o.homing_done(true,v)==O::Action::RequestG29U);}
    CHECK(o.cancel()==O::Action::StopAndRestoreOldRamMesh);
    CHECK(o.phase()==O::Phase::Cancelled);CHECK(o.cancel()==O::Action::None);
  }
  // Time rollover: stable interval must still be correct.
  { O o;auto v=input();auto old=old_mesh();uint32_t t=UINT32_MAX-10000u;
    CHECK(o.start(t,v,old)==O::Action::SetBedTo60);
    v.bed_c=60;v.target_c=60;CHECK(o.tick(t+200,v)==O::Action::None);
    CHECK(o.tick(t+20199u,v)==O::Action::None);
    CHECK(o.tick(t+20200u,v)==O::Action::RequestG28);
  }
  std::printf("SV04_NEXT_AUTO60_ORCHESTRATOR PASS checks=%d eeprom_actions=0\n",checks);
}
