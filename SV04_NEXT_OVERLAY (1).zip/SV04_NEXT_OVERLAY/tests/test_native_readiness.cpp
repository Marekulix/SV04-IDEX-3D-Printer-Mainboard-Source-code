#include "../include/SV04NextNativeReadiness.hpp"
#include <assert.h>
#include <math.h>
#include <stdio.h>
using namespace sv04next;
static unsigned tests=0;
#define CHECK(x) do { ++tests; assert(x); }while(0)
int main(){
  NativeReadiness bridge;
  G29UReceipt receipt;
  NativeReadiness::Live s;
  CHECK(bridge.view().gate==NativeReadiness::Gate::Waiting);
  CHECK(!bridge.view().observed);
  CHECK(!bridge.allow_automatic_heating());
  CHECK(!bridge.allow_automatic_homing());
  CHECK(!bridge.allow_automatic_g29());
  CHECK(!bridge.allow_eeprom_save());
  CHECK(!bridge.hardware_approved());
  s.tool0=true;s.dual_auto_park=true;s.xyz_trusted=true;
  s.t1_x=362;s.t1_home_x=362;s.bed_c=60;s.bed_set_c=60;s.probe_offset_z=-1.10f;
  bridge.observe(100,s,receipt);
  CHECK(bridge.view().gate==NativeReadiness::Gate::NoPhysicalT1Witness);
  CHECK(!bridge.view().ram_mesh_16_of_16);
  CHECK(bridge.view().g29_run_id==0);
  CHECK(bridge.view().last_sample_ms==100);
  // Every known unsafe condition takes precedence over a presumed park.
  s.stopped=true;CHECK(NativeReadiness::evaluate(s)==NativeReadiness::Gate::PrinterStopped);s.stopped=false;
  s.printing=true;CHECK(NativeReadiness::evaluate(s)==NativeReadiness::Gate::PrintOngoing);s.printing=false;
  s.motion_queued=true;CHECK(NativeReadiness::evaluate(s)==NativeReadiness::Gate::MotionActive);s.motion_queued=false;
  s.tool0=false;CHECK(NativeReadiness::evaluate(s)==NativeReadiness::Gate::WrongTool);s.tool0=true;
  s.dual_auto_park=false;CHECK(NativeReadiness::evaluate(s)==NativeReadiness::Gate::WrongCarriageMode);s.dual_auto_park=true;
  s.xyz_trusted=false;CHECK(NativeReadiness::evaluate(s)==NativeReadiness::Gate::UntrustedAxes);s.xyz_trusted=true;
  s.t1_x=360;CHECK(NativeReadiness::evaluate(s)==NativeReadiness::Gate::X2SoftwarePosition);s.t1_x=362;
  s.t1_x=NAN;CHECK(NativeReadiness::evaluate(s)==NativeReadiness::Gate::X2SoftwarePosition);s.t1_x=362;
  s.t1_home_x=INFINITY;CHECK(NativeReadiness::evaluate(s)==NativeReadiness::Gate::X2SoftwarePosition);s.t1_home_x=362;
  s.bed_c=NAN;CHECK(NativeReadiness::evaluate(s)==NativeReadiness::Gate::Temperature);s.bed_c=60;
  s.bed_set_c=150;CHECK(NativeReadiness::evaluate(s)==NativeReadiness::Gate::Temperature);s.bed_set_c=60;
  s.probe_offset_z=NAN;CHECK(NativeReadiness::evaluate(s)==NativeReadiness::Gate::OffsetInvalid);s.probe_offset_z=-1.10f;
  s.physical_t1_park_witness=true;
  CHECK(NativeReadiness::evaluate(s)==NativeReadiness::Gate::NoProbeStowWitness);
  s.probe_stow_witness=true;
  CHECK(NativeReadiness::evaluate(s)==NativeReadiness::Gate::ObservingRamResult);
  // Even with manufactured positive witnesses the firmware NEVER actuates.
  for(unsigned i=0;i<256;i++){
    s.bed_c=(i&1)?60:25;
    s.bed_set_c=(i&2)?60:0;
    s.physical_t1_park_witness=(i&4)!=0;
    s.probe_stow_witness=(i&8)!=0;
    s.stopped=(i&16)!=0;
    s.printing=(i&32)!=0;
    s.motion_queued=(i&64)!=0;
    s.tool0=(i&128)!=0;
    bridge.observe(i+1000,s,receipt);
    CHECK(!bridge.allow_automatic_heating());
    CHECK(!bridge.allow_automatic_homing());
    CHECK(!bridge.allow_automatic_g29());
    CHECK(!bridge.allow_eeprom_save());
    CHECK(!bridge.hardware_approved());
  }
  s=NativeReadiness::Live{};
  s.tool0=true;s.dual_auto_park=true;s.xyz_trusted=true;
  s.t1_x=362;s.t1_home_x=362;s.bed_c=60;s.bed_set_c=60;s.probe_offset_z=-1.1f;
  CHECK(receipt.begin());
  for(unsigned y=0;y<4;y++)for(unsigned x=0;x<4;x++) {
    CHECK(receipt.point(x,y,(float)(x+y)*0.01f));
    bridge.observe((uint32_t)(5000+y*4+x),s,receipt);
    CHECK(bridge.view().measured==(y*4+x+1));
    CHECK(bridge.view().receipt_phase==G29UReceipt::Phase::Running);
    CHECK(!bridge.view().ram_mesh_16_of_16);
  }
  CHECK(receipt.finish_ram_only());
  bridge.observe(5100,s,receipt);
  CHECK(bridge.view().ram_mesh_16_of_16);
  CHECK(bridge.view().valid_mask==0xFFFF);
  CHECK(bridge.view().measured==16);
  CHECK(!bridge.allow_eeprom_save());
  CHECK(receipt.begin());
  CHECK(receipt.point(0,0,0.2f));
  receipt.fail(G29UReceipt::Failure::Temperature);
  bridge.observe(5200,s,receipt);
  CHECK(!bridge.view().ram_mesh_16_of_16);
  CHECK(bridge.view().receipt_failure==G29UReceipt::Failure::Temperature);
  CHECK(bridge.view().g29_run_id==2);
  printf("native readiness real-status/receipt model PASS: %u assertions; NO hardware commands\n",tests);
}
