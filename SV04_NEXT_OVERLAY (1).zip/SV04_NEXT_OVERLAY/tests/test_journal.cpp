#include "../include/SV04NextMeshJournal.hpp"
#include "../include/SV04NextDwinView.hpp"
#include <cassert>
#include <cstdio>
#include <cmath>
#include <cstring>
using namespace sv04next;
static int count=0;
#define CHECK(x) do { assert(x); ++count; } while(0)
static float initial[16];
static void init(){for(int i=0;i<16;i++)initial[i]=0.01f*i;}
static void feed(MeshJournal& m){for(int i=0;i<16;i++){CHECK(m.sample(i, 0.05f+i*0.01f, 60, true,true));CHECK(m.sample(i, 0.052f+i*0.01f, 60,true,true));}}
int main(){
  init();
  {
    MeshJournal m;CHECK(!m.allow_eeprom_write());CHECK(m.begin(initial,-1.10f,true,true,true));
    feed(m);CHECK(m.completed()==16);CHECK(!m.allow_eeprom_write());
    CHECK(m.finished(true,true,true,true,true,-1.10f));CHECK(m.allow_eeprom_write());
    CHECK(m.begin_save());CHECK(!m.allow_eeprom_write());CHECK(m.save_result(true));
    float saved[16];for(int i=0;i<16;i++)saved[i]=m.candidate(i);
    CHECK(m.verified_from_eeprom(true,saved,-1.10f));CHECK(m.stage()==MeshJournal::Stage::Done);
    CHECK(!m.restore_old_ram_mesh(saved,&saved[0],nullptr));
  }
  // Inject a fault at every one of the 32 physical samples. No EEPROM write may follow.
  for(int wrong=0;wrong<32;wrong++){
    MeshJournal m;CHECK(m.begin(initial,-1.10f,true,true,true));
    for(int n=0;n<32;n++){
      bool ok=m.sample(n/2,0.01f*(n/2),60,n!=wrong,true);
      if(n==wrong){CHECK(!ok);break;}CHECK(ok);
    }
    CHECK(!m.allow_eeprom_write());CHECK(m.stage()==MeshJournal::Stage::Failed);
    float dest[16]={};float zoff=0;bool active=false;
    CHECK(m.restore_old_ram_mesh(dest,&zoff,&active));
    CHECK(memcmp(dest,initial,sizeof(dest))==0);CHECK(zoff==-1.10f);CHECK(active);
  }
  // At each position, reject large disagreement, temperature excursions, and NaN.
  for(int i=0;i<16;i++){
    MeshJournal m;CHECK(m.begin(initial,-1.10f,false,true,true));
    for(int n=0;n<i;n++){CHECK(m.sample(n,0.1f,60,true,true));CHECK(m.sample(n,0.1f,60,true,true));}
    CHECK(m.sample(i,0.1f,60,true,true));CHECK(!m.sample(i,0.161f,60,true,true));CHECK(!m.allow_eeprom_write());
  }
  for(int i=0;i<16;i++){
    MeshJournal m;CHECK(m.begin(initial,-1.10f,true,true,true));
    for(int n=0;n<i;n++){CHECK(m.sample(n,0.1f,60,true,true));CHECK(m.sample(n,0.1f,60,true,true));}
    CHECK(!m.sample(i,0.1f,66,true,true));CHECK(!m.allow_eeprom_write());
  }
  {
    MeshJournal m;CHECK(!m.begin(initial,-1.10f,true,false,true));CHECK(!m.allow_eeprom_write());
  }
  {
    MeshJournal m;CHECK(m.begin(initial,-1.10f,true,true,true));
    CHECK(!m.sample(1,0.0f,60,true,true));CHECK(!m.allow_eeprom_write());
  }
  {
    MeshJournal m;CHECK(m.begin(initial,-1.10f,true,true,true));feed(m);
    CHECK(!m.sample(16,0.0f,60,true,true));CHECK(!m.allow_eeprom_write());
  }
  {
    MeshJournal m;CHECK(m.begin(initial,-1.10f,true,true,true));feed(m);
    CHECK(!m.finished(true,true,true,true,true,-1.11f));CHECK(!m.allow_eeprom_write());
  }
  {
    MeshJournal m;CHECK(m.begin(initial,-1.10f,true,true,true));feed(m);
    CHECK(m.finished(true,true,true,true,true,-1.10f));CHECK(m.begin_save());CHECK(!m.save_result(false));
    CHECK(m.possible_eeprom_change());CHECK(!m.allow_eeprom_write());
  }
  {
    MeshJournal m;CHECK(m.begin(initial,-1.10f,true,true,true));feed(m);
    CHECK(m.finished(true,true,true,true,true,-1.10f));CHECK(m.begin_save());CHECK(m.save_result(true));
    float bad[16];for(int i=0;i<16;i++)bad[i]=m.candidate(i);bad[15]+=0.002f;
    CHECK(!m.verified_from_eeprom(true,bad,-1.10f));CHECK(!m.allow_eeprom_write());
  }
  {
    MeshJournal m;CHECK(m.begin(initial,-1.10f,true,true,true));m.cancel();CHECK(!m.allow_eeprom_write());
  }
  for(int i=0;i<16;i++){
    CHECK(DwinView::y_at(i)==i/4);
    CHECK(DwinView::x_at(i)==((i/4)%2?i%4:3-(i%4)));
    CHECK(DwinView::rts_value_address(i)==0x1100+2*i);
  }
  CHECK(DwinView::rts_value_address(16)==0);
  CHECK(DwinView::x_at(16)==255);
  CHECK(DwinView::color_for(NAN,0)==DwinView::Color::Gray);
  CHECK(DwinView::color_for(0.0f,0)==DwinView::Color::Green);
  CHECK(DwinView::color_for(0.1f,0)==DwinView::Color::Yellow);
  CHECK(DwinView::color_for(0.4f,0)==DwinView::Color::Red);
  std::printf("SV04_NEXT JOURNAL_AND_DWIN_HOST PASS assertions=%d\n",count);
}
