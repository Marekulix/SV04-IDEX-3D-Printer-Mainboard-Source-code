#include "../include/SV04NextT1CorrelationAudit.hpp"
#include <cassert>
#include <iostream>
using namespace sv04next;
int main(){
 T1CorrelationAudit audit; G28PassiveReceipt home; T1EndstopObserver sw;
 audit.observe(0,home.view(),sw); assert(audit.view().reason==T1CorrelationAudit::Reason::NoHoming);
 // Old switch edge must not be reused as proof for a new G28.
 sw.observe(10,true,false);sw.observe(120,true,false);sw.observe(200,true,true);sw.observe(510,true,true);
 assert(sw.electrical_edge_observed(510));
 assert(home.begin(520)); audit.observe(520,home.view(),sw);
 assert(home.finish(600,true,true,true,true));
 audit.observe(610,home.view(),sw);
 assert(!audit.view().electrical_correlation);
 // New release-press cycle during already observed homing sequence.
 sw.observe(620,true,false);sw.observe(750,true,false);sw.observe(810,true,true);sw.observe(1120,true,true);
 audit.observe(1120,home.view(),sw);
 assert(audit.view().electrical_correlation);
 assert(!audit.view().physical_park_verified && !audit.permit_motion() && !audit.permit_eeprom());
 audit.observe(50000,home.view(),sw);
 assert(!audit.view().electrical_correlation || audit.view().reason!=T1CorrelationAudit::Reason::TemporalCorrelationOnly);
 assert(home.begin(50100));audit.observe(50100,home.view(),sw);
 home.early_return();audit.observe(50200,home.view(),sw);
 assert(!audit.view().electrical_correlation);
 // Exhaust all combinations of electrical edges and G28 trust bits.
 unsigned checks=0;
 for(unsigned i=0;i<4096;++i){
   T1CorrelationAudit a; G28PassiveReceipt h; T1EndstopObserver s;
   const uint32_t t=100u + i*1000u;
   if(i&1u) {s.observe(t,true,false);s.observe(t+105,true,false);s.observe(t+200,true,true);s.observe(t+505,true,true);}
   h.begin(t+600); a.observe(t+600,h.view(),s);
   if(i&2u)h.finish(t+800,(i&4u)!=0,(i&8u)!=0,(i&16u)!=0,(i&32u)!=0);
   else h.early_return();
   a.observe(t+810,h.view(),s);
   assert(!a.view().physical_park_verified && !a.view().motion_allowed && !a.view().eeprom_allowed);
   assert(!a.permit_motion() && !a.permit_eeprom()); ++checks;
 }
 std::cout<<"T1 CORRELATION AUDIT PASS "<<checks<<" combinations (no physical proof)\n";
}
