#include "../include/SV04NextMeshIntegrity.hpp"
#include <cassert>
#include <cstdio>
#include <limits>
using namespace sv04next;
static int checks=0;
#define CHECK(X) do{++checks;assert(X);}while(0)
static MeshIntegrity::Mesh mesh(){MeshIntegrity::Mesh x;
 x.origin_x=25;x.origin_y=25;x.pitch_x=80;x.pitch_y=80;x.z_offset=-1.10f;
 for(int j=0;j<16;++j)x.z[j]=float(j)*.005f;
 return x;}
int main(){using M=MeshIntegrity;
 for(uint32_t run=1;run<=2500;++run){
  M m;auto orig=mesh();orig.z[run%16]+=(float)(run%100)*.0002f;
  CHECK(m.capture(run,orig));CHECK(!m.rollback_verified());
  M::Mesh saved;CHECK(m.original(run,saved));CHECK(m.original_fingerprint()!=0u);
  CHECK(!m.enables_eeprom());CHECK(!m.changes_native_ram());
  auto candidate=orig;candidate.z[run%16]+=.02f;
  CHECK(m.check_candidate(run,candidate));CHECK(m.stage_ram_candidate_only());
  CHECK(!m.rollback_verified());CHECK(m.check_restored(run,orig));CHECK(m.rollback_verified());
 }
 for(uint32_t i=1;i<=1200;++i){
  M m;auto x=mesh();CHECK(m.capture(i,x));auto bad=x;
  switch(i%8){
   case 0:bad.z[i%16]=std::numeric_limits<float>::quiet_NaN();break;
   case 1:bad.z[i%16]=3.5f;break;
   case 2:bad.z_offset=bad.z_offset+0.01f;break;
   case 3:bad.pitch_x+=1.f;break;
   case 4:bad.origin_y-=1.f;break;
   case 5:bad.z[0]=std::numeric_limits<float>::infinity();break;
   case 6:bad.z[1]=4.f;break;
   default:bad.origin_x=500.f;break;
  }
  CHECK(!m.check_candidate(i,bad));CHECK(m.stage()==M::Stage::Failed);
 }
 {M m;auto orig=mesh();CHECK(m.capture(10,orig));CHECK(m.check_candidate(10,orig));
  auto wrong=orig;wrong.leveling_enabled=true;CHECK(!m.check_restored(10,wrong));
  CHECK(!m.rollback_verified());}
 std::printf("MESH-INTEGRITY PASS checks=%d; exact rollback model; NO EEPROM\n",checks);
}
