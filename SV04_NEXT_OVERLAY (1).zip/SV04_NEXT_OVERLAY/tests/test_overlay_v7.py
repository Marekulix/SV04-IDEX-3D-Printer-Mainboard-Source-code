"""v7 overlay fixture plus failure-atomic application checks; NOT a Marlin build."""
from __future__ import annotations
import sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'integration'),str(ROOT/'tests')]
import apply_native_guard_v7 as v7
import test_overlay_v6 as f
TH=(ROOT/'include/SV04NextNativeThermalGate.hpp').read_text()
VI=(ROOT/'include/SV04NextVisitProof.hpp').read_text()
RC=(ROOT/'include/SV04NextG29UReceipt.hpp').read_text()
source=dict(f.source)
out=v7.render(source,TH,VI,RC)
g=out[v7.G29]
checks=0
def ck(cond,msg):
 global checks
 assert cond,msg
 checks+=1
ck(out['Marlin/Configuration.h']==source['Marlin/Configuration.h'],'OEM config')
ck(out['Marlin/src/module/probe.cpp']==source['Marlin/src/module/probe.cpp'],'OEM probing')
ck(out[v7.RECEIPT_TARGET]==RC,'native receipt copied')
ck(g.count('G29UReceipt g29u_receipt;')==1,'native singleton')
ck(g.count('G29UReceipt::Scope sv04_receipt_scope(')==1,'early return guard')
ck(g.count('g29u_receipt.point(')==1,'native per-point capture')
ck(g.count('g29u_receipt.finish_ram_only()')==1,'success only after full mesh')
ck(g.count('g29u_receipt.fail(')>=3,'native failures')
ck(g.count('g29u_receipt.refuse(')>=8,'preflight refusals')
ck(g.count('sv04_mesh_guard.revert()')>=1,'RAM rollback')
ck('SV04 NEXT G29U ABORT: heat changed during probe' in g,'instant temperature failure')
ck('!sv04_visit_proof.record(' in g,'duplicate native guard')
ck('!sv04_visit_proof.complete()' not in g and 'sv04_visit_proof.complete()' in g,'full grid acceptance')
ck('settings.save()' not in g and 'M500' not in g,'never save')
ck('queue.enqueue' not in g and 'setTargetBed(' not in g,'never command heat/motion')
ck(out[v7.THERMAL_TARGET]==TH and out[v7.VISIT_TARGET]==VI,'old headers intact')
try:v7.render(out,TH,VI,RC)
except v7.PatchRefused:ck(True,'double render refused')
else:raise AssertionError('double render was accepted')
for bad in (RC.replace('READ ONLY','NOT READ ONLY'),RC.replace('return false;','return true;')):
 try:v7.render(source,TH,VI,bad)
 except v7.PatchRefused:ck(True,'untrusted receipt refused')
 else:
  # One of the replacements may be accepted by simple textual check.
  if 'eeprom_authorized() const { return false; }' not in bad:raise AssertionError('unsafe receipt allowed')
# Fail-closed source SHA verification does not write anything until all inputs pass.
with tempfile.TemporaryDirectory() as temp:
 t=Path(temp)
 for name,content in source.items():
  p=t/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(content)
 sha=dict(v7.OEM_BLOBS)
 try:
  v7.OEM_BLOBS.clear();v7.OEM_BLOBS.update({k:v7.previous.previous.git_blob_sha(x.encode()) for k,x in source.items()})
  (t/'Marlin/src/module/probe.cpp').write_text('incorrect')
  try:v7.apply(t,ROOT/'include/SV04NextNativeThermalGate.hpp',ROOT/'include/SV04NextVisitProof.hpp',ROOT/'include/SV04NextG29UReceipt.hpp')
  except v7.PatchRefused:ck(True,'tamper detected')
  else:raise AssertionError('tamper accepted')
  ck(not (t/v7.RECEIPT_TARGET).exists(),'no changes after refusal')
  (t/'Marlin/src/module/probe.cpp').write_text(source['Marlin/src/module/probe.cpp'])
  report=v7.apply(t,ROOT/'include/SV04NextNativeThermalGate.hpp',ROOT/'include/SV04NextVisitProof.hpp',ROOT/'include/SV04NextG29UReceipt.hpp',t/'proof/report.json')
  ck(report['eeprom_write_authorized'] is False and report['stm32_build_proven'] is False,'limits explicit')
  ck((t/v7.G29).read_text()==g,'patched G29 exact')
  ck((t/v7.RECEIPT_TARGET).read_text()==RC,'receipt exact')
  for p in source:
   if p in ('Marlin/Configuration.h','Marlin/src/module/probe.cpp'):
    ck((t/p).read_text()==source[p],'OEM unmodified')
  try:v7.apply(t,ROOT/'include/SV04NextNativeThermalGate.hpp',ROOT/'include/SV04NextVisitProof.hpp',ROOT/'include/SV04NextG29UReceipt.hpp')
  except v7.PatchRefused:ck(True,'repeat overlay refused')
  else:raise AssertionError('repeat accepted')
 finally:
  v7.OEM_BLOBS.clear();v7.OEM_BLOBS.update(sha)
print('SV04 NEXT v7 overlay PASS checks=',checks)
