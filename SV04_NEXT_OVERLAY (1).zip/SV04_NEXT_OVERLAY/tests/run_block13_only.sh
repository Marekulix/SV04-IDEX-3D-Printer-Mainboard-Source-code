#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
g++ -std=c++11 -O2 -Wall -Wextra -Werror -pedantic tests/test_auto60_engine.cpp -o /tmp/sv04-next-auto60-engine-b13
/tmp/sv04-next-auto60-engine-b13 | tail -1
python3 harness/run_harness.py | grep -E "^===|^FAIL"
python3 tests/test_overlay_v16.py
echo 'BLOCK 13 PASS (Host-Simulation; Marlin-Build NOT run)'
