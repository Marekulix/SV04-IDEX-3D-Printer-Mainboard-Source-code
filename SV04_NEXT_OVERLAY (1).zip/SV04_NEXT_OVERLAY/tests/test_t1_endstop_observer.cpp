#include "../include/SV04NextT1EndstopObserver.hpp"
#include <assert.h>
#include <stdio.h>
#include <stdint.h>
using sv04next::T1EndstopObserver;
using State=T1EndstopObserver::State;
static unsigned checks=0;
static void ck(bool b){assert(b);++checks;}
int main() {
  T1EndstopObserver x;
  ck(x.state()==State::Unavailable);
  ck(!x.electrical_edge_observed(0));
  for(uint32_t i=0;i<1500;i+=10){x.observe(i,true,true);ck(!x.electrical_edge_observed(i));}
  ck(x.state()==State::WaitingForRelease); // stuck pressed at startup
  x.observe(1600,true,false);ck(x.state()==State::ReleaseDebounce);
  x.observe(1699,true,false);ck(x.state()==State::ReleaseDebounce);
  x.observe(1700,true,false);ck(x.state()==State::Released);
  x.observe(1710,true,true);ck(x.state()==State::PressDebounce);
  x.observe(1999,true,true);ck(!x.electrical_edge_observed(1999));
  x.observe(2010,true,true);ck(x.electrical_edge_observed(2010));
  ck(x.edge_epochs()==1);ck(x.release_epochs()==1);
  for(uint32_t i=2011;i<2400;++i){x.observe(i,true,true);ck(x.electrical_edge_observed(i));}
  ck(x.edge_epochs()==1);
  // A broken or disconnected input must revoke the electrical observation.
  x.observe(2500,false,false);ck(x.state()==State::Unavailable);ck(!x.electrical_edge_observed(2500));
  x.observe(2600,true,true);ck(x.state()==State::WaitingForRelease);
  ck(!x.electrical_edge_observed(2600));
  // Bounce: a premature return to LOW cancels pending HIGH.
  x.observe(2700,true,false);x.observe(2800,true,false);x.observe(2810,true,true);
  x.observe(2990,true,false);ck(x.state()==State::Released);
  x.observe(3000,true,true);x.observe(3300,true,true);
  ck(x.electrical_edge_observed(3300));ck(x.edge_epochs()==2);
  // Discontinuous sampling does not count a 300ms press.
  x.observe(7301,true,true);ck(!x.electrical_edge_observed(7301));
  ck(x.state()==State::WaitingForRelease);
  // Wraparound: elapsed age and debounce must be uint32 safe.
  T1EndstopObserver rollover;
  rollover.observe(0xFFFFFF00u,true,false);
  rollover.observe(0xFFFFFF64u,true,false);
  rollover.observe(0xFFFFFF80u,true,true);
  rollover.observe(0x000000ACu,true,true);
  ck(rollover.electrical_edge_observed(0x000000ACu));
  ck(!rollover.electrical_edge_observed(4000u));
  // Neither a switch press nor a firmware X coordinate can authorize movement.
  for(unsigned i=0;i<1024;++i){
    x.observe(8000u+i,true, (i&7)!=0);
    ck(!x.physical_t1_park_proven());
    ck(!x.allow_motion());
    ck(!x.allow_eeprom_write());
  }
  printf("SV04 NEXT native X_MAX electrical proof host PASS checks=%u; physical parking not verified\n",checks);
}
