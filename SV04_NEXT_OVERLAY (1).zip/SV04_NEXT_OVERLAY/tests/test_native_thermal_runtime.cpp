#include <cassert>
#include <cmath>
#include <iostream>
#include "../include/SV04NextNativeThermalGate.hpp"
namespace sv04next {NativeThermalGate native_thermal_gate;}
int main(){
  int n=0;
  auto ck=[&](bool v){assert(v);++n;};
  using G=sv04next::NativeThermalGate;
  G gate;
  for(uint32_t i=0;i<=20000;i+=1000)gate.observe(i,60,60,true);
  ck(gate.ready(20000));
  // A busy G29 does not necessarily call idle-loop RTSUpdate(). It must
  // independently read the *live* bed temperature, not a stale ready state.
  ck(!gate.ready(40000));
  ck(G::live_sample_safe(60,60));
  for(int i=-200;i<=200;++i){
    const float bed=60.0f+((float)i/100.0f);
    ck(G::live_sample_safe(bed,60)==(bed>=59 && bed<=61));
  }
  ck(!G::live_sample_safe(NAN,60));
  ck(!G::live_sample_safe(INFINITY,60));
  ck(!G::live_sample_safe(60,NAN));
  ck(!G::live_sample_safe(60,61));
  ck(!G::live_sample_safe(58.9f,60));
  ck(!G::live_sample_safe(61.1f,60));
  std::cout<<"SV04 NEXT direct thermal runtime PASS checks="<<n<<"\n";
}
