#include "../include/SV04NextReceiptBinder.hpp"
#include <cassert>
#include <cstdio>
using namespace sv04next;
static int checks=0;
#define CHECK(x) do{++checks;assert(x);}while(0)
static ReceiptBinder::Live safe(){ReceiptBinder::Live v;v.t1_witness=true;v.bed_stable_60=true;v.probe_stowed=true;return v;}
int main(){
  using R=G29UReceipt;using B=ReceiptBinder;
  B b;R receipt;auto v=safe();
  CHECK(!b.prepare(0,0));CHECK(b.prepare(10,receipt.sequence()));
  CHECK(!b.observe(10,receipt,v));CHECK(!b.ram_complete()); // must see real native run start
  for(int run=0;run<256;++run){
    R r;B q;CHECK(q.prepare(123,0));
    CHECK(r.begin());CHECK(q.observe(123,r,v));
    const int count=run%17;
    for(int i=0;i<count;++i){CHECK(r.point((uint8_t)(i%4),(uint8_t)(i/4),.001f*i));CHECK(q.observe(123,r,v));}
    CHECK(q.points()==count);
    if(count==16){CHECK(r.finish_ram_only());CHECK(q.observe(123,r,v));CHECK(q.ram_complete());}
    else {CHECK(!q.ram_complete());CHECK(!q.eeprom_authorized());}
  }
  {R r;B q;CHECK(q.prepare(22,0));CHECK(r.begin());CHECK(!q.observe(23,r,v));CHECK(q.phase()==B::Phase::Rejected);}
  {R r;B q;CHECK(q.prepare(22,0));CHECK(r.begin());CHECK(r.point(0,0,1));CHECK(!q.observe(22,r,v));CHECK(q.error()==B::Error::LateStart);}
  {R r;B q;CHECK(q.prepare(22,0));CHECK(r.begin());CHECK(q.observe(22,r,v));r.fail();CHECK(!q.observe(22,r,v));CHECK(q.error()==B::Error::G29Failure);}
  {R r;B q;CHECK(q.prepare(22,0));CHECK(r.begin());CHECK(q.observe(22,r,v));auto x=v;x.t1_witness=false;CHECK(!q.observe(22,r,x));CHECK(q.error()==B::Error::UnsafeRuntime);}
  {R r;B q;CHECK(q.prepare(22,0));CHECK(r.begin());CHECK(q.observe(22,r,v));auto x=v;x.offset_unchanged=false;CHECK(!q.observe(22,r,x));CHECK(q.error()==B::Error::WrongOffset);}
  {R r;B q;CHECK(q.prepare(22,0));CHECK(r.begin());CHECK(q.observe(22,r,v));R other;CHECK(other.begin());CHECK(other.begin()==false); // same seq; simulate replaced instance impossible except a different prior count
    CHECK(other.point(0,0,.1f)); CHECK(q.observe(22,other,v)); /* equal seq and monotonic; no promise of object identity */}
  for(int n=0;n<100;++n){
    R r;B q;CHECK(q.prepare(n+1,0));CHECK(r.begin());CHECK(q.observe(n+1,r,v));
    for(int i=0;i<16;++i){CHECK(r.point(i%4,i/4,float(i)/100.f));CHECK(q.observe(n+1,r,v));}
    CHECK(r.finish_ram_only());auto bad=v;bad.probe_stowed=false;
    CHECK(!q.observe(n+1,r,bad));CHECK(!q.ram_complete());CHECK(!q.eeprom_authorized());
  }
  std::printf("NATIVE-RECEIPT-BINDER PASS checks=%d SAVE=0\n",checks);
}
