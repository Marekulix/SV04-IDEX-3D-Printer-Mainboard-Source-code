#!/usr/bin/env python3
"""Structural and atomicity tests, not real Marlin compilation/hardware."""
import sys, tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'integration'))
import apply_native_guard_v3 as p

checks=0
def check(condition,why):
    global checks
    assert condition,why
    checks+=1

keys=list(p.OEM_BLOBS)
conf='''#define GRID_MAX_POINTS_X 4
//#define MULTIPLE_PROBING 2
'''
probe='''Probe probe;
#elif TOTAL_PROBING == 2
    const float z2 = current_position.z;

    if (DEBUGGING(LEVELING))
'''
g29='''#include "../../../module/probe.h"
#define G29_RETURN(b) return TERN_(G29_RETRY_AND_RECOVER, b)
G29_TYPE GcodeSuite::G29() {
  reset_stepper_timeout();
  if (something) G29_RETURN(false);
  if (other) G29_RETURN(true);
  for (int i=0; i<16; i++) {
          abl.measured_z = faux ? 0.001f * random(-100, 101) : probe.probe_at_point(abl.probePos, raise_after, abl.verbose_level);
            z_values[abl.meshCount.x][abl.meshCount.y] = z;
            TERN_(EXTENSIBLE_UI, ExtUI::onMeshUpdate(abl.meshCount, z));
  }
  #if ENABLED(RTS_AVAILABLE)
    RTS_AutoBedLevelPage();
  #endif
  report_current_position();

  TERN_(FULL_REPORT_TO_HOST_FEATURE, set_and_report_grblstate(M_IDLE));

  G29_RETURN(isnan(abl.measured_z));
}'''
base=dict(zip(keys,[conf,probe,g29]))
out=p.render(base)
g=out['Marlin/src/gcode/bedlevel/abl/G29.cpp']

# Preflight must be executed before ANY OEM command processing and motor work.
for sub in ('unsupported parameter/grid','printing or moving','IDEX/homing preflight',
            'bed not stable at 60C'):
    check(sub in g,'missing start guard: '+sub)
    check(g.index(sub)<g.index('if (something)'), 'guard too late: '+sub)
for op in 'NJWDQCOZLRFBHS':
    check("parser.seen_test('%s')" % op in p.PREFLIGHT, 'unsafe parameter allowed: '+op)
for clause in ('GRID_MAX_POINTS_X != 4','GRID_MAX_POINTS_Y != 4',
               'IsStopped()','printJobOngoing()','printingIsPaused()','planner.has_blocks_queued()',
               'active_extruder != 0','dual_x_carriage_mode != DXC_AUTO_PARK_MODE',
               '!axis_is_trusted(X_AXIS)','!axis_is_trusted(Y_AXIS)',
               '!axis_is_trusted(Z_AXIS)','!isfinite(inactive_extruder_x)',
               'ABS(inactive_extruder_x - X2_MAX_POS) > 1.0f',
               'thermalManager.degBed()','thermalManager.degTargetBed() != 60',
               '!isfinite(probe.offset.z)'):
    check(clause in p.PREFLIGHT,'missing native preflight: '+clause)
for clause in ('!isfinite(thermalManager.degBed())','thermalManager.degTargetBed() != 60',
               'IsStopped()','printJobOngoing()','printingIsPaused()', 'old_probe_offset', 'abl.measured_z = NAN;'):
    check(clause in p.POINT_CHECK, 'missing mid-run protection '+clause)
check(g.index('SV04 NEXT G29U ABORT') < g.index('probe.probe_at_point('), 'runtime check too late')
check('SV04 NEXT G29U PROGRESS ' in g,'no progress telemetry')
check('if (!sv04_transactional_run || !isnan(abl.measured_z))' in g,
      'failure can cause false RTS success page')
check('rtscheck.RTS_SndData(0, AUTO_BED_LEVEL_ICON_VP)' in g, 'failure icon not reset')
check(g.count('SV04 NEXT G29U')>=6,'incomplete status reporting')
check(g.count('if (sv04_good)') >=2,'finalization safety gate missing')
check(g.index('if (sv04_good && (IsStopped()') < g.index('sv04_mesh_guard.accept();'),
      'final check occurs after commit')
check('sv04_mesh_guard.revert();' in g,'rollback lost')
check('isfinite(z_values[x][y])' in g,'finite validation lost')
check('sv04_measured_points == 16' in g,'incomplete grid accepted')
check('probe.offset.z = old_probe_offset;' in g, 'Z offset not restored on failure')
check('SV04 NEXT: G29 U 16/16 OK, RAM mesh only' in g,'result ambiguous')
for unsafe in ('settings.save(', 'M500', 'queue.enqueue', 'setTargetBed('):
    check(unsafe not in g,'unsafe action injected '+unsafe)
check('//#define MULTIPLE_PROBING 2' not in out[keys[0]], 'double-probe not activated')
check('if (sv04_next_g29_u_active &&' in out[keys[1]],'cross-module signal lost')
# Fail-closed against changed or double-patched sources.
for path in keys:
    altered=dict(base); altered[path]+='// unexpected change\n'
    try:p.render(altered)
    except p.PatchRefused:check(True,'mismatch refused')
    else:
        # Appending alone does not invalidate anchors; SHA guard rejects it.
        check(p.git_blob_sha(altered[path].encode())!=p.OEM_BLOBS[path],
              'SHA gate must reject tampered source')
try:p.render(out)
except p.PatchRefused:check(True,'reapplication refused')
else:raise AssertionError('double application unexpectedly succeeded')
with tempfile.TemporaryDirectory() as td:
    r=Path(td)
    original=dict(p.OEM_BLOBS)
    try:
        p.OEM_BLOBS.clear()
        for path,data in base.items():
            f=r/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(data)
            p.OEM_BLOBS[path]=p.git_blob_sha(f.read_bytes())
        result=p.apply(r,r/'proof.json')
        check(result['m500_automated'] is False,'M500 permitted')
        check(result['automatic_60c_start'] is False,'false automation claim')
        check(result['flash_approved'] is False,'false flash claim')
        for path,content in out.items():check((r/path).read_text()==content,'output incorrect')
        old_outputs={path:(r/path).read_bytes() for path in keys}
        try:p.apply(r,r/'double.json')
        except p.PatchRefused:check(True,'second run refused')
        else:raise AssertionError('second patch not refused')
        check(not (r/'double.json').exists(),'partial artifact created')
        for path in keys:check((r/path).read_bytes()==old_outputs[path], 'modified on refusal')
    finally:
        p.OEM_BLOBS.clear();p.OEM_BLOBS.update(original)
print('SV04 NEXT G29 U V3 INTEGRATION FIXTURE PASS: %d checks, no firmware build' % checks)
