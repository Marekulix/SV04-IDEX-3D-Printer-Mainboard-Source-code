#include "../include/SV04NextOperationLedger.hpp"
#include <cassert>
#include <cstdio>
using namespace sv04next;
static int checks=0;
#define CHECK(X) do{++checks;assert(X);}while(0)
int main(){
  using O=OperationLedger;
  O::Live s;s.t1_physically_witnessed=true;s.target_is_60=true;s.bed_60_stable=false;
  for(uint32_t run=1;run<=2000;++run){
    O x; O::Ticket a,b;
    const uint32_t start=run==1?0xFFFFFF00u:1000u;
    CHECK(!x.issue(run,O::Step::HomeXYZ,start,s,a));
    CHECK(!x.issue(run,O::Step::ProbeG29U,start,s,a));
    CHECK(x.issue(run,O::Step::Heat60,start,s,a));
    CHECK(x.phase()==O::Phase::AwaitAcceptance);
    CHECK(!x.finished(a,start+500u,true,s));
    CHECK(!x.issue(run,O::Step::Heat60,start+1u,s,b));
    CHECK(x.accepted(a,start+1000u,true,s));
    CHECK(x.phase()==O::Phase::Executing);
    CHECK(!x.finished(a,start+1001u,true,s));
    CHECK(x.phase()==O::Phase::Locked); // can't finish merely from heater ACK
    CHECK(!x.permits_eeprom());CHECK(!x.permits_heater());CHECK(!x.permits_motor());
  }
  for(uint32_t run=1;run<=1500;++run){
    O x; O::Ticket heat,home,probe;
    uint32_t t=run==1?0xFFFFF000u:1000u+run;
    CHECK(x.issue(run,O::Step::Heat60,t,s,heat));
    CHECK(x.accepted(heat,t+40u,true,s));
    CHECK(x.poll(t+60000u,s));  // 1 minute, NOT a heat ACK timeout
    auto finished=s;finished.bed_60_stable=true;
    CHECK(x.finished(heat,t+120000u,true,finished));
    CHECK(x.phase()==O::Phase::Completed);
    CHECK(!x.accepted(heat,t+120100u,true,finished));
    CHECK(x.consume(heat));CHECK(!x.consume(heat));
    CHECK(!x.issue(run,O::Step::ProbeG29U,t+121000u,finished,probe));
    CHECK(x.issue(run,O::Step::HomeXYZ,t+121000u,finished,home));
    CHECK(x.accepted(home,t+121010u,true,finished));
    CHECK(!x.consume(home));
    auto homed=finished;homed.xyz_homed_after_command=true;
    CHECK(x.finished(home,t+126000u,true,homed));CHECK(x.consume(home));
    CHECK(x.issue(run,O::Step::ProbeG29U,t+126100u,homed,probe));
    CHECK(x.accepted(probe,t+126110u,true,homed));
    CHECK(!x.finished(heat,t+126200u,true,homed));
    auto probed=homed;probed.native_g29_current_run_complete=true;
    CHECK(x.finished(probe,t+180000u,true,probed));
    CHECK(!x.finished_ram_only());CHECK(x.consume(probe));
    CHECK(x.finished_ram_only());CHECK(x.completed_steps()==3);
    CHECK(!x.issue(run,O::Step::Heat60,t+180001u,probed,heat));
    CHECK(!x.permits_eeprom());
  }
  // Explicit failure matrix: all cases must fail closed and lock.
  for(uint32_t k=0;k<800;++k){
    O x;O::Ticket t;auto v=s;
    CHECK(x.issue(k+1,O::Step::Heat60,10,v,t));
    switch(k%8){
      case 0:v.t1_physically_witnessed=false;CHECK(!x.accepted(t,11,true,v));break;
      case 1:v.heater_ok=false;CHECK(!x.accepted(t,11,true,v));break;
      case 2:v.stopped=true;CHECK(!x.poll(11,v));break;
      case 3:v.printing=true;CHECK(!x.poll(11,v));break;
      case 4:CHECK(!x.accepted(t,30011,true,v));break;
      case 5:CHECK(!x.accepted(t,11,false,v));break;
      case 6:v.offset_unchanged=false;CHECK(!x.poll(11,v));break;
      default:v.t0=false;CHECK(!x.poll(11,v));break;
    }
    CHECK(x.phase()==O::Phase::Locked);
    CHECK(!x.finished_ram_only());CHECK(!x.permits_eeprom());
  }
  {O x;O::Ticket a,b;auto v=s;
    CHECK(x.issue(1,O::Step::Heat60,100,v,a));x.abort();
    CHECK(!x.restart(1,v));v.queue_empty=false;CHECK(!x.restart(2,v));
    v.queue_empty=true;CHECK(!x.restart(2,v)); // unsafe legacy restart disabled
    AbortQuarantine q;CHECK(q.attach_run(1));
    auto token=q.abort(1,200,AbortQuarantine::Cause::UserCancel);
    CHECK(token.valid());CHECK(!x.restart_supervised(2,v,q));
    AbortQuarantine::Sample r;
    r.valid=true;r.planner_idle=true;r.queue_empty=true;r.movement_idle=true;
    r.probe_stowed=true;r.bed_target_zero=true;r.heater_command_idle=true;
    r.offset_unchanged=true;r.prior_mesh_restored=true;r.t1_physical_park_verified=true;
    for(uint32_t j=0;j<=20;++j)CHECK(q.sample(token,200+250*j,r));
    CHECK(!x.restart_supervised(2,v,q));
    CHECK(q.operator_ack(token,5200,true));CHECK(q.retire(token,5200));
    CHECK(x.restart_supervised(2,v,q));
    CHECK(x.issue(2,O::Step::Heat60,1000,v,b));CHECK(b.id!=a.id);
    CHECK(!x.accepted(a,1001,true,v));CHECK(x.accepted(b,1001,true,v));
  }
  { // Execution may run for minutes, but never indefinitely.
    O x;O::Ticket t;auto v=s;
    CHECK(x.issue(1,O::Step::Heat60,0,v,t));CHECK(x.accepted(t,1,true,v));
    CHECK(x.poll(O::HeatMs,v));CHECK(!x.poll(O::HeatMs+1u,v));
    CHECK(x.failure()==O::Failure::ExecutionTimeout);
  }
  { // A changed heater target invalidates an in-flight heat command.
    O x;O::Ticket t;auto v=s;
    CHECK(x.issue(1,O::Step::Heat60,0,v,t));CHECK(x.accepted(t,1,true,v));
    v.target_is_60=false;CHECK(!x.poll(2,v));CHECK(x.phase()==O::Phase::Locked);
  }
  std::printf("OPERATION-LEDGER PASS checks=%d; ACK != completion; EEPROM=0\n",checks);
}
