Hierher gehoeren die ENTPACKTEN Artefakte der GitHub-Workflows (nur echte Dateien aus einem echten Lauf; nichts von Hand schreiben):
  ci-evidence/5-inventur/...            aus dem Artefakt "5-inventur"        (inventur.json, ZUSAMMENFASSUNG.md, ...)
  ci-evidence/6-build-baseline/...      aus "6-build-baseline"               (build.exit, build.log, firmware.sha256, ...)
  ci-evidence/6-build-overlay/...       aus "6-build-overlay"
  ci-evidence/6-build-overlay-auto60/.. aus "6-build-overlay-auto60"
  ci-evidence/6-host-tests/...          aus "6-host-tests"
Danach: python3 tools/score_progress.py --root . --detail. Die C-Stufe eines Kriteriums zaehlt nur, wenn die dort genannten Dateien existieren UND ihr Inhalt passt (siehe progress/catalog.json).
