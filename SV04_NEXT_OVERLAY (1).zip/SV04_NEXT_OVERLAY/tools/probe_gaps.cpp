// Sonden für vermutete Lücken. Nur Messung, keine Änderung am Code unter Test.
#include <cstdio>
#include <cmath>
#include "SV04NextG29UReceipt.hpp"
#include "SV04NextNativeThermalGate.hpp"
#include "SV04NextT1EndstopObserver.hpp"
using namespace sv04next;
int main() {
  // G1: NaN-Sperre des nativen G29-Belegs
  { G29UReceipt r; r.begin(); volatile float nan_v = NAN; bool ok = r.point(0, 0, nan_v); std::printf("G1 NaN als Messhöhe: point()=%s phase=%d failure=%d\n", ok ? "ANGENOMMEN" : "abgelehnt", (int)r.phase(), (int)r.failure()); }
  { G29UReceipt r; r.begin(); volatile float inf_v = INFINITY; bool ok = r.point(0, 0, inf_v); std::printf("G1b +Inf als Messhöhe: point()=%s\n", ok ? "ANGENOMMEN" : "abgelehnt"); }
  // G2: Plausibilität
  { G29UReceipt r; r.begin(); int acc = 0; for (int y = 0; y < 4; ++y) for (int x = 0; x < 4; ++x) acc += r.point(x, y, (x + y) % 2 ? 1.0e30f : -1.0e30f) ? 1 : 0; bool fin = r.finish_ram_only(); std::printf("G2 16 Punkte mit +-1e30 mm: angenommen=%d, finish_ram_only()=%s phase=%d (4 = RamOnlySuccess)\n", acc, fin ? "TRUE" : "false", (int)r.phase()); }
  { G29UReceipt r; r.begin(); for (int y = 0; y < 4; ++y) for (int x = 0; x < 4; ++x) r.point(x, y, 25.0f); std::printf("G2b 16 Punkte mit 25,0 mm (Bett 25 mm schief?): RamOnlySuccess=%s\n", r.finish_ram_only() ? "JA" : "nein"); }
  // G3: Temperaturtor, langsames Abkühlen von 61,0 auf 59,0 in 40 s (0,05 C/s) mit Soll 60
  { NativeThermalGate g; g.reset(); uint32_t first_ready = 0; for (uint32_t t = 0; t <= 40000; t += 500) { float bed = 61.0f - 2.0f * (float)t / 40000.0f; g.observe(t, bed, 60.0f, true); if (!first_ready && g.ready(t)) first_ready = t; } std::printf("G3 Bett fällt dauernd 61,0->59,0 C in 40 s: ready() ab %u ms (Spanne im Fenster 2 C, keine Drift-Prüfung)\n", first_ready); }
  { NativeThermalGate g; g.reset(); uint32_t first_ready = 0; for (uint32_t t = 0; t <= 40000; t += 500) { float bed = 59.0f + 2.0f * (float)t / 40000.0f; g.observe(t, bed, 60.0f, true); if (!first_ready && g.ready(t)) first_ready = t; } std::printf("G3b Bett steigt dauernd 59,0->61,0 C in 40 s: ready() ab %u ms\n", first_ready); }
  // G4: Endstop-Beobachter bei 1-s-Abtastung
  { T1EndstopObserver o; uint32_t t = 0; o.observe(t, true, false); t += 1000; o.observe(t, true, false); t += 1000; o.observe(t, true, true); t += 1000; o.observe(t, true, true); std::printf("G4 nur 4 Stichproben im 1-s-Raster (2 offen, 2 gedrückt): Zustand=%d (5 = StablePressed), edge_epochs=%u, electrical_edge_observed=%s\n", (int)o.state(), o.edge_epochs(), o.electrical_edge_observed(t) ? "JA" : "nein"); }
  // G5: 'edge' ist ein Pegel: bleibt wahr, solange gedrückt
  { T1EndstopObserver o; uint32_t t = 0; o.observe(t, true, false); t += 150; o.observe(t, true, false); t += 150; o.observe(t, true, true); t += 400; o.observe(t, true, true); bool first = o.electrical_edge_observed(t); t += 3000; o.observe(t, true, true); std::printf("G5 Schalter dauerhaft gedrückt: edge_observed direkt danach=%s, 3 s später=%s (Pegel, kein Ereignis)\n", first ? "JA" : "nein", o.electrical_edge_observed(t) ? "JA" : "nein"); }
}
