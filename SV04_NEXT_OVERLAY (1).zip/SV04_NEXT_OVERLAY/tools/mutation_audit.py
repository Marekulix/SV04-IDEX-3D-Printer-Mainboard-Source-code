#!/usr/bin/env python3
"""Mutationskampagne über die sicherheitsrelevanten SV04-Header: gezielte Fehler einbauen und prüfen, ob IRGENDEIN abhängiger Test anschlägt.
Aufruf: python3 mutation_audit.py <SV04_WORK-Ordner> [von bis]   Ausgabe: je Mutant killed / SURVIVED / INVALID(Compilefehler)."""
import json, os, shutil, subprocess, sys, tempfile
W = os.path.abspath(sys.argv[1]); lo, hi = (int(sys.argv[2]), int(sys.argv[3])) if len(sys.argv) > 3 else (0, 10 ** 6)
deps = {}
for _t in sorted(f for f in os.listdir(os.path.join(W, 'tests')) if f.endswith('.cpp')):
    _r = subprocess.run(['g++', '-std=c++11', '-MM', os.path.join(W, 'tests', _t)], capture_output=True, text=True)
    for _h in {os.path.basename(x) for x in _r.stdout.replace('\\\n', ' ').split() if x.endswith('.hpp')}: deps.setdefault(_h, []).append(_t)
H = lambda s: 'SV04Next' + s + '.hpp'
M = [  # (id, Header, alt, neu, Beschreibung)
 ('G01', 'G29UReceipt', "if (x >= Grid || y >= Grid)", "if (x > Grid || y > Grid)", 'Punktindex-Grenze um 1 verschoben'),
 ('G02', 'G29UReceipt', "if (mask_ & bit) {", "if (false) {", 'doppelte Messpunkte werden akzeptiert'),
 ('G03', 'G29UReceipt', "if (!float_is_finite(z) || z > MaxAbsZmm || z < -MaxAbsZmm) {", "if (false) {", 'NaN/Inf-Messhöhe UND Plausibilität entfallen', "if (!isfinite(z)) {"),
 ('N01', 'G29UReceipt', "if (!float_is_finite(z) || z > MaxAbsZmm || z < -MaxAbsZmm) {", "if (!float_is_finite(z)) {", 'Plausibilitätsgrenze der Messhöhe entfällt'),
 ('N02', 'NativeThermalGate', "if (hi - lo > MaxSpreadC) {", "if (false) {", 'Drift-Prüfung entfällt'),
 ('N03', 'SafeFloat', "return ((bits >> 23) & 0xFFu) != 0xFFu;", "return true;", 'bitbasierter Finite-Check akzeptiert alles'),
 ('N04', 'NativeThermalGate', "MaxSpreadC = 0.8f;", "MaxSpreadC = 5.0f;", 'Drift-Grenze 5 C statt 0,8 C'),
 ('G04', 'G29UReceipt', "if (mask_ != 0xFFFFu || count_ != Count) return fail(Failure::Incomplete);", "if (count_ < 15) return fail(Failure::Incomplete);", '15 von 16 Punkten gelten als Erfolg'),
 ('G05', 'G29UReceipt', "if (phase_ == Phase::Running) return false; // never overwrite active run", "", 'laufender Lauf darf überschrieben werden'),
 ('G06', 'G29UReceipt', "~Scope() { if (armed_ && target_.phase() == Phase::Running)\n                 target_.fail(Failure::EarlyReturn); }", "~Scope() { }", 'früher Rücksprung hinterlässt Running'),
 ('G07', 'G29UReceipt', "bool eeprom_authorized() const { return false; }", "bool eeprom_authorized() const { return true; }", 'EEPROM-Freigabe true'),
 ('G08', 'G29UReceipt', "if (sequence_ == 0) ++sequence_;", "", 'Sequenz 0 nach Überlauf erlaubt'),
 ('G09', 'G29UReceipt', "pixel_[index] = Pixel::Problem;\n      return fail(Failure::Duplicate);", "return fail(Failure::Duplicate);", 'Duplikat-Pixel nicht als Problem markiert'),
 ('T01', 'NativeThermalGate', "target_c == 60.0f && bed_c >= 59.0f && bed_c <= 61.0f;\n    if (!valid)", "target_c >= 60.0f && bed_c >= 59.0f && bed_c <= 61.0f;\n    if (!valid)", 'Solltemperatur >= 60 statt genau 60'),
 ('T02', 'NativeThermalGate', "bed_c >= 59.0f && bed_c <= 61.0f;\n    if (!valid)", "bed_c >= 50.0f && bed_c <= 70.0f;\n    if (!valid)", 'Temperaturfenster 50 bis 70 statt 59 bis 61'),
 ('T03', 'NativeThermalGate', "StableMillis = 20000U", "StableMillis = 2000U", 'Stabilitätszeit 2 s statt 20 s'),
 ('T04', 'NativeThermalGate', "(uint32_t)(now - last_sample_) <= MaxSampleAgeMillis &&", "true &&", 'ready() prüft das Probenalter nicht'),
 ('T05', 'NativeThermalGate', "(uint32_t)(now - last_sample_) > MaxSampleAgeMillis) {", "false) {", 'Lücke in den Proben startet die Stabilität nicht neu'),
 ('T06', 'NativeThermalGate', "const bool valid = machine_idle &&", "const bool valid = true &&", 'Maschinenzustand wird ignoriert'),
 ('R01', 'NativeReadiness', "fabsf(s.t1_x - s.t1_home_x) > 1.0f", "fabsf(s.t1_x - s.t1_home_x) > 100.0f", 'T1-X-Toleranz 100 mm statt 1 mm'),
 ('R02', 'NativeReadiness', "if (s.printing) return Gate::PrintOngoing;", "", 'laufender Druck wird ignoriert'),
 ('R03', 'NativeReadiness', "if (!s.physical_t1_park_witness) return Gate::NoPhysicalT1Witness;", "", 'fehlender physischer T1-Beleg wird ignoriert'),
 ('R04', 'NativeReadiness', "bool allow_automatic_heating() const { return false; }", "bool allow_automatic_heating() const { return true; }", 'automatische Heizfreigabe true'),
 ('R05', 'NativeReadiness', "if (!s.xyz_trusted) return Gate::UntrustedAxes;", "", 'nicht vertrauenswürdige Achsen werden ignoriert'),
 ('R06', 'NativeReadiness', "if (s.motion_queued) return Gate::MotionActive;", "", 'laufende Bewegung wird ignoriert'),
 ('E01', 'T1EndstopObserver', "PressMs = 300u", "PressMs = 1u", 'Entprellzeit 1 ms statt 300 ms'),
 ('E02', 'T1EndstopObserver', "if (seen_ && (uint32_t)(now - last_ms_) > MaxGapMs) {", "if (false) {", 'Zeitlücke wird nicht erkannt'),
 ('E03', 'T1EndstopObserver', "bool physical_t1_park_proven() const { return false; }", "bool physical_t1_park_proven() const { return true; }", 'physischer T1-Parkbeweis true'),
 ('E04', 'T1EndstopObserver', "bool allow_motion() const { return false; }", "bool allow_motion() const { return true; }", 'Bewegungsfreigabe true'),
 ('E05', 'T1EndstopObserver', "if (triggered) state_ = State::WaitingForRelease;", "if (false) state_ = State::WaitingForRelease;", 'dauerhaft gedrückter Schalter wird nicht abgewiesen'),
 ('P01', 'G28PassiveReceipt', "v_.xyz_trusted=x&&y&&z;", "v_.xyz_trusted=x||y||z;", 'G28 gilt als vertrauenswürdig, wenn EINE Achse stimmt'),
 ('P02', 'G28PassiveReceipt', "if(elapsed>MaxDurationMs){", "if(false){", 'unplausibel lange G28-Dauer wird akzeptiert'),
 ('P03', 'G28PassiveReceipt', "if(v_.phase==Phase::Entered)return false;", "", 'laufender G28-Beleg darf überschrieben werden'),
 ('P04', 'G28PassiveReceipt', "bool physical_t1_proven()const{return false;}", "bool physical_t1_proven()const{return true;}", 'physischer T1-Beweis true'),
 ('H01', 'NativeIdexHomingTrace', "if(tool!=1){invalidate(Reason::WrongTool);return;}", "", 'falsches Werkzeug bei X2-Rückkehr ignoriert'),
 ('H02', 'NativeIdexHomingTrace', "if(view_.x2_returns!=view_.x1_returns){invalidate(Reason::WrongOrder);return;}", "", 'falsche Reihenfolge bei X2 ignoriert'),
 ('H03', 'NativeIdexHomingTrace', "if(view_.x2_returns>=2){invalidate(Reason::DuplicateX2);return;}", "if(view_.x2_returns>=9){invalidate(Reason::DuplicateX2);return;}", 'drittes X2-Homing erlaubt'),
 ('H04', 'NativeIdexHomingTrace', "view_.both_x_homeaxis_returned=view_.x2_returns>0 &&\n      view_.x2_returns==view_.x1_returns;", "view_.both_x_homeaxis_returned=true;", 'beide X-Rückkehren gelten immer als erfüllt'),
 ('H05', 'NativeIdexHomingTrace', "bool physical_t1_park_proven()const{return false;}", "bool physical_t1_park_proven()const{return true;}", 'physischer T1-Parkbeweis true'),
 ('V01', 'NativeIdexEvidence', "if(g28.phase!=G28PassiveReceipt::Phase::EndObservedTrusted ||\n       !g28.xyz_trusted || !g28.tool0){frame_.reason=Reason::G28Untrusted;return;}", "if(false){frame_.reason=Reason::G28Untrusted;return;}", 'untrusted G28 wird akzeptiert'),
 ('V02', 'NativeIdexEvidence', "if((uint32_t)(now-g28.ended_ms)>MaxAgeMs){frame_.reason=Reason::Stale;return;}", "", 'veraltete G28-Evidenz wird akzeptiert'),
 ('V03', 'NativeIdexEvidence', "frame_.t1_physically_parked=false;", "frame_.t1_physically_parked=true;", 'T1 gilt als physisch geparkt'),
 ('V04', 'NativeIdexEvidence', "if(trace.g28_sequence!=g28.sequence || trace.state==NativeIdexHomingTrace::State::Invalid){", "if(false){", 'falsche Sequenz/ungültige Spur wird akzeptiert'),
 ('A01', 'Auto60Safety', "if (!std::isfinite(celsius) || celsius >= kEmergencyTempC)", "if (!std::isfinite(celsius))", 'Notabschalttemperatur 65 C entfällt'),
 ('A02', 'Auto60Safety', "if (completed_ >= kPoints || point_index >= kPoints || point_index != completed_)", "if (completed_ >= kPoints)", 'Messpunkt-Reihenfolge entfällt'),
 ('A03', 'Auto60Safety', "if (!std::isfinite(z_mm) || std::fabs(z_mm) > kMaxAbsProbeMm)", "if (!std::isfinite(z_mm))", 'Plausibilitätsgrenze 3 mm entfällt'),
 ('A04', 'Auto60Safety', "if (std::fabs(first_ - z_mm) > kMaxProbeDifferenceMm)", "if (false)", 'Zwei-Proben-Abweichung entfällt'),
 ('A05', 'Auto60Safety', "bool allow_m500() const { return state_ == State::ReadyToPersist; }", "bool allow_m500() const { return state_ == State::ReadyToPersist || state_ == State::Probing; }", 'M500 auch während der Messung erlaubt'),
 ('A06', 'Auto60Safety', "if (completed_ != kPoints || samples_ != 0) return reject(Fault::MeshIncomplete);", "", 'unvollständiges Mesh wird akzeptiert'),
 ('J01', 'MeshJournal', "if(stage_!=Stage::Measuring || next_!=points || have_first_)return fail(Problem::Incomplete);", "", 'unvollständige Messung wird validiert'),
 ('J02', 'MeshJournal', "bool allow_eeprom_write() const{return stage_==Stage::Validated;}", "bool allow_eeprom_write() const{return stage_==Stage::Validated || stage_==Stage::Measuring;}", 'EEPROM-Schreiben schon während der Messung erlaubt'),
 ('J03', 'MeshJournal', "if(!snapshot_ || !dest || !offset || !leveling || stage_==Stage::Done) return false;", "if(!snapshot_ || !dest || !offset || !leveling) return false;", 'Rollback auch nach Commit erlaubt'),
 ('J04', 'MeshJournal', "!isfinite(offset_now)||fabsf(offset_now-original_offset_)>0.00001f) return fail(Problem::G29Failed);", "!isfinite(offset_now)) return fail(Problem::G29Failed);", 'Z-Offset-Änderung während der Messung wird akzeptiert'),
 ('J05', 'MeshJournal', "if (fabsf(first_-z)>max_disagreement_mm) return fail(Problem::Disagreement);", "", 'Zwei-Proben-Abweichung entfällt'),
]
work = tempfile.mkdtemp(); shutil.copytree(os.path.join(W, 'include'), work + '/include'); shutil.copytree(os.path.join(W, 'tests'), work + '/tests', ignore=shutil.ignore_patterns('*.py', '*.sh'))
res = []
for i, _m in enumerate(M):
    mid, hdr, old, new, why = _m[:5]
    if not lo <= i < hi: continue
    path = f'{work}/include/{H(hdr)}'
    if not os.path.exists(path): print(f'{mid} NICHT ANWENDBAR (Datei {H(hdr)} existiert in diesem Stand nicht)'); continue
    orig = open(path, encoding='utf-8').read()
    if orig.count(old) != 1 and len(_m) > 5 and orig.count(_m[5]) == 1: old = _m[5]   # Alternativtext für den Stand 10
    if orig.count(old) != 1: print(f'{mid} UNGÜLTIG: Fundstellen {orig.count(old)}'); res.append((mid, 'BADPATCH')); continue
    open(path, 'w', encoding='utf-8').write(orig.replace(old, new)); tests = sorted(deps[H(hdr)], key=lambda t: (hdr.lower().replace('native', '')[:6] not in t.lower(), t)); status = 'SURVIVED'; killer = ''
    for t in tests:
        exe = f'/tmp/mu_{mid}'; c = subprocess.run(['g++', '-std=c++11', '-O0', 'tests/' + t, '-o', exe], cwd=work, capture_output=True, text=True)
        if c.returncode: status, killer = 'INVALID', t; break
        r = subprocess.run([exe], cwd=work, capture_output=True, text=True, timeout=60)
        if r.returncode: status, killer = 'killed', t[5:-4]; break
    open(path, 'w', encoding='utf-8').write(orig); res.append((mid, status)); print(f'{mid} {status:9} {hdr:22} {why}' + (f'  <- {killer}' if killer else f'  (alle {len(tests)} abhängigen Tests grün)'), flush=True)
k = sum(1 for _, s in res if s == 'killed'); s_ = sum(1 for _, s in res if s == 'SURVIVED'); inv = sum(1 for _, s in res if s in ('INVALID', 'BADPATCH'))
print(f'--- Teilergebnis: erkannt {k}, ÜBERLEBT {s_}, ungültig {inv} von {len(res)}')
