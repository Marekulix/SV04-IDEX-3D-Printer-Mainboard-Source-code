#!/usr/bin/env python3
"""Mutationskampagne gegen die ausgelieferte Zustandsmaschine include/SV04NextAuto60Engine.hpp. Jeder Mutant baut EINEN gezielten Fehler ein; der Test muss fehlschlagen (killed).
Aufruf: python3 tools/mutate_engine.py [Wurzel]"""
import os, shutil, subprocess, sys, tempfile
from concurrent.futures import ThreadPoolExecutor
ROOT = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
HDR = 'include/SV04NextAuto60Engine.hpp'; orig = open(os.path.join(ROOT, HDR), encoding='utf-8').read()
M = [
 ('M01', 'veralteten G28-Beleg akzeptieren (Annahme = Abschluss)', 'if (o.g28_seq == home_seq_ || o.g28_seq == 0) return Action::None;', 'if (o.g28_seq == 0) return Action::None;'),
 ('M02', 'Alter des G28-Belegs nicht pruefen', 'if ((uint32_t)(o.now_ms - o.g28_ended_ms) > cfg_.max_receipt_age_ms) return abort_(Reason::HomeStale);', ''),
 ('M03', 'G28 mit Werkzeug T1 akzeptieren', '|| !o.g28_trusted || !o.g28_tool0) return abort_(Reason::HomeFailed);', '|| !o.g28_trusted) return abort_(Reason::HomeFailed);'),
 ('M04', 'g28_trusted nicht pruefen (durch Phase abgedeckt)', '|| !o.g28_trusted || !o.g28_tool0) return abort_(Reason::HomeFailed);', '|| !o.g28_tool0) return abort_(Reason::HomeFailed);'),
 ('M05', 'G28-Endphase und Vertrauen nicht pruefen', 'if (o.g28_phase != G28PassiveReceipt::Phase::EndObservedTrusted || !o.g28_trusted || !o.g28_tool0) return abort_(Reason::HomeFailed);', 'if (!o.g28_tool0) return abort_(Reason::HomeFailed);'),
 ('M06', 'Heat60: Thermotor ready nicht verlangt', 'if (target_seen_ && o.thermal_ready && o.thermal_safe) enter(State::TempStable);', 'if (target_seen_) enter(State::TempStable);'),
 ('M07', 'TempStable: Thermotor-Pruefung entfernt (durch Heat60 abgedeckt)', 'if (!o.thermal_ready || !o.thermal_safe || o.bed_target_c != 60.0f) return abort_(Reason::TempLost);\n        if (!quiet(o))', 'if (!quiet(o))'),
 ('M08', 'Soll nicht uebernommen: kein Abbruch', 'else if (elapsed() > cfg_.target_apply_ms) return abort_(Reason::HeatTargetNotApplied);', ''),
 ('M09', 'Fremdes Soll waehrend des Heizens ignorieren', 'else if (target_seen_) return abort_(Reason::ExternalActivity);', 'else if (target_seen_) {}'),
 ('M10', 'Uebertemperatur-Notgrenze entfernt', 'if (o.bed_c >= cfg_.overshoot_c) return abort_(Reason::TempOvershoot);', ''),
 ('M11', 'Not-Aus (stopped) nicht beachtet', 'if (o.stopped) return abort_(Reason::Stopped);', ''),
 ('M12', 'Druckstart/Pause waehrend des Ablaufs nicht beachtet', 'if (state_ != State::StartRequested && state_ != State::Precheck && (o.printing || o.paused)) return abort_(Reason::ExternalActivity);', ''),
 ('M13', 'ungueltige Messwerte (NaN) nicht beachtet', 'if (!float_is_finite(o.bed_c) || !float_is_finite(o.bed_target_c) || !float_is_finite(o.probe_offset_z)) return abort_(Reason::ObservationInvalid);', ''),
 ('M14', 'Benutzerabbruch wirkungslos', 'if (o.user_abort) return abort_(Reason::UserAbort);', ''),
 ('M15', 'Precheck: belegte Warteschlange nicht beachtet', 'o.motion_queued || o.queue_busy ||', 'o.motion_queued ||'),
 ('M16', 'Precheck: laufenden Druck nicht beachtet', 'if (o.stopped || o.printing || o.paused || o.motion_queued', 'if (o.stopped || o.paused || o.motion_queued'),
 ('M17', 'Precheck: aktives Werkzeug T1 nicht beachtet', 'if (!o.tool0 || !o.dual_auto_park ||', 'if (!o.dual_auto_park ||'),
 ('M18', 'TempStable: Ruhe der Maschine nicht verlangt', 'if (!quiet(o)) { if (elapsed() > cfg_.target_apply_ms) return abort_(Reason::NotIdle); return Action::None; }', ''),
 ('M19', 'VerifyHome: Z-Offset-Aenderung nicht beachtet', '        if (ABSF(o.probe_offset_z - z0_) > 0.00001f) return abort_(Reason::OffsetChanged);\n        meas_seq_ = o.g29_seq;', '        meas_seq_ = o.g29_seq;'),
 ('M20', 'VerifyLeveling: Z-Offset nicht erneut pruefen (G29 prueft selbst)', '        if (ABSF(o.probe_offset_z - z0_) > 0.00001f) return abort_(Reason::OffsetChanged);\n        if (!quiet(o) || !o.thermal_safe) return abort_(Reason::NotIdle);', '        if (!quiet(o) || !o.thermal_safe) return abort_(Reason::NotIdle);'),
 ('M21', 'veralteten G29-Beleg akzeptieren', 'if (o.g29_seq == meas_seq_ || o.g29_seq == 0) return Action::None;', 'if (o.g29_seq == 0) return Action::None;'),
 ('M22', 'G29-Fehlschlag nicht als solchen erkennen (Grund geht verloren)', 'if (o.g29_phase != G29UReceipt::Phase::RamOnlySuccess) { mesh_failure_ = o.g29_failure; return abort_(Reason::MeshFailed); }', 'if (false) { mesh_failure_ = o.g29_failure; return abort_(Reason::MeshFailed); }'),
 ('M23', 'VerifyRamMesh: Pruefung entfernt (durch MeasureG29 abgedeckt)', 'if (o.g29_phase != G29UReceipt::Phase::RamOnlySuccess || o.g29_completed != 16 || o.g29_seq == meas_seq_) return abort_(Reason::MeshFailed);', ''),
 ('M24', 'Leveling-Aktivierung nicht verlangt', 'if (!o.leveling_active) return abort_(Reason::LevelingInactive);', ''),
 ('M25', 'Commit trotz fehlender Plattformunterstuetzung', 'if (!o.eeprom_commit_supported) return finish(State::DoneRamOnly, Reason::CommitNotAvailable);', ''),
 ('M26', 'Commit ohne Bestaetigung', 'if (cfg_.auto_commit || o.user_ack)', 'if (true)'),
 ('M27', 'Heiz-Timeout entfernt', 'if (elapsed() > cfg_.heat_timeout_ms) return abort_(Reason::HeatTimeout);', ''),
 ('M28', 'G28-Timeout entfernt', 'if (elapsed() > cfg_.home_timeout_ms) return abort_(Reason::HomeTimeout);', ''),
 ('M29', 'Mess-Timeout entfernt', 'if (elapsed() > cfg_.measure_timeout_ms) return abort_(Reason::MeasureTimeout);', ''),
 ('M30', 'Commit-Timeout entfernt', 'if (elapsed() > cfg_.commit_timeout_ms) return abort_(Reason::CommitTimeout);', ''),
 ('M31', 'Wartezeit auf Bestaetigung entfernt', 'if (elapsed() > cfg_.confirm_wait_ms) return finish(State::DoneRamOnly, Reason::CommitNotConfirmed);', ''),
 ('M32', 'Readback-Abweichung nicht erkennen', 'if (o.eeprom == Eeprom::ReadbackMismatch || o.eeprom == Eeprom::SaveFailed) return abort_(Reason::ReadbackMismatch);', ''),
 ('M33', 'EEPROM-Verdacht nach Commit nicht vermerken', 'may_change_ = true; enter(State::EepromReadback);', 'enter(State::EepromReadback);'),
 ('M34', 'EEPROM-Verdacht nach bestaetigtem Readback nicht loeschen', 'may_change_ = false; return finish(State::Done, Reason::None);', 'return finish(State::Done, Reason::None);'),
 ('M35', 'Heizung beim Abbruch nicht abschalten (Hilfsfunktion; Endzustand schaltet noch)', 'Action heater_off_action() { if (heater_on_ && !off_issued_) {', 'Action heater_off_action() { if (false) {'),
 ('M36', 'Heizung im Endzustand nicht abschalten (Hilfsfunktion schaltet bereits)', 'case State::Done: case State::DoneRamOnly: case State::AbortLocked:\n        if (heater_on_ && !off_issued_) { off_issued_ = true; heater_on_ = false; return Action::SetBedOff; }', 'case State::Done: case State::DoneRamOnly: case State::AbortLocked:\n        if (false) { return Action::SetBedOff; }'),
 ('M42', 'Heizung im Endzustand UND in der Hilfsfunktion nicht abschalten (beide Pfade)', None, None),
 ('M37', 'Freigabe ohne Quittung-Bedingungen (nur ack)', 'if (o.user_ack && quiet(o) && o.g28_phase != G28PassiveReceipt::Phase::Entered && o.g29_phase != G29UReceipt::Phase::Running) {', 'if (o.user_ack) {'),
 ('M38', 'zweiter Start nicht abgelehnt', 'if (state_ != State::Idle) { if (dup_ < 255) ++dup_; return false; }', 'if (false) { if (dup_ < 255) ++dup_; return false; }'),
 ('M39', 'Zeitdifferenz ohne Ueberlauf-Schutz', 'uint32_t elapsed() const { return (uint32_t)(now_ - state_ms_); }', 'uint32_t elapsed() const { return now_ > state_ms_ ? now_ - state_ms_ : 0u; }'),
 ('M40', 'Merker der G28-Sequenz beim Home-Befehl nicht setzen', 'home_seq_ = o.g28_seq; enter(State::HomeG28);', 'home_seq_ = 0; enter(State::HomeG28);'),
 ('M41', 'Heizung wird nicht als vom Ablauf eingeschaltet vermerkt', 'z0_ = o.probe_offset_z; enter(State::Heat60); heater_on_ = true; return Action::SetBed60;', 'z0_ = o.probe_offset_z; enter(State::Heat60); return Action::SetBed60;'),
]
def one(item):
    mid, why, old, new = item
    both = mid == 'M42'
    if both:
        a1 = 'Action heater_off_action() { if (heater_on_ && !off_issued_) {'; a2 = 'case State::Done: case State::DoneRamOnly: case State::AbortLocked:\n        if (heater_on_ && !off_issued_) { off_issued_ = true; heater_on_ = false; return Action::SetBedOff; }'
        assert orig.count(a1) == 1 and orig.count(a2) == 1; mutated = orig.replace(a1, 'Action heater_off_action() { if (false) {').replace(a2, 'case State::Done: case State::DoneRamOnly: case State::AbortLocked:\n        if (false) { return Action::SetBedOff; }')
    elif orig.count(old) != 1: return (mid, why, 'UNGUELTIG(%d)' % orig.count(old), '')
    d = tempfile.mkdtemp(); shutil.copytree(os.path.join(ROOT, 'include'), d + '/include'); shutil.copy(os.path.join(ROOT, 'tests/test_auto60_engine.cpp'), d)
    open(d + '/' + HDR, 'w', encoding='utf-8').write(mutated if both else orig.replace(old, new))
    c = subprocess.run(['g++', '-std=gnu++14', '-O1', '-w', '-Iinclude', 'test_auto60_engine.cpp', '-o', 't'], cwd=d, capture_output=True, text=True)
    if c.returncode: return (mid, why, 'INVALID', 'Compilefehler')
    try: r = subprocess.run(['./t'], cwd=d, capture_output=True, text=True, timeout=120)
    except subprocess.TimeoutExpired: shutil.rmtree(d, ignore_errors=True); return (mid, why, 'killed', 'Zeitueberschreitung')
    fl = [l[6:70].strip() for l in r.stdout.splitlines() if l.startswith('FAIL')]; shutil.rmtree(d, ignore_errors=True)
    return (mid, why, 'killed' if r.returncode else 'SURVIVED', ('%d Pruefungen, z. B. %s' % (len(fl), fl[0])) if fl else '')
with ThreadPoolExecutor(max_workers=max(2, (os.cpu_count() or 2))) as ex: res = list(ex.map(one, M))
for mid, why, st, info in res: print(f'{mid} {st:9} {why}' + (f'  <- {info}' if info else ''))
k = sum(1 for r in res if r[2] == 'killed'); s = [r[0] for r in res if r[2] == 'SURVIVED']; bad = [r[0] for r in res if r[2] in ('INVALID',) or r[2].startswith('UNGUELTIG')]
print(f'--- erkannt {k}, UEBERLEBT {len(s)}: {s}, ungueltig {len(bad)} {bad} von {len(res)}')
