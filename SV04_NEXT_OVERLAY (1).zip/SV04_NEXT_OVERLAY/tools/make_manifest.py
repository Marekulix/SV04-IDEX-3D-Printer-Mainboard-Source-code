#!/usr/bin/env python3
"""SHA256-Manifest über ALLE Dateien (auch tests/*.cpp, die proof/SHA256SUMS_10.txt nicht abdeckte). Erzeugen: make_manifest.py ; Prüfen: make_manifest.py --check"""
import hashlib, os, sys
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); out = os.path.join(root, 'proof', 'SHA256SUMS_13_ALL.txt')
def files():
    for d, _, fs in os.walk(root):
        for f in sorted(fs):
            p = os.path.join(d, f)
            if p != out and '__pycache__' not in p and not p.endswith('.pyc'): yield os.path.relpath(p, root).replace(os.sep, '/')
h = lambda p: hashlib.sha256(open(os.path.join(root, p), 'rb').read()).hexdigest()
if '--check' in sys.argv:
    exp = dict((l.split(maxsplit=1)[1].strip(), l.split()[0]) for l in open(out)); cur = set(files()); bad = [p for p in exp if p not in cur or h(p) != exp[p]]; extra = sorted(cur - set(exp))
    print(f'{len(exp)} Einträge, abweichend/fehlend: {len(bad)}, nicht im Manifest: {len(extra)}'); [print('  ', x) for x in bad[:10] + extra[:10]]; sys.exit(1 if bad or extra else 0)
open(out, 'w').write(''.join(f'{h(p)}  {p}\n' for p in sorted(files()))); print('geschrieben:', out)
