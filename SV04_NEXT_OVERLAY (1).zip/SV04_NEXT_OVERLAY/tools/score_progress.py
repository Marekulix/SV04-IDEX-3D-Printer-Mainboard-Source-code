#!/usr/bin/env python3
"""Zählt Fortschrittspunkte aus progress/catalog.json. Ein Kriterium erhält den Gewichtsanteil einer Stufe (S/C/H) NUR, wenn die Stufe Nachweise listet und JEDE gelistete Nachweisdatei im
angegebenen Baum existiert und ihre Regex im Dateiinhalt trifft. Aufruf: score_progress.py --root <Baum> [--catalog <catalog.json>] [--detail] [--sensitivity]"""
import argparse, json, re, sys
from pathlib import Path
def tier_ok(root, items):
    if not items: return False, 'kein Nachweis definiert'
    for it in items:
        files = it['file'] if isinstance(it['file'], list) else [it['file']]; hit = False
        for f in files:
            p = root / f
            if p.is_file() and re.search(it['regex'], p.read_text(encoding='utf-8', errors='replace')): hit = True; break
        if not hit: return False, f"fehlt: {files[0]} ~ /{it['regex']}/"
    return True, ''
def score(root, cat, s_override=None):
    rows = []; tot = 0.0
    for c in cat['criteria']:
        w = dict(c['weights']); got = {}
        for t in w:
            ok, why = tier_ok(root, c['evidence'].get(t, [])); got[t] = (ok, why)
        weights = w
        if s_override is not None and 'H' in w:   # Sensitivität nur für Firmware-Kriterien (S/C/H): S-Gewicht ändern, Rest proportional
            rest = 100 - w['S']; weights = {k: (s_override if k == 'S' else v * (100 - s_override) / rest) for k, v in w.items()}
        pts = sum(c['points'] * weights[t] / 100 for t in w if got[t][0]); tot += pts; rows.append((c, got, pts))
    return tot, rows
if __name__ == '__main__':
    a = argparse.ArgumentParser(); a.add_argument('--root', required=True); a.add_argument('--catalog'); a.add_argument('--detail', action='store_true'); a.add_argument('--sensitivity', action='store_true'); a = a.parse_args()
    root = Path(a.root); cat = json.load(open(a.catalog or (Path(__file__).resolve().parents[1] / 'progress/catalog.json'), encoding='utf-8')); tot, rows = score(root, cat)
    if a.detail:
        for c, got, pts in rows: print(f"{c['id']:3} {pts:5.2f}/{c['points']:<3} " + ' '.join(f"{t}:{'JA' if ok else 'nein'}" for t, (ok, _) in got.items()) + '  ' + c['title'][:70])
    print(f'SUMME {tot:.2f} von 100')
    if a.sensitivity:
        for s in (15, 25, 35): print(f'  Sensitivität S-Gewicht {s} %: {score(root, cat, s)[0]:.2f}')
