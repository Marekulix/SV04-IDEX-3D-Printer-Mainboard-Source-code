"""Führt apply_native_guard_v14.apply() erstmals tatsächlich aus. SYNTHETISCHE Wurzel aus den Fixtures der Lieferung (kein echtes OEM); OEM_BLOBS werden auf die Fixture-Hashes gesetzt."""
import contextlib, hashlib, io, json, os, shutil, sys, tempfile
from pathlib import Path
W = Path(__file__).resolve().parents[1]; sys.path[:0] = [str(W / 'integration'), str(W / 'tests')]
with contextlib.redirect_stdout(io.StringIO()): import test_overlay_v14 as T
v14 = T.v14; src = dict(T.src); HEAD = [W / 'include' / n for n in v14.HEADERS]
blob = lambda b: hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
names = list(v14.OEM_BLOBS)
def make(transform=lambda n, t: t.encode('utf-8')):
    d = Path(tempfile.mkdtemp()); shas = {}
    for n in names: p = d / n; p.parent.mkdir(parents=True, exist_ok=True); b = transform(n, src[n]); p.write_bytes(b); shas[n] = blob(b)
    v14.OEM_BLOBS = shas; return d
snap = lambda d: {n: (d / n).read_bytes() for n in names}
def run(label, fn):
    try: r = fn(); print(f'{label}: OK -> {r}')
    except Exception as e: print(f'{label}: {type(e).__name__}: {str(e)[:110]}')
# A1 Normalfall
d = make(); before = snap(d); rep = v14.apply(d, HEAD, d / 'ev.json'); after = snap(d)
print('A1 Normalfall: geänderte Dateien:', sorted(n.split('/')[-1] for n in names if before[n] != after[n]), '| Configuration.h und probe.cpp unverändert:', all(before[n] == after[n] for n in ('Marlin/Configuration.h', 'Marlin/src/module/probe.cpp')), '| Evidenz-Schlüssel:', sorted(rep)[:4], '| neu angelegte Header:', sum(1 for _ in (d / 'Marlin/src/feature/sv04_next').glob('*.hpp')))
# A2 erneutes Anwenden
run('A2 erneutes Anwenden auf gepatchter Wurzel', lambda: v14.apply(d, HEAD))
# A3 SHA-Abweichung: nichts darf geschrieben werden
d3 = make(); (d3 / names[2]).write_bytes((d3 / names[2]).read_bytes() + b'\n// Drift\n'); b3 = snap(d3); run('A3 SHA-Abweichung', lambda: v14.apply(d3, HEAD)); print('   danach unverändert:', snap(d3) == b3)
# A4 Fehler mitten im Schreiben (zweite Schreiboperation scheitert)
d4 = make(); b4 = snap(d4); orig_write = type(d4).write_text; cnt = {'n': 0}
def flaky(self, *a, **k):
    cnt['n'] += 1
    if cnt['n'] == 2: raise OSError('Datenträger voll (simuliert)')
    return orig_write(self, *a, **k)
type(d4).write_text = flaky
try: v14.apply(d4, HEAD, d4 / 'ev.json'); print('A4: kein Fehler?')
except OSError as e: print('A4 Fehler beim 2. Schreiben:', e)
finally: type(d4).write_text = orig_write
a4 = snap(d4); mod = [n.split('/')[-1] for n in names if a4[n] != b4[n]]; print('   Zustand danach: geänderte OEM-Dateien =', mod, '| Wurzel halb gepatcht:', 0 < len(mod) < 3)
v14.OEM_BLOBS = {n: blob(b4[n]) for n in names}; run('   erneuter Versuch danach', lambda: v14.apply(d4, HEAD))
# A5 Nicht-UTF-8 im OEM (z. B. chinesische Kommentare in GBK)
d5 = make(lambda n, t: (t + '\n// ' + '注释').encode('gbk') if n.endswith('LCD_RTS.cpp') else t.encode('utf-8')); run('A5 OEM-Datei in GBK-Kodierung', lambda: v14.apply(d5, HEAD))
# A6 CRLF-Zeilenenden im OEM
d6 = make(lambda n, t: t.replace('\n', '\r\n').encode('utf-8')); b6 = snap(d6); run('A6 OEM mit CRLF-Zeilenenden', lambda: v14.apply(d6, HEAD)); print('   danach unverändert:', snap(d6) == b6)
