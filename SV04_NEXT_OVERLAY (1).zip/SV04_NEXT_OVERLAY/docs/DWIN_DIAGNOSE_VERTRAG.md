# Stand 7: Diagnosevertrag für die spätere DWIN-Integration

**Status:** Geplante/experimentelle interne RAM-Schnittstellen. Kein fertiges Displaymenü. **NICHT FLASHEN.**

## Was tatsächlich existiert

`integration/apply_native_guard_v12.py` baut auf v10 auf und ergänzt im originalen
`LCD_RTS.cpp` rein lesende RAM-Aktualisierungen: `NativeStatusPacket` und `MeshMapPacket`.
Nichts davon sendet Daten ans Display oder nimmt Touchbefehle entgegen. Die normale
Sovol-Bettvermessung bleibt unverändert; `G29 U` ist weiterhin nur ein separater
experimenteller, optionaler Pfad. `Marlin/Configuration.h` und `probe.cpp` bleiben
bei Anwendung des Patches unverändert.

## Statusdatensatz `S7`, Formatversion 1, exakt 32 Bytes

| Offset | Bytes | Inhalt |
|---|---:|---|
| 0–1 | 2 | ASCII `S7` |
| 2 | 1 | Version 1 |
| 3 | 1 | Länge 32 |
| 4–7 | 4 | Millisekundenzeit, LE |
| 8–11 | 4 | native G29-U-Laufkennung, LE |
| 12–13 | 2 | 16-Punkt-Bitmaske, LE |
| 14 | 1 | gültige Messpunkte (0–16) |
| 15 | 1 | Qualität der passiven Ereignisbeobachtung |
| 16 | 1 | NativeReadiness Gate |
| 17 | 1 | G29-U-Phase |
| 18 | 1 | G29-U-Fehler |
| 19 | 1 | X_MAX-Schalterbeobachtung |
| 20 | 1 | Anzeigestatus 0–6 |
| 21 | 1 | Fehlergrund 0–8 |
| 22 | 1 | **Nur Diagnoseflags:** RAM fertig, elektrischer Schalterkontakt, Datenquelle beobachtet |
| 23 | 1 | **Immer 0**, keine Motor-/Heiz-/EEPROM-Freigabebits |
| 24–27 | 4 | Anzahl Beobachtungen |
| 28–29 | 2 | Schalter-Ereigniszähler, gesättigt bei 65.535 |
| 30–31 | 2 | CRC16-CCITT-FALSE (Init FFFF, Polynom 1021) über Bytes 0–29, LE |

Anzeigestatus: 0 Keine Daten; 1 Leerlauf; 2 Laufende Messung;
3 **16/16 erfolgreich im RAM**; 4 Abgelehnt; 5 Fehlgeschlagen; 6 Ungültig.
**Status 3 darf niemals als `M500`- oder Flash-Freigabe interpretiert werden.**

## Messwertdatensatz `SM`, Formatversion 1, exakt 48 Bytes

| Offset | Bytes | Inhalt |
|---|---:|---|
| 0–1 | 2 | ASCII `SM` |
| 2 | 1 | Version 1 |
| 3 | 1 | Länge 48 |
| 4–7 | 4 | G29-U-Laufkennung |
| 8–9 | 2 | 4×4-Recordmaske |
| 10 | 1 | Anzahl erfasster Punkte |
| 11 | 1 | native G29-U-Phase |
| 12–43 | 32 | 16 Werte, zeilenweise `index = y×4 + x` |
| 44 | 1 | 0 Leer; 1 Unvollständig; 2 RAM vollständig; 3 Ungültig |
| 45 | 1 | Immer 0, keine Freigabe |
| 46–47 | 2 | CRC16-CCITT-FALSE über Bytes 0–45 |

Messwerte sind **vorläufige Höhenmessungen in 0,001 mm**, 16-Bit signed LE.
Der Wert `-32768` bedeutet „nicht gemessen“ und darf nicht als negative Höhe
interpretiert werden. Werte außerhalb ±10 mm werden defensiv zurückgewiesen.
Wichtig: Dies sind gemessene BLTouch-Z-Werte und **nicht** automatisch dieselben
Werte wie eine gespeicherte Mesh-Korrektur oder ein neu bestätigter Z-Offset.

## Für die spätere Bildschirmdarstellung

Die originale DWIN-HMI-Projektdatei samt Ressourcen und festen VP-Adressen ist
weiterhin erforderlich. Es werden **keine** erfundenen Button-, Image- oder VP-Adressen
benutzt. Vorhandene 16 originalen Levelling-VPs dürfen nicht überschrieben werden,
solange ihr Layout und die Rückwärtskompatibilität nicht geklärt sind.

Geplante Anzeige: aktueller Schritt, G29-U-Laufnummer, Punktzähler, 4×4-Werte,
Heizbetttemperatur, Fehlerursache, roter Abbruchstatus. Farben für eine vollständige
Messkarte erst bei **Status 3 + Kartenstatus 2**, beide gleiche Laufkennung und
aktuell. **Grün bedeutet nur RAM-Messerfolg, niemals schon EEPROM gespeichert.**

## Harte Grenzen

- CRC ist Fehlererkennung, keine kryptografische Authentifizierung.
- Es gibt kein echtes Displaymenü, keine Automatik und keine physische
  T1-Parkbestätigung. Endschalterkontakt ist kein sicherer physischer Parkbeweis.
- Bei verspäteten, widersprüchlichen oder nach einer Zeitlücke gesehenen
  Ereignissen wird **keine erfolgreiche Karte** ausgegeben.
- Nach Rückkehr von GitHub: ein gemeinsamer STM32-Build für alle neuen
  Offline-Änderungen; danach unabhängige Hardware- und Kollisionsprüfungen.
