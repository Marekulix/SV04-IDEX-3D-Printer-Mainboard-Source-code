# RAM-Mesh-Sicherung (vorhanden) und kontrollierter Commit (offen), Stand 12

## Was im Overlay bereits steht (G29.cpp, eingefügt von `apply_native_guard_v2..v7`)
* `SV04NextMeshRollback`: Snapshot von `z_values`, `bilinear_start`, `bilinear_grid_spacing`, `planner.leveling_active`, `probe.offset.z`; `revert()` stellt alles wieder her (`set_bed_leveling_enabled(false)` → Mesh zurück → `refresh_bed_level()` → Leveling wie vorher) und zeichnet die DWIN-Meshfelder (bei `RTS_AVAILABLE`) mit den alten Werten neu. Der Destruktor ruft `revert()`; nur `accept()` nach 16/16 entschärft ihn.
* Vor der Konstruktion des Guards liegen alle Verweigerungen (nichts wurde bis dahin verändert). Kein `settings.save()` und kein `M500` im gesamten eingefügten Code (statisch geprüft in den Patchskripten).
* Nachweis (Simulation): `harness/run_harness.py`, 130 Szenarien, Fehler an jedem der 16 Punkte; Mutationskampagne `harness/mutate_g29.py` (Rollbackpfade werden von Mutanten M11 bis M16, M29 erkannt).

## Annahmen, die nur der native Build oder das Gerät klären kann (OPEN)
1. Nach einem erfolgreichen OEM-`G29` ist `planner.leveling_active` wahr. Der Erfolgsentscheid in `G29.cpp` verlangt das (`sv04_good`). Falls Marlin die Leveling-Aktivierung anders handhabt, würde jeder Lauf zurückgerollt (Szenario L01 des Harness beschreibt genau diesen Ausgang).
2. `refresh_bed_level()`, `set_bed_leveling_enabled()`, `bilinear_start`, `bilinear_grid_spacing`, `probe.offset.z` heißen im exakten OEM-Stand so (die Namen stammen aus Patches, die laut Ihnen für v9 zweimal gebaut wurden; v14 nicht).
3. Das Verhalten bei `M112`, Watchdog und Stromausfall während des Laufs: RAM-Mesh geht verloren, das EEPROM-Mesh bleibt unverändert, weil im eingefügten Code kein Schreibpfad existiert.

## Was fehlt (Commit-Stufe, bewusst nicht implementiert)
`M500` genau einmal nach `RamOnlySuccess`, danach Readback (`M420 V`/`M503`) mit Bit-Vergleich der 16 Werte und des Offsets; Abweichung ⇒ Fehler, Mesh bleibt im RAM, Benutzerhinweis. `Auto60Safety`/`MeshJournal` modellieren das nur auf dem Host (gehören nicht zum Firmware-Code). **Befund B15 bleibt:** `allow_m500()` bleibt bis `begin_persist()` wahr; ein nativer Aufrufer muss beides atomar tun.
**Nicht garantierbar:** EEPROM-Atomarität bei Stromausfall während `M500`.
