# SV04 NEXT: Stand 13 (Claude, 30.10.2026)  |  NICHT FLASHEN

Stand 13 = Stand 12 + auslieferbare Zustandsmaschine `SV04NextAuto60Engine.hpp` (Heizen auf 60 C, Referenzfahrt mit Verifikation durch NEUE Belege, Messung, Abbruch, Commit-Gating) + Marlin-Bruecke `SV04NextAuto60Glue.hpp`
(nur vier Aktionen: Soll 60, Soll 0, "G28", "G29 U"; EEPROM NICHT verdrahtet) + Overlay `apply_native_guard_v16.py`.
Die Bruecke ist STANDARDMAESSIG NICHT einkompiliert (Makro SV04_NEXT_AUTO60_ENGINE, nirgends gesetzt) und es gibt KEINEN AUSLOESER (kein DWIN-Knopf, kein G-Code, kein Aufruf von auto60_request_start()).
Nachweise nur als SIMULATION: Maschine 66 Pruefungen (Szenarien, 10 x 156 zeitgesteuerte Stoerungen, 20.000 Zufallslaeufe, Invarianten bei jedem Schritt), E2E-Harness 16 Pruefungen gegen den vom Overlay erzeugten G28/G29-Code,
Overlay v16 53 Pruefungen, Mutationskampagnen: Maschine 37/42, Bruecke 15/16, erzeugter G29-Code 25/30. KEIN Marlin-Build, KEIN CI-Lauf, KEIN Hardwaretest.
Die Namen der drei Marlin-Makros der Bruecke (setTargetBed, enqueue_one_P, has_commands_queued) sind UNVERIFIZIERT; `6.yml` baut dafuer die Variante overlay-auto60.
Fortschritt laut Katalog: 16,85 von 100 (Stand 12: 10,85; Stand 11: 1,75). Alle frueheren Prozentangaben gelten nicht mehr.
