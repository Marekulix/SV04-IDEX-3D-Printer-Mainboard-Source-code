# SV04 NEXT – Entwicklungsstand 10 (30.10.2026)

**NICHT FLASHEN. 40 % gewichtete Gesamtfortschrittsschätzung (+2 Prozentpunkte zu 38 %).**

## Echte Änderungen gegenüber 9.zip

1. `SV04NextNativeIdexHomingTrace.hpp`: native passive G28-Ablaufspur für rechts T1/X2 und links T0/X1. Pro G28-Lauf werden bis zu zwei X2/X1-Homeaxis-Rückkehrpaare, ihre zeitliche Reihenfolge und frühe Rückkehr erfasst. Ein Homeaxis-Rücksprung ist keine Endschalter- oder Parkbestätigung.
2. `SV04NextNativeIdexEvidence.hpp`: verknüpft denselben G28-Lauf mit bestehendem G28-Receipt, elektrischem X_MAX-Audit und optionalem G29-U-RAM-Erfolg. Widersprüche, alte Messungen, Teil-Homing oder fehlender rechter Schlitten werden abgewiesen.
3. `apply_native_guard_v14.py`: Instrumentierung genau an beiden OEM-`G28.cpp`-IDEX-X2->X1-Homeaxis-Paaren sowie RAM-Observer-Integration in die native `LCD_RTS.cpp`. Nur für IDEX mit bilinearem ABL; bei unerwartetem OEM-Quelltext wird der Patch zurückgewiesen.
4. Schutz: Änderungen an `Marlin/Configuration.h` und originaler `probe.cpp` weiterhin verboten; neuer Code kann weder Motoren noch Heizung, G-Code-Queue, EEPROM oder Display bedienen. Kein T1-Parkbeweis.
5. Tests: zwei neue C++11-Kombinationstests, OEM-Patch-Fixture, Compiler GCC -O0/-O2/UBSan und Clang ASan+UBSan. Vollständige lokale Testsuite inklusive aller älteren Entwicklungsblöcke bestanden (Log `proof/full-local-tests-10.log`, Exit 0). **Das ist KEIN STM32-Firmwarebuild!**

## Wesentliche Erkenntnis

Die vorherige G28-/X_MAX-Korrelation konnte durch reine zeitliche Nähe ein elektrisches Ereignis nach G28 anzeigen, ohne dass der aktuelle G28 beide X-Schlitten ansteuerte. Der neue kombinierte Bericht verlangt beobachtete rechte und linke `homeaxis`-Rückkehr im selben G28-Lauf. Das ist besserer Nachweis des **ausgeführten Firmwarepfads**, kein Nachweis physischer Kollisionsfreiheit.

## Fortschrittsmaßstab (internes Schätzmodell, Gesamt 100 Punkte)

| Teilbereich | Maximal | Erreicht |
|---|---:|---:|
| Anforderungen/Architektur | 8 | 8 |
| G29-U-Receipts/16-Punkte-RAM-Karte | 13 | 11 |
| 60-Grad-Temperaturprüfung | 8 | 5 |
| G28-/IDEX-native Pfadbeobachtung | 12 | 9 |
| Unabhängiger physischer T1-Interlock | 15 | 0 |
| Abbruch/Rücksetzung | 10 | 5 |
| Reale automatische Steuerung | 12 | 1 |
| EEPROM-Commit mit Readback | 8 | 0 |
| Echte DWIN-Touchintegration | 7 | 1 |
| STM32-Integration und Druckertests | 7 | 0 |
| **Gesamt** | **100** | **40** |

Das Modell ist **kein objektives Messverfahren**. Sicherheitskritische fehlende Funktionen bleiben trotz hoher Host-Testabdeckung hoch gewichtet. Keine Hardwarefreigabe.

## Nächste Schritte

- Native STM32-Gesamtkompilierung von v14 gegen exakt verifizierte Sovol-Quellen.
- Physische T1-Park- und Kollisionserkennung unabhängig vom gespeicherten X2-Koordinatenwert nachweisen.
- Erst danach eine transaktionale, zeitüberwachte Steuerung für 60°C -> G28 -> G29 -> Validierung -> geschützter EEPROM-Commit entwickeln.
- Originales DWIN-HMI-Projekt/VPA-Karte des Displays beschaffen oder echtes Gerät sicher analysieren. Keine erfundenen VP-Adressen.
