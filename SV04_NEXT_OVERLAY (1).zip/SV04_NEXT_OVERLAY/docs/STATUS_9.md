# SV04 NEXT – Sammelangriff 9 (offline, keine Firmware)

## Tatsächlich verändert
- Neuer `SV04NextT1CorrelationAudit.hpp`: wertet G28-Zustand und beobachteten X_MAX-Release-/Press-Zyklus zeitlich zusammen aus; niemals Bewegungsfreigabe oder physischer Parkbeweis.
- Gegen alte bereits vorhandene Schalterimpulse abgegrenzt; 30-Sekunden-Grenze nach G28-Ende.
- Diagnose-Fehlerkorrektur: Ein einmal beobachteter elektrischer Zusammenhang wird bei späterem ungültigen Sample **zurückgesetzt**.
- `SV04NextG28G29OrderWitness.hpp`: alte G28/G29-Erfolgsmeldungen verfallen nach höchstens 20 Minuten; nach Stale kein automatischer Wiederanlauf.
- Neue 4.096-kombinatorische T1-Tests sowie Compiler- und Sanitizerprüfung.

## Offene Risiken
- Kein unabhängiger physischer T1-Parkzeugen, daher **keine Bewegungsfreigabe**.
- Kein STM32-Gesamtbuild dieses Pakets und keine Hardwaretests.
- Keine DWIN-Touchfläche, kein automatisches Heizen, G28/G29-Auslösen oder EEPROM-Schreiben.
- Native Integration der neuen T1-Auditklasse fehlt: sie ist derzeit ein testbarer Read-only-Hostbaustein. Die G28/G29-Header-Zeitgrenze wird mit dem bestehenden Patch übernommen.
- Bestehender G28-G29-Reihenfolgecheck liefert nur Diagnosedaten; er ist nicht sicherheitszertifiziert.

## Fortschritt
Gewichtete technische Schätzung: 38 % (vorher 37 %; +1 Prozentpunkt). Keine naive Summe bestandener Tests, fehlende reale Steuerung zählt hoch.

## Testläufe
- `proof/focused-tests-9.log`: sämtliche geänderten Tests GCC O0/O2, GCC UBSan, Clang ASan+UBSan bestanden, v13 Patch-Fixture PASS.
- `proof/full-local-tests-9.log`: gesamter Lauf nach erfolgreichem Block 6 wegen Laufzeitlimit **nicht vollständig**; daraus kein Gesamtsuite-PASS abgeleitet.
