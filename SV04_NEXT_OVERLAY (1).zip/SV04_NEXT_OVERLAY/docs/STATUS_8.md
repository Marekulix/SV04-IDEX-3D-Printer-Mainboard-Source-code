# SV04 NEXT - Stand 8: G28-Frühabbruch und G28→G29-U-Ereignisse

**NICHT FLASHEN. Kein GitHub-Upload erforderlich.**

## Verbindlicher Gesamtfortschritt (gewichtete Schätzung)

| Pflichtbereich | Gewicht | Stand 8 erreicht (geschätzt) |
|---|---:|---:|
| Reproduzierbarer OEM-Firmwarebuild und Entwicklungsbasis | 10 % | 10 % |
| G29-U-Doppelmessung, 4×4-Mesh-Erfassung und Tests | 18 % | 12 % |
| Native 60-°C-Heiz-/Stabilitätssteuerung | 12 % | 4 % |
| G28-/G29-Ablauf und Endereignisse | 12 % | 3 % |
| Physischer IDEX-T1-Kollisionsschutz | 14 % | 2 % |
| Abbruch, RAM-Rollback und kontrolliertes EEPROM | 12 % | 4 % |
| DWIN-Touchbedienung inkl. Messkarte | 12 % | 2 % |
| Echte Drucker- und Freigabetests | 10 % | 0 % |
| **Gesamt** | **100 %** | **37 %** |

Der Stand 7 war nach derselben Bewertungslogik etwa **34 %**. Die Anzeige ist eine subjektive Entwicklungs- und Risikoeinschätzung, keine präzise wissenschaftliche Messung und keine Flashfreigabe. Der große Rest besteht überwiegend aus **nicht validierten Hardwarefunktionen**.

## Neue funktionierende Bausteine

1. `include/SV04NextG28PassiveReceipt.hpp`: Kennzeichnet G28-Eintritt, vorzeitigen Rücksprung sowie beobachtetes Funktionsende mit XYZ-Softwarevertrauen. Ein vorzeitiger Rücksprung zählt niemals als reguläres Ende.
2. `include/SV04NextG28G29OrderWitness.hpp`: Rein passive Zuordnung eines frischen G29-U-Laufs zum jüngsten G28-Endereignis. Ablehnung alter Laufergebnisse, fehlender Referenzvertrauenswerte und überlanger Zeitabstände.
3. `integration/apply_native_guard_v13.py`: Ergänzt zwei Read-only-Hooks in `G28.cpp` und `LCD_RTS.cpp`, bei echtem Originalcode nur mit SHA-gesichertem Ausgangsstand. Der originale Sovol-Quelltext `G28.cpp` hat Git-Blob-SHA `5700ac25228ef7405797a80b840bab1dacddfcc7`.
4. `tests/test_g28_receipt.cpp`, `tests/test_g28_g29_order.cpp`: Zustandstests mit 65.536 Varianten, in GCC -O0/-O2/UBSan und Clang ASan+UBSan.
5. `tests/test_overlay_v13.py`: Prüft Quelltextanker, Verweigerung von doppeltem Patch, Sicherheitsverbot und Erhaltung der OEM-Konfiguration.

## Harte Grenzen

- Ein regulär zurückgekehrtes G28 und `axis_is_trusted()` beweisen **nicht**, dass der Endschalter tatsächlich korrekt betätigt wurde oder T1 physisch sicher steht.
- Ein G28-Ende ist **kein** Auftrag zum nächsten G29. Die Zuordnung ist ausschließlich ein Diagnosewert.
- Bisherige `Marlin/Configuration.h` und originale `probe.cpp` bleiben unverändert.
- Keine automatische Aufheizung / Homing / G29-Steuerung und keine Motor-/Heizungsfreigabe.
- Keine Speicherung mit `M500`, keine neue DWIN-Schaltfläche, kein Druckerversuch.
- **Der neu veränderte native G28-Code ist noch NICHT auf dem STM32 kompiliert worden.** Hosttests und Patch-Fixtures reichen für eine Hardwarefreigabe nicht aus.

## Nächste Angriffe, ohne wiederholte GitHub-Uploads

1. Eindeutige G28-Nachweise für X0/X1, Y, Z und Nicht-Erfolg trotz vertrauenswürdiger Vorpositionen entwickeln.
2. Prüfung, ob aktives Werkzeug nach Homing wieder auf 0 zurückkehrt und wann ein sicherer Parknachweis möglich ist.
3. Echte DWIN-Quell-Pins bzw. HMI-Ressourcen beschaffen; keine erfundenen Touch-Adressen.
4. Transaktionalen Abbruch im blockierenden G29 bis zur mechanisch verifizierten Hardwareprüfung weiterhin nicht freigeben.
5. Alle neuen nativen Patches später in **einem** gebündelten STM32-GitHub-Build testen.
