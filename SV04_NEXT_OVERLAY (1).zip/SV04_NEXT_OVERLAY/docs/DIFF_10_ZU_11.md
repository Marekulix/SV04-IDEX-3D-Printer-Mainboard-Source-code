# Änderungsübersicht Stand 10 → Stand 11 (ohne proof/)

**Geändert (5):** `include/SV04NextG29UReceipt.hpp`, `include/SV04NextMeshMapPacket.hpp`, `include/SV04NextNativeReadiness.hpp`, `include/SV04NextNativeThermalGate.hpp`, `tests/run_all_local.sh`

**Neu (10):** `include/SV04NextSafeFloat.hpp`, `integration/apply_native_guard_v15.py`, `tests/run_block11_only.sh`, `tests/run_matrix_11.sh`, `tests/test_audit11_negative.cpp`, `tests/test_fastmath_native_guard.cpp`, `tests/test_overlay_v15.py`, `tools/mutation_audit.py`, `tools/probe_apply_v14.py`, `tools/probe_gaps.cpp`

**Entfernt:** keine

| Datei | SHA256 Stand 11 |
|---|---|
| `include/SV04NextG29UReceipt.hpp` | `2dbb44ba0bbabe5f30d7316f72b64d4901d63138ee2ac7293d481746cea32e88` |
| `include/SV04NextMeshMapPacket.hpp` | `36f929b8435e114fdf609f58a5581c13fafbe06cfdc1233416aecd4e18e083c0` |
| `include/SV04NextNativeReadiness.hpp` | `016678690c8630f8d6d78e7b3bc5cc170bb0f234899bbd0bd93531412f003e77` |
| `include/SV04NextNativeThermalGate.hpp` | `a6ec714fd80fbe31e68ba12e838202568cc29e3526a30da6acd79bd8896f973f` |
| `tests/run_all_local.sh` | `b5bfa8ac0727a5028cbeefa76cbc8e33406da8a14eec970ebba261e5fcb07305` |
| `include/SV04NextSafeFloat.hpp` | `5f00772a9f22575346731bd7075fb954cab9019d711831b338f13dd1cb3ac5d0` |
| `integration/apply_native_guard_v15.py` | `2c4491aab0fbd3fa8eda858d45691b631b064ec3dd6512f3144c9b5bff17f2e0` |
| `tests/run_block11_only.sh` | `27258c711ea561bde5dc466a661ff122ae24f43fb9b0c64ae8d6c341b3199169` |
| `tests/run_matrix_11.sh` | `36246f0d118659b15f2abfa0e991b0ba2aeb2847ec388a40cd2f3b0e2908a904` |
| `tests/test_audit11_negative.cpp` | `0466263efd66be5d9a9f55918227927235c6fd846e24ed87c9519c5ac025d203` |
| `tests/test_fastmath_native_guard.cpp` | `90aedf5dfc091c3b0729e97d105ba2771892aff18c6a55d547bd6ab4c788affa` |
| `tests/test_overlay_v15.py` | `8e5b66700fb099603e04509714be1b66cb8f225bc1f2c1fed83447c11f2ff2f1` |
| `tools/mutation_audit.py` | `b7d86d8721070eb2cad2eff87f03cc6b5d5ac3a61ab590901953703523c1b9a1` |
| `tools/probe_apply_v14.py` | `2c21e284d6476026fe7773cea72aec115383e709fbd506b1a8aef70688d380ed` |
| `tools/probe_gaps.cpp` | `8ecafe34f0a6ad1ae5189f1367ca65a55c337c73cefe3e8b1ef9d14480d18121` |

Nicht geändert: `integration/apply_native_guard_v2..v14.py`, `Marlin`-Overlay-Logik von v14 (v15 ergänzt sie), alle übrigen Header. OEM-`Configuration.h`/`probe.cpp` werden weiterhin NIE verändert.
