# SV04 NEXT – Stand 11 (Prüfer-Stand von Claude, 30.10.2026)

**NICHT FLASHEN. Kein nativer STM32-Build, keine Hardwaretests. Keine Freigabe.** Dieser Stand ist Härtung und Testgüte, kein Funktionsfortschritt.

## Was sich geändert hat (jeweils durch einen reproduzierten Befund belegt, Details in `CLAUDE_PRUEFBERICHT.md`)
1. `SV04NextSafeFloat.hpp` (neu): bitbasierter Finite-Check. Die nativen Header (G29UReceipt, NativeReadiness, NativeThermalGate, MeshMapPacket) verwenden ihn statt `isfinite()`. Unter `-ffast-math` nahm der Stand 10 NaN/Inf als Messhöhe an.
2. `SV04NextG29UReceipt.hpp`: Plausibilitätsgrenze `MaxAbsZmm = 3.0f` (Stand 10 akzeptierte ±1e30 mm und 25 mm als RamOnlySuccess).
3. `SV04NextNativeThermalGate.hpp`: Drift-Prüfung `MaxSpreadC = 0.8f` (Stand 10 meldete ein Bett, das nur durch 59..61 °C hindurchfährt, nach 20 s als bereit). **Schwelle UNVALIDIERT**, an der echten Heizplatte abzustimmen; zu enge Werte führen zu „nie bereit" (sicherer Ausfall).
4. `apply_native_guard_v15.py` (neu): atomarer Einstieg mit Rollback, `--dry-run`, `--diff-out`, klare Ablehnung bei CRLF und Nicht-UTF-8, installiert SafeFloat.
5. Tests: `test_audit11_negative.cpp` (125 Prüfungen, tötet alle 13 überlebenden Mutanten), `test_fastmath_native_guard.cpp`, `test_overlay_v15.py` (führt `apply()` erstmals tatsächlich aus). Mutationskampagne: Stand 10 37/50 erkannt, Stand 11 54/54.
6. Läufer: irreführendes Zwischenbanner entfernt, ehrliches `NOT_RUN` für Clang und STM32, `run_block11_only.sh`, `run_matrix_11.sh`; Manifest über ALLE Dateien (`tools/make_manifest.py`).

## Fortschrittsbewertung
Die interne 40-%-Schätzung wird **nicht bestätigt und nicht erhöht**. Claudes subjektive Einschätzung (kein Messwert): etwa 30 % (Spanne 25–35 %), begründet in `CLAUDE_STATUS.md`. Mein Stand 11 erhöht keinen Teilbereich, weil er Härtung und Testgüte betrifft und keine Anforderung nativ umsetzt.

## Weiterhin offen
Nativer Build gegen exakte OEM-Quellen (A01), unabhängiger physischer T1-Interlock, native RAM-Mesh-Sicherung und Wiederherstellung, DWIN (keine VP-Karte), EEPROM-Commit, reale Ablaufsteuerung, Vereinheitlichung der konkurrierenden Modelle (A04). Siehe `docs/ENTWURF_RAM_MESH_UND_COMMIT_11.md`.
