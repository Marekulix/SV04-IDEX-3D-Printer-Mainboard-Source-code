# Ziel: spätere native Marlin-Abbruchanbindung, jetzt NICHT ausführbar

Die vorhandenen Dateien sind bewusst C++11-Hostmodelle. Sie dürfen nicht direkt
als Motor-/Heiz-/GCode-Adapter eingebaut werden. Für einen künftig erlaubten
Build wird zuerst ein passiver Adapter mit folgenden getrennten Quellen benötigt:

1. **Run/Generation**: Boot-Generation und Laufnummer; nach Firmware-Neustart
   sämtliche alten Laufnachweise ungültig. Auto-Start bleibt gesperrt.
2. **Aktive Kommandos**: Native Befehlsannahme, Ausführung, tatsächliches
   Ende und das aktuelle Kommandoticket müssen aus derselben Generation stammen.
3. **Planner / Queue**: Bewegung aus, Warteschlange leer und aktueller
   Maschinenzustand nach einem Abbruch sind zu unterscheiden. `M400`-Antwort
   allein ist kein physischer Sicherheitsnachweis.
4. **BLTouch**: G29-Erfolg braucht 16 individuell validierte Messstellen, jeden
   Punkt zweimal gemessen, homogene Temperatur, plausiblen Höhenbereich und
   eine echte eingefahrene Sonde. G29-Fehler darf kein nachfolgendes `M500`
   auslösen, selbst wenn der GCode-Puffer bereits weitere Kommandos enthält.
5. **T1-Parkposition**: mechanisch nachgewiesener T1-Weg und gültiges Endschalter-
   Ereignis beim tatsächlich ausgeführten T1-Homing, samt Kollisionsabstand zu
   T0, nicht nur X2-Koordinate und X-Max-Kontakt. Fehlt dieser Nachweis, startet
   keine automatische Bewegung.
6. **Thermik**: Bett-Target 60°C, 20s Stabilitätswitness, Heizungslimits,
   Thermistor-Gültigkeit. Abbruch erfordert unabhängiges Stoppen des Ablaufs;
   diese Hostmodule schalten weder Heizung noch Motoren ab.
7. **RAM-Schutz**: ursprünglichen Zustand (16 Werte, Geometrie,
   Leveling-Aktivierung und Z-Offset) sichern; bei Abbruch erst quiescent,
   dann sicheres Restore durchführen und wirklich zurücklesen. Ohne gültiges
   Readback bleibt die Sperre dauerhaft bestehen. Keine automatische Änderung
   des Benutzer-Z-Offsets (bisher -1,10mm).
8. **M500**: weiter kategorisch gesperrt. Eine spätere Freigabe muss
   transaktionsgebunden und vom echten getesteten Zustand abhängig sein.

## Reale DWIN-Integration

Erst Original-HMI-Projekt identifizieren und Kollisionen mit vorhandenen VP
vermeiden. Bis dahin nur passives Statusmodell; niemals allein anhand der
simulierten Hostdaten `100%` und Grün auf dem Drucker anzeigen.

## Teststrategie ohne GitHub

- Die lokale Suite darf Änderungen im Hostmodell prüfen, ersetzt aber
  **keinen** echten STM32/Marlin-Kompiliertest.
- Neue native Patchdateien später nur an die bestätigte OEM-Quelle binden,
  mit SHA-Schutz, danach ein gemeinsamer GitHub-Build.
- Vor einem Hardwaretest ausdrücklich Sicherheitsfreigaben und geeignete
  Kontrolle des bewegten Druckkopfs vor Ort verlangen.
