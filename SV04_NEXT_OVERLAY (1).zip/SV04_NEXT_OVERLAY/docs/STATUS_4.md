# 4 | SV04 NEXT | großer Offline-Entwicklungsblock ohne GitHub

**STATUS: ENTWICKLUNGSSTAND, NICHT FLASHEN.**

## Herkunft der Nachweise

- Basis: Benutzerstand `3.zip` inklusive nativer v9-Diagnose und aller älteren Host-Tests.
- Letzter unabhängig bestätigter STM32-Build: GitHub `2` auf dem damaligen Stand 2:
  STM32F103RET6_creality, RAM 14,3 %, Flash 30,3 %, `SUCCESS`.
- Die hier neu hinzugefügten Module sind **lokal in C++11** getestet; sie sind
  **nicht** in Marlin oder das physische DWIN-Touchdisplay verdrahtet und wurden
  **nicht** für STM32 gebaut.
- Dieser Stand wird ohne YAML bereitgestellt und erfordert momentan kein GitHub.

## Technischer Fortschritt (neue Module)

1. `SV04NextAuto60Policy.hpp`: zentrale 30-s-Annahmefrist für Kommandos,
   12-min-Gesamtlaufzeit Heizen, 20-s-stabile Temperatur, 3-s-Messgap,
   3-min-G28-Timeout und 15-min-G29-Timeout. Diese Fristen sind aktuell
   Entwicklungsparameter aus dem bestehenden SequencedController, keine
   durch Hardwaretests validierten Produktionswerte.
2. `SV04NextOperationLedger.hpp`: eindeutige Laufnummer plus Befehls-ID,
   **separate** native Befehlsannahme und nachgewiesene Ausführung.
   Heizauftrag wird nicht nach 30 Sekunden als aufgewärmt betrachtet.
   Ungültige, doppelte oder zeitfremde Rückmeldungen können kein
   neues Kommando starten. Dropout bei Sicherheitsdaten sperrt.
3. `SV04NextThermalWitness.hpp`: kontinuierliche 60-Grad-Messung über 20 Sekunden,
   inkl. Temperaturabweichung, Sensorfehler, 3-s-Datenlücke, Zieländerung,
   Übertemperatur und Zeitüberlauf. Alle Messwerte HOST-/SIMULIERT.
4. `SV04NextHomingWitness.hpp`: G28-Abschluss muss an *aktueller Lauf + aktueller
   Dispatch + frisches natives Homing-Ereignis* gebunden sein.
   **Noch kein echtes Homing-Ereignis aus Marlin angeschlossen.**
   Kein T1-Parknachweis durch dieses Modul.
5. `SV04NextMeshIntegrity.hpp`: 4x4-Mesh geometrisch und numerisch prüfen,
   originalen Z-Offset und Rastergeometrie bitgenau bewahren,
   RAM-Rollback-Readback nur bei vollständig identischem Original zulassen.
   Hier gibt es KEINE physische RAM-Rückschreibfunktion.
6. `SV04NextDwinStatusContract.hpp`: vollständiger, deutsch benannter
   Status-/Fehler-Datenvertrag für eine spätere DWIN-Anzeige. Keine grüne
   100-%-Anzeige ohne passende aktuelle Laufnummer, gültige 16 Zellen,
   bestätigtes G29-RAM-Ergebnis und Sicherheitsbelege.
   Keine tatsächliche Displaygrafik oder VP-Anbindung.

Die alte `SV04NextCommandHandshake.hpp` wurde ausdrücklich als älteres
Host-Modell gekennzeichnet; die neue `OperationLedger` ist der maßgebliche
Zwei-Phasen-Entwurf.

## Neue Tests

`bash tests/run_all_local.sh`

Je `-O0`, `-O2` und UBSan erfolgreich:
- OperationLedger: 66.017 Assertions
- ThermalWitness: 89.428 Assertions
- HomingWitness: 12.002 Assertions
- MeshIntegrity: 31.104 Assertions
- DwinStatus: 262.177 Assertions (inkl. aller 65.536 4x4-Masken)
- End-to-End: 52.736 Assertions über 128 vollständige
  Heiz/G28/G29/RAM-Mesh-Anzeigeläufe plus 256 Fehlerläufe.

**513.464 neue Assertions je Konfiguration**; insgesamt 3 Durchläufe
(+ komplette ältere Testsuite). Diese sind HOST-Tests mit simulierten
Eingängen, keine echten BLTouch-/Motor-/Heizbett-/Displaymessungen.

## Nicht als fertig oder sicher ausgeben

- Die physische T1-Parklage ist **nicht nachgewiesen**. Die bisherigen
  Endschalterdiagnosen lesen lediglich elektrische Pegel/Flanken.
- Es existiert keine autorisierte native GCode-Heiz-, G28- oder G29-Automatik.
- `G29 U` ist der zuvor GitHub-kompilierte experimentelle Einzelfall mit
  eigenen Prüfungen; es gibt noch keine vollständig integrierte
  Ein-Knopf-Sequenz.
- Keine originale DWIN-HMI-Grafikdatei, keine neue Touchadresse, kein
  neues funktionierendes Touchmenü und keine Visualisierung auf echter Hardware.
- Keine automatische EEPROM-Speicherung (`M500`) oder freigegebene
  RAM-Rückschreibsequenz; Originaloffset derzeit -1,10 mm wird nicht verändert.
- **Nicht flashen**; weder Hardwaretest noch STM32-Integration dieser Module.

## Nächste sinnvolle Offline-Arbeit

1. Native Ereignisadapter mit echten Marlin-Run/Dispatch-IDs ausbauen,
   zunächst nur lesend und ohne HMI-Schaltfläche.
2. Physische T1-Parknachweise und Kollisionseinhüllung am Gerät klären.
3. DWIN-Datensatz und originales HMI-Projekt beschaffen, VP-Kollisionen prüfen.
4. Den von G29 U ausgegebenen 4x4-RAM-Mesh-Readback an die exakte
   Kandidaten-/Originalprüfung binden.
5. Erst nach ausreichend nativer Integration einen gemeinsamen GitHub-Build
   mit dem nächsten einfachen Workflow-Namen anfordern; **kein Upload jetzt**.
