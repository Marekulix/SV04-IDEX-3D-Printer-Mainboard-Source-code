// SV04 NEXT - two-phase command lifecycle model. HOST ONLY, NOT A MARLIN ACTUATOR.
// ACK merely means accepted. Only independently checked completion advances the FSM.
// Neither this module nor its callers may infer physical parking from a coordinate.
#pragma once
#include <stdint.h>
#include "SV04NextAuto60Policy.hpp"
#include "SV04NextAbortQuarantine.hpp"

namespace sv04next {
class OperationLedger final {
public:
  enum class Step : uint8_t { Heat60, HomeXYZ, ProbeG29U };
  enum class Phase : uint8_t { Empty, AwaitAcceptance, Executing, Completed, Locked };
  enum class Failure : uint8_t { None, BadRun, Order, Unsafe, Busy, StaleTicket,
    AcceptanceTimeout, ExecutionTimeout, CommandRejected, BadCompletion, Interrupted };
  struct Live {
    bool stopped=false, printing=false, paused=false;
    bool t0=true, auto_park=true, t1_physically_witnessed=false;
    bool heater_ok=true, bltouch_ok=true, offset_unchanged=true;
    bool planner_idle=true, queue_empty=true, probe_stowed=true;
    bool bed_60_stable=false, xyz_homed_after_command=false;
    bool native_g29_current_run_complete=false;
    bool target_is_60=false;
  };
  struct Ticket { uint32_t run=0, id=0; Step step=Step::Heat60;
    bool valid()const{return run!=0 && id!=0;}
  };
  static constexpr uint32_t AcceptanceMs=Auto60Policy::CommandAcceptMs;
  static constexpr uint32_t HeatMs=Auto60Policy::HeatTimeoutMs; // 12min, not 30sec
  static constexpr uint32_t HomeMs=Auto60Policy::HomeTimeoutMs;
  static constexpr uint32_t ProbeMs=Auto60Policy::ProbeTimeoutMs;
  bool issue(uint32_t run, Step step, uint32_t now, const Live &s, Ticket &t) {
    t=Ticket{};
    if(!run)return reject(Failure::BadRun);
    if(phase_==Phase::Locked)return false;
    if(phase_!=Phase::Empty)return reject(Failure::Busy);
    if(owner_ && owner_!=run)return reject(Failure::BadRun);
    if(next_!=static_cast<uint8_t>(step))return reject(Failure::Order);
    if(!baseline(s) || !s.planner_idle || !s.queue_empty || !s.probe_stowed)
      return reject(Failure::Unsafe);
    if(step==Step::HomeXYZ && !s.bed_60_stable)return reject(Failure::Unsafe);
    if(step==Step::ProbeG29U && (!s.bed_60_stable || !s.xyz_homed_after_command))
      return reject(Failure::Unsafe);
    owner_=run;
    if(++serial_==0)++serial_;
    ticket_.run=run;ticket_.id=serial_;ticket_.step=step;
    started_=now;accepted_=0;phase_=Phase::AwaitAcceptance;error_=Failure::None;
    t=ticket_;return true;
  }
  bool accepted(const Ticket &t, uint32_t now, bool native_accepted, const Live &s) {
    if(!matches(t) || phase_!=Phase::AwaitAcceptance)return reject(Failure::StaleTicket);
    if(age(now,started_)>AcceptanceMs)return lock(Failure::AcceptanceTimeout);
    if(!native_accepted)return lock(Failure::CommandRejected);
    if(!baseline(s))return lock(Failure::Unsafe);
    if(t.step==Step::Heat60 && !s.target_is_60)return lock(Failure::Unsafe);
    // Command accepted does NOT mean bed is hot, axes are homed or G29 succeeded.
    accepted_=now;phase_=Phase::Executing;return true;
  }
  bool finished(const Ticket &t,uint32_t now,bool native_completed,const Live &s) {
    if(!matches(t) || phase_!=Phase::Executing)return reject(Failure::StaleTicket);
    if(age(now,started_)>duration(t.step))return lock(Failure::ExecutionTimeout);
    if(!native_completed || !baseline(s))return lock(Failure::BadCompletion);
    if(!s.planner_idle || !s.queue_empty || !s.probe_stowed)
      return lock(Failure::BadCompletion);
    switch(t.step){
      case Step::Heat60:
        if(!s.bed_60_stable || !s.target_is_60)return lock(Failure::BadCompletion);
        break;
      case Step::HomeXYZ:
        if(!s.xyz_homed_after_command || !s.bed_60_stable)return lock(Failure::BadCompletion);
        break;
      case Step::ProbeG29U:
        if(!s.native_g29_current_run_complete || !s.bed_60_stable || !s.xyz_homed_after_command)
          return lock(Failure::BadCompletion);
        break;
    }
    phase_=Phase::Completed;return true;
  }
  bool consume(const Ticket &t) {
    if(!matches(t) || phase_!=Phase::Completed)return false;
    ++next_;phase_=Phase::Empty;ticket_=Ticket{};
    return true;
  }
  bool poll(uint32_t now,const Live &s) {
    if(phase_!=Phase::AwaitAcceptance && phase_!=Phase::Executing)return phase_!=Phase::Locked;
    if(!baseline(s))return lock(Failure::Interrupted);
    if(phase_==Phase::Executing &&
       ((ticket_.step==Step::Heat60 && !s.target_is_60) ||
        (ticket_.step!=Step::Heat60 && !s.bed_60_stable)))
      return lock(Failure::Interrupted);
    if(phase_==Phase::AwaitAcceptance && age(now,started_)>AcceptanceMs)
      return lock(Failure::AcceptanceTimeout);
    if(phase_==Phase::Executing && age(now,started_)>duration(ticket_.step))
      return lock(Failure::ExecutionTimeout);
    return true;
  }
  void abort(){lock(Failure::Interrupted);}
  // A plain idle/queue check must NEVER restart a cancelled or faulted run.
  // Legacy callers are intentionally blocked. A signed-off, manual recovery
  // procedure must first pass AbortQuarantine and create a new run number.
  bool restart(uint32_t, const Live &){ return false; }
  bool restart_supervised(uint32_t newrun,const Live &s,const AbortQuarantine &q){
    if(!newrun || newrun==owner_ || phase_!=Phase::Locked ||
       !q.recovery_recorded() || q.token().run!=owner_ ||
       !baseline(s) || !s.planner_idle || !s.queue_empty || !s.probe_stowed)return false;
    owner_=newrun;next_=0;ticket_=Ticket{};phase_=Phase::Empty;error_=Failure::None;
    return true;
  }
  Phase phase()const{return phase_;}
  Failure failure()const{return error_;}
  uint8_t completed_steps()const{return next_;}
  bool finished_ram_only()const{return next_==3 && phase_==Phase::Empty;}
  Ticket pending()const{return phase_==Phase::AwaitAcceptance || phase_==Phase::Executing ? ticket_ : Ticket{};}
  bool permits_heater()const{return false;}
  bool permits_motor()const{return false;}
  bool permits_eeprom()const{return false;}
private:
  static uint32_t age(uint32_t now,uint32_t start){return (uint32_t)(now-start);}
  static uint32_t duration(Step s){return s==Step::HomeXYZ?HomeMs:s==Step::Heat60?HeatMs:ProbeMs;}
  static bool baseline(const Live &s){return !s.stopped && !s.printing && !s.paused &&
    s.t0 && s.auto_park && s.t1_physically_witnessed && s.heater_ok && s.bltouch_ok && s.offset_unchanged;}
  bool matches(const Ticket &t)const{return t.valid() && ticket_.valid() && t.run==ticket_.run && t.id==ticket_.id && t.step==ticket_.step;}
  bool reject(Failure f){if(phase_==Phase::Empty)error_=f;return false;}
  bool lock(Failure f){phase_=Phase::Locked;error_=f;ticket_=Ticket{};return false;}
  uint32_t owner_=0,serial_=0,started_=0,accepted_=0;
  uint8_t next_=0;
  Phase phase_=Phase::Empty;
  Failure error_=Failure::None;
  Ticket ticket_{};
};
} // namespace sv04next
