// SV04 NEXT: bind a native G29 U receipt to exactly one expected transaction.
// Prevents a stale 16/16 result from satisfying a later Auto60 run.
// A completed G29 U result is still RAM-ONLY; never authorizes M500.
#pragma once
#include "SV04NextG29UReceipt.hpp"
#include <stdint.h>
#include <math.h>

namespace sv04next {
class ReceiptBinder final {
public:
  enum class Phase : uint8_t { Empty, AwaitingStart, Observing, FinishedRam, Rejected };
  enum class Error : uint8_t { None, BadRun, LateStart, ChangedSequence, Regressed,
    BadValue, G29Failure, Incomplete, UnsafeRuntime, WrongOffset };
  struct Live {
    bool print_active=false, stopped=false, t1_witness=false;
    bool offset_unchanged=true, probe_stowed=false, bed_stable_60=false;
  };
  bool prepare(uint32_t run, uint32_t prior_seq) {
    if(phase_!=Phase::Empty || !run)return false;
    run_=run; prior_=prior_seq; native_seq_=0;
    count_=0;mask_=0;phase_=Phase::AwaitingStart;error_=Error::None;
    for(uint8_t i=0;i<16;++i)values_[i]=NAN;
    return true;
  }
  bool observe(uint32_t run,const G29UReceipt &r,const Live &s) {
    if(run!=run_ || !run || phase_==Phase::Empty || phase_==Phase::Rejected)
      return reject(Error::BadRun);
    if(s.print_active || s.stopped || !s.t1_witness || !s.bed_stable_60)
      return reject(Error::UnsafeRuntime);
    if(!s.offset_unchanged)return reject(Error::WrongOffset);
    if(phase_==Phase::AwaitingStart){
      // A receipt already terminal on the first observation is NOT trusted.
      if(r.phase()!=G29UReceipt::Phase::Running || !r.sequence() || r.sequence()==prior_ ||
         r.completed()>0 || r.point_mask()!=0)return reject(Error::LateStart);
      native_seq_=r.sequence();phase_=Phase::Observing;
    }
    if(r.sequence()!=native_seq_)return reject(Error::ChangedSequence);
    if(phase_==Phase::FinishedRam && r.phase()!=G29UReceipt::Phase::RamOnlySuccess)
      return reject(Error::G29Failure);
    if(r.phase()==G29UReceipt::Phase::Refused || r.phase()==G29UReceipt::Phase::Failed)
      return reject(Error::G29Failure);
    if(r.phase()!=G29UReceipt::Phase::Running && r.phase()!=G29UReceipt::Phase::RamOnlySuccess)
      return reject(Error::G29Failure);
    if(r.completed()<count_ || (r.point_mask() & mask_)!=mask_ ||
       r.completed()>16 || bitcount(r.point_mask())!=r.completed())
      return reject(Error::Regressed);
    for(uint8_t i=0;i<16;++i){
      const bool present=(r.point_mask() & (uint16_t)(1u<<i))!=0;
      if(present && (!isfinite(r.value(i)) || fabsf(r.value(i))>3.f ||
        r.pixel(i)!=G29UReceipt::Pixel::Recorded))return reject(Error::BadValue);
      if(present && (mask_ & (uint16_t)(1u<<i)) && r.value(i)!=values_[i])
        return reject(Error::Regressed);
      if(present)values_[i]=r.value(i);
    }
    count_=r.completed();mask_=r.point_mask();
    if(r.phase()==G29UReceipt::Phase::RamOnlySuccess){
      if(count_!=16 || mask_!=0xFFFFu || !s.probe_stowed)return reject(Error::Incomplete);
      phase_=Phase::FinishedRam;
    }
    return true;
  }
  void revoke(){phase_=Phase::Rejected;error_=Error::UnsafeRuntime;}
  Phase phase()const{return phase_;}
  Error error()const{return error_;}
  uint8_t points()const{return count_;}
  uint32_t native_sequence()const{return native_seq_;}
  bool ram_complete()const{return phase_==Phase::FinishedRam && count_==16 && mask_==0xFFFFu;}
  bool eeprom_authorized()const{return false;}
  bool physical_motion_authorized()const{return false;}
private:
  static uint8_t bitcount(uint16_t n){uint8_t c=0;while(n){c+=(uint8_t)(n&1u);n>>=1;}return c;}
  bool reject(Error e){if(phase_!=Phase::Rejected){phase_=Phase::Rejected;error_=e;}return false;}
  uint32_t run_=0,prior_=0,native_seq_=0;
  float values_[16]={};
  uint16_t mask_=0;
  uint8_t count_=0;
  Phase phase_=Phase::Empty;
  Error error_=Error::None;
};
} // namespace sv04next
