// SV04 NEXT - exact RAM mesh snapshot / rollback verification contract.
// NO EEPROM WRITES, NO G29 commands, NO real RAM restore operation here.
#pragma once
#include <stdint.h>
#include <math.h>
#include <string.h>
namespace sv04next {
class MeshIntegrity final {
public:
  struct Mesh {
    float z[16]{};
    float origin_x=0.f,origin_y=0.f,pitch_x=0.f,pitch_y=0.f;
    float z_offset=0.f;
    bool leveling_enabled=false;
  };
  enum class Stage : uint8_t { Empty, OriginalSaved, CandidateChecked, RollbackChecked, Failed };
  static bool geometrically_plausible(const Mesh &m){
    if(!isfinite(m.origin_x)||!isfinite(m.origin_y)||!isfinite(m.pitch_x)||!isfinite(m.pitch_y)||
      !isfinite(m.z_offset)||m.origin_x<0.f||m.origin_y<0.f||m.pitch_x<=0.f||m.pitch_y<=0.f||
      m.origin_x+3.f*m.pitch_x>302.5f || m.origin_y+3.f*m.pitch_y>302.5f || fabsf(m.z_offset)>10.f)
      return false;
    for(uint8_t i=0;i<16;++i)if(!isfinite(m.z[i])||fabsf(m.z[i])>3.f)return false;
    return true;
  }
  bool capture(uint32_t run,const Mesh &original){
    if(!run || stage_!=Stage::Empty || !geometrically_plausible(original))return false;
    original_=original;run_=run;fingerprint_=hash(original);stage_=Stage::OriginalSaved;return true;
  }
  bool check_candidate(uint32_t run,const Mesh &candidate){
    if(run!=run_||stage_!=Stage::OriginalSaved||!geometrically_plausible(candidate))return fail();
    if(!same_geometry(candidate,original_) || !same_bits(candidate.z_offset,original_.z_offset))return fail();
    candidate_=candidate;stage_=Stage::CandidateChecked;return true;
  }
  bool check_restored(uint32_t run,const Mesh &readback){
    if(run!=run_||run==0||stage_!=Stage::CandidateChecked)return fail();
    if(hash(readback)!=fingerprint_ || !exact(readback,original_))return fail();
    stage_=Stage::RollbackChecked;return true;
  }
  bool original(uint32_t run,Mesh &out)const{
    if(run!=run_ || run==0 || stage_==Stage::Empty)return false;
    out=original_;return true;
  }
  bool rollback_verified()const{return stage_==Stage::RollbackChecked;}
  bool stage_ram_candidate_only()const{return stage_==Stage::CandidateChecked;}
  Stage stage()const{return stage_;}
  uint32_t original_fingerprint()const{return fingerprint_;}
  bool enables_eeprom()const{return false;}
  bool changes_native_ram()const{return false;}
private:
  static bool same_bits(float a,float b){return memcmp(&a,&b,sizeof(float))==0;}
  static bool exact(const Mesh&a,const Mesh&b){
    for(uint8_t i=0;i<16;++i)if(!same_bits(a.z[i],b.z[i]))return false;
    return same_geometry(a,b) && same_bits(a.z_offset,b.z_offset) && a.leveling_enabled==b.leveling_enabled;
  }
  static bool same_geometry(const Mesh&a,const Mesh&b){return same_bits(a.origin_x,b.origin_x)&&
    same_bits(a.origin_y,b.origin_y)&&same_bits(a.pitch_x,b.pitch_x)&&same_bits(a.pitch_y,b.pitch_y);}
  static uint32_t hash(const Mesh &m){
    uint32_t value=2166136261u;
    const float* fields[21] = {&m.z[0],&m.z[1],&m.z[2],&m.z[3],&m.z[4],&m.z[5],
      &m.z[6],&m.z[7],&m.z[8],&m.z[9],&m.z[10],&m.z[11],&m.z[12],&m.z[13],
      &m.z[14],&m.z[15],&m.origin_x,&m.origin_y,&m.pitch_x,&m.pitch_y,&m.z_offset};
    for(uint8_t i=0;i<21;++i){
      uint32_t bits=0;memcpy(&bits,fields[i],sizeof(bits));
      for(uint8_t j=0;j<4;++j){value^=(uint8_t)(bits>>(j*8));value*=16777619u;}
    }
    value ^= m.leveling_enabled?1u:0u;value*=16777619u;
    return value;
  }
  bool fail(){stage_=Stage::Failed;return false;}
  Mesh original_{},candidate_{};
  uint32_t run_=0,fingerprint_=0;
  Stage stage_=Stage::Empty;
};
}
