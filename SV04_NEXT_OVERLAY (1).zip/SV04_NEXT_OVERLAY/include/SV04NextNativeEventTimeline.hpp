// SV04 NEXT - native passive event timeline. EXPERIMENTAL; NO ACTUATION.
// Correlates Marlin's current read-only G29 U receipt with sampled uptime and
// the X_MAX electrical signal. Does NOT prove safe parking or grant permissions.
#pragma once
#include <stdint.h>
#include "SV04NextNativeReadiness.hpp"
#include "SV04NextT1EndstopObserver.hpp"

namespace sv04next {
class NativeEventTimeline final {
public:
  static constexpr uint32_t MaxGapMs=3000u;
  enum class Quality : uint8_t { Never, Fresh, SourceMissing, Gap, ClockBackwards, CorruptReceipt };
  enum class Event : uint8_t { None, NewRun, PointAdvanced, RamOnlyComplete, RunRefused,
                               RunFailed, Invalidated };
  struct Frame {
    Quality quality=Quality::Never;
    Event event=Event::None;
    uint32_t observed_ms=0, run=0, observations=0, electrical_edges=0;
    uint16_t mask=0;
    uint8_t count=0;
    bool receipt_16_ram=false, electrical_press_seen=false;
    bool physical_t1_proven=false, automatic_sequence_allowed=false,
         eeprom_allowed=false, hardware_approved=false;
  };

  // NativeReadiness::View is produced exclusively from real Marlin state;
  // this collector does NOT accept simulated operator acknowledgements.
  // A broken sampling chain or malformed receipt latches invalid until the
  // firmware reports a genuinely NEW G29 U sequence.
  void observe(uint32_t now,const NativeReadiness::View &v,const T1EndstopObserver &sensor){
    frame_.event=Event::None;
    if(!v.observed){ invalidate(Quality::SourceMissing);return; }
    if(seen_){
      const uint32_t delta=(uint32_t)(now-last_ms_);
      if(delta>0x7FFFFFFFu){invalidate(Quality::ClockBackwards);seen_=false;return;}
      if(delta>MaxGapMs)invalidate(Quality::Gap);
    }
    last_ms_=now;seen_=true;
    frame_.observed_ms=now;
    if(frame_.observations!=0xFFFFFFFFu)++frame_.observations;
    frame_.electrical_edges=sensor.edge_epochs();
    frame_.electrical_press_seen=sensor.electrical_edge_observed(now);
    // No physical parking claim can be derived from this electrical contact.
    frame_.physical_t1_proven=false;
    frame_.automatic_sequence_allowed=false;
    frame_.eeprom_allowed=false;
    frame_.hardware_approved=false;

    const uint32_t seq=v.g29_run_id;
    if(seq==0){
      // Sequence 0 after an active run implies reboot, reset, or lost source.
      // Even a previously complete 16/16 result must become invalid.
      if(have_seq_){invalidate(Quality::SourceMissing);return;}
      if(v.receipt_phase!=G29UReceipt::Phase::Never || v.measured || v.valid_mask)
        invalidate(Quality::CorruptReceipt);
      else if(frame_.quality==Quality::Never)frame_.quality=Quality::Fresh;
      return;
    }
    if(have_seq_ && seq!=last_seq_){
      // The native receipt counter normally advances, never goes backward.
      // A reset/reboot invalidates a prior successful result.
      const uint32_t delta=(uint32_t)(seq-last_seq_);
      if(delta==0 || delta>0x7FFFFFFFu){invalidate(Quality::CorruptReceipt);return;}
    }
    const bool new_run=!have_seq_ || seq!=last_seq_;
    if(new_run){
      have_seq_=true;last_seq_=seq;last_mask_=0;last_count_=0;
      last_phase_=G29UReceipt::Phase::Never;completion_announced_=false;
      frame_.quality=Quality::Fresh;frame_.event=Event::NewRun;
      frame_.receipt_16_ram=false;
    }
    frame_.run=seq;
    frame_.mask=v.valid_mask;
    frame_.count=v.measured;
    if(frame_.quality!=Quality::Fresh)return; // quarantine original root cause
    const uint8_t bits=popcount(v.valid_mask);
    if(v.measured>16 || bits!=v.measured ||
       (!new_run && terminal(last_phase_) && v.receipt_phase!=last_phase_) ||
       (!new_run && last_phase_!=G29UReceipt::Phase::Never &&
        v.receipt_phase==G29UReceipt::Phase::Never) ||
       (v.receipt_phase==G29UReceipt::Phase::Never && (v.measured || v.valid_mask)) ||
       (v.receipt_phase==G29UReceipt::Phase::RamOnlySuccess &&
         (v.measured!=16 || v.valid_mask!=0xFFFFu || !v.ram_mesh_16_of_16)) ||
       ((v.receipt_phase==G29UReceipt::Phase::Running ||
         v.receipt_phase==G29UReceipt::Phase::RamOnlySuccess) &&
        ((v.valid_mask & last_mask_)!=last_mask_ || v.measured<last_count_))){
      invalidate(Quality::CorruptReceipt);return;
    }
    if(frame_.quality!=Quality::Fresh)return; // old evidence never revives
    if(v.receipt_phase==G29UReceipt::Phase::Running && v.measured>last_count_)
      frame_.event=Event::PointAdvanced;
    if(v.receipt_phase==G29UReceipt::Phase::RamOnlySuccess){
      frame_.receipt_16_ram=true;
      if(new_run || !completion_announced_)frame_.event=Event::RamOnlyComplete;
      completion_announced_=true;
    }
    if(v.receipt_phase==G29UReceipt::Phase::Failed){
      frame_.receipt_16_ram=false;
      if(last_phase_!=G29UReceipt::Phase::Failed)frame_.event=Event::RunFailed;
    }
    if(v.receipt_phase==G29UReceipt::Phase::Refused){
      frame_.receipt_16_ram=false;
      if(last_phase_!=G29UReceipt::Phase::Refused)frame_.event=Event::RunRefused;
    }
    last_mask_=v.valid_mask;last_count_=v.measured;last_phase_=v.receipt_phase;
    if(new_run)completion_announced_=v.receipt_phase==G29UReceipt::Phase::RamOnlySuccess;
  }
  const Frame &view()const{return frame_;}
  bool allows_motion()const{return false;}
  bool allows_heating()const{return false;}
  bool allows_eeprom()const{return false;}
private:
  static bool terminal(G29UReceipt::Phase p){return p==G29UReceipt::Phase::RamOnlySuccess ||
      p==G29UReceipt::Phase::Refused || p==G29UReceipt::Phase::Failed;}
  static uint8_t popcount(uint16_t n){
    uint8_t c=0;while(n){c=(uint8_t)(c+(n&1u));n=(uint16_t)(n>>1);}return c;
  }
  void invalidate(Quality q){
    frame_.quality=q;frame_.event=Event::Invalidated;
    frame_.receipt_16_ram=false;
  }
  Frame frame_{};
  uint32_t last_ms_=0,last_seq_=0;
  uint16_t last_mask_=0;
  uint8_t last_count_=0;
  G29UReceipt::Phase last_phase_=G29UReceipt::Phase::Never;
  bool seen_=false,have_seq_=false,completion_announced_=false;
};
extern NativeEventTimeline native_event_timeline;
} // namespace sv04next
