// SV04 NEXT - read-only continuous heater witness. HOST MODEL, NO M190 COMMAND.
// Validates a 60 C hold via repeated live samples; no cached/old success.
#pragma once
#include <stdint.h>
#include <math.h>
#include "SV04NextAuto60Policy.hpp"
namespace sv04next {
class ThermalWitness final {
public:
  enum class Phase : uint8_t { Idle, Heating, Stabilizing, Ready, Fault };
  enum class Error : uint8_t { None, BadRun, NoSample, BadSensor, TargetChanged,
    SampleGap, TooHot, HeatTimeout, Interrupted };
  static constexpr uint32_t HoldMs=Auto60Policy::TemperatureHoldMs;
  static constexpr uint32_t GapMs=Auto60Policy::SensorGapMs;
  static constexpr uint32_t MaxHeatMs=Auto60Policy::HeatTimeoutMs;
  struct Reading { bool valid=true, stopped=false, printing=false, heater_ok=true;
    float actual=25.f,target=60.f; };
  bool begin(uint32_t run,uint32_t now,const Reading &r) {
    if(!run || phase_!=Phase::Idle)return false;
    if(!good(r))return false;
    run_=run;begin_=last_=now;phase_=Phase::Heating;error_=Error::None;
    sampled_=true;return true;
  }
  bool observe(uint32_t run,uint32_t now,const Reading&r){
    if(run!=run_ || !run || phase_==Phase::Idle || phase_==Phase::Fault)return false;
    if(!sampled_)return fault(Error::NoSample);
    if((uint32_t)(now-last_)>GapMs)return fault(Error::SampleGap);
    if((uint32_t)(now-begin_)>MaxHeatMs)return fault(Error::HeatTimeout);
    if(!r.valid || !isfinite(r.actual) || !isfinite(r.target) || r.actual<0.f || r.actual>115.f)
      return fault(Error::BadSensor);
    if(r.stopped || r.printing || !r.heater_ok)return fault(Error::Interrupted);
    if(fabsf(r.target-60.f)>0.1f)return fault(Error::TargetChanged);
    if(r.actual>65.f)return fault(Error::TooHot);
    last_=now;
    if(fabsf(r.actual-60.f)<=1.0f){
      if(phase_==Phase::Heating){hold_=now;phase_=Phase::Stabilizing;}
      else if(phase_==Phase::Stabilizing && (uint32_t)(now-hold_)>=HoldMs)phase_=Phase::Ready;
    }else if(phase_==Phase::Stabilizing || phase_==Phase::Ready){
      // A finished hold can be lost; never reuse a previous green result.
      phase_=Phase::Heating;
    }
    return true;
  }
  bool ready(uint32_t run,uint32_t now)const{return run==run_ && phase_==Phase::Ready &&
    (uint32_t)(now-last_)<=GapMs;}
  void cancel(){fault(Error::Interrupted);}
  Phase phase()const{return phase_;}Error error()const{return error_;}
  bool issues_gcode()const{return false;}
  bool approves_eeprom()const{return false;}
private:
  static bool good(const Reading&r){return r.valid && !r.stopped && !r.printing && r.heater_ok &&
    isfinite(r.actual) && r.actual>=0.f && r.actual<=65.f && isfinite(r.target) && fabsf(r.target-60.f)<=0.1f;}
  bool fault(Error e){phase_=Phase::Fault;error_=e;return false;}
  uint32_t run_=0,begin_=0,last_=0,hold_=0;
  bool sampled_=false;
  Phase phase_=Phase::Idle;Error error_=Error::None;
};
}
