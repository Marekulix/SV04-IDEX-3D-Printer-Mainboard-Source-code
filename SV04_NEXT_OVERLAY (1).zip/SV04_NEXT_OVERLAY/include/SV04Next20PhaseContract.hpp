// SV04 NEXT: 10.53–10.72 unified verification contract.
// Host side design and verification only: NEVER commands motors/heater/EEPROM.
// All physical prerequisites must be supplied by an independently reviewed
// Marlin adapter; values synthesized from an unhomed planner are NOT proof.
#pragma once
#include <stdint.h>
#include <math.h>
#include <string.h>

namespace sv04next {

struct MachineFacts {
  bool stopped=false, printing=false, paused=false, motion=false, queue=false;
  bool t0=true, x2_homed=false, x2_physically_parked=false, auto_park=false;
  bool probe_ok=true, probe_stowed=true, heater_ok=true, xyz_homed=false;
  bool abort_request=false, thermal_fault=false;
  float bed=25.f, bed_target=0.f, z_offset=-1.10f;
};

class TwentyPhaseContract final {
public:
  static constexpr unsigned Points=16;
  enum class State:uint8_t {Idle, Heat, Home, Probe, Validated, Cancelled, Failed};
  enum class Error:uint8_t {None, Unsafe, Busy, Park, Probe, Temperature, HeatingTimeout, Homing,
    Order, Sample, Spread, Offset, UserCancel, Incomplete, Mesh, Changed};
  enum class Command:uint8_t {None, RequestHeat60, RequestG28, RequestG29U, RestoreRam};
  enum class Color:uint8_t {Untested, Accepted, Disagreement, Invalid};
  struct Original {
    float z[Points];float offset, origin_x, origin_y, step_x, step_y;
    bool enabled;
  };
  struct Display {
    uint8_t completed=0;
    uint8_t phase=0;
    uint8_t fault=0;
    uint16_t bed10=0;
    uint16_t target10=0;
    Color colors[Points]{};
  };

  bool capture(const Original& old) {
    if (state_!=State::Idle || !isfinite(old.offset) || !isfinite(old.origin_x) ||
        !isfinite(old.origin_y) || !isfinite(old.step_x) || !isfinite(old.step_y) ||
        old.step_x<=0.f || old.step_y<=0.f) return reject(Error::Mesh);
    memcpy(&original_,&old,sizeof(old)); stored_=true; return true;
  }
  Command begin(uint32_t ms,const MachineFacts& v) {
    if (!stored_ || state_!=State::Idle) return Command::None;
    if(!safe(v,true) || !v.probe_stowed) {reject(why(v));return Command::None;}
    if(!isfinite(v.bed) || v.bed < 0.f || v.bed > 115.f || !isfinite(v.bed_target)) {reject(Error::Temperature);return Command::None;}
    if (!isfinite(v.z_offset) || fabsf(v.z_offset-original_.offset)>.00001f)
      {reject(Error::Offset);return Command::None;}
    start_=ms; since_=ms; stable_=false; target_seen_=false; count_=0;
    for(unsigned i=0;i<Points;++i){mesh_[i]=NAN; display_.colors[i]=Color::Untested;}
    state_=State::Heat;
    return Command::RequestHeat60;
  }
  Command update(uint32_t ms, const MachineFacts& v) {
    display_.phase=static_cast<uint8_t>(state_);
    display_.fault=static_cast<uint8_t>(error_);
    if(isfinite(v.bed)&&v.bed>=0&&v.bed<1000)display_.bed10=static_cast<uint16_t>(v.bed*10.f+.5f);
    if(isfinite(v.bed_target)&&v.bed_target>=0&&v.bed_target<1000)display_.target10=static_cast<uint16_t>(v.bed_target*10.f+.5f);
    if (!active()) return Command::None;
    if(v.abort_request){reject(Error::UserCancel);state_=State::Cancelled;return Command::RestoreRam;}
    if (!safe(v,false)){reject(why(v));return Command::RestoreRam;}
    if(!isfinite(v.z_offset)||fabsf(v.z_offset-original_.offset)>.00001f)
      {reject(Error::Offset);return Command::RestoreRam;}
    if(!isfinite(v.bed)||!isfinite(v.bed_target)||v.bed<0.f||v.bed>115.f)
      {reject(Error::Temperature);return Command::RestoreRam;}
    if(state_==State::Heat){
      if((uint32_t)(ms-start_)>720000u){reject(Error::HeatingTimeout);return Command::RestoreRam;}
      if(fabsf(v.bed_target-60.f)>.01f){
        if(target_seen_){reject(Error::Changed);return Command::RestoreRam;}
        stable_=false;return Command::None;
      }
      target_seen_=true;
      if(fabsf(v.bed-60.f)<=1.f){
        if(!stable_){stable_=true;since_=ms;}
        if((uint32_t)(ms-since_)>=20000u){
          if(v.queue||v.motion||!v.probe_stowed){reject(Error::Busy);return Command::RestoreRam;}
          state_=State::Home;return Command::RequestG28;
        }
      } else stable_=false;
    }
    else if(fabsf(v.bed-60.f)>1.f || fabsf(v.bed_target-60.f)>.01f)
      {reject(Error::Temperature);return Command::RestoreRam;}
    return Command::None;
  }
  Command homed(const MachineFacts& v) {
    if(state_!=State::Home)return Command::None;
    if(!safe(v,true)||!v.xyz_homed){reject(Error::Homing);return Command::RestoreRam;}
    if(!v.probe_stowed){reject(Error::Probe);return Command::RestoreRam;}
    if(!isfinite(v.z_offset)||fabsf(v.z_offset-original_.offset)>.00001f){reject(Error::Offset);return Command::RestoreRam;}
    if(!isfinite(v.bed)||fabsf(v.bed-60.f)>1.f||fabsf(v.bed_target-60.f)>.01f)
      {reject(Error::Temperature);return Command::RestoreRam;}
    state_=State::Probe;return Command::RequestG29U;
  }
  bool measure(uint8_t index,float first,float second,const MachineFacts& v) {
    if(state_!=State::Probe)return false;
    if(v.abort_request){reject(Error::UserCancel);state_=State::Cancelled;return false;}
    if(!safe(v,false)){reject(why(v));return false;}
    if(!isfinite(v.bed)||fabsf(v.bed-60.f)>1.f||fabsf(v.bed_target-60.f)>.01f)
      return reject(Error::Temperature);
    if(!isfinite(v.z_offset)||fabsf(v.z_offset-original_.offset)>.00001f)return reject(Error::Offset);
    if(index!=count_||index>=Points)return reject(Error::Order);
    if(!isfinite(first)||!isfinite(second)||fabsf(first)>3.f||fabsf(second)>3.f){
      display_.colors[count_]=Color::Invalid;return reject(Error::Sample);
    }
    if(fabsf(first-second)>.06f){
      display_.colors[count_]=Color::Disagreement;return reject(Error::Spread);
    }
    mesh_[count_]=(2.f*first+3.f*second)*.2f;
    display_.colors[count_]=Color::Accepted;
    ++count_;display_.completed=count_;
    return true;
  }
  bool finish(const float *result,const MachineFacts& v,bool g29_ok,bool probe_parked) {
    if(state_!=State::Probe)return false;
    if(!g29_ok||!probe_parked||!v.xyz_homed||!safe(v,true))return reject(Error::Probe);
    if(count_!=Points||!result)return reject(Error::Incomplete);
    if(!isfinite(v.bed)||fabsf(v.bed-60.f)>1.f||fabsf(v.bed_target-60.f)>.01f)return reject(Error::Temperature);
    if(!isfinite(v.z_offset)||fabsf(v.z_offset-original_.offset)>.00001f)return reject(Error::Offset);
    for(unsigned i=0;i<Points;++i)
      if(!isfinite(result[i])||fabsf(result[i]-mesh_[i])>.0001f)return reject(Error::Mesh);
    state_=State::Validated;
    return true;
  }
  bool restore(Original& destination) const {
    if(!stored_ || state_==State::Validated)return false;
    memcpy(&destination,&original_,sizeof(original_));return true;
  }
  // EEPROM: No unsupervised M500 or writes. Separate physical EEPROM backup,
  // readback and rollback tests are mandatory before enabling any adapter.
  bool allow_eeprom_write() const {return false;}
  bool verify_readback(const float *actual,float saved_offset) const {
    if(state_!=State::Validated || !actual || !isfinite(saved_offset) ||
       fabsf(saved_offset-original_.offset)>.00001f)return false;
    for(unsigned i=0;i<Points;++i)
      if(!isfinite(actual[i])||fabsf(actual[i]-mesh_[i])>.0001f)return false;
    return true;
  }
  bool cancel() {if(!active())return false;reject(Error::UserCancel);state_=State::Cancelled;return true;}
  bool active() const {return state_==State::Heat||state_==State::Home||state_==State::Probe;}
  State state() const{return state_;} Error error() const{return error_;}
  unsigned completed() const{return count_;} const Display& display() const{return display_;}
  float candidate(uint8_t i)const{return i<Points?mesh_[i]:NAN;}
private:
  bool safe(const MachineFacts& v,bool stationary) const {
    return !v.stopped&&!v.printing&&!v.paused&&!v.thermal_fault&&v.heater_ok&&v.probe_ok&&v.t0&&
       v.x2_homed&&v.x2_physically_parked&&v.auto_park&&
       (!stationary||(!v.queue&&!v.motion));
  }
  Error why(const MachineFacts& v)const{
    if(v.stopped||v.thermal_fault||!v.heater_ok)return Error::Unsafe;
    if(v.printing||v.paused||v.motion||v.queue)return Error::Busy;
    if(!v.t0||!v.x2_homed||!v.x2_physically_parked||!v.auto_park)return Error::Park;
    return Error::Probe;
  }
  bool reject(Error e){error_=e;state_=State::Failed;display_.phase=static_cast<uint8_t>(state_);display_.fault=static_cast<uint8_t>(e);return false;}
  State state_=State::Idle;Error error_=Error::None;
  Original original_{};bool stored_=false,target_seen_=false,stable_=false;
  uint32_t start_=0,since_=0; uint8_t count_=0;
  float mesh_[Points]{};Display display_{};
};
} // namespace sv04next
