// SV04 NEXT 7: 4x4 probe value snapshot for a FUTURE display adapter.
// RAM ONLY. These are raw probe heights, NOT automatically saved bed corrections.
// No DWIN VP, no serial output, no motors, heater, EEPROM or G-code commands.
#pragma once
#include <stdint.h>
#include <math.h>
#include "SV04NextNativeStatusPacket.hpp"
#include "SV04NextSafeFloat.hpp"

namespace sv04next {
class MeshMapPacket final {
public:
  static constexpr uint8_t Size=48u;
  static constexpr uint8_t Version=1u;
  static constexpr int16_t Missing=(-32767-1);
  enum class MapState:uint8_t { Empty=0, InProgress=1, RamComplete=2, Invalid=3 };
  void capture(const G29UReceipt &r,const NativeEventTimeline::Frame &timeline,
               const NativeStatusPacket &status){
    for(uint8_t i=0;i<Size;++i)data_[i]=0;
    data_[0]='S';data_[1]='M';data_[2]=Version;data_[3]=Size;
    put32(4,r.sequence());
    put16(8,r.point_mask());
    data_[10]=r.completed();
    data_[11]=(uint8_t)r.phase();
    state_=MapState::Invalid;
    for(uint8_t i=0;i<16;++i)put16((uint8_t)(12+2*i),(uint16_t)Missing);
    if(r.sequence()==0 && r.phase()==G29UReceipt::Phase::Never &&
       status.display()==NativeStatusPacket::Display::Idle)
      state_=MapState::Empty;
    else if(r.sequence()!=0 && r.sequence()==timeline.run &&
            r.point_mask()==timeline.mask && r.completed()==timeline.count &&
            NativeStatusPacket::verify(status.bytes(),NativeStatusPacket::Size) &&
            (status.display()==NativeStatusPacket::Display::Measuring ||
             status.display()==NativeStatusPacket::Display::RamComplete)){
      bool valid=true;
      uint8_t found=0;
      for(uint8_t i=0;i<16;++i){
        const uint16_t bit=(uint16_t)(1u<<i);
        if(!(r.point_mask()&bit)) {
          if(r.pixel(i)!=G29UReceipt::Pixel::Empty) valid=false;
          continue;
        }
        const float z=r.value(i);
        if(r.pixel(i)!=G29UReceipt::Pixel::Recorded ||
           !float_is_finite(z) || z< -10.0f || z>10.0f){valid=false;continue;}
        const float um=z*1000.0f;
        // The native probe record is a float in mm. Round to integer um.
        const int32_t rounded=(int32_t)(um>=0.f?um+0.5f:um-0.5f);
        if(rounded< -10000 || rounded>10000){valid=false;continue;}
        put16((uint8_t)(12+2*i),(uint16_t)(int16_t)rounded);
        ++found;
      }
      if(valid && found==r.completed() &&
         status.display()==NativeStatusPacket::Display::RamComplete &&
         r.phase()==G29UReceipt::Phase::RamOnlySuccess &&
         found==16 && r.point_mask()==0xFFFFu)
        state_=MapState::RamComplete;
      else if(valid && status.display()==NativeStatusPacket::Display::Measuring &&
              r.phase()==G29UReceipt::Phase::Running)
        state_=MapState::InProgress;
    }
    // Byte 44 is informational status only, not any permission to persist.
    data_[44]=(uint8_t)state_; data_[45]=0;
    put16(46,NativeStatusPacket::crc16(data_,46));
  }
  MapState state()const{return state_;}
  const uint8_t *bytes()const{return data_;}
  bool allows_eeprom()const{return false;}
  bool allows_motion()const{return false;}
  bool allows_heating()const{return false;}
  static bool verify(const uint8_t *p,uint8_t len){
    if(!p || len!=Size || p[0]!='S' || p[1]!='M' || p[2]!=Version ||
       p[3]!=Size || p[44]>(uint8_t)MapState::Invalid || p[45]!=0u ||
       p[10]>16u)return false;
    if(p[44]==(uint8_t)MapState::RamComplete &&
       (p[10]!=16u || p[8]!=0xFFu || p[9]!=0xFFu ||
        p[11]!=(uint8_t)G29UReceipt::Phase::RamOnlySuccess))return false;
    return NativeStatusPacket::crc16(p,46)==(uint16_t)(p[46]|((uint16_t)p[47]<<8));
  }
private:
  void put16(uint8_t i,uint16_t n){data_[i]=(uint8_t)n;data_[i+1]=(uint8_t)(n>>8);}
  void put32(uint8_t i,uint32_t n){for(uint8_t j=0;j<4;++j)data_[i+j]=(uint8_t)(n>>(j*8u));}
  uint8_t data_[Size]={};
  MapState state_=MapState::Empty;
};
extern MeshMapPacket mesh_map_packet;
} // namespace sv04next
