// SV04 NEXT 11.13-11.32: unique 4x4 native probe coverage.
// Pure, no motion, no heater, no EEPROM; optional G29 U only.
#pragma once
#include <stdint.h>
namespace sv04next {
class VisitProof final {
public:
  static constexpr uint16_t AllPoints = 0xFFFFu;
  bool record(uint8_t x, uint8_t y) {
    if (x >= 4 || y >= 4 || count_ >= 16) return false;
    const uint16_t bit = (uint16_t)(1u << ((unsigned)y * 4u + (unsigned)x));
    if (visited_ & bit) return false;
    visited_ = (uint16_t)(visited_ | bit);
    ++count_;
    return true;
  }
  bool complete() const { return count_ == 16u && visited_ == AllPoints; }
  uint8_t count() const { return count_; }
  uint16_t mask() const { return visited_; }
private:
  uint16_t visited_ = 0;
  uint8_t count_ = 0;
};
} // namespace sv04next
