// SV04 NEXT 8: observation-only G28 -> G29 U order checker.
// Temporal order is not authorization to heat, home, move, or save.
#pragma once
#include <stdint.h>
#include "SV04NextG28PassiveReceipt.hpp"
#include "SV04NextG29UReceipt.hpp"
namespace sv04next {
class G28G29OrderWitness final {
public:
  enum class Quality : uint8_t { Unknown, AwaitG28, AwaitG29, OrderObserved,
                                 G28NotTrusted, G28Interrupted, G29Failed, Stale };
  struct Frame {
    Quality quality=Quality::Unknown;
    uint32_t g28_sequence=0,g29_sequence=0,seen_ms=0;
    bool completed_g28_entry=false;
    bool ram_only_g29_16=false;
    bool safe_for_actuation=false,save_allowed=false;
  };
  void observe(uint32_t now,const G28PassiveReceipt::View &h,
               const G29UReceipt &p){
    const uint32_t start=now;
    if(h.sequence==0){reset(Quality::AwaitG28,start);return;}
    if(h.sequence!=last_h_){
      last_h_=h.sequence;
      last_p_=p.sequence();
      armed_=false;
      frame_.g28_sequence=h.sequence;
      frame_.g29_sequence=0;
      frame_.quality=Quality::AwaitG29;
    }
    frame_.seen_ms=now;
    // A receipt cannot certify indefinite freshness after its native event.
    if (h.phase==G28PassiveReceipt::Phase::EndObservedTrusted &&
        (uint32_t)(now-h.ended_ms)>MaxObservationAgeMs) {
      frame_.quality=Quality::Stale; armed_=false; clear_success(); return;
    }
    // No temporal evidence from a G28 which returned early or exceeded time.
    if(h.phase==G28PassiveReceipt::Phase::ReturnedEarly ||
       h.phase==G28PassiveReceipt::Phase::ClockInvalid){
      frame_.quality=Quality::G28Interrupted;armed_=false;clear_success();return;
    }
    if(h.phase==G28PassiveReceipt::Phase::EndObservedUntrusted){
      frame_.quality=Quality::G28NotTrusted;armed_=false;clear_success();return;
    }
    if(h.phase!=G28PassiveReceipt::Phase::EndObservedTrusted || !h.xyz_trusted){
      clear_success();return;
    }
    // A G29 U that was already running when G28 began must never qualify.
    if(!armed_ && p.sequence()!=last_p_){
      const uint32_t d=(uint32_t)(p.sequence()-last_p_);
      if(d==0 || d>0x7FFFFFFFu){frame_.quality=Quality::Stale;clear_success();return;}
      // Timestamp bound prevents an old homing receipt from authorizing even
      // a merely informational association many hours later.
      if((uint32_t)(now-h.ended_ms)>MaxG29StartAfterG28Ms){
        frame_.quality=Quality::Stale;clear_success();return;
      }
      last_p_=p.sequence();
      frame_.g29_sequence=last_p_;
      frame_.completed_g28_entry=true;
      armed_=true;
      frame_.quality=Quality::AwaitG29;
    }
    if(!armed_)return;
    if(p.sequence()!=last_p_){
      frame_.quality=Quality::Stale;armed_=false;clear_success();return;
    }
    switch(p.phase()){
      case G29UReceipt::Phase::RamOnlySuccess:
        if(p.completed()==16 && p.point_mask()==0xFFFFu){
          frame_.ram_only_g29_16=true;
          frame_.quality=Quality::OrderObserved;
        }else{frame_.quality=Quality::G29Failed;clear_success();}
        break;
      case G29UReceipt::Phase::Failed:
      case G29UReceipt::Phase::Refused:
        frame_.quality=Quality::G29Failed;clear_success();break;
      default:
        frame_.ram_only_g29_16=false;
    }
  }
  const Frame& view()const{return frame_;}
  bool allows_motion()const{return false;}
  bool allows_heating()const{return false;}
  bool allows_eeprom()const{return false;}
  static constexpr uint32_t MaxG29StartAfterG28Ms=120000u;
  static constexpr uint32_t MaxObservationAgeMs=1200000u;
private:
  void clear_success(){frame_.ram_only_g29_16=false;frame_.completed_g28_entry=false;}
  void reset(Quality q,uint32_t now){
    frame_=Frame{};frame_.quality=q;frame_.seen_ms=now;
    last_h_=0;last_p_=0;armed_=false;
  }
  Frame frame_{};
  uint32_t last_h_=0,last_p_=0;
  bool armed_=false;
};
extern G28G29OrderWitness g28_g29_order_witness;
}
