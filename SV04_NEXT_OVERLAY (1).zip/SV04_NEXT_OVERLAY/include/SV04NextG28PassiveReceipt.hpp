// SV04 NEXT 8: passive native G28 scope receipt. NO actuator control.
// Reports function-level execution only. It NEVER certifies safe IDEX parking,
// actual endstop validation, or automatic homing / movement / EEPROM permission.
#pragma once
#include <stdint.h>
namespace sv04next {
class G28PassiveReceipt final {
public:
  enum class Phase : uint8_t { Never, Entered, ReturnedEarly, EndObservedTrusted,
                               EndObservedUntrusted, ClockInvalid };
  struct View {
    uint32_t sequence=0, begun_ms=0, ended_ms=0;
    Phase phase=Phase::Never;
    bool xyz_trusted=false, tool0=false;
    bool physically_parked_t1=false;
    bool auto_start_allowed=false, eeprom_allowed=false;
  };
  class Scope final {
  public:
    Scope(G28PassiveReceipt &r, uint32_t now):r_(r),armed_(r_.begin(now)){}
    ~Scope() { if(armed_)r_.early_return(); }
    void finish(uint32_t now, bool x, bool y, bool z, bool tool0){
      if(!armed_)return;
      r_.finish(now,x,y,z,tool0);
      armed_=false;
    }
    Scope(const Scope&)=delete;
    Scope& operator=(const Scope&)=delete;
  private:
    G28PassiveReceipt &r_;
    bool armed_;
  };
  bool begin(uint32_t now){
    // Never replace a still-running record with a new one.
    if(v_.phase==Phase::Entered)return false;
    ++v_.sequence;
    if(v_.sequence==0)++v_.sequence;
    v_.begun_ms=now;
    v_.ended_ms=0;
    v_.phase=Phase::Entered;
    v_.xyz_trusted=false;
    v_.tool0=false;
    return true;
  }
  void early_return(){
    if(v_.phase==Phase::Entered){
      v_.phase=Phase::ReturnedEarly;
      v_.xyz_trusted=false;
      v_.tool0=false;
    }
  }
  bool finish(uint32_t now,bool x,bool y,bool z,bool tool0){
    if(v_.phase!=Phase::Entered)return false;
    v_.ended_ms=now;
    const uint32_t elapsed=(uint32_t)(now-v_.begun_ms);
    if(elapsed>MaxDurationMs){
      v_.phase=Phase::ClockInvalid;return false;
    }
    v_.xyz_trusted=x&&y&&z;
    v_.tool0=tool0;
    v_.phase=v_.xyz_trusted?Phase::EndObservedTrusted:Phase::EndObservedUntrusted;
    return v_.xyz_trusted;
  }
  const View& view()const{return v_;}
  bool allows_motion()const{return false;}
  bool allows_heating()const{return false;}
  bool allows_eeprom()const{return false;}
  bool physical_t1_proven()const{return false;}
  static constexpr uint32_t MaxDurationMs=600000u;
private:
  View v_{};
};
extern G28PassiveReceipt g28_passive_receipt;
} // namespace sv04next
