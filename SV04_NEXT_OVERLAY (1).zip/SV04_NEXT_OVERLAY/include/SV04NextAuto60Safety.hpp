// SV04 NEXT - Phase 10.27: HOST-ONLY safety model, not connected to Marlin.
// This header deliberately cannot issue M190, G28, G29, M500, or motion commands.
// MIT-style usage permitted only under the surrounding firmware's license.
#pragma once

#include <cmath>
#include <cstdint>

namespace sv04next {

class Auto60Safety final {
public:
  enum class State : uint8_t {
    Idle, Heating, ReadyForHoming, Homing, ReadyForMesh,
    Probing, ReadyToPersist, Persisting, VerifyEEPROM,
    Complete, Failed, Cancelled
  };
  enum class Fault : uint8_t {
    None, UnsafeStart, InvalidTemperature, HeaterTimeout,
    UnexpectedEvent, HomingFailed, ProbeFailed,
    ProbeOutOfOrder, ProbeRange, ProbeDisagreement,
    MeshIncomplete, MeshVerificationFailed,
    PersistFailed, EepromVerificationFailed, UserAbort
  };
  static constexpr uint8_t kGridSide = 4;
  static constexpr uint8_t kPoints = kGridSide * kGridSide;
  static constexpr float kTargetC = 60.0f;
  static constexpr float kMaxDeviationC = 1.0f;
  static constexpr float kEmergencyTempC = 65.0f;
  static constexpr uint32_t kStableSeconds = 30;
  static constexpr uint32_t kHeatTimeoutSeconds = 20 * 60;
  static constexpr float kMaxProbeDifferenceMm = 0.06f;
  static constexpr float kMaxAbsProbeMm = 3.0f;

  State state() const { return state_; }
  Fault fault() const { return fault_; }
  uint8_t completed_points() const { return completed_; }
  uint8_t completed_samples() const { return samples_; }
  bool allow_m500() const { return state_ == State::ReadyToPersist; }
  bool rollback_ram_mesh_required() const { return rollback_needed_; }
  bool eeprom_may_have_changed() const { return eeprom_may_have_changed_; }
  float point_z(uint8_t index) const { return index < kPoints ? points_[index] : NAN; }

  // A real Marlin integration MUST separately verify the boolean preconditions.
  // No heating or motion is started by this routine.
  bool start(bool idle, bool not_printing, bool bltouch_healthy,
             bool selected_probe_tool_and_other_carriage_parked,
             bool prior_mesh_snapshot_valid) {
    if (state_ != State::Idle) return reject(Fault::UnexpectedEvent);
    if (!(idle && not_printing && bltouch_healthy &&
          selected_probe_tool_and_other_carriage_parked &&
          prior_mesh_snapshot_valid)) return reject(Fault::UnsafeStart);
    state_ = State::Heating;
    return true;
  }

  // Samples are rejected if non-finite, or if the heater reaches an unsafe value.
  bool temperature(float celsius, uint32_t elapsed_seconds, uint32_t stable_seconds) {
    if (state_ != State::Heating) return reject(Fault::UnexpectedEvent);
    if (!std::isfinite(celsius) || celsius >= kEmergencyTempC)
      return reject(Fault::InvalidTemperature);
    if (elapsed_seconds > kHeatTimeoutSeconds)
      return reject(Fault::HeaterTimeout);
    if (std::fabs(celsius - kTargetC) <= kMaxDeviationC &&
        stable_seconds >= kStableSeconds) state_ = State::ReadyForHoming;
    return true;
  }

  bool begin_homing() {
    if (state_ != State::ReadyForHoming) return reject(Fault::UnexpectedEvent);
    state_ = State::Homing;
    return true;
  }

  bool homing_finished(bool g28_ok, bool x_y_z_trusted, bool carriages_safe) {
    if (state_ != State::Homing) return reject(Fault::UnexpectedEvent);
    if (!(g28_ok && x_y_z_trusted && carriages_safe)) return reject(Fault::HomingFailed);
    state_ = State::ReadyForMesh;
    return true;
  }

  bool begin_mesh(bool probe_ready, bool heater_stable, bool old_mesh_snapshot_still_valid) {
    if (state_ != State::ReadyForMesh) return reject(Fault::UnexpectedEvent);
    if (!(probe_ready && heater_stable && old_mesh_snapshot_still_valid))
      return reject(Fault::ProbeFailed);
    rollback_needed_ = true; // Marlin G29 may overwrite the RAM mesh in-place.
    state_ = State::Probing;
    return true;
  }

  // Two separate samples per point. An integration MUST prove that the actual
  // Marlin/BLTouch hardware produces these samples, not fabricate them from G29.
  bool probe_sample(uint8_t point_index, float z_mm, bool probe_ok, bool bed_stable) {
    if (state_ != State::Probing) return reject(Fault::UnexpectedEvent);
    if (!probe_ok || !bed_stable) return reject(Fault::ProbeFailed);
    if (completed_ >= kPoints || point_index >= kPoints || point_index != completed_)
      return reject(Fault::ProbeOutOfOrder);
    if (!std::isfinite(z_mm) || std::fabs(z_mm) > kMaxAbsProbeMm)
      return reject(Fault::ProbeRange);
    if (samples_ == 0) {
      first_ = z_mm;
      samples_ = 1;
    } else {
      if (std::fabs(first_ - z_mm) > kMaxProbeDifferenceMm)
        return reject(Fault::ProbeDisagreement);
      points_[completed_] = (first_ + z_mm) * 0.5f;
      ++completed_;
      samples_ = 0;
    }
    return true;
  }

  bool mesh_finished(bool g29_ok, bool exactly_4_by_4,
                     bool leveling_enabled, bool probe_stowed,
                     bool selected_tool_unchanged, bool bed_stable) {
    if (state_ != State::Probing) return reject(Fault::UnexpectedEvent);
    if (completed_ != kPoints || samples_ != 0) return reject(Fault::MeshIncomplete);
    if (!(g29_ok && exactly_4_by_4 && leveling_enabled && probe_stowed &&
          selected_tool_unchanged && bed_stable))
      return reject(Fault::MeshVerificationFailed);
    state_ = State::ReadyToPersist;
    return true;
  }

  // M500 is NEVER executed here. Integration may request one M500 only in
  // ReadyToPersist, followed by a real M420 V / M503 read-back comparison.
  bool begin_persist() {
    if (!allow_m500()) return reject(Fault::UnexpectedEvent);
    state_ = State::Persisting;
    eeprom_may_have_changed_ = true; // Fail-safe assumption until read-back.
    return true;
  }

  bool persist_returned(bool m500_ok) {
    if (state_ != State::Persisting) return reject(Fault::UnexpectedEvent);
    if (!m500_ok) return reject(Fault::PersistFailed);
    state_ = State::VerifyEEPROM;
    return true;
  }

  bool verify_saved(bool verified_same_mesh_and_z_offset) {
    if (state_ != State::VerifyEEPROM) return reject(Fault::UnexpectedEvent);
    if (!verified_same_mesh_and_z_offset) return reject(Fault::EepromVerificationFailed);
    rollback_needed_ = false;
    eeprom_may_have_changed_ = false;
    state_ = State::Complete;
    return true;
  }

  void cancel() {
    if (state_ != State::Complete && state_ != State::Failed) {
      state_ = State::Cancelled;
      fault_ = Fault::UserAbort;
    }
  }

private:
  State state_ = State::Idle;
  Fault fault_ = Fault::None;
  uint8_t completed_ = 0, samples_ = 0;
  float first_ = 0.0f;
  float points_[kPoints] = {};
  bool rollback_needed_ = false;
  bool eeprom_may_have_changed_ = false;

  bool reject(Fault why) {
    state_ = State::Failed;
    fault_ = why;
    return false;
  }
};

} // namespace sv04next
