// LEGACY HOST MODEL - superseded for accepted-versus-completed distinction
// by SV04NextOperationLedger.hpp. NEVER wire this model to native actuators.
// SV04 NEXT: command-intent handshake between the Auto60 FSM and a future
// hardware-validated Marlin actuator adapter. HOST MODEL ONLY, no commands.
// A step cannot complete from a late ACK belonging to an earlier generation.
// NOT integrated with Marlin, not a physical park attestation.
#pragma once
#include <stdint.h>

namespace sv04next {
class CommandHandshake final {
public:
  enum class Step : uint8_t { Heat60, HomeXYZ, ProbeG29U, SafeStop, RestoreRAM };
  enum class State : uint8_t { Idle, Pending, Acknowledged, Locked };
  enum class Error : uint8_t { None, Busy, InvalidRun, Preconditions, WrongAck, Timeout, Rejected, Locked };
  struct Live {
    bool printer_stopped=false, printing=false, paused=false;
    bool planner_idle=true, queue_empty=true, t0_active=true;
    bool physical_t1_verified=false; // no current firmware provider can assert this
    bool auto_park=true, bltouch_healthy=true, heater_healthy=true;
    bool bed_stable_60=false, xyz_homed=false, probe_stowed=true;
    bool offset_unchanged=true, g29_ram_16_success=false;
  };
  struct Ticket {
    uint32_t run=0, dispatch=0;
    Step step=Step::Heat60;
    bool valid()const{return run!=0 && dispatch!=0;}
  };
  bool issue(uint32_t run, Step step, uint32_t now, const Live &s, Ticket &out) {
    out=Ticket{};
    if (run==0) return reject(Error::InvalidRun);
    if (state_==State::Pending) return reject(Error::Busy);
    if (state_==State::Locked) return reject(Error::Locked);
    // A previous completed dispatch must be independently consumed. Never
    // let repeated RTS ticks send the same heater/homing/probe command twice.
    if (state_==State::Acknowledged) return reject(Error::Busy);
    if (owner_!=0 && run!=owner_) return reject(Error::InvalidRun);
    if (!sequence_permitted(step) || !permitted(step,s)) return reject(Error::Preconditions);
    owner_=run;
    ++serial_;
    if(!serial_)++serial_;
    active_.run=run; active_.dispatch=serial_; active_.step=step;
    issued_at_=now;state_=State::Pending;error_=Error::None;
    out=active_;
    return true;
  }
  bool confirm(const Ticket& t,bool actual_success,uint32_t now,const Live &s) {
    if(state_!=State::Pending || !same(t,active_))return reject(Error::WrongAck);
    if ((uint32_t)(now-issued_at_)>timeout(t.step))return lock(Error::Timeout);
    if (!actual_success || !confirmation_valid(t.step,s))return lock(Error::Rejected);
    state_=State::Acknowledged;error_=Error::None;return true;
  }
  bool consume(const Ticket &t) {
    if(state_!=State::Acknowledged || !same(t,active_))return false;
    if(t.step==Step::Heat60)progress_=Progress::Heated;
    else if(t.step==Step::HomeXYZ)progress_=Progress::Homed;
    else if(t.step==Step::ProbeG29U)progress_=Progress::Probed;
    state_=State::Idle;error_=Error::None;return true;
  }
  bool poll(uint32_t now) {
    if(state_!=State::Pending)return true;
    return (uint32_t)(now-issued_at_)>timeout(active_.step)?lock(Error::Timeout):true;
  }
  // Abort/recovery must bypass the ordinary pending queue. The caller must
  // still physically stop the machine; this method ONLY revokes the ticket.
  void revoke() { state_=State::Locked;error_=Error::Locked;active_=Ticket{}; }
  bool reset_after_quiescence(uint32_t new_run, const Live &s) {
    if(state_!=State::Locked && state_!=State::Idle)return false;
    if(!new_run || new_run==owner_ || s.printing || s.paused || s.printer_stopped ||
       !s.planner_idle || !s.queue_empty || !s.probe_stowed)return false;
    state_=State::Idle;error_=Error::None;owner_=new_run;active_=Ticket{};progress_=Progress::Fresh;
    return true;
  }
  State state() const{return state_;}
  Error error() const{return error_;}
  Ticket pending() const{return state_==State::Pending?active_:Ticket{};}
  bool can_write_eeprom() const{return false;}
  bool native_actuators_connected() const{return false;}
  bool ram_only_success() const{return progress_==Progress::Probed && state_==State::Idle;}
  bool hardware_approved() const{return false;}
private:
  enum class Progress : uint8_t { Fresh, Heated, Homed, Probed };
  bool sequence_permitted(Step s)const {
    if(s==Step::SafeStop)return true;
    if(s==Step::RestoreRAM)return false; // RAM rollback needs its own verified quiescence adapter
    return (s==Step::Heat60 && progress_==Progress::Fresh) ||
      (s==Step::HomeXYZ && progress_==Progress::Heated) ||
      (s==Step::ProbeG29U && progress_==Progress::Homed);
  }
  static bool same(const Ticket&a,const Ticket&b){return a.valid() && a.run==b.run && a.dispatch==b.dispatch && a.step==b.step;}
  static uint32_t timeout(Step s){switch(s){case Step::Heat60:return 30000u;case Step::HomeXYZ:return 180000u;case Step::ProbeG29U:return 900000u;case Step::SafeStop:return 15000u;case Step::RestoreRAM:return 15000u;}return 0u;}
  static bool baseline(const Live&s){return !s.printer_stopped && !s.printing && !s.paused &&
    s.t0_active && s.physical_t1_verified && s.auto_park && s.bltouch_healthy &&
    s.heater_healthy && s.offset_unchanged;}
  static bool permitted(Step step,const Live&s) {
    if(step==Step::SafeStop)return true;
    if(step==Step::RestoreRAM)return !s.printer_stopped && !s.printing && !s.paused &&
      s.planner_idle && s.queue_empty && s.probe_stowed;
    if(!baseline(s))return false;
    if(step==Step::Heat60)return s.planner_idle && s.queue_empty && s.probe_stowed;
    if(step==Step::HomeXYZ)return s.planner_idle && s.queue_empty && s.probe_stowed && s.bed_stable_60;
    if(step==Step::ProbeG29U)return s.planner_idle && s.queue_empty && s.probe_stowed &&
      s.bed_stable_60 && s.xyz_homed;
    return false;
  }
  static bool confirmation_valid(Step step,const Live&s){
    if(step==Step::SafeStop)return s.planner_idle && s.queue_empty && s.probe_stowed;
    if(step==Step::RestoreRAM)return s.planner_idle && s.queue_empty && s.probe_stowed;
    if(!baseline(s))return false;
    if(step==Step::Heat60)return s.bed_stable_60;
    if(step==Step::HomeXYZ)return s.xyz_homed && s.probe_stowed && s.bed_stable_60 && s.planner_idle && s.queue_empty;
    if(step==Step::ProbeG29U)return s.g29_ram_16_success && s.xyz_homed && s.probe_stowed && s.bed_stable_60 && s.planner_idle && s.queue_empty;
    return false;
  }
  bool reject(Error e){if(state_!=State::Pending && state_!=State::Acknowledged && state_!=State::Locked)error_=e;return false;}
  bool lock(Error e){state_=State::Locked;error_=e;active_=Ticket{};return false;}
  Progress progress_=Progress::Fresh;
  State state_=State::Idle;
  Error error_=Error::None;
  uint32_t owner_=0,serial_=0,issued_at_=0;
  Ticket active_{};
};
} // namespace sv04next
