// SV04 NEXT: display model ONLY. No VP addresses and no physical HMI writes.
// German status names; never display 100%/green unless all proofs are current.
#pragma once
#include <stdint.h>
#include <math.h>
namespace sv04next {
class DwinStatusContract final {
public:
  enum class Status : uint8_t { Idle, Interlock, Warming, Stabilizing, Homing,
    Measuring, RamVerified, Aborted, Fault, Restoring, SensorFault };
  enum class Shade : uint8_t { Empty, Measuring, Unverified, Validated, Error };
  struct Reading {
    uint32_t active_run=0,controller_run=0,receipt_run=0;
    Status requested=Status::Idle;
    bool t1_park_proven=false,receipt_is_current=false;
    bool controller_ram_complete=false,probe_stowed=false;
    bool offset_unchanged=false,temperature_good=false;
    uint16_t mask=0;
    float z[16]{};
    float bed=0.f,target=0.f;
  };
  struct Frame {
    Status status=Status::Idle;
    uint8_t count=0,percent=0;
    bool ram_16_verified=false,eeprom_saved=false;
    int16_t bed_x10=0,target_x10=0;
    Shade cells[16]{};
  };
  static Frame make(const Reading &r){
    Frame out;out.status=r.requested;
    if(isfinite(r.bed)&&r.bed>=0.f&&r.bed<=115.f)out.bed_x10=(int16_t)(r.bed*10.f+.5f);
    if(isfinite(r.target)&&r.target>=0.f&&r.target<=115.f)out.target_x10=(int16_t)(r.target*10.f+.5f);
    bool good_run=r.active_run!=0 && r.active_run==r.controller_run && r.active_run==r.receipt_run;
    uint8_t count=0;
    for(uint8_t i=0;i<16;++i){
      const bool valid=(r.mask & (uint16_t)(1u<<i)) && isfinite(r.z[i]) && fabsf(r.z[i])<=3.f;
      if(valid && good_run){++count;out.cells[i]=Shade::Unverified;}
      else if(r.mask & (uint16_t)(1u<<i))out.cells[i]=Shade::Error;
      else out.cells[i]=Shade::Empty;
    }
    out.count=count;
    out.ram_16_verified=good_run && r.receipt_is_current && r.controller_ram_complete &&
      r.t1_park_proven && r.probe_stowed && r.offset_unchanged && r.temperature_good &&
      r.mask==0xFFFFu && count==16 && r.requested==Status::RamVerified;
    out.percent=(uint8_t)(count*100u/16u);
    if(!out.ram_16_verified){
      if(out.percent==100)out.percent=99;
      if(out.status==Status::RamVerified)out.status=Status::Interlock;
    }else{
      out.percent=100;
      for(uint8_t i=0;i<16;++i)out.cells[i]=Shade::Validated;
    }
    return out;
  }
  static const char* german(Status code){
    switch(code){
      case Status::Idle:return "Bereit";
      case Status::Interlock:return "Sicherheitspruefung";
      case Status::Warming:return "Heizbett auf 60 C";
      case Status::Stabilizing:return "Temperatur stabilisieren";
      case Status::Homing:return "Referenzfahrt G28";
      case Status::Measuring:return "Bettvermessung";
      case Status::RamVerified:return "16 Punkte im RAM geprueft";
      case Status::Aborted:return "Abgebrochen";
      case Status::Fault:return "Messfehler";
      case Status::Restoring:return "RAM-Mesh wiederherstellen";
      case Status::SensorFault:return "Sensor pruefen";
    }
    return "Unbekannter Status";
  }
  static bool writes_hmi() {return false;}
  static bool commands_motion() {return false;}
  static bool auto_saves() {return false;}
};
}
