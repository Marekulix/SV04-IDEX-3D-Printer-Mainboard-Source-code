// SV04 NEXT: experimental, read-only native Marlin status gate.
// No G-code queueing, heaters, steppers, EEPROM, DWIN VP writes, or HMI touch events.
// A firmware coordinate (X2=362) is NOT evidence that carriage T1 is physically parked.
#pragma once
#include <stdint.h>
#include <math.h>
#include "SV04NextG29UReceipt.hpp"
#include "SV04NextSafeFloat.hpp"

namespace sv04next {

class NativeReadiness final {
public:
  enum class Gate : uint8_t {
    Waiting, PrinterStopped, PrintOngoing, MotionActive, WrongTool,
    WrongCarriageMode, UntrustedAxes, X2SoftwarePosition, Temperature,
    OffsetInvalid, NoPhysicalT1Witness, NoProbeStowWitness, ObservingRamResult
  };
  struct Live final {
    bool stopped = false;
    bool printing = false;          // includes paused jobs
    bool motion_queued = false;
    bool tool0 = false;
    bool dual_auto_park = false;
    bool xyz_trusted = false;
    float t1_x = NAN;               // Software estimate ONLY
    float t1_home_x = NAN;
    float bed_c = NAN;
    float bed_set_c = NAN;
    float probe_offset_z = NAN;
    // The current Sovol firmware has no independent proof provider for these.
    bool physical_t1_park_witness = false;
    bool probe_stow_witness = false;
  };
  struct View final {
    Gate gate = Gate::Waiting;
    uint32_t last_sample_ms = 0;
    uint32_t g29_run_id = 0;
    uint8_t measured = 0;
    uint16_t valid_mask = 0;
    G29UReceipt::Phase receipt_phase = G29UReceipt::Phase::Never;
    G29UReceipt::Failure receipt_failure = G29UReceipt::Failure::None;
    // Not a persisted-mesh confirmation. This is RAM-level status only.
    bool ram_mesh_16_of_16 = false;
    bool observed = false;
  };

  void observe(uint32_t now_ms, const Live &live, const G29UReceipt &receipt) {
    view_.observed = true;
    view_.last_sample_ms = now_ms;
    view_.g29_run_id = receipt.sequence();
    view_.measured = receipt.completed();
    view_.valid_mask = receipt.point_mask();
    view_.receipt_phase = receipt.phase();
    view_.receipt_failure = receipt.failure();
    view_.ram_mesh_16_of_16 = receipt.phase() == G29UReceipt::Phase::RamOnlySuccess
      && receipt.completed() == 16 && receipt.point_mask() == 0xFFFFu;
    view_.gate = evaluate(live);
  }

  static Gate evaluate(const Live &s) {
    if (s.stopped) return Gate::PrinterStopped;
    if (s.printing) return Gate::PrintOngoing;
    if (s.motion_queued) return Gate::MotionActive;
    if (!s.tool0) return Gate::WrongTool;
    if (!s.dual_auto_park) return Gate::WrongCarriageMode;
    if (!s.xyz_trusted) return Gate::UntrustedAxes;
    if (!float_is_finite(s.t1_x) || !float_is_finite(s.t1_home_x) ||
        fabsf(s.t1_x - s.t1_home_x) > 1.0f) return Gate::X2SoftwarePosition;
    if (!float_is_finite(s.bed_c) || !float_is_finite(s.bed_set_c) || s.bed_c < 0.f ||
        s.bed_c > 115.f || s.bed_set_c < 0.f || s.bed_set_c > 115.f)
      return Gate::Temperature;
    if (!float_is_finite(s.probe_offset_z)) return Gate::OffsetInvalid;
    if (!s.physical_t1_park_witness) return Gate::NoPhysicalT1Witness;
    if (!s.probe_stow_witness) return Gate::NoProbeStowWitness;
    return Gate::ObservingRamResult;
  }

  const View &view() const { return view_; }
  // Deliberate fail-closed gate. Physical evidence, safe actuator adapter,
  // DWIN touch image, controlled persistence, and real hardware tests absent.
  bool allow_automatic_heating() const { return false; }
  bool allow_automatic_homing() const { return false; }
  bool allow_automatic_g29() const { return false; }
  bool allow_eeprom_save() const { return false; }
  bool hardware_approved() const { return false; }

private:
  View view_{};
};

extern NativeReadiness native_readiness;
} // namespace sv04next
