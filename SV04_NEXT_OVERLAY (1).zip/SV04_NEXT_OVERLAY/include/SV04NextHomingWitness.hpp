// SV04 NEXT - independent G28 event provenance, not physical endstop proof.
// Requires a fresh native homing event and NEW trusted XYZ flags after this ticket.
// No commands; cannot prove the T1 carriage is mechanically parked.
#pragma once
#include <stdint.h>
#include "SV04NextAuto60Policy.hpp"
namespace sv04next {
class HomingWitness final {
public:
  enum class Phase : uint8_t { Idle, Awaiting, Verified, Rejected };
  enum class Error : uint8_t { None, WrongRun, StaleEvent, Timeout, Unsafe, PartialAxes, Repeated };
  static constexpr uint32_t MaxMs=Auto60Policy::HomeTimeoutMs;
  struct Native { uint32_t homing_epoch=0;bool stopped=false,print_active=false,
    movement=false,queue_pending=false,t0=true,probe_stowed=true,
    xyz_homed=false,t1_physical_witness=false,bed_60_stable=false,offset_unchanged=true; };
  bool begin(uint32_t run,uint32_t dispatch,uint32_t now,const Native &s){
    if(phase_!=Phase::Idle || !run || !dispatch || !safe(s))return false;
    run_=run;dispatch_=dispatch;start_=now;prior_epoch_=s.homing_epoch;
    phase_=Phase::Awaiting;return true;
  }
  bool finish(uint32_t run,uint32_t dispatch,uint32_t now,bool genuine_g28_done,const Native&s){
    if(phase_!=Phase::Awaiting)return false;
    if(run!=run_ || dispatch!=dispatch_)return reject(Error::WrongRun);
    if((uint32_t)(now-start_)>MaxMs)return reject(Error::Timeout);
    if(!safe(s))return reject(Error::Unsafe);
    if(!genuine_g28_done || s.homing_epoch==prior_epoch_ || s.homing_epoch==0)
      return reject(Error::StaleEvent);
    if(!s.xyz_homed || s.movement || s.queue_pending || !s.probe_stowed)
      return reject(Error::PartialAxes);
    phase_=Phase::Verified;return true;
  }
  void revoke(){reject(Error::Unsafe);}
  bool verified(uint32_t run,uint32_t dispatch)const{return phase_==Phase::Verified && run==run_ && dispatch==dispatch_;}
  bool physically_parked_t1()const{return false;}
  bool starts_g28()const{return false;}
  Phase phase()const{return phase_;}Error error()const{return error_;}
private:
  static bool safe(const Native &s){return !s.stopped && !s.print_active && s.t0 &&
    s.t1_physical_witness && s.bed_60_stable && s.offset_unchanged;}
  bool reject(Error e){phase_=Phase::Rejected;error_=e;return false;}
  uint32_t run_=0,dispatch_=0,start_=0,prior_epoch_=0;
  Phase phase_=Phase::Idle;Error error_=Error::None;
};
}
