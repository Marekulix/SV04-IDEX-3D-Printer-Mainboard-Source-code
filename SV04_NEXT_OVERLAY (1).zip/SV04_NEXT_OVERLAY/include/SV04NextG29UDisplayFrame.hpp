// SV04 NEXT 11.33-11.52: read-only 4x4 receipt-to-DWIN color model.
// THIS DOES NOT CREATE A REAL DWIN/HMI SCREEN OR A TOUCH BUTTON.
#pragma once
#include "SV04NextG29UReceipt.hpp"
#include "SV04NextDwinView.hpp"
#include <stdint.h>
#include <math.h>

namespace sv04next {
class G29UDisplayFrame final {
public:
  using Color=DwinView::Color;
  static bool success(const G29UReceipt &r) {
    if (r.phase() != G29UReceipt::Phase::RamOnlySuccess ||
        r.completed() != 16 || r.point_mask() != 0xFFFFu) return false;
    for(uint8_t i=0;i<16;++i) if (!isfinite(r.value(i))) return false;
    return true;
  }
  static Color pixel(const G29UReceipt &r,uint8_t x,uint8_t y) {
    if (x>=4 || y>=4) return Color::Gray;
    const uint8_t index=(uint8_t)(y*4+x);
    if (r.pixel(index)==G29UReceipt::Pixel::Problem) return Color::Red;
    if (r.pixel(index)!=G29UReceipt::Pixel::Recorded) return Color::Gray;
    if (!success(r)) return Color::Yellow; // uncommitted measurement, NOT success
    const float base=reference(r);
    return DwinView::color_for(r.value(index),base);
  }
  static float reference(const G29UReceipt &r) {
    if (!success(r)) return NAN;
    // Mean of sixteen validated points. Only a visualization reference; the
    // actual bilinear correction remains the native Marlin mesh.
    float sum=0.f;
    for (uint8_t i=0;i<16;++i) sum+=r.value(i);
    return sum/16.f;
  }
  static uint8_t percent(const G29UReceipt &r) {
    return (uint8_t)(((unsigned)r.completed()*100u)/16u);
  }
  static bool EEPROM_verified(const G29UReceipt &) {return false;}
};
} // namespace sv04next
