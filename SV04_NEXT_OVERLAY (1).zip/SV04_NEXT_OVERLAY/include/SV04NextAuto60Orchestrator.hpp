// SV04 NEXT – phase 10.35-10.40: fail-closed host-verified Auto60 plan.
// This class NEVER drives motors/heaters, calls M500, or touches EEPROM.
// A future reviewed native adapter must implement actions and hardware confirmations.
#pragma once
#include <stdint.h>
#include <math.h>
#include <string.h>

namespace sv04next {

struct Auto60Inputs {
  bool printing = false;               // includes host, SD and recovery print
  bool motion_idle = true;
  bool queue_empty = true;
  bool tool0_selected = true;
  bool tool1_park_verified = true;     // required separately for IDEX
  bool heater_healthy = true;
  bool bltouch_healthy = true;
  bool estop_clear = true;
  bool homed_xyz = false;
  bool probe_stowed = true;
  float bed_c = 20.f;
  float target_c = 0.f;
  float z_offset = -1.10f;
};

// No M500 action exists by design. RAM candidate only until a later EEPROM transaction
// with actual persistent backup, independent readback and restore has been proven.
class Auto60Orchestrator final {
public:
  static constexpr unsigned points = 16;
  static constexpr float target_c = 60.f;
  static constexpr float heat_tolerance_c = 1.f;
  static constexpr float z_delta_limit_mm = 0.06f;  // experimental, hardware tuning required
  static constexpr float max_abs_mesh_mm = 3.f;      // conservative diagnostic bound
  static constexpr uint32_t heat_timeout_ms = 12u * 60u * 1000u;
  static constexpr uint32_t stable_duration_ms = 20u * 1000u;
  enum class Phase : uint8_t { Idle, Heating, Homing, Probing, Review, Failed, Cancelled };
  enum class Action : uint8_t {
    None, SetBedTo60, RequestG28, RequestG29U,
    StopAndRestoreOldRamMesh, FinishedRamOnly
  };
  enum class Fault : uint8_t {
    None, Busy, CollisionGuard, HeaterFault, BLTouchFault, EmergencyStop,
    InvalidTemperature, HeatTimeout, HomingError, InvalidSample,
    SampleDisagreement, SampleOrder, ProbeError, MeshMismatch, OffsetChanged, CancelledByUser
  };
  struct Snapshot {
    float mesh[points];
    float z_offset;
    bool leveling_enabled;
    // G29 may change mesh geometry as well as point values.
    // Stored byte-for-byte for a future firmware-side transactional restore.
    float start_x, start_y, spacing_x, spacing_y;
  };

  Action start(uint32_t now_ms, const Auto60Inputs &v, const Snapshot &previous) {
    if (phase_ != Phase::Idle) return Action::None;
    if (!preflight(v) || !isfinite(previous.z_offset) ||
        !isfinite(v.z_offset) || fabsf(v.z_offset - previous.z_offset) > 0.00001f) {
      fault_ = !preflight(v) ? classify(v) : Fault::OffsetChanged;
      phase_ = Phase::Failed;
      return Action::None;             // Refusal: no hardware command emitted
    }
    memcpy(&old_, &previous, sizeof(Snapshot)); // preserves NaNs and old mesh bit patterns
    snapshot_valid_ = true;
    began_ms_ = now_ms;
    stable_since_ms_ = now_ms;
    stable_ = false;
    target_seen_ = false;
    next_point_ = 0;
    phase_ = Phase::Heating;
    return Action::SetBedTo60;
  }

  Action tick(uint32_t now_ms, const Auto60Inputs &v) {
    if (!active()) return Action::None;
    if (!basic_safe(v)) return fail(classify(v));
    if (!isfinite(v.bed_c) || !isfinite(v.target_c) || v.bed_c < 0.f || v.bed_c > 115.f)
      return fail(Fault::InvalidTemperature);
    // Check offsets before any transition can request physical motion.
    if (fabsf(v.z_offset - old_.z_offset) > 0.00001f || !isfinite(v.z_offset))
      return fail(Fault::OffsetChanged);
    // Wrap-safe for bounded elapsed intervals (< 2^31 milliseconds).
    if (phase_ == Phase::Heating) {
      if ((uint32_t)(now_ms - began_ms_) > heat_timeout_ms) return fail(Fault::HeatTimeout);
      if (fabsf(v.target_c - target_c) > 0.01f) {
        if (target_seen_) return fail(Fault::HeaterFault); // Don't accept later target overrides
        stable_ = false;             // Wait for the first heater-target acknowledgement
        return Action::None;
      }
      target_seen_=true;
      if (fabsf(v.bed_c - target_c) <= heat_tolerance_c) {
        if (!stable_) { stable_=true; stable_since_ms_=now_ms; }
        if ((uint32_t)(now_ms - stable_since_ms_) >= stable_duration_ms) {
          if (!v.queue_empty || !v.motion_idle || !v.probe_stowed)
            return fail(Fault::Busy);
          phase_=Phase::Homing;
          return Action::RequestG28;
        }
      } else stable_ = false;
    } else if (phase_ == Phase::Homing || phase_ == Phase::Probing) {
      if (fabsf(v.bed_c-target_c) > heat_tolerance_c || fabsf(v.target_c-target_c) > .01f)
        return fail(Fault::HeaterFault);
    }
    return Action::None;
  }

  Action homing_done(bool confirmed, const Auto60Inputs &v) {
    if (phase_ != Phase::Homing) return Action::None;
    if (!basic_safe(v)) return fail(classify(v));
    if (!confirmed || !v.homed_xyz || !v.probe_stowed || !v.queue_empty || !v.motion_idle)
      return fail(Fault::HomingError);
    if (!isfinite(v.z_offset) || fabsf(v.z_offset-old_.z_offset)>0.00001f)
      return fail(Fault::OffsetChanged);
    if (!isfinite(v.bed_c) || !isfinite(v.target_c) ||
        fabsf(v.bed_c-target_c) > heat_tolerance_c || fabsf(v.target_c-target_c)>0.01f)
      return fail(Fault::HeaterFault);
    phase_=Phase::Probing;
    return Action::RequestG29U;
  }

  bool measurement(uint8_t sample_index, float fast, float slow, const Auto60Inputs &v) {
    if (phase_ != Phase::Probing) return false;
    if (!basic_safe(v)) { fail(classify(v)); return false; }
    if (sample_index != next_point_ || next_point_ >= points) { fail(Fault::SampleOrder); return false; }
    if (!isfinite(v.z_offset) || fabsf(v.z_offset-old_.z_offset)>0.00001f) {
      fail(Fault::OffsetChanged); return false;
    }
    if (!isfinite(v.bed_c) || !isfinite(v.target_c)) { fail(Fault::InvalidTemperature); return false; }
    if (fabsf(v.bed_c-target_c) > heat_tolerance_c || fabsf(v.target_c-target_c) > 0.01f) {
      fail(Fault::HeaterFault); return false;
    }
    if (!isfinite(fast) || !isfinite(slow) || fabsf(fast) > max_abs_mesh_mm || fabsf(slow) > max_abs_mesh_mm) {
      fail(Fault::InvalidSample); return false;
    }
    if (fabsf(fast-slow) > z_delta_limit_mm) { fail(Fault::SampleDisagreement); return false; }
    candidate_[next_point_++] = (2.f*fast + 3.f*slow)*0.2f;
    return true;
  }

  Action probe_done(bool g29_success, const Auto60Inputs &v, const float *observed_mesh) {
    if (phase_ != Phase::Probing) return Action::None;
    if (!basic_safe(v)) return fail(classify(v));
    if (!g29_success || !observed_mesh || next_point_ != points || !v.probe_stowed || !v.homed_xyz)
      return fail(Fault::ProbeError);
    if (!isfinite(v.bed_c) || !isfinite(v.target_c) ||
        fabsf(v.bed_c-target_c)>heat_tolerance_c || fabsf(v.target_c-target_c)>0.01f)
      return fail(Fault::HeaterFault);
    if (fabsf(v.z_offset-old_.z_offset)>0.00001f || !isfinite(v.z_offset)) return fail(Fault::OffsetChanged);
    for (uint8_t i=0; i<points; ++i) {
      if (!isfinite(observed_mesh[i]) || fabsf(candidate_[i]-observed_mesh[i]) > 0.0001f)
        return fail(Fault::MeshMismatch);
    }
    phase_=Phase::Review;
    return Action::FinishedRamOnly;
  }

  Action cancel() { return active() ? fail(Fault::CancelledByUser, true) : Action::None; }
  bool snapshot(const Snapshot *&data) const { data=snapshot_valid_? &old_ : nullptr; return snapshot_valid_; }
  bool eeprom_save_permitted() const { return false; } // deliberate hard prohibition
  bool active() const {return phase_==Phase::Heating || phase_==Phase::Homing || phase_==Phase::Probing;}
  Phase phase() const {return phase_;}
  Fault fault() const {return fault_;}
  unsigned finished_points() const {return next_point_;}
  float candidate(unsigned i) const { return i<points ? candidate_[i] : NAN; }
private:
  static bool basic_safe(const Auto60Inputs &v) {
    return !v.printing && v.tool0_selected && v.tool1_park_verified && v.heater_healthy &&
      v.bltouch_healthy && v.estop_clear;
  }
  static bool preflight(const Auto60Inputs &v) {
    return basic_safe(v) && v.motion_idle && v.queue_empty && v.probe_stowed &&
      isfinite(v.bed_c) && v.bed_c >= 0.f && v.bed_c <= 115.f;
  }
  static Fault classify(const Auto60Inputs &v) {
    if (!v.estop_clear) return Fault::EmergencyStop;
    if (v.printing || !v.queue_empty || !v.motion_idle || !v.probe_stowed) return Fault::Busy;
    if (!v.tool0_selected || !v.tool1_park_verified) return Fault::CollisionGuard;
    if (!v.heater_healthy) return Fault::HeaterFault;
    if (!v.bltouch_healthy) return Fault::BLTouchFault;
    return Fault::InvalidTemperature;
  }
  Action fail(Fault f, bool cancelled=false) {
    if (active()) { phase_=cancelled ? Phase::Cancelled : Phase::Failed; fault_=f; return Action::StopAndRestoreOldRamMesh; }
    return Action::None;
  }
  Phase phase_=Phase::Idle;
  Fault fault_=Fault::None;
  Snapshot old_ = {};
  float candidate_[points] = {};
  bool snapshot_valid_=false, stable_=false, target_seen_=false;
  uint32_t began_ms_=0, stable_since_ms_=0;
  uint8_t next_point_=0;
};

} // namespace sv04next
