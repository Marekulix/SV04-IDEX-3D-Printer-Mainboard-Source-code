// Shared offline-model timing limits. No implicit permission to actuate.
#pragma once
#include <stdint.h>
namespace sv04next {
struct Auto60Policy final {
  static constexpr uint32_t CommandAcceptMs=30000u;
  static constexpr uint32_t HeatTimeoutMs=720000u; // agrees with SequencedController
  static constexpr uint32_t TemperatureHoldMs=20000u;
  static constexpr uint32_t SensorGapMs=3000u;
  static constexpr uint32_t HomeTimeoutMs=180000u;
  static constexpr uint32_t ProbeTimeoutMs=900000u;
  static constexpr float BedTargetC=60.f;
  static constexpr float StableWindowC=1.f;
};
}
