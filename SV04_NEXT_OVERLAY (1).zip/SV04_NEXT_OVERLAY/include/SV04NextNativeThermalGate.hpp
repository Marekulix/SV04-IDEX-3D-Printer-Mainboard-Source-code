// SV04 NEXT experimental native 60 C stability monitor. C++11, no I/O.
// Do NOT treat readiness as evidence of safe IDEX parking or BLTouch hardware.
#pragma once
#include <stdint.h>
#include <math.h>
#include "SV04NextSafeFloat.hpp"

namespace sv04next {
class NativeThermalGate final {
public:
  static constexpr uint32_t StableMillis = 20000U;
  static constexpr uint32_t MaxSampleAgeMillis = 4000U;
  // Drift guard (Stand 11): within one stable window max-min may not exceed this. A bed that only
  // PASSES through the 59..61 C window (heating or cooling) is not stable. UNVALIDATED conservative
  // default: tune against the real bed (a bang-bang controller with larger hysteresis never becomes
  // ready, which is the safe failure).
  static constexpr float MaxSpreadC = 0.8f;
  void reset() {
    started_ = false;
    stable_since_ = 0;
    last_sample_ = 0;
    min_c_ = max_c_ = 0.0f;
  }
  void observe(uint32_t now, float bed_c, float target_c, bool machine_idle) {
    const bool valid = machine_idle && float_is_finite(bed_c) && float_is_finite(target_c) &&
      target_c == 60.0f && bed_c >= 59.0f && bed_c <= 61.0f;
    if (!valid) { reset(); return; }
    if (!started_ || (uint32_t)(now - last_sample_) > MaxSampleAgeMillis) {
      stable_since_ = now;
      min_c_ = max_c_ = bed_c;
      started_ = true;
    } else {
      const float lo = bed_c < min_c_ ? bed_c : min_c_;
      const float hi = bed_c > max_c_ ? bed_c : max_c_;
      if (hi - lo > MaxSpreadC) { stable_since_ = now; min_c_ = max_c_ = bed_c; }  // drifting: restart
      else { min_c_ = lo; max_c_ = hi; }
    }
    last_sample_ = now;
  }
  // Runtime measurement validity, independent of RTSUpdate frequency.
  // Entry still requires ready(now) after a continuous 20s observation.
  static bool live_sample_safe(float bed_c, float target_c) {
    return float_is_finite(bed_c) && float_is_finite(target_c) &&
      target_c == 60.0f && bed_c >= 59.0f && bed_c <= 61.0f;
  }
  bool ready(uint32_t now) const {
    return started_ &&
      (uint32_t)(now - last_sample_) <= MaxSampleAgeMillis &&
      (uint32_t)(now - stable_since_) >= StableMillis;
  }
private:
  uint32_t stable_since_ = 0, last_sample_ = 0;
  float min_c_ = 0.0f, max_c_ = 0.0f;
  bool started_ = false;
};

extern NativeThermalGate native_thermal_gate;
} // namespace sv04next
