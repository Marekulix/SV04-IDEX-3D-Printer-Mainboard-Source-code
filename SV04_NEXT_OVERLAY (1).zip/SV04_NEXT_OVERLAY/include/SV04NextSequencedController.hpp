// SV04 NEXT 10.73-10.92: sequenced, fail-closed host orchestration contract.
// Diagnostic-only. NO Marlin/DWIN wiring; NO physical commands; NO M500.
// External callbacks must be authenticated against an ACTIVE run token. This
// token is not a cryptographic proof; it only prevents stale local callbacks.
#pragma once
#include <stdint.h>
#include <math.h>
#include <string.h>

namespace sv04next {
class SequencedController final {
public:
  static constexpr unsigned Points = 16;
  enum class State : uint8_t {
    Idle, AwaitHeatAck, Heating, Homing, Probing, Quiescing,
    RestoringRam, FinishedRam, Failed, Cancelled
  };
  enum class Action : uint8_t {
    None, Heat60, HomeXYZ, ProbeG29U, RequestSafeStop,
    RestoreOldRam, FinishedRamOnly
  };
  enum class Error : uint8_t {
    None, Busy, Unsafe, UnsafeT1, Heater, HeatAckTimeout,
    HeatTimeout, HomeTimeout, ProbeTimeout, InvalidCallback,
    SampleOrder, InvalidSample, ProbeSpread, ZOffsetChanged,
    ThermalDeviation, G29Failed, Incomplete, MeshMismatch,
    ProbeNotStowed, UserCancel, RestoreFailed
  };
  enum class Pixel : uint8_t { Empty, Valid, Invalid, Mismatch };
  struct Inputs {
    bool marlin_stopped=false, print_active=false, print_paused=false;
    bool motion_active=false, queued_gcode=false;
    bool t0_active=true, t1_homed=false, t1_park_physically_confirmed=false;
    bool auto_park_mode=false, xyz_homed=false;
    bool bltouch_healthy=true, probe_stowed=true, heater_healthy=true;
    bool abort_requested=false;
    float bed=22.f, setpoint=0.f, zoffset=-1.10f;
  };
  struct MeshSnapshot {
    float z[Points];
    float origin_x=0.f, origin_y=0.f, pitch_x=0.f, pitch_y=0.f;
    float zoffset=0.f;
    bool leveling_enabled=false;
  };
  struct Display {
    uint16_t bed_x10=0, target_x10=0;
    uint8_t measured=0;
    State phase=State::Idle;
    Error error=Error::None;
    Pixel point[Points]{};
  };
  struct Request { Action action; uint32_t token;
    Request(Action a=Action::None,uint32_t t=0):action(a),token(t){}
  };

  bool load_snapshot(const MeshSnapshot& s) {
    if (state_!=State::Idle || !isfinite(s.zoffset) ||
        !isfinite(s.origin_x) || !isfinite(s.origin_y) ||
        !isfinite(s.pitch_x) || !isfinite(s.pitch_y) ||
        s.pitch_x<=0 || s.pitch_y<=0) return false;
    memcpy(&original_,&s,sizeof(s));
    have_snapshot_=true;
    return true;
  }
  Request start(uint32_t now,const Inputs& v) {
    if(state_!=State::Idle || !have_snapshot_)return {};
    if (!preflight(v)) { fail_immediate(classify(v)); return {}; }
    if(!good_offset(v)) {fail_immediate(Error::ZOffsetChanged);return {};}
    if(!thermal_input_valid(v)) {fail_immediate(Error::Heater);return {};}
    ++token_;
    if(token_==0) ++token_;
    count_=0; stable_=false; accepted_setpoint_=false;
    for(unsigned i=0;i<Points;++i){ candidate_[i]=NAN; display_.point[i]=Pixel::Empty; }
    display_.measured=0;
    started_=stage_started_=now;
    state_=State::AwaitHeatAck;
    set_display(v);
    return {Action::Heat60,token_};
  }
  Request acknowledge_heat(uint32_t token,uint32_t now,bool accepted,const Inputs& v) {
    if(!is_current(token) || state_!=State::AwaitHeatAck)return {};
    if(v.abort_requested)return abort_with_error(Error::UserCancel,true);
    if(elapsed(now,stage_started_)>30000u) return abort_with_error(Error::HeatAckTimeout);
    if(!accepted || !good_runtime(v) || !good_offset(v))return abort_with_error(Error::Heater);
    if(!thermal_input_valid(v) || fabsf(v.setpoint-60.f)>0.01f)
      return abort_with_error(Error::Heater);
    accepted_setpoint_=true; stable_=false; state_=State::Heating; stage_started_=now;
    set_display(v);return {};
  }
  Request poll(uint32_t now,const Inputs& v) {
    set_display(v);
    if(!active())return {};
    if(v.abort_requested)return abort_with_error(Error::UserCancel,true);
    if(!good_runtime(v))return abort_with_error(classify(v));
    if(!good_offset(v))return abort_with_error(Error::ZOffsetChanged);
    if(!thermal_input_valid(v))return abort_with_error(Error::Heater);
    if(state_==State::AwaitHeatAck){
      if(elapsed(now,stage_started_)>30000u) return abort_with_error(Error::HeatAckTimeout);
      return {};
    }
    if(fabsf(v.setpoint-60.f)>0.01f)return abort_with_error(Error::ThermalDeviation);
    if(state_==State::Heating){
      if(elapsed(now,started_)>720000u)return abort_with_error(Error::HeatTimeout);
      if(fabsf(v.bed-60.f)<=1.f){
        if(!stable_){stable_=true;stable_since_=now;}
        if(elapsed(now,stable_since_)>=20000u){
          if(v.motion_active || v.queued_gcode || !v.probe_stowed)
            return abort_with_error(Error::Busy);
          state_=State::Homing;stage_started_=now;set_display(v);
          return {Action::HomeXYZ,token_};
        }
      }else stable_=false;
    }else{
      if(fabsf(v.bed-60.f)>1.f)return abort_with_error(Error::ThermalDeviation);
      if(state_==State::Homing && elapsed(now,stage_started_)>180000u)
        return abort_with_error(Error::HomeTimeout);
      if(state_==State::Probing && elapsed(now,stage_started_)>900000u)
        return abort_with_error(Error::ProbeTimeout);
    }
    return {};
  }
  Request homing_complete(uint32_t token,uint32_t now,bool success,const Inputs& v) {
    if(!is_current(token) || state_!=State::Homing)return {};
    if(v.abort_requested)return abort_with_error(Error::UserCancel,true);
    if(elapsed(now,stage_started_)>180000u)return abort_with_error(Error::HomeTimeout);
    if(!success || !v.xyz_homed || v.motion_active || v.queued_gcode || !v.probe_stowed)
      return abort_with_error(Error::Unsafe);
    if(!good_runtime(v) || !good_offset(v) || !thermal_near60(v))
      return abort_with_error(Error::Unsafe);
    state_=State::Probing;stage_started_=now;set_display(v);
    return {Action::ProbeG29U,token_};
  }
  bool probe_sample(uint32_t token,uint8_t point,float fast,float slow,const Inputs& v,uint32_t now) {
    if(!is_current(token) || state_!=State::Probing)return false;
    if(elapsed(now,stage_started_)>900000u){abort_with_error(Error::ProbeTimeout);return false;}
    if(v.abort_requested){abort_with_error(Error::UserCancel,true);return false;}
    if(!good_runtime(v) || !good_offset(v) || !thermal_near60(v)){
      abort_with_error(Error::Unsafe);return false;
    }
    if(point != count_ || point>=Points){abort_with_error(Error::SampleOrder);return false;}
    if(!isfinite(fast)||!isfinite(slow)||fabsf(fast)>3.f||fabsf(slow)>3.f){
      display_.point[count_]=Pixel::Invalid;
      abort_with_error(Error::InvalidSample);return false;
    }
    if(fabsf(fast-slow)>0.06f){
      display_.point[count_]=Pixel::Mismatch;
      abort_with_error(Error::ProbeSpread);return false;
    }
    candidate_[count_]=(2.f*fast+3.f*slow)*0.2f;
    display_.point[count_]=Pixel::Valid;
    display_.measured=++count_;
    return true;
  }
  Request probing_complete(uint32_t token,bool success,const float* measured,
                           bool stow_confirmed,const Inputs& v,uint32_t now) {
    if(!is_current(token) || state_!=State::Probing)return {};
    if(elapsed(now,stage_started_)>900000u)return abort_with_error(Error::ProbeTimeout);
    if(v.abort_requested)return abort_with_error(Error::UserCancel,true);
    if(!success)return abort_with_error(Error::G29Failed);
    if(!stow_confirmed || !v.probe_stowed)return abort_with_error(Error::ProbeNotStowed);
    if(!good_runtime(v) || !good_offset(v) || !thermal_near60(v))
      return abort_with_error(Error::Unsafe);
    if(count_!=Points || !measured)return abort_with_error(Error::Incomplete);
    for(unsigned i=0;i<Points;++i)
      if(!isfinite(measured[i]) || fabsf(measured[i]-candidate_[i])>0.0001f)
        return abort_with_error(Error::MeshMismatch);
    state_=State::FinishedRam;display_.phase=state_;
    return {Action::FinishedRamOnly,token_};
  }
  Request cancel(uint32_t token){
    if(!is_current(token) || !active())return {};
    return abort_with_error(Error::UserCancel,true);
  }
  // Safety: never restore RAM while movement or queued G-codes may still
  // modify leveling or the head is physically probing. The runtime adapter
  // MUST perform independent motor stop + native BLTouch stow beforehand.
  Request quiesced(uint32_t token,const Inputs& v) {
    if(!is_current(token) || state_!=State::Quiescing)return {};
    if(v.motion_active || v.queued_gcode || !v.probe_stowed || v.print_active ||
       v.print_paused || v.marlin_stopped)
      return {};
    state_=State::RestoringRam;display_.phase=state_;
    return {Action::RestoreOldRam,token_};
  }
  bool restored(uint32_t token,bool exact_ram_restore) {
    if(!is_current(token) || state_!=State::RestoringRam)return false;
    if(!exact_ram_restore){state_=State::Failed;error_=Error::RestoreFailed;display_.error=error_;return false;}
    state_=was_cancelled_?State::Cancelled:State::Failed;
    display_.phase=state_;
    return true;
  }
  bool original_for_rollback(uint32_t token,MeshSnapshot& destination)const{
    if(!is_current(token)||state_!=State::RestoringRam||!have_snapshot_)return false;
    memcpy(&destination,&original_,sizeof(destination));return true;
  }
  // A new run requires an explicit reset and fresh snapshot. Neither a
  // pending rollback nor a moving/stopped printer may be silently reset.
  bool reset_for_new_run(const Inputs& v) {
    if (state_!=State::FinishedRam && state_!=State::Failed && state_!=State::Cancelled)
      return false;
    if (v.motion_active || v.queued_gcode || !v.probe_stowed || v.print_active ||
        v.print_paused || v.marlin_stopped) return false;
    ++token_;
    if(token_==0)++token_;
    state_=State::Idle;error_=Error::None;have_snapshot_=false;
    display_=Display{};
    count_=0;stable_=false;accepted_setpoint_=false;was_cancelled_=false;
    return true;
  }
  uint32_t token()const{return token_;}
  State state()const{return state_;}
  Error error()const{return error_;}
  unsigned completed()const{return count_;}
  const Display& display()const{return display_;}
  bool active()const{return state_==State::AwaitHeatAck||state_==State::Heating||state_==State::Homing||state_==State::Probing;}
  bool allow_eeprom_write()const{return false;}
  bool has_verified_physical_park()const{return false;} // cannot assert from firmware coordinate
  float candidate(unsigned point)const{return point<Points?candidate_[point]:NAN;}
private:
  bool is_current(uint32_t t)const{return t!=0 && t==token_;}
  static uint32_t elapsed(uint32_t now,uint32_t start){return now-start;}
  static bool thermal_input_valid(const Inputs&v){return isfinite(v.bed)&&isfinite(v.setpoint)&&v.bed>=0.f&&v.bed<=115.f;}
  bool good_offset(const Inputs& v)const{return isfinite(v.zoffset) && fabsf(v.zoffset-original_.zoffset)<=0.00001f;}
  static bool unsafe_idle(const Inputs&v){return v.marlin_stopped||v.print_active||v.print_paused;}
  static bool good_runtime(const Inputs&v){
    return !unsafe_idle(v) && v.t0_active && v.t1_homed && v.t1_park_physically_confirmed &&
      v.auto_park_mode && v.bltouch_healthy && v.heater_healthy;
  }
  static bool preflight(const Inputs&v){
    return good_runtime(v) && !v.motion_active && !v.queued_gcode &&
      v.probe_stowed && !v.abort_requested;
  }
  static Error classify(const Inputs&v){
    if(v.marlin_stopped || !v.heater_healthy || !v.bltouch_healthy)return Error::Unsafe;
    if(v.print_active || v.print_paused || v.motion_active || v.queued_gcode)return Error::Busy;
    if(!v.t0_active || !v.t1_homed || !v.t1_park_physically_confirmed || !v.auto_park_mode)return Error::UnsafeT1;
    return Error::Unsafe;
  }
  bool thermal_near60(const Inputs&v)const{
    return thermal_input_valid(v) && fabsf(v.bed-60.f)<=1.f && fabsf(v.setpoint-60.f)<=0.01f;
  }
  void set_display(const Inputs&v){
    if(isfinite(v.bed)&&v.bed>=0.f&&v.bed<=115.f)
      display_.bed_x10=static_cast<uint16_t>(v.bed*10.f+.5f);
    if(isfinite(v.setpoint)&&v.setpoint>=0.f&&v.setpoint<=115.f)
      display_.target_x10=static_cast<uint16_t>(v.setpoint*10.f+.5f);
    display_.phase=state_;display_.error=error_;
  }
  Request abort_with_error(Error e,bool cancelled=false){
    error_=e; was_cancelled_=cancelled;
    state_=State::Quiescing;display_.phase=state_;display_.error=e;
    return {Action::RequestSafeStop,token_};
  }
  void fail_immediate(Error e){error_=e;state_=State::Failed;display_.phase=state_;display_.error=e;}
  MeshSnapshot original_{};
  bool have_snapshot_=false,stable_=false,accepted_setpoint_=false,was_cancelled_=false;
  uint32_t token_=0,started_=0,stage_started_=0,stable_since_=0;
  float candidate_[Points]{};
  uint8_t count_=0;
  State state_=State::Idle;
  Error error_=Error::None;
  Display display_{};
};
} // namespace sv04next
