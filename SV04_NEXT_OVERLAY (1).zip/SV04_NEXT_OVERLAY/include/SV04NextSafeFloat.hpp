// SV04 NEXT 11: finite-float check by BIT PATTERN. Independent of -ffast-math / -ffinite-math-only,
// under which isfinite() may be folded to true and silently accept NaN/Inf probe heights or temperatures.
#pragma once
#include <stdint.h>
#include <string.h>
namespace sv04next {
static_assert(sizeof(float) == 4, "SV04 NEXT assumes IEEE-754 binary32 float");
inline bool float_is_finite(float v) {
  uint32_t bits; memcpy(&bits, &v, sizeof(bits));
  return ((bits >> 23) & 0xFFu) != 0xFFu;   // exponent all ones = Inf or NaN
}
} // namespace sv04next
