// SV04 NEXT, experimental RTS/DWIN read-only telemetry address mapping.
// Does not add any HMI resources or define new touch keys.
#pragma once
#include <stdint.h>
#include <math.h>
namespace sv04next {
struct RtsTelemetry final {
  static constexpr uint16_t bed_actual_vp=0x103C;
  static constexpr uint16_t bed_set_vp=0x103A;
  static constexpr uint16_t progress_vp=0x108D;
  static constexpr uint16_t first_mesh_vp=0x1100;
  static constexpr uint16_t last_mesh_vp=0x111E;
  static constexpr unsigned points=16;
  static uint16_t mesh_vp(unsigned sample){return sample<points ? (uint16_t)(first_mesh_vp+2*sample) : 0;}
  static bool valid_progress(unsigned p){return p<=points;}
  static bool encode_mesh_mm(float mm,int16_t &out){
    if (!isfinite(mm) || fabsf(mm)>3.f)return false;
    float scaled=mm*1000.f;
    out=(int16_t)(scaled>=0.f?scaled+0.5f:scaled-0.5f);
    return true;
  }
  static bool encode_bed_c(float value,uint16_t &out){
    if(!isfinite(value) || value<0 || value>115)return false;
    out=(uint16_t)(value+0.5f);
    return true;
  }
};
}
