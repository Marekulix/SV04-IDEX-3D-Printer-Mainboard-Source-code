// SV04 NEXT block 10: native, passive IDEX X-carriage G28 execution trace.
// A homeaxis() RETURN is NOT switch validation or independent physical parking.
// No actuators, G-code execution, heater commands, EEPROM or HMI writes.
#pragma once
#include <stdint.h>

namespace sv04next {
class NativeIdexHomingTrace final {
public:
  enum class State : uint8_t { Never, Active, ReturnedEarly, EndObserved, Invalid };
  enum class Reason : uint8_t { None, NoRun, WrongTool, WrongOrder, ClockInvalid,
                                DuplicateX2, DuplicateX1, Incomplete };
  struct View final {
    uint32_t g28_sequence=0, started_ms=0, ended_ms=0, x2_ms=0, x1_ms=0;
    uint8_t x2_returns=0, x1_returns=0;
    State state=State::Never;
    Reason reason=Reason::NoRun;
    bool both_x_homeaxis_returned=false;
    bool physical_t1_park_proven=false, allow_motion=false, allow_eeprom=false;
  };
  class Scope final {
  public:
    Scope(NativeIdexHomingTrace &trace,uint32_t now,uint32_t seq)
      :trace_(trace),armed_(trace_.begin(now,seq)){}
    ~Scope(){ if(armed_)trace_.early_return(); }
    void finish(uint32_t now){if(armed_){trace_.finish(now);armed_=false;}}
    Scope(const Scope&)=delete;
    Scope& operator=(const Scope&)=delete;
  private:
    NativeIdexHomingTrace &trace_;bool armed_;
  };
  bool begin(uint32_t now,uint32_t sequence){
    if(sequence==0 || view_.state==State::Active){invalidate(Reason::NoRun);return false;}
    view_=View{};view_.g28_sequence=sequence;view_.started_ms=now;
    view_.state=State::Active;view_.reason=Reason::None;return true;
  }
  void saw_x2_homeaxis_return(uint32_t now,uint8_t tool){
    if(view_.state!=State::Active)return;
    if(tool!=1){invalidate(Reason::WrongTool);return;}
    if(view_.x2_returns!=view_.x1_returns){invalidate(Reason::WrongOrder);return;}
    if(view_.x2_returns>=2){invalidate(Reason::DuplicateX2);return;}
    if(!in_time(now)){invalidate(Reason::ClockInvalid);return;}
    ++view_.x2_returns;view_.x2_ms=now;
  }
  void saw_x1_homeaxis_return(uint32_t now,uint8_t tool){
    if(view_.state!=State::Active)return;
    if(tool!=0){invalidate(Reason::WrongTool);return;}
    if(view_.x2_returns!=view_.x1_returns+1u){invalidate(Reason::WrongOrder);return;}
    if(view_.x1_returns>=2){invalidate(Reason::DuplicateX1);return;}
    if(!in_time(now)){invalidate(Reason::ClockInvalid);return;}
    ++view_.x1_returns;view_.x1_ms=now;
  }
  void finish(uint32_t now){
    if(view_.state!=State::Active)return;
    if(!in_time(now)){invalidate(Reason::ClockInvalid);return;}
    view_.ended_ms=now;view_.state=State::EndObserved;
    view_.both_x_homeaxis_returned=view_.x2_returns>0 &&
      view_.x2_returns==view_.x1_returns;
    if(!view_.both_x_homeaxis_returned)view_.reason=Reason::Incomplete;
  }
  void early_return(){
    if(view_.state==State::Active){view_.state=State::ReturnedEarly;
      view_.both_x_homeaxis_returned=false;view_.reason=Reason::Incomplete;}
  }
  const View &view()const{return view_;}
  bool physical_t1_park_proven()const{return false;}
  bool allows_motion()const{return false;}
  bool allows_eeprom()const{return false;}
  static constexpr uint32_t MaxDurationMs=600000u;
private:
  bool in_time(uint32_t now)const{
    return (uint32_t)(now-view_.started_ms)<=MaxDurationMs;
  }
  void invalidate(Reason reason){view_.state=State::Invalid;
    view_.reason=reason;view_.both_x_homeaxis_returned=false;}
  View view_{};
};
extern NativeIdexHomingTrace native_idex_homing_trace;
} // namespace sv04next
