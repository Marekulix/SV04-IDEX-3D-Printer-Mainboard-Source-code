// SV04 NEXT 11.33-11.52: G29 U native result receipt (READ ONLY).
// No actuator commands, no persistence, no DWIN addresses.
// Scope ensures early G29 returns cannot leave a misleading Running/Success
// result. This header does not attest physical T1 position or safe flashability.
#pragma once
#include <stdint.h>
#include <math.h>
#include "SV04NextSafeFloat.hpp"

namespace sv04next {

class G29UReceipt final {
public:
  static constexpr uint8_t Grid = 4;
  static constexpr uint8_t Count = 16;
  // Sanity bound shared with the host models (Auto60Safety, MeshJournal). NOT a calibration limit:
  // |z| above this can only be a probe fault. Rejected as Failure::Sample.
  static constexpr float MaxAbsZmm = 3.0f;
  enum class Phase : uint8_t { Never, Running, Refused, Failed, RamOnlySuccess };
  enum class Failure : uint8_t {
    None, Reentry, Preconditions, EarlyReturn, PointIndex, Duplicate,
    Sample, Incomplete, RunFailed, Temperature, Busy, UnsafeIDEX
  };
  enum class Pixel : uint8_t { Empty, Recorded, Problem };

  class Scope final {
  public:
    Scope(bool enabled, G29UReceipt &target):target_(target),armed_(enabled && target.begin()){}
    ~Scope() { if (armed_ && target_.phase() == Phase::Running)
                 target_.fail(Failure::EarlyReturn); }
    bool armed() const { return armed_; }
    Scope(const Scope &)=delete;
    Scope &operator=(const Scope &)=delete;
  private:
    G29UReceipt &target_;
    bool armed_;
  };

  bool begin() {
    if (phase_ == Phase::Running) return false; // never overwrite active run
    ++sequence_;
    if (sequence_ == 0) ++sequence_;
    phase_ = Phase::Running;
    failure_ = Failure::None;
    count_ = 0;
    mask_ = 0;
    for (uint8_t i=0; i<Count; ++i) {
      z_[i] = NAN;
      pixel_[i] = Pixel::Empty;
    }
    return true;
  }
  bool point(uint8_t x, uint8_t y, float z) {
    if (phase_ != Phase::Running) return false;
    if (x >= Grid || y >= Grid) return fail(Failure::PointIndex);
    const uint8_t index = (uint8_t)(y * Grid + x);
    const uint16_t bit = (uint16_t)(1u << index);
    if (mask_ & bit) {
      pixel_[index] = Pixel::Problem;
      return fail(Failure::Duplicate);
    }
    if (!float_is_finite(z) || z > MaxAbsZmm || z < -MaxAbsZmm) {
      pixel_[index] = Pixel::Problem;
      return fail(Failure::Sample);
    }
    mask_ = (uint16_t)(mask_ | bit);
    z_[index] = z;
    pixel_[index] = Pixel::Recorded;
    ++count_;
    return true;
  }
  bool finish_ram_only() {
    if (phase_ != Phase::Running) return false;
    if (mask_ != 0xFFFFu || count_ != Count) return fail(Failure::Incomplete);
    phase_ = Phase::RamOnlySuccess;
    return true;
  }
  bool refuse(Failure why=Failure::Preconditions) {
    if (phase_ != Phase::Running) return false;
    phase_ = Phase::Refused;
    failure_ = why;
    return false;
  }
  bool fail(Failure why=Failure::RunFailed) {
    if (phase_ != Phase::Running) return false;
    phase_ = Phase::Failed;
    failure_ = why;
    return false;
  }
  uint32_t sequence() const { return sequence_; }
  Phase phase() const { return phase_; }
  Failure failure() const { return failure_; }
  uint8_t completed() const { return count_; }
  uint16_t point_mask() const { return mask_; }
  Pixel pixel(uint8_t idx) const { return idx < Count ? pixel_[idx] : Pixel::Problem; }
  float value(uint8_t idx) const { return idx < Count ? z_[idx] : NAN; }
  bool eeprom_authorized() const { return false; }
  bool hardware_verified() const { return false; }
private:
  Phase phase_ = Phase::Never;
  Failure failure_ = Failure::None;
  uint32_t sequence_ = 0;
  uint16_t mask_ = 0;
  uint8_t count_ = 0;
  float z_[Count] = {};
  Pixel pixel_[Count] = {};
};

// Defined in G29.cpp when native G29 U is compiled; accessible to future
// UI adapters without granting those adapters permission to save EEPROM.
extern G29UReceipt g29u_receipt;

} // namespace sv04next
