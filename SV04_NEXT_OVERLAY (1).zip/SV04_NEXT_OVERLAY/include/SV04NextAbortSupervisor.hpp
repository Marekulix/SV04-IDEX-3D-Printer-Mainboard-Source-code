// SV04 NEXT - passive supervisor combining command state, cancellation, and trace.
// Reads results from other components, but never dispatches Marlin G-code.
#pragma once
#include <stdint.h>
#include "SV04NextOperationLedger.hpp"
#include "SV04NextAbortQuarantine.hpp"
#include "SV04NextFaultTrace.hpp"
namespace sv04next {
class AbortSupervisor final {
public:
  enum class Phase : uint8_t { Idle, Monitoring, Aborted, Closed };
  bool attach(uint32_t run,uint32_t now){
    if(phase_!=Phase::Idle || !run || !barrier_.attach_run(run) || !trace_.begin(run,now))return false;
    run_=run;phase_=Phase::Monitoring;return true;
  }
  // Legacy callbacks cannot be trusted once revoked; even when they report success.
  bool observe_ledger(uint32_t run,uint32_t now,const OperationLedger &ledger){
    if(phase_!=Phase::Monitoring || run!=run_)return false;
    if(ledger.phase()==OperationLedger::Phase::Locked){
      abort(run,now,AbortQuarantine::Cause::PlannerFault,(uint16_t)ledger.failure());
      return false;
    }
    return true;
  }
  AbortQuarantine::Token abort(uint32_t run,uint32_t now,AbortQuarantine::Cause c,uint16_t code=0){
    if(phase_!=Phase::Monitoring || run!=run_)return AbortQuarantine::Token{};
    auto t=barrier_.abort(run,now,c);
    if(!t.valid())return t;
    phase_=Phase::Aborted;
    trace_.record(run,now,FaultTrace::Event::SafetyTrip,0,code);
    trace_.record(run,now,FaultTrace::Event::StopRequested,0,code);
    // Event is an advisory to the future native emergency adapter. It does NOT stop hardware.
    return t;
  }
  bool sample(uint32_t run,uint32_t now,const AbortQuarantine::Sample &s){
    if(phase_!=Phase::Aborted || run!=run_)return false;
    auto before=barrier_.state();
    bool ok=barrier_.sample(barrier_.token(),now,s);
    if(ok && before!=AbortQuarantine::State::StableQuiet &&
       barrier_.state()==AbortQuarantine::State::StableQuiet)
      trace_.record(run,now,FaultTrace::Event::Quiescent,0,0);
    return ok;
  }
  bool acknowledge(uint32_t run,uint32_t now,bool explicit_user){
    if(phase_!=Phase::Aborted || run!=run_)return false;
    if(!barrier_.operator_ack(barrier_.token(),now,explicit_user))return false;
    trace_.record(run,now,FaultTrace::Event::OperatorReviewed,0,0);
    return true;
  }
  bool close(uint32_t run,uint32_t now){
    if(phase_!=Phase::Aborted || run!=run_ || !barrier_.retire(barrier_.token(),now))return false;
    phase_=Phase::Closed;
    trace_.record(run,now,FaultTrace::Event::RecoveryClosed,0,0);
    return true;
  }
  Phase phase()const{return phase_;}
  const AbortQuarantine &barrier()const{return barrier_;}
  const FaultTrace &trace()const{return trace_;}
  bool authorizes_gcode()const{return false;}
  bool authorizes_eeprom()const{return false;}
  bool authorizes_auto_restart()const{return false;}
private:
  AbortQuarantine barrier_{};
  FaultTrace trace_{};
  uint32_t run_=0;
  Phase phase_=Phase::Idle;
};
}
