// SV04 NEXT - offline abort containment / supervised recovery MODEL.
// Never acts on motors, heaters, queue, RAM or EEPROM. It cannot stop a moving printer.
// The host must implement physical emergency handling independently.
#pragma once
#include <stdint.h>

namespace sv04next {
class AbortQuarantine final {
public:
  enum class State : uint8_t { Uninitialized, Active, Quarantined, StableQuiet, OperatorConfirmed, Retired };
  enum class Cause : uint8_t { None, UserCancel, SensorFault, ThermalFault, G28Fault,
                               G29Fault, StaleEvidence, OffsetChanged, PlannerFault, Unknown };
  struct Sample {
    bool valid=false, printer_stopped=false, printing=false, paused=false;
    bool planner_idle=false, queue_empty=false, movement_idle=false, probe_stowed=false;
    bool bed_target_zero=false, heater_command_idle=false;
    bool offset_unchanged=false, prior_mesh_restored=false;
    bool t1_physical_park_verified=false;
  };
  struct Token { uint32_t run=0, incident=0;
    bool valid() const { return run!=0 && incident!=0; }
  };
  static constexpr uint32_t MaxSampleGapMs=1000;
  static constexpr uint32_t StableQuietMs=5000;

  // A new live run begins only from an independent trusted context. No motion is authorized.
  bool attach_run(uint32_t run){
    if(!run || state_!=State::Uninitialized)return false;
    run_=run;state_=State::Active;return true;
  }
  Token abort(uint32_t run, uint32_t now, Cause cause){
    if(!run || run!=run_ || state_!=State::Active || cause==Cause::None)return Token{};
    ++incident_;if(!incident_)++incident_;
    token_.run=run_;token_.incident=incident_; cause_=cause;state_=State::Quarantined;
    last_=now;since_=now;last_valid_=false;acknowledged_=false;
    return token_;
  }
  // Aborting again is a no-op; do not issue new generation IDs for duplicate UI events.
  bool sample(const Token &t, uint32_t now,const Sample &s){
    if(!same(t) || state_==State::Active || state_==State::Uninitialized ||
       state_==State::Retired)return false;
    const uint32_t gap=(uint32_t)(now-last_);
    last_=now;
    if(!s.valid || gap>MaxSampleGapMs || !quiescent(s)){
      state_=State::Quarantined; last_valid_=false;acknowledged_=false;
      return false;
    }
    if(!last_valid_){
      since_=now; last_valid_=true; state_=State::Quarantined;
      acknowledged_=false;
    }
    if((uint32_t)(now-since_)>=StableQuietMs){
      state_=acknowledged_?State::OperatorConfirmed:State::StableQuiet;
    }
    return true;
  }
  // Must follow a fresh quiet window. Caller must source this from a deliberate human action,
  // never from a timer, endstop, G28 ACK, or screen refresh.
  bool operator_ack(const Token &t, uint32_t now, bool explicit_operator_action){
    if(!same(t) || state_!=State::StableQuiet || !explicit_operator_action ||
       (uint32_t)(now-last_)>MaxSampleGapMs)return false;
    acknowledged_=true;state_=State::OperatorConfirmed;return true;
  }
  // Closure of the old incident does NOT permit motor, heater, EEPROM, or new auto runs.
  bool retire(const Token &t,uint32_t now){
    if(!same(t) || state_!=State::OperatorConfirmed ||
       (uint32_t)(now-last_)>MaxSampleGapMs)return false;
    state_=State::Retired;return true;
  }
  bool accepts_old_callback(uint32_t)const{return false;}
  bool permits_automatic_restart()const{return false;}
  bool permits_motion()const{return false;}
  bool permits_heating()const{return false;}
  bool permits_eeprom()const{return false;}
  bool stop_has_physically_occurred()const{return false;}
  bool recovery_recorded()const{return state_==State::Retired;}
  bool blocked()const{return state_!=State::Active;}
  State state()const{return state_;}
  Cause cause()const{return cause_;}
  Token token()const{return token_;}
private:
  static bool quiescent(const Sample &s){return !s.printer_stopped && !s.printing && !s.paused &&
    s.planner_idle && s.queue_empty && s.movement_idle && s.probe_stowed &&
    s.bed_target_zero && s.heater_command_idle && s.offset_unchanged &&
    s.prior_mesh_restored && s.t1_physical_park_verified;}
  bool same(const Token &t)const{return t.valid() && t.run==token_.run && t.incident==token_.incident;}
  uint32_t run_=0,incident_=0,last_=0,since_=0;
  State state_=State::Uninitialized;
  Cause cause_=Cause::None;
  Token token_{};
  bool last_valid_=false,acknowledged_=false;
};
} // namespace sv04next
