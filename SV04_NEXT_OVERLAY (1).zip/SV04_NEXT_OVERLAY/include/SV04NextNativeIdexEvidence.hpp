// SV04 NEXT block 10: combines native G28 RAII result with actual X2/X1
// homeaxis-return path. Observational only; not a collision safety certificate.
#pragma once
#include <stdint.h>
#include "SV04NextNativeIdexHomingTrace.hpp"
#include "SV04NextG28PassiveReceipt.hpp"
#include "SV04NextT1CorrelationAudit.hpp"
#include "SV04NextG28G29OrderWitness.hpp"
namespace sv04next {
class NativeIdexEvidence final {
public:
  enum class Reason : uint8_t { NoG28, Running, EarlyReturn, WrongSequence,
    IncompleteXCarriages, G28Untrusted, Stale, ElectricalOnly, NoSwitchCorrelation };
  struct Frame final {
    Reason reason=Reason::NoG28;
    uint32_t g28_sequence=0, x2_ms=0, x1_ms=0;
    uint8_t x2_returns=0,x1_returns=0;
    bool both_x_homeaxis_returned=false, electrical_correlated=false;
    bool g28_xyz_trusted=false, g29_ram_complete=false;
    bool t1_physically_parked=false, allow_motion=false, allow_heat=false, allow_eeprom=false;
  };
  void observe(uint32_t now,const G28PassiveReceipt::View &g28,
       const NativeIdexHomingTrace::View &trace,
       const T1CorrelationAudit::Result &sw,
       const G28G29OrderWitness::Frame &order){
    frame_=Frame{};frame_.g28_sequence=g28.sequence;
    if(!g28.sequence)return;
    if(g28.phase==G28PassiveReceipt::Phase::Entered ||
       trace.state==NativeIdexHomingTrace::State::Active){frame_.reason=Reason::Running;return;}
    if(g28.phase==G28PassiveReceipt::Phase::ReturnedEarly ||
       trace.state==NativeIdexHomingTrace::State::ReturnedEarly ||
       g28.phase==G28PassiveReceipt::Phase::ClockInvalid){frame_.reason=Reason::EarlyReturn;return;}
    if(trace.g28_sequence!=g28.sequence || trace.state==NativeIdexHomingTrace::State::Invalid){
      frame_.reason=Reason::WrongSequence;return;
    }
    frame_.x2_returns=trace.x2_returns;frame_.x1_returns=trace.x1_returns;
    frame_.x2_ms=trace.x2_ms;frame_.x1_ms=trace.x1_ms;
    if(!trace.both_x_homeaxis_returned){frame_.reason=Reason::IncompleteXCarriages;return;}
    frame_.both_x_homeaxis_returned=true;
    if(g28.phase!=G28PassiveReceipt::Phase::EndObservedTrusted ||
       !g28.xyz_trusted || !g28.tool0){frame_.reason=Reason::G28Untrusted;return;}
    frame_.g28_xyz_trusted=true;
    if((uint32_t)(now-g28.ended_ms)>MaxAgeMs){frame_.reason=Reason::Stale;return;}
    frame_.g29_ram_complete=order.quality==G28G29OrderWitness::Quality::OrderObserved &&
       order.g28_sequence==g28.sequence && order.ram_only_g29_16;
    frame_.electrical_correlated=sw.homing_sequence==g28.sequence &&
       sw.electrical_correlation;
    frame_.reason=frame_.electrical_correlated?Reason::ElectricalOnly:Reason::NoSwitchCorrelation;
    // Even a perfectly correlated X_MAX switch edge is electrical evidence only.
    frame_.t1_physically_parked=false;
    frame_.allow_motion=false;frame_.allow_heat=false;frame_.allow_eeprom=false;
  }
  const Frame &view()const{return frame_;}
  bool physical_t1_park_proven()const{return false;}
  bool permits_motion()const{return false;}
  bool permits_heating()const{return false;}
  bool permits_eeprom()const{return false;}
  static constexpr uint32_t MaxAgeMs=120000u;
private:Frame frame_{};
};
extern NativeIdexEvidence native_idex_evidence;
} // namespace sv04next
