// SV04 NEXT 7: RAM-ONLY, versioned 32-byte diagnostic snapshot.
// This is NOT a DWIN protocol or VP map and sends NOTHING to the display.
// No motor, heater, G-code queue, probe command, EEPROM or IO access.
#pragma once
#include <stdint.h>
#include "SV04NextNativeEventTimeline.hpp"

namespace sv04next {
class NativeStatusPacket final {
public:
  static constexpr uint8_t Size = 32u;
  static constexpr uint8_t Version = 1u;
  static constexpr uint32_t FreshnessMs = 250u;
  enum class Display : uint8_t {
    NoData=0, Idle=1, Measuring=2, RamComplete=3,
    Refused=4, Failed=5, Invalid=6
  };
  enum class Reason : uint8_t {
    None=0, NotObserved=1, SamplingGap=2, ClockReset=3,
    Malformed=4, Stale=5, CrossRun=6, InvalidProgress=7,
    NotStarted=8
  };

  // Compose from the native *read-only* objects. No callback, no IO.
  // A gate that reports NoPhysicalT1Witness NEVER becomes a safety approval.
  void capture(uint32_t now, const NativeReadiness::View &readiness,
               const NativeEventTimeline::Frame &timeline,
               const T1EndstopObserver &sensor) {
    for (uint8_t i=0;i<Size;++i) data_[i]=0;
    data_[0]='S'; data_[1]='7'; data_[2]=Version; data_[3]=Size;
    put32(4,now);
    put32(8,timeline.run);
    put16(12,timeline.mask);
    data_[14]=timeline.count;
    data_[15]=(uint8_t)timeline.quality;
    data_[16]=(uint8_t)readiness.gate;
    data_[17]=(uint8_t)readiness.receipt_phase;
    data_[18]=(uint8_t)readiness.receipt_failure;
    data_[19]=(uint8_t)sensor.state();
    put32(24,timeline.observations);
    put16(28,(uint16_t)(timeline.electrical_edges>65535u?65535u:timeline.electrical_edges));

    reason_=Reason::None;
    state_=Display::NoData;
    const NativeEventTimeline::Quality q=timeline.quality;
    if (!readiness.observed || q==NativeEventTimeline::Quality::Never ||
        q==NativeEventTimeline::Quality::SourceMissing)
      reason_=Reason::NotObserved;
    else if(q==NativeEventTimeline::Quality::Gap)
      reason_=Reason::SamplingGap;
    else if(q==NativeEventTimeline::Quality::ClockBackwards)
      reason_=Reason::ClockReset;
    else if(q==NativeEventTimeline::Quality::CorruptReceipt)
      reason_=Reason::Malformed;
    else if (!fresh(now,readiness.last_sample_ms) ||
             !fresh(now,timeline.observed_ms))
      reason_=Reason::Stale;
    else if (readiness.g29_run_id!=timeline.run ||
             readiness.valid_mask!=timeline.mask ||
             readiness.measured!=timeline.count)
      reason_=Reason::CrossRun;
    else if (timeline.count>16 || popcount(timeline.mask)!=timeline.count)
      reason_=Reason::InvalidProgress;
    else if (timeline.run==0) {
      if (readiness.receipt_phase==G29UReceipt::Phase::Never && !timeline.count && !timeline.mask)
        state_=Display::Idle;
      else reason_=Reason::NotStarted;
    }
    else {
      switch(readiness.receipt_phase) {
        case G29UReceipt::Phase::Running:
          state_=Display::Measuring;break;
        case G29UReceipt::Phase::Refused:
          state_=Display::Refused;break;
        case G29UReceipt::Phase::Failed:
          state_=Display::Failed;break;
        case G29UReceipt::Phase::RamOnlySuccess:
          if (timeline.receipt_16_ram && readiness.ram_mesh_16_of_16 &&
              timeline.count==16 && timeline.mask==0xFFFFu)
            state_=Display::RamComplete;
          else reason_=Reason::InvalidProgress;
          break;
        case G29UReceipt::Phase::Never:
          reason_=Reason::NotStarted;break;
      }
    }
    if (reason_!=Reason::None)state_=Display::Invalid;
    data_[20]=(uint8_t)state_;
    data_[21]=(uint8_t)reason_;
    // Diagnostic flags are observational only. No bit can grant actuation.
    // bit 0 = completed in RAM, bit 1 = stable electrical X_MAX contact,
    // bit 2 = source observed. All three may be true without physical approval.
    data_[22]= (uint8_t)((state_==Display::RamComplete?1u:0u) |
                        (sensor.electrical_edge_observed(now)?2u:0u) |
                        (readiness.observed?4u:0u));
    // data_[23] reserved 0; no permission or physical-park bit!
    put16(30,crc16(data_,30));
  }
  const uint8_t *bytes()const{return data_;}
  Display display()const{return state_;}
  Reason reason()const{return reason_;}
  bool permits_motion()const{return false;}
  bool permits_heating()const{return false;}
  bool permits_eeprom()const{return false;}
  bool is_physical_park_verified()const{return false;}

  static bool verify(const uint8_t *p,uint8_t n) {
    if(!p || n!=Size || p[0]!='S' || p[1]!='7' || p[2]!=Version ||
       p[3]!=Size || p[23]!=0u || (p[22]&0xF8u)!=0u ||
       p[20]>(uint8_t)Display::Invalid || p[21]>(uint8_t)Reason::NotStarted ||
       p[15]>(uint8_t)NativeEventTimeline::Quality::CorruptReceipt ||
       p[19]>(uint8_t)T1EndstopObserver::State::Stale ||
       p[14]>16u)return false;
    const bool completed=p[20]==(uint8_t)Display::RamComplete;
    if(((p[22]&1u)!=0u)!=completed ||
       (p[20]==(uint8_t)Display::Invalid)!=(p[21]!=(uint8_t)Reason::None))
      return false;
    if(completed && (p[14]!=16u || p[12]!=0xFFu || p[13]!=0xFFu ||
       p[17]!=(uint8_t)G29UReceipt::Phase::RamOnlySuccess))return false;
    return crc16(p,30)==(uint16_t)(p[30] | ((uint16_t)p[31]<<8));
  }
  static uint16_t crc16(const uint8_t *buf,uint8_t n){
    uint16_t c=0xFFFFu;
    for(uint8_t i=0;i<n;++i){
      c=(uint16_t)(c^((uint16_t)buf[i]<<8));
      for(uint8_t bit=0;bit<8;++bit)
        c=(uint16_t)((c&0x8000u)?((c<<1)^0x1021u):(c<<1));
    }
    return c;
  }
private:
  static bool fresh(uint32_t now,uint32_t then){
    const uint32_t dt=(uint32_t)(now-then);
    return dt<=FreshnessMs; // Valid across millis() wrap, backwards fails closed.
  }
  static uint8_t popcount(uint16_t x){
    uint8_t r=0;while(x){r=(uint8_t)(r+(x&1u));x>>=1;}return r;
  }
  void put16(uint8_t i,uint16_t x){data_[i]=(uint8_t)x;data_[i+1]=(uint8_t)(x>>8);}
  void put32(uint8_t i,uint32_t x){
    for(uint8_t j=0;j<4;++j)data_[i+j]=(uint8_t)(x>>(8u*j));
  }
  uint8_t data_[Size]={};
  Display state_=Display::NoData;
  Reason reason_=Reason::NotObserved;
};
extern NativeStatusPacket native_status_packet;
} // namespace sv04next
