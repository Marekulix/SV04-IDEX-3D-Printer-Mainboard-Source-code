// SV04 NEXT: single read-only Auto60/DWIN view source, no VP/HMI writes.
// NOTE: color is only proposed until the original DWIN project is available.
#pragma once
#include "SV04NextSequencedController.hpp"
#include "SV04NextG29UDisplayFrame.hpp"
#include "SV04NextReceiptBinder.hpp"
#include <stdint.h>
#include <math.h>
namespace sv04next {
class Auto60ViewModel final {
public:
  using Controller=SequencedController;
  enum class Screen : uint8_t {
    Idle, Blocked, Heating, Homing, Measuring, Stopping, Restoring,
    RamVerified, Failed, Cancelled
  };
  struct Cell {
    DwinView::Color color=DwinView::Color::Gray;
    float z=NAN;
  };
  struct Frame {
    Screen screen=Screen::Idle;
    uint8_t measured=0, percent=0;
    uint16_t bed_x10=0,target_x10=0;
    uint32_t run_id=0;
    Controller::Error error=Controller::Error::None;
    bool user_cancelled=false;
    bool ram_only_16_of_16=false;
    bool physical_park_verified=false; // Never infer from X2 coordinates/switch alone
    bool eeprom_saved=false;
    bool touch_button_integrated=false;
    Cell cell[16];
  };
  static Frame make(const Controller &c,const G29UReceipt &receipt,
                    const ReceiptBinder &bound,bool physical_park_proven){
    Frame out;
    out.run_id=c.token();
    out.error=c.error();
    out.measured=c.display().measured;
    out.bed_x10=c.display().bed_x10;
    out.target_x10=c.display().target_x10;
    out.physical_park_verified=physical_park_proven;
    switch(c.state()){
      case Controller::State::Idle:out.screen=Screen::Idle;break;
      case Controller::State::AwaitHeatAck:
      case Controller::State::Heating:out.screen=Screen::Heating;break;
      case Controller::State::Homing:out.screen=Screen::Homing;break;
      case Controller::State::Probing:out.screen=Screen::Measuring;break;
      case Controller::State::Quiescing:out.screen=Screen::Stopping;break;
      case Controller::State::RestoringRam:out.screen=Screen::Restoring;break;
      case Controller::State::FinishedRam:out.screen=Screen::RamVerified;break;
      case Controller::State::Failed:out.screen=Screen::Failed;break;
      case Controller::State::Cancelled:out.screen=Screen::Cancelled;out.user_cancelled=true;break;
    }
    // Both sources MUST confirm the same run: the controller's terminal
    // state and the binder's native 16/16 receipt. No receipt, no green map.
    out.ram_only_16_of_16 = c.state()==Controller::State::FinishedRam &&
      bound.ram_complete() && physical_park_proven &&
      G29UDisplayFrame::success(receipt) &&
      receipt.sequence()==bound.native_sequence();
    if (out.ram_only_16_of_16) {
      out.measured=16;out.percent=100;
    } else {
      if(out.measured>16)out.measured=16;
      out.percent=(uint8_t)((unsigned)out.measured*100u/16u);
      // 100% is reserved for a verified native full-run receipt.
      if(out.percent==100)out.percent=99;
      if(out.screen==Screen::RamVerified)out.screen=Screen::Blocked;
    }
    for(uint8_t i=0;i<16;++i){
      if(receipt.pixel(i)==G29UReceipt::Pixel::Problem){
        out.cell[i].color=DwinView::Color::Red;continue;
      }
      if(receipt.pixel(i)!=G29UReceipt::Pixel::Recorded)continue;
      if(receipt.sequence()!=bound.native_sequence() || !bound.native_sequence())continue;
      out.cell[i].z=receipt.value(i);
      out.cell[i].color=out.ram_only_16_of_16 ?
        G29UDisplayFrame::pixel(receipt,(uint8_t)(i%4),(uint8_t)(i/4)) :
        DwinView::Color::Yellow;
    }
    return out;
  }
  static constexpr bool writes_dwin_vp(){return false;}
  static constexpr bool controls_heaters(){return false;}
  static constexpr bool saves_eeprom(){return false;}
};
} // namespace sv04next
