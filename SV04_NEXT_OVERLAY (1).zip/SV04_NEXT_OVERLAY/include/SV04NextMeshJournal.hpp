// SV04 NEXT: transactional 4x4 mesh preparation (host-verified model).
// This file performs NO real motion, heating or EEPROM writes.
#pragma once
#include <stdint.h>
#include <math.h>
#include <string.h>

namespace sv04next {

class MeshJournal final {
public:
  enum class Stage : uint8_t { Idle, Measuring, Validated, Saving, Verify, Done, Failed, Aborted };
  enum class Problem : uint8_t { None, Order, Invalid, Disagreement, Temperature, Incomplete, G29Failed, SaveFailed, VerifyFailed, AbortedByUser };
  static constexpr uint8_t points = 16;
  static constexpr float max_disagreement_mm = 0.06f;
  static constexpr float max_abs_z_mm = 3.0f;

  bool begin(const float *existing, float current_z_offset, bool previous_leveling, bool idle, bool other_head_safe) {
    if (stage_ != Stage::Idle || !existing || !isfinite(current_z_offset) || !idle || !other_head_safe)
      return fail(Problem::Invalid);
    memcpy(previous_, existing, sizeof(previous_)); // Preserve NaN and uninitialized meshes bitwise.
    original_offset_ = current_z_offset;
    original_leveling_ = previous_leveling;
    for (uint8_t i=0; i<points; ++i) proposed_[i]=NAN;
    have_first_=false; next_=0; snapshot_=true;
    stage_=Stage::Measuring;
    return true;
  }
  bool sample(uint8_t index, float z, float bed_c, bool probe_ok, bool heater_ok) {
    if (stage_ != Stage::Measuring || index != next_ || next_ >= points) return fail(Problem::Order);
    if (!heater_ok || !isfinite(bed_c) || bed_c < 59 || bed_c > 61) return fail(Problem::Temperature);
    if (!probe_ok || !isfinite(z) || fabsf(z)>max_abs_z_mm) return fail(Problem::Invalid);
    if (!have_first_) {
      first_=z; have_first_=true;
    } else {
      if (fabsf(first_-z)>max_disagreement_mm) return fail(Problem::Disagreement);
      proposed_[next_]=(first_*2.0f+z*3.0f)*0.2f; // Matches Marlin's fast/slow weighting.
      have_first_=false;
      ++next_;
    }
    return true;
  }
  bool finished(bool g29_success, bool bltouch_stowed, bool x_y_z_trusted,
                bool leveling_enabled, bool other_head_safe, float offset_now) {
    if(stage_!=Stage::Measuring || next_!=points || have_first_)return fail(Problem::Incomplete);
    if(!g29_success||!bltouch_stowed||!x_y_z_trusted||!leveling_enabled||!other_head_safe||
       !isfinite(offset_now)||fabsf(offset_now-original_offset_)>0.00001f) return fail(Problem::G29Failed);
    for (uint8_t i=0;i<points;i++) if(!isfinite(proposed_[i])) return fail(Problem::Incomplete);
    stage_=Stage::Validated;
    return true;
  }
  bool begin_save() {
    if(stage_!=Stage::Validated) return fail(Problem::Order);
    stage_=Stage::Saving; possible_eeprom_change_=true;
    return true;
  }
  bool save_result(bool saved) {
    if(stage_!=Stage::Saving) return fail(Problem::Order);
    if(!saved) return fail(Problem::SaveFailed);
    stage_=Stage::Verify;
    return true;
  }
  bool verified_from_eeprom(bool verified, const float *actual, float offset_after) {
    if(stage_!=Stage::Verify || !actual) return fail(Problem::VerifyFailed);
    if(!verified||!isfinite(offset_after)||fabsf(offset_after-original_offset_)>0.00001f)
      return fail(Problem::VerifyFailed);
    for(uint8_t i=0;i<points;i++) if(!isfinite(actual[i]) || fabsf(actual[i]-proposed_[i])>0.0001f)
      return fail(Problem::VerifyFailed);
    stage_=Stage::Done; possible_eeprom_change_=false; return true;
  }
  // Caller must restore RAM mesh AND its geometry/leveling state from its snapshot.
  // Never auto-overwrite the EEPROM after a failing measurement.
  bool restore_old_ram_mesh(float *dest, float *offset, bool *leveling) const {
    if(!snapshot_ || !dest || !offset || !leveling || stage_==Stage::Done) return false;
    memcpy(dest,previous_,sizeof(previous_));
    *offset=original_offset_; *leveling=original_leveling_;
    return true;
  }
  void cancel() { if(stage_!=Stage::Done && stage_!=Stage::Failed){ stage_=Stage::Aborted; problem_=Problem::AbortedByUser; } }
  Stage stage() const{return stage_;}
  Problem problem() const{return problem_;}
  uint8_t completed() const{return next_;}
  bool allow_eeprom_write() const{return stage_==Stage::Validated;}
  bool possible_eeprom_change() const{return possible_eeprom_change_;}
  float candidate(uint8_t i) const{return i<points?proposed_[i]:NAN;}
private:
  bool fail(Problem p){if(stage_!=Stage::Done){stage_=Stage::Failed;problem_=p;}return false;}
  Stage stage_=Stage::Idle; Problem problem_=Problem::None;
  float previous_[points]={};float proposed_[points]={};
  float first_=0,original_offset_=0;
  uint8_t next_=0;
  bool snapshot_=false,original_leveling_=false,have_first_=false,possible_eeprom_change_=false;
};

} // namespace sv04next
