// SV04 NEXT 9: T1 endstop/G28 temporal correlation, observation ONLY.
// Even a valid electrical correlation is NOT a physical parking proof.
#pragma once
#include <stdint.h>
#include "SV04NextT1EndstopObserver.hpp"
#include "SV04NextG28PassiveReceipt.hpp"
namespace sv04next {
class T1CorrelationAudit final {
public:
  enum class Reason : uint8_t { NoHoming, HomingRunning, G28Interrupted, G28Untrusted,
                                NoFreshSwitchEdge, SwitchStale, OrderInvalid,
                                TemporalCorrelationOnly };
  struct Result { Reason reason=Reason::NoHoming; uint32_t homing_sequence=0;
    uint32_t switch_epoch=0; bool electrical_correlation=false;
    bool physical_park_verified=false, motion_allowed=false, eeprom_allowed=false; };
  void observe(uint32_t now,const G28PassiveReceipt::View &h,
               const T1EndstopObserver &sw) {
    result_.electrical_correlation=false; result_.switch_epoch=0;
    const bool changed=h.sequence!=last_h_;
    if(changed) { last_h_=h.sequence; baseline_edge_=sw.edge_epochs();
      baseline_set_=true; result_=Result{}; result_.homing_sequence=h.sequence; }
    if(h.sequence==0){result_.reason=Reason::NoHoming;return;}
    if(h.phase==G28PassiveReceipt::Phase::Entered){result_.reason=Reason::HomingRunning;return;}
    if(h.phase==G28PassiveReceipt::Phase::ReturnedEarly || h.phase==G28PassiveReceipt::Phase::ClockInvalid){result_.reason=Reason::G28Interrupted;return;}
    if(h.phase!=G28PassiveReceipt::Phase::EndObservedTrusted || !h.xyz_trusted || !h.tool0){result_.reason=Reason::G28Untrusted;return;}
    if(!sw.electrical_edge_observed(now)){result_.reason=Reason::SwitchStale;return;}
    if(!baseline_set_ || sw.edge_epochs()<=baseline_edge_){result_.reason=Reason::NoFreshSwitchEdge;return;}
    if((uint32_t)(now-h.ended_ms)>MaxAssociationAgeMs){result_.reason=Reason::OrderInvalid;return;}
    result_.switch_epoch=sw.edge_epochs(); result_.electrical_correlation=true;
    result_.reason=Reason::TemporalCorrelationOnly;
  }
  const Result& view() const{return result_;}
  bool physical_t1_park_proven()const{return false;}
  bool permit_motion()const{return false;}
  bool permit_eeprom()const{return false;}
  static constexpr uint32_t MaxAssociationAgeMs=30000u;
private:
  uint32_t last_h_=0,baseline_edge_=0; bool baseline_set_=false;
  Result result_{};
};
} // namespace sv04next
