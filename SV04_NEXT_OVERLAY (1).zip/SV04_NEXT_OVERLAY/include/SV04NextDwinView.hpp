// SV04 NEXT: data model for OEM RTS/DWIN 4x4 screen (no HMI resource generated).
#pragma once
#include <stdint.h>
#include <math.h>
namespace sv04next {
class DwinView final {
public:
  enum class Color : uint8_t { Gray, Green, Yellow, Red };
  // OEM G29 PROBE_Y_FIRST disabled and 4 columns: first row 3,2,1,0; next row 0..3.
  static uint8_t x_at(uint8_t sample) { return sample<16 ? ((sample/4)%2 ? sample%4 : 3-(sample%4)) : 255; }
  static uint8_t y_at(uint8_t sample) { return sample<16 ? sample/4 : 255; }
  static uint16_t rts_value_address(uint8_t sample) { return sample<16 ? uint16_t(0x1100 + sample*2) : 0; }
  static uint16_t rts_progress_address() { return 0x108D; }
  static uint16_t rts_bed_temperature_address() { return 0x103C; }
  // Color bands are PROPOSED. A genuine colorful display requires modifying the DWIN/HMI resources.
  static Color color_for(float z, float reference) {
    if(!isfinite(z) || !isfinite(reference)) return Color::Gray;
    const float d=fabsf(z-reference);
    return d<=0.05f ? Color::Green : d<=0.20f ? Color::Yellow : Color::Red;
  }
};
}
