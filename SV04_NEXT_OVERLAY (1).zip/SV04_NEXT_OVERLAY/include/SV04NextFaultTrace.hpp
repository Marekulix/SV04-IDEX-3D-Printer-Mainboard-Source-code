// SV04 NEXT - bounded volatile failure trace for later serial / DWIN diagnostics.
// HOST ONLY; intentionally no filesystem, serial, EEPROM or DWIN calls.
#pragma once
#include <stdint.h>
namespace sv04next {
class FaultTrace final {
public:
  enum class Event : uint8_t { Start, HeatAccepted, HeatStable, Homed,
    ProbeStarted, ProbePoint, RamSuccess, Cancel, SafetyTrip,
    StopRequested, Quiescent, OperatorReviewed, RecoveryClosed };
  struct Row {uint32_t run=0,t_ms=0;uint16_t sequence=0;Event event=Event::Start;
    uint8_t point=0;uint16_t code=0;};
  static constexpr uint8_t Capacity=32;
  bool begin(uint32_t run,uint32_t now){
    if(!run || (run_!=0 && run<=run_))return false;
    run_=run;used_=0;head_=0;next_=0;last_time_=now;
    return record(run,now,Event::Start,0,0);
  }
  bool record(uint32_t run,uint32_t now,Event e,uint8_t point,uint16_t code){
    if(!run_ || run!=run_ || (e==Event::ProbePoint && point>=16) ||
       (used_!=0 && (uint32_t)(now-last_time_)>0x7FFFFFFFu))return false;
    Row row;row.run=run;row.t_ms=now;row.sequence=++next_;
    row.event=e;row.point=point;row.code=code;
    entries_[head_]=row;head_=(uint8_t)((head_+1u)%Capacity);
    if(used_<Capacity)++used_;
    last_time_=now;return true;
  }
  bool latest(uint8_t reverse_index,Row &out)const{
    if(reverse_index>=used_)return false;
    const uint8_t ix=(uint8_t)((head_+Capacity-1u-reverse_index)%Capacity);
    out=entries_[ix];return true;
  }
  uint32_t run()const{return run_;}
  uint8_t size()const{return used_;}
  bool eeprom_writes()const{return false;}
  bool heater_commands()const{return false;}
private:
  Row entries_[Capacity]{};
  uint32_t run_=0,last_time_=0;
  uint16_t next_=0;
  uint8_t used_=0,head_=0;
};
}
