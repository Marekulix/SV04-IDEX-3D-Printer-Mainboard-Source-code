// Experimental SV04 NEXT: READ-ONLY X_MAX signal transition diagnostics.
// A switch transition alone is NOT proof of a safely parked second carriage.
// NEVER use this class to command motion, heat, probing, or EEPROM writes.
#pragma once
#include <stdint.h>

namespace sv04next {
class T1EndstopObserver final {
public:
  enum class State : uint8_t {
    Unavailable, WaitingForRelease, ReleaseDebounce, Released,
    PressDebounce, StablePressed, Stale
  };
  static constexpr uint32_t ReleaseMs = 100u;
  static constexpr uint32_t PressMs = 300u;
  static constexpr uint32_t MaxGapMs = 3500u;

  void observe(uint32_t now, bool available, bool triggered) {
    if (!available) {
      reset(State::Unavailable);
      return;
    }
    if (seen_ && (uint32_t)(now - last_ms_) > MaxGapMs) {
      // Never allow a discontinuous timeline to complete a debounce window.
      reset(State::Stale);
    }
    last_ms_ = now;
    seen_ = true;
    switch (state_) {
      case State::Unavailable:
      case State::Stale:
      case State::WaitingForRelease:
        if (!triggered) { stage_ms_ = now; state_ = State::ReleaseDebounce; }
        else state_ = State::WaitingForRelease;
        break;
      case State::ReleaseDebounce:
        if (triggered) state_ = State::WaitingForRelease;
        else if ((uint32_t)(now-stage_ms_) >= ReleaseMs) {
          state_ = State::Released;
          ++release_epochs_;
        }
        break;
      case State::Released:
        if (triggered) { stage_ms_ = now; state_ = State::PressDebounce; }
        break;
      case State::PressDebounce:
        if (!triggered) state_ = State::Released;
        else if ((uint32_t)(now-stage_ms_) >= PressMs) {
          state_ = State::StablePressed;
          ++edge_epochs_;
        }
        break;
      case State::StablePressed:
        if (!triggered) { stage_ms_ = now; state_ = State::ReleaseDebounce; }
        break;
    }
  }
  State state() const { return state_; }
  uint32_t release_epochs() const { return release_epochs_; }
  uint32_t edge_epochs() const { return edge_epochs_; }
  bool electrical_edge_observed(uint32_t now) const {
    return state_ == State::StablePressed && seen_ &&
           (uint32_t)(now-last_ms_) <= MaxGapMs;
  }
  // The switch could be faulty or pressed by something else. There is no
  // independently verified G28-T1/parking history in the current adapter.
  bool physical_t1_park_proven() const { return false; }
  bool allow_motion() const { return false; }
  bool allow_eeprom_write() const { return false; }
private:
  void reset(State value) {
    state_ = value;
    seen_ = false;
    last_ms_ = stage_ms_ = 0;
  }
  State state_ = State::Unavailable;
  bool seen_ = false;
  uint32_t last_ms_ = 0, stage_ms_ = 0;
  uint32_t release_epochs_ = 0, edge_epochs_ = 0;
};
extern T1EndstopObserver t1_endstop_observer;
}  // namespace sv04next
