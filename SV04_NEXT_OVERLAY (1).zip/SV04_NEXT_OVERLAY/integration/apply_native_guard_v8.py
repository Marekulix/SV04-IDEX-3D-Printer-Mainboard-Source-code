#!/usr/bin/env python3
"""Add read-only native SV04 NEXT Auto60 preflight telemetry to compiled G29 U v7.

No actuator/EEPROM/UI changes. OEM blob checks inherited from v7.
This is a compile/integration research artifact; it is NOT flashable.
"""
from __future__ import annotations
import argparse,hashlib,json
from pathlib import Path
import apply_native_guard_v7 as previous

OEM_BLOBS=previous.OEM_BLOBS
PatchRefused=previous.PatchRefused
replace_one=previous.replace_one
NATIVE_TARGET='Marlin/src/feature/sv04_next/SV04NextNativeReadiness.hpp'
RTS='Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp'

def render(original:dict[str,str],thermal:str,visit:str,receipt:str,native:str)->dict[str,str]:
    if not native.startswith('// SV04 NEXT: experimental, read-only native Marlin status gate.'):
        raise PatchRefused('native adapter provenance mismatch')
    safety_contract=(
       'bool allow_automatic_heating() const { return false; }',
       'bool allow_automatic_homing() const { return false; }',
       'bool allow_automatic_g29() const { return false; }',
       'bool allow_eeprom_save() const { return false; }',
       'bool hardware_approved() const { return false; }',
       'physical_t1_park_witness = false;',
       'probe_stow_witness = false;',
    )
    if not all(item in native for item in safety_contract):
        raise PatchRefused('native adapter missing fail-closed guard')
    out=previous.render(original,thermal,visit,receipt)
    rt=out[RTS]
    rt=replace_one(rt,
        '#include "../../../feature/sv04_next/SV04NextNativeThermalGate.hpp"',
        '#include "../../../feature/sv04_next/SV04NextNativeThermalGate.hpp"\n'
        '#if ENABLED(AUTO_BED_LEVELING_BILINEAR) && DISABLED(PROBE_MANUALLY)\n'
        '  #include "../../../feature/sv04_next/SV04NextNativeReadiness.hpp"\n'
        '#endif',RTS)
    rt=replace_one(rt,
        'namespace sv04next { NativeThermalGate native_thermal_gate; }',
        'namespace sv04next { NativeThermalGate native_thermal_gate; }\n'
        '#if ENABLED(AUTO_BED_LEVELING_BILINEAR) && DISABLED(PROBE_MANUALLY)\n'
        '  namespace sv04next { NativeReadiness native_readiness; }\n'
        '#endif',RTS)
    anchor='''    !IsStopped() && !printJobOngoing() && !printingIsPaused());'''
    extension='''    !IsStopped() && !printJobOngoing() && !printingIsPaused());
  #if ENABLED(AUTO_BED_LEVELING_BILINEAR) && DISABLED(PROBE_MANUALLY)
    // Actual Marlin state sampled here, but NEVER interpreted as physical
    // proof that the second IDEX carriage is parked. No commands are emitted.
    sv04next::NativeReadiness::Live n;
    n.stopped = IsStopped();
    n.printing = printJobOngoing() || printingIsPaused();
    n.motion_queued = planner.has_blocks_queued();
    n.tool0 = active_extruder == 0;
    n.dual_auto_park = dual_x_carriage_mode == DXC_AUTO_PARK_MODE;
    n.xyz_trusted = axis_is_trusted(X_AXIS) && axis_is_trusted(Y_AXIS) && axis_is_trusted(Z_AXIS);
    n.t1_x = inactive_extruder_x;     // firmware coordinate, NOT a sensor
    n.t1_home_x = X2_MAX_POS;
    n.bed_c = thermalManager.degBed();
    n.bed_set_c = thermalManager.degTargetBed();
    n.probe_offset_z = probe.offset.z;
    n.physical_t1_park_witness = false; // no independent T1 sensor evidence
    n.probe_stow_witness = false;       // no independent BLTouch stow evidence
    sv04next::native_readiness.observe((uint32_t)millis(), n, sv04next::g29u_receipt);
  #endif'''
    rt=replace_one(rt,anchor,extension,RTS)
    if any(a in extension for a in ('queue.enqueue', 'settings.save', 'setTargetBed(', 'M500', 'process_subcommands_now', 'G28', 'G29 U')):
        raise PatchRefused('actuator instructions forbidden in new adapter')
    out[RTS]=rt
    out[NATIVE_TARGET]=native
    if out['Marlin/Configuration.h']!=original['Marlin/Configuration.h'] or out['Marlin/src/module/probe.cpp']!=original['Marlin/src/module/probe.cpp']:
        raise PatchRefused('OEM probe or config changed')
    return out

def apply(root:Path,thermal:Path,visit:Path,receipt:Path,native:Path,evidence:Path|None=None):
    originals={}
    for name,sha in OEM_BLOBS.items():
        raw=(root/name).read_bytes()
        if previous.previous.previous.previous.previous.git_blob_sha(raw)!=sha:
            raise PatchRefused('OEM original changed: '+name)
        originals[name]=raw.decode('utf-8')
    out=render(originals,thermal.read_text(),visit.read_text(),receipt.read_text(),native.read_text())
    report={'status':'NATIVE_BUILD_PENDING_NOT_FLASHABLE','integration':'READ_ONLY_NATIVE_INPUT_AND_G29U_RECEIPT',
      'native_compile_verified':False,'physical_t1_verified':False,'probe_stow_physically_verified':False,
      'automatic_heat_enabled':False,'automatic_homing_enabled':False,'automatic_g29_enabled':False,
      'eeprom_write_enabled':False,'new_dwin_hmi_button':False,'changed':{}}
    for name,content in out.items():
        if name not in originals or content!=originals[name]:
            report['changed'][name]=hashlib.sha256(content.encode()).hexdigest()
    for name,content in out.items():
        if name not in originals or content!=originals[name]:
            dest=root/name;dest.parent.mkdir(parents=True,exist_ok=True)
            dest.write_text(content,encoding='utf-8')
    if evidence:
        evidence.parent.mkdir(parents=True,exist_ok=True)
        evidence.write_text(json.dumps(report,indent=2)+'\n')
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--root',type=Path,default=Path('.'))
    p.add_argument('--thermal-header',type=Path,default=Path('include/SV04NextNativeThermalGate.hpp'))
    p.add_argument('--visit-header',type=Path,default=Path('include/SV04NextVisitProof.hpp'))
    p.add_argument('--receipt-header',type=Path,default=Path('include/SV04NextG29UReceipt.hpp'))
    p.add_argument('--native-header',type=Path,default=Path('include/SV04NextNativeReadiness.hpp'))
    p.add_argument('--evidence',type=Path)
    v=p.parse_args()
    print(json.dumps(apply(v.root,v.thermal_header,v.visit_header,v.receipt_header,v.native_header,v.evidence),indent=2))
