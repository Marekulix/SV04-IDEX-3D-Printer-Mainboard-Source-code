#!/usr/bin/env python3
"""SV04 NEXT 11.13-11.32: scoped 4x4 coverage + direct run-time thermal checks.

Extends v5. No new actuator commands; only opt-in G29 U changes. The normal
G29, OEM probe logic and original configuration remain byte-identical.
Native STM32 compilation not yet proven; old v5 build artifact required.
"""
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path
import apply_native_guard_v5 as previous

OEM_BLOBS=previous.OEM_BLOBS
PatchRefused=previous.PatchRefused
replace_one=previous.replace_one
THERMAL_TARGET=previous.PATCH_TARGET
VISIT_TARGET='Marlin/src/feature/sv04_next/SV04NextVisitProof.hpp'


def render(original:dict[str,str],thermal_header:str,visit_header:str)->dict[str,str]:
    if not visit_header.startswith('// SV04 NEXT 11.13-11.32: unique 4x4 native probe coverage.'):
        raise PatchRefused('VisitProof header provenance mismatch')
    if 'static bool live_sample_safe(float bed_c, float target_c)' not in thermal_header:
        raise PatchRefused('thermal header missing v6 live-sample precondition')
    out=previous.render(original,thermal_header)
    g='Marlin/src/gcode/bedlevel/abl/G29.cpp'
    code=out[g]
    # Probe coverage applies to G29 U only. Ordinary G29 maintains its OEM path.
    code=replace_one(code,
        '#include "../../../module/probe.h"',
        '#include "../../../module/probe.h"\n#if ENABLED(AUTO_BED_LEVELING_BILINEAR) && DISABLED(PROBE_MANUALLY)\n  #include "../../../feature/sv04_next/SV04NextVisitProof.hpp"\n#endif', g)
    code=replace_one(code,
        '    uint8_t sv04_measured_points = 0;',
        '    uint8_t sv04_measured_points = 0;\n    sv04next::VisitProof sv04_visit_proof;', g)
    # At the point after XY assignment but before actual motion / probe.
    probe_anchor='''          // Avoid probing outside the round or hexagonal area
          if (TERN0(IS_KINEMATIC, !probe.can_reach(abl.probePos))) continue;'''
    probe_replacement='''          // Avoid probing outside the round or hexagonal area
          if (TERN0(IS_KINEMATIC, !probe.can_reach(abl.probePos))) continue;

          #if ENABLED(AUTO_BED_LEVELING_BILINEAR) && DISABLED(PROBE_MANUALLY)
            // Reject duplicate or out-of-bounds XY before any physical probe.
            // Recording an unsuccessful point is harmless: the whole run aborts.
            if (sv04_transactional_run &&
                !sv04_visit_proof.record(abl.meshCount.x, abl.meshCount.y)) {
              SERIAL_ERROR_MSG("SV04 NEXT G29U ABORT: repeated/out-of-grid point");
              abl.measured_z = NAN;
              break;
            }
          #endif'''
    code=replace_one(code,probe_anchor,probe_replacement,g)
    # Before the first and second probe the existing v3 checks sample real
    # temperature; immediately after second probe also do a direct sample.
    anchor='''              else abl.measured_z = (first_z + second_z) * 0.5f;
            }
          }
          else
            abl.measured_z = faux ? 0.001f * random(-100, 101) : probe.probe_at_point(abl.probePos, raise_after, abl.verbose_level);'''
    new='''              else abl.measured_z = (first_z + second_z) * 0.5f;
            }
          }
          else
            abl.measured_z = faux ? 0.001f * random(-100, 101) : probe.probe_at_point(abl.probePos, raise_after, abl.verbose_level);

          #if ENABLED(RTS_AVAILABLE)
            if (sv04_transactional_run &&
                !sv04next::NativeThermalGate::live_sample_safe(
                  thermalManager.degBed(), (float)thermalManager.degTargetBed())) {
              SERIAL_ERROR_MSG("SV04 NEXT G29U ABORT: heat changed during probe");
              abl.measured_z = NAN;
            }
          #endif'''
    code=replace_one(code,anchor,new,g)
    # The initial proof of 20s stability stays mandatory. At finalization,
    # avoid ready(now), which depends on idle-loop RTS polling during blocking
    # probe moves and could falsely fail after a perfectly stable G29 run.
    marker='''        if (sv04_good && !sv04next::native_thermal_gate.ready((uint32_t)millis()))
          sv04_good = false;'''
    code=replace_one(code,marker,'''        if (sv04_good &&
            !sv04next::NativeThermalGate::live_sample_safe(
              thermalManager.degBed(), (float)thermalManager.degTargetBed()))
          sv04_good = false;''',g)
    code=replace_one(code,
        '&& sv04_measured_points == 16 && planner.leveling_active',
        '&& sv04_measured_points == 16 && sv04_visit_proof.complete() && planner.leveling_active',g)
    if code.count('native_thermal_gate.ready((uint32_t)millis())')!=1:
        raise PatchRefused('initial 20s gate missing / extra gate present')
    if 'settings.save(' in code or 'M500' in code:
        raise PatchRefused('EEPROM command introduced')
    if 'queue.enqueue' in code or 'setTargetBed(' in code:
        raise PatchRefused('unapproved actuator command introduced')
    out[g]=code
    out[VISIT_TARGET]=visit_header
    return out


def apply(root:Path, thermal_header:Path, visit_header:Path, evidence:Path|None=None):
    if (root/THERMAL_TARGET).exists() or (root/VISIT_TARGET).exists():
        raise PatchRefused('one of the native feature headers already exists')
    originals={}
    for name,sha in OEM_BLOBS.items():
        data=(root/name).read_bytes()
        if previous.git_blob_sha(data)!=sha:
            raise PatchRefused('OEM original drift: '+name)
        originals[name]=data.decode('utf-8')
    updated=render(originals,thermal_header.read_text(),visit_header.read_text())
    if updated['Marlin/Configuration.h']!=originals['Marlin/Configuration.h'] or updated['Marlin/src/module/probe.cpp']!=originals['Marlin/src/module/probe.cpp']:
        raise PatchRefused('original normal probing was modified')
    proof={'phase_range':'11.13-11.32', 'result':'NATIVE_PATCH_UNCOMPILED_NOT_FLASHABLE',
      'native_stm32_build_passed':False,'physical_t1_park_proven':False,
      'automatic_dwin_button_available':False,'automatic_heating_enabled':False,
      'm500_enabled':False,'patched_files':{}}
    for name,new in updated.items():
        if name not in originals or new!=originals[name]:
            proof['patched_files'][name]=hashlib.sha256(new.encode()).hexdigest()
    for name,new in updated.items():
        if name not in originals or new!=originals[name]:
            file=root/name;file.parent.mkdir(parents=True,exist_ok=True);file.write_text(new)
    if evidence:
        evidence.parent.mkdir(parents=True,exist_ok=True)
        evidence.write_text(json.dumps(proof,indent=2)+'\n')
    return proof

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--root',type=Path,default=Path('.'))
    p.add_argument('--thermal-header',type=Path,default=Path('include/SV04NextNativeThermalGate.hpp'))
    p.add_argument('--visit-header',type=Path,default=Path('include/SV04NextVisitProof.hpp'))
    p.add_argument('--evidence',type=Path)
    args=p.parse_args()
    print(json.dumps(apply(args.root,args.thermal_header,args.visit_header,args.evidence),indent=2))
