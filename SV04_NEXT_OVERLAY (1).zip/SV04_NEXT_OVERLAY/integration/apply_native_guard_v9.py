#!/usr/bin/env python3
"""Read-only X_MAX endstop observation on top of GitHub-compiled v8 firmware.

FAIL CLOSED: no automatic heating, G28, G29, EEPROM, new HMI, or motion.
The OEM Configuration.h and probe.cpp remain byte-identical.
"""
from __future__ import annotations
import argparse,hashlib,json
from pathlib import Path
import apply_native_guard_v8 as previous

OEM_BLOBS=previous.OEM_BLOBS
PatchRefused=previous.PatchRefused
replace_one=previous.replace_one
RTS=previous.RTS
SENSOR_TARGET='Marlin/src/feature/sv04_next/SV04NextT1EndstopObserver.hpp'


def render(original:dict[str,str],thermal:str,visit:str,receipt:str,native:str,sensor:str)->dict[str,str]:
    if not sensor.startswith('// Experimental SV04 NEXT: READ-ONLY X_MAX signal transition diagnostics.'):
        raise PatchRefused('untrusted sensor header')
    required=('physical_t1_park_proven() const { return false; }',
              'allow_motion() const { return false; }',
              'allow_eeprom_write() const { return false; }',
              'MaxGapMs', 'PressMs', 'ReleaseMs')
    if not all(x in sensor for x in required):
        raise PatchRefused('fail-closed contract missing')
    out=previous.render(original,thermal,visit,receipt,native)
    source=out[RTS]
    source=replace_one(source,
        '  #include "../../../feature/sv04_next/SV04NextNativeReadiness.hpp"',
        '  #include "../../../feature/sv04_next/SV04NextNativeReadiness.hpp"\n'
        '  #include "../../../feature/sv04_next/SV04NextT1EndstopObserver.hpp"', RTS)
    source=replace_one(source,
        '  namespace sv04next { NativeReadiness native_readiness; }',
        '  namespace sv04next { NativeReadiness native_readiness; }\n'
        '  namespace sv04next { T1EndstopObserver t1_endstop_observer; }',RTS)
    anchor='    sv04next::native_readiness.observe((uint32_t)millis(), n, sv04next::g29u_receipt);'
    replacement='''    sv04next::native_readiness.observe((uint32_t)millis(), n, sv04next::g29u_receipt);
    // READ ONLY: raw X_MAX electrical signal, sampled without any movement.
    // A switch press is not a validated T1 homing event or physical park proof.
    // A future hardware-validated adapter must associate switch transitions
    // with verified T1 movement and a safe collision envelope.
    #if PIN_EXISTS(X_MAX)
      const bool x_max_electrical_triggered = (READ(X_MAX_PIN) != X_MAX_ENDSTOP_INVERTING);
      sv04next::t1_endstop_observer.observe((uint32_t)millis(), true, x_max_electrical_triggered);
    #else
      sv04next::t1_endstop_observer.observe((uint32_t)millis(), false, false);
    #endif'''
    source=replace_one(source,anchor,replacement,RTS)
    if any(s in replacement for s in ('queue.enqueue','settings.save(', 'setTargetBed(', 'G28', 'G29 U', 'M500')):
        raise PatchRefused('forbidden native command in sensor adapter')
    if source.count('t1_endstop_observer.observe(')!=2:
        raise PatchRefused('sensor observation not compiled for both pin modes')
    out[RTS]=source
    out[SENSOR_TARGET]=sensor
    for unchanged in ('Marlin/Configuration.h','Marlin/src/module/probe.cpp'):
        if out[unchanged]!=original[unchanged]:
            raise PatchRefused('OEM global-probe path modified')
    return out

def apply(root:Path,thermal:Path,visit:Path,receipt:Path,native:Path,sensor:Path,evidence:Path|None=None):
    originals={}
    for name,sha in OEM_BLOBS.items():
        raw=(root/name).read_bytes()
        if previous.previous.previous.previous.previous.previous.git_blob_sha(raw)!=sha:
            raise PatchRefused('OEM original changed: '+name)
        originals[name]=raw.decode('utf-8')
    out=render(originals,thermal.read_text(),visit.read_text(),receipt.read_text(),native.read_text(),sensor.read_text())
    report={'workflow':'2','status':'EXPERIMENTAL_NATIVE_COMPILE_PENDING_NOT_FLASHABLE',
            'physical_t1_proven':False,'endstop_electrical_observation':True,
            'automatic_heat':False,'automatic_g28':False,'automatic_g29':False,
            'eeprom_auto_save':False,'dwin_hmi_button':False,
            'flash_approved':False,'changes':{}}
    for p,s in out.items():
        if p not in originals or s!=originals[p]:
            report['changes'][p]=hashlib.sha256(s.encode()).hexdigest()
    for p,s in out.items():
        if p not in originals or s!=originals[p]:
            dest=root/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(s,encoding='utf-8')
    if evidence:
        evidence.parent.mkdir(parents=True,exist_ok=True)
        evidence.write_text(json.dumps(report,indent=2)+'\n')
    return report
if __name__=='__main__':
    a=argparse.ArgumentParser()
    a.add_argument('--root',type=Path,default=Path('.'))
    for flag in ('thermal','visit','receipt','native','sensor'):
        a.add_argument('--'+flag, type=Path,
                       default=Path('include/'+{'thermal':'SV04NextNativeThermalGate.hpp',
                        'visit':'SV04NextVisitProof.hpp','receipt':'SV04NextG29UReceipt.hpp',
                        'native':'SV04NextNativeReadiness.hpp','sensor':'SV04NextT1EndstopObserver.hpp'}[flag]))
    a.add_argument('--evidence',type=Path)
    opts=a.parse_args()
    print(json.dumps(apply(opts.root,opts.thermal,opts.visit,opts.receipt,opts.native,opts.sensor,opts.evidence),indent=2))
