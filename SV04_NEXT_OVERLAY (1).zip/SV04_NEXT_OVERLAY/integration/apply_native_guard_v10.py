#!/usr/bin/env python3
"""v10 passive RTS telemetry overlay on the latest native G29-U v9 code.

NO commands, motor moves, heaters, EEPROM, or touch writes. Native build pending.
"""
from __future__ import annotations
import argparse,hashlib,json
from pathlib import Path
import apply_native_guard_v9 as previous

OEM_BLOBS=previous.OEM_BLOBS
RTS=previous.RTS
PatchRefused=previous.PatchRefused
replace_one=previous.replace_one
TARGET='Marlin/src/feature/sv04_next/SV04NextNativeEventTimeline.hpp'


def render(original:dict[str,str],thermal:str,visit:str,receipt:str,native:str,sensor:str,timeline:str)->dict[str,str]:
    required=('bool allows_motion()const{return false;}',
              'bool allows_heating()const{return false;}',
              'bool allows_eeprom()const{return false;}',
              'frame_.physical_t1_proven=false;',
              'frame_.automatic_sequence_allowed=false;',
              'frame_.eeprom_allowed=false;',
              'frame_.hardware_approved=false;')
    if not timeline.startswith('// SV04 NEXT - native passive event timeline.') or not all(x in timeline for x in required):
        raise PatchRefused('unsafe or unknown event collector')
    out=previous.render(original,thermal,visit,receipt,native,sensor)
    rt=out[RTS]
    rt=replace_one(rt,
        '  #include "../../../feature/sv04_next/SV04NextT1EndstopObserver.hpp"',
        '  #include "../../../feature/sv04_next/SV04NextT1EndstopObserver.hpp"\n'
        '  #include "../../../feature/sv04_next/SV04NextNativeEventTimeline.hpp"',RTS)
    rt=replace_one(rt,
        '  namespace sv04next { T1EndstopObserver t1_endstop_observer; }',
        '  namespace sv04next { T1EndstopObserver t1_endstop_observer; }\n'
        '  namespace sv04next { NativeEventTimeline native_event_timeline; }',RTS)
    anchor='''      sv04next::t1_endstop_observer.observe((uint32_t)millis(), false, false);
    #endif'''
    replacement='''      sv04next::t1_endstop_observer.observe((uint32_t)millis(), false, false);
    #endif
    // Passive cross-check: no scheduler, move, new touchscreen VP, or save.
    sv04next::native_event_timeline.observe((uint32_t)millis(),
      sv04next::native_readiness.view(), sv04next::t1_endstop_observer);'''
    rt=replace_one(rt,anchor,replacement,RTS)
    if rt.count('native_event_timeline.observe(')!=1 or any(x in replacement for x in
           ('queue.enqueue','settings.save','setTargetBed','process_subcommands_now','M500')):
        raise PatchRefused('v10 observer call violates contract')
    out[RTS]=rt
    out[TARGET]=timeline
    for unchanged in ('Marlin/Configuration.h','Marlin/src/module/probe.cpp'):
        if out[unchanged]!=original[unchanged]:raise PatchRefused('OEM config/probe modified')
    return out


def apply(root:Path,thermal:Path,visit:Path,receipt:Path,native:Path,sensor:Path,timeline:Path,evidence:Path|None=None):
    originals={}
    for path,sha in OEM_BLOBS.items():
        raw=(root/path).read_bytes()
        if previous.previous.previous.previous.previous.previous.previous.git_blob_sha(raw)!=sha:
            raise PatchRefused('OEM original changed: '+path)
        originals[path]=raw.decode('utf-8')
    out=render(originals,*[x.read_text(encoding='utf-8') for x in
          (thermal,visit,receipt,native,sensor,timeline)])
    report={'workflow':'NOT_REQUESTED','native_build_verified':False,
            'auto_heat':False,'auto_g28':False,'auto_g29':False,'auto_eeprom':False,
            'physical_t1_park_proven':False,'touch_button':False,'flash_approved':False,
            'changes':{}}
    for path,content in out.items():
        if path not in originals or content!=originals[path]:
            report['changes'][path]=hashlib.sha256(content.encode()).hexdigest()
            dest=root/path;dest.parent.mkdir(parents=True,exist_ok=True)
            dest.write_text(content,encoding='utf-8')
    if evidence:evidence.write_text(json.dumps(report,indent=2)+'\n')
    return report
if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--root',type=Path,default=Path('.'))
    for flag,file in [('thermal','SV04NextNativeThermalGate.hpp'),('visit','SV04NextVisitProof.hpp'),
                      ('receipt','SV04NextG29UReceipt.hpp'),('native','SV04NextNativeReadiness.hpp'),
                      ('sensor','SV04NextT1EndstopObserver.hpp'),('timeline','SV04NextNativeEventTimeline.hpp')]:
        p.add_argument('--'+flag,type=Path,default=Path('include')/file)
    p.add_argument('--evidence',type=Path)
    a=p.parse_args();print(json.dumps(apply(a.root,a.thermal,a.visit,a.receipt,a.native,a.sensor,a.timeline,a.evidence),indent=2))
