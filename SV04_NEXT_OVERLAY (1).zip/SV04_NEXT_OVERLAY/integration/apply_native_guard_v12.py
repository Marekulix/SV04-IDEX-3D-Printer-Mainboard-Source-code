#!/usr/bin/env python3
"""Add RAM-only 16-point probe telemetry. Does not enable touch button or action."""
from __future__ import annotations
import argparse,json,hashlib
from pathlib import Path
import apply_native_guard_v11 as previous
import apply_native_guard_v5 as base
OEM_BLOBS=previous.OEM_BLOBS
RTS=previous.RTS
PatchRefused=previous.PatchRefused
replace_one=previous.replace_one
TARGET='Marlin/src/feature/sv04_next/SV04NextMeshMapPacket.hpp'

def render(original:dict[str,str],thermal:str,visit:str,receipt:str,native:str,
           sensor:str,timeline:str,status:str,map_packet:str)->dict[str,str]:
    required=('// SV04 NEXT 7: 4x4 probe value snapshot',
      'bool allows_eeprom()const{return false;}',
      'bool allows_motion()const{return false;}',
      'bool allows_heating()const{return false;}',
      'found==16 && r.point_mask()==0xFFFFu',
      'NativeStatusPacket::verify(',
      'NativeStatusPacket::crc16(')
    if not all(x in map_packet for x in required):
        raise PatchRefused('untrusted or actuator-enabled mesh data header')
    out=previous.render(original,thermal,visit,receipt,native,sensor,timeline,status)
    rt=out[RTS]
    rt=replace_one(rt,
      '  #include "../../../feature/sv04_next/SV04NextNativeStatusPacket.hpp"',
      '  #include "../../../feature/sv04_next/SV04NextNativeStatusPacket.hpp"\n'
      '  #include "../../../feature/sv04_next/SV04NextMeshMapPacket.hpp"',RTS)
    rt=replace_one(rt,
      '  namespace sv04next { NativeStatusPacket native_status_packet; }',
      '  namespace sv04next { NativeStatusPacket native_status_packet; }\n'
      '  namespace sv04next { MeshMapPacket mesh_map_packet; }',RTS)
    anchor='''    sv04next::native_status_packet.capture((uint32_t)millis(),
      sv04next::native_readiness.view(), sv04next::native_event_timeline.view(),
      sv04next::t1_endstop_observer);'''
    replacement=anchor+'''
    // Only a RAM mirror of native G29 U probe values. Do NOT write any VP.
    sv04next::mesh_map_packet.capture(sv04next::g29u_receipt,
      sv04next::native_event_timeline.view(), sv04next::native_status_packet);'''
    rt=replace_one(rt,anchor,replacement,RTS)
    if rt.count('mesh_map_packet.capture(')!=1 or any(x in replacement for x in
      ('queue.enqueue','settings.save','sendData','M500','process_subcommands_now','setTargetBed(')):
        raise PatchRefused('unsafe native mesh hook')
    out[RTS]=rt;out[TARGET]=map_packet
    for path in ('Marlin/Configuration.h','Marlin/src/module/probe.cpp'):
        if out[path]!=original[path]:raise PatchRefused('OEM must be unchanged')
    return out

def apply(root:Path,thermal:Path,visit:Path,receipt:Path,native:Path,
          sensor:Path,timeline:Path,status:Path,map_packet:Path,evidence:Path|None=None):
    originals={}
    for name,sha in OEM_BLOBS.items():
        raw=(root/name).read_bytes()
        if base.git_blob_sha(raw)!=sha:raise PatchRefused('OEM git blob SHA mismatch '+name)
        originals[name]=raw.decode('utf-8')
    out=render(originals,*[p.read_text(encoding='utf-8') for p in
      (thermal,visit,receipt,native,sensor,timeline,status,map_packet)])
    report={'workflow':'NONE','native_stm32_verified':False,
      'touch_button':False,'auto_heat':False,'auto_g28':False,
      'auto_g29':False,'auto_eeprom':False,'physical_t1_verified':False,
      'flash_approved':False,'changed':{}}
    for path,src in out.items():
        if path not in originals or src!=originals[path]:
            report['changed'][path]=hashlib.sha256(src.encode()).hexdigest()
            dest=root/path;dest.parent.mkdir(parents=True,exist_ok=True)
            dest.write_text(src,encoding='utf-8')
    if evidence:evidence.write_text(json.dumps(report,indent=2)+'\n')
    return report
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path('.'))
    for flag,file in [('thermal','SV04NextNativeThermalGate.hpp'),('visit','SV04NextVisitProof.hpp'),
       ('receipt','SV04NextG29UReceipt.hpp'),('native','SV04NextNativeReadiness.hpp'),
       ('sensor','SV04NextT1EndstopObserver.hpp'),('timeline','SV04NextNativeEventTimeline.hpp'),
       ('status','SV04NextNativeStatusPacket.hpp'),('map_packet','SV04NextMeshMapPacket.hpp')]:
        p.add_argument('--'+flag,type=Path,default=Path('include')/file)
    p.add_argument('--evidence',type=Path)
    a=p.parse_args()
    print(json.dumps(apply(a.root,a.thermal,a.visit,a.receipt,a.native,a.sensor,
          a.timeline,a.status,a.map_packet,a.evidence),indent=2))
