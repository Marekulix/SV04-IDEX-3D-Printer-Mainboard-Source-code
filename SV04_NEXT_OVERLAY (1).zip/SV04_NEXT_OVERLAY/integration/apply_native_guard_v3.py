#!/usr/bin/env python3
"""SV04 NEXT 10.47–10.52: experimental G29 U v3 integration, fail-closed.

Extends the GitHub-compiled v2 patch. No DWIN new button, no M500, no heater
or motion commands are injected. OEM SHA gate remains mandatory. All edits
are to an ephemeral checkout only. Firmware not authorized for flashing.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import apply_native_guard_v2 as old

OEM_BLOBS=old.OEM_BLOBS
PatchRefused=old.PatchRefused
replace_one=old.replace_one

# Native preflight lives BEFORE the first step of G29. The X2 position checks
# only software state, not actual physical proof: hardware validation remains
# essential before enabling any new DWIN button.
PREFLIGHT='''    // SV04 NEXT V3: opt-in only. These preconditions are checked before
    // OEM G29 can change the mesh, deploy the probe, or move either carriage.
    if (sv04_transactional_run) {
      if (GRID_MAX_POINTS_X != 4 || GRID_MAX_POINTS_Y != 4 ||
          parser.seen_test('N') || parser.seen_test('J') ||
          parser.seen_test('W') || parser.seen_test('D') ||
          parser.seen_test('Q') || parser.seen_test('C') ||
          parser.seen_test('O') || parser.seen_test('Z') ||
          parser.seen_test('L') || parser.seen_test('R') ||
          parser.seen_test('F') || parser.seen_test('B') ||
          parser.seen_test('H') || parser.seen_test('S')) {
        SERIAL_ERROR_MSG("SV04 NEXT G29U REFUSED: unsupported parameter/grid");
        G29_RETURN(true);
      }
      if (IsStopped() || printJobOngoing() || printingIsPaused() || planner.has_blocks_queued()) {
        SERIAL_ERROR_MSG("SV04 NEXT G29U REFUSED: printing or moving");
        G29_RETURN(true);
      }
      // The OEM starts with X2=362 even BEFORE homing. This is NOT proof
      // of physical parking, merely an extra prerequisite.
      if (active_extruder != 0 || dual_x_carriage_mode != DXC_AUTO_PARK_MODE ||
          !axis_is_trusted(X_AXIS) || !axis_is_trusted(Y_AXIS) ||
          !axis_is_trusted(Z_AXIS) ||
          !isfinite(inactive_extruder_x) ||
          ABS(inactive_extruder_x - X2_MAX_POS) > 1.0f) {
        SERIAL_ERROR_MSG("SV04 NEXT G29U REFUSED: IDEX/homing preflight");
        G29_RETURN(true);
      }
      // The safe heating/stabilization controller is NOT yet wired to the
      // DWIN button. Users cannot bypass temperature checks with G29 U.
      const float bed_c = thermalManager.degBed();
      if (!isfinite(bed_c) || ABS(bed_c - 60.0f) > 1.0f ||
          thermalManager.degTargetBed() != 60 || !isfinite(probe.offset.z)) {
        SERIAL_ERROR_MSG("SV04 NEXT G29U REFUSED: bed not stable at 60C");
        G29_RETURN(true);
      }
    }
'''

POINT_CHECK='''          // Fail closed during a long 16-point run. Never commit a partial
          // mesh after heater changes or if a print gets started elsewhere.
          #if ENABLED(AUTO_BED_LEVELING_BILINEAR) && DISABLED(PROBE_MANUALLY)
            if (sv04_transactional_run &&
                (IsStopped() || printJobOngoing() || printingIsPaused() ||
                 !isfinite(thermalManager.degBed()) ||
                 ABS(thermalManager.degBed() - 60.0f) > 1.0f ||
                 thermalManager.degTargetBed() != 60 ||
                 !isfinite(probe.offset.z) ||
                 ABS(probe.offset.z - sv04_mesh_guard.old_probe_offset) > 0.00001f)) {
              SERIAL_ERROR_MSG("SV04 NEXT G29U ABORT: runtime temperature/job/offset");
              abl.measured_z = NAN;
              break;
            }
          #endif

'''

TAIL_OLD='''  #if ENABLED(RTS_AVAILABLE)
    RTS_AutoBedLevelPage();
  #endif
  report_current_position();'''
TAIL_NEW='''  #if ENABLED(RTS_AVAILABLE)
    // Existing OEM RTS page 22 is an ordinary finished-leveling page.
    // A failed G29 U must NOT transition to it as if successful.
    #if ENABLED(AUTO_BED_LEVELING_BILINEAR) && DISABLED(PROBE_MANUALLY)
      if (!sv04_transactional_run || !isnan(abl.measured_z))
        RTS_AutoBedLevelPage();
      else
        rtscheck.RTS_SndData(0, AUTO_BED_LEVEL_ICON_VP);
    #else
      RTS_AutoBedLevelPage();
    #endif
  #endif
  report_current_position();'''

def render(src:dict[str,str])->dict[str,str]:
    out=old.render(src)
    g='Marlin/src/gcode/bedlevel/abl/G29.cpp'
    s=out[g]
    s=replace_one(s,'#include "../../../module/probe.h"',
        '#include "../../../module/probe.h"\n#include "../../../module/temperature.h"\n#include "../../../MarlinCore.h"',g)
    marker="    const bool sv04_transactional_run = parser.seen_test('U');\n"
    s=replace_one(s,marker,marker+PREFLIGHT,g)
    marker='''          abl.measured_z = faux ? 0.001f * random(-100, 101) : probe.probe_at_point(abl.probePos, raise_after, abl.verbose_level);'''
    s=replace_one(s,marker,POINT_CHECK+marker,g)
    marker='''              if (sv04_transactional_run) ++sv04_measured_points;'''
    s=replace_one(s,marker,'''              if (sv04_transactional_run) {
                ++sv04_measured_points;
                SERIAL_ECHOLNPGM("SV04 NEXT G29U PROGRESS ", int(sv04_measured_points), "/16");
              }''',g)
    s=replace_one(s,TAIL_OLD,TAIL_NEW,g)
    # Ensure rollback restores the original Z probe offset in RAM, too.
    s=replace_one(s,
        '        bilinear_grid_spacing = old_spacing;\n        refresh_bed_level();',
        '        bilinear_grid_spacing = old_spacing;\n        probe.offset.z = old_probe_offset;\n        refresh_bed_level();',g)
    # A temperature fault after point 16, while stowing the probe or finalizing
    # leveling, must reject acceptance just like a fault between probe points.
    acceptance='''      if (sv04_good) {
        sv04_mesh_guard.accept();
        SERIAL_ECHOLNPGM("SV04 NEXT: G29 U 16/16 OK, RAM mesh only");
      }'''
    validated='''      if (sv04_good && (IsStopped() || printJobOngoing() || printingIsPaused() ||
          !isfinite(thermalManager.degBed()) ||
          ABS(thermalManager.degBed() - 60.0f) > 1.0f ||
          thermalManager.degTargetBed() != 60 ||
          dual_x_carriage_mode != DXC_AUTO_PARK_MODE ||
          active_extruder != 0 ||
          !isfinite(inactive_extruder_x) ||
          ABS(inactive_extruder_x - X2_MAX_POS) > 1.0f))
        sv04_good = false;
      if (sv04_good) {
        sv04_mesh_guard.accept();
        SERIAL_ECHOLNPGM("SV04 NEXT: G29 U 16/16 OK, RAM mesh only");
      }'''
    s=replace_one(s,acceptance,validated,g)
    # Forbid accidental EEPROM write or queue injection in newly inserted code.
    injected=PREFLIGHT+POINT_CHECK+TAIL_NEW
    if any(s in injected for s in ['settings.save(', 'M500', 'queue.enqueue', 'setTargetBed(', 'process_subcommands_now']):
        raise PatchRefused('unsafe command added')
    out[g]=s
    return out

def git_blob_sha(data:bytes)->str:return old.git_blob_sha(data)

def apply(root:Path,evidence:Path|None=None):
    originals={}
    for path,expected in OEM_BLOBS.items():
        raw=(root/path).read_bytes()
        actual=git_blob_sha(raw)
        if actual!=expected:raise PatchRefused(f'OEM mismatch {path}: {actual} != {expected}')
        originals[path]=raw.decode('utf-8')
    modified=render(originals)
    info={'phase':'10.47-10.52','result':'EXPERIMENTAL_NO_FLASH','native_build_pending':True,
          'automatic_60c_start':False,'hardware_x2_park_verified':False,
          'm500_automated':False,'dwin_hmi_button_added':False,'flash_approved':False,
          'source_patch':{}}
    for path,content in modified.items():
        info['source_patch'][path]={'git_sha_before':OEM_BLOBS[path],
            'sha256_after':hashlib.sha256(content.encode()).hexdigest()}
        (root/path).write_text(content,encoding='utf-8')
    if evidence:
        evidence.parent.mkdir(parents=True,exist_ok=True)
        evidence.write_text(json.dumps(info,indent=2)+'\n')
    return info

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--root',type=Path,default=Path('.'))
    ap.add_argument('--evidence',type=Path)
    args=ap.parse_args()
    print(json.dumps(apply(args.root,args.evidence),indent=2))
