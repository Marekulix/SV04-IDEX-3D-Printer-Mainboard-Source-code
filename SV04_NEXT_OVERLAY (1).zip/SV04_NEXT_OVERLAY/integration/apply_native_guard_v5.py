#!/usr/bin/env python3
"""SV04 NEXT 10.93-11.12. Native G29 U only double-probe + 20s DWIN thermal gate.

Fail-closed overlay applied to ephemeral OEM checkout. Normal OEM G29, probe.cpp,
Configuration.h unchanged. No heating, movement initiation, M500, or new HMI.
"""
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path
import apply_native_guard_v4 as previous

OEM_BLOBS = dict(previous.OEM_BLOBS)
OEM_BLOBS['Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp'] = '2a63c281c8d8861e9780997df60e82becaa02805'
PATCH_TARGET = 'Marlin/src/feature/sv04_next/SV04NextNativeThermalGate.hpp'
PatchRefused=previous.PatchRefused
replace_one=previous.replace_one

FORBIDDEN_G29_MODIFIERS = "N O J W D C Z E H L R B F S V X Y P Q T".split()


def render(original:dict[str,str], thermal_gate_source:str)->dict[str,str]:
    if set(original)!=set(OEM_BLOBS):raise PatchRefused('incorrect original source set')
    if not thermal_gate_source.startswith('// SV04 NEXT experimental native 60 C stability monitor.'):
        raise PatchRefused('thermal gate header provenance mismatch')
    out=previous.render({k:original[k] for k in previous.OEM_BLOBS})
    g='Marlin/src/gcode/bedlevel/abl/G29.cpp'
    r='Marlin/src/lcd/e3v2/creality/LCD_RTS.cpp'
    code=out[g]
    # Undo global double probing and probe.cpp mutation; prevent behavior change
    # in the OEM normal G29 / other Marlin probe consumers.
    out['Marlin/Configuration.h']=original['Marlin/Configuration.h']
    out['Marlin/src/module/probe.cpp']=original['Marlin/src/module/probe.cpp']
    code=replace_one(code,
        '#include "../../../MarlinCore.h"',
        '#include "../../../MarlinCore.h"\n#if ENABLED(RTS_AVAILABLE)\n  #include "../../../feature/sv04_next/SV04NextNativeThermalGate.hpp"\n#endif',g)

    # Reject modifiers that could result in homing, dry run, malformed
    # measurements, custom grids, or early success before transaction guard.
    restrictions=' ||\n          '.join(f"parser.seen_test('{item}')" for item in FORBIDDEN_G29_MODIFIERS)
    rejection=f'''  #if ENABLED(AUTO_BED_LEVELING_BILINEAR) && DISABLED(PROBE_MANUALLY)
    if (parser.seen_test('U') && ({restrictions})) {{
      SERIAL_ERROR_MSG("SV04 NEXT G29U REFUSED: modifiers not allowed");
      G29_RETURN(true);
    }}
  #endif
'''
    code=replace_one(code,'  reset_stepper_timeout();\n', rejection+'\n  reset_stepper_timeout();\n',g)

    guard='''    // RTSUpdate() observes real bed temperature in the background; the
    // special G29 U requires 20s in [59, 61] C, with 60C setpoint.
    #if ENABLED(RTS_AVAILABLE)
      if (sv04_transactional_run && !sv04next::native_thermal_gate.ready((uint32_t)millis())) {
        SERIAL_ERROR_MSG("SV04 NEXT G29U REFUSED: bed not stable for 20s");
        G29_RETURN(true);
      }
    #else
      if (sv04_transactional_run) {
        SERIAL_ERROR_MSG("SV04 NEXT G29U REFUSED: no native DWIN temperature monitor");
        G29_RETURN(true);
      }
    #endif
'''
    # v3's preflight follows this line. Insert before v3 guards.
    code=replace_one(code,"    const bool sv04_transactional_run = parser.seen_test('U');\n",
        "    const bool sv04_transactional_run = parser.seen_test('U');\n"+guard,g)
    old='''          abl.measured_z = faux ? 0.001f * random(-100, 101) : probe.probe_at_point(abl.probePos, raise_after, abl.verbose_level);'''
    new='''          // Ordinary G29 still calls the OEM probe path exactly once.
          // G29 U alone performs two complete physical probe cycles.
          if (sv04_transactional_run && !faux) {
            const float first_z = probe.probe_at_point(abl.probePos, PROBE_PT_RAISE, abl.verbose_level);
            if (!isfinite(first_z)) abl.measured_z = NAN;
            else {
              const float second_z = probe.probe_at_point(abl.probePos, raise_after, abl.verbose_level);
              if (!isfinite(second_z) || ABS(first_z - second_z) > 0.06f) {
                SERIAL_ERROR_MSG("SV04 NEXT G29U ABORT: two-probe disagreement");
                abl.measured_z = NAN;
              }
              else abl.measured_z = (first_z + second_z) * 0.5f;
            }
          }
          else
            abl.measured_z = faux ? 0.001f * random(-100, 101) : probe.probe_at_point(abl.probePos, raise_after, abl.verbose_level);'''
    code=replace_one(code,old,new,g)
    # Refuse obviously faulty probe values before mutation of the live RAM mesh.
    old='''            const float z = abl.measured_z + abl.Z_offset;
            z_values[abl.meshCount.x][abl.meshCount.y] = z;'''
    new='''            const float z = abl.measured_z + abl.Z_offset;
            if (sv04_transactional_run && (!isfinite(z) || ABS(z) > 3.0f)) {
              SERIAL_ERROR_MSG("SV04 NEXT G29U ABORT: out-of-range mesh Z");
              abl.measured_z = NAN;
              break;
            }
            z_values[abl.meshCount.x][abl.meshCount.y] = z;'''
    code=replace_one(code,old,new,g)
    # Enforce the full runtime preflight at the end, even after stow.
    old='''      if (sv04_good) {
        sv04_mesh_guard.accept();'''
    new='''      if (sv04_good && !sv04next::native_thermal_gate.ready((uint32_t)millis()))
        sv04_good = false;
      if (sv04_good) {
        sv04_mesh_guard.accept();'''
    # Only include extra gate if the DWIN is enabled. In SV04 config it is.
    new='''      #if ENABLED(RTS_AVAILABLE)
        if (sv04_good && !sv04next::native_thermal_gate.ready((uint32_t)millis()))
          sv04_good = false;
      #endif
      if (sv04_good) {
        sv04_mesh_guard.accept();'''
    code=replace_one(code,old,new,g)
    out[g]=code

    # The original 2s update calls RTSUpdate; sampling on every idle invocation
    # is cheap. Does not heat the bed or touch the display resources.
    rt=original[r]
    rt=replace_one(rt,'#include "../../../module/probe.h"',
      '#include "../../../module/probe.h"\n#include "../../../feature/sv04_next/SV04NextNativeThermalGate.hpp"',r)
    rt=replace_one(rt,'#if ENABLED(RTS_AVAILABLE)\n\n#define CHECKFILEMENT true',
      '#if ENABLED(RTS_AVAILABLE)\n\nnamespace sv04next { NativeThermalGate native_thermal_gate; }\n\n#define CHECKFILEMENT true',r)
    rt=replace_one(rt,'void RTSUpdate()\n{', '''void RTSUpdate()
{
  // Observe only. This is NOT permission to start G28, G29, heater or EEPROM.
  sv04next::native_thermal_gate.observe(
    (uint32_t)millis(), thermalManager.degBed(),
    (float)thermalManager.degTargetBed(),
    !IsStopped() && !printJobOngoing() && !printingIsPaused());''',r)
    out[r]=rt
    out[PATCH_TARGET]=thermal_gate_source
    if out['Marlin/Configuration.h'] != original['Marlin/Configuration.h']:raise PatchRefused('OEM config changed')
    if out['Marlin/src/module/probe.cpp'] != original['Marlin/src/module/probe.cpp']:raise PatchRefused('OEM probe behavior changed')
    if any(s in new+guard for s in ['M500','settings.save(', 'queue.enqueue', 'setTargetBed(', 'process_subcommands_now']):
        raise PatchRefused('unsafe command injected')
    return out


def git_blob_sha(data:bytes)->str:return previous.previous.git_blob_sha(data)

def apply(root:Path, header:Path, evidence:Path|None=None):
    if (root/PATCH_TARGET).exists():raise PatchRefused('native header already exists: refuse replacement')
    originals={}
    for name,git_sha in OEM_BLOBS.items():
        raw=(root/name).read_bytes()
        if git_blob_sha(raw)!=git_sha:raise PatchRefused(f'Original drift: {name}')
        originals[name]=raw.decode('utf-8')
    generated=render(originals, header.read_text(encoding='utf-8'))
    report={'phase_range':'10.93-11.12','result':'NATIVE_BUILD_PENDING_NOT_FLASHABLE',
      'new_dwin_hmi_button':False,'physical_t1_park_verified':False,
      'eeprom_write_enabled':False,'automatic_heat_or_homing_enabled':False,
      'ordinary_g29_unchanged':True,'native_thermal_stability_gate_seconds':20,'patches':{}}
    for name,new_content in generated.items():
        if name not in originals or new_content!=originals[name]:
            report['patches'][name]={'sha256_after':hashlib.sha256(new_content.encode()).hexdigest()}
    for name,new_content in generated.items():
        if name not in originals or new_content!=originals[name]:
            f=root/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(new_content,encoding='utf-8')
    if evidence:
        evidence.parent.mkdir(parents=True,exist_ok=True)
        evidence.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path('.'))
    p.add_argument('--header',type=Path,default=Path('include/SV04NextNativeThermalGate.hpp'))
    p.add_argument('--evidence',type=Path)
    args=p.parse_args()
    print(json.dumps(apply(args.root,args.header,args.evidence),indent=2))
