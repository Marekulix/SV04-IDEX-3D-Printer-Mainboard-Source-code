#!/usr/bin/env python3
"""Native read-only status snapshot overlay on top of v10. NO DWIN writes.

Never queues commands, writes EEPROM, drives motors or modifies OEM configs.
"""
from __future__ import annotations
import argparse,hashlib,json
from pathlib import Path
import apply_native_guard_v10 as previous
import apply_native_guard_v5 as base
OEM_BLOBS=previous.OEM_BLOBS
RTS=previous.RTS
PatchRefused=previous.PatchRefused
replace_one=previous.replace_one
TARGET='Marlin/src/feature/sv04_next/SV04NextNativeStatusPacket.hpp'

def render(original:dict[str,str],thermal:str,visit:str,receipt:str,native:str,
           sensor:str,timeline:str,status:str)->dict[str,str]:
    required=('// SV04 NEXT 7: RAM-ONLY, versioned 32-byte diagnostic snapshot.',
       'bool permits_motion()const{return false;}',
       'bool permits_heating()const{return false;}',
       'bool permits_eeprom()const{return false;}',
       'bool is_physical_park_verified()const{return false;}',
       'data_[23] reserved 0', 'static bool verify(', 'crc16(')
    if not all(x in status for x in required):
        raise PatchRefused('untrusted or actuator-enabled status packet')
    out=previous.render(original,thermal,visit,receipt,native,sensor,timeline)
    rt=out[RTS]
    rt=replace_one(rt,
        '  #include "../../../feature/sv04_next/SV04NextNativeEventTimeline.hpp"',
        '  #include "../../../feature/sv04_next/SV04NextNativeEventTimeline.hpp"\n'
        '  #include "../../../feature/sv04_next/SV04NextNativeStatusPacket.hpp"',RTS)
    rt=replace_one(rt,
        '  namespace sv04next { NativeEventTimeline native_event_timeline; }',
        '  namespace sv04next { NativeEventTimeline native_event_timeline; }\n'
        '  namespace sv04next { NativeStatusPacket native_status_packet; }',RTS)
    anchor='''    sv04next::native_event_timeline.observe((uint32_t)millis(),
      sv04next::native_readiness.view(), sv04next::t1_endstop_observer);'''
    replacement=anchor+'''
    // Only capture into RAM. Do not send a new DWIN VP or enqueue any G-code.
    sv04next::native_status_packet.capture((uint32_t)millis(),
      sv04next::native_readiness.view(), sv04next::native_event_timeline.view(),
      sv04next::t1_endstop_observer);'''
    rt=replace_one(rt,anchor,replacement,RTS)
    if rt.count('native_status_packet.capture(')!=1 or any(k in replacement for k in
         ('queue.enqueue','settings.save','M500','M190','G28','DWIN_', 'sendData')):
        raise PatchRefused('unsafe native source injection')
    out[RTS]=rt;out[TARGET]=status
    for unchanged in ('Marlin/Configuration.h','Marlin/src/module/probe.cpp'):
        if out[unchanged]!=original[unchanged]:raise PatchRefused('OEM changed')
    return out

def apply(root:Path,thermal:Path,visit:Path,receipt:Path,native:Path,sensor:Path,
          timeline:Path,status:Path,evidence:Path|None=None):
    originals={}
    for path,sha in OEM_BLOBS.items():
        raw=(root/path).read_bytes()
        if previous.base.git_blob_sha(raw)!=sha:
            raise PatchRefused('original source hash changed: '+path)
        originals[path]=raw.decode('utf-8')
    out=render(originals,*[p.read_text(encoding='utf-8') for p in
         (thermal,visit,receipt,native,sensor,timeline,status)])
    report={'workflow':'NONE','native_build_verified':False,
       'automatic_heat':False,'automatic_homing':False,'automatic_g29':False,
       'automatic_eeprom':False,'physical_park_verified':False,
       'dwin_project_integrated':False,'flash_allowed':False,'changed':{}}
    for path,code in out.items():
        if path not in originals or code!=originals[path]:
            report['changed'][path]=hashlib.sha256(code.encode()).hexdigest()
            dest=root/path;dest.parent.mkdir(parents=True,exist_ok=True)
            dest.write_text(code,encoding='utf-8')
    if evidence:evidence.write_text(json.dumps(report,indent=2)+'\n')
    return report
if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--root',type=Path,default=Path('.'))
    for flag,file in [('thermal','SV04NextNativeThermalGate.hpp'),('visit','SV04NextVisitProof.hpp'),
       ('receipt','SV04NextG29UReceipt.hpp'),('native','SV04NextNativeReadiness.hpp'),
       ('sensor','SV04NextT1EndstopObserver.hpp'),('timeline','SV04NextNativeEventTimeline.hpp'),
       ('status','SV04NextNativeStatusPacket.hpp')]:
        p.add_argument('--'+flag,type=Path,default=Path('include')/file)
    p.add_argument('--evidence',type=Path)
    a=p.parse_args()
    print(json.dumps(apply(a.root,a.thermal,a.visit,a.receipt,a.native,a.sensor,
      a.timeline,a.status,a.evidence),indent=2))
