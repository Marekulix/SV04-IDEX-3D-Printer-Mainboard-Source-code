#!/usr/bin/env python3
"""SV04 NEXT 10.53–10.72: additional passive native G29-U safety guards.

Includes previously GitHub-compiled v2, subsequently prepared v3, and this
small v4 extension. No firmware is declared safe for flashing. No new HMI
buttons, heating, automatic homing, EEPROM writes or G-code scheduling.
"""
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path
import apply_native_guard_v3 as previous

OEM_BLOBS=previous.OEM_BLOBS
PatchRefused=previous.PatchRefused
replace_one=previous.replace_one

def render(source:dict[str,str])->dict[str,str]:
    out=previous.render(source)
    g='Marlin/src/gcode/bedlevel/abl/G29.cpp'
    contents=out[g]
    old='''                 ABS(probe.offset.z - sv04_mesh_guard.old_probe_offset) > 0.00001f)) {'''
    new='''                 ABS(probe.offset.z - sv04_mesh_guard.old_probe_offset) > 0.00001f ||
                 // Re-check IDEX state and XYZ trust before EVERY native point.
                 active_extruder != 0 ||
                 dual_x_carriage_mode != DXC_AUTO_PARK_MODE ||
                 !axis_is_trusted(X_AXIS) || !axis_is_trusted(Y_AXIS) ||
                 !axis_is_trusted(Z_AXIS) ||
                 !isfinite(inactive_extruder_x) ||
                 ABS(inactive_extruder_x-X2_MAX_POS) > 1.0f)) {'''
    contents=replace_one(contents,old,new,g)
    # Reject end-of-run if a position axis lost its trusted state.
    old='''          active_extruder != 0 ||
          !isfinite(inactive_extruder_x) ||'''
    new='''          active_extruder != 0 ||
          !axis_is_trusted(X_AXIS) ||
          !axis_is_trusted(Y_AXIS) ||
          !axis_is_trusted(Z_AXIS) ||
          !isfinite(inactive_extruder_x) ||'''
    contents=replace_one(contents,old,new,g)
    # Never include direct EEPROM storage or queued motion in the experimental guard.
    if 'settings.save()' in contents or 'queue.enqueue' in previous.PREFLIGHT + previous.POINT_CHECK:
        raise PatchRefused('unexpected side effect')
    out[g]=contents
    return out

def apply(root:Path,evidence:Path|None=None):
    originals={}
    for path,expected in OEM_BLOBS.items():
        raw=(root/path).read_bytes()
        actual=previous.git_blob_sha(raw)
        if actual!=expected:raise PatchRefused(f'OEM file changed: {path}, expected={expected}, actual={actual}')
        originals[path]=raw.decode('utf-8')
    patched=render(originals)
    report={'phase_range':'10.53-10.72',
            'result':'EXPERIMENTAL_NOT_FLASHABLE',
            'new_dwin_button':False,'new_dwin_hmi_binary':False,
            'physical_t1_park_verified':False,'nonblocking_auto60_wired':False,
            'automatic_eeprom_save_enabled':False,'firmware_hardware_validated':False,
            'patches':{}}
    for path,content in patched.items():
        report['patches'][path]={'original_git_blob':OEM_BLOBS[path],
            'new_sha256':hashlib.sha256(content.encode('utf-8')).hexdigest()}
    # Compute all outputs before first mutation. OEM SHA gate prevents drift.
    for path,content in patched.items():(root/path).write_text(content,encoding='utf-8')
    if evidence:
        evidence.parent.mkdir(parents=True,exist_ok=True)
        evidence.write_text(json.dumps(report,indent=2)+'\n')
    return report

if __name__=='__main__':
    cli=argparse.ArgumentParser();cli.add_argument('--root',type=Path,default=Path('.'));cli.add_argument('--evidence',type=Path)
    args=cli.parse_args();print(json.dumps(apply(args.root,args.evidence),indent=2))
