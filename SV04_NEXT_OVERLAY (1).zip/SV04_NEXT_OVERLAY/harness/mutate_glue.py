#!/usr/bin/env python3
"""Mutationskampagne gegen die Marlin-Bruecke include/SV04NextAuto60Glue.hpp, geprueft vom E2E-Harness (Maschine + Bruecke + erzeugter G28/G29-Code)."""
import os, shutil, subprocess, sys, tempfile
from pathlib import Path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); import run_harness as RH
BASE = RH.build_tree(Path(tempfile.mkdtemp())); GL = 'Marlin/src/feature/sv04_next/SV04NextAuto60Glue.hpp'; orig = (BASE / GL).read_text(encoding='utf-8')
M = [
 ('G01', 'Heizziel 65 statt 60', 'SV04_NEXT_SET_BED_TARGET(60); break;', 'SV04_NEXT_SET_BED_TARGET(65); break;'),
 ('G02', 'Heizung wird nie abgeschaltet', 'case Auto60Engine::Action::SetBedOff: SV04_NEXT_SET_BED_TARGET(0); break;', 'case Auto60Engine::Action::SetBedOff: break;'),
 ('G03', 'Messbefehl "G29" statt "G29 U"', 'SV04_NEXT_ENQUEUE("G29 U")', 'SV04_NEXT_ENQUEUE("G29")'),
 ('G04', 'Befehl "G29 U" statt "G28" beim Referenzieren', 'SV04_NEXT_ENQUEUE("G28")', 'SV04_NEXT_ENQUEUE("G29 U")'),
 ('G05', 'kein Wiedereintrittsschutz', 'if (auto60_in_tick()) return;', ''),
 ('G06', 'Einreihfehler (G28) wird ignoriert', 'case Auto60Engine::Action::Home: if (!SV04_NEXT_ENQUEUE("G28")) auto60_engine.notify_action_failed(); break;', 'case Auto60Engine::Action::Home: (void)SV04_NEXT_ENQUEUE("G28"); break;'),
 ('G07', 'Einreihfehler (G29 U) wird ignoriert', 'case Auto60Engine::Action::Measure: if (!SV04_NEXT_ENQUEUE("G29 U")) auto60_engine.notify_action_failed(); break;', 'case Auto60Engine::Action::Measure: (void)SV04_NEXT_ENQUEUE("G29 U"); break;'),
 ('G08', 'EEPROM-Commit als unterstuetzt melden', 'o.eeprom_commit_supported = false;', 'o.eeprom_commit_supported = true;'),
 ('G09', 'Thermotor immer bereit', 'o.thermal_ready = native_thermal_gate.ready(now);', 'o.thermal_ready = true;'),
 ('G10', 'Beleg-Sequenz von G28 nicht uebergeben', 'o.g28_seq = g.sequence;', 'o.g28_seq = 0;'),
 ('G11', 'G29-Phase nicht uebergeben', 'o.g29_phase = g29u_receipt.phase();', 'o.g29_phase = G29UReceipt::Phase::Never;'),
 ('G12', 'Benutzerabbruch wird nicht uebergeben', 'o.user_abort = auto60_abort_flag();', 'o.user_abort = false;'),
 ('G13', 'Not-Aus nicht uebergeben', 'o.stopped = IsStopped();', 'o.stopped = false;'),
 ('G14', 'Druckstatus nicht uebergeben', 'o.printing = printJobOngoing();', 'o.printing = false;'),
 ('G15', 'Soll-Temperatur nicht uebergeben (immer 60)', 'o.bed_target_c = (float)thermalManager.degTargetBed();', 'o.bed_target_c = 60.0f;'),
 ('G16', 'Quittung wird nie zurueckgesetzt', 'auto60_abort_flag() = false; auto60_ack_flag() = false;', ''),
]
work = tempfile.mkdtemp(); shutil.copytree(BASE / 'Marlin', work + '/Marlin'); shutil.copy(BASE / 'driver_e2e.cpp', work); res = {}
for mid, why, old, new in M:
    if orig.count(old) != 1: print(f'{mid} UNGUELTIG ({orig.count(old)}): {why}'); res[mid] = 'BAD'; continue
    (Path(work) / GL).write_text(orig.replace(old, new), encoding='utf-8')
    c = subprocess.run(['g++', '-std=gnu++14', '-O0', '-w', '-I.', 'driver_e2e.cpp', RH.G29, RH.G28, '-o', 'e2e_m'], cwd=work, capture_output=True, text=True)
    if c.returncode: print(f'{mid} INVALID  {why}'); res[mid] = 'INVALID'; continue
    try: r = subprocess.run(['./e2e_m'], cwd=work, capture_output=True, text=True, timeout=120); rc = r.returncode; out = r.stdout
    except subprocess.TimeoutExpired: rc, out = 1, 'FAIL Zeitueberschreitung'
    fl = [l[6:60].strip() for l in out.splitlines() if l.startswith('FAIL')]; res[mid] = 'killed' if rc else 'SURVIVED'
    print(f'{mid} {res[mid]:9} {why}' + (f'  <- {len(fl)} Pruefungen, z. B. {fl[0]}' if fl else ''), flush=True)
k = sum(v == 'killed' for v in res.values()); s = [m for m, v in res.items() if v == 'SURVIVED']
print(f'--- erkannt {k}, UEBERLEBT {len(s)}: {s}, ungueltig {sum(v in ("BAD", "INVALID") for v in res.values())} von {len(res)}')
