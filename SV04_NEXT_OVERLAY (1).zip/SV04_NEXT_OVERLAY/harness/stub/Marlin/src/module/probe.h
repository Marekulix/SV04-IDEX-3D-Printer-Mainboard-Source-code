// MARLIN-ATTRAPPE für den Host-Harness. KEIN Marlin-Code. Sie bildet nur die vom Overlay benutzten Symbole nach; reale Semantik wird erst durch den CI-Build belegt.
#pragma once
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <string>
#include <vector>
#include <functional>
#include <deque>
#define DUAL_X_CARRIAGE 1
#define PSTR(s) s
typedef int celsius_t;
#define ENABLED(x) (x)
#define DISABLED(x) (!(x))
#ifndef AUTO_BED_LEVELING_BILINEAR
#define AUTO_BED_LEVELING_BILINEAR 1
#endif
#define PROBE_MANUALLY 0
#ifndef RTS_AVAILABLE
#define RTS_AVAILABLE 1
#endif
#define TERN_(O, A)
#define TERN0(O, A) 0
#define G29_TYPE void
#define GRID_MAX_POINTS_X 4
#define GRID_MAX_POINTS_Y 4
#define ABS(x) fabsf(x)
#define X_AXIS 0
#define Y_AXIS 1
#define Z_AXIS 2
#define DXC_AUTO_PARK_MODE 1
#define PROBE_PT_RAISE 1
#define AUTO_BED_LEVEL_1POINT_VP 1000
#define AUTO_BED_LEVEL_ICON_VP 900
#define X2_MAX_POS 362.0f
struct xy_pos_t { float x = 0, y = 0; };
struct xy_float_t { float x = 0, y = 0; };
struct World {
  std::string parser_letters; bool stopped = false, printing = false, paused = false, blocks = false;
  bool trusted[3] = {true, true, true}; int target = 60; float bed = 60.0f; uint32_t now_ms = 100000;
  int point_idx = 0, probe_calls = 0, eeprom_saves = 0, levelling_toggles = 0, refresh_calls = 0, rts_sends = 0, rts_pages = 0, progress_msgs = 0, restore_msgs = 0, errors = 0;
  float rts_vals[16]; int rts_seen = 0; std::vector<std::string> log;
  std::deque<std::string> queue; std::vector<int> target_log;
  std::vector<float> probe_script;                 // je Aufruf von probe_at_point; fehlt ein Eintrag -> NAN
  std::function<void(int)> before_probe;           // Einspeisung von Weltveränderungen vor dem n-ten Sondenaufruf
  std::function<void(int)> on_progress;            // nach der Fortschrittsmeldung eines Punktes (zeitlich NACH der Prüfung direkt nach der Antastung)
};
extern World w;
extern bool faux; extern int raise_after; extern int active_extruder; extern int dual_x_carriage_mode; extern float inactive_extruder_x;
extern float z_values[GRID_MAX_POINTS_X][GRID_MAX_POINTS_Y]; extern xy_pos_t bilinear_start; extern xy_float_t bilinear_grid_spacing;
struct DynX { operator int() const { return w.point_idx % 4; } }; struct DynY { operator int() const { return w.point_idx / 4; } };
struct Abl { xy_pos_t probePos; struct { DynX x; DynY y; } meshCount; int verbose_level = 0; float measured_z = 0; float Z_offset = 0; bool dryrun = false; };
extern Abl abl;
struct Parser { bool seen_test(char c) const { return w.parser_letters.find(c) != std::string::npos; } }; extern Parser parser;
struct Planner { bool leveling_active = true; bool has_blocks_queued() const { return w.blocks; } }; extern Planner planner;
struct ProbeOffset { float z = -1.10f; }; struct Probe { ProbeOffset offset; float probe_at_point(const xy_pos_t &, int, int); bool can_reach(const xy_pos_t &) { return true; } }; extern Probe probe;
struct Thermal { float degBed() const { return w.bed; } int degTargetBed() const { return w.target; } void setTargetBed(celsius_t c) { w.target = c; w.target_log.push_back(c); } }; extern Thermal thermalManager;
struct Settings { bool save() { ++w.eeprom_saves; return true; } }; extern Settings settings;
struct Rts { void RTS_SndData(float v, int vp) { ++w.rts_sends; int i = (vp - AUTO_BED_LEVEL_1POINT_VP) / 2; if (i >= 0 && i < 16) { w.rts_vals[i] = v; ++w.rts_seen; } } }; extern Rts rtscheck;
inline bool IsStopped() { return w.stopped; } inline bool printJobOngoing() { return w.printing; } inline bool printingIsPaused() { return w.paused; }
inline bool axis_is_trusted(int a) { return w.trusted[a]; }
inline void reset_stepper_timeout() {} inline void report_current_position() {} inline void RTS_AutoBedLevelPage() { ++w.rts_pages; }
inline void set_bed_leveling_enabled(bool b) { planner.leveling_active = b; ++w.levelling_toggles; } inline void refresh_bed_level() { ++w.refresh_calls; }
inline uint32_t millis() { return w.now_ms; } inline long random(long a, long) { return a; }
inline void g_next_point() { ++w.point_idx; }
inline void sv_log(const char *m) { w.log.push_back(m); ++w.errors; }
#define SERIAL_ERROR_MSG(m) do { sv_log(m); if (strstr(m, "restored")) ++w.restore_msgs; } while (0)
template <class... A> void sv_echo(const char *m, A... a) { (void)sizeof...(a); w.log.push_back(m); if (strstr(m, "PROGRESS")) { ++w.progress_msgs; if (w.on_progress) w.on_progress(w.progress_msgs - 1); } }
#define SERIAL_ECHOLNPGM(...) sv_echo(__VA_ARGS__)
struct Queue { bool full = false; std::string fail_cmd; std::function<void()> on_enqueue; bool enqueue_one_P(const char *s) { if (on_enqueue) on_enqueue(); if (full || (!fail_cmd.empty() && fail_cmd == s)) return false; w.queue.push_back(s); return true; } bool has_commands_queued() const { return !w.queue.empty(); } }; extern Queue queue;
void homeaxis(int);
class GcodeSuite { public: static G29_TYPE G29(); static void G28(); };
