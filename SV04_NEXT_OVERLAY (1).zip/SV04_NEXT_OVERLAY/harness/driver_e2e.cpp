// E2E-Harness: Auto60Engine -> Marlin-Bruecke -> Warteschlange -> der vom Overlay ERZEUGTE G28.cpp/G29.cpp-Code -> echte Belege -> Auto60Engine.
// Stufe: SIMULATION gegen eine Marlin-Attrappe (kein Marlin-Build). Waehrend G28/G29 laeuft die Zeit weiter (wie RTSUpdate() ueber idle()).
#define SV04_NEXT_AUTO60_ENGINE 1
#include "Marlin/src/module/probe.h"
#include "Marlin/src/feature/sv04_next/SV04NextG29UReceipt.hpp"
#include "Marlin/src/feature/sv04_next/SV04NextNativeThermalGate.hpp"
#include "Marlin/src/feature/sv04_next/SV04NextAuto60Glue.hpp"
#include <algorithm>
#include <cstdio>
#include <cmath>
namespace sv04next { NativeThermalGate native_thermal_gate; Auto60Engine auto60_engine; }
extern bool sv04_next_g29_u_active;
World w; bool faux = false; int raise_after = 0; int active_extruder = 0; int dual_x_carriage_mode = DXC_AUTO_PARK_MODE; float inactive_extruder_x = 362.0f;
float z_values[GRID_MAX_POINTS_X][GRID_MAX_POINTS_Y]; xy_pos_t bilinear_start; xy_float_t bilinear_grid_spacing; Abl abl; Parser parser; Planner planner; Probe probe; Thermal thermalManager; Settings settings; Rts rtscheck; Queue queue;
using E = sv04next::Auto60Engine; using St = E::State; using Rs = E::Reason;
static float OLD[4][4], NEWV[16]; static float noise_state = 0; static bool g28_trusted_result = true; static int nan_point = -1; static uint32_t now_base = 100000; static bool user_abort_mid_g29 = false, print_mid_g29 = false, stop_mid_g29 = false, foreign_mid_g29 = false; static int g29_calls = 0, g28_calls = 0; static St term_st = St::Idle; static Rs term_rs = Rs::None;
static void advance(uint32_t ms) {            // entspricht idle() -> RTSUpdate(): Physik, Thermotor, Bruecke
  for (uint32_t t = 0; t < ms; t += 250) {
    w.now_ms += 250; float tgt = (float)w.target; if (tgt > 0.0f) { float d = tgt - w.bed, st = 0.5f * 0.25f; w.bed += (d > 0 ? (d < st ? d : st) : (d > -st ? d : -st)); } else w.bed += (25.0f - w.bed) * 0.002f;
    noise_state = std::fmod(noise_state * 7.0f + 0.37f, 1.0f); float m = (tgt > 0.0f && std::fabs(w.bed - tgt) < 1.0f) ? w.bed + (noise_state - 0.5f) * 0.3f : w.bed; float keep = w.bed; w.bed = m;
    sv04next::native_thermal_gate.observe(w.now_ms, w.bed, (float)w.target, !w.printing && !w.stopped);
    sv04next::auto60_glue_tick(); w.bed = keep;
  }
}
void homeaxis(int) { advance(5000); w.trusted[0] = w.trusted[1] = w.trusted[2] = g28_trusted_result; }
float Probe::probe_at_point(const xy_pos_t &, int, int) { int n = w.probe_calls++; advance(7500); if (user_abort_mid_g29 && n == 9) { sv04next::auto60_user_abort(); user_abort_mid_g29 = false; advance(500); } if (print_mid_g29 && n == 9) { w.printing = true; print_mid_g29 = false; advance(500); } if (stop_mid_g29 && n == 9) { w.stopped = true; stop_mid_g29 = false; advance(500); } if (foreign_mid_g29 && n == 9) { w.target = 55; foreign_mid_g29 = false; advance(500); } if (n == 0) { bilinear_start.x = 33; } return (nan_point >= 0 && n / 2 == nan_point) ? NAN : (1.0f + 0.01f * (float)(n / 2) + (n % 2 ? 0.02f : 0.0f)); }
static void reset() {
  w = World(); w.now_ms = now_base; w.bed = 25.0f; w.target = 0; w.trusted[0] = w.trusted[1] = w.trusted[2] = false; for (int x = 0; x < 4; ++x) for (int y = 0; y < 4; ++y) { OLD[x][y] = 0.10f * (float)x + 0.37f * (float)y + 0.05f; z_values[x][y] = OLD[x][y]; }
  planner.leveling_active = true; probe.offset.z = -1.10f; active_extruder = 0; dual_x_carriage_mode = DXC_AUTO_PARK_MODE; inactive_extruder_x = 362.0f; abl = Abl(); sv04_next_g29_u_active = false; queue = Queue(); g28_trusted_result = true; nan_point = -1; user_abort_mid_g29 = print_mid_g29 = stop_mid_g29 = foreign_mid_g29 = false; g29_calls = g28_calls = 0; term_st = St::Idle; term_rs = Rs::None;
  sv04next::native_thermal_gate.reset(); sv04next::auto60_engine = E(); sv04next::auto60_abort_flag() = sv04next::auto60_ack_flag() = sv04next::auto60_in_tick() = false; sv04next::g29u_receipt = sv04next::G29UReceipt();
  for (int p = 0; p < 16; ++p) NEWV[p] = (1.0f + 0.01f * (float)p + (1.0f + 0.01f * (float)p + 0.02f)) * 0.5f;
}
static void run_machine(bool start, uint32_t max_ms) {
  uint32_t t = 0; if (start) { advance(1000); sv04next::auto60_request_start(); }
  while (t < max_ms) {
    advance(250); t += 250;
    if (!w.queue.empty()) { std::string c = w.queue.front(); w.queue.pop_front();
      if (c == "G28") { ++g28_calls; parser.seen_test('x'); w.parser_letters = ""; GcodeSuite::G28(); }
      else if (c == "G29 U") { ++g29_calls; w.parser_letters = "U"; w.probe_calls = 0; w.point_idx = 0; GcodeSuite::G29(); }
      else { std::printf("FAIL  unbekannter Befehl in der Warteschlange: %s\n", c.c_str()); } }
    St s = sv04next::auto60_engine.state(); if ((s == St::Done || s == St::DoneRamOnly || s == St::AbortLocked) && w.queue.empty() && !sv04_next_g29_u_active) { term_st = s; term_rs = sv04next::auto60_engine.reason(); advance(3000); sv04next::auto60_user_ack(); advance(1000); if (sv04next::auto60_engine.state() == St::Idle) break; }
  }
}
static int fails = 0, total = 0;
static void check(const char *n, bool ok, const char *why = "") { ++total; if (ok) std::printf("PASS  %s\n", n); else { ++fails; std::printf("FAIL  %-70s %s\n", n, why); } }
static bool mesh_old() { return memcmp(z_values, OLD, sizeof(OLD)) == 0; }
static bool mesh_new() { for (int p = 0; p < 16; ++p) if (std::fabs(z_values[p % 4][p / 4] - NEWV[p]) > 1e-5f) return false; return true; }
int main() {
  { reset(); run_machine(true, 1500000); bool ok = sv04next::auto60_engine.state() == St::Idle && g28_calls == 1 && g29_calls == 1 && mesh_new() && w.target == 0 && w.target_log == std::vector<int>({60, 0}) && w.eeprom_saves == 0 && probe.offset.z == -1.10f && planner.leveling_active && sv04next::g29u_receipt.phase() == sv04next::G29UReceipt::Phase::RamOnlySuccess;
    check("E2E-01 Erfolg: G28 dann G29 U genau einmal, neues Mesh im RAM, Soll 60 dann 0, EEPROM 0, Offset unveraendert", ok, "Ablauf"); }
  { reset(); run_machine(true, 1500000); check("E2E-02 Ende des Erfolgslaufs: DoneRamOnly(CommitNotAvailable), weil Commit nicht verdrahtet ist (nie M500/settings.save)", term_st == St::DoneRamOnly && term_rs == Rs::CommitNotAvailable && w.eeprom_saves == 0, "Endzustand"); }
  for (int k : {0, 7, 15}) { reset(); nan_point = k; run_machine(true, 1500000); char nm[128]; std::snprintf(nm, sizeof nm, "E2E-03 Sonde liefert NaN an Punkt %d: echter G29-Code rollt zurueck, Maschine AbortLocked, Heizung 0", k);
    check(nm, term_st == St::AbortLocked && term_rs == Rs::MeshFailed && mesh_old() && w.restore_msgs == 1 && w.target == 0 && w.eeprom_saves == 0 && g29_calls == 1 && probe.offset.z == -1.10f && sv04next::g29u_receipt.phase() == sv04next::G29UReceipt::Phase::Failed, "Rollback/Heizung"); }
  { reset(); g28_trusted_result = false; run_machine(true, 1500000); check("E2E-04 G28 endet ohne Vertrauen: Maschine bricht ab (HomeFailed), G29 U wird NIE eingereiht, Heizung 0", term_st == St::AbortLocked && term_rs == Rs::HomeFailed && g28_calls == 1 && g29_calls == 0 && w.target == 0 && mesh_old() && w.target_log == std::vector<int>({60, 0}), "Ablauf"); }
  { reset(); user_abort_mid_g29 = true; run_machine(true, 1500000); check("E2E-05 Benutzerabbruch MITTEN in G29: Heizung aus -> echter G29-Code bricht ab und rollt zurueck", term_st == St::AbortLocked && term_rs == Rs::UserAbort && mesh_old() && w.restore_msgs == 1 && w.target == 0 && w.eeprom_saves == 0 && sv04next::g29u_receipt.phase() != sv04next::G29UReceipt::Phase::RamOnlySuccess, "kein Abbruch/Rollback"); }
  { reset(); print_mid_g29 = true; run_machine(true, 1500000); check("E2E-06 Druckstart MITTEN in G29: echter G29-Code bricht ab und rollt zurueck, Heizung 0", term_st == St::AbortLocked && term_rs == Rs::ExternalActivity && mesh_old() && w.restore_msgs == 1 && w.target == 0 && w.eeprom_saves == 0, "kein Abbruch/Rollback"); }
  { reset(); queue.full = true; run_machine(true, 1500000); check("E2E-07 Warteschlange voll (G28 nicht einreihbar): ActionFailed, nichts ausgefuehrt, Heizung 0", term_st == St::AbortLocked && term_rs == Rs::ActionFailed && g28_calls == 0 && g29_calls == 0 && w.target == 0 && mesh_old() && w.target_log == std::vector<int>({60, 0}), "Ablauf"); }
  { reset(); queue.on_enqueue = [] { sv04next::auto60_glue_tick(); }; run_machine(true, 1500000); check("E2E-08 Wiedereintritt (enqueue ruft idle -> RTSUpdate -> Tick): keine Doppelaktion, Ablauf unveraendert", term_st == St::DoneRamOnly && g28_calls == 1 && g29_calls == 1 && mesh_new() && w.target_log == std::vector<int>({60, 0}), "Doppelaktion"); }
  { reset(); queue.fail_cmd = "G29 U"; run_machine(true, 1500000); check("E2E-07b G28 geht, G29 U nicht einreihbar: ActionFailed, G29 nie ausgefuehrt, Heizung 0, Mesh unveraendert", term_st == St::AbortLocked && term_rs == Rs::ActionFailed && g28_calls == 1 && g29_calls == 0 && w.target == 0 && mesh_old(), "Ablauf"); }
  { reset(); stop_mid_g29 = true; run_machine(true, 1500000); check("E2E-11 Not-Aus MITTEN in G29: Maschine Stopped, echter G29-Code rollt zurueck, Heizung 0", term_st == St::AbortLocked && term_rs == Rs::Stopped && mesh_old() && w.restore_msgs == 1 && w.target == 0 && w.eeprom_saves == 0, "Ablauf"); }
  { reset(); foreign_mid_g29 = true; run_machine(true, 1500000); check("E2E-12 Fremder setzt Soll auf 55 MITTEN in G29: Maschine TempLost, Rollback im echten G29-Code, Heizung 0", term_st == St::AbortLocked && term_rs == Rs::TempLost && mesh_old() && w.restore_msgs == 1 && w.target == 0, "Ablauf"); }
  { reset(); user_abort_mid_g29 = true; run_machine(true, 1500000); bool first_ok = mesh_old() && term_rs == Rs::UserAbort && sv04next::auto60_engine.state() == St::Idle; w.probe_calls = 0; g28_calls = g29_calls = 0; w.target_log.clear(); w.restore_msgs = 0; run_machine(true, 1500000);
    check("E2E-13 zweiter Lauf direkt nach einem Abbruch: Abbruchmarke wurde zurueckgesetzt, Lauf gelingt (DoneRamOnly, neues Mesh)", first_ok && term_st == St::DoneRamOnly && mesh_new() && g28_calls == 1 && g29_calls == 1, "Marke blieb haengen"); }
  { reset(); run_machine(false, 600000); check("E2E-09 Makro gesetzt, aber kein request_start(): in 10 Minuten KEIN Soll, KEIN Befehl, Mesh unveraendert", w.target_log.empty() && w.queue.empty() && g28_calls == 0 && g29_calls == 0 && mesh_old(), "es hat etwas gestartet"); }
  { reset(); sv04next::auto60_engine.request_start(); bool second = sv04next::auto60_engine.request_start(); check("E2E-10 zweiter Start waehrend eines Laufs wird abgelehnt", !second); }
  std::printf("=== %d E2E-Pruefungen, %d FAIL\n", total, fails); return fails ? 1 : 0;
}
