// Host-Harness für den TATSÄCHLICH vom Overlay erzeugten G29.cpp-Text (Marlin-Attrappe, Fake-Sensoren, Fehlereinspeisung). Stufe: SIMULATION (Host), kein Marlin-Build.
#include "Marlin/src/module/probe.h"
#include "Marlin/src/feature/sv04_next/SV04NextG29UReceipt.hpp"
#include "Marlin/src/feature/sv04_next/SV04NextNativeThermalGate.hpp"
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <new>
namespace sv04next { NativeThermalGate native_thermal_gate; }
extern bool sv04_next_g29_u_active;
World w; bool faux = false; int raise_after = 0; int active_extruder = 0; int dual_x_carriage_mode = DXC_AUTO_PARK_MODE; float inactive_extruder_x = 362.0f;
float z_values[GRID_MAX_POINTS_X][GRID_MAX_POINTS_Y]; xy_pos_t bilinear_start; xy_float_t bilinear_grid_spacing; Abl abl; Parser parser; Planner planner; Probe probe; Thermal thermalManager; Settings settings; Rts rtscheck;
float Probe::probe_at_point(const xy_pos_t &, int, int) { int n = w.probe_calls++; if (n == 0) { bilinear_start.x = 33; bilinear_start.y = 44; bilinear_grid_spacing.x = 7; bilinear_grid_spacing.y = 8; }   /* OEM-G29 setzt das Gitter für das neue Mesh */ if (w.before_probe) w.before_probe(n); return n < (int)w.probe_script.size() ? w.probe_script[n] : NAN; }
static float OLD[4][4], NEWV[16];
static std::vector<float> good_script() { std::vector<float> s; for (int p = 0; p < 16; ++p) { float f = 1.00f + 0.01f * (float)p; s.push_back(f); s.push_back(f + 0.02f); NEWV[p] = (f + (f + 0.02f)) * 0.5f; } return s; }
static void reset(const char *letters = "U") {
  w = World(); w.parser_letters = letters; for (int x = 0; x < 4; ++x) for (int y = 0; y < 4; ++y) { OLD[x][y] = 0.10f * (float)x + 0.37f * (float)y + 0.05f; z_values[x][y] = OLD[x][y]; }
  planner.leveling_active = true; probe.offset.z = -1.10f; active_extruder = 0; dual_x_carriage_mode = DXC_AUTO_PARK_MODE; inactive_extruder_x = 362.0f; abl = Abl(); faux = false; sv04_next_g29_u_active = false;
  bilinear_start.x = 10; bilinear_start.y = 20; bilinear_grid_spacing.x = 5; bilinear_grid_spacing.y = 6; sv04next::g29u_receipt = sv04next::G29UReceipt();
  sv04next::native_thermal_gate.reset(); for (uint32_t t = 0; t <= 25000u; t += 500u) sv04next::native_thermal_gate.observe(t, 60.0f, 60.0f, true); w.now_ms = 25000u; w.probe_script = good_script();
}
enum Out { SUCCESS, ROLLBACK, REFUSED, NONU };
static int fails = 0, total = 0; static bool g_skip_off = false, g_prior_active = false;
static bool mesh_is_old() { return memcmp(z_values, OLD, sizeof(OLD)) == 0; }
static bool mesh_is_new() { for (int p = 0; p < 16; ++p) if (z_values[p % 4][p / 4] != NEWV[p]) return false; return true; }
static void run(const char *name, Out exp) {
  ++total; GcodeSuite::G29(); const auto &r = sv04next::g29u_receipt; std::string why; auto bad = [&](const char *m) { if (why.empty()) why = m; };
  if (w.eeprom_saves != 0) bad("EEPROM geschrieben");
  if (exp != NONU && !g_skip_off && probe.offset.z != -1.10f) bad("Z-Offset verändert"); if (sv04_next_g29_u_active != g_prior_active) bad("Lauf-Flag nicht zurückgesetzt");
  if (exp == SUCCESS) { if (r.phase() != sv04next::G29UReceipt::Phase::RamOnlySuccess || r.completed() != 16) bad("kein RamOnlySuccess 16/16"); if (!mesh_is_new()) bad("neues Mesh nicht im RAM"); if (w.restore_msgs) bad("Rollback trotz Erfolg"); if (!planner.leveling_active) bad("Leveling nicht aktiv"); if (w.progress_msgs != 16) bad("Fortschritt != 16"); }
  if (exp == ROLLBACK) { if (!mesh_is_old()) bad("altes Mesh NICHT wiederhergestellt"); if (r.phase() == sv04next::G29UReceipt::Phase::RamOnlySuccess) bad("Erfolgsbeleg trotz Fehler"); if (w.restore_msgs != 1) bad("kein (genau ein) Rollback"); if (w.refresh_calls < 1) bad("refresh_bed_level nicht aufgerufen"); if (!planner.leveling_active) bad("Leveling nicht wie vorher"); if (bilinear_start.x != 10 || bilinear_start.y != 20 || bilinear_grid_spacing.x != 5 || bilinear_grid_spacing.y != 6) bad("Gitterparameter nicht zurück");
    float got[16]; for (int i = 0; i < 16; ++i) got[i] = w.rts_vals[i]; float exp_v[16]; int k = 0; for (int y = 0; y < 4; ++y) for (int x = 0; x < 4; ++x) exp_v[k++] = OLD[x][y] * 1000; std::sort(got, got + 16); std::sort(exp_v, exp_v + 16); for (int i = 0; i < 16; ++i) if (got[i] != exp_v[i]) { bad("Anzeige zeigt nicht das alte Mesh"); break; } }
  if (exp == REFUSED) { if (!mesh_is_old()) bad("Mesh bei Verweigerung verändert"); if (w.probe_calls != 0) bad("Sonde trotz Verweigerung benutzt"); if (r.phase() != sv04next::G29UReceipt::Phase::Refused) bad("Beleg nicht Refused"); if (w.restore_msgs) bad("Rollback ohne Änderung"); if (w.levelling_toggles) bad("Leveling umgeschaltet"); }
  if (exp == NONU) { if (r.phase() != sv04next::G29UReceipt::Phase::Never) bad("Beleg bei normalem G29 verändert"); if (w.restore_msgs) bad("Rollback bei normalem G29"); }
  if (!why.empty()) { ++fails; std::printf("FAIL  %-58s %s\n", name, why.c_str()); } else std::printf("PASS  %s\n", name);
}
#define SC(name, exp, setup) do { reset(); g_skip_off = false; g_prior_active = false; setup; run(name, exp); } while (0)
int main() {
  SC("S00 Erfolg 16/16 mit zwei Antastungen je Punkt", SUCCESS, {});
  char nm[96];
  for (int k = 0; k < 16; ++k) { snprintf(nm, sizeof nm, "F%02d erste Antastung NaN an Punkt %d", k, k); SC(nm, ROLLBACK, w.probe_script[2 * k] = NAN); }
  for (int k = 0; k < 16; ++k) { snprintf(nm, sizeof nm, "F%02d zweite Antastung NaN an Punkt %d", k, k); SC(nm, ROLLBACK, w.probe_script[2 * k + 1] = NAN); }
  for (int k = 0; k < 16; ++k) { snprintf(nm, sizeof nm, "F%02d Abweichung 0,07 mm an Punkt %d", k, k); SC(nm, ROLLBACK, w.probe_script[2 * k + 1] = w.probe_script[2 * k] + 0.07f); }
  for (int k : {0, 7, 15}) { snprintf(nm, sizeof nm, "R%02d Messhöhe 3,01 mm an Punkt %d", k, k); SC(nm, ROLLBACK, { w.probe_script[2 * k] = 3.01f; w.probe_script[2 * k + 1] = 3.01f; }); }
  for (int k : {0, 5, 15}) { snprintf(nm, sizeof nm, "T%02d Bett 61,5 C vor Antastung an Punkt %d", k, k); SC(nm, ROLLBACK, w.before_probe = [k](int n) { if (n == 2 * k) w.bed = 61.5f; }); }
  for (int k : {0, 9}) { snprintf(nm, sizeof nm, "T%02d Soll-Temperatur 65 C mitten im Lauf (Punkt %d)", k, k); SC(nm, ROLLBACK, w.before_probe = [k](int n) { if (n == 2 * k) w.target = 65; }); }
  for (int k : {0, 8, 15}) { snprintf(nm, sizeof nm, "P%02d Druckjob startet anderswo (Punkt %d)", k, k); SC(nm, ROLLBACK, w.before_probe = [k](int n) { if (n == 2 * k) w.printing = true; }); }
  for (int k : {3, 12}) { snprintf(nm, sizeof nm, "P%02d Not-Aus (IsStopped) an Punkt %d", k, k); SC(nm, ROLLBACK, w.before_probe = [k](int n) { if (n == 2 * k) w.stopped = true; }); }
  for (int k : {2, 13}) { snprintf(nm, sizeof nm, "W%02d Werkzeugwechsel auf T1 an Punkt %d", k, k); SC(nm, ROLLBACK, w.before_probe = [k](int n) { if (n == 2 * k) active_extruder = 1; }); }
  for (int k : {4, 11}) { snprintf(nm, sizeof nm, "A%02d Z-Achse verliert Vertrauen an Punkt %d", k, k); SC(nm, ROLLBACK, w.before_probe = [k](int n) { if (n == 2 * k) w.trusted[2] = false; }); }
  for (int k : {1, 10}) { snprintf(nm, sizeof nm, "O%02d Probe-Offset ändert sich mitten im Lauf (Punkt %d)", k, k); SC(nm, ROLLBACK, w.before_probe = [k](int n) { if (n == 2 * k) probe.offset.z = -1.20f; }); }
  SC("D01 DXC-Modus wechselt mitten im Lauf", ROLLBACK, w.before_probe = [](int n) { if (n == 6) dual_x_carriage_mode = 0; });
  SC("D02 inaktiver Schlitten X2 verlässt 362 mitten im Lauf", ROLLBACK, w.before_probe = [](int n) { if (n == 6) inactive_extruder_x = 300.0f; });
  SC("L01 Leveling nach dem Lauf nicht aktiv (Annahme der Attrappe)", ROLLBACK, w.before_probe = [](int n) { if (n == 0) planner.leveling_active = false; });
  SC("V01 vorab: Thermotor nicht bereit (nie 20 s beobachtet)", REFUSED, sv04next::native_thermal_gate.reset());
  for (const char *m : {"UN", "UO", "UJ", "UW", "UD", "UC", "UZ", "UE", "UH", "UL", "UR", "UB", "UF", "US", "UV", "UX", "UY", "UP", "UQ", "UT"}) { snprintf(nm, sizeof nm, "V02 vorab: Modifikator %c zusätzlich zu U", m[1]); reset(m); run(nm, REFUSED); }
  SC("V03 vorab: Bewegung in der Warteschlange", REFUSED, w.blocks = true);
  SC("V04 vorab: Druck läuft", REFUSED, w.printing = true);
  SC("V05 vorab: Druck pausiert", REFUSED, w.paused = true);
  SC("V06 vorab: Not-Aus gesetzt", REFUSED, w.stopped = true);
  SC("V07 vorab: Werkzeug T1 aktiv", REFUSED, active_extruder = 1);
  SC("V08 vorab: DXC-Modus nicht Auto-Park", REFUSED, dual_x_carriage_mode = 0);
  for (int a = 0; a < 3; ++a) { snprintf(nm, sizeof nm, "V09 vorab: Achse %d nicht vertrauenswürdig", a); SC(nm, REFUSED, w.trusted[a] = false); }
  SC("V10 vorab: X2 nicht bei 362", REFUSED, inactive_extruder_x = 300.0f);
  SC("V11 vorab: Bett 58 C", REFUSED, w.bed = 58.0f);
  SC("V12 vorab: Soll-Temperatur 0", REFUSED, w.target = 0);
  SC("V13 vorab: Probe-Offset NaN", REFUSED, { probe.offset.z = NAN; g_skip_off = true; });
  SC("V14 vorab: Wiedereintritt (Lauf aktiv)", REFUSED, { sv04_next_g29_u_active = true; g_prior_active = true; });
  // Kurzzeitige Störungen: gesetzt kurz vor dem Punktwechsel, vor der nächsten Antastung wieder gelöscht. Nur die Prüfung VOR jedem Punkt kann sie sehen.
  struct Tr { const char *n; std::function<void()> on, off; };
  std::vector<Tr> trs = { {"Druckjob", [] { w.printing = true; }, [] { w.printing = false; }}, {"Not-Aus", [] { w.stopped = true; }, [] { w.stopped = false; }}, {"Werkzeug T1", [] { active_extruder = 1; }, [] { active_extruder = 0; }},
    {"X-Vertrauen", [] { w.trusted[0] = false; }, [] { w.trusted[0] = true; }}, {"DXC-Modus", [] { dual_x_carriage_mode = 0; }, [] { dual_x_carriage_mode = DXC_AUTO_PARK_MODE; }}, {"X2 verlässt 362", [] { inactive_extruder_x = 300.0f; }, [] { inactive_extruder_x = 362.0f; }},
    {"Probe-Offset", [] { probe.offset.z = -1.2f; }, [] { probe.offset.z = -1.10f; }}, {"Soll 65 C", [] { w.target = 65; }, [] { w.target = 60; }}, {"Bett 61,5 C", [] { w.bed = 61.5f; }, [] { w.bed = 60.0f; }} };
  for (const auto &t : trs) { snprintf(nm, sizeof nm, "K01 kurzzeitig %s zwischen Punkt 5 und 6", t.n); SC(nm, ROLLBACK, w.before_probe = [t](int n) { if (n == 11) t.on(); if (n == 12) t.off(); }); }
  // Störung erst bei der LETZTEN Antastung (Punkt 15, Aufruf 31): nur die Abschlussprüfung bzw. die Prüfung nach der Antastung kann sie sehen.
  for (const auto &t : trs) { snprintf(nm, sizeof nm, "K02 %s erst bei der letzten Antastung", t.n); SC(nm, ROLLBACK, w.before_probe = [t](int n) { if (n == 31) t.on(); }); }
  // Störung NUR direkt nach der Antastung sichtbar (vor der Fortschrittsmeldung gelöscht): nur die Prüfung nach der Antastung kann sie sehen.
  for (int k : {0, 7, 15}) { snprintf(nm, sizeof nm, "K03 Bett 61,5 C nur direkt nach der Antastung (Punkt %d)", k); SC(nm, ROLLBACK, { w.before_probe = [k](int n) { if (n == 2 * k + 1) w.bed = 61.5f; }; w.on_progress = [k](int p) { if (p == k) w.bed = 60.0f; }; }); }
  // Folgeläufe ohne Zwischen-Reset: Erfolg, dann Fehler (Rückfall auf das ERFOLGS-Mesh, nicht auf das Urmesh), dann wieder Erfolg
  { reset(); ++total; GcodeSuite::G29(); bool a = mesh_is_new(); float meshA[4][4]; memcpy(meshA, z_values, sizeof(meshA)); w.probe_calls = 0; w.point_idx = 0; w.restore_msgs = 0; w.probe_script = good_script(); for (auto &v : w.probe_script) v += 0.5f; w.probe_script[19] = NAN; sv04next::native_thermal_gate.reset(); for (uint32_t t = 30000; t <= 52000u; t += 500u) sv04next::native_thermal_gate.observe(t, 60.0f, 60.0f, true); w.now_ms = 52000u;
    GcodeSuite::G29(); bool b = memcmp(z_values, meshA, sizeof(meshA)) == 0 && w.restore_msgs == 1; w.probe_calls = 0; w.point_idx = 0; w.restore_msgs = 0; w.probe_script = good_script(); w.probe_script[0] += 0.25f; w.probe_script[1] += 0.25f; GcodeSuite::G29(); bool c = sv04next::g29u_receipt.phase() == sv04next::G29UReceipt::Phase::RamOnlySuccess && w.restore_msgs == 0 && w.eeprom_saves == 0;
    if (a && b && c) std::printf("PASS  Q01 Folge Erfolg, Fehler (Rückfall auf Erfolgs-Mesh), Erfolg ohne Zwischen-Reset\n"); else { ++fails; std::printf("FAIL  Q01 Folgeläufe (Erfolg %d, Rückfall %d, Erfolg2 %d)\n", a, b, c); } }
  { reset(""); w.probe_script.clear(); for (int p = 0; p < 16; ++p) w.probe_script.push_back(2.0f + 0.01f * (float)p); GcodeSuite::G29(); ++total; bool ok = sv04next::g29u_receipt.phase() == sv04next::G29UReceipt::Phase::Never && w.restore_msgs == 0 && z_values[0][0] == 2.0f && w.eeprom_saves == 0; if (ok) std::printf("PASS  N01 normaler G29 (ohne U) unverändert: Mesh wird ersetzt, kein Beleg, kein Rollback\n"); else { ++fails; std::printf("FAIL  N01 normaler G29 verändert\n"); } }
  { reset(""); w.probe_script.assign(16, 1.0f); w.probe_script[5] = NAN; GcodeSuite::G29(); ++total; bool ok = w.restore_msgs == 0 && !mesh_is_old(); if (ok) std::printf("PASS  N02 normaler G29 mit Sondenfehler: OEM-Verhalten bleibt (kein Eingriff des Guards)\n"); else { ++fails; std::printf("FAIL  N02 normaler G29 wird vom Guard verändert\n"); } }
  std::printf("=== %d Szenarien, %d FAIL\n", total, fails); return fails ? 1 : 0;
}
