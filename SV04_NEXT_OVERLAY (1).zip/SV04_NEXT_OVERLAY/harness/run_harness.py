#!/usr/bin/env python3
"""Host-Harness: übersetzt den vom Overlay ERZEUGTEN G29.cpp-Text gegen eine MARLIN-ATTRAPPE und führt Fake-Sensor-Szenarien mit Fehlereinspeisung aus.
Stufe: SIMULATION (Host). Kein Marlin-Build, keine Hardware. Der Fixture-Text von G29.cpp erhält EINEN Eingriff (Fortschrittshaken im Schleifenkopf), damit der Mesh-Index wandert.
Aufruf: python3 harness/run_harness.py            (Exit 0 nur wenn alle Szenarien bestehen)"""
import contextlib, io, os, shutil, subprocess, sys, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; HERE = Path(__file__).resolve().parent; G29 = 'Marlin/src/gcode/bedlevel/abl/G29.cpp'; G28 = 'Marlin/src/gcode/calibrate/G28.cpp'
def build_tree(dest: Path) -> Path:
    sys.path[:0] = [str(ROOT / 'integration'), str(ROOT / 'tests')]
    with contextlib.redirect_stdout(io.StringIO()): import test_overlay_v14 as T
    import apply_native_guard_v15 as v15
    shutil.copytree(HERE / 'stub' / 'Marlin', dest / 'Marlin'); (dest / 'Marlin/src/feature/sv04_next').mkdir(parents=True, exist_ok=True)
    for h in (ROOT / 'include').glob('*.hpp'): shutil.copy2(h, dest / 'Marlin/src/feature/sv04_next' / h.name)
    src = dict(T.src); old = 'for (int i=0; i<16; i++) {'; assert src[G29].count(old) == 1
    src[G29] = src[G29].replace(old, 'for (int i=0; i<16; i++, g_next_point()) {')
    out = v15.render(src, *[(ROOT / 'include' / n).read_text(encoding='utf-8') for n in v15.HEADERS])
    (dest / G29).parent.mkdir(parents=True, exist_ok=True); (dest / G29).write_text(out[G29], encoding='utf-8')
    (dest / G28).parent.mkdir(parents=True, exist_ok=True); (dest / G28).write_text(out[G28], encoding='utf-8')
    for d in ('driver.cpp', 'driver_e2e.cpp'): shutil.copy2(HERE / d, dest / d)
    return dest
def compile_harness(tree: Path, extra=()):
    return subprocess.run(['g++', '-std=gnu++14', '-O1', '-Wall', '-Wextra', '-Wno-unused-parameter', '-Wno-misleading-indentation', '-I.', *extra, 'driver.cpp', G29, '-o', 'harness'], cwd=tree, capture_output=True, text=True)
def main():
    tmp = Path(tempfile.mkdtemp()); tree = build_tree(tmp); c = compile_harness(tree)
    if c.returncode or c.stderr.strip(): print('COMPILE-AUSGABE:\n' + c.stderr)
    if c.returncode: print('FAIL: Harness nicht übersetzbar'); return 1
    r = subprocess.run(['./harness'], cwd=tree, capture_output=True, text=True); sys.stdout.write(r.stdout); rc = r.returncode
    e = subprocess.run(['g++', '-std=gnu++14', '-O1', '-Wall', '-Wextra', '-Wno-unused-parameter', '-Wno-misleading-indentation', '-I.', 'driver_e2e.cpp', G29, G28, '-o', 'e2e'], cwd=tree, capture_output=True, text=True)
    if e.returncode or e.stderr.strip(): print('COMPILE-AUSGABE e2e:\n' + e.stderr)
    if e.returncode: print('FAIL: E2E-Harness nicht übersetzbar'); return 1
    r2 = subprocess.run(['./e2e'], cwd=tree, capture_output=True, text=True); sys.stdout.write(r2.stdout); return rc or r2.returncode
if __name__ == '__main__': sys.exit(main())
